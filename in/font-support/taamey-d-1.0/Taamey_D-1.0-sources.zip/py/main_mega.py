"""Build and check the maintained Taamey D font without requiring PowerShell."""

import argparse
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import sys

REPO_ROOT = Path(__file__).resolve().parent.parent
FONT_DIRECTORY = Path("font-m-TaD")
FONT_STEM = "Taamey_D"
FONTFORGE_SCRIPT = FONT_DIRECTORY / "ffscript_generate_sfd_n_ttf.py"


def find_fontforge(explicit_path=None):
    """Prefer an explicit command, then PATH, then the existing Windows layouts."""
    if explicit_path:
        command = shutil.which(explicit_path)
        if command:
            return str(Path(command).absolute())
        raise RuntimeError(f"FontForge command not found: {explicit_path}")
    command = shutil.which("fontforge")
    if command:
        return str(Path(command).absolute())
    if os.name == "nt":
        for variable in ("ProgramFiles", "ProgramFiles(x86)"):
            directory = os.environ.get(variable)
            if directory:
                batch = Path(directory) / "FontForgeBuilds" / "fontforge.bat"
                if batch.is_file():
                    return str(batch)
    raise RuntimeError("FontForge not found; put it on PATH or pass --fontforge")


def child_environment():
    environment = os.environ.copy()
    # Older child entry points print Hebrew without configuring their streams.
    environment["PYTHONIOENCODING"] = "utf-8:backslashreplace"
    count = int(environment.get("GIT_CONFIG_COUNT", "0"))
    environment[f"GIT_CONFIG_KEY_{count}"] = "safe.directory"
    environment[f"GIT_CONFIG_VALUE_{count}"] = REPO_ROOT.as_posix()
    environment["GIT_CONFIG_COUNT"] = str(count + 1)
    return environment


def run(command, description, environment):
    print(f"== {description} ==", flush=True)
    result = subprocess.run(command, cwd=REPO_ROOT, env=environment, check=False)
    if result.returncode:
        raise RuntimeError(f"{description} failed (exit {result.returncode})")


def run_fontforge(command, environment):
    arguments = [command, "-script", FONTFORGE_SCRIPT.as_posix()]
    if os.name == "nt" and Path(command).suffix.lower() in {".bat", ".cmd"}:
        # cmd needs its own quoting, rather than the C argv quoting used by
        # subprocess for lists. Expand the path from the environment once so
        # spaces, &, %, Unicode, and ! in installation paths remain literal.
        environment = environment.copy()
        environment["HBOFONTS_FONTFORGE"] = command
        shell = os.environ.get("COMSPEC", "cmd.exe")
        arguments = (
            f'"{shell}" /d /s /v:off /c '
            f'""%HBOFONTS_FONTFORGE%" -script {FONTFORGE_SCRIPT.as_posix()}"'
        )
    run(arguments, "Generate Taamey D with FontForge", environment)


def generate(fontforge, environment):
    pairs = (
        (f"{FONT_STEM}.sym.fea", f"{FONT_STEM}.fea"),
        (f"{FONT_STEM}-nofea.sym.sfd", f"{FONT_STEM}-nofea.sfd"),
        ("license.sym.txt", "license.txt"),
    )
    for source, destination in pairs:
        output = (FONT_DIRECTORY / destination).as_posix()
        # Preserve the Windows generated-file attributes. POSIX needs no attrib
        # equivalent; do not alter its permission bits.
        if os.name == "nt":
            run(["attrib", "-r", output], "Unlock generated template", environment)
        run(
            [
                sys.executable,
                str(REPO_ROOT / "main_fill_in_template.py"),
                FONT_STEM,
                (FONT_DIRECTORY / source).as_posix(),
                output,
            ],
            f"Fill {output}",
            environment,
        )
        if os.name == "nt":
            run(["attrib", "+r", output], "Protect generated template", environment)
    run_fontforge(fontforge, environment)
    source = REPO_ROOT / FONT_DIRECTORY / f"{FONT_STEM}.woff2"
    destination = REPO_ROOT / "gh-pages" / "woff2" / source.name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
    if (
        hashlib.sha256(source.read_bytes()).digest()
        != hashlib.sha256(destination.read_bytes()).digest()
    ):
        raise RuntimeError("failed to synchronize the Taamey D documentation WOFF2")


def mega(fontforge, allow_legacy_latest=False):
    environment = child_environment()
    generate(fontforge, environment)
    run(
        [sys.executable, str(REPO_ROOT / "main_gen_doc.py")],
        "Generate maintained documentation",
        environment,
    )
    run(
        [
            sys.executable,
            str(REPO_ROOT / "main_run_shaping_checks.py"),
            (FONT_DIRECTORY / f"{FONT_STEM}.ttf").as_posix(),
        ],
        "Run Taamey D shaping checks (read every PASS/FAIL/SKIP result)",
        environment,
    )
    run(
        ["git", "diff", "--exit-code", "--", "qa-out/Taamey_D"],
        "Compare Taamey D QA reports with the checked-in baseline",
        environment,
    )
    arguments = [
        sys.executable,
        str(REPO_ROOT / "py" / "main_release.py"),
        "check",
        "--append-only-history",
    ]
    if allow_legacy_latest:
        arguments.append("--allow-legacy-latest")
    run(arguments, "Validate public download tree", environment)


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8", errors="backslashreplace")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--allow-legacy-latest", action="store_true")
    parser.add_argument(
        "--generate-only",
        action="store_true",
        help="only build and synchronize Taamey D",
    )
    parser.add_argument(
        "--fontforge", help="FontForge executable or Windows batch path"
    )
    args = parser.parse_args()
    try:
        fontforge = find_fontforge(args.fontforge)
        if args.generate_only:
            generate(fontforge, child_environment())
        else:
            mega(fontforge, args.allow_legacy_latest)
    except (OSError, RuntimeError, ValueError) as error:
        raise SystemExit(f"error: {error}") from error


if __name__ == "__main__":
    main()

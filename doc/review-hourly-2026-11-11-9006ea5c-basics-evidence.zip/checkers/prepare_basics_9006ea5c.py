"""Own a separate frozen Basics screen; do not access another repository."""

from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess

HOME = Path("/workspace/MAM-basics")
ROOT = Path("/workspace/scratch")
OUT = ROOT / "basics-9006ea5c-artifacts"
WORK = ROOT / "basics-9006ea5c-checkout"
BASE = "068c9256038a98150d75ed3553a64745a49d38fb"
HEAD = "9006ea5ca465642faa60aaf13fdd9391780b57ef"
PRIOR = "45b574a41c23ccab6e83c3898f79d65eed5562d9"


def git(*args):
    return subprocess.check_output(["git", "-C", str(HOME), *args])


assert (
    git("rev-parse", "HEAD").decode().strip()
    == "cb878aef91e692d5561435f00021f73b75868e45"
)
assert not git("status", "--porcelain=v1", "-z")
assert not WORK.exists() and not OUT.exists()
OUT.mkdir()
slot = ROOT / "basics-9006ea5c-slot.json"
with slot.open("x") as f:
    json.dump(
        dict(
            state="claimed",
            owner="saved-cloud Basics hourly 9006ea5c",
            claimed_utc=datetime.now(timezone.utc).isoformat(),
            home=str(HOME),
            checkout=str(WORK),
            source=HEAD,
        ),
        f,
        indent=2,
    )
subprocess.run(
    ["git", "-C", str(HOME), "worktree", "add", "--detach", str(WORK), HEAD], check=True
)
for name, ref, path in [
    ("AGENTS.md", HEAD, "AGENTS.md"),
    ("review-trial.md", HEAD, "doc/review-trial.md"),
    ("periodic-review.md", HEAD, "doc/periodic-review.md"),
    ("prior-status.md", PRIOR, "doc/review-trial-status.md"),
]:
    (OUT / name).write_bytes(git("show", ref + ":" + path))
(OUT / "source.diff").write_bytes(git("diff", "--binary", BASE, HEAD))
(OUT / "input.json").write_text(
    json.dumps(
        dict(
            base=BASE,
            head=HEAD,
            prior_receipt=PRIOR,
            home=str(HOME),
            checkout=str(WORK),
            interpreter=str(HOME / ".venv/bin/python"),
            created_utc=datetime.now(timezone.utc).isoformat(),
            changed_paths=git("diff", "--name-only", "-z", BASE, HEAD)
            .decode()
            .strip("\0")
            .split("\0"),
        ),
        indent=2,
    )
    + "\n"
)
print((OUT / "input.json").read_text())

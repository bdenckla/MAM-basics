"""Run exact committed sub-site checker on frozen base/head and retain warnings."""

from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import subprocess
import time

ROOT = Path("/workspace/scratch")
OUT = ROOT / "basics-9006ea5c-artifacts"
PYTHON = "/workspace/MAM-basics/.venv/bin/python"
results = {}
for side, work in [
    ("base", ROOT / "basics-9006ea5c-baseline"),
    ("head", ROOT / "basics-9006ea5c-checkout"),
]:
    name = "subsite-" + side
    assert not (OUT / (name + ".json")).exists(), "Do not repeat recorded checks"
    cmd = [PYTHON, "py/check_html_syntax_and_sanity.py", "gh-pages/MAM-with-doc"]
    start = datetime.now(timezone.utc).isoformat()
    timer = time.monotonic()
    result = subprocess.run(cmd, cwd=work, capture_output=True)
    elapsed = time.monotonic() - timer
    (OUT / (name + ".stdout")).write_bytes(result.stdout)
    (OUT / (name + ".stderr")).write_bytes(result.stderr)
    lines = result.stdout.decode().splitlines()
    count = re.search(r"Found (\d+) issue\(s\)\.", result.stdout.decode())
    assert count
    issues = [s for s in lines if s and not s.startswith(("Informational:", "Found "))]
    assert len(issues) == int(count[1])
    record = dict(
        command=cmd,
        cwd=str(work),
        started_utc=start,
        elapsed_seconds=round(elapsed, 6),
        exit_code=result.returncode,
        issue_count=len(issues),
        issues=issues,
    )
    (OUT / (name + ".json")).write_text(json.dumps(record, indent=2) + "\n")
    results[side] = record
    print(json.dumps({k: v for k, v in record.items() if k != "issues"}), flush=True)
    assert result.returncode == 1
before, after = [Counter(results[s]["issues"]) for s in ("base", "head")]
added = list((after - before).elements())
removed = list((before - after).elements())
expected = [
    "he_ws_intro_to_mam_gaya_text.html",
    "he_ws_intro_to_mam_gray_maqaf_1.html",
    "he_ws_intro_to_mam_pasleg.html",
    "review_of_artscroll_transliterated_linear_siddur.html",
    "review_of_hebrew_reader_for_the_pentateuch.html",
]
assert results["base"]["issue_count"] == 76 and results["head"]["issue_count"] == 81
assert not removed and sorted(added) == sorted(
    "orphan HTML (not linked from any page): misc/" + s for s in expected
)
independent = json.loads((OUT / "independent-check.json").read_text())
assert all(
    "MAM-with-doc/misc/" + s in independent["reachability"]
    and len(independent["reachability"]["MAM-with-doc/misc/" + s]) == 2
    for s in expected
)
summary = dict(
    result="EXPECTED_NONZERO_REPORTS",
    base_issues=76,
    head_issues=81,
    base_exit_code=1,
    head_exit_code=1,
    added_issues=added,
    removed_issues=removed,
    disposition="All five added reports are orphan-within-subsite diagnostics for pages linked directly from the deployment-root index. All 76 old issues remain; this is not a clean checker pass. No newly broken destination identified.",
    limits="Local sub-site scan excludes the top-level index; no W3C/live requests or broad suite.",
)
(OUT / "subsite-comparison.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
scratch = ROOT / "basics-9006ea5c-checkout/py/novc_basics_9006ea5c_check.py"
assert scratch.read_bytes() == (ROOT / "check_basics_9006ea5c.py").read_bytes()
scratch.unlink()
assert not subprocess.check_output(
    [
        "git",
        "-C",
        str(ROOT / "basics-9006ea5c-checkout"),
        "status",
        "--porcelain=v1",
        "-z",
    ]
)
assert not subprocess.check_output(
    [
        "git",
        "-C",
        str(ROOT / "basics-9006ea5c-baseline"),
        "status",
        "--porcelain=v1",
        "-z",
    ]
)

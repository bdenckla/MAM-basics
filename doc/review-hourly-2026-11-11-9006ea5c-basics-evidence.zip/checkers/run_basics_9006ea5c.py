"""Record sequential maintained focused checks without accepting generated changes."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import time

WORK = Path("/workspace/scratch/basics-9006ea5c-checkout")
OUT = Path("/workspace/scratch/basics-9006ea5c-artifacts")
PYTHON = "/workspace/MAM-basics/.venv/bin/python"
HEAD = "9006ea5ca465642faa60aaf13fdd9391780b57ef"
stages = [
    ("gen-misc", [PYTHON, "py/main_authored.py", "gen-misc"]),
    (
        "focused-tests",
        [
            PYTHON,
            "py/main_test.py",
            "py/tests/test_site_index_links.py",
            "py/tests/test_deploy_root_html.py",
            "py/tests/test_prose_conventions.py",
            "py/tests/test_prose_mark_order.py",
            "-q",
        ],
    ),
    (
        "changed-source-black",
        [
            PYTHON,
            "-m",
            "black",
            "--check",
            "py/author_site/site_data.py",
            "py/main_authored.py",
            "py/author_misc/he_ws_intro_to_mam_gaya_text.py",
            "py/author_misc/review_of_hebrew_reader_for_the_pentateuch.py",
            "py/author_misc/urwotm_common.py",
        ],
    ),
]


def git(*args):
    return subprocess.check_output(["git", "-C", str(WORK), *args])


assert git("rev-parse", "HEAD").decode().strip() == HEAD
assert not git("status", "--porcelain=v1", "-z")
for name, cmd in stages:
    record = OUT / (name + ".json")
    assert not record.exists(), "Never repeat a completed recorded stage"
    start = datetime.now(timezone.utc).isoformat()
    timer = time.monotonic()
    with (OUT / (name + ".log")).open("wb") as log:
        result = subprocess.run(cmd, cwd=WORK, stdout=log, stderr=subprocess.STDOUT)
    elapsed = time.monotonic() - timer
    status = git("status", "--porcelain=v1", "-z")
    (OUT / (name + "-status.z")).write_bytes(status)
    (OUT / (name + "-tracked.diff")).write_bytes(git("diff", "--binary"))
    output = dict(
        command=cmd,
        cwd=str(WORK),
        started_utc=start,
        elapsed_seconds=round(elapsed, 6),
        exit_code=result.returncode,
        status_clean=not status,
        log_sha256=hashlib.sha256((OUT / (name + ".log")).read_bytes()).hexdigest(),
    )
    record.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output), flush=True)
    assert (
        result.returncode == 0 and not status
    ), "Preserve failure or output differences before proceeding"

import datetime
import json
import pathlib
import subprocess
import time

task = pathlib.Path(__file__).parent
src = task / 'source'
out = task / 'evidence'
py = '/workspace/MAM-basics/.venv/bin/python'
stages = [
    ('diff-check', ['git','diff','--check','4f2ed30c5ba8764baa01884637c90248892576f5','efb3bd01cb3ed01f8f37d4e7cd6af59cb146734f']),
    ('black', [py,'-m','black','--check','py/author_site/stress_helper_comparison.py','py/main_authored.py']),
    ('gen-site',[py,'py/main_authored.py','gen-site','--trust-surveys']),
    ('focused-tests',[py,'py/main_test.py','py/tests/test_prose_conventions.py','py/tests/test_prose_mark_order.py','py/tests/test_shared_html_styles.py','py/tests/test_site_links_relative.py','py/tests/test_site_index_links.py','-q']),
    ('scoped-html',[py,'py/check_html_syntax_and_sanity.py','gh-pages/stress-helpers']),
]
results=[]
for name,cmd in stages:
    start=datetime.datetime.now(datetime.UTC).isoformat()
    tick=time.monotonic()
    with (out/f'{name}.txt').open('wb') as f:
        r=subprocess.run(cmd,cwd=src,stdout=f,stderr=subprocess.STDOUT)
    result={'name':name,'command':cmd,'cwd':str(src),'start_utc':start,'wall_seconds':round(time.monotonic()-tick,6),'exit':r.returncode}
    results.append(result)
    (out/'commands.json').write_text(json.dumps(results,indent=2)+'\n')
    (out/f'{name}-post.diff').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=src))
    status=subprocess.check_output(['git','status','--porcelain=v1','-z'],cwd=src)
    (out/f'{name}-post-status.bin').write_bytes(status)
    print(json.dumps(result),flush=True)
    if status:
        raise SystemExit('Unexpected generated status: raw diff retained; triage required')
    if r.returncode and name != 'scoped-html':
        raise SystemExit(r.returncode)

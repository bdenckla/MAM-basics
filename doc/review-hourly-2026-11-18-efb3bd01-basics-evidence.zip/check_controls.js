const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');
const task = __dirname;
const data = JSON.parse(fs.readFileSync(path.join(task,'evidence/controls-input.json'),'utf8'));
function elem(value='') {
  return {value,defaultValue:value,textContent:'',attrs:{},hidden:true,listeners:{},
    addEventListener(event,fn){this.listeners[event]=fn;},
    getAttribute(name){return this.attrs[name];},
    setAttribute(name,value){this.attrs[name]=String(value);}};
}
const es = Object.fromEntries(['hebrew-size','size-value','size-reset','toggle-images','find','filter','batch','visible'].map(k=>['#'+k,elem()]));
es['#hebrew-size'].value = es['#hebrew-size'].defaultValue = '30';
es['#toggle-images'].attrs['aria-expanded'] = 'false';
const rows = data.rows.map(r=>({...r,cells:r.cells.map(textContent=>({textContent})),hidden:false}));
const crops = Array.from({length:rows.length+1},()=>elem());
const styles = {};
const document = {querySelector:s=>es[s],querySelectorAll:s=>s.endsWith('.scan')?crops:rows,
  documentElement:{style:{setProperty:(key,value)=>{styles[key]=value;}}}};
vm.runInNewContext(fs.readFileSync(path.join(task,'source/gh-pages/stress-helpers/controls.js'),'utf8'),{document});
let checks=0;
const marks = new Set([...Array(0x05bd-0x0591+1)].map((_,i)=>0x0591+i).concat([...Array(0x05c7-0x05bf+1)].map((_,i)=>0x05bf+i)));
function key(text){return [...text.toLowerCase()].filter(c=>!marks.has(c.codePointAt(0))).join('');}
assert.equal(rows.filter(r=>!r.hidden).length,93);checks++;
for(const category of data.filters) for(const batch of data.batches) for(const query of data.queries){
  es['#filter'].value=category; es['#batch'].value=batch; es['#find'].value=query;
  es['#find'].listeners.input();
  const expected=data.rows.map(r=>(!category||r.dataset.filter===category)&&(!batch||r.dataset.batch===batch)&&r.cells.some(c=>key(c).includes(key(query.trim()))));
  assert.deepEqual(rows.map(r=>!r.hidden),expected);
  const n=expected.filter(Boolean).length;
  assert.equal(es['#visible'].textContent,n+(n===1?' difference':' differences'));
  checks+=2;
}
es['#find'].value='';es['#filter'].value='';es['#batch'].value='1';es['#batch'].listeners.change();
assert.equal(rows.filter(r=>!r.hidden).length,37);checks++;
es['#batch'].value='2';es['#batch'].listeners.change();assert.equal(rows.filter(r=>!r.hidden).length,56);checks++;
es['#filter'].value=data.filters[1];es['#filter'].listeners.change();
assert.equal(rows.filter(r=>!r.hidden).length,data.rows.filter(r=>r.dataset.batch==='2'&&r.dataset.filter===data.filters[1]).length);checks++;
const visibility=rows.map(r=>r.hidden);
for(const show of [true,false,true,false]){
  es['#toggle-images'].listeners.click();
  assert.ok(crops.every(c=>c.hidden===!show));
  assert.equal(es['#toggle-images'].attrs['aria-expanded'],String(show));
  assert.equal(es['#toggle-images'].textContent,show?'Hide images':'Show images');
  assert.deepEqual(rows.map(r=>r.hidden),visibility);checks+=4;
}
for(const v of ['20','48','34']){es['#hebrew-size'].value=v;es['#hebrew-size'].listeners.input();assert.equal(styles['--hebrew-size'],v+'px');assert.equal(es['#size-value'].textContent,v+' px');checks+=2;}
es['#size-reset'].listeners.click();assert.equal(styles['--hebrew-size'],'30px');assert.equal(es['#hebrew-size'].value,'30');checks+=2;
console.log(JSON.stringify({rows:rows.length,categories:data.filters.length,batches:data.batches.length,queries:data.queries.length,filter_combinations:data.filters.length*data.batches.length*data.queries.length,counted_assertions:checks,actual_committed_controls:true,browser:false},null,2));

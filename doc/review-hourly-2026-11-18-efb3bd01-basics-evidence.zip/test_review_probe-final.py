import collections
import copy
import json
import pathlib
import re
import subprocess
import urllib.parse

import pytest
from lxml import html
from author_site import stress_helper_comparison as gen
from mb_cmn import hebrew_verse_numerals as hvn

TASK = pathlib.Path(__file__).parent
SRC = TASK / 'source'
EVID = TASK / 'evidence'
BASE = '4f2ed30c5ba8764baa01884637c90248892576f5'
MERGE = '2a5412afb63d0dc974f897881d3f7509890f3271'
HEAD = 'efb3bd01cb3ed01f8f37d4e7cd6af59cb146734f'

def blob(commit, path):
    return subprocess.check_output(['git','show',f'{commit}:{path}'],cwd=SRC)

def rows(raw):
    return re.findall(r'<tr data-filter=.*?</tr>',raw.decode(),re.S)

def current():
    return {e:json.loads((SRC/f'in/stress-helpers/{e}.json').read_text()) for e in gen._EDITIONS}

def test_data_and_rows():
    data=current()
    old_results=json.loads(blob(BASE,'in/stress-helpers/results.json'))['editions']
    changed=[]
    citations=[]
    record_count=0
    for edition,d in data.items():
        original=json.loads(blob(BASE,f'in/stress-helpers/{edition}.json'))
        earlier=original['differences']+old_results[edition]['differences']
        assert len(d['differences']) == len(earlier)
        assert {k:v for k,v in original.items() if k!='differences'} == {k:v for k,v in d.items() if k!='differences'}
        split=len(original['differences'])
        for i,(before,after) in enumerate(zip(earlier,d['differences'])):
            record_count+=1
            assert after['batch'] == (1 if i<split else 2)
            assert set(after) == set(before)|{'batch'}
            assert before['mam'].encode() == after['mam'].encode()
            assert before['printed'].encode() == after['printed'].encode()
            delta={k for k in before if before[k]!=after[k]}
            if delta:
                ref=(edition,after['book'],after['chapter'],after['verse'])
                changed.append({'reference':ref,'fields':sorted(delta)})
                if after['book']=='Ezekiel' and after['chapter']==16 and after['verse']==61:
                    assert delta == {'category','notes'}
                    assert after['category']=='redundant-edition'
                else:
                    assert delta == {'notes'}
                    assert after['notes'][:-1] == before['notes']
                    note=after['notes'][-1]
                    assert set(note)=={'text','href'}
                    citations.append((ref,note))
    assert record_count==125 and len(changed)==9 and len(citations)==7
    old_rows={1:rows(blob(BASE,'gh-pages/stress-helpers/index.html')),2:rows(blob(BASE,'gh-pages/stress-helpers/results.html'))}
    merged=rows(blob(MERGE,'gh-pages/stress-helpers/index.html'))
    new=rows(blob(HEAD,'gh-pages/stress-helpers/index.html'))
    assert len(new)==len(merged)==93
    for batch,n in ((1,37),(2,56)):
        got=[r.replace(f' data-batch="{batch}"','') for r in merged if f'data-batch="{batch}"' in r]
        assert len(got)==n==len(old_rows[batch])
        altered=[]
        for before,after in zip(old_rows[batch],got):
            if before!=after:
                assert batch==2 and 'c16v61' in before
                def unchanged_cells(row):
                    row=re.sub(r' data-filter="[^"]*"','',row)
                    return re.sub(r'<td class="difference">.*?</td>','',row,flags=re.S)
                assert unchanged_cells(before)==unchanged_cells(after)
                altered.append(before)
        assert len(altered)==(1 if batch==2 else 0)
    changed_row_ids=[]
    for before,after in zip(merged,new):
        if before!=after:
            a=html.fromstring(after)
            b=html.fromstring(before)
            ap=a.xpath('.//td[@class="difference"]/p')
            bp=b.xpath('.//td[@class="difference"]/p')
            assert len(ap)==len(bp)+1
            ap[-1].getparent().remove(ap[-1])
            assert html.tostring(a)==html.tostring(b)
            changed_row_ids.append(a.xpath('.//th/a/@href')[0])
    assert len(changed_row_ids)==6
    dom=html.fromstring((SRC/'gh-pages/stress-helpers/index.html').read_bytes())
    rendered=dom.xpath('//table[@id="observations"]/tbody/tr')
    # Independently group on source values and attributes, rather than generator rows.
    groups=collections.defaultdict(list)
    for edition,d in data.items():
        for r in d['differences']:
            k=tuple(r.get(f) for f in ('book','chapter','verse','atom','strand','location','mam','printed','verse_href','category','batch'))
            groups[k].append(edition)
    assert len(groups)==93
    actual=[]
    for row in rendered:
        key=(row.get('data-batch'),row.xpath('.//th/a/@href')[0],row.xpath('.//span[@class="hebrew"]/text()')[0],row.xpath('.//span[@class="hebrew"]/text()')[1])
        matches=[(k,e) for k,e in groups.items() if (str(k[-1]),k[8],k[6],k[7])==key]
        assert len(matches)==1
        k,editions=matches[0]
        suffix={'koren':'Kor','simanim-tanakh':'Sim'}[editions[0]] if len(editions)==1 else 'KorSim'
        assert row.get('data-filter')==k[9]+'-'+suffix
        actual.append(k)
    assert len(set(actual))==93
    assert [k[:3] for k in actual] == [k[:3] for k in sorted(actual,key=lambda k:(gen.bib_locales.get_bknu(k[0]),k[1],k[2],k[3] or 0))]
    populations=collections.Counter(r.get('data-filter') for r in rendered)
    for option in dom.xpath('//select[@id="filter"]/option'):
        assert int(re.search(r'\((\d+)\)',option.text)[1]) == (93 if not option.get('value') else populations[option.get('value')])
    assert [o.get('value') for o in dom.xpath('//select[@id="batch"]/option')]==['','1','2']
    # Resolve all local links/assets and anchors without any network request.
    count=0
    for node in dom.xpath('//*[@href or @src]'):
        for attr in ('href','src'):
            if not node.get(attr): continue
            u=urllib.parse.urlsplit(node.get(attr))
            if u.scheme or u.netloc: continue
            target=(SRC/'gh-pages/stress-helpers'/urllib.parse.unquote(u.path)).resolve()
            assert target.is_file(),str(target)
            if u.fragment:
                targetdom=html.fromstring(target.read_bytes())
                assert targetdom.xpath('//*[@id=$id or @name=$id]',id=urllib.parse.unquote(u.fragment))
            count+=1
    assert not (SRC/'gh-pages/stress-helpers/results.html').exists()
    assert not (SRC/'in/stress-helpers/results.json').exists()
    assert subprocess.run(['git','grep','-n','-E','stress-helpers/results[.]html|_RESULTS_HREF|_RESULTS_FNAME|in/stress-helpers/results[.]json','--','py','gh-pages'],cwd=SRC,capture_output=True).returncode==1
    # Retain the actual cited public note text for human comparison, not source research.
    citation_evidence=[]
    for ref,note in citations:
        u=urllib.parse.urlsplit(note['href'])
        target=(SRC/'gh-pages/stress-helpers'/u.path).resolve()
        targetdom=html.fromstring(target.read_bytes())
        element=targetdom.xpath('//*[@id=$id]',id=u.fragment)[0]
        if 'doc' not in u.fragment:
            text=element.getparent().text_content()
        else:
            text=element.text_content()
        raw_rel='in/mam-ws/'+target.name.replace('-big-doc.html','.json').replace('.html','.json')
        raw=json.loads((SRC/raw_rel).read_text())
        chapter=hvn.INT_TO_STR_DIC[ref[2]]
        verse=hvn.INT_TO_STR_DIC[ref[3]]
        matches=[s for s in raw[chapter] if re.search(r'\{\{מ:פסוק\|[^|]+\|'+chapter+r'\|'+verse+r'(?:\||\}\})',s)]
        assert len(matches)==1
        raw_verse=matches[0]
        citation_evidence.append({'reference':ref,'note':note,'public_target':str(target.relative_to(SRC)),'fragment':u.fragment,'target_text':text,'raw_source_path':raw_rel,'raw_source_verse':raw_verse})
    (EVID/'public-citations.json').write_text(json.dumps(citation_evidence,ensure_ascii=False,indent=2)+'\n')
    (EVID/'data-dom-summary.json').write_text(json.dumps({'source_records':125,'all_mam_printed_bytes_preserved':True,'changed_fields':changed,'rows':93,'batch_rows':{'1':37,'2':56},'new_citations':7,'distinct_changed_note_rows':6,'local_attributes_resolved':count,'row_membership_order_options_exact':True},indent=2)+'\n')
    # Pass actual DOM text/options to the JavaScript probe.
    payload={'rows':[{'dataset':{'filter':r.get('data-filter'),'batch':r.get('data-batch')},'cells':[c.text_content() for c in r]} for r in rendered], 'filters':[o.get('value') for o in dom.xpath('//select[@id="filter"]/option')], 'batches':['','1','2'],'queries':['','nomatch-ever','Exod','ezek','  EXOD  ',*[r.xpath('.//span[@class="hebrew"]/text()')[0] for r in rendered]]}
    (EVID/'controls-input.json').write_text(json.dumps(payload,ensure_ascii=False)+'\n')

def test_adversarial_validation():
    original=current()['koren']
    changed=[]
    for kind in ('missing-batch','unknown-batch','missing-notes','repeated-batch'):
        d=copy.deepcopy(original)
        if kind=='missing-batch': del d['differences'][0]['batch']
        elif kind=='unknown-batch': d['differences'][0]['batch']=3
        elif kind=='missing-notes': next(r for r in d['differences'] if r['batch']==2)['notes']=[]
        else:
            r=copy.deepcopy(d['differences'][0]);r.update(batch=2,category='extra-helper',printed=d['differences'][1]['printed']);d['differences'].append(r)
        with pytest.raises(ValueError): gen._check('koren',d,SRC/'gh-pages/stress-helpers')
        changed.append(kind)
    (EVID/'adversarial-summary.json').write_text(json.dumps({'refused':changed},indent=2)+'\n')

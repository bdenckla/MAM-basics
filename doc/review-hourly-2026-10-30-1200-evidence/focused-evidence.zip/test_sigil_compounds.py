import collections
import json
import re
import subprocess
from pathlib import Path

from sigils import inventory as inv

OUT = Path('/workspace/scratch/review-hourly-20261030-1200/basics')
ROOT = Path('/workspace/MAM-basics')
OLD = {}
exec(compile((OUT / 'inventory-base.py').read_text(encoding='utf-8'), 'inventory-base.py', 'exec'), OLD)
QUOTES = set(map(chr, [0x27, 0x22, 0x2019, 0x201D, 0x5F3, 0x5F4]))


def letter(c):
    return 'א' <= c <= 'ת'


def alnum(c):
    return letter(c) or c in '0123456789'


def eat(text, i, predicate):
    while i < len(text) and predicate(text[i]):
        i += 1
    return i


def part(text, i):
    end = eat(text, i, alnum)
    if end == i:
        return i
    if end < len(text) and text[end] in QUOTES:
        quoted_end = eat(text, end + 1, alnum)
        if quoted_end > end + 1:
            end = quoted_end
    return end


def tails(text, end):
    while end < len(text) and text[end] == '-':
        after = part(text, end + 1)
        if after == end + 1:
            break
        end = after
    return end


def neighbor(c):
    n = ord(c)
    return c.isalnum() or c == '_' or 0x591 <= n <= 0x5BD or n in {0x5BF, 0x5C1, 0x5C2, 0x5C4, 0x5C5, 0x5C7, 0x5BE, 0xFB1E, 0x34F, 0x2D} or c in QUOTES


def independent_matches(text):
    result = []
    i = 0
    while i < len(text):
        prefix = eat(text, i, letter)
        end = i
        if prefix > i:
            if prefix < len(text) and text[prefix] in QUOTES:
                after = eat(text, prefix + 1, alnum)
                if after > prefix + 1:
                    end = tails(text, after)
            if end == i and prefix < len(text) and text[prefix] == '(':
                after = eat(text, prefix + 1, letter)
                if after > prefix + 1 and after < len(text) and text[after] == ')':
                    end = after + 1
            if end == i and prefix < len(text) and text[prefix] == '-':
                after = tails(text, prefix)
                if after > prefix:
                    end = after
            if end == i:
                after = eat(text, prefix, lambda c: c in '0123456789')
                if after > prefix:
                    end = tails(text, after)
            left_clear = i == 0 or not neighbor(text[i - 1])
            if end == i and left_clear and i + 1 < len(text) and text[i + 1] in '?!':
                end = i + 2
            if end == i and left_clear and (i + 1 == len(text) or not neighbor(text[i + 1])):
                end = i + 1
        if end == i:
            i += 1
            continue
        token = text[i:end]
        if OLD['_looks_authority_like_expression'](token) or any(c in token for c in QUOTES):
            result.append(token)
        i = end
    return result


def independent_unpointed(text):
    def in_run(c):
        n = ord(c)
        return 0x5D0 <= n <= 0x5EA or 0x591 <= n <= 0x5BD or n in {0x5BF, 0x5C1, 0x5C2, 0x5C4, 0x5C5, 0x5C7, 0x5BE, 0xFB1E, 0x34F}
    def point(c):
        n = ord(c)
        return 0x591 <= n <= 0x5BD or n in {0x5BF, 0x5C1, 0x5C2, 0x5C4, 0x5C5, 0x5C7, 0xFB1E}
    out = []
    i = 0
    while i < len(text):
        end = eat(text, i, in_run)
        if end == i:
            out.append(text[i])
            i += 1
        else:
            if not any(point(c) for c in text[i:end]):
                out.append(text[i:end])
            i = end
    return ''.join(out)


def test_all_notes_against_independent_scanner():
    books = inv.plus.read_parsed_plus_bk39s(mam_parsed_path=inv.paths.mam_parsed_path())
    expected = {}
    old_counts, new_counts = collections.Counter(), collections.Counter()
    count = cgj_count = 0
    for book in inv.tbn.ALL_BK39_IDS:
        for bcvt, minirow in books[book]['verses_plus'].items():
            for column, data in [('CP', minirow.CP), ('EP', minirow.EP)]:
                for template in inv.doc_extract.find_docnote_tmpls(data):
                    count += 1
                    text = inv._note_text(template)
                    cgj_count += text.count(chr(0x34F))
                    scan = independent_unpointed(text)
                    assert scan == inv._without_pointed_hebrew(text)
                    tokens = independent_matches(scan)
                    assert tokens == inv._prose_abbreviation_tokens(scan), (book, bcvt, tokens)
                    old_counts.update(OLD['_prose_abbreviation_tokens'](OLD['_without_pointed_hebrew'](text)))
                    new_counts.update(tokens)
                    for token in tokens:
                        row = expected.setdefault(token, {'count': 0, 'examples': []})
                        row['count'] += 1
                        if len(row['examples']) < 5:
                            row['examples'].append({'ref': inv._bcvt_to_ref(bcvt), 'column': column, 'source_kind': 'prose-token', 'note_text': text})
    committed = json.loads((ROOT / 'out/sigil-inventory.json').read_text(encoding='utf-8'))
    assert expected == {r['item']: {k: v for k, v in r.items() if k != 'item'} for r in committed['prose_tokens']}
    report = {'notes': count, 'cgj_occurrences': cgj_count, 'old_total_prose_tokens': sum(old_counts.values()), 'new_total_prose_tokens': sum(new_counts.values()), 'removed_occurrences': sum((old_counts - new_counts).values()), 'added_occurrences': sum((new_counts - old_counts).values()), 'all_streams_counts_examples_match': True, 'header': committed['header']['counts']}
    (OUT / 'corpus-audit.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')


def test_compounds_quote_forms_and_cgj():
    for value in ['מ"ג-ק-מ', 'א-מ"ק', 'ל-כתי"ש1', 'ש1-כתיב', 'ב"א-ב"נ', 'ק-מ-כתיב']:
        assert inv._prose_abbreviation_tokens(value) == [value]
    for q in QUOTES:
        token = 'מ' + q + 'ק-ל' + q + 'א-ש1-כתיב'
        assert inv._prose_abbreviation_tokens(token) == [token]
        assert inv._looks_authority_like_expression('ואח' + q + 'כ')
    pointed = 'א' + chr(0x5B4) + chr(0x34F) + 'ב'
    assert inv._without_pointed_hebrew(pointed) == ''
    unpointed = 'א' + chr(0x34F) + 'ב'
    assert inv._without_pointed_hebrew(unpointed) == unpointed
    assert inv._prose_abbreviation_tokens("''ל''") == []


def test_shared_authority_sections_unchanged():
    old = json.loads(subprocess.check_output(['git', '-C', str(ROOT), 'show', 'fc9c6f14eea3b48bc152a394acc0ca1aef43aeb0:out/sigil-inventory.json']))
    new = json.loads((ROOT / 'out/sigil-inventory.json').read_text(encoding='utf-8'))
    assert old['expressions'] == new['expressions']
    assert old['expression_tokens'] == new['expression_tokens']
    assert old['header']['counts']['notes_with_matches'] == new['header']['counts']['notes_with_matches']
    assert next(r for r in new['prose_tokens'] if r['item'] == 'א(ס)') == next(r for r in old['prose_tokens'] if r['item'] == 'א(ס)')

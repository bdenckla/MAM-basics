"""Independent committed-output accounting; synthetic fixtures do not port new credits."""
from collections import Counter
from dataclasses import replace
import copy,csv,hashlib,html,io,json,re,subprocess
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlsplit,unquote
import pytest
from mb_cmn import paths
from mb_diff_mpu import mpplus_credits as c,mpplus_html as h,mpplus_contributors as p
from subcommands import diff_mpplus

ROOT=paths.repo_root();FOLDER=ROOT/'gh-pages/MAM-with-doc/change-log'
BASE='5ed853e2670bac7a7158553848cb66fad375fb53'
def blob(path):return subprocess.check_output(['git','show',BASE+':'+path],cwd=ROOT)
def reports():
    return [e['name']for e in json.loads((FOLDER/'releases.json').read_text())['releases']]+['unpinned-latest']
class Info(HTMLParser):
    def __init__(self):super().__init__(convert_charrefs=True);self.ids=[];self.links=[];self.data=[]
    def handle_starttag(self,tag,attrs):
        d=dict(attrs)
        if 'id'in d:self.ids.append(d['id'])
        if tag=='a'and'href'in d:self.links.append(d['href'])
    def handle_data(self,d):self.data.append(d)
def cards(text):
    return {m.group(1):m.group(0)for m in re.finditer(r'<div class="diff-card" id="([^"]+)" .*?\n</div>',text,re.S)}

def test_port_accounting_and_frozen_capture():
    data=json.loads(c.CREDITS_JSON.read_text());credits=c.load_credits()
    assert len(credits)==62 and len(data['contributors'])==8
    rows=list(csv.reader(io.StringIO((ROOT/'in/mam-go-changes-tab/changes.csv').read_bytes().decode(),newline='')))
    raw=(ROOT/'in/mam-go-changes-tab/changes.csv').read_bytes()
    assert len(rows)==1084 and len(raw)==189511 and hashlib.sha256(raw).hexdigest()=='030cb757027c00754600a43a989d8fd5bf6b8f2ed3f6196f23d39d6f1567684e'
    refs=[(i,e['row'])for i,r in enumerate(data['credits'])for e in r['evidence']if e['kind']=='mam-sheet-changes-row']
    assert len({i for i,_ in refs})==61 and len({r for _,r in refs})==28
    assert not{249,264,273}&{r for _,r in refs}
    for _,r in refs:assert 3<=r<=len(rows)and'credit'in rows[r-1][3].lower()
    exceptional=[data['credits'][i]for i,r in refs if r==142]
    assert len(exceptional)==1 and tuple(exceptional[0][k]for k in['book','chapter','verse'])==('2Samuel',24,10)
    assert [i for i,r in refs if r==9]==[i for i,r in refs if r==240]
    row104=[data['credits'][i]for i,r in refs if r==104]
    assert len(row104)==2 and all(r['contributor']=='anonymous-contributor-at-hebrew-wikisource'for r in row104)
    old=json.loads(blob('in/mam-change-log-credits.json'))['credits'][0]
    first=copy.deepcopy(data['credits'][0]);first['contributor']=old['contributor'];assert first==old

def test_ids_forms_links_and_output_preservation():
    credits=c.load_credits();matches=c.require_each_record_matched_once(FOLDER,reports())
    counts=Counter(m.report for m in matches)
    assert counts=={'2025-03-19a':39,'2026-03-06':4,'2026-03-16':1,'2026-09-17':17,'unpinned-latest':1}
    cardmap={};all_ids=[]
    for name in reports():
        path=f'gh-pages/MAM-with-doc/change-log/{name}.html'
        old=blob(path).decode();new=(ROOT/path).read_text(encoding='utf-8')
        def strip(t):
            return re.sub(r' id="credit-[^"]+"','',re.sub(r'<p class="credit">.*?</p>\n','',t))
        assert strip(old)==strip(new)
        info=Info();info.feed(new);assert len(info.ids)==len(set(info.ids));all_ids.extend(i for i in info.ids if i.startswith('credit-'))
        cardmap[name]=cards(new)
        olddata=json.loads(blob(path.replace('.html','.json')));newdata=json.loads((ROOT/path.replace('.html','.json')).read_bytes())
        for d in [olddata,newdata]:
            for entry in d['diffs']:entry.pop('credits',None)
        assert olddata==newdata
    assert len(all_ids)==len(set(all_ids))==62
    page=(FOLDER/'contributors.html').read_text();info=Info();info.feed(page)
    expected_forms=[];rubies=0
    for match in matches:
        credit=match.credit;selector={'change':dict(zip(('old','new'),credit.change))}if credit.change else{'templates':dict(zip(('added','removed'),map(list,credit.templates)))}
        digest=hashlib.sha256(json.dumps(selector,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()[:8]
        ident=f'credit-{credit.book.replace(" ","-")}-{credit.chapter}-{credit.verse}-{digest}'
        assert c.card_id(credit)==ident
        card=cardmap[match.report][ident];assert h.credit_line_html(credit)in card
        forms=re.search(r'(?m)^<div class="change-display">.*$',card)
        if forms:expected_forms.append(forms.group());rubies+='ruby'in forms.group()
    actual_forms=re.findall(r'(?m)^<div class="change-display">.*$',page)
    assert Counter(actual_forms)==Counter(expected_forms)and rubies>=1
    local=[link for link in info.links if not urlsplit(link).scheme]
    assert len(local)==125
    for link in local:
        url=urlsplit(link);target=FOLDER/unquote(url.path);assert target.is_file()
        if url.fragment:
            target_info=Info();target_info.feed(target.read_text());assert target_info.ids.count(unquote(url.fragment))==1
    linkline='<p><a href="contributors.html">Contributors credited in the MAM change logs</a></p>\n'
    assert(FOLDER/'index.html').read_text().replace(linkline,'',1)==blob('gh-pages/MAM-with-doc/change-log/index.html').decode()
    for name in ['style.css','filter.js','releases.json']:
        assert(FOLDER/name).read_bytes()==blob('gh-pages/MAM-with-doc/change-log/'+name)
    assert'contributors.html'in diff_mpplus.generated_artifact_names()
    result=dict(records=len(credits),contributors=8,report_counts=dict(counts),stable_unique_ids=len(all_ids),local_navigation_links=len(local),card_forms_copied_exactly=len(actual_forms),ruby_cards=rubies,port_source_rows=28,only_declared_product_changes=True)
    Path(__file__).with_name('port-preservation.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')

def test_identity_stability_and_suffixes():
    credit=c.load_credits()[0];ident=c.card_id(credit)
    changed=replace(credit,number=999,contributor='other',name='<Other>',user_page=None,evidence=())
    assert c.card_id(changed)==ident
    assert [c.card_id(x)for x in reversed(c.load_credits())]==list(reversed([c.card_id(x)for x in c.load_credits()]))
    assert h._card_ids([{'card_credits':[credit]}, {}, {'card_credits':[changed]}])==[ident,None,ident+'-2']
    assert c.card_id(replace(credit,change=(credit.change[0],credit.change[1]+'x')))!=ident

@pytest.mark.parametrize('fault',['absent','duplicate','verse-line','credit-line','forms'])
def test_contributors_refuses_bad_card(fault):
    credit=c.load_credits()[0];ident=c.card_id(credit)
    text=(FOLDER/'unpinned-latest.html').read_text();block=cards(text)[ident]
    if fault=='absent':text=text.replace(block,'')
    elif fault=='duplicate':text+='\n'+block
    elif fault=='verse-line':text=text.replace(block,block.replace('<div class="verse-ref">','<div class="wrong">',1))
    elif fault=='credit-line':text=text.replace(h.credit_line_html(credit),'<p>missing credit</p>')
    if fault=='forms':
        with pytest.raises(c.CreditError):p._shown(credit,None,'fixture')
    else:
        with pytest.raises(c.CreditError):p._read_card(text.split('\n'),'fixture',credit)

def test_escaping_and_structural_fallback():
    credit=replace(c.load_credits()[0],name='\u05d0<&"',user_page=None)
    out=h.credit_name_html(credit);assert out=='<bdi>\u05d0&lt;&amp;&quot;</bdi>'and'lang='not in out
    structural=replace(credit,change=None,templates=(('<&', '<&'),('other',)))
    out=p._shown(structural,None,'fixture')
    assert'<bdi>&lt;&amp;</bdi> x2'in out and'<bdi>other</bdi>'in out

def test_contributor_associations_and_order():
    matches=c.require_each_record_matched_once(FOLDER,reports());order={r:i for i,r in enumerate(reports())}
    text=(FOLDER/'contributors.html').read_text();groups=re.findall(r'<h2>(.*?)</h2>\n(.*?)(?=<h2>|</body>)',text,re.S)
    by_ident={m.credit.contributor:m.credit.name for m in matches}
    expected_names=sorted(by_ident,key=lambda k:(by_ident[k].casefold(),k))
    seen=0
    assert len(groups)==len(expected_names)==8
    for ident,(heading,body)in zip(expected_names,groups):
        head=Info();head.feed(heading);plain=''.join(head.data)
        assert plain.startswith(by_ident[ident]+' (')
        expected=[m for m in matches if m.credit.contributor==ident]
        expected.sort(key=lambda m:(order[m.report],m.entry,(FOLDER/(m.report+'.html')).read_text().index('id="'+c.card_id(m.credit)+'"')))
        blocks=re.findall(r'<div class="diff-card">\n(.*?)\n</div>',body,re.S)
        assert len(blocks)==len(expected)
        for match,block in zip(expected,blocks):
            info=Info();info.feed(block);target=f'{match.report}.html#{c.card_id(match.credit)}'
            assert info.links[:2]==[match.report+'.html',target]
            assert info.links[2:]==[url for kind,label,url in match.credit.evidence]
            actual=re.search(r'(?m)^<div class="change-display">.*$',block).group()
            original=cards((FOLDER/(match.report+'.html')).read_text())[c.card_id(match.credit)]
            assert actual==re.search(r'(?m)^<div class="change-display">.*$',original).group()
            seen+=1
    assert seen==62

from pathlib import Path
from datetime import datetime,timezone
import json,os,subprocess,time
R=Path('/workspace/scratch/hourly-20261119-port');C=R/'basics-source';E=R/'public-artifacts';PY='/workspace/MAM-basics/.venv/bin/python'
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUNBUFFERED='1');assert not env.get('PYTHONPATH')
assert not(E/'commands.json').exists()
jobs=[('diff-check',['git','diff','--check','5ed853e2670bac7a7158553848cb66fad375fb53','45c6f6a85cb5f144447f678781b75eb2b4b331a8']),('black',[PY,'-m','black','--check','py/mb_diff_mpu/mpplus_contributors.py','py/mb_diff_mpu/mpplus_credits.py','py/mb_diff_mpu/mpplus_html.py','py/mb_diff_mpu/mpplus_index.py','py/subcommands/diff_mpplus.py','py/tests/test_diff_mpplus_unpinned_latest.py']),('mpplus-all',[PY,'py/main_diff.py','mpplus','--all']),('mpplus-check',[PY,'py/main_diff.py','mpplus','--check']),('focused-tests',[PY,'py/main_test.py','py/tests/test_diff_mpplus_unpinned_latest.py','py/tests/test_mpplus_extract.py','py/tests/test_mpplus_historical_archives.py','py/tests/test_mpplus_alternative_oracle.py','py/tests/test_shared_html_styles.py','-q','-ra']),('change-log-html',[PY,'py/check_html_syntax_and_sanity.py','gh-pages/MAM-with-doc/change-log'])]
rows=[]
for label,argv in jobs:
 assert not subprocess.check_output(['git','status','--porcelain=v1','-z'],cwd=C)
 t=time.perf_counter();start=datetime.now(timezone.utc).isoformat()
 with(E/(label+'.log')).open('xb')as f:p=subprocess.run(argv,cwd=C,env=env,stdout=f,stderr=subprocess.STDOUT)
 status=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all','-z'],cwd=C);diff=subprocess.check_output(['git','diff','HEAD','--binary'],cwd=C)
 (E/(label+'-status.z')).write_bytes(status);(E/(label+'-diff.patch')).write_bytes(diff)
 row=dict(stage=label,argv=argv,cwd=str(C),started_utc=start,finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=round(time.perf_counter()-t,6),exit=p.returncode,status_clean=not status,diff_empty=not diff)
 rows.append(row);(E/'commands.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print(json.dumps(row),flush=True)
 if p.returncode or status:
  print((E/(label+'.log')).read_text(encoding='utf-8')[-3000:]);raise SystemExit('Unexpected result preserved')

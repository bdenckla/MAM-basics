from pathlib import Path
from datetime import datetime,timezone
import json,os,subprocess,time
R=Path('/workspace/scratch/hourly-20261119-port');C=R/'basics-source';E=R/'public-artifacts';argv=['/workspace/MAM-basics/.venv/bin/python','py/main_test.py',str(E/'test_port_review.py')+'::test_contributor_associations_and_order','-q','-ra']
assert not(E/'association-command.json').exists();t=time.perf_counter();start=datetime.now(timezone.utc).isoformat()
with(E/'association.log').open('xb')as f:p=subprocess.run(argv,cwd=C,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=f,stderr=subprocess.STDOUT)
row=dict(stage='association-order-probe',argv=argv,cwd=str(C),started_utc=start,finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=round(time.perf_counter()-t,6),exit=p.returncode)
(E/'association-command.json').write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8');print(json.dumps(row));print((E/'association.log').read_text(encoding='utf-8')[-2000:]);assert p.returncode==0

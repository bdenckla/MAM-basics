"""Offline byte/metadata audit of the frozen Introduction mirror refresh."""
from collections import Counter
from datetime import datetime, timezone
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

BASE = '6d3426fda4176a9a69f948761490988d8ba43e25'
TIP = '6449404315f45a2185c45ea0e69c83f10297a9b9'
ROOT = Path('/workspace/MAM-basics')
OUT = Path(__file__).parent
PREFIX = 'in/mam-ws-intro/'
started = time.perf_counter()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def blob(commit, path):
    return git('show', commit + ':' + path)

assert git('rev-parse', 'HEAD').decode().strip() == TIP
assert not git('status', '--porcelain', '-z')
paths = git('diff', '--name-only', '-z', BASE, TIP).decode().rstrip('\0').split('\0')
assert set(paths) == {PREFIX + name for name in ('appendices.mediawiki', 'index-aleppo.mediawiki', 'index-leningrad.mediawiki', 'manifest.json')}
assert git('rev-list', BASE + '..' + TIP).decode().splitlines() == [TIP]
old_manifest = json.loads(blob(BASE, PREFIX + 'manifest.json'))
manifest = json.loads(blob(TIP, PREFIX + 'manifest.json'))
assert set(manifest) == set(old_manifest) == {'provenance', 'pages'}
assert manifest['provenance'] == old_manifest['provenance']
assert set(manifest['pages']) == set(old_manifest['pages']) and len(manifest['pages']) == 13
expected = {'appendices': (3101789, 221398), 'index-aleppo': (3101811, 107092), 'index-leningrad': (3101815, 304083)}
facts = []
for slug, meta in manifest['pages'].items():
    old_meta = old_manifest['pages'][slug]
    before, after = [blob(c, PREFIX + slug + '.mediawiki') for c in (BASE, TIP)]
    assert meta['size'] == len(after) and old_meta['size'] == len(before)
    assert meta['title'] == old_meta['title']
    changed = before != after
    assert changed == (slug in expected)
    if changed:
        assert set(meta) == set(old_meta) == {'title', 'revid', 'timestamp', 'size'}
        assert (meta['revid'], meta['size']) == expected[slug]
        assert meta['revid'] > old_meta['revid']
        assert datetime.fromisoformat(meta['timestamp'].replace('Z', '+00:00')) > datetime.fromisoformat(old_meta['timestamp'].replace('Z', '+00:00'))
    else:
        assert meta == old_meta
    facts.append({'slug': slug, 'changed': changed, 'before_bytes': len(before), 'after_bytes': len(after), 'revid': meta['revid'], 'sha256': hashlib.sha256(after).hexdigest()})

before, after = [blob(c, PREFIX + 'index-leningrad.mediawiki') for c in (BASE, TIP)]
marker = '==ספר בראשית==\n'.encode()
assert before.count(marker) == after.count(marker) == 1
old_head, old_body = before.split(marker)
new_head, new_body = after.split(marker)
assert old_body == new_body
row_key = b'[[:COMMONS:File:Leningrad Codex Folio '
old_rows = [line for line in before.splitlines(keepends=True) if row_key in line]
new_rows = [line for line in after.splitlines(keepends=True) if row_key in line]
assert old_rows == new_rows and len(new_rows) == 999
page_names = [re.search(rb'Leningrad Codex Folio ([0-9]{3}[ab])\.jpg', row).group(1) for row in new_rows]
assert len(set(page_names)) == 982 and Counter(Counter(page_names).values()) == {1: 965, 2: 17}
assert all(row.count(row_key) == 1 and b'https://archive.org/details/Leningrad_Codex_Color_Images/page/' in row and b'https://manuscripts.sefaria.org/leningrad-color/BIB_LENCDX_' in row for row in new_rows)
assert b'#' == new_head.splitlines()[16][:1]
old_aleppo, new_aleppo = [blob(c, PREFIX + 'index-aleppo.mediawiki') for c in (BASE, TIP)]
addition = 'ראו עוד: '.encode()
assert new_aleppo.count(addition) == old_aleppo.count(addition) + 1
line2 = new_aleppo.splitlines(keepends=True)[1]
assert addition in line2
assert new_aleppo.replace(line2, line2.replace(addition, b'', 1), 1) == old_aleppo

appendices = [blob(c, PREFIX + 'appendices.mediawiki').decode().splitlines(keepends=True) for c in (BASE, TIP)]
assert len(appendices[0]) == len(appendices[1])
deltas = []
for line, (old, new) in enumerate(zip(*appendices), 1):
    if old == new:
        continue
    changes = []
    for kind, a, b, c, d in difflib.SequenceMatcher(a=old, b=new, autojunk=False).get_opcodes():
        if kind != 'equal':
            changes.append({'old': old[a:b], 'new': new[c:d]})
    deltas.append({'line': line, 'changes': changes})
assert len(deltas) == 3
psalms_link = r'\[\[(?:[^\]\n]*תהלים[^\]\n]*)\]\]'
assert re.findall(psalms_link, ''.join(appendices[0])) == re.findall(psalms_link, ''.join(appendices[1]))
git('diff', '--check', BASE, TIP)
result = {
    'recorded_utc': datetime.now(timezone.utc).isoformat(),
    'source_base': BASE, 'source_tip': TIP,
    'result': 'All offline assertions passed; no repository test suite or generator invoked.',
    'elapsed_seconds': round(time.perf_counter() - started, 3),
    'changed_paths': paths,
    'manifest_pages': facts,
    'leningrad': {'unchanged_index_rows': 999, 'distinct_page_names': 982, 'unchanged_suffix_from_genesis_bytes': len(marker + old_body), 'old_preamble_bytes': len(old_head), 'new_preamble_bytes': len(new_head), 'body_sha256': hashlib.sha256(marker + old_body).hexdigest()},
    'aleppo': 'Only the see-also phrase is inserted in the header; all other bytes preserved.',
    'appendices_deltas': deltas,
    'limits': 'Stored metadata consistency only; no live API/scan authenticity or new manuscript interpretation verified. No mark-order normalization or lint was applied to the verbatim mirror.'
}
(OUT / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'manifest_pages'}, ensure_ascii=False, indent=2))
print('Changed page sizes:', [(x['slug'], x['before_bytes'], x['after_bytes']) for x in facts if x['changed']])

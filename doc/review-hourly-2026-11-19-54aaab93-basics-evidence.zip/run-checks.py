import json,os,subprocess,time
from pathlib import Path
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1];S=R/'source';E=R/'evidence';P='/workspace/MAM-basics/.venv/bin/python';B='63ee193d6ce4c23217c76be81c00df0aad8ddf43';H='54aaab9300e1559c891275a547dd516a84207354'
changed=[x.decode() for x in subprocess.check_output(['git','diff','--name-only','-z',B,H,'--','*.py'],cwd=S).split(b'\0') if x]
steps=[('diff-check',['git','diff','--check',B,H]),('black',[P,'-m','black','--check',*changed]),('near-html',[P,'py/main_near_aleppo.py','--html']),('foi',[P,'py/main_foi_features_of_interest.py','--foi','args-foi-dexi-stress-meteg']),('telg',[P,'py/main_accgram.py','generate-html-telg-doc-notes']),('ps17',[P,'py/main_accgram.py','generate-html-ps17v14-mam-doc-notes']),('intro-review',[P,'py/main_intro_doc_audit.py','review']),('gen-site',[P,'py/main_authored.py','gen-site','--trust-surveys']),('koren',[P,'py/main_accgram.py','generate-html-printed-decalogue-koren']),('maqaf',[P,'py/main_accgram.py','generate-html-maqaf-nonfinal-accents']),('focused-tests',[P,'py/main_test.py',*[f'py/tests/test_{n}.py' for n in ['prose_conventions','prose_mark_order','h_dot_below_nfc','transliterations','shared_html_styles','site_links_relative','site_index_links','near_aleppo','near_aleppo_note_content','printed_decalogue_koren','printed_decalogue_page','maqaf_nonfinal_accents_page']],'-q','-ra'])]
records=[]
for name,cmd in steps:
 start=datetime.now(timezone.utc).isoformat();t=time.monotonic()
 with (E/(name+'.txt')).open('wb') as f:out=subprocess.run(cmd,cwd=S,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=f,stderr=subprocess.STDOUT)
 wall=time.monotonic()-t;status=subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=S);diff=subprocess.check_output(['git','diff','--binary'],cwd=S)
 (E/(name+'-post-status.bin')).write_bytes(status);(E/(name+'-post.diff')).write_bytes(diff)
 row=dict(name=name,command=cmd,cwd=str(S),start_utc=start,exit=out.returncode,wall_seconds=round(wall,6),status_bytes=len(status),diff_bytes=len(diff));records.append(row);(E/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
 if out.returncode or status or diff:raise SystemExit(1)

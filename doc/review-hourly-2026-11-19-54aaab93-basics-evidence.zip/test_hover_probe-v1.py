import copy,json,re,subprocess
from html import escape
from pathlib import Path
import pytest
from lxml import html
from mb_misc import printed_tradition as pt,mb_html
from accgram import telg_doc_notes as telg,printed_decalogue_koren_page as koren,maqaf_nonfinal_accents_page as maqaf

ROOT=Path.cwd();BASE='63ee193d6ce4c23217c76be81c00df0aad8ddf43';HEAD='54aaab9300e1559c891275a547dd516a84207354'
SAMPLES=['the printed tradition','The printed tradition','part of the printed tradition and Koren','most of the printed\ntradition','<script>"& the printed tradition <x>','אִ the printed tradition אב','nothe printed tradition the printed traditions','plain & < > "']
def norm(s):return re.sub(r'\s+',' ',s).strip()
def spans(d):return d.xpath('.//span[@class="explained"]')
@pytest.mark.parametrize('text',SAMPLES)
def test_both_rendering_routes_preserve_text_and_escape(text):
 string=pt.explain_html(text);tree=mb_html.el_to_str_for_sef(mb_html.span(pt.explain(text)))
 a=html.fromstring('<div>'+string+'</div>');b=html.fromstring(tree)
 assert a.text_content()==text and norm(b.text_content())==norm(text)
 assert re.findall(r'[\u0590-\u05ff]+',a.text_content())==re.findall(r'[\u0590-\u05ff]+',text)
 assert [(e.text,e.get('title')) for e in spans(a)]==[(e.text,e.get('title')) for e in spans(b)]
 assert all(set(e.attrib)=={'class','title'} and e.get('title')==pt.HOVER for e in spans(a))
 assert not a.xpath('.//script|.//x')
 assert pt.explain_html(text)==string
 first=telg._explained(text);assert telg._explained(first)==first

def test_plain_renderer_and_quoted_markup_contract():
 d=html.fromstring('<div>'+pt.explain_html('left the printed tradition right',plain=lambda s:'<i>'+escape(s)+'</i>')+'</div>')
 assert len(d.xpath('./i'))==2 and len(spans(d))==1 and d.text_content()=='left the printed tradition right'
 # This function takes plain text, not a previously serialized HTML fragment.
 prior=pt.explain_html('the printed tradition');again=html.fromstring('<div>'+pt.explain_html(prior)+'</div>')
 assert again.text_content()==prior and not again.xpath('.//script|.//img')

def test_old_stress_hover_and_page_bytes_preserved():
 old=subprocess.check_output(['git','show',BASE+':py/author_site/stress_helper_comparison.py'])
 import ast
 n=next(n for n in ast.parse(old).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='_PRINTED_TRADITION' for t in n.targets))
 assert ast.literal_eval(n.value)==pt.HOVER
 assert subprocess.check_output(['git','show',BASE+':gh-pages/stress-helpers/index.html'])==(ROOT/'gh-pages/stress-helpers/index.html').read_bytes()

def test_all_current_hovers_single_and_styled():
 names=[x.decode() for x in subprocess.check_output(['git','ls-files','-z','gh-pages/*.html','gh-pages/**/*.html']).split(b'\0') if x]
 used=[]
 def sheet(path,seen=None):
  seen=set() if seen is None else seen
  if path in seen:return ''
  seen.add(path);s=path.read_text()
  for name in re.findall(r'@import\s+(?:url\()?\s*[\"\x27]([^\"\x27]+)',s):s+='\n'+sheet((path.parent/name).resolve(),seen)
  return s
 for name in names:
  raw=(ROOT/name).read_bytes()
  if b'class="explained"' not in raw:continue
  d=html.document_fromstring(raw);ss=d.xpath('//span[@class="explained"]');used.append(name)
  assert all(x.get('title')==pt.HOVER and not x.xpath('.//span[@class="explained"]') for x in ss)
  css='\n'.join(d.xpath('//style/text()'))
  for href in d.xpath('//link[@rel="stylesheet"]/@href'):
   if '://' not in href:css+='\n'+sheet(((ROOT/name).parent/href).resolve())
  assert pt.STYLE in css
 assert len(used)==9

def test_exact_pin_scope_on_synthetic_survey(monkeypatch,tmp_path):
 path=ROOT/'out/accgram/maqaf-nonfinal-accents.json';survey=json.loads(path.read_bytes());baseline=koren._munax_munax_precedent();maqaf.pin_claims(survey)
 fixture=copy.deepcopy(survey);record=fixture['corpora']['mam_simple']['poetic']['occurrences'][0];record['shape']='mun-mun'
 fake=tmp_path/'survey.json';fake.write_text(json.dumps(fixture,ensure_ascii=False));monkeypatch.setattr(koren.mpa,'default_json_out_path',lambda:fake)
 assert koren._munax_munax_precedent()==baseline
 with pytest.raises(AssertionError) as e:maqaf.pin_claims(fixture)
 assert e.value.args==(record,)
 fixture=copy.deepcopy(survey);fixture['corpora']['mam_simple']['prose']['occurrences'][0]['shape']='mun-mun';fake.write_text(json.dumps(fixture,ensure_ascii=False))
 with pytest.raises(AssertionError):koren._munax_munax_precedent()

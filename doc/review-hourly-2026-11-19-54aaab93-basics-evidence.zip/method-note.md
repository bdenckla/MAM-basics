# Original reviewer diagnostics and limits

A read-only diff-stat lookup preceded completion of the initial fetch and returned exit128,
"fatal: bad object 54aaab9300e1559c891275a547dd516a84207354" (tool-returned diagnostic).
After waiting for that same successful fetch, the complete32-path inventory was read. No
product command ran against missing or substituted inputs.

Hover probe v1 used mb_html's single-line Sefaria serializer for a multiline fixture:11
passed/1 failed. V2 used the general serializer but compared its inserted English wrapping
newlines literally:6 passed/6 failed. Both original helpers, summaries and full pytest
diagnostics remain. The final probe uses the general serializer, normalizes only displayed
whitespace for comparison, and retains exact title/Hebrew checks:12 passed. No product changed.

The later term-coverage assertion initially included the Koren comparison page's title and
heading, which say "the printed tradition" in the author's voice rather than translating a
note's sigil. Originals/diagnostics are retained. Restricting the check to the actual hover
sweep leaves50 occurrences:49 wrapped and the one explicit sigil definition unwrapped.
The two comparison pages remain covered for markup, tables, pointed text and scripts.
The string-HTML helper takes plain text; it is deterministic but is not an HTML postprocessor.
The concrete element-tree caller is idempotent on its already expanded contents. These are
explicit contracts, not a claim of generic repeated HTML-string idempotence.

Owner title/source/scan and approval reports remain attributed. No live source research,
browser/native proof, font work or retired/frozen research was performed. Historical HTML
orphan findings remain open; their checker was not repeated for unchanged image/link markup.

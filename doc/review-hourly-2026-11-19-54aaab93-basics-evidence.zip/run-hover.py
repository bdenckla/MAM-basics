import json,os,subprocess,time
from pathlib import Path
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1];S=R/'source';E=R/'evidence';cmd=['/workspace/MAM-basics/.venv/bin/python','py/main_test.py',str(E/'test_hover_probe.py'),'-q','-ra'];start=datetime.now(timezone.utc).isoformat();t=time.monotonic()
with (E/'hover-tests.txt').open('wb') as f:run=subprocess.run(cmd,cwd=S,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=f,stderr=subprocess.STDOUT)
wall=time.monotonic()-t;status=subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=S);diff=subprocess.check_output(['git','diff','--binary'],cwd=S);(E/'hover-post-status.bin').write_bytes(status);(E/'hover-post.diff').write_bytes(diff)
row=dict(command=cmd,cwd=str(S),start_utc=start,exit=run.returncode,wall_seconds=round(wall,6),status_bytes=len(status),diff_bytes=len(diff));(E/'hover-command.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row));assert run.returncode==0 and not status and not diff

import copy,json,re,subprocess,time
from pathlib import Path
from lxml import html
R=Path(__file__).resolve().parents[1]/'source';E=R.parent/'evidence';B='63ee193d6ce4c23217c76be81c00df0aad8ddf43';H='54aaab9300e1559c891275a547dd516a84207354';start=time.monotonic();checks=[]
def g(rev,path):return subprocess.check_output(['git','show',rev+':'+path],cwd=R)
def ok(n,v=True):
 assert v,n
 checks.append(n)
paths=[x.decode() for x in subprocess.check_output(['git','diff','--name-only','-z',B,H],cwd=R).split(b'\0') if x]
documents=[];hovers=0
for path in [x for x in paths if x.endswith('.html')]:
 a=html.document_fromstring(g(B,path));b=html.document_fromstring(g(H,path));ss=b.xpath('//span[@class="explained"]');hovers+=len(ss)
 for e in ss:e.drop_tag()
 aa=[x for x in a.iter() if x.tag!='style'];bb=[x for x in b.iter() if x.tag!='style']
 ok('only hover markup added '+path,[(x.tag,dict(x.attrib)) for x in aa]==[(x.tag,dict(x.attrib)) for x in bb])
 ok('pointed display contents exact '+path,a.xpath('//*[@lang="hbo"]/text()')==b.xpath('//*[@lang="hbo"]/text()'))
 ok('all tables Hebrew text exact '+path,re.findall(r'[\u0590-\u05ff]+',''.join(x.text_content() for x in a.xpath('//table')))==re.findall(r'[\u0590-\u05ff]+',''.join(x.text_content() for x in b.xpath('//table'))))
 ok('script contents exact '+path,a.xpath('//script/text()')==b.xpath('//script/text()'))
 documents.append(path)
changes=[]
def compare(a,b,loc=()):
 assert type(a) is type(b),loc
 if isinstance(a,dict):
  assert a.keys()==b.keys(),loc
  for k in a:compare(a[k],b[k],loc+(k,))
 elif isinstance(a,list):
  assert len(a)==len(b),loc
  for i,(x,y) in enumerate(zip(a,b)):compare(x,y,loc+(i,))
 elif a!=b:
  assert isinstance(a,str) and loc[-1]=='translation',loc
  ok('translated Hebrew exact '+str(loc),re.findall(r'[\u0590-\u05ff]+',a)==re.findall(r'[\u0590-\u05ff]+',b));changes.append(dict(location=loc,before=a,after=b))
p='doc/intro-doc-audit/human-review.json';compare(json.loads(g(B,p)),json.loads(g(H,p)))
ok('only ten Introduction translations changed',len(changes)==10)
for prefix in ['MAM-parsed','MAM-simple','in/mam-ws','in/mam-ws-intro','in/stress-helpers','out/accgram/maqaf-nonfinal-accents.json']:
 ok('source/data input unchanged '+prefix,subprocess.check_output(['git','diff','--name-only','-z',B,H,'--',prefix],cwd=R)==b'')
ok('historical Introduction source pin unchanged',g(B,'doc/intro-doc-audit/source-pin.json')==g(H,'doc/intro-doc-audit/source-pin.json'))
unwrapped=[];visible_terms=0
for path in documents+['gh-pages/stress-helpers/index.html']:
 d=html.document_fromstring((R/path).read_bytes())
 for node in d.xpath('//text()[not(ancestor::script) and not(ancestor::style)]'):
  matches=re.findall(r'(?<!\w)[Tt]he\s+printed\s+tradition(?!\w)',str(node))
  if not matches:continue
  visible_terms+=len(matches);parent=node.getparent();parent=parent.getparent() if node.is_tail else parent
  ancestors=[parent,*parent.iterancestors()]
  if not any('explained' in (x.get('class') or '').split() for x in ancestors):unwrapped.extend(dict(path=path,parent=parent.tag,text=str(node)) for _ in matches)
ok('only explicit sigil definition remains without hover',len(unwrapped)==1 and unwrapped[0]['path']=='gh-pages/wlc/accgram/telg-doc-notes.html' and 'the customary text' in unwrapped[0]['text'])
result=dict(base=B,source=H,checks_passed=len(checks),HTML_documents=len(documents),explained_spans_in_changed_HTML=hovers,visible_term_occurrences=visible_terms,unwrapped_definition=unwrapped,changed_Introduction_translations=len(changes),documents=documents,changes=changes,checks=checks,original_source_or_visual_verification=False,wall_seconds=round(time.monotonic()-start,6));(E/'preservation-summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('checks','changes','documents','unwrapped_definition')},indent=2))

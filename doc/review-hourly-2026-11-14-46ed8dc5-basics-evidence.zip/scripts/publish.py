"""Publish one prepared isolated receipt normally, verify remote scope and bytes."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

kind = "basics"
task = Path("/workspace/scratch/basics-46ed8dc5")
record = json.loads((task / "publication-prepared.json").read_bytes())
home = Path("/workspace/MAM-" + kind)
tree = task / "receipts"
branch = record["branch"]
parent = record["parent"]


def git(*args):
    return subprocess.check_output(["git", "-C", str(tree), *args])


def dump(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()


assert git("rev-parse", "HEAD").decode().strip() == parent
assert git("branch", "--show-current").decode().strip() == branch
assert (
    git("ls-remote", "origin", "refs/heads/" + branch).decode()
    == parent + "\trefs/heads/" + branch + "\n"
)
link_updates = []
changed = set(
    filter(None, git("diff", "--name-only", "-z").decode().split("\0"))
) | set(
    filter(
        None,
        git("ls-files", "--others", "--exclude-standard", "-z").decode().split("\0"),
    )
)
assert changed == set(record["paths"])
assert all(p.startswith("doc/review-") for p in changed)
git("diff", "--check")
for ref in (parent, record["source"]):
    workflows = [
        p
        for p in git("ls-tree", "-r", "--name-only", "-z", ref, "--", ".github")
        .decode()
        .split("\0")
        if p
    ]
    if kind == "private":
        assert not workflows
    else:
        assert workflows == [".github/workflows/pages.yml"]
        assert (
            git("rev-parse", ref + ":.github/workflows/pages.yml").decode().strip()
            == "18ceb19405424710bda47d9a38c470cc2ed9c385"
        )
        assert b"on:\n  workflow_dispatch:\n" in git(
            "show", ref + ":.github/workflows/pages.yml"
        )
git("add", "--", *record["paths"])
assert set(
    filter(None, git("diff", "--cached", "--name-only", "-z").decode().split("\0"))
) == set(record["paths"])
git("commit", "-m", "Record bounded November 14 01:00 UTC cycle screen")
commit = git("rev-parse", "HEAD").decode().strip()
assert git("rev-parse", "HEAD^").decode().strip() == parent
assert set(
    filter(
        None,
        git("diff-tree", "--no-commit-id", "--name-only", "-r", "-z", parent, commit)
        .decode()
        .split("\0"),
    )
) == set(record["paths"])
assert not git("status", "--porcelain=v1", "-z")
record.update(
    commit=commit,
    historical_link_repairs=link_updates,
    committed_utc=datetime.now(timezone.utc).isoformat(),
    push_state="not attempted",
)
destination = task / "publication.json"
assert not destination.exists()
destination.write_bytes(dump(record))
# An unexpected existing tip is a conflict: stop rather than overwrite or force-push.
assert (
    git("ls-remote", "origin", "refs/heads/" + branch).decode()
    == parent + "\trefs/heads/" + branch + "\n"
)
result = subprocess.run(
    ["git", "-C", str(tree), "push", "origin", "HEAD:refs/heads/" + branch],
    capture_output=True,
)
(task / (kind + "-push.stdout")).write_bytes(result.stdout)
(task / (kind + "-push.stderr")).write_bytes(result.stderr)
remote = git("ls-remote", "origin", "refs/heads/" + branch).decode()
record.update(
    push_exit=result.returncode,
    remote_ref=remote.strip(),
    observed_utc=datetime.now(timezone.utc).isoformat(),
)
destination.write_bytes(dump(record))
assert (
    remote == commit + "\trefs/heads/" + branch + "\n"
), "Push not confirmed: inspect outcome before any retry"
git("fetch", "--no-tags", "origin", "refs/heads/" + branch)
assert git("rev-parse", "FETCH_HEAD").decode().strip() == commit
assert git("rev-parse", "FETCH_HEAD^").decode().strip() == parent
assert set(
    filter(
        None,
        git(
            "diff-tree",
            "--no-commit-id",
            "--name-only",
            "-r",
            "-z",
            parent,
            "FETCH_HEAD",
        )
        .decode()
        .split("\0"),
    )
) == set(record["paths"])
archive_name = "doc/" + record["archive"]["path"]
raw = git("show", "FETCH_HEAD:" + archive_name)
assert len(raw) == record["archive"]["bytes"]
assert hashlib.sha256(raw).hexdigest() == record["archive"]["sha256"]
with zipfile.ZipFile(tree / archive_name) as z:
    assert z.testzip() is None
    manifest = json.loads(z.read("manifest.json"))
    assert len(z.namelist()) == len(set(z.namelist()))
    assert set(z.namelist()) == set(manifest) | {"manifest.json"}
    for name, item in manifest.items():
        data = z.read(name)
        assert (
            len(data) == item["bytes"]
            and hashlib.sha256(data).hexdigest() == item["sha256"]
        )
    for name in z.namelist():
        if name.endswith(".zip"):
            import io

            with zipfile.ZipFile(io.BytesIO(z.read(name))) as inner:
                assert inner.testzip() is None
                if "manifest.json" in inner.namelist():
                    for item_name, item in json.loads(
                        inner.read("manifest.json")
                    ).items():
                        data = inner.read(item_name)
                        assert (
                            len(data) == item["bytes"]
                            and hashlib.sha256(data).hexdigest() == item["sha256"]
                        )
record.update(
    push_state="verified",
    verified_payloads=len(manifest),
    verified_paths=record["paths"],
)
destination.write_bytes(dump(record))
print(json.dumps(record, indent=2))

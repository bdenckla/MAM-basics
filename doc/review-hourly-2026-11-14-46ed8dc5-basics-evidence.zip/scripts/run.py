"""Run bounded checks sequentially, retaining commands, logs and generated changes."""

from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "head"
OUT = ROOT / "evidence"
PYTHON = "/workspace/MAM-basics/.venv/bin/python"
SOURCE = "46ed8dc5ac41fe556b131b7911726c215ab64140"
STAGES = [
    ("gen-site", [PYTHON, "-B", "py/main_authored.py", "gen-site", "--trust-surveys"]),
    (
        "html",
        [PYTHON, "-B", "py/check_html_syntax_and_sanity.py", "gh-pages/stress-helpers"],
    ),
    ("probes", [PYTHON, "-B", str(ROOT / "probe.py")]),
]
if len(sys.argv) > 1:
    STAGES = [(sys.argv[1], sys.argv[2:])]


def git(*args):
    return subprocess.check_output(["git", "-C", str(TREE), *args])


assert git("rev-parse", "HEAD").decode().strip() == SOURCE
assert not git("status", "--porcelain=v1", "-z")
assert git("rev-parse", "--show-toplevel").decode().strip() == str(TREE)
assert not git("branch", "--show-current").strip()
for name, cmd in STAGES:
    log = OUT / (name + ".log")
    assert not log.exists()
    start = time.monotonic()
    stamp = datetime.now(timezone.utc).isoformat()
    print("Starting " + name, flush=True)
    with log.open("wb") as stream:
        result = subprocess.run(cmd, cwd=TREE, stdout=stream, stderr=subprocess.STDOUT)
    record = {
        "stage": name,
        "started_utc": stamp,
        "finished_utc": datetime.now(timezone.utc).isoformat(),
        "seconds": round(time.monotonic() - start, 6),
        "command": cmd,
        "cwd": str(TREE),
        "exit": result.returncode,
    }
    (OUT / (name + ".json")).write_text(
        json.dumps(record, indent=2) + "\n", encoding="utf-8", newline="\n"
    )
    (OUT / (name + ".diff")).write_bytes(git("diff", "--binary"))
    (OUT / (name + ".status")).write_bytes(git("status", "--porcelain=v1", "-z"))
    print(json.dumps(record), flush=True)
    assert git("rev-parse", "HEAD").decode().strip() == SOURCE
    assert not git(
        "status", "--porcelain=v1", "-z"
    ), "Inspect retained output before continuing"

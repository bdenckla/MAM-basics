"""Independent named-field source/DOM oracle and bounded mechanical probes."""

from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from urllib.parse import unquote, urlsplit

from lxml import html
from PIL import Image

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "head"
OUT = ROOT / "evidence"
BASE = "9b5086dc6f8543dba99f855851f9ccc9f625e9b3"
SOURCE = "46ed8dc5ac41fe556b131b7911726c215ab64140"
PARENT = "fc4afef02881b131e183d3fbb698ae740b85cd6d"
sys.path.insert(0, str(TREE / "py"))  # Disposable scratch harness only.
from author_site import stress_helper_comparison as renderer
from mb_cmn import uni_denorm

FIELDS = (
    "book",
    "chapter",
    "verse",
    "strand",
    "instance",
    "location",
    "mam",
    "printed",
    "verse_href",
    "category",
)


def git(*args):
    return subprocess.check_output(["git", "-C", str(TREE), *args])


def save(name, value):
    (OUT / name).write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def text(node):
    return " ".join(node.text_content().split())


def ident(record):
    return tuple(record.get(k) for k in FIELDS)


def crops(sources):
    return [
        (edition, p)
        for edition in ("koren", "simanim-tanakh")
        for p in sources.get(edition, {}).get("crops", [])
        + [
            p
            for r in sources.values()
            for p in r.get("comparison_crops", {}).get(edition, [])
        ]
    ]


def check_crops(row, sources):
    record = next(iter(sources.values()))
    expected = crops(sources)
    anchors = row.xpath('./td[@class="scan"]/a')
    assert len(anchors) == len(expected)
    ref = text(row.xpath("./th/a")[0])
    if record.get("location"):
        ref += ", " + record["location"].lower()
    for anchor, (edition, path) in zip(anchors, expected):
        full, short = (
            ("Koren", "Koren")
            if edition == "koren"
            else ("the Simanim Tanakh", "SimTan")
        )
        assert anchor.get("href") == path and anchor.xpath("./img/@src") == [path]
        assert anchor.xpath("./img/@alt") == [full + " scan crop for " + ref]
        assert anchor.xpath("./img/@loading") == ["lazy"] and anchor.xpath(
            "./img/@decoding"
        ) == ["async"]
        assert [text(n) for n in anchor.xpath('./span[@class="source"]')] == (
            [short] if len({e for e, _ in expected}) > 1 else []
        )


assert git("rev-parse", "HEAD").decode().strip() == SOURCE
assert not git("status", "--porcelain=v1", "-z")
changed = [
    p for p in git("diff", "--name-only", "-z", BASE, SOURCE).decode().split("\0") if p
]
assert len(changed) == 2
git("diff", "--check", BASE, SOURCE)
(OUT / "endpoint.diff").write_bytes(git("diff", BASE, SOURCE))
(OUT / "commits.txt").write_bytes(git("log", "--format=fuller", BASE + ".." + SOURCE))
identities = {}
for p in changed:
    identities[p] = {}
    for ref in (BASE, SOURCE):
        result = subprocess.run(
            ["git", "-C", str(TREE), "show", ref + ":" + p], capture_output=True
        )
        identities[p][ref] = {
            "exists": result.returncode == 0,
            "bytes": len(result.stdout),
            "sha256": (
                hashlib.sha256(result.stdout).hexdigest()
                if result.returncode == 0
                else None
            ),
        }
save("identities.json", identities)

inputs, groups, deltas = {}, {}, []
for edition in ("koren", "simanim-tanakh"):
    p = "in/stress-helpers/" + edition + ".json"
    current = json.loads((TREE / p).read_bytes())
    old = json.loads(git("show", BASE + ":" + p))
    assert {k: v for k, v in current.items() if k != "differences"} == {
        k: v for k, v in old.items() if k != "differences"
    }
    old_records = {
        tuple(r.get(k) for k in FIELDS if k != "location"): r
        for r in old["differences"]
    }
    for record in current["differences"]:
        key = tuple(record.get(k) for k in FIELDS if k != "location")
        before = old_records.pop(key, None)
        if before != record:
            deltas.append({"edition": edition, "before": before, "after": record})
        if before is not None:
            allowed = (
                {"location", "notes", "comparison_crops"}
                if edition == "simanim-tanakh"
                and (record["book"], record["chapter"], record["verse"])
                in {("Jeremiah", 22, 23), ("Ruth", 2, 9)}
                else set()
            )
            assert {k: v for k, v in before.items() if k not in allowed} == {
                k: v for k, v in record.items() if k not in allowed
            }
        assert all(uni_denorm.has_std_mark_order(record[k]) for k in ("mam", "printed"))
        assert edition not in groups.setdefault(ident(record), {})
        groups[ident(record)][edition] = record
    assert not old_records
    inputs[edition] = current
assert len(deltas) == 2
assert all(d["before"] is not None for d in deltas)
save("data-deltas.json", deltas)

target = TREE / "gh-pages/stress-helpers/index.html"
new_raw = target.read_bytes()
doc = html.fromstring(new_raw)
rows = doc.xpath('//table[@id="observations"]/tbody/tr')
assert len(rows) == len(groups)
ids = doc.xpath("//*[@id]/@id")
assert len(ids) == len(set(ids))
remaining = dict(groups)
counts, memberships = Counter(), Counter()
row_evidence, js_rows, linked = [], [], set()
cache = {}


def page(path):
    path = path.resolve()
    if path not in cache:
        cache[path] = html.fromstring(path.read_bytes())
    return cache[path]


def qere(node):
    node = deepcopy(node)
    for ketiv in node.xpath('.//span[@class="mam-kq-k"]'):
        ketiv.drop_tree()
    return text(node).replace("[", "").replace("]", "")


for row in rows:
    forms = row.xpath('.//span[@class="hebrew"]/text()')
    href = row.xpath("./th/a/@href")
    small = [text(n) for n in row.xpath("./th/small")]
    candidates = []
    for key, sources in remaining.items():
        r = next(iter(sources.values()))
        labels = ([f"Instance {r['instance']}"] if r.get("instance") else []) + (
            [r["location"]] if r.get("location") else []
        )
        if (
            [r["mam"], r["printed"]] == forms
            and [r["verse_href"]] == href
            and labels == small
            and row.xpath("./th/bdi/text()")
            == ([r["strand"]] if r.get("strand") else [])
        ):
            candidates.append((key, sources))
    assert len(candidates) == 1
    key, sources = candidates[0]
    remaining.pop(key)
    r = next(iter(sources.values()))
    suffix = {
        frozenset(["koren"]): "Kor",
        frozenset(["simanim-tanakh"]): "Sim",
        frozenset(["koren", "simanim-tanakh"]): "KorSim",
    }[frozenset(sources)]
    expected_filter = r["category"] + "-" + suffix
    assert row.get("data-filter") == expected_filter
    counts[expected_filter] += 1
    memberships[len(sources)] += 1
    assert row.xpath('./th/span[@class="source"]/@title') == [
        s["scan"] for s in sources.values()
    ]
    assert [text(n) for n in row.xpath('.//span[@class="edition"]')] == [
        "MAM",
        " / ".join("Koren" if e == "koren" else "SimTan" for e in sources),
    ]
    check_crops(row, sources)
    linked.update(p for _, p in crops(sources))
    loc = urlsplit(r["verse_href"])
    anchors = page(target.parent / unquote(loc.path)).xpath(
        "//*[@id=$ident]", ident=loc.fragment
    )
    assert len(anchors) == 1 and " ".join(r["mam"].split()) in qere(
        anchors[0].getparent()
    )
    assert [text(n) for n in row.xpath('./td[@class="difference"]/p')] == list(
        dict.fromkeys(
            n["text"] + (" " + n.get("label", "MAM doc-note") if n.get("href") else "")
            for s in sources.values()
            for n in s.get("notes", [])
        )
    )
    row_evidence.append(
        {
            "identity": dict(zip(FIELDS, key)),
            "editions": list(sources),
            "filter": expected_filter,
            "crops": crops(sources),
        }
    )
    js_rows.append(
        {
            "filter": expected_filter,
            "category": r["category"],
            "editions": list(sources),
            "cells": [text(c) for c in row],
        }
    )
assert not remaining
options = doc.xpath('//*[@id="filter"]/option')
assert (
    options[0].get("value") == ""
    and text(options[0]) == f"All differences ({len(rows)})"
)
assert {o.get("value") for o in options[1:]} == set(counts)
assert all(text(o).endswith(f"({counts[o.get('value')]})") for o in options[1:])
old_doc = html.fromstring(git("show", BASE + ":gh-pages/stress-helpers/index.html"))
old_rows = old_doc.xpath('//table[@id="observations"]/tbody/tr')
serialized = {html.tostring(r) for r in rows}
unchanged_rows = sum(html.tostring(r) in serialized for r in old_rows)
assert unchanged_rows == len(old_rows) - 2
assert (
    git("show", BASE + ":gh-pages/stress-helpers/controls.js")
    == (target.parent / "controls.js").read_bytes()
)
local, external = 0, set()
for node in doc.xpath("//*[@href or @src]"):
    for attr in ("href", "src"):
        value = node.get(attr)
        if value is None:
            continue
        loc = urlsplit(value)
        if loc.scheme or loc.netloc:
            external.add(value)
            continue
        dest = (target.parent / unquote(loc.path)).resolve() if loc.path else target
        assert dest.is_relative_to(TREE / "gh-pages") and dest.is_file(), value
        if loc.fragment:
            assert page(dest).xpath(
                "//*[@id=$ident or @name=$ident]", ident=unquote(loc.fragment)
            ), value
        local += 1
pngs = {}
for p in sorted((target.parent / "img").glob("*.png")):
    with Image.open(p) as image:
        assert image.format == "PNG"
        pngs["img/" + p.name] = {
            "width": image.width,
            "height": image.height,
            "bytes": p.stat().st_size,
            "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
        }
        image.verify()
orphans = sorted(pngs.keys() - linked)
assert orphans == [
    "img/koren-deuter-5-13-A5-D-281-370-1.png",
    "img/koren-deuter-5-13-A5-D-281-370-2.png",
    "img/simanim-tanakh-deuter-5-6-A9-A5-10C-0351-1685-1.png",
    "img/simanim-tanakh-exodus-20-2-A9-A2-10C-0350-1684-1.png",
]


# Named input fields establish the bounded 13-case population; no whole-corpus census.
site_fields = (
    "book",
    "chapter",
    "verse",
    "strand",
    "instance",
    "location",
    "mam",
    "verse_href",
)


def site_key(record):
    return tuple(record.get(k) for k in site_fields)


koren = {site_key(r): r for r in inputs["koren"]["differences"]}
sim_redundant = [
    r
    for r in inputs["simanim-tanakh"]["differences"]
    if r["category"] == "redundant-edition"
]
pattern = []
shared_pashta = []
exceptions = []
for r in sim_redundant:
    k = koren.get(site_key(r))
    assert r["mam"].count("\N{HEBREW ACCENT PASHTA}") == 1
    assert r["printed"].count("\N{HEBREW ACCENT PASHTA}") == 2
    if k is not None and k["category"] == "redundant-edition":
        assert k["printed"] == r["printed"]
        assert k["printed"].count("\N{HEBREW ACCENT PASHTA}") == 2
        shared_pashta.append(site_key(r))
    else:
        exceptions.append(site_key(r))
    pattern.append(
        {"site": dict(zip(site_fields, site_key(r))), "simanim": r, "koren": k}
    )
assert len(sim_redundant) == 13 and len(shared_pashta) == 11 and len(exceptions) == 2
jer = next(
    r
    for r in sim_redundant
    if r["book"] == "Jeremiah"
    and r["chapter"] == 22
    and r["verse"] == 23
    and r.get("location") == "Opening qere"
)
jk = koren[site_key(jer)]
assert jk["category"] == "different-accent"
assert "\N{HEBREW ACCENT PASHTA}" not in jk["printed"]
assert jk["printed"].count("\N{HEBREW ACCENT MUNAH}") == 1
assert jer["comparison_crops"] == {"koren": jk["crops"]}
ruth = next(
    r
    for r in sim_redundant
    if r["book"] == "Ruth" and r["chapter"] == 2 and r["verse"] == 9
)
assert site_key(ruth) not in koren and ruth["location"] == "Second occurrence"
assert "MAM and Koren (p. 158) have a single pashta" in ruth["notes"][0]["text"]
assert "would likely consider" in ruth["notes"][0]["text"]
# Ruth's Koren single-pashta reading is the authored source-note, not a new difference record.
save(
    "eleven-case-pattern.json",
    {
        "population": "13 Simanim Tanakh redundant-edition input records; joined by named site/MAM fields",
        "shared_matching_pashta_helpers": len(shared_pashta),
        "exceptions": exceptions,
        "cases": pattern,
        "limit": "Structural input support only; no printed-source rereading, whole-MAM census, or proof of editor intent.",
    },
)
same = {}
for p in (
    "py/author_site/stress_helper_comparison.py",
    "gh-pages/stress-helpers/controls.js",
    "gh-pages/stress-helpers/style.css",
):
    raw = (TREE / p).read_bytes()
    assert raw == git("show", BASE + ":" + p)
    same[p] = {
        "git_blob": git("rev-parse", SOURCE + ":" + p).decode().strip(),
        "sha256": hashlib.sha256(raw).hexdigest(),
    }
save("unchanged-executable-style-blobs.json", same)
raw_old = git("show", BASE + ":gh-pages/stress-helpers/index.html")
old_lines = {
    line for line in raw_old.splitlines() if line.startswith(b"<tr data-filter=")
}
new_lines = {
    line for line in new_raw.splitlines() if line.startswith(b"<tr data-filter=")
}
assert len(old_lines & new_lines) == len(rows) - 2
assert len(rows) == 37 and memberships == {1: 23, 2: 14}
assert len(inputs["koren"]["differences"]) == 34
assert len(inputs["simanim-tanakh"]["differences"]) == 17
assert len(options) - 1 == 9 and len(pngs) == 56 and len(linked) == 52
crop = jer["comparison_crops"]["koren"][0]
assert new_raw.count(('src="' + crop + '"').encode()) == 2
assert raw_old.count(('src="' + crop + '"').encode()) == 1
assert not any(
    r["book"] == "2Samuel" and r["chapter"] == 13 and r["verse"] == 20
    for data in inputs.values()
    for r in data["differences"]
)
save("png-identities.json", pngs)
save("rows.json", row_evidence)
save(
    "probe-result.json",
    {
        "observed_utc": datetime.now(timezone.utc).isoformat(),
        "source": SOURCE,
        "base": BASE,
        "records": {e: len(d["differences"]) for e, d in inputs.items()},
        "rows": len(rows),
        "memberships": dict(memberships),
        "menu_choices": len(options) - 1,
        "unchanged_prior_rows": len(old_lines & new_lines),
        "local_attributes": local,
        "png_files": len(pngs),
        "unique_linked_pngs": len(linked),
        "image_occurrences": len(doc.xpath("//img")),
        "orphan_pngs": orphans,
        "restored_crop": crop,
        "restored_crop_occurrences": 2,
        "structural_pattern_shared": len(shared_pashta),
        "limits": [
            "No tests or JavaScript matrix rerun",
            "No source/editorial/editor-intent proof",
            "No browser/font/visual verification",
        ],
    },
)
assert not git("status", "--porcelain=v1", "-z")
print((OUT / "probe-result.json").read_text(encoding="utf-8"))

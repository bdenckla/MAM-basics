"""Freeze public evidence and prepare exactly three isolated receipt paths."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "evidence"
TREE = ROOT / "head"
RECEIPTS = ROOT / "receipts"
BASE = "9b5086dc6f8543dba99f855851f9ccc9f625e9b3"
SOURCE = "46ed8dc5ac41fe556b131b7911726c215ab64140"
PARENT = "fc4afef02881b131e183d3fbb698ae740b85cd6d"
BRANCH = "review-hourly-20261113-7173440e-basics-receipts"
NAME = "review-hourly-2026-11-14-46ed8dc5-basics"


def git(*args, tree=TREE):
    return subprocess.check_output(["git", "-C", str(tree), *args])


def dump(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


assert git("rev-parse", "HEAD").decode().strip() == SOURCE
assert not git("status", "--porcelain=v1", "-z")
assert git("rev-parse", "HEAD", tree=RECEIPTS).decode().strip() == PARENT
assert git("branch", "--show-current", tree=RECEIPTS).decode().strip() == BRANCH
assert not git("status", "--porcelain=v1", "-z", tree=RECEIPTS)
stages = {}
for name in (
    "gen-site",
    "html",
    "probes",
    "scratch-black",
    "scratch-black-preparation",
):
    result = json.loads((OUT / (name + ".json")).read_bytes())
    assert result["exit"] == (1 if name == "html" else 0)
    assert not (OUT / (name + ".diff")).read_bytes()
    assert not (OUT / (name + ".status")).read_bytes()
    stages[name] = result
probe = json.loads((OUT / "probe-result.json").read_bytes())
assert probe["structural_pattern_shared"] == 11
workflow = {}
for ref in (PARENT, SOURCE):
    paths = list(
        filter(
            None,
            git("ls-tree", "-r", "--name-only", "-z", ref, "--", ".github")
            .decode()
            .split("\0"),
        )
    )
    assert paths == [".github/workflows/pages.yml"]
    blob = git("rev-parse", ref + ":.github/workflows/pages.yml").decode().strip()
    body = git("show", ref + ":.github/workflows/pages.yml")
    assert blob == "18ceb19405424710bda47d9a38c470cc2ed9c385"
    assert b"on:\n  workflow_dispatch:\n" in body
    workflow[ref] = {"paths": paths, "blob": blob, "body": body.decode()}
(OUT / "workflow-safety.json").write_bytes(dump(workflow))
assert git("rev-list", "--count", BASE + ".." + SOURCE).decode().strip() == "1"
assert set(
    filter(None, git("diff", "--name-only", "-z", BASE, SOURCE).decode().split("\0"))
) == {"in/stress-helpers/simanim-tanakh.json", "gh-pages/stress-helpers/index.html"}
old_receipt = "doc/review-hourly-2026-11-14-9b5086dc-basics.md"
(OUT / "prior-receipt.md").write_bytes(git("show", PARENT + ":" + old_receipt))
pngs = json.loads((OUT / "png-identities.json").read_bytes())
for path, item in pngs.items():
    item["immutable_git_path"] = SOURCE + ":gh-pages/stress-helpers/" + path
(OUT / "png-identities.json").write_bytes(dump(pngs))
limits = {
    "not_run": [
        "pytest via py/main_test.py, including prior 13 selected tests and Decalogue modules",
        "full mega or suite",
        "JavaScript filter/controls matrix",
        "changed-production-Python Black (no production Python change)",
        "survey recomputation",
        "browser/layout/accessibility tree/font checks",
        "printed-source/crop editorial reading, source refresh, whole-MAM census or editor-intent proof",
        "native Windows/HP, deployment or scheduling",
    ],
    "reason": "Two changed files contain two report-note rewrites and reuse of an existing crop; no executable/style/control change. Maintained generation plus scoped HTML and independent named-field/DOM/source-structure checks cover this surface. Earlier 13-test and JavaScript results at the base remain prior evidence only.",
    "html_disposition": "Known four orphan Decalogue images retained; exit 1 is not a passing HTML run. 111 undefined CSS references are informational.",
    "source_limit": "The 11-case claim is structural support within 13 Simanim Tanakh redundant-edition records, not a whole-MAM census or an independent reading of the printed editions. Ruth's Koren single-pashta reading is attributed to the committed source-note; editor intent remains qualified by likely.",
    "cross_machine_ownership": "unverified",
}
(OUT / "scope-and-limits.json").write_bytes(dump(limits))
review = {
    "observed_utc": datetime.now(timezone.utc).isoformat(),
    "source": SOURCE,
    "base": BASE,
    "receipt_parent": PARENT,
    "files": 2,
    "commits": 1,
    "insertions": 7,
    "deletions": 4,
    "findings": "No consequential introduced defect established; no product repair.",
    "stages": stages,
    "prepare_command": [
        "/workspace/MAM-basics/.venv/bin/python",
        "-B",
        str(ROOT / "prepare.py"),
    ],
    "cleanup_command": [
        "/workspace/MAM-basics/.venv/bin/python",
        "-B",
        "/workspace/scratch/window_controls_20261112.py",
        "cleanup",
        str(ROOT),
        "basics",
        SOURCE,
    ],
    "cleanup_status": "not executed at preparation; separate later closeout",
    "publication_status": "not attempted at preparation; separate later verification",
    "operational_failure": {
        "command": [
            "/workspace/MAM-basics/.venv/bin/python",
            "-B",
            str(ROOT / "prepare.py"),
        ],
        "exit": 1,
        "exception": "AssertionError at line 130; public-content guard matched its own literal",
        "original_script_sha256": sha((ROOT / "prepare-first-failure.py").read_bytes()),
        "preservation": "Original failed script and traceback retained locally outside archive; the guard's excluded-home literal is omitted from public payloads.",
        "disposition": "Replaced value scan with neutral payload-namespace checks. No receipt paths existed at failure, no product changes, and no product check rerun.",
    },
}
(OUT / "review.json").write_bytes(dump(review))
payloads = {"evidence/" + p.name: p.read_bytes() for p in OUT.iterdir() if p.is_file()}
for name in (
    "bootstrap.py",
    "setup.py",
    "run.py",
    "probe.py",
    "prepare.py",
    "publish.py",
):
    payloads["scripts/" + name] = (ROOT / name).read_bytes()
assert all(
    name.startswith(("evidence/", "scripts/")) and ".." not in Path(name).parts
    for name in payloads
)
assert all(
    Path(name).suffix in {".py", ".json", ".log", ".diff", ".status", ".txt", ".md"}
    for name in payloads
)
manifest = {
    name: {"bytes": len(data), "sha256": sha(data)}
    for name, data in sorted(payloads.items())
}
archive = RECEIPTS / "doc" / (NAME + "-evidence.zip")
assert not archive.exists()
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as output:
    for name, data in sorted(payloads.items()):
        output.writestr(name, data)
    output.writestr("manifest.json", dump(manifest))
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    assert set(check.namelist()) == set(manifest) | {"manifest.json"}
    for name, item in manifest.items():
        data = check.read(name)
        assert len(data) == item["bytes"] and sha(data) == item["sha256"]
admission = json.loads((OUT / "admission.json").read_bytes())
receipt = f"""# Bounded Basics screen, November 14, 2026, 01:00 UTC cycle

State: completed 2026-11-14; focused technical review, no product repair

Reviewed `{BASE}` → `{SOURCE}`: **one commit / two paths**, seven insertions / four deletions. No consequential introduced defect established. The Simanim Tanakh opening-qere row at Jeremiah 22:23 reuses the existing Koren crop and describes the differing accents; the Ruth 2:9 second-occurrence note adds the owner's qualified inference about Koren's likely editorial judgment. No new source record, reading or edition membership is introduced.

Independent named-field and HTML checks reconcile **51 edition records** (34 Koren / 17 Simanim Tanakh), **37 rows** (14 shared / 23 single), **9 populated menu choices**, and **35 byte-identical prior rows**. The 13 Simanim Tanakh `redundant-edition` records join 11 Koren records with the same doubled pashta; Jeremiah's opening qere has munaḥ in Koren's input, while Ruth's Koren single pashta is attributed to the committed note. This supports the bounded eleven-case pattern structurally; it does not prove editor intent, reread printed sources or establish a whole-MAM census. The word “likely” remains in the owner's inference.

`gen-site --trust-surveys` exits 0 in **{stages['gen-site']['seconds']:.6f} s**, reproducing every tracked output exactly. The focused probe exits 0: **159 local attributes**, **56 PNGs / 52 unique linked images**, and **53 image occurrences** reconcile. The restored crop appears twice, once in each appropriate row, with correct edition labels, alt text and existing PNG identity. No image-content copy is archived. The maintained generator, controls and style blobs are unchanged. Scoped HTML validation **exits 1** for the same four retained orphan Decalogue crops; **111** CSS references are informational. This is not a passing HTML result.

**Not run:** tests (including the prior 13 selected tests and Decalogue modules), full mega/suite, JavaScript truth matrix, survey recomputation, browser/layout/accessibility-tree/font/native-Windows checks, or printed-source/editorial research. No executable code changed; exact maintained regeneration, scoped HTML validation and independent input/DOM checks cover this small surface. The [prior receipt](review-hourly-2026-11-14-9b5086dc-basics.md)'s tests and JavaScript results remain prior evidence only. Scratch scripts receive owning-environment Black.

Actual admission: **{admission['observed_utc']}**; focused checks finished **{stages['probes']['finished_utc']}**. The [evidence archive]({NAME}-evidence.zip) retains full command arrays, actual UTC times, logs, endpoint diff, per-stage empty generated diffs/statuses, checker scripts, case joins, immutable PNG paths/hashes and payload manifest. The first scratch packaging attempt stopped before receipt writes because its public-content guard matched its own literal; the guard was corrected and the reviewer-tooling failure retained. Product checks were not repeated. The HTML failure remains without cleanup or deletion.

Receipt parent `{PARENT}` preserves every historical status byte, pending gap, finished receipt and November 13 nightly/Windows supplement. Overall reviewed `210affe3ac2931473bead0de839be0de08309e3d` and broad-tested `9ed47c6e8999ecaf56031e9b3f524bee6e01507a` remain unchanged. Source and receipt-parent Pages workflows share the sole manual-dispatch blob `18ceb19405424710bda47d9a38c470cc2ed9c385`. Only the existing isolated receipt branch is prepared; publication and cleanup require separate later closeout evidence. Cross-machine ownership is unverified. No main/shared integration, dispatch, deployment, scheduling or other-repository work.
"""
receipt_path = RECEIPTS / "doc" / (NAME + ".md")
assert not receipt_path.exists()
receipt_path.write_text(receipt, encoding="utf-8", newline="\n")
status_path = RECEIPTS / "doc/review-trial-status.md"
before = git("show", PARENT + ":doc/review-trial-status.md")
assert status_path.read_bytes() == before
section = f"""## Bounded screen, 2026-11-14 01:00 UTC cycle, 46ed8dc5

Reviewed `{BASE}` → `{SOURCE}`: one commit / two paths; no consequential introduced defect or product repair. Existing Koren crop reuse preserves Simanim-only membership; two note rewrites retain the owner's qualified editorial inference. The 13 Simanim Tanakh redundant-edition input cases join 11 matching Koren helper cases, with Jeremiah/Ruth exceptions explicitly scoped; no whole-MAM census or editor-intent proof. 51 records, 37 rows (14 shared/23 single), nine choices and 35 unchanged rows reconcile. gen-site exact; independent 159-local-attribute and 56-PNG/52-linked/53-occurrence checks pass. HTML exits 1 for four retained orphan crops (111 informational CSS references). Tests, JavaScript matrix and broad checks **not run**: no executable/style/control change; prior tests remain prior evidence only. [Receipt]({NAME}.md), [evidence]({NAME}-evidence.zip).

Receipt parent `{PARENT}` and all historical status bytes, gaps, immutable receipts and November 13 nightly/Windows evidence are preserved. Overall reviewed `210affe3ac2931473bead0de839be0de08309e3d` and broad-tested `9ed47c6e8999ecaf56031e9b3f524bee6e01507a` remain unchanged. Preparation only; publication/cleanup have separate later evidence. No new source/editorial/browser/font/native-Windows, other-repository, main/shared/deployment or schedule work.

""".encode("utf-8")
position = before.index(b"## Bounded screen,")
after = before[:position] + section + before[position:]
assert after.replace(section, b"", 1) == before
status_path.write_bytes(after)
paths = [
    "doc/" + NAME + ".md",
    "doc/" + NAME + "-evidence.zip",
    "doc/review-trial-status.md",
]
assert set(
    filter(None, git("diff", "--name-only", "-z", tree=RECEIPTS).decode().split("\0"))
) | set(
    filter(
        None,
        git("ls-files", "--others", "--exclude-standard", "-z", tree=RECEIPTS)
        .decode()
        .split("\0"),
    )
) == set(
    paths
)
git("diff", "--check", tree=RECEIPTS)
raw = archive.read_bytes()
prepared = {
    "branch": BRANCH,
    "parent": PARENT,
    "source": SOURCE,
    "paths": paths,
    "archive": {
        "path": archive.name,
        "bytes": len(raw),
        "sha256": sha(raw),
        "payload_files": len(manifest),
    },
    "prepared_utc": datetime.now(timezone.utc).isoformat(),
}
(ROOT / "publication-prepared.json").write_bytes(dump(prepared))
(ROOT / "stage.json").write_bytes(
    dump(
        {
            "state": "completed",
            "source": SOURCE,
            "base": BASE,
            "stages": stages,
            "prepared_utc": prepared["prepared_utc"],
            "publication": "not attempted",
            "cleanup": "not executed",
        }
    )
)
print(json.dumps(prepared, indent=2))

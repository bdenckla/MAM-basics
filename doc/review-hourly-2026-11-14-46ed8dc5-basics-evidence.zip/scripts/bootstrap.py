"""Prepare bounded public-only scripts from inspected prior-window helpers."""

from pathlib import Path

root = Path(__file__).resolve().parent
prior = Path("/workspace/scratch/basics-9b5086dc")
source = "46ed8dc5ac41fe556b131b7911726c215ab64140"
base = "9b5086dc6f8543dba99f855851f9ccc9f625e9b3"
parent = "fc4afef02881b131e183d3fbb698ae740b85cd6d"
setup = (prior / "setup.py").read_text(encoding="utf-8")
setup = setup.replace(base, source).replace(
    "04d8c567659353f0742b659d27b12846ad55d9dd", parent
)
(root / "setup.py").write_text(setup, encoding="utf-8", newline="\n")
run = (prior / "run.py").read_text(encoding="utf-8").replace(base, source)
begin = run.index("STAGES = [")
end = run.index("if len(sys.argv)", begin)
run = run[:begin] + """STAGES = [
    ("gen-site", [PYTHON, "-B", "py/main_authored.py", "gen-site", "--trust-surveys"]),
    ("html", [PYTHON, "-B", "py/check_html_syntax_and_sanity.py", "gh-pages/stress-helpers"]),
    ("probes", [PYTHON, "-B", str(ROOT / "probe.py")]),
]
""" + run[end:]
(root / "run.py").write_text(run, encoding="utf-8", newline="\n")
probe = (prior / "probe.py").read_text(encoding="utf-8")
probe = probe[: probe.index("seed = deepcopy(")]
probe = (
    probe.replace(base, source)
    .replace("4214fd938d0bfaa92e693f09bfbc1b7207e0a451", base)
    .replace("04d8c567659353f0742b659d27b12846ad55d9dd", parent)
)
probe = probe.replace("assert len(changed) == 7", "assert len(changed) == 2")
probe = probe.replace("assert len(deltas) == 3", "assert len(deltas) == 2")
probe = probe.replace(
    'assert sum(d["before"] is None for d in deltas) == 1',
    'assert all(d["before"] is not None for d in deltas)',
)
probe += """
# Named input fields establish the bounded 13-case population; no whole-corpus census.
site_fields = ("book", "chapter", "verse", "strand", "instance", "location", "mam", "verse_href")
def site_key(record):
    return tuple(record.get(k) for k in site_fields)

koren = {site_key(r): r for r in inputs["koren"]["differences"]}
sim_redundant = [r for r in inputs["simanim-tanakh"]["differences"] if r["category"] == "redundant-edition"]
pattern = []
shared_pashta = []
exceptions = []
for r in sim_redundant:
    k = koren.get(site_key(r))
    assert r["mam"].count("\\N{HEBREW ACCENT PASHTA}") == 1
    assert r["printed"].count("\\N{HEBREW ACCENT PASHTA}") == 2
    if k is not None and k["category"] == "redundant-edition":
        assert k["printed"] == r["printed"]
        assert k["printed"].count("\\N{HEBREW ACCENT PASHTA}") == 2
        shared_pashta.append(site_key(r))
    else:
        exceptions.append(site_key(r))
    pattern.append({"site": dict(zip(site_fields, site_key(r))), "simanim": r, "koren": k})
assert len(sim_redundant) == 13 and len(shared_pashta) == 11 and len(exceptions) == 2
jer = next(r for r in sim_redundant if r["book"] == "Jeremiah" and r["chapter"] == 22 and r["verse"] == 23 and r.get("location") == "Opening qere")
jk = koren[site_key(jer)]
assert jk["category"] == "different-accent"
assert "\\N{HEBREW ACCENT PASHTA}" not in jk["printed"]
assert jk["printed"].count("\\N{HEBREW ACCENT MUNAH}") == 1
assert jer["comparison_crops"] == {"koren": jk["crops"]}
ruth = next(r for r in sim_redundant if r["book"] == "Ruth" and r["chapter"] == 2 and r["verse"] == 9)
assert site_key(ruth) not in koren and ruth["location"] == "Second occurrence"
assert "MAM and Koren (p. 158) have a single pashta" in ruth["notes"][0]["text"]
assert "would likely consider" in ruth["notes"][0]["text"]
# Ruth's Koren single-pashta reading is the authored source-note, not a new difference record.
save("eleven-case-pattern.json", {"population": "13 Simanim Tanakh redundant-edition input records; joined by named site/MAM fields", "shared_matching_pashta_helpers": len(shared_pashta), "exceptions": exceptions, "cases": pattern, "limit": "Structural input support only; no printed-source rereading, whole-MAM census, or proof of editor intent."})
same = {}
for p in ("py/author_site/stress_helper_comparison.py", "gh-pages/stress-helpers/controls.js", "gh-pages/stress-helpers/style.css"):
    raw = (TREE / p).read_bytes()
    assert raw == git("show", BASE + ":" + p)
    same[p] = {"git_blob": git("rev-parse", SOURCE + ":" + p).decode().strip(), "sha256": hashlib.sha256(raw).hexdigest()}
save("unchanged-executable-style-blobs.json", same)
raw_old = git("show", BASE + ":gh-pages/stress-helpers/index.html")
old_lines = {line for line in raw_old.splitlines() if line.startswith(b"<tr data-filter=")}
new_lines = {line for line in new_raw.splitlines() if line.startswith(b"<tr data-filter=")}
assert len(old_lines & new_lines) == len(rows) - 2
assert len(rows) == 37 and memberships == {1: 23, 2: 14}
assert len(inputs["koren"]["differences"]) == 34
assert len(inputs["simanim-tanakh"]["differences"]) == 17
assert len(options) - 1 == 9 and len(pngs) == 56 and len(linked) == 52
crop = jer["comparison_crops"]["koren"][0]
assert new_raw.count(('src="' + crop + '"').encode()) == 2
assert raw_old.count(('src="' + crop + '"').encode()) == 1
assert not any(r["book"] == "2Samuel" and r["chapter"] == 13 and r["verse"] == 20 for data in inputs.values() for r in data["differences"])
save("png-identities.json", pngs)
save("rows.json", row_evidence)
save("probe-result.json", {"observed_utc": datetime.now(timezone.utc).isoformat(), "source": SOURCE, "base": BASE, "records": {e: len(d["differences"]) for e, d in inputs.items()}, "rows": len(rows), "memberships": dict(memberships), "menu_choices": len(options)-1, "unchanged_prior_rows": len(old_lines & new_lines), "local_attributes": local, "png_files": len(pngs), "unique_linked_pngs": len(linked), "image_occurrences": len(doc.xpath('//img')), "orphan_pngs": orphans, "restored_crop": crop, "restored_crop_occurrences": 2, "structural_pattern_shared": len(shared_pashta), "limits": ["No tests or JavaScript matrix rerun", "No source/editorial/editor-intent proof", "No browser/font/visual verification"]})
assert not git("status", "--porcelain=v1", "-z")
print((OUT / "probe-result.json").read_text(encoding="utf-8"))
"""
(root / "probe.py").write_text(probe, encoding="utf-8", newline="\n")
publisher = (
    (prior / "publish.py")
    .read_text(encoding="utf-8")
    .replace(str(prior), str(root))
    .replace("November 14 00:00 UTC", "November 14 01:00 UTC")
)
(root / "publish.py").write_text(publisher, encoding="utf-8", newline="\n")

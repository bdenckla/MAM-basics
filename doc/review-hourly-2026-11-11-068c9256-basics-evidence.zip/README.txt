PUBLIC frozen source e4533ff6844355d3dcb47f9b7e2e4d3d926e9267..068c9256038a98150d75ed3553a64745a49d38fb.
Executed checker retained verbatim with actual WORK/OUT/PYTHON paths. Recreate the exact committed input in a new owned isolated checkout and adjust only local path constants for reproduction.
Four maintained commands: gen-site --trust-surveys; gen-mam-for-sefaria-doc; six explicit py/main_test.py targets; changed-source Black. All outputs stayed byte-identical to committed head.
The documentation CLI executes survey/_silluq_cases on committed CSV, CSV-AJF and canonical MAM-simple; the selected documentation test independently matches all annotation branches/exporter projections against the rendered guide table. No fresh product export or live request.
Independent source AST/HTML/Hebrew/link checks and exact committed target-index.html are retained. Only phi4 and its URL constant change; owner wording is untouched.
14 tests actually passed; owner-reported 20 is a separate attributed population. No broad suite/mega, manuscript/editorial/browser/font judgment, source refresh, baseline/build/hbofonts, main/shared integration, deployment/dispatch or schedule operation.

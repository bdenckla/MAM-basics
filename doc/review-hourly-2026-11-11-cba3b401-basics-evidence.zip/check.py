"""Bounded relocation/header comparison and offline checker-guard probes."""

import ast
import hashlib
from html.parser import HTMLParser
import importlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
from urllib.parse import unquote, urlsplit

ROOT = Path("/workspace/scratch/basics-cba3b401-checkout")
OUT = Path("/workspace/scratch/basics-cba3b401-artifacts")
BASE = "b1bdd3787ee2ab2a1e6315b01d8a1019894c9b48"
HEAD = "cba3b401666aa0a49147fdc54294086ff343de81"


def git(*args):
    return subprocess.check_output(["git", "-C", str(ROOT), *args])


def raw(commit, path):
    return git("show", f"{commit}:{path}")


def files(commit):
    return (
        git("ls-tree", "-r", "--name-only", "-z", commit)
        .decode()
        .strip("\0")
        .split("\0")
    )


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tags = []

    def handle_starttag(self, tag, attrs):
        self.tags.append((tag, dict(attrs)))


assert git("rev-parse", "HEAD").decode().strip() == HEAD
assert not git("status", "--porcelain=v1", "-z")
old_paths, new_paths = set(files(BASE)), set(files(HEAD))
changes = git("diff", "--name-status", "-z", "-M", BASE, HEAD)
(OUT / "endpoint-name-status.z").write_bytes(changes)
(OUT / "endpoint.patch").write_bytes(git("diff", "--binary", "-M", BASE, HEAD))
post_paths = sorted(
    p
    for p in old_paths
    if p.startswith("gh-pages/post-stress-meteg") and p.endswith(".html")
)
assert len(post_paths) == 16
counts = {"stylesheets": 0, "crops": 0}
identities = []
moved = []
for old in post_paths:
    new = "gh-pages/post-stress-meteg/" + Path(old).name
    before, after = raw(BASE, old), raw(HEAD, new)
    for kind, pattern in [
        ("stylesheets", rb'href="(document\.css|style\.css|wlc/style\.css)"'),
        ("crops", rb'src="(img/[^\"]+)"'),
    ]:
        before, n = re.subn(
            pattern, lambda m: m[0].replace(m[1], b"../" + m[1], 1), before
        )
        counts[kind] += n
    assert before == after, new
    identities.append(
        {"base": old, "head": new, "head_sha256": hashlib.sha256(after).hexdigest()}
    )
    moved.append(new)
assert counts == {"stylesheets": 48, "crops": 37}
assert {
    p
    for p in new_paths
    if p.startswith("gh-pages/post-stress-meteg")
    and p.endswith(".html")
    and p.count("/") == 1
} == {"gh-pages/post-stress-meteg.html"}

ib_old = "gh-pages/MAM-with-doc/misc/review_of_israel_bible.html"
ib_new = "gh-pages/israel-bible-review/index.html"
before, after = raw(BASE, ib_old), raw(HEAD, ib_new)
for old, new in [
    (
        b"py/author_misc/review_of_israel_bible.py",
        b"py/author_misc/israel_bible_review_index.py",
    ),
    (b"../../document.css", b"../document.css"),
    (b"review_of_israel_bible.css", b"style.css"),
    (
        b"../../near-aleppo/link-presentation.css",
        b"../near-aleppo/link-presentation.css",
    ),
    (b"img/israel_bible/", b"img/"),
]:
    assert before.count(old) == 1, old
    before = before.replace(old, new)
assert before == after
assert ib_old not in new_paths
old_crop = next(
    p for p in old_paths if p.startswith("gh-pages/MAM-with-doc/misc/img/israel_bible/")
)
new_crop = "gh-pages/israel-bible-review/img/" + Path(old_crop).name
assert raw(BASE, old_crop) == raw(HEAD, new_crop)
old_css = raw(BASE, "gh-pages/MAM-with-doc/misc/review_of_israel_bible.css")
new_css = raw(HEAD, "gh-pages/israel-bible-review/style.css")
strip_comments = lambda b: re.sub(rb"/\*.*?\*/", b"", b, flags=re.S)
assert strip_comments(old_css).replace(b"../../woff2/", b"../woff2/") == strip_comments(
    new_css
)

for path in [
    "MAM-OSIS/header.xml",
    "MAM-OSIS/mapm.osis.xml",
    "MAM-morphhb/header.xml",
    "MAM-morphhb/MAPM.xml",
]:
    before = raw(BASE, path)
    for old, new in [
        (
            b"<title>Miqra according to the Mesorah</title>",
            b"<title>Miqra according to the Masorah</title>",
        ),
        (
            b"<description>Miqra `al pi ha-Mesorah",
            b"<description>Miqra `al pi ha-Masorah",
        ),
        (
            b"http://en.wikisource.org/wiki/User:Dovi/Miqra_according_to_the_Mesorah",
            b"https://en.wikisource.org/wiki/User:Dovi/Miqra_according_to_the_Masorah",
        ),
    ]:
        assert before.count(old) == 1, (path, old)
        before = before.replace(old, new)
    assert before == raw(HEAD, path), path
conf = raw(BASE, "MAM-OSIS/mapm.conf")
assert conf.count(b"Mesorah") == 3
assert conf.replace(b"Mesorah", b"Masorah") == raw(HEAD, "MAM-OSIS/mapm.conf")

target = "post-stress-meteg/post-stress-meteg.html"
stub = raw(HEAD, "gh-pages/post-stress-meteg.html").decode()
assert f'<link rel="canonical" href="{target}">' in stub
assert f'<meta http-equiv="refresh" content="0; url={target}">' in stub
assert (
    f"location.replace({json.dumps(target)} + location.search + location.hash);" in stub
)
assert f'<a href="{target}">' in stub
resolved = 0
for path in moved + [ib_new, "gh-pages/post-stress-meteg.html"]:
    parser = Links()
    parser.feed(raw(HEAD, path).decode())
    for tag, attrs in parser.tags:
        key = "src" if tag == "img" else "href" if tag in ("a", "link") else None
        if not key or key not in attrs:
            continue
        url = urlsplit(attrs[key])
        if url.scheme or url.netloc or not url.path:
            continue
        destination = (ROOT / path).parent / unquote(url.path)
        assert destination.is_file(), (path, attrs[key])
        resolved += 1
for sheet in ["gh-pages/israel-bible-review/style.css", "gh-pages/wlc/style.css"]:
    for url in re.findall(r"url\([\"\']?([^\)\"\']+)", raw(HEAD, sheet).decode()):
        if not urlsplit(url).scheme:
            assert ((ROOT / sheet).parent / url).is_file(), (sheet, url)

sys.path.insert(0, str(ROOT / "py"))
checker = importlib.import_module("check_html_syntax_and_sanity")
with tempfile.TemporaryDirectory(prefix="guard-", dir=OUT) as folder:
    deploy = Path(folder)
    expected = "_PAGES_FOR_OUTSIDE_LINKS names a missing page: post-stress-meteg.html"
    assert checker._check_orphan_html(deploy, [], {}, deploy, recursive=False) == [
        expected
    ]
    stub_path = deploy / "post-stress-meteg.html"
    stub_path.write_text(stub)
    assert (
        checker._check_orphan_html(deploy, [stub_path], {}, deploy, recursive=False)
        == []
    )
    subsite = deploy / "unrelated-subsite"
    subsite.mkdir()
    assert checker._check_orphan_html(subsite, [], {}, deploy, recursive=True) == []

for path in ["requirements.txt", "constraints.txt"]:
    assert (Path("/workspace/MAM-basics") / path).read_bytes() == raw(HEAD, path)

result = dict(
    result="PASS",
    base=BASE,
    head=HEAD,
    post_stress_pages=16,
    path_insertions=counts,
    israel_bible="Exact HTML reconstruction by five path/banner substitutions; CSS executable rules differ only by font path; crop byte-identical.",
    export_headers="Exactly three header substitutions in both headers and full XML exports; mapm.conf three spelling substitutions; other bytes unchanged.",
    redirect="Four agreeing targets; JavaScript expression retains search and hash. Static check, no browser execution.",
    relative_link_asset_targets=resolved,
    missing_outside_page_probes=3,
    environment="Python 3.13.15; home requirements/constraints byte-identical to source.",
    identities=identities,
    limits="No live/source/manuscript/editorial/browser/font verification, no broad suite/mega or historical anchor advance.",
)
(OUT / "independent-result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))

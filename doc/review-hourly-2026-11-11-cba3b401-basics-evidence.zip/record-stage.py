"""Retain one sequential focused stage for the frozen Basics endpoint."""

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path("/workspace/scratch/basics-cba3b401-checkout")
OUT = Path("/workspace/scratch/basics-cba3b401-artifacts")
PYTHON = "/workspace/MAM-basics/.venv/bin/python"
SLOT = Path("/workspace/scratch/basics-cba3b401-slot/owner.json")
HEAD = "cba3b401666aa0a49147fdc54294086ff343de81"
if sys.argv[1] == "html-holman-base":
    ROOT = Path("/workspace/scratch/basics-cba3b401-baseline")
    HEAD = "b1bdd3787ee2ab2a1e6315b01d8a1019894c9b48"
COMMANDS = {
    "gen-israel-bible-review": [
        PYTHON,
        "-B",
        "py/main_authored.py",
        "gen-israel-bible-review",
    ],
    "gen-misc": [PYTHON, "-B", "py/main_authored.py", "gen-misc"],
    "gen-site": [PYTHON, "-B", "py/main_authored.py", "gen-site", "--trust-surveys"],
    "holman-render": [PYTHON, "-B", "py/main_verify_and_render_table.py"],
    "mam-morphhb": [PYTHON, "-B", "py/main_mam_morphhb.py"],
    "mam-osis": [PYTHON, "-B", "py/main_mam_osis.py"],
    "html-israel": [
        PYTHON,
        "-B",
        "py/check_html_syntax_and_sanity.py",
        "gh-pages/israel-bible-review",
    ],
    "html-post-stress": [
        PYTHON,
        "-B",
        "py/check_html_syntax_and_sanity.py",
        "gh-pages/post-stress-meteg",
    ],
    "html-root": [PYTHON, "-B", "py/check_html_syntax_and_sanity.py", "--deploy-root"],
    "html-mam-with-doc": [
        PYTHON,
        "-B",
        "py/check_html_syntax_and_sanity.py",
        "gh-pages/MAM-with-doc",
    ],
    "html-holman": [
        PYTHON,
        "-B",
        "py/check_html_syntax_and_sanity.py",
        "gh-pages/holman",
    ],
    "html-holman-base": [
        PYTHON,
        "-B",
        "py/check_html_syntax_and_sanity.py",
        "gh-pages/holman",
    ],
    "tests": [
        PYTHON,
        "-B",
        "py/main_test.py",
        "py/tests/test_israel_bible_review_mam_forms.py",
        "py/tests/test_shared_html_styles.py",
        "py/tests/test_site_index_links.py",
        "py/tests/test_product_scopes.py",
        "py/tests/test_mega_coverage.py",
        "py/tests/test_deploy_root_html.py",
        "py/tests/test_sibling_reach.py",
        "py/tests/test_post_stress_meteg_plain_word.py",
        "py/tests/test_post_stress_meteg_annotations.py",
        "py/tests/test_entry_point_subcommands.py",
        "py/tests/test_h_dot_below_nfc.py",
        "py/tests/test_cgj_between_marks.py",
        "py/tests/test_prose_mark_order.py",
        "py/tests/test_prose_conventions.py",
        "py/tests/test_transliterations.py",
        "py/tests/test_tracked_filenames.py",
        "py/tests/test_no_machine_paths_in_artifacts.py",
    ],
    "diff-check": ["git", "diff", "--check"],
    "independent": [PYTHON, "-B", "/workspace/scratch/check_basics_cba3b401.py"],
}


def git(*args):
    return subprocess.check_output(["git", "-C", str(ROOT), *args])


name = sys.argv[1]
assert git("rev-parse", "HEAD").decode().strip() == HEAD
if not SLOT.exists():
    SLOT.write_text(
        json.dumps(
            dict(
                state="claimed",
                owner="saved-cloud Basics cba3b401 screen",
                claimed_utc=datetime.now(timezone.utc).isoformat(),
                source=HEAD,
                checkout=str(ROOT),
                home="/workspace/MAM-basics",
                cross_machine_ownership="HP list unavailable; not independently verified",
            ),
            indent=2,
        )
        + "\n"
    )
state = OUT / "current-stage.json"
if state.exists():
    assert json.loads(state.read_text())["state"] != "running"
record = OUT / (name + ".json")
assert (
    not record.exists()
), "Inspect completed or uncertain operation; never repeat blindly"
if name == "black":
    raw = git(
        "diff",
        "--name-only",
        "-z",
        "--diff-filter=AMR",
        "b1bdd3787ee2ab2a1e6315b01d8a1019894c9b48",
        HEAD,
    )
    files = [x for x in raw.decode().split("\0") if x.endswith(".py")]
    command = [PYTHON, "-B", "-m", "black", "--check", *files]
else:
    command = COMMANDS[name]
env = os.environ.copy()
env.update(
    PYTHONDONTWRITEBYTECODE="1",
    PYTHONUNBUFFERED="1",
    PATH="/workspace/.cloud-setup/bin:" + env["PATH"],
    XDG_CACHE_HOME="/workspace/.cloud-setup/cache",
)
summary = dict(
    stage=name,
    state="running",
    command=command,
    cwd=str(ROOT),
    started_utc=datetime.now(timezone.utc).isoformat(),
    runner_pid=os.getpid(),
)
record.write_text(json.dumps(summary, indent=2) + "\n")
state.write_text(json.dumps(summary, indent=2) + "\n")
start = time.monotonic()
print("START", name, summary["started_utc"], flush=True)
with (OUT / (name + ".log")).open("wb") as log:
    completed = subprocess.run(
        command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT
    )
summary.update(
    state="completed",
    exit_code=completed.returncode,
    elapsed_seconds=round(time.monotonic() - start, 6),
    finished_utc=datetime.now(timezone.utc).isoformat(),
)
for label, args, suffix in [
    ("status", ["status", "--porcelain=v1", "-z"], ".z"),
    ("tracked-diff", ["diff", "--binary"], ".diff"),
    ("untracked", ["ls-files", "--others", "--exclude-standard", "-z"], ".z"),
]:
    raw = git(*args)
    (OUT / (name + "-" + label + suffix)).write_bytes(raw)
    if label == "status":
        summary["status_clean"] = not raw
record.write_text(json.dumps(summary, indent=2) + "\n")
state.write_text(json.dumps(summary, indent=2) + "\n")
print("FINISH", json.dumps(summary), flush=True)
sys.exit(completed.returncode)

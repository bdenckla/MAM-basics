"""Run one configured focused stage sequentially and preserve exact outcomes."""

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import time

config = json.loads(Path(sys.argv[1]).read_text())
name = sys.argv[2]
stage = config["stages"][name]
root = Path(stage.get("cwd", config["root"]))
out = Path(config["out"])
command = stage["command"]
expected = stage.get("head", config["head"])
assert (
    subprocess.check_output(["git", "-C", str(root), "rev-parse", "HEAD"])
    .decode()
    .strip()
    == expected
)
record = out / (name + ".json")
assert not record.exists(), "Inspect prior/uncertain outcome before any retry"
current = out / "current-stage.json"
if current.exists():
    assert json.loads(current.read_text())["state"] != "running"
env = os.environ.copy()
env.update(
    PYTHONDONTWRITEBYTECODE="1",
    PYTHONUNBUFFERED="1",
    PATH="/workspace/.cloud-setup/bin:" + env["PATH"],
    XDG_CACHE_HOME="/workspace/.cloud-setup/cache",
)
env.update(config.get("env", {}))
info = dict(
    stage=name,
    state="running",
    command=command,
    cwd=str(root),
    source=expected,
    started_utc=datetime.now(timezone.utc).isoformat(),
    runner_pid=os.getpid(),
    environment_overrides=config.get("env", {}),
)
record.write_text(json.dumps(info, indent=2) + "\n")
current.write_text(json.dumps(info, indent=2) + "\n")
print("START", name, info["started_utc"], flush=True)
timer = time.monotonic()
with (out / (name + ".log")).open("wb") as log:
    result = subprocess.run(
        command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT
    )
info.update(
    state="completed",
    exit_code=result.returncode,
    elapsed_seconds=round(time.monotonic() - timer, 6),
    finished_utc=datetime.now(timezone.utc).isoformat(),
)
for label, args, suffix in [
    ("status", ["status", "--porcelain=v1", "-z"], ".z"),
    ("tracked-diff", ["diff", "--binary"], ".diff"),
    ("untracked", ["ls-files", "--others", "--exclude-standard", "-z"], ".z"),
]:
    data = subprocess.check_output(["git", "-C", str(root), *args])
    (out / (name + "-" + label + suffix)).write_bytes(data)
    if label == "status":
        info["status_clean"] = not data
record.write_text(json.dumps(info, indent=2) + "\n")
current.write_text(json.dumps(info, indent=2) + "\n")
print("FINISH", json.dumps(info), flush=True)
sys.exit(result.returncode)

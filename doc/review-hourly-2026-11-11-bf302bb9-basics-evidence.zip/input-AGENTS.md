# AGENTS.md

## Approved review and testing trial, 2026-10-07

Follow [doc/review-trial.md](doc/review-trial.md) for ordinary verification, review triage,
routine repair authority and exception PRs. It controls the older review and broad-check
requirements during this trial; focused regeneration and product/privacy safeguards still apply.

## Compatibility note for historical instruction citations

`AGENTS.md` is the common repository instruction body. Codex loads it directly, and Claude Code
loads it through the minimal `CLAUDE.md` wrapper. Historical prose that cites “`CLAUDE.md`'s
section X” means either the matching section here or the task-specific reference to which that
section now points; do not mechanically rewrite historical citations.

## Hebrew marks go in MAM-normal order, not Unicode-normal order

MAM-normal order gives priority to shin dot, sin dot, dagesh/mapiq/shuruq dot,
dagesh ḥazaq (U+05C9), and rafe. The two dagesh code points share a priority while
preserving the other marks' relative order. `py/mb_cmn/uni_denorm.py` is the authority:
`give_std_mark_order` applies the order and `has_std_mark_order` checks it.

`unicodedata.normalize` puts Hebrew marks in Unicode's order, not MAM's. So don't use it to
produce Hebrew that belongs in MAM's order, or to hide a mark-order mismatch that matters;
`give_std_mark_order` is the tool for both. A call that only asks what normalization would do,
as the fragility test in `py/mb_cmn/uni_norm_fragile.py` does, is fine. Hebrew copied from a
browser is especially suspect because the two orders render identically.

Do not “repair” faithful external captures or intermediates upstream of the pipeline's deliberate
denormalization. Known examples include `in/mam-ws/`, its faithful intermediates, and verbatim
source captures. For scope, census evidence, and the checks covering authored prose, Python,
JSON, data, and generated pages, read `doc/mam-normal-mark-order.md` before changing mark order.

## Tracked filenames do not use Hebrew letters; Git filename output is NUL-delimited

No tracked filename contains a Hebrew letter. Convert a Hebrew filename component with
`consensus_to_ascii` from `py/author_boj_util/author.py`; do not invent another
transliteration.

Every programmatic Git command returning filenames requests NUL delimiters with `-z` and splits
on `"\0"`, never on lines. Spaces, tabs, newlines, quoting characters, and future non-ASCII
filenames remain possible. `py/tests/test_tracked_filenames.py` enforces both rules.

## Invoke the `hebrew-prose` skill before accentuation prose

Before writing, editing, or reviewing prose about Hebrew accentuation or cantillation, in any
register from rendered pages to chat, load the user-level `hebrew-prose` skill and its
`references/mam-basics.md`, which carries this repository's exceptions. The skill's canonical
copy is `dot-claude/skills/hebrew-prose/`; never edit a live copy. `dot-claude/README.md`
gives the deployment and the cloud SessionStart hook, `.claude/hooks/install-user-config.sh`.

## The MAM introduction is mirrored locally

Read `in/mam-ws-intro/README.md` and the mirror itself instead of fetching a summarized web copy.
The README maps all thirteen files, gives the independent refresh command, explains the
byte-verbatim mark-order exception, and distinguishes the two manually maintained index pages
from their retired one-off generators. `manifest.json` records each source revision and
timestamp.

## MAM special pages are mirrored with every Wikisource chapter download

Every `py/main_download.py fr-wikisource` run maintains the 36 declared Decalogue,
song-form, and corresponding chapter pages under `in/mam-ws-special/`, even when the
chapter selection is narrow. The `.mediawiki` files are byte-verbatim captures and
`manifest.json` records requested and resolved titles, exact revisions, byte sizes,
and SHA-256 hashes. `py/ws/ws_special_page_download.py` owns the literal inventory and
permits only the eight declared identities to overlap the chapter mirror. It checks the
inventory against chapter 2 of the mirrored introduction, `in/mam-ws-intro/ch2.mediawiki`:
the Decalogue section's table and the paragraph after it, and the song-form table. Do not
hand-edit the mirror or its manifest.

## Holman and book-of-Job work has local routing documentation

Before touching Holman mailboxes, correspondence derivatives, dispositions, or authored assets,
read `holman/WORKFLOW.md`. Raw mail remains untracked; public derivatives exclude addresses; MAM
suggestion dispositions contain substantive judgments rather than personal circumstances; and
authored CSS and JavaScript live in `holman/assets/`, not in generated `gh-pages/` copies.

Before touching `py/author_boj*`, read the relevant `doc/boj-*.md` procedure. Those four
procedures began as Copilot instructions and have not all been re-verified, so current
user-level and repository instructions win when a command conflicts. The two procedures for
reading the evacuated product live under `book-of-job/doc/`.

## The HBCE Psalms snapshot is never refreshed from its site's API

Before touching `hbce-psalms/`, `py/hbce_psalms/` or `py/main_hbce_psalms.py`, read
`hbce-psalms/README.md`. Never fetch from hbcepsalms.manuscriptroom.com's web-service API, which
the site's robots.txt disallows: the snapshot is a good-faith download made before anyone had read
that file. If the work resumes, fresh data comes only through the INTF or its documented exports,
and whether to contact the INTF is Ben's decision. `hbce-psalms/out/` is a frozen record of one
run: by Ben's decision of 2026-09-26, a change to MAM's data does not oblige rerunning
`py/main_hbce_psalms.py compare`, as the hand-run rule below would otherwise require.

## Taamey D work has local routing documentation

Before touching `Taamey-D/`, `py/taamey_d*/`, `py/main_taamey_d*.py` or `gh-pages/taamey-d/`,
read `Taamey-D/README.md`. The font's FontForge build, `py/main_taamey_d_build.py`, is a hand-run
generator. Never normalize or casually reorder the Hebrew in Taamey D's files. Accepting
observed output into the shaping checks' baseline needs Ben's approval, and publishing a Taamey D
release is outward-facing.

## Issue citations in MAM-basics

Load the `github-issues` skill for any issue operation or citation audit. The always-needed
MAM-basics rules are:

1. A bare `#NN` in current MAM-basics files means a MAM-basics issue. Cite another tracker as
   `repo#NN`. In an issue or comment, use the other issue's full URL.
2. A number that is not an issue never takes a bare `#NN` form. Name an ITM section, a design-doc
   item, a UXLC change, or a CSS color in a form that cannot link to an unrelated issue.
3. Imported wlc-utils documents under `doc/` and `in/`, and imported UXLC-utils documents under
   `uxlc/doc/`, retain their original bare-number meaning. Read the surrounding sentence before
   changing a citation.
4. `py/py_render/rt_issue_tags.py` and `py/hkq_cmn/table_row_github_issues.py` render
   holman-ketiv-qere issue numbers as data. Repository constants supply that tracker; prefixing
   the stored numbers would corrupt the output.

For collision history, evacuated tracker dispositions, transferred issues, and the exact traps
encountered by past sweeps, read the skill's `references/mam-basics-trackers.md`.

## Review filenames and finished dated documents

Follow `doc/periodic-review.md`, “Review filenames and State lines”, for ordinary review
records. Private review records stay in MAM-private.

Load `iterative-document-editing`, “Finished receipts and maintained documents” and
“MAM-basics and MAM-private State conventions”, for receipt corrections and non-review State.
Load `mam-repository-topology/references/repository-maintenance.md`, “Manual document
retirement”, before retiring a receipt family or carrying out Ben-authorized reclassification.

## Repository topology is task-specific

Load the shared `mam-repository-topology` skill before setting up or synchronizing GitRepos,
performing repository maintenance, publishing redirect stubs, retiring a clone, or deciding
where an evacuated repository or sibling dependency lives. If the skill is not installed in a
cloud session, read `dot-claude/skills/mam-repository-topology/SKILL.md` from the checkout and
follow its reference routing.

`in/repo_maintenance_policy.json` and `all-repos.code-workspace` are the sources of truth.
Roster clones in the forests declared by `clone_forests` are expected. An evacuated or unlisted
repository's clone is residue, not evidence that its disposition changed. Do not infer the
desired clone set from `gh repo list` or a disk set difference. Evacuated repositories, the
public ones and the private hbofonts alike, can remain redirect hosts, download hosts or issue
trackers while belonging on no machine; the skill's `references/evacuated-repositories.md`
carries their exact current dispositions, temporary-stub procedures, and historical traps.

## What this repository's products are, and which check a change owes

`py/product_scopes.py` is the declaration of record, enforced by
`py/tests/test_product_scopes.py`. The product tiers are:

1. **Published:** `gh-pages/`, published from `main` only on manual dispatch of
   `.github/workflows/pages.yml`; by Ben's decision of 2026-10-22 it no longer also deploys daily
   at 4:17 AM, New York time. A push to `main` therefore reaches the site only at the next
   dispatch. Since Ben's decision of 2026-10-29 the workflow first runs
   `py/main_taamey_d.py release-check` on the full history, and deploys nothing if it fails.
2. **Distributed data:** `MAM-parsed/`, `MAM-simple/`, `MAM-for-Sefaria/`, `MAM-with-doc/`,
   `MAM-OSIS/`, `MAM-morphhb/`, `Phonetic-MAM/`, `Taamey-D/`, `Yeivin-ITM/`, and
   `out/near-aleppo/`.
3. **Generators:** the entry points run by `py/main_0_mega.py`.

Before pushing `main` to `origin`, run the mega and the suite. Like most rules this one has
exceptions: skip either when you judge the changes reasonably likely to be safe, or unlikely to
have a problem that it would catch, and say what you skipped, and why, in the message of the last
commit you push. If that decision follows the last commit, as when a worktree branch is
fast-forwarded unchanged, push an empty commit (`git commit --allow-empty`) whose message says it,
rather than amending. Committing to or integrating into a local `main` needs no such check until
that `main` is pushed. When the mega runs, a failing step or an unexplained tracked diff is a failure.
The mega does not run the hand-run generators, so a hand-run generator can reach a product that
no mega run checks. A change to a hand-run generator, or to any input it reads, requires
rerunning every affected hand-run generator and inspecting its tracked outputs, with three
exceptions that Ben decided. A refresh of MAM's text does not oblige rerunning
`py/main_mam4sef.py` or `py/main_mam_osis.py` (his decision of 2026-09-30) or
`py/main_mam_morphhb.py` (his decision of 2026-11-03), so MAM-for-Sefaria, MAM-OSIS and
MAM-morphhb may lag MAM-simple, as their READMEs say; any other change to one of those
generators or to its inputs still does. A change to MAM's data does not oblige rerunning
`py/main_hbce_psalms.py compare` (his decision of 2026-09-26, in the HBCE section above). A
refresh of MAM's text does not oblige refreshing Taamey D's shaping-check corpus with
`py/main_taamey_d.py corpus` (his decision of 2026-10-28): the mega's `taamey-d-corpus` step
reports `REFRESH PENDING` instead, and a refresh needs his baseline acceptance. That corpus,
`Taamey-D/qa-in/`, is a pinned test population of MAM's text, the decision's deliberate
exception to the next paragraph's rule.
Product reach and whether an act is hard to undo are separate risk axes, as the user-level
instructions explain.

A product derived from MAM's text takes each Wikisource refresh through the
`mam-wikisource-refresh` runbook's judgment of every diff, so it gets no hashes, fingerprints
or pinned populations of its inputs. A deterministic check is closed dispatch, or it tests
that a hand-made statement about the data still holds and covers exactly what that statement
depends on: a stored pointed ketiv's check covers its ketiv and its whole qere, letters and
every mark, and not its template's name.

Ben decided on 2026-09-11 that `py/main_0_mega.py` writes nothing outside this repository.

## Generated clock dates and timestamps shown on pages use New York time and say so

A date or timestamp that repository code generates from a clock for display on a page or report
is converted through `py/mb_cmn/new_york_time.py` and followed by “, New York time”. Historical
decision dates, citations, quotations, release or revision dates, and date-like names—including
release names, change ids and dated filenames—take no label. Stored timestamps retain full ISO
8601 offsets. Git dates retain their offset with `%cI` or `%ct`, never `%cs`; clock reads name
their zone. `py/tests/test_explicit_time_zones.py` enforces the mechanical rule.

## A code path reads MAM-private every time it runs, or never

A code path that depends on MAM-private reads it unconditionally. Every other code path must
fail loudly if it unexpectedly needs MAM-private; it must not probe for the private tree only
when particular data happens to require it. Use `py/mb_cmn/paths.py`'s required-sibling helpers.
The Phonetic MAM exporter alone reads private inputs through a read-only subprocess.
Rendering, public analyses and final-stress tests consume the tracked `Phonetic-MAM/`
release, including in cloud sessions; they have no private-input fallback.

## Integrating a worktree branch here

A worktree's integration fast-forwards its home clone's `main` and then pushes it, so the
products section's rule for a push decides whether the mega and the suite run. Run whatever that
push needs before the fast-forward: after merging the home clone's `main` into the worktree branch,
run from the worktree root using the home clone's interpreter by absolute path, and commit each
explained generated change on the worktree branch, since the home clone takes only fast-forwards.
The full-clone form of the mega is:

```powershell
./.venv/Scripts/python.exe py/main_0_mega.py
```

The `linked-worktrees` skill's `references/integration.md` gives the remaining integration order.

## Running tests: use the one entrypoint from the repository root

Run the suite from the verified MAM-basics repository root. A full clone uses its own
environment; a linked worktree uses its home clone's interpreter by absolute path:

```powershell
./.venv/Scripts/python.exe py/main_test.py
```

Arguments pass through to pytest. A linked worktree normally finds MAM-private through Git's
common-directory metadata and needs no `REPOS_ROOT`; the variable remains an override for an
unusual layout. Always run from the repository root because some inputs are intentionally
cwd-relative.

`py/main_test.py` is the only runner. A bare `pytest` or `pytest py/tests` failing imports is the
designed state; do not add `sys.path` surgery, a root `conftest.py`, pytest `pythonpath`, a `.pth`,
`PYTHONPATH`, or an editable installation. Pytest discovers `test_*.py` and `*_test.py`
automatically; no registry exists.

Compare pytest summary counts using the same options.

Sibling paths use `mb_cmn.paths.repo_root()`, `repos_root()`, `sibling_repo(name)`, and the
required-sibling helpers, not cwd-relative parent paths or ad hoc `Path.parents` chains. The
local product directories do not require sibling clones.

## Writing tests: differential and lint-shaped only

Follow the common instruction body's “Tests are differential or lint-shaped” rule.
`doc/agent-planning-principles.md`, “Generated Outputs Are the Tests”, carries that rule's dated
evidence and rationale. The `ws_bot` tests remain a deliberate exception because a live
Wikisource edit is an outward-facing act with no regeneratable artifact. By Ben's decision of
2026-09-30, which the 2026-09-29 review's archived
[turn-01 update](https://github.com/bdenckla/MAM-basics/blob/be9c03961dcd970a620cd66b861b6aeaf0d58af3/doc/dual-agent-review-2026-09-29-turn-01-claude-update.md)
records under “Ben's decisions and approval of the package, 2026-09-30”, the five stub test ids of
`py/tests/test_wikisource_special_page_download.py` are a second exception. Its four
fault-injection ids hold five cases: each checks that a bad API response or bad local metadata
makes the special-page download raise, and all but the last, a manifest overwritten with "not
json", also check that no mirrored file changed, a property with no regeneratable artifact. Its
round trip is the only offline check of the download's reuse and forced refresh, neither of
which a regenerated mirror's diff would show.

## This is the only repository instruction body

Codex loads this file directly. Claude Code's minimal `CLAUDE.md` imports it. Retired Copilot and
disabled instruction files are historical records, not additional instruction sources.

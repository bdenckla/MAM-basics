"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const vm = require("node:vm");
const root = "/workspace/scratch/basics-bf302bb9-checkout/gh-pages/";
const cases = [
  ["post-stress-meteg.html", "post-stress-meteg/post-stress-meteg.html"],
  ["post-stress-meteg-post-silluq-1s17v5.html", "post-stress-meteg/post-stress-meteg-post-silluq-1s17v5.html"],
];
let checks = 0;
for (const [old, target] of cases) {
  const text = fs.readFileSync(root + old, "utf8");
  const scripts = [...text.matchAll(/<script>([\s\S]*?)<\/script>/g)];
  assert.equal(scripts.length, 1);
  const script = scripts[0][1];
  assert.equal(script.trim(), `location.replace(${JSON.stringify(target)} + location.search + location.hash);`);
  for (const search of ["", "?from=case&mode=two%20words"]) {
    for (const hash of ["", "#manuscript-images", "#%D7%90"]) {
      const destinations = [];
      const location = Object.freeze({search, hash, replace: value => destinations.push(value)});
      vm.runInNewContext(script, {location}, {timeout: 1000});
      assert.deepEqual(destinations, [target + search + hash]);
      checks++;
    }
  }
}
const result = {result: "PASS", redirect_stubs: 2, exact_script_executions: checks,
  limits: "The committed script runs in an isolated VM with only a location mock; no browser navigation or network."};
fs.writeFileSync("/workspace/scratch/basics-bf302bb9-artifacts/redirect-js-result.json", JSON.stringify(result, null, 2) + "\n");
process.stdout.write(JSON.stringify(result, null, 2) + "\n");

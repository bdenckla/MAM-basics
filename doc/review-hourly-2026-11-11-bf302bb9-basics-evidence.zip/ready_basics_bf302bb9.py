"""Record a known-not-executed setup failure and select the ready checkout stage."""

import json
from pathlib import Path
import subprocess

root = Path("/workspace/scratch/basics-bf302bb9-checkout")
out = Path("/workspace/scratch/basics-bf302bb9-artifacts")
assert not subprocess.check_output(
    ["git", "-C", str(root), "status", "--porcelain=v1", "-z"]
)
assert (root / "py/main_authored.py").is_file()
assert "can't open file" in (out / "gen-site.log").read_text()
config_path = Path("/workspace/scratch/basics-bf302bb9-config.json")
config = json.loads(config_path.read_text())
config["stages"]["gen-site-ready"] = config["stages"]["gen-site"]
config_path.write_text(json.dumps(config, indent=2) + "\n")
(out / "setup-recovery.json").write_text(
    json.dumps(
        dict(
            original="gen-site",
            exit_code=2,
            classification="reviewer checkout-order error, not product failure",
            reason="Python entrypoint absent while git worktree add was still populating; no generator executed.",
            recovery="Worktree command completed; exact HEAD and clean status verified before gen-site-ready.",
        ),
        indent=2,
    )
    + "\n"
)

import collections
import datetime
import hashlib
import json
import re
import subprocess
import unicodedata
from pathlib import Path

ROOT = Path('/workspace/MAM-basics')
OUT = Path('/workspace/scratch/review-hourly-20261030-0000')
BASE = '8339eb1352a745c5c2e16945a42b73b50aa30864'
SOURCE = '10708b47582fbb7f895f415683f852afe80787bc'
ORIGINAL = '926a6e785be4236673ac4a5c8c34afe63ed417f4'
BRANCH = 'review-hourly-20261030-0000-source'
HISTORY = 'py/ws/ws_bot_edit_history.md'


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write_json(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def codepoints(value):
    return [f'U+{ord(char):04X} {unicodedata.name(char, "UNNAMED")}' for char in value]


before = {'utc': now(), 'head': git('rev-parse', 'HEAD').decode().strip(), 'branch': git('branch', '--show-current').decode().strip(), 'status': git('status', '--porcelain').decode()}
assert before['head'] == ORIGINAL and before['branch'] == 'work' and not before['status'], before
write_json('checkout-before.json', before)
changed = [s.decode() for s in git('diff', '--name-only', '-z', BASE, SOURCE).split(b'\0') if s]
assert changed == [HISTORY], changed
assert git('rev-parse', SOURCE + '^').decode().strip() == BASE
old = git('show', BASE + ':' + HISTORY)
new = git('show', SOURCE + ':' + HISTORY)
old_lines = old.decode().splitlines(keepends=True)
new_lines = new.decode().splitlines(keepends=True)
assert len(old_lines) == len(new_lines)
line_changes = [(i + 1, a, b) for i, (a, b) in enumerate(zip(old_lines, new_lines)) if a != b]
assert len(line_changes) == 1 and line_changes[0][0] == 490
number, before_line, after_line = line_changes[0]
old_quote = next(q for q in re.findall(r'`([^`]+)`', before_line) if '+' in q)
new_quote = next(q for q in re.findall(r'`([^`]+)`', after_line) if '+' in q)
assert before_line.replace(old_quote, new_quote, 1) == after_line
assert collections.Counter(old_quote) == collections.Counter(new_quote)
dagesh = chr(0x05BC)
assert old_quote.replace(dagesh, '') == new_quote.replace(dagesh, '')
assert old_quote != new_quote
assert old_quote.count(dagesh) == new_quote.count(dagesh) == 3
expected = old_quote.replace(chr(0x05EA) + chr(0x05B4) + dagesh, chr(0x05EA) + dagesh + chr(0x05B4), 1)
expected = expected.replace(chr(0x05EA) + chr(0x05B0) + dagesh, chr(0x05EA) + dagesh + chr(0x05B0), 1)
assert expected == new_quote
assert chr(0x034F) not in old_quote and chr(0x034F) not in new_quote
raw_paths = ['in/mam-ws-bot-edits/note-deuteronomy-3-22-reversed-hataf-hiriq.json', 'in/mam-ws/A5-Deuter.json']
raw = []
for path in raw_paths:
    a = git('show', BASE + ':' + path)
    b = git('show', SOURCE + ':' + path)
    assert a == b and old_quote in b.decode()
    raw.append({'path': path, 'sha256_unchanged': hashlib.sha256(b).hexdigest(), 'raw_quote_preserved': True})
audit = {'utc': now(), 'base': BASE, 'source': SOURCE, 'changed_paths': changed, 'single_changed_line': number, 'old_quote_codepoints': codepoints(old_quote), 'new_quote_codepoints': codepoints(new_quote), 'only_two_tav_dagesh_vowel_swaps': True, 'all_other_bytes_preserved': True, 'same_letters_marks_non_dagesh_relative_order': True, 'raw_inputs': raw, 'all_other_tree_paths_unchanged': True, 'owner_disposition': 'Authored historical prose uses MAM-normal form; raw captures preserve exact order. Earlier scoped-exclusion suggestion is not required by this endpoint.'}
write_json('endpoint-audit.json', audit)
(OUT / 'endpoint.patch').write_bytes(git('diff', '--binary', BASE, SOURCE))
git('diff', '--check', BASE, SOURCE)
git('switch', '-c', BRANCH, SOURCE)
command = [str(ROOT / '.venv/bin/python'), 'py/main_test.py', 'py/tests/test_prose_mark_order.py', '-q']
start = now()
run = subprocess.run(command, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
end = now()
(OUT / 'prose-lint.log').write_text(run.stdout, encoding='utf-8')
result = {'source_commit': SOURCE, 'command': command, 'cwd': str(ROOT), 'started_utc': start, 'completed_utc': end, 'returncode': run.returncode, 'status_after': git('status', '--porcelain').decode()}
write_json('prose-lint.result.json', result)
print(json.dumps({'audit': audit, 'focused_check': result}, ensure_ascii=True, indent=2))
print(run.stdout)
assert run.returncode == 0 and not result['status_after']
assert '1 passed' in run.stdout and 'skipped' not in run.stdout

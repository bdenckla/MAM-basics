"""Static comparison of committed text/JSON only; no project import or runtime check."""
from collections import Counter
import difflib
import json
from pathlib import Path
import subprocess

repo = Path('/workspace/MAM-basics')
base = '438ee6f15d5a90572eca0f9268a3a5584ea127e8'
tip = '4aca1d2e13f31edecff8dda8fd339348cb3e9ddb'
out = Path('/workspace/scratch/review-hourly-20261028-cgj-refresh')

def git(*args):
    return subprocess.check_output(['git', '-C', str(repo), *args])

def data(rev, path):
    return git('show', rev + ':' + path).decode('utf-8')

def cgj_insertions(a, b):
    i, j, positions = 0, 0, []
    while i < len(a) and j < len(b):
        if a[i] == b[j]:
            i, j = i + 1, j + 1
        elif b[j] == '\u034f':
            positions.append(j)
            j += 1
        else:
            return None
    while j < len(b) and b[j] == '\u034f':
        positions.append(j)
        j += 1
    return positions if i == len(a) and j == len(b) else None

def changes(a, b, path=''):
    if a == b:
        return []
    if isinstance(a, dict) and isinstance(b, dict):
        return [d for k in sorted(a.keys() | b.keys()) for d in (
            [{'path': path + '/' + k, 'kind': 'membership'}] if k not in a or k not in b else changes(a[k], b[k], path + '/' + k))]
    if isinstance(a, list) and isinstance(b, list) and len(a) == len(b):
        return [d for i, (x, y) in enumerate(zip(a, b)) for d in changes(x, y, path + '/' + str(i))]
    if isinstance(a, str) and isinstance(b, str):
        insertions = cgj_insertions(a, b)
        return [{'path': path, 'kind': 'CGJ insertions only' if insertions is not None else 'other string change',
                 'cgj_insertions': len(insertions) if insertions is not None else None}]
    return [{'path': path, 'kind': 'other change'}]

paths = [p.decode() for p in git('diff', '--name-only', '-z', base, tip).split(b'\0') if p]
report = {'base': base, 'tip': tip, 'paths': len(paths), 'static_data_comparisons': {}, 'html_text_comparisons': {}, 'mirror_edits': {}}
json_prefixes = ('in/mam-ws/', 'MAM-parsed/plus/', 'out/mam-ws-', 'out/near-aleppo/plus/')
for path in paths:
    if path.endswith('.json') and path.startswith(json_prefixes):
        delta = changes(json.loads(data(base, path)), json.loads(data(tip, path)))
        report['static_data_comparisons'][path] = delta
    if path.startswith('gh-pages/') and path.endswith('.html') and 'change-log/' not in path:
        a, b = data(base, path), data(tip, path)
        direct = cgj_insertions(a, b)
        collapsed = cgj_insertions(''.join(a.split()), ''.join(b.split()))
        report['html_text_comparisons'][path] = {'net_CGJ': b.count('\u034f') - a.count('\u034f'),
            'CGJ_insertions_only': direct is not None, 'CGJ_only_after_whitespace_collapse': collapsed is not None}
    if path.endswith('.mediawiki'):
        a, b = data(base, path).splitlines(), data(tip, path).splitlines()
        parts = []
        for op, i, j, k, m in difflib.SequenceMatcher(a=a, b=b, autojunk=False).get_opcodes():
            if op == 'equal':
                continue
            left, right = '\n'.join(a[i:j]), '\n'.join(b[k:m])
            prefix = 0
            while prefix < min(len(left), len(right)) and left[prefix] == right[prefix]:
                prefix += 1
            suffix = 0
            while suffix < min(len(left)-prefix, len(right)-prefix) and left[len(left)-1-suffix] == right[len(right)-1-suffix]:
                suffix += 1
            parts.append({'operation': op, 'old': left[prefix:len(left)-suffix if suffix else None],
                          'new': right[prefix:len(right)-suffix if suffix else None]})
        report['mirror_edits'][path] = parts
ledger = 'in/near-aleppo/doc-note-review.json'
a, b = json.loads(data(base, ledger)), json.loads(data(tip, ledger))
old_rows = {row['id']: row for row in a['notes']}
new_rows = {row['id']: row for row in b['notes']}
report['review_ledger'] = {'old_rows': len(old_rows), 'new_rows': len(new_rows),
    'added_ids': sorted(new_rows.keys() - old_rows.keys()), 'removed_ids': sorted(old_rows.keys() - new_rows.keys()),
    'changed_rows': {key: changes(old_rows[key], new_rows[key]) for key in old_rows.keys() & new_rows.keys() if old_rows[key] != new_rows[key]}}
(out / 'static-delta.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k != 'mirror_edits'}, ensure_ascii=False, indent=2))
for name, parts in report['mirror_edits'].items():
    if name.endswith('ch5.mediawiki'):
        continue
    print(name)
    for part in parts:
        print(json.dumps(part, ensure_ascii=False)[:700])

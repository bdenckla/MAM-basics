"""Await each authorized focused command; stop on any failure or tracked write."""
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import time

source = Path('/workspace/review-hourly-20261028-cgj-refresh-source')
evidence = Path('/workspace/scratch/review-hourly-20261028-cgj-refresh/focused')
evidence.mkdir()
python = '/workspace/MAM-basics/.venv/bin/python'
expected = '4aca1d2e13f31edecff8dda8fd339348cb3e9ddb'
commands = [
    ('note-review', ['py/main_near_aleppo.py', '--check-note-review']),
    ('near-build', ['py/main_near_aleppo.py', '--build', '--check']),
    ('baked-note-replay', ['py/main_test.py', 'py/tests/test_near_aleppo_note_content.py::test_baked_clauses_match_reviews_and_preserve_current_pre_bake_book_content', '-q']),
    ('near-html', ['py/main_near_aleppo.py', '--html', '--check']),
    ('mwd-2kings', ['py/main_mam_with_doc.py', '--book39', '2Kings']),
    ('mwd-ezekiel', ['py/main_mam_with_doc.py', '--book39', 'Ezekiel']),
    ('change-log', ['py/main_diff.py', 'mpplus', '--check']),
    ('changed-python-black', ['-m', 'black', '--check', 'py/near_aleppo/phase5_readings.py']),
]
assert subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True, encoding='utf-8').strip() == expected
assert not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain=v1', '-z'])
for label, args in commands:
    started = datetime.now(timezone.utc).isoformat()
    clock = time.monotonic()
    print('START ' + label + ' ' + started, flush=True)
    process = subprocess.run([python, *args], cwd=source, capture_output=True, text=True, encoding='utf-8')
    status = subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain=v1', '-z'])
    record = {'name': label, 'source_commit': expected, 'cwd': str(source), 'command': [python, *args],
              'started_utc': started, 'completed_utc': datetime.now(timezone.utc).isoformat(),
              'seconds': round(time.monotonic() - clock, 3), 'exit_code': process.returncode,
              'tracked_status_after': status.decode()}
    (evidence / (label + '.log')).write_text(process.stdout + process.stderr, encoding='utf-8')
    (evidence / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print('END ' + json.dumps(record), flush=True)
    print((process.stdout + process.stderr)[-900:], flush=True)
    if process.returncode or status:
        (evidence / 'stopped.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
        if status:
            (evidence / (label + '.patch')).write_bytes(subprocess.check_output(['git', '-C', str(source), 'diff', '--binary']))
        raise SystemExit('Focused checks stopped; preserve and triage the recorded result')
print('All eight focused stages completed sequentially.', flush=True)

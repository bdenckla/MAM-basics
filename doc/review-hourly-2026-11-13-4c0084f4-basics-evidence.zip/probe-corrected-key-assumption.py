"""Independently reconcile this endpoint's public data, DOM, links and crops."""

from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
from difflib import SequenceMatcher
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import unquote, urlsplit

from lxml import html
from PIL import Image

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "head"
OUT = ROOT / "evidence"
BASE = "5287ba189e87bd90cb889fe7c578c8ada8c1f55b"
SOURCE = "4c0084f405351e36eb590180fa6a7f4a4f1ee063"
PARENT = "34a4db7c6a54d0df792709df8b15b3c350577b78"
sys.path.insert(0, str(TREE / "py"))  # Disposable review harness only.
from mb_cmn import uni_denorm
from accgram import printed_decalogue


def git(*args):
    return subprocess.check_output(["git", "-C", str(TREE), *args])


def save(name, value):
    (OUT / name).write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def text(node):
    return " ".join(node.text_content().split())


def qere(node):
    node = deepcopy(node)
    for ketiv in node.xpath('.//span[@class="mam-kq-k"]'):
        ketiv.drop_tree()
    return text(node).replace("[", "").replace("]", "")


cache = {}


def page(path):
    path = path.resolve()
    if path not in cache:
        cache[path] = html.fromstring(path.read_bytes())
    return cache[path]


def key(row):
    return tuple(row.get(k) for k in ("book", "chapter", "verse", "strand", "instance"))


def mark_letters(value, mark):
    return [
        m.group(1)
        for m in re.finditer(r"([\u05d0-\u05ea])([^\u05d0-\u05ea]*)", value)
        if mark in m.group(2)
    ]


assert git("rev-parse", "HEAD").decode().strip() == SOURCE
assert not git("status", "--porcelain=v1", "-z")
paths = [
    p for p in git("diff", "--name-only", "-z", BASE, SOURCE).decode().split("\0") if p
]
assert len(paths) == 11
identities = {}
for path in paths:
    raw = (TREE / path).read_bytes()
    assert raw == git("show", SOURCE + ":" + path)
    identities[path] = {
        "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "blob": git("rev-parse", SOURCE + ":" + path).decode().strip(),
    }
save("identities.json", identities)
(OUT / "endpoint-text.diff").write_bytes(
    git("diff", BASE, SOURCE, "--", ".", ":(exclude)gh-pages/stress-helpers/img/")
)
(OUT / "commits.txt").write_bytes(git("log", "--format=fuller", BASE + ".." + SOURCE))
git("diff", "--check", BASE, SOURCE)
source = printed_decalogue.load_source()
versions = {
    (v["book"], v["reading"], v["tradition"]): " ".join(v["chanted_verses"])
    for v in source["versions"]
}
result = {
    "base": BASE,
    "source": SOURCE,
    "paths": len(paths),
    "editions": {},
    "dec_source_revision": source["provenance"]["oldid"],
}
all_crops = set()
old_crops = set()
links = 0
external = set()
js_pages = []
for edition in ("koren", "simanim-tanakh"):
    relative = "in/stress-helpers/" + edition + ".json"
    data = json.loads((TREE / relative).read_bytes())
    old = json.loads(git("show", BASE + ":" + relative))
    old_by = {key(r): r for r in old["differences"]}
    by = {key(r): r for r in data["differences"]}
    assert len(by) == len(data["differences"])
    removed = [r for k, r in old_by.items() if k not in by]
    added = [r for k, r in by.items() if k not in old_by]
    for k in old_by.keys() & by.keys():
        assert {f: v for f, v in old_by[k].items() if f != "notes"} == {
            f: v for f, v in by[k].items() if f != "notes"
        }
    assert [(r["book"], r["chapter"], r["verse"]) for r in removed] == (
        [("Deuter", 5, 13)]
        if edition == "koren"
        else [("Exodus", 20, 2), ("Deuter", 5, 6)]
    )
    assert [(r["book"], r["chapter"], r["verse"]) for r in added] == (
        [
            ("Joshua", 24, 3),
            ("Judges", 18, 19),
            ("Zechariah", 1, 16),
            ("2Chronicles", 20, 27),
        ]
        if edition == "koren"
        else [("2Chronicles", 20, 27)]
    )
    dec_matches = []
    for r in removed:
        if edition == "koren":
            reading = uni_denorm.give_std_mark_order(
                versions[("dt", "taxton", "printed")]
            )
            skeleton = re.sub(r"[^\u05d0-\u05ea]", "", r["printed"])
            matched = [
                token
                for token in reading.split()
                if re.sub(r"[^\u05d0-\u05ea]", "", token) == skeleton
            ]
            assert len(matched) == 1
            literal_edits = [
                {
                    "operation": tag,
                    "source": matched[0][a:b],
                    "report": r["printed"][c:d],
                    "source_span": [a, b],
                    "report_span": [c, d],
                }
                for tag, a, b, c, d in SequenceMatcher(
                    None, matched[0], r["printed"], autojunk=False
                ).get_opcodes()
                if tag != "equal"
            ]
            assert len(literal_edits) == 1
            assert literal_edits[0]["operation"] == "insert"
            assert literal_edits[0]["source"] == ""
            assert literal_edits[0]["report"] == "\N{HEBREW POINT METEG}"
            assert (
                mark_letters(matched[0], "\N{HEBREW ACCENT REVIA}")
                == mark_letters(r["printed"], "\N{HEBREW ACCENT REVIA}")
                == ["\N{HEBREW LETTER TAV}"]
            )
            assert (
                mark_letters(matched[0], "\N{HEBREW ACCENT TELISHA GEDOLA}")
                == mark_letters(r["printed"], "\N{HEBREW ACCENT TELISHA GEDOLA}")
                == []
            )
            dec_matches.append(
                {
                    "reference": "Deuter 5:13",
                    "matching_strand": "printed taxton",
                    "former_report_form": r["printed"],
                    "mirrored_form": matched[0],
                    "literal_difference": literal_edits,
                    "scope": "Same revia on tav and no telisha gedolah helper. Former printed form has one additional meteg on second vav; no claim of full-mark identity.",
                }
            )
        else:
            book = "ex" if r["book"] == "Exodus" else "dt"
            reading = uni_denorm.give_std_mark_order(
                versions[(book, "elyon", "manuscript")]
            )
            skeleton = re.sub(r"[^\u05d0-\u05ea]", "", r["printed"])
            matched = [
                token
                for token in reading.split()
                if re.sub(r"[^\u05d0-\u05ea]", "", token) == skeleton
            ]
            assert len(matched) == 1
            assert mark_letters(matched[0], "\N{HEBREW ACCENT TEVIR}") == [
                "\N{HEBREW LETTER TAV}"
            ]
            dec_matches.append(
                {
                    "reference": [r["book"], r["chapter"], r["verse"]],
                    "matching_strand": "manuscript elyon",
                    "form": matched[0],
                }
            )
    target = TREE / "gh-pages/stress-helpers" / (edition + ".html")
    doc = page(target)
    rows = doc.xpath('//table[@id="observations"]/tbody/tr')
    assert len(rows) == len(data["differences"])
    headings = doc.xpath('//table[@id="observations"]/thead/tr/th')
    assert [text(h) for h in headings] == ["", "Verse", "Difference", "Scan crop"]
    assert doc.xpath('//*[@id="hebrew-size"]/@value') == ["30"]
    assert len(doc.xpath('//*[@class="scan" and @hidden]')) == len(rows) + 1
    ids = doc.xpath("//*[@id]/@id")
    assert len(ids) == len(set(ids))
    category = Counter()
    for r, row in zip(data["differences"], rows):
        assert len(row) == 4 and row[0].get("dir") == "rtl"
        assert row.get("data-outcome") == r["category"]
        category[r["category"]] += 1
        assert row.xpath('.//span[@class="hebrew"]/text()') == [r["mam"], r["printed"]]
        assert row.xpath('.//span[@class="edition"]/text()') == [
            "MAM",
            "Koren" if edition == "koren" else "SimTan",
        ]
        assert row.xpath('./th/span[@class="source"]/@title') == [r["scan"]]
        assert text(row.xpath('./th/span[@class="source"]')[0]) == "p. " + str(
            r["page"]
        )
        assert row.xpath(".//img/@src") == r["crops"]
        assert r["mam"] != r["printed"]
        assert all(uni_denorm.has_std_mark_order(r[f]) for f in ("mam", "printed"))
        loc = urlsplit(r["verse_href"])
        anchor = page(target.parent / unquote(loc.path)).xpath(
            "//*[@id=$ident]", ident=loc.fragment
        )
        assert len(anchor) == 1
        assert " ".join(r["mam"].split()) in qere(anchor[0].getparent()), (
            edition,
            key(r),
            r["mam"],
        )
        assert "Phonetic MAM" not in " ".join(n["text"] for n in r.get("notes", []))
        assert not any("phonetic-mam" in n.get("href", "") for n in r.get("notes", []))
        if r["category"] == "redundant-edition":
            assert r["mam"].count("\N{HEBREW ACCENT PASHTA}") == 1
            assert r["printed"].count("\N{HEBREW ACCENT PASHTA}") == 2
            assert re.search(
                "[\u05d0-\u05ea][\u0591-\u05c9]*\N{HEBREW POINT SHEVA}[\u0591-\u05c9]*[\u05d0-\u05ea][\u0591-\u05c9]*\N{HEBREW POINT SHEVA}[\u0591-\u05c9]*$",
                r["mam"],
            )
        all_crops.update(r["crops"])
    for r in old["differences"]:
        old_crops.update(r["crops"])
    for node in doc.xpath("//*[@href or @src]"):
        for attr in ("href", "src"):
            value = node.get(attr)
            if value is None:
                continue
            loc = urlsplit(value)
            if loc.scheme or loc.netloc:
                external.add(value)
                continue
            dest = (target.parent / unquote(loc.path)).resolve() if loc.path else target
            assert dest.is_relative_to(TREE / "gh-pages") and dest.is_file(), value
            if loc.fragment:
                assert page(dest).xpath(
                    "//*[@id=$ident or @name=$ident]", ident=unquote(loc.fragment)
                ), value
            links += 1
    result["editions"][edition] = {
        "rows": len(rows),
        "categories": dict(category),
        "added": [list(key(r)) for r in added],
        "removed": [list(key(r)) for r in removed],
        "removed_matching_strands": dec_matches,
        "all_mam_forms_in_cited_public_body": True,
    }
    js_pages.append(
        {
            "edition": edition,
            "rows": [
                {"outcome": row.get("data-outcome"), "cells": [text(c) for c in row]}
                for row in rows
            ],
            "queries": [r["mam"] for r in data["differences"]]
            + ["p. " + str(r["page"]) for r in added],
        }
    )
pngs = {}
for p in sorted((TREE / "gh-pages/stress-helpers/img").glob("*.png")):
    with Image.open(p) as img:
        assert img.format == "PNG"
        pngs["img/" + p.name] = {
            "width": img.width,
            "height": img.height,
            "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
        }
        img.verify()
unreferenced = sorted(pngs.keys() - all_crops)
assert set(unreferenced) == old_crops - all_crops
assert len(pngs) == 56 and len(all_crops) == 52 and len(unreferenced) == 4
# The Chronicles claim compares two public forms; an error judgment remains owner research.
kor = json.loads((TREE / "in/stress-helpers/koren.json").read_bytes())
chron = next(r for r in kor["differences"] if r["book"] == "2Chronicles")
loc = urlsplit(chron["notes"][1]["href"])
gen = page(TREE / "gh-pages/stress-helpers" / loc.path).xpath(
    "//*[@id=$ident]", ident=loc.fragment
)[0]
assert chron["printed"] in qere(gen.getparent())
assert mark_letters(chron["mam"], "\N{HEBREW ACCENT TELISHA GEDOLA}") == ["ו", "ב"]
assert mark_letters(chron["printed"], "\N{HEBREW ACCENT TELISHA GEDOLA}") == ["ו", "ש"]
assert re.sub(r"[\u0591-\u05af]", "", chron["mam"]) == re.sub(
    r"[\u0591-\u05af]", "", chron["printed"]
)
result.update(
    pngs=len(pngs),
    linked_crops=len(all_crops),
    retained_unreferenced_crops=unreferenced,
    local_link_attributes=links,
    external_links_unfetched=sorted(external),
    chronicles_comparison="Same letters/vowels; helper on bet in Chronicles versus shin at Genesis 14:7; likely-error interpretation is owner-attributed.",
    scan_completeness_claim="10,223 owner-attributed checks; not independently repeated.",
)
save("png-integrity.json", pngs)
save("js-input.json", js_pages)
save("probe-result.json", result)
workflow = {}
for ref in (PARENT, SOURCE):
    files = [
        p
        for p in git("ls-tree", "-r", "--name-only", "-z", ref, "--", ".github")
        .decode()
        .split("\0")
        if p
    ]
    assert files == [".github/workflows/pages.yml"]
    blob = git("rev-parse", ref + ":.github/workflows/pages.yml").decode().strip()
    assert blob == "18ceb19405424710bda47d9a38c470cc2ed9c385"
    workflow[ref] = {
        "files": files,
        "blob": blob,
        "text": git("show", ref + ":.github/workflows/pages.yml").decode(),
    }
status = git("show", PARENT + ":doc/review-trial-status.md").decode()
assert (
    "Hourly prose screen, 2026-11-13 19:00 UTC" in status
    and "Hourly presentation screen, 2026-11-13 18:00 UTC" in status
)
for anchor in (
    "210affe3ac2931473bead0de839be0de08309e3d",
    "9ed47c6e8999ecaf56031e9b3f524bee6e01507a",
    "3030161007bc393f554cf0c95cf819ed4d81a93c",
):
    assert anchor in status
save(
    "workflow-and-lineage.json",
    {
        "observed_utc": datetime.now(timezone.utc).isoformat(),
        "parent": PARENT,
        "workflow": workflow,
        "reconciled_status": "19:00 and 18:00 screens preserve 17:00, nightly, Windows supplement, global anchors and all historical pending gaps.",
    },
)
print(json.dumps(result, ensure_ascii=False, indent=2))

"""Prepare a three-path receipt on the exact prior receipt parent."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "head"
OUT = ROOT / "evidence"
BASE = "5287ba189e87bd90cb889fe7c578c8ada8c1f55b"
SOURCE = "4c0084f405351e36eb590180fa6a7f4a4f1ee063"
PARENT = "34a4db7c6a54d0df792709df8b15b3c350577b78"
NAME = "review-hourly-2026-11-13-4c0084f4-basics"
BRANCH = "review-hourly-20261113-4c0084f4-basics-receipts"


def git(*args, tree=TREE):
    return subprocess.check_output(["git", "-C", str(tree), *args])


def dump(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


assert git("rev-parse", "HEAD").decode().strip() == SOURCE
assert not git("status", "--porcelain=v1", "-z")
assert not git("ls-remote", "origin", "refs/heads/" + BRANCH)
assert git("rev-list", "--count", BASE + ".." + SOURCE).strip() == b"5"
for ancestor in (
    "3e814ef2e793a5106ce198e0d4c7cbd637a642f1",
    "8b521eba4a7d87b649da69223431ed332047cca8",
    "3030161007bc393f554cf0c95cf819ed4d81a93c",
):
    subprocess.run(
        ["git", "-C", str(TREE), "merge-base", "--is-ancestor", ancestor, PARENT],
        check=True,
    )
probe = json.loads((OUT / "probe-result.json").read_bytes())
javascript = json.loads((OUT / "js-result.json").read_bytes())
assert [v["rows"] for v in probe["editions"].values()] == [34, 18]
assert (
    probe["pngs"] == 56
    and probe["linked_crops"] == 52
    and probe["local_link_attributes"] == 183
)
assert sum(v["query_category_combinations"] for v in javascript["results"]) == 1030
names = (
    "black",
    "gen-site",
    "tests",
    "html",
    "probes",
    "probes-corrected",
    "probes-final",
    "javascript",
)
stages = [json.loads((OUT / (name + ".json")).read_bytes()) for name in names]
assert [s["exit"] for s in stages] == [0, 0, 0, 1, 1, 1, 0, 0]
assert all(
    not (OUT / (name + ".diff")).read_bytes()
    and not (OUT / (name + ".status")).read_bytes()
    for name in names
)
assert "37 passed in 40.23s" in (OUT / "tests.log").read_text(encoding="utf-8")
orphan_log = (OUT / "html.log").read_text(encoding="utf-8")
assert "Found 4 issue(s)." in orphan_log
assert all(
    "orphan image: " + p in orphan_log for p in probe["retained_unreferenced_crops"]
)
unchanged = {}
for path in (
    "gh-pages/stress-helpers/controls.js",
    "MAM-parsed",
    "MAM-with-doc",
    "gh-pages/MAM-with-doc",
):
    before = git("rev-parse", BASE + ":" + path).decode().strip()
    after = git("rev-parse", SOURCE + ":" + path).decode().strip()
    assert before == after
    unchanged[path] = after
stopped_path = OUT / "gen-site-initial-stopped.json"
stopped = json.loads(stopped_path.read_bytes())
stopped["started_after_utc"] = stopped.pop("started_utc")
stopped["start_bound_source"] = (
    "Preceding Black completion; exact child start/elapsed time was not captured before SIGTERM."
)
stopped["runner_exit"] = 143
stopped["owned_pids"] = [5573, 5637]
stopped["child_after_stop"] = (
    "PID 5637 observed defunct (Z, PPID 1); no running command remains."
)
stopped_path.write_bytes(dump(stopped))
visuals = [
    {
        "crop": "koren-2chronicles-20-27-FD-2C-346-1609-1.png",
        "observation": "Visible telisha gedolah helper is on shin, agreeing with the supplied printed form.",
    },
    {
        "crop": "simanim-tanakh-2chronicles-20-27-FD-2C-1432-1609-1.png",
        "observation": "Visible telisha gedolah helper is on shin, agreeing with the supplied printed form.",
    },
    {
        "crop": "koren-joshua-24-3-B1-Js-040-526-1.png",
        "observation": "Initial telisha gedolah and helper on het, plus meteg on initial vav, agree with the supplied form.",
    },
    {
        "crop": "koren-judges-18-19-B2-Ju-077-573-1.png",
        "observation": "Final telisha qetanna and meteg on yod, with no helper on yod, agree with the supplied form.",
    },
    {
        "crop": "koren-zechariah-1-16-CK-Zc-574-13074-1.png",
        "observation": "Pashta helper on shin agrees with the supplied form.",
    },
]
disposition = {
    "result": "No consequential introduced defect established; no product repair.",
    "screened": {
        "base": BASE,
        "source": SOURCE,
        "commits": 5,
        "paths": 11,
        "insertions": 217,
        "deletions": 215,
    },
    "scope": "Removed three nonmatching-strand Decalogue comparisons, added five rows across four verses, replaced derivative stress citations with underlying MAM readings, and simplified the two tables.",
    "html_exit_1": {
        "count": 4,
        "paths": probe["retained_unreferenced_crops"],
        "disposition": "Exactly the four still-tracked source crops for the three intentionally removed rows. Harmless retained evidence; no deletion or product repair. 151 informational CSS references are not fatal. HTML is not reported clean.",
    },
    "scratch_failures": [
        "The initial probe assumed full identity between the removed Koren compound and the matching mirrored strand. Exact comparison shows one additional meteg on the second vav in Koren. Same revia on tav and no telisha gedolah helper support the removal's narrower scope; no full-mark identity claimed.",
        "The next probe used verse/strand/instance alone as row identity. Two Simanim comparisons share those values; full MAM/printed forms distinguish them. Original scripts/logs retained, product unchanged.",
    ],
    "invocation_scope_correction": stopped,
    "visual_observations": visuals,
    "visual_limit": "Only the five supplied new crops were viewed. No browser rendering, complete original-page collation, full research catalogue/OCR verification or source acquisition.",
    "research_limits": "10,223 scan checks remain owner-attributed and were not repeated. The public Chronicles/Genesis mark difference is reproduced; likely-MAM-error classification remains owner editorial research. No underlying MAM correction or rights/publication decision.",
    "unchanged_blob_or_tree_ids": unchanged,
    "overall_reviewed": "210affe3ac2931473bead0de839be0de08309e3d",
    "latest_broad_tested": "9ed47c6e8999ecaf56031e9b3f524bee6e01507a",
    "receipt_parent": PARENT,
    "preservation": "19:00/18:00/17:00 receipts, November 13 nightly and Windows supplement 3030161007bc393f554cf0c95cf819ed4d81a93c, every older pending gap, immutable receipt and Taamey D corpus/baseline limitation retained. Cross-machine ownership remains unverified.",
}
(OUT / "disposition.json").write_bytes(dump(disposition))
completed = {
    "state": "completed",
    "source": SOURCE,
    "completed_utc": datetime.now(timezone.utc).isoformat(),
    "stages": stages,
    "stopped_initial_invocation": stopped,
    "disposition": "No consequential introduced defect; four triaged retained orphan crops and two corrected scratch assumptions. No product changes.",
}
(ROOT / "stage.json").write_bytes(dump(completed))
(OUT / "stage.json").write_bytes(dump(completed))
payload = {p.name: p.read_bytes() for p in OUT.iterdir() if p.is_file()}
for name in (
    "run.py",
    "probe.py",
    "js-probe.cjs",
    "inspect_inputs.py",
    "diagnose_decalogue.py",
    "recover_generation.py",
    "record_diagnostics.py",
    "prepare.py",
    "publish.py",
):
    payload["checkers/" + name] = (ROOT / name).read_bytes()
assert not any(name.endswith(".png") for name in payload)
payload["manifest.json"] = dump(
    {
        name: {"bytes": len(raw), "sha256": sha(raw)}
        for name, raw in sorted(payload.items())
    }
)
receipts = ROOT / "receipts"
assert not receipts.exists()
subprocess.run(
    [
        "git",
        "-C",
        "/workspace/MAM-basics",
        "worktree",
        "add",
        "-b",
        BRANCH,
        str(receipts),
        PARENT,
    ],
    check=True,
    capture_output=True,
)
assert git("rev-parse", "--show-toplevel", tree=receipts).decode().strip() == str(
    receipts
)
assert git("rev-parse", "HEAD", tree=receipts).decode().strip() == PARENT
assert git("branch", "--show-current", tree=receipts).decode().strip() == BRANCH
assert not git("status", "--porcelain=v1", "-z", tree=receipts)
archive = receipts / "doc" / (NAME + "-evidence.zip")
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as z:
    for name, raw in sorted(payload.items()):
        z.writestr(name, raw)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist()))
    for name, item in json.loads(z.read("manifest.json")).items():
        assert (
            len(z.read(name)) == item["bytes"] and sha(z.read(name)) == item["sha256"]
        )
stage_rows = "\n".join(
    f"| {s['stage']} | {s['exit']} | {s['seconds']} |" for s in stages
)
commands = "\n".join(shlex.join(s["command"]) for s in stages[:4])
orphan_lines = "\n".join("- `" + p + "`" for p in probe["retained_unreferenced_crops"])
report = f"""# Bounded Basics screen, November 13, 2026, 20:00 UTC cycle

State: completed 2026-11-13; focused technical review, no product repair

Frozen endpoint `{BASE}` → `{SOURCE}`: **five commits / 11 paths**, 217 insertions / 215 deletions. The complete endpoint changes remove three comparisons against nonmatching Decalogue strands, add five rows across four verses with five crops, cite underlying MAM readings instead of their Phonetic MAM derivative, and simplify the two tables. No consequential introduced defect was established; no product repair. Receipt parent: `{PARENT}`, reconciling the 19:00 and 18:00 screens after the 17:00 receipt.

Actual maintained `gen-site --trust-surveys` reproduces all tracked outputs exactly. Changed-source Black passes and **37 selected tests pass** through `py/main_test.py -q -ra`: the three relevant Decalogue modules and six site/style/prose modules named in the evidence. Commands ran sequentially from the detached exact source, using the home interpreter:

```text
{commands}
```

The HTML checker **exits 1**, reporting precisely the four retained crops of the three removed rows; 151 CSS-class references are informational. These existing source assets are harmless retained evidence and were not deleted. No HTML-clean claim is made. The four reports are:

{orphan_lines}

Independent checks pass for **52 displayed pairs** (34 Koren / 18 Simanim), all **52 underlying MAM body/qere readings**, exact page/scan labels and four-cell rows, all **183** local link/asset attributes and fragments, and integrity of **56 PNGs** (52 linked, the four above retained). Existing rows preserve their forms, categories, page/scan/crop fields; only notes change. The 11/13 redundant-helper claims match displayed double pashta and double-sheva endings. The five new supplied crops were viewed; their visible helper placements agree with the printed forms. No crops are copied into the evidence archive.

The removed Simanim rows agree with tevir on tav in the matching manuscript-tradition עליון. The removed Koren compound agrees with revia on tav and absence of a telisha gedolah helper in printed-tradition תחתון, but Koren has **one additional meteg on the second vav**. Both literal forms and that exact difference are retained; full-mark identity is not claimed. The Chronicles/Genesis comparison reproduces the same letters/vowels with the helper on bet versus shin. The “likely MAM error” interpretation and **10,223 scan-check** completion claim remain owner-attributed research, not independently established here; underlying MAM is unchanged.

The unchanged actual `controls.js` passes **1,030 query/category combinations** on the current four-cell DOM data, plus range/reset and four image toggles per page, in a minimal Node model. This verifies those behaviors only; it supplies no browser/layout/accessibility-tree/font result.

| Stage (full arguments and UTC timestamps in evidence JSON) | Exit | Seconds |
| --- | ---: | ---: |
{stage_rows}

Two scratch assumptions failed before the final passing probe: exact Koren full-mark identity, and using verse/strand/instance alone as comparison identity. Their original scripts, logs and empty diffs/statuses are retained; the corrected probe records the literal meteg difference and includes both displayed forms in identity. An initial `gen-site` without `--trust-surveys` unnecessarily began the unrelated post-stress survey and was stopped with SIGTERM (owned runner exit 143; child observed defunct). Partial output/diff/status and the exact invocation are retained; no completed survey result is claimed. The corrected bounded generation then passed. These are reviewer invocation/fixture corrections, not product failures. Every completed stage leaves empty tracked/untracked output diffs/statuses.

Overall reviewed-through remains `210affe3ac2931473bead0de839be0de08309e3d`; broad-tested remains `9ed47c6e8999ecaf56031e9b3f524bee6e01507a`. All historic pending windows, finished receipts, November 13 nightly/Windows supplement `3030161007bc393f554cf0c95cf819ed4d81a93c`, and Taamey D corpus/baseline limitations remain. Local admission was fresh; cross-machine ownership remains unverified. No broad/nightly rerun, original-source acquisition, Private or hbofonts work, editorial/rights change, main/shared integration, deployment/dispatch or schedule change.

[Evidence]({archive.name}): **{archive.stat().st_size} bytes**, SHA-256 `{sha(archive.read_bytes())}`; local CRC and all payload hashes verified. Only the isolated three-path receipt branch is prepared for normal publication; source and parent retain the sole manual-dispatch Pages workflow. Exact remote verification and owned-worktree cleanup/slot release are closeout steps, recorded after they occur.
"""
(receipts / "doc" / (NAME + ".md")).write_text(report, encoding="utf-8", newline="\n")
status_path = receipts / "doc/review-trial-status.md"
status = status_path.read_text(encoding="utf-8")
assert status.count("## Hourly prose screen, 2026-11-13 19:00 UTC") == 1
section = f"""## Bounded screen, 2026-11-13 20:00 UTC cycle, 4c0084f4

Examined `{BASE}` → `{SOURCE}`: five commits / 11 paths. Removed nonmatching-strand comparisons, five new rows/five crops, direct-MAM citations and table changes checked. No consequential introduced defect or product repair. gen-site --trust-surveys is exact; 37 selected tests and changed-source Black pass. HTML exits 1 for four retained crops belonging to removed rows; no HTML-clean claim. Independent checks reconcile 52 pairs/all cited MAM forms, 56 PNGs/52 linked crops and 183 local attributes; 1,030 actual-script Node filter combinations pass. Five supplied new crops viewed. Two scratch assumptions and an initial overbroad generator invocation corrected with original evidence retained. Koren's residual meteg difference is explicit; 10,223-check completeness and likely Chronicles error remain owner-attributed research. [Receipt]({NAME}.md), [evidence]({archive.name}).

Receipt lineage continues from `{PARENT}` and preserves the 19:00/18:00/17:00 receipts plus November 13 nightly/Windows supplement. Overall reviewed-through `210affe3ac2931473bead0de839be0de08309e3d`, broad-tested `9ed47c6e8999ecaf56031e9b3f524bee6e01507a`, all historical pending gaps, finished records and source/browser/editorial/Taamey D limitations remain unchanged. Isolated receipt publication only; no main/shared integration or dispatch. No Private or hbofonts work.

"""
status = status.replace(
    "## Hourly prose screen, 2026-11-13 19:00 UTC",
    section + "## Hourly prose screen, 2026-11-13 19:00 UTC",
    1,
)
status = status.replace(
    "| Latest bounded screen 3badbc72 |", "| Previous bounded screen 3badbc72 |", 1
).replace(
    "| Latest focused evidence 3badbc72 |", "| Previous focused evidence 3badbc72 |", 1
)
table_anchor = "| Anchor | Commit/result |\n| --- | --- |\n"
new_rows = f"| Latest bounded screen 4c0084f4 | `{BASE}` → `{SOURCE}`; five commits / 11 paths. No consequential introduced defect or product repair. Research and all earlier gaps retained. [Receipt]({NAME}.md). |\n| Latest focused evidence 4c0084f4 | gen-site exact, 37 selected tests/changed-source Black pass. HTML exit 1: four retained orphan crops. Independent 52-pair/56-PNG/183-link checks and 1,030 Node combinations pass; five new crops viewed. Scratch corrections, literal Koren meteg difference and owner-attributed research limits retained. [Evidence]({archive.name}). |\n"
assert status.count(table_anchor) == 1
status = status.replace(table_anchor, table_anchor + new_rows, 1)
status_path.write_text(status, encoding="utf-8", newline="\n")
paths = sorted(
    [
        "doc/" + NAME + ".md",
        "doc/" + NAME + "-evidence.zip",
        "doc/review-trial-status.md",
    ]
)
actual = set(
    p for p in git("diff", "--name-only", "-z", tree=receipts).decode().split("\0") if p
) | set(
    p
    for p in git("ls-files", "--others", "--exclude-standard", "-z", tree=receipts)
    .decode()
    .split("\0")
    if p
)
assert actual == set(paths)
git("diff", "--check", tree=receipts)
prepared = {
    "branch": BRANCH,
    "parent": PARENT,
    "source": SOURCE,
    "paths": paths,
    "archive": {
        "path": archive.name,
        "bytes": archive.stat().st_size,
        "sha256": sha(archive.read_bytes()),
        "payload_files": len(payload) - 1,
    },
    "prepared_utc": datetime.now(timezone.utc).isoformat(),
}
(ROOT / "publication-prepared.json").write_bytes(dump(prepared))
print(json.dumps(prepared, indent=2))

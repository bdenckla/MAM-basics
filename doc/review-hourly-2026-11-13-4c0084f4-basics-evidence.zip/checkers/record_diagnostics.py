"""Retain preparatory read errors and the owned invocation-scope interruption."""

import json
from pathlib import Path

root = Path(__file__).resolve().parent
out = root / "evidence"
old = (root / "run.py").read_text(encoding="utf-8")
assert old.count('"--trust-surveys"') == 1
(out / "run-initial.py").write_text(
    old.replace(', "--trust-surveys"', "", 1), encoding="utf-8", newline="\n"
)
diagnostics = [
    {
        "action": "git show 34a4db7c6a54d0df792709df8b15b3c350577b78:doc/review-hourly-2026-11-13-5287ba18-basics.md",
        "exit": 128,
        "error": "fatal: path 'doc/review-hourly-2026-11-13-5287ba18-basics.md' does not exist in '34a4db7c6a54d0df792709df8b15b3c350577b78'",
        "disposition": "19:00 and 18:00 receipts are sections in the maintained status, which was read exactly. No standalone receipt assumed in publication.",
    },
    {
        "action": "cat py/tests/test_simanim_decalogue.py",
        "exit": 1,
        "error": "cat: py/tests/test_simanim_decalogue.py: No such file or directory",
        "disposition": "rg --files located actual test_printed_decalogue_simanim.py before maintained checks were run.",
    },
    {
        "action": "rg --files /workspace/scratch/basics-3badbc72 | rg '\\.js$'",
        "exit": 1,
        "error": "No matching .js suffix; available harness is js-probe.cjs.",
        "disposition": "Read actual .cjs harness; data and assertions are dynamic for current DOM. No product script changes.",
    },
    {
        "action": "apply_patch comparison-key edit",
        "executed": False,
        "error": "apply_patch verification failed: Failed to find expected lines (Black had collapsed key expression to one line)",
        "disposition": "Read exact current lines, then applied the intended comparison-identity correction. Original script retained as probe-corrected-key-assumption.py.",
    },
    {
        "action": "kill -TERM 5573 5637",
        "exit": 0,
        "targets": {
            "5573": "Owned initial run.py",
            "5637": "Owned initial py/main_authored.py gen-site child",
        },
        "runner_exit": 143,
        "child_observation": "5637 (python) Z, PPID 1: defunct after SIGTERM; no executable job remains. Corrected gen-site completed exactly in 5.441252 seconds.",
        "source_diff_and_status": "Both empty after stopped invocation; preserved separately. Scope correction, not product failure.",
    },
]
(out / "preparatory-diagnostics.json").write_text(
    json.dumps(diagnostics, indent=2) + "\n", encoding="utf-8", newline="\n"
)
print(json.dumps({"retained_diagnostics": len(diagnostics)}))

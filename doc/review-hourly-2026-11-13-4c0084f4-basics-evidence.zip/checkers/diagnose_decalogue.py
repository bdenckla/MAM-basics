"""Show exact codepoint differences after the failed reviewer string assumption."""

import json
from pathlib import Path
import re
import subprocess
import sys

root = Path(__file__).resolve().parent
tree = root / "head"
sys.path.insert(0, str(tree / "py"))
from mb_cmn import uni_denorm
from accgram import printed_decalogue

data = printed_decalogue.load_source()
version = next(
    v
    for v in data["versions"]
    if (v["book"], v["reading"], v["tradition"]) == ("dt", "taxton", "printed")
)
old = json.loads(
    subprocess.check_output(
        [
            "git",
            "-C",
            str(tree),
            "show",
            "5287ba189e87bd90cb889fe7c578c8ada8c1f55b:in/stress-helpers/koren.json",
        ]
    )
)
removed = next(
    r for r in old["differences"] if r["book"] == "Deuter" and r["chapter"] == 5
)
reading = uni_denorm.give_std_mark_order(" ".join(version["chanted_verses"]))
skeleton = lambda s: re.sub(r"[^\u05d0-\u05ea]", "", s)
target = skeleton(removed["printed"])
tokens = [t for t in reading.split() if skeleton(t) == target]
out = {
    "former_report_printed": removed["printed"],
    "matching_mirrored_tokens": tokens,
    "former_report_codepoints": [f"U+{ord(c):04X}" for c in removed["printed"]],
    "matching_tokens_codepoints": [[f"U+{ord(c):04X}" for c in t] for t in tokens],
}
(root / "evidence/decalogue-diagnosis.json").write_text(
    json.dumps(out, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n"
)
print(json.dumps(out, ensure_ascii=False, indent=2))

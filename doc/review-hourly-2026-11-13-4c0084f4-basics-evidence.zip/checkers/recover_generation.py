"""Retain the stopped command, then select bounded tracked-survey generation."""

from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
out = root / "evidence"
tree = root / "head"
assert not (out / "gen-site.json").exists()
record = {
    "stage": "gen-site-initial-stopped",
    "command": [
        "/workspace/MAM-basics/.venv/bin/python",
        "-B",
        "py/main_authored.py",
        "gen-site",
    ],
    "cwd": str(tree),
    "started_utc": "2026-11-13T20:17:27.435665+00:00",
    "stopped_utc": datetime.now(timezone.utc).isoformat(),
    "result": "Owned runner and gen-site child terminated with SIGTERM before completion; initial command unnecessarily recomputed the unrelated post-stress survey. No result claimed.",
    "correction": "Run actual maintained gen-site with --trust-surveys to consume its tracked survey.",
}
(out / "gen-site.log").rename(out / "gen-site-initial-stopped.log")
(out / "gen-site-initial-stopped.json").write_text(
    json.dumps(record, indent=2) + "\n", encoding="utf-8", newline="\n"
)
for label, args in [
    ("diff", ["diff", "--binary"]),
    ("status", ["status", "--porcelain=v1", "-z"]),
]:
    raw = subprocess.check_output(["git", "-C", str(tree), *args])
    (out / ("gen-site-initial-stopped." + label)).write_bytes(raw)
    assert not raw
run = root / "run.py"
old = run.read_text(encoding="utf-8")
assert '"gen-site"]' in old
new = old.replace('"gen-site"]', '"gen-site", "--trust-surveys"]', 1)
new = new.replace('        "black",\n', '        "black",\n', 1)
run.write_text(new, encoding="utf-8", newline="\n")
print(json.dumps(record, indent=2))

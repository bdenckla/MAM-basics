"""Canonicalize the uncommitted status against its parent and refresh evidence."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

root = Path(__file__).resolve().parent
tree = root / "receipts"
out = root / "evidence"
name = "review-hourly-2026-11-13-4c0084f4-basics"
parent = "34a4db7c6a54d0df792709df8b15b3c350577b78"


def git(*args):
    return subprocess.check_output(["git", "-C", str(tree), *args])


def dump(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


assert git("rev-parse", "HEAD").decode().strip() == parent
assert (
    git("branch", "--show-current").decode().strip()
    == "review-hourly-20261113-4c0084f4-basics-receipts"
)
status_path = tree / "doc/review-trial-status.md"
current = status_path.read_text(encoding="utf-8")
baseline = git("show", parent + ":doc/review-trial-status.md").decode("utf-8")
header = "## Bounded screen, 2026-11-13 20:00 UTC cycle, 4c0084f4"
next_header = "## Hourly prose screen, 2026-11-13 19:00 UTC"
assert current.count(header) == 2
(root / "status-draft-duplicate-sections.md").write_text(
    current, encoding="utf-8", newline="\n"
)
section = current[current.rindex(header) : current.index(next_header)]
rows = [
    line
    for line in current.splitlines(keepends=True)
    if line.startswith(
        ("| Latest bounded screen 4c0084f4 |", "| Latest focused evidence 4c0084f4 |")
    )
]
assert len(rows) == 4 and rows[:2] == rows[2:]
table = "| Anchor | Commit/result |\n| --- | --- |\n"
final = baseline.replace(next_header, section + next_header, 1)
final = final.replace(
    "| Latest bounded screen 3badbc72 |", "| Previous bounded screen 3badbc72 |", 1
).replace(
    "| Latest focused evidence 3badbc72 |", "| Previous focused evidence 3badbc72 |", 1
)
final = final.replace(table, table + "".join(rows[:2]), 1)
assert final.count(header) == 1
assert final.count("| Latest bounded screen 4c0084f4 |") == 1
assert final.count("| Latest focused evidence 4c0084f4 |") == 1
restored = (
    final.replace(section, "", 1)
    .replace("".join(rows[:2]), "", 1)
    .replace(
        "| Previous bounded screen 3badbc72 |", "| Latest bounded screen 3badbc72 |", 1
    )
    .replace(
        "| Previous focused evidence 3badbc72 |",
        "| Latest focused evidence 3badbc72 |",
        1,
    )
)
assert restored == baseline
status_path.write_text(final, encoding="utf-8", newline="\n")
corrections = {
    "observed_utc": datetime.now(timezone.utc).isoformat(),
    "simanim": "Former stored printed forms have merkha; mirrored manuscript-elyon forms and two viewed retained crops have tevir on tav. Literal difference explicitly recorded before first publication.",
    "preparation_retry": "KeyError on previously-converted start-bound timestamp key occurred before receipt/archive mutation; failed script/log retained. Conditional conversion fixed it.",
    "status_preparation": "A second preparation initially duplicated uncommitted new rows/section. Rebuilt from exact parent and verified removing only new section/rows and reversing two label changes recovers parent bytes exactly. Original duplicate draft retained locally; prepare.py now always reads parent status.",
    "product_changes": False,
}
(out / "prepublication-corrections.json").write_bytes(dump(corrections))
record_path = root / "publication-prepared.json"
record = json.loads(record_path.read_bytes())
archive = tree / "doc" / record["archive"]["path"]
before = record["archive"].copy()
payload = {p.name: p.read_bytes() for p in out.iterdir() if p.is_file()}
for fname in (
    "run.py",
    "probe.py",
    "js-probe.cjs",
    "inspect_inputs.py",
    "diagnose_decalogue.py",
    "recover_generation.py",
    "record_diagnostics.py",
    "prepare.py",
    "publish.py",
    "finalize_prepared.py",
):
    payload["checkers/" + fname] = (root / fname).read_bytes()
payload["manifest.json"] = dump(
    {n: {"bytes": len(b), "sha256": sha(b)} for n, b in sorted(payload.items())}
)
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as z:
    for n, b in sorted(payload.items()):
        z.writestr(n, b)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist()))
    for n, item in json.loads(z.read("manifest.json")).items():
        assert len(z.read(n)) == item["bytes"] and sha(z.read(n)) == item["sha256"]
receipt = tree / "doc" / (name + ".md")
text = receipt.read_text(encoding="utf-8")
assert "former stored Simanim printed forms carry **merkha**" in text
old_measurement = f"**{before['bytes']} bytes**, SHA-256 `{before['sha256']}`"
new_measurement = (
    f"**{archive.stat().st_size} bytes**, SHA-256 `{sha(archive.read_bytes())}`"
)
assert text.count(old_measurement) == 1
text = text.replace(old_measurement, new_measurement, 1)
needle = "Every completed stage leaves empty tracked/untracked output diffs/statuses."
assert text.count(needle) == 1
text = text.replace(
    needle,
    needle
    + " A preparation retry stopped on an already-converted timestamp key before writing; the original script/log remain archived. The uncommitted status was rebuilt from the exact parent to remove duplicate draft sections, with complete prior content preservation verified.",
    1,
)
receipt.write_text(text, encoding="utf-8", newline="\n")
record["archive"] = {
    "path": archive.name,
    "bytes": archive.stat().st_size,
    "sha256": sha(archive.read_bytes()),
    "payload_files": len(payload) - 1,
}
record["prepared_utc"] = datetime.now(timezone.utc).isoformat()
record_path.write_bytes(dump(record))
git("diff", "--check")
changed = set(
    p for p in git("diff", "--name-only", "-z").decode().split("\0") if p
) | set(
    p
    for p in git("ls-files", "--others", "--exclude-standard", "-z")
    .decode()
    .split("\0")
    if p
)
assert changed == set(record["paths"])
assert json.loads((root / "stage.json").read_bytes())["state"] == "completed"
print(
    json.dumps(
        {
            "prepared": record,
            "parent_status_fully_preserved": True,
            "latest_section_count": 1,
        },
        indent=2,
    )
)

"""Inspect the public source shapes needed by the bounded comparator."""

import json
from pathlib import Path
import sys
from lxml import html

root = Path(__file__).resolve().parent
tree = root / "head"
sys.path.insert(0, str(tree / "py"))
from accgram import printed_decalogue

source = printed_decalogue.load_source()
(root / "evidence/dec_source_shape.json").write_text(
    json.dumps(source, ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8",
    newline="\n",
)
print(
    json.dumps(
        {"type": type(source).__name__, "keys": list(source)}, ensure_ascii=False
    )
)
for book, ident in [
    ("FD-2Chronicles", "c20v27"),
    ("A1-Genesis", "c14v7"),
    ("A2-Exodus", "c20v2"),
    ("A5-Deuter", "c5v13"),
]:
    doc = html.fromstring(
        (tree / "gh-pages/MAM-with-doc" / (book + ".html")).read_bytes()
    )
    node = doc.xpath("//*[@id=$ident]", ident=ident)[0]
    print(book, html.tostring(node.getparent(), encoding="unicode")[:4500])

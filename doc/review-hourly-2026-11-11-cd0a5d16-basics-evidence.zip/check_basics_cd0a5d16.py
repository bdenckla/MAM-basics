"""Independent whole-endpoint HTML/JSON preservation and relative-link probes."""

from collections import Counter
import hashlib
from html.parser import HTMLParser
import importlib
import json
from pathlib import Path
import posixpath
import re
import subprocess
import sys
import tempfile

ROOT = Path("/workspace/scratch/basics-cd0a5d16-checkout")
OUT = Path("/workspace/scratch/basics-cd0a5d16-artifacts")
BASE = "cba3b401666aa0a49147fdc54294086ff343de81"
HEAD = "cd0a5d16bbfdfd96acef4ee7a3936fb47d21bf8e"
SITE = "https://bdenckla.github.io/MAM-basics/"
counts = Counter()


def git(*args):
    return subprocess.check_output(["git", "-C", str(ROOT), *args])


def read(commit, path):
    return git("show", f"{commit}:{path}").decode()


def relative(page, url):
    assert url.startswith(SITE)
    target = url[len(SITE) :]
    cut = min(
        [i for i in (target.find("?"), target.find("#")) if i >= 0], default=len(target)
    )
    path, suffix = target[:cut], target[cut:]
    if not path or path.endswith("/"):
        path += "index.html"
    return posixpath.relpath(path, posixpath.dirname(page) or ".") + suffix


class Canonical(HTMLParser):
    def __init__(self, page, before):
        super().__init__(convert_charrefs=True)
        self.page, self.before, self.events = page, before, []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        ib = self.page == "israel-bible-review/index.html"
        if (
            ib
            and not self.before
            and tag == "link"
            and attrs.get("href") == "../MAM-with-doc/misc/style.css"
        ):
            counts["new_shared_sheet"] += 1
            return
        if self.before:
            for key in ("href", "src"):
                if attrs.get(key, "").startswith(SITE):
                    attrs[key] = relative(self.page, attrs[key])
                    counts["converted_site_attributes"] += 1
            if ib and tag == "span" and attrs.get("class") == "he":
                attrs["class"] = "extra-letter-spacing"
                counts["form_class_changes"] += 1
            elif ib and tag == "span" and attrs.get("class") == "hi":
                del attrs["class"]
                counts["inline_class_removals"] += 1
        self.events.append(("start", tag, sorted(attrs.items())))

    def handle_endtag(self, tag):
        self.events.append(("end", tag))

    def handle_data(self, data):
        data = " ".join(data.split())
        if data:
            self.events.append(("text", data))


paths = json.loads((OUT / "inventory.json").read_text())
changed = git("diff", "--name-only", "-z", BASE, HEAD).decode().strip("\0").split("\0")
assert len(changed) == paths["changed_paths"] == 402
html_paths = [p for p in changed if p.startswith("gh-pages/") and p.endswith(".html")]
for path in html_paths:
    old, new = read(BASE, path), read(HEAD, path)
    assert re.findall(r"[\u0590-\u05ff]+", old) == re.findall(
        r"[\u0590-\u05ff]+", new
    ), path
    left, right = Canonical(path[len("gh-pages/") :], True), Canonical(
        path[len("gh-pages/") :], False
    )
    left.feed(old)
    right.feed(new)
    assert left.events == right.events, path
assert counts == dict(
    converted_site_attributes=2239,
    new_shared_sheet=1,
    form_class_changes=112,
    inline_class_removals=3,
), counts


def transform(value):
    if isinstance(value, dict):
        return {k: transform(v) for k, v in value.items()}
    if isinstance(value, list):
        return [transform(v) for v in value]
    if isinstance(value, str):

        def replace(match):
            counts["json_link_changes"] += 1
            return relative("book-of-job/jobn-details/unused.html", match[0])

        return re.sub(re.escape(SITE) + r'[^\s"<>]+', replace, value)
    return value


record = "book-of-job/out/enriched-quirkrecs.json"
assert transform(json.loads(read(BASE, record))) == json.loads(read(HEAD, record))
assert counts["json_link_changes"] == 4
sys.path.insert(0, str(ROOT / "py"))
links = importlib.import_module("mb_cmn.site_links")
checker = importlib.import_module("check_html_syntax_and_sanity")
cases = [
    ("index.html", "MAM-with-doc/index.html", "MAM-with-doc/index.html"),
    (
        "wlc/accgram/x.html",
        "MAM-with-doc/E1-Song%20of%20Songs.html?x=1#c1v1",
        "../../MAM-with-doc/E1-Song%20of%20Songs.html?x=1#c1v1",
    ),
    (
        "israel-bible-review/index.html",
        "israel-bible-review/index.html#fn-x",
        "index.html#fn-x",
    ),
    (
        "near-aleppo/edition/index.html",
        "yeivin-itm/yeivin_itm.html#ns391",
        "../../yeivin-itm/yeivin_itm.html#ns391",
    ),
]
for page, target, expected in cases:
    assert links.site_href(page, target) == expected
    assert links.site_href_from_url(page, SITE + target) == expected
assert links.site_href_from_url("index.html", SITE) == "index.html"
assert (
    links.href_in_folder("wlc", "https://example.org/x#q") == "https://example.org/x#q"
)
assert links.site_url("MAM-with-doc/?q=1#x") == SITE + "MAM-with-doc/?q=1#x"
for page, target in [
    ("../bad.html", "index.html"),
    ("index.html", "../bad.html"),
    ("/index.html", "x.html"),
    ("index.html", "https://bad/x"),
]:
    try:
        links.site_href(page, target)
    except ValueError:
        pass
    else:
        raise AssertionError((page, target))
assert checker._fragment_found("a%28b%29", {"a(b)"})
assert checker._fragment_found("%D7%90", {"א"})
assert not checker._fragment_found("%D7%91", {"א"})
with tempfile.TemporaryDirectory(prefix="fragment-", dir=OUT) as temp:
    folder = Path(temp)
    target = folder / "target.html"
    target.write_text(
        '<!doctype html><html lang="en"><body><p id="א">x</p></body></html>'
    )
    parser = checker._HTMLInfo()
    parser.feed(
        '<a href="target.html#%D7%90">one</a><a href="target.html#%D7%90">two</a>'
    )
    cache = {}
    assert not checker._check_internal_links(
        Path("source.html"), parser, folder, {}, cache
    )
    assert list(cache) == [target.resolve()]
result = dict(
    result="PASS",
    base=BASE,
    head=HEAD,
    changed_paths=len(changed),
    html_pages=len(html_paths),
    transformations=dict(counts),
    html_comparison="All nodes/attributes and non-whitespace text equal after only declared href/src and Israel Bible styling transforms; Hebrew codepoints unchanged.",
    helper_probes=15,
    fragment_probes=4,
    limits="Whitespace folding explicit; no browser/readability, manuscript/source, font or broad-suite verification.",
)
(OUT / "independent-result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))

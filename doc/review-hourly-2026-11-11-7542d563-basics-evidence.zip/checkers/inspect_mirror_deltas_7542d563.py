"""Display every captured data delta succinctly, without changing products."""

import difflib
import json
from pathlib import Path

out = Path("/workspace/scratch/basics-7542d563-artifacts")
result = json.loads((out / "independent-check.json").read_bytes())
summary = {}
for book, record in result["corpus"].items():
    fields = {}
    for label, delta in [
        ("raw", record["raw_changes"]),
        ("plus", record["plus_changes"]),
        *record["mirrored_changes"].items(),
    ]:
        excerpts = []
        for d in delta:
            a, b = d["before"], d["after"]
            edits = []
            for op, i, j, k, l in difflib.SequenceMatcher(
                None, a, b, autojunk=False
            ).get_opcodes():
                if op != "equal":
                    edits.append(
                        dict(
                            old=a[i:j],
                            new=b[k:l],
                            old_context=a[max(0, i - 25) : min(len(a), j + 25)],
                            new_context=b[max(0, k - 25) : min(len(b), l + 25)],
                        )
                    )
            excerpts.append(dict(path=d["path"], edits=edits))
        fields[label] = excerpts
    summary[book] = fields
(out / "mirror-delta-inspection.json").write_text(
    json.dumps(summary, ensure_ascii=False, indent=2) + "\n"
)
print(json.dumps(summary, ensure_ascii=False, indent=2))

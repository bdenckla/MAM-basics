"""Record the sequential affected public producers at one frozen source commit."""

from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import time

WORK = Path("/workspace/scratch/basics-7542d563-checkout")
OUT = Path("/workspace/scratch/basics-7542d563-artifacts")
PY = "/workspace/MAM-basics/.venv/bin/python"
stages = [
    ("gen-misc", ["py/main_authored.py", "gen-misc"]),
    ("morphhb", ["py/main_mam_morphhb.py"]),
    *[
        ("parse-" + name, ["py/main_parse.py", "ws", "--book39", book])
        for name, book in [
            ("2samuel", "2Samuel"),
            ("jeremiah", "Jeremiah"),
            ("2chronicles", "2Chronicles"),
        ]
    ],
    *[
        ("mwd-" + name, ["py/main_mam_with_doc.py", "--book39", book])
        for name, book in [
            ("2samuel", "2Samuel"),
            ("jeremiah", "Jeremiah"),
            ("2chronicles", "2Chronicles"),
        ]
    ],
    ("sigil-inventory", ["py/main_sigil_inventory.py"]),
    ("near-note-review", ["py/main_near_aleppo.py", "--check-note-review"]),
    ("near-build", ["py/main_near_aleppo.py", "--build", "--check"]),
    ("near-html", ["py/main_near_aleppo.py", "--html", "--check"]),
    ("change-log", ["py/main_diff.py", "mpplus", "--check"]),
    ("head-subsite", ["py/check_html_syntax_and_sanity.py", "gh-pages/MAM-with-doc"]),
    (
        "focused-tests",
        [
            "py/main_test.py",
            "py/tests/test_site_index_links.py",
            "py/tests/test_deploy_root_html.py",
            "py/tests/test_redirect_manifest.py",
            "py/tests/test_prose_conventions.py",
            "py/tests/test_prose_mark_order.py",
            "py/tests/test_near_aleppo_note_content.py",
            "py/tests/test_wikisource_special_page_download.py::test_declared_special_page_inventory_matches_the_independent_intro_tables",
            "py/tests/test_diff_mpplus_unpinned_latest.py::test_registered_report_tree_declares_every_checked_artifact",
            "-q",
        ],
    ),
    (
        "changed-source-black",
        [
            "-m",
            "black",
            "--check",
            "py/author_misc/he_ws_intro_to_mam_gaya_text.py",
            "py/author_misc/review_of_hebrew_reader_for_the_pentateuch.py",
            "py/author_misc/tsinnorit_and_the_xxd_in_bhs.py",
            "py/author_misc/urwotm_common.py",
            "py/author_site/site_data.py",
            "py/check_html_syntax_and_sanity.py",
            "py/main_authored.py",
            "py/main_mam_morphhb.py",
        ],
    ),
]


def git(*args):
    return subprocess.check_output(["git", "-C", str(WORK), *args])


assert (
    git("rev-parse", "HEAD").decode().strip()
    == "7542d5636edeec99e7493249130df7a298b1144a"
)
assert not git("status", "--porcelain=v1", "-z")
for name, args in stages:
    record = OUT / (name + ".json")
    assert not record.exists(), "Do not repeat completed recorded stages"
    cmd = [PY, *args]
    timer = time.monotonic()
    started = datetime.now(timezone.utc).isoformat()
    print("START", name, started, flush=True)
    with (OUT / (name + ".log")).open("wb") as log:
        result = subprocess.run(cmd, cwd=WORK, stdout=log, stderr=subprocess.STDOUT)
    elapsed = time.monotonic() - timer
    status = git("status", "--porcelain=v1", "-z")
    (OUT / (name + "-status.z")).write_bytes(status)
    (OUT / (name + "-tracked.diff")).write_bytes(git("diff", "--binary"))
    summary = dict(
        command=cmd,
        cwd=str(WORK),
        started_utc=started,
        elapsed_seconds=round(elapsed, 6),
        exit_code=result.returncode,
        status_clean=not status,
    )
    record.write_text(json.dumps(summary, indent=2) + "\n")
    print("FINISH", name, json.dumps(summary), flush=True)
    assert (
        result.returncode == 0 and not status
    ), "Preserve failures/differences and investigate before continuing"

"""Retain the original pre-repair checker report and account for its disposition."""

from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import subprocess
import time

ROOT = Path("/workspace/scratch")
OUT = ROOT / "basics-7542d563-artifacts"
WORK = ROOT / "basics-7542d563-precheck"
cmd = [
    "/workspace/MAM-basics/.venv/bin/python",
    "py/check_html_syntax_and_sanity.py",
    "gh-pages/MAM-with-doc",
]
assert not (OUT / "pre-repair-subsite.json").exists()
timer = time.monotonic()
started = datetime.now(timezone.utc).isoformat()
result = subprocess.run(cmd, cwd=WORK, capture_output=True)
(OUT / "pre-repair-subsite.stdout").write_bytes(result.stdout)
(OUT / "pre-repair-subsite.stderr").write_bytes(result.stderr)
elapsed = time.monotonic() - timer
lines = result.stdout.decode().splitlines()
issues = [s for s in lines if s and not s.startswith(("Informational:", "Found "))]
count = re.search(r"Found (\d+) issue\(s\)\.", result.stdout.decode())
record = dict(
    command=cmd,
    cwd=str(WORK),
    source="7a0ea7a3bfa9c1ef0e3e6d6f35fb5d1ea20e2a51",
    exit_code=result.returncode,
    elapsed_seconds=round(elapsed, 6),
    started_utc=started,
    issue_count=int(count[1]) if count else None,
)
(OUT / "pre-repair-subsite.json").write_text(json.dumps(record, indent=2) + "\n")
assert result.returncode == 1 and count and len(issues) == int(count[1]) == 80
head = (OUT / "head-subsite.log").read_text()
assert "No HTML output issues found." in head
assert json.loads((OUT / "head-subsite.json").read_bytes())["exit_code"] == 0
categories = Counter(s.split(":", 1)[0] for s in issues)
assert (
    categories["orphan image"] == 36
    and categories["orphan HTML (not linked from any page)"] == 6
)
extensions = Counter(
    Path(s.split(": ", 1)[1]).suffix
    for s in issues
    if s.startswith("unexpected file type: ")
)
assert extensions[".csv"] == 1 and sum(extensions.values()) == 38
assert set(extensions) == {".csv", ".md", ".json"}
before_info = re.findall(r"^Informational:.*$", result.stdout.decode(), re.M)
after_info = re.findall(r"^Informational:.*$", head, re.M)
assert before_info == after_info
summary = dict(
    result="PASS_WITH_EXPLICIT_INFORMATIONAL_CSS_REPORT",
    before=record,
    after=json.loads((OUT / "head-subsite.json").read_bytes()),
    before_categories=categories,
    old_unexpected_extensions=extensions,
    disposition="36 unreferenced images retained byte-identically outside deployment; one unused CSV deleted; nonempty JSON/Markdown allowed by explicit owner choice; five root-linked pages and one explicit outside-linked stub accounted for by the new orphan scope/exemption.",
    fatal_issue_counts=[80, 0],
    informational_css_messages=after_info,
    limits="No external W3C upload, live link or browser claim. CSS references remain informational under maintained ownership policy, not verified class definitions.",
)
(OUT / "checker-settlement.json").write_text(json.dumps(summary, indent=2) + "\n")
scratch = ROOT / "basics-7542d563-checkout/py/novc_basics_7542d563_check.py"
assert scratch.read_bytes() == (ROOT / "check_basics_7542d563.py").read_bytes()
scratch.unlink()
for work in (WORK, ROOT / "basics-7542d563-checkout"):
    assert not subprocess.check_output(
        ["git", "-C", str(work), "status", "--porcelain=v1", "-z"]
    )
print(json.dumps(summary, indent=2))

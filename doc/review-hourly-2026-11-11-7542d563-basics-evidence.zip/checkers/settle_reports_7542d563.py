"""Account for already completed checker runs; execute no product check."""

from collections import Counter
import json
from pathlib import Path
import re
import subprocess

ROOT = Path("/workspace/scratch")
OUT = ROOT / "basics-7542d563-artifacts"
before = json.loads((OUT / "pre-repair-subsite.json").read_bytes())
assert before["exit_code"] == 1 and before["issue_count"] == 80
report = (OUT / "pre-repair-subsite.stdout").read_text()
issues = [
    s
    for s in report.splitlines()
    if s and not s.startswith(("Informational:", "Found "))
]
assert len(issues) == 80
categories = Counter(s.split(":", 1)[0] for s in issues)
extensions = Counter(
    Path(s.split(": ", 1)[1]).suffix
    for s in issues
    if s.startswith("unexpected file type: ")
)
assert categories == {
    "orphan image": 36,
    "unexpected file type": 38,
    "orphan HTML (not linked from any page)": 6,
}
assert extensions == {".json": 34, ".csv": 1, ".md": 1, ".gif": 2}
head = (OUT / "head-subsite.log").read_text()
after = json.loads((OUT / "head-subsite.json").read_bytes())
assert after["exit_code"] == 0 and "No HTML output issues found." in head
old_info = re.findall(r"^Informational:.*$", report, re.M)
new_info = re.findall(r"^Informational:.*$", head, re.M)
assert old_info == new_info
summary = dict(
    result="PASS_WITH_EXPLICIT_INFORMATIONAL_CSS_REPORT",
    before=before,
    after=after,
    before_categories=categories,
    old_unexpected_extensions=extensions,
    disposition="36 orphan-image reports and two additional GIF-type reports settled by retaining the same 36 images outside deployment; one unused CSV deleted; 34 JSON and one Markdown report covered by explicit allowed extensions; five root-linked pages and one explicit outside-linked stub accounted for by new orphan scope/exemption.",
    fatal_issue_counts=[80, 0],
    informational_css_messages=new_info,
    limits="No W3C upload, live link or browser claim. Undefined CSS references remain informational under maintained ownership policy, not verified class definitions.",
)
(OUT / "checker-settlement.json").write_text(json.dumps(summary, indent=2) + "\n")
diagnostics = dict(
    product_failures=[],
    reviewer_errors=[
        dict(
            checker="independent-check-first.py",
            issue="Assumed ledger IDs omitted their Hebrew sub-book label.",
            correction="Use the structured ref fields to compare the book-group/chapter/verse; corrected scratch checker passes.",
            rerun="Only corrected scratch checker; no maintained producer/test repeated.",
        ),
        dict(
            checker="settlement-reporter-first.py",
            issue="Omitted two unexpected GIF-type reports for images that also have orphan reports.",
            correction="Original recorded report contains 34 JSON, one CSV, one Markdown and two GIF type reports. This analysis reads retained logs only.",
            rerun="No checker command repeated; original 80-issue and final zero-issue CLI runs retained.",
        ),
    ],
)
(OUT / "diagnostics.json").write_text(json.dumps(diagnostics, indent=2) + "\n")
scratch = ROOT / "basics-7542d563-checkout/py/novc_basics_7542d563_check.py"
assert scratch.read_bytes() == (ROOT / "check_basics_7542d563.py").read_bytes()
scratch.unlink()
for work in (ROOT / "basics-7542d563-precheck", ROOT / "basics-7542d563-checkout"):
    assert not subprocess.check_output(
        ["git", "-C", str(work), "status", "--porcelain=v1", "-z"]
    )
print(json.dumps(summary, indent=2))

import json,subprocess
from collections import Counter
from pathlib import Path
from lxml import html
r=Path('/workspace/scratch/hourly-f996f756-public'); source=r/'source'; e=r/'evidence'
base='5b6a2ef44c579a08e1f092dbfd6ac4ad681707e8'; head='f996f75630e19241d055215450165bd1da5fed80'
def g(rev,path):return subprocess.check_output(['git','show',rev+':'+path],cwd=source)
paths=['gh-pages/stress-helpers/index.html','gh-pages/israel-bible-review/index.html','gh-pages/wlc/accgram/printed-decalogue-koren.html']
added=[]
for p in paths:
 a=Counter(html.document_fromstring(g(base,p)).xpath('//@href|//@src')); b=Counter(html.document_fromstring(g(head,p)).xpath('//@href|//@src'))
 assert not a-b
 added.extend((b-a).elements())
assert Counter(added)==Counter({'../wlc/accgram/printed-decalogue-koren.html#koren-conclusion':2,'../wlc/accgram/printed-decalogue-simanim.html#simanim-conclusion':1})
issues=[]
for name,tree,expected in [('stress','gh-pages/stress-helpers',4),('wlc','gh-pages/wlc',11)]:
 lines=(e/('html-'+name+'.txt')).read_text().splitlines()
 found=[x for x in lines if x.startswith(('orphan image: ','unexpected file type: '))]
 assert len(found)==expected
 for line in found:
  path=tree+'/'+line.split(': ',1)[1]
  assert g(base,path)==g(head,path)
  issues.append({'finding':line,'path':path,'unchanged_blob':subprocess.check_output(['git','rev-parse',head+':'+path],cwd=source).decode().strip()})
assert g(base,'py/check_html_syntax_and_sanity.py')==g(head,'py/check_html_syntax_and_sanity.py')
summary={'all_15_finding_files_byte_identical_to_base':True,'checker_unchanged':True,'changed_HTML_attributes_only_add_three_nonimage_links':added,'no_new_HTML_failure_established':True,'findings':issues,'CSS_information_counts':{'stress':275,'wlc':142}}
(e/'html-findings-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'result':'PASS','historical_stress_issues':4,'historical_wlc_issues':11}))

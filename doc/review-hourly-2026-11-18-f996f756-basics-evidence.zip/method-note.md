# Reviewer method and original diagnostics

The first preservation helper exited 1 (wall 0.097133425 s), because it compared raw
Koren cell serialization after the formatter rewrapped the narrowed table. The original
helper is check-preservation-v1.py; preservation-v1.stderr retains its tool-returned
traceback. The corrected helper normalizes wrapping in the two retained cells, preserves
their markup/codepoints, and compares bytes exactly outside the table/caption. No product
changed. Its final command/result is recorded separately; all generator diffs stayed empty.

An initial read-only rg lookup named the nonexistent author_misc/israel_bible_review.py
and returned exit 2; the maintained entrypoint routes gen-israel-bible-review to
author_misc/israel_bible_review_index.py. This discovery error was corrected before any
generator command. It is not a producer failure.

The two HTML checker exits 1 are retained, not passing: four historical stress orphan
crops; ten historical wlc orphan images and one XML file-type issue. The separate findings
checker verifies all fifteen affected blobs unchanged, the checker unchanged and only
three new nonimage links across changed HTML. CSS notices remain informational. There
was no W3C upload, browser/native proof, new scan/source research or editorial decision.

import copy
import json
import re
import subprocess
from pathlib import Path
from urllib.parse import unquote, urlsplit

from lxml import html, etree

ROOT=Path('/workspace/scratch/hourly-f996f756-public/source')
EVIDENCE=ROOT.parent/'evidence'
BASE='5b6a2ef44c579a08e1f092dbfd6ac4ad681707e8'
HEAD='f996f75630e19241d055215450165bd1da5fed80'
checks=[]

def data(path,rev):
 return subprocess.check_output(['git','-C',str(ROOT),'show',rev+':'+path])

def ok(name,condition):
 assert condition,name
 checks.append(name)

def serial(node):
 return etree.tostring(node,encoding='unicode',method='html',with_tail=False)

def unwrapped(node):
 node=copy.deepcopy(node)
 for e in node.iter():
  if e.text: e.text=re.sub(r'\s+',' ',e.text)
  if e.tail: e.tail=re.sub(r'\s+',' ',e.tail)
 return serial(node)

added=[]; records=0
for edition in ['koren','simanim-tanakh']:
 path='in/stress-helpers/'+edition+'.json'
 a=json.loads(data(path,BASE)); b=json.loads(data(path,HEAD))
 ok(edition+' JSON root unchanged except findings',set(a)==set(b))
 # The schema calls its ordered population findings.
 key='findings'
 if key not in a:
  key=next(k for k,v in a.items() if isinstance(v,list) and v and isinstance(v[0],dict) and 'mam' in v[0])
 ok(edition+' population stable',len(a[key])==len(b[key]))
 aa=copy.deepcopy(a); bb=copy.deepcopy(b)
 for i,(old,new) in enumerate(zip(aa[key],bb[key])):
  records+=1
  if old!=new:
   ok(edition+' modified record only appends one note '+str(i),set(old)==set(new) and len(new['notes'])==len(old['notes'])+1 and new['notes'][:-1]==old['notes'])
   note=new['notes'].pop()
   added.append((edition,i,note))
 ok(edition+' every other field and exact forms unchanged',aa==bb)
ok('exactly three added notes',len(added)==3)
path='gh-pages/stress-helpers/index.html'
old=html.document_fromstring(data(path,BASE)); new=html.document_fromstring(data(path,HEAD))
orows=old.xpath('//tbody/tr'); nrows=new.xpath('//tbody/tr')
ok('93 rows unchanged membership/order',len(orows)==len(nrows)==93)
changed=0
for a,b in zip(orows,nrows):
 if serial(a)==serial(b): continue
 changed+=1
 ok('changed row only gained last note '+str(changed),a.attrib==b.attrib)
 cell=b.xpath('./td[@class="difference"]')[0]
 last=cell[-1]
 ok('new note link is one of the declared targets',last.tag=='p' and last.xpath('./a/@href') in [[n['href']] for _,_,n in added])
 cell.remove(last)
 ok('all other row bytes/markup preserved '+str(changed),serial(a)==serial(b))
ok('only three stress rows changed',changed==3)
ok('whole stress DOM preserved after removing declared notes',serial(old)==serial(new))

path='in/israel-bible-review/review.md'
a=data(path,BASE); b=data(path,HEAD)
expected=a.replace(b'is the Westminster Leningrad Codex (WLC), version 4.18',b'is WLC, version 4.18',1).replace(b'of the body text of _Biblia Hebraica Stuttgartensia_ (BHS),',b'of the body text of BHS,',1)
ok('Markdown exact two intended title reductions only',expected==b)
path='gh-pages/israel-bible-review/index.html'
a=data(path,BASE); b=data(path,HEAD)
expected=a.replace(b'is the Westminster Leningrad Codex (<abbr title="the Westminster Leningrad Codex">WLC</abbr>),',b'is <abbr title="the Westminster Leningrad Codex">WLC</abbr>,',1).replace(b'of the body text of <cite>Biblia Hebraica Stuttgartensia</cite> (<abbr title="Biblia Hebraica Stuttgartensia">BHS</abbr>),',b'of the body text of <abbr title="Biblia Hebraica Stuttgartensia">BHS</abbr>,',1)
ok('HTML exact two reductions, quotation and all other bytes preserved',expected==b)
ad=html.document_fromstring(a); bd=html.document_fromstring(b)
ok('all abbreviation titles preserved',ad.xpath('//abbr/@title')==bd.xpath('//abbr/@title'))
ok('all Israel Bible Hebrew sequences exact',re.findall(rb'[\xd6\xd7][\x80-\xbf]',a)==re.findall(rb'[\xd6\xd7][\x80-\xbf]',b))

path='gh-pages/wlc/accgram/printed-decalogue-koren.html'
a=data(path,BASE).decode(); b=data(path,HEAD).decode()
pattern=r'<table class="printed-decalogue-transcription-verdict(?: ruled-rows)?">.*?</table>'
ta=re.findall(pattern,a,re.S); tb=re.findall(pattern,b,re.S)
ok('one verdict table per version',len(ta)==len(tb)==1)
oa=html.fromstring(ta[0]); nb=html.fromstring(tb[0])
ar=oa.xpath('.//tr'); br=nb.xpath('.//tr')
ok('four verdict rows and header retained',len(ar)==len(br)==5)
for i,(ra,rb) in enumerate(zip(ar,br)):
 ca=list(ra); cb=list(rb)
 ok('five columns merged to three '+str(i),len(ca)==5 and len(cb)==3)
 ok('last two cells contents and markup retained ignoring wrapping '+str(i),[unwrapped(x) for x in ca[-2:]]==[unwrapped(x) for x in cb[-2:]])
 if i:
  oldlabels=[''.join(c.itertext()) for c in ca[:3]]
  oldlabels[0]=oldlabels[0].replace('Exodus','Ex').replace('Deuteronomy','Dt')
  newlabels=[]; segment=cb[0].text or ''
  for child in cb[0]:
   if child.tag=='br': newlabels.append(segment); segment=child.tail or ''
   else: segment+=''.join(child.itertext())+(child.tail or '')
  newlabels.append(segment)
  ok('all labels/pages/strands retained in stacked row header '+str(i),newlabels==oldlabels and cb[0].tag=='th')
caps_a=re.findall(r'<figcaption>.*?</figcaption>',a,re.S); caps_b=re.findall(r'<figcaption>.*?</figcaption>',b,re.S)
ok('caption count retained',len(caps_a)==len(caps_b))
changed_caps=[(x,y) for x,y in zip(caps_a,caps_b) if x!=y]
ok('one caption gains Latin runway',len(changed_caps)==1 and 'The span' in changed_caps[0][1])
old_caption=re.sub(r'\s+',' ',changed_caps[0][0]); new_caption=re.sub(r'\s+',' ',changed_caps[0][1])
ok('caption only adds The span ignoring wrapping',re.sub(r'\. (?=[\u0590-\u05ff])','. The span ',old_caption,count=1)==new_caption)
outside_a=a.replace(ta[0],'<VERDICT>'); outside_b=b.replace(tb[0],'<VERDICT>')
outside_a=outside_a.replace(changed_caps[0][0],'<CAPTION>'); outside_b=outside_b.replace(changed_caps[0][1],'<CAPTION>')
ok('every byte outside table and caption preserved',outside_a==outside_b)
ok('all Koren Hebrew codepoints retained',re.findall(r'[\u0590-\u05ff]+',a)==re.findall(r'[\u0590-\u05ff]+',b))
css=(ROOT/'gh-pages/wlc/style.css').read_text()
ok('last-two-cell alignment rule present', 'table.printed-decalogue-transcription-verdict td:nth-last-child(-n+2) { text-align: left; }' in css)
sim=html.document_fromstring((ROOT/'gh-pages/wlc/accgram/printed-decalogue-simanim.html').read_bytes())
st=sim.xpath('//table[contains(concat(" ",normalize-space(@class)," ")," printed-decalogue-transcription-verdict ")]')
ok('two unchanged Simanim verdict tables',len(st)==2)
simrows=0
for table in st:
 for row in table.xpath('.//tr')[1:]:
  cells=list(row); simrows+=1
  ok('same cells selected in Simanim row '+str(simrows),len(cells)==5 and [i for i,c in enumerate(cells) if c.tag=='td' and i>=3]==[i for i,c in enumerate(cells) if c.tag=='td' and i>=len(cells)-2])
ruled=[]
for f in (ROOT/'gh-pages/wlc').rglob('*.html'):
 if re.search(r'<table[^>]*class="[^"]*\bruled-rows\b',f.read_text(encoding='utf-8')): ruled.append(str(f.relative_to(ROOT)))
ok('ruled-rows opts in only Koren within shared wlc tree',ruled==[path])
links=0
for name in ['gh-pages/stress-helpers/index.html','gh-pages/israel-bible-review/index.html',path]:
 dom=html.document_fromstring((ROOT/name).read_bytes())
 ids=dom.xpath('//@id'); ok('unique IDs in '+name,len(ids)==len(set(ids)))
 for url in dom.xpath('//@href|//@src'):
  p=urlsplit(url)
  if p.scheme or p.netloc: continue
  file=(ROOT/name).parent/unquote(p.path) if p.path else ROOT/name
  file=file.resolve()
  if file.is_dir(): file=file/'index.html'
  ok('local path exists '+str(links),file.is_file())
  if p.fragment and file.suffix=='.html':
   target=html.document_fromstring(file.read_bytes()); ok('local anchor resolves '+str(links),unquote(p.fragment) in target.xpath('//@id'))
  links+=1
summary={'base':BASE,'source':HEAD,'checks_passed':len(checks),'edition_records':records,'added_notes':len(added),'stress_rows':93,'koren_verdict_rows':4,'verdict_columns_old_new':[5,3],'simanim_rows_equivalent_css_selection':simrows,'local_href_src_occurrences_resolved':links,'checks':checks,'browser_or_original_source_claim':False}
(EVIDENCE/'preservation-summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k!='checks'},indent=2))

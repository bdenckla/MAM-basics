import json
import os
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

root=Path('/workspace/scratch/hourly-f996f756-public')
source=root/'source'; evidence=root/'evidence'
python='/workspace/MAM-basics/.venv/bin/python'
tests=['py/tests/'+s for s in ['test_printed_decalogue_koren.py','test_printed_decalogue_simanim.py','test_printed_decalogue_page.py','test_israel_bible_review_mam_forms.py','test_shared_html_styles.py','test_prose_conventions.py','test_prose_mark_order.py','test_site_links_relative.py','test_site_index_links.py']]
steps=[
 ('diff-check',['git','diff','--check','5b6a2ef44c579a08e1f092dbfd6ac4ad681707e8','f996f75630e19241d055215450165bd1da5fed80']),
 ('black',[python,'-m','black','--check','py/accgram/printed_decalogue_koren_page.py']),
 ('gen-site',[python,'py/main_authored.py','gen-site','--trust-surveys']),
 ('gen-israel',[python,'py/main_authored.py','gen-israel-bible-review']),
 ('gen-koren',[python,'py/main_accgram.py','generate-html-printed-decalogue-koren']),
 ('focused-tests',[python,'py/main_test.py',*tests,'-q']),
]
records=[]
for name,command in steps:
 start=time.monotonic()
 record={'name':name,'command':command,'cwd':str(source),'start_utc':datetime.now(timezone.utc).isoformat()}
 run=subprocess.run(command,cwd=source,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (evidence/(name+'.txt')).write_bytes(run.stdout)
 status=subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=source)
 diff=subprocess.check_output(['git','diff','--binary'],cwd=source)
 (evidence/(name+'-post-status.bin')).write_bytes(status); (evidence/(name+'-post.diff')).write_bytes(diff)
 record.update(exit=run.returncode,wall_seconds=round(time.monotonic()-start,6),status_bytes=len(status),diff_bytes=len(diff))
 records.append(record); (evidence/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps(record),flush=True)
 if run.returncode or status or diff:
  print(run.stdout.decode('utf-8',errors='replace')); raise SystemExit(1)

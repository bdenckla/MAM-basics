import json
import subprocess
import time
from datetime import datetime,timezone
from pathlib import Path
r=Path('/workspace/scratch/hourly-f996f756-public'); e=r/'evidence'
command=['/workspace/MAM-basics/.venv/bin/python',str(e/'check-preservation.py')]
start=time.monotonic(); observed=datetime.now(timezone.utc).isoformat()
run=subprocess.run(command,cwd=r/'source',stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(e/'preservation.txt').write_bytes(run.stdout)
record={'command':command,'cwd':str(r/'source'),'start_utc':observed,'exit':run.returncode,'wall_seconds':round(time.monotonic()-start,6),'prior_reviewer_failure':{'exit':1,'wall_seconds':0.097133425,'script':'check-preservation-v1.py','stderr':'preservation-v1.stderr','reason':'raw HTML line-wrapping equality assumption'}}
(e/'preservation-command.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record)); print(run.stdout.decode('utf-8'))
raise SystemExit(run.returncode)

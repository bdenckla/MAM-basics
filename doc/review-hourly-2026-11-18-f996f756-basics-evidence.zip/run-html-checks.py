import json,os,subprocess,time
from datetime import datetime,timezone
from pathlib import Path
r=Path('/workspace/scratch/hourly-f996f756-public'); records=[]
for name,path in [('israel','gh-pages/israel-bible-review'),('stress','gh-pages/stress-helpers'),('wlc','gh-pages/wlc')]:
 command=['/workspace/MAM-basics/.venv/bin/python','py/check_html_syntax_and_sanity.py',path]
 start=time.monotonic(); began=datetime.now(timezone.utc).isoformat()
 run=subprocess.run(command,cwd=r/'source',env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (r/'evidence'/('html-'+name+'.txt')).write_bytes(run.stdout)
 status=subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=r/'source')
 record={'name':name,'command':command,'cwd':str(r/'source'),'start_utc':began,'wall_seconds':round(time.monotonic()-start,6),'exit':run.returncode,'normal_status_bytes':len(status)}
 records.append(record); (r/'evidence/html-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps(record),flush=True)
 assert run.returncode in (0,1) and status==b''

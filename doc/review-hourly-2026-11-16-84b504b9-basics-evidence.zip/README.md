# Bounded review methods and evidence

Exact source: 84b504b9a63c75aa0ef87dadda6e7ec301a46ebe.
Base: 1884cf59c47d85d8cb74ec3f2a2a26015444e431.
Receipt parent: 39e03b9165063ae0784622d7acdf22f2b10c5823.
Owning interpreter: /workspace/MAM-basics/.venv/bin/python (Python 3.13.15).
All checks run sequentially from /workspace/scratch/basics-84b504b9.
No selected check needs a sibling input. No Private review material is present.

Each command JSON gives its actual argument array, UTC start, wall time and exit.
stage-states.json records empty source status and tracked diff after every stage.
The reviewer scripts are methods, not maintained source/tests. Their sys.path insertion
is confined to disposable review helpers. No original DOCX was available or acquired.

parser_fixtures.py writes 40 synthetic minimal DOCX files, not original book sources.
Seven DOCX shapes are accepted and 33 malformed shapes refused; a further positive
extraction/location/source-metadata assertion gives 41 outcome records (8/33).
Synthetic missing/incorrect field state, instruction, style, nesting and picture/text
placement are covered. These are adversarial behavior assertions, not a source audit.
report_and_preservation.py compares 85 retained earlier preview files and their hashes,
without reading old code or rerunning a prior generator. It also records the maintained
check CLI on one fabricated one-verse file: actual expected exit 1, four deliberate
inventory/extraction/versification/similarity mismatches, and all four picture diagnostics.
This is not original extraction/check evidence or an unexplained product failure.

offline_audit.py reads every tracked Miqra JSON payload and all current page outputs.
It checks complete preview inventory/titles and source payloads after NFC only at the
declared MediaWiki page boundary. It compares 12 display texts to an independent raw
MAM-simple starts-with-sampe/verse walk, declared sort keys and tracked heading inventory.
It compares 2626 letter projections across 13 registered books plus committed Judges;
two newly recognized projection sites are recorded. Every endpoint file matches its
committed bytes. Source metadata hashes/sizes are not independent Word-file evidence.

The ZIP excludes preview copies, synthetic DOCX copies, original sources and unrelated
repositories. Scripts and compact summaries retain decisive reproduction methods.
Root's no-open-PR branch query and initial process/slot admission are coordinator
evidence reported in the receipt, not executions invented in this archive.

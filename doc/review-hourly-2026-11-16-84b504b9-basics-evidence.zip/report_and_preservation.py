"""Expected-failing synthetic check CLI and retained-preview comparison only."""
import datetime
import hashlib
import json
import pathlib
import shutil
import subprocess
import time

OUT=pathlib.Path(__file__).parent
ROOT=pathlib.Path('/workspace/scratch/basics-84b504b9')
PREVIOUS=pathlib.Path('/workspace/scratch/basics-1884cf59-artifacts')
manifest=json.loads((PREVIOUS/'preview-manifest.json').read_text(encoding='utf-8'))
compared=[]
for row in manifest:
    rel=row['path']
    if not rel.endswith('.wiki'): continue
    previous=(PREVIOUS/'miqra-preview'/rel).read_bytes()
    current=(OUT/'base-pages'/rel).read_bytes()
    assert hashlib.sha256(previous).hexdigest()==row['sha256'],rel
    assert current==previous,rel
    compared.append(dict(path=rel,sha256=row['sha256'],bytes=len(current)))
assert len(compared)==85
(OUT/'preserved-preview-manifest.json').write_text(json.dumps(dict(prior_source='1884cf59c47d85d8cb74ec3f2a2a26015444e431',prior_receipt='39e03b9165063ae0784622d7acdf22f2b10c5823',method='current maintained pages output compared to retained earlier output and its manifest, no old generator rerun',compared=compared),indent=2)+'\n',encoding='utf-8',newline='\n')

directory=OUT/'synthetic-check-input';directory.mkdir(exist_ok=False)
shutil.copyfile(OUT/'synthetic-docx/pictures-four-row-kinds.docx',directory/'yehoshua.docx')
command=['/workspace/MAM-basics/.venv/bin/python','py/main_miqra_mevoar.py','check',str(directory)]
start=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.perf_counter()
result=subprocess.run(command,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(OUT/'synthetic-check-cli.txt').write_bytes(result.stdout)
text=result.stdout.decode('utf-8')
assert result.returncode==1,(result.returncode,text)
assert 'failures: 4' in text,text
for where in ['the title row','the heading of 1:1','1:1','an empty row']:
    assert '('+where+')' in text,text
assert text.count('a picture that holds no text, read past')==4,text
records=dict(command=command,cwd=str(ROOT),started_utc=start,wall_seconds=round(time.perf_counter()-clock,6),exit_code=result.returncode,expected_exit_code=1,synthetic_only=True,
    disposition='Expected refusal for a one-verse fabricated Word file: different book inventory, extraction, versification and Bible similarity. All four picture location diagnostics retained. This is not original-source check evidence.')
(OUT/'synthetic-check-cli.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n')
print('85 earlier preview files unchanged against retained output and recorded hashes.')
print('Synthetic-only maintained check CLI expected exit 1; four mismatches and all four picture locations verified.')

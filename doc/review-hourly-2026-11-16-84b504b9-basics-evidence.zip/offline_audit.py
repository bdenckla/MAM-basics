"""Independent committed-data, local page and letter-projection checks.

No network, Private, original DOCX, bot or frozen-study execution. No input is normalized.
NFC conversion applies only to the declared MediaWiki page output contract.
"""
import collections
import hashlib
import json
import pathlib
import re
import subprocess
import sys
import unicodedata

ROOT=pathlib.Path('/workspace/scratch/basics-84b504b9')
OUT=pathlib.Path(__file__).parent
sys.path.insert(0,str(ROOT/'py'))
from mb_cmn import hebrew_verse_numerals as hvn
from miqra_mevoar import books, display_page, mam_simple, tracked

head='84b504b9a63c75aa0ef87dadda6e7ec301a46ebe'
base='1884cf59c47d85d8cb74ec3f2a2a26015444e431'
def git(*args): return subprocess.check_output(['git','-C',str(ROOT),*args])
assert git('rev-parse','HEAD').decode().strip()==head
assert git('status','--porcelain=v1','-z')==b''
changed=[name.decode() for name in git('diff','--name-only','-z',base,head).split(b'\0') if name]
manifest=[]
for name in changed:
    data=(ROOT/name).read_bytes()
    assert data==git('show',head+':'+name),name
    manifest.append(dict(path=name,size=len(data),sha256=hashlib.sha256(data).hexdigest()))
assert len(changed)==12
assert git('rev-list','--count',base+'..'+head).strip()==b'5'
previews=OUT/'base-pages'
titles=[line.split('\t') for line in (previews/'titles.tsv').read_text(encoding='utf-8').splitlines()]
title_map=dict(titles)
assert len(titles)==len(title_map)==len(set(t[1] for t in titles))
expected_paths={'titles.tsv'}
records=[]
total=collections.Counter()
for path in sorted((ROOT/'in/miqra-mevoar').glob('*.json')):
    before=path.read_bytes()
    stem=path.stem
    record=json.loads(before)
    source=record['source']
    assert source['file']==stem+'.docx'
    assert isinstance(source['size'],int) and source['size']>0
    assert re.fullmatch('[0-9a-f]{64}',source['sha256'])
    count=collections.Counter(chapters=len(record['chapters']))
    for chapter in record['chapters']:
        number=chapter['chapter']; rel=f'{stem}/{number:02}.wiki';expected_paths.add(rel)
        numeral=hvn.INT_TO_STR_DIC[number]
        assert title_map[rel]==f'מקרא מבואר/פרקי בסיס/ספר {record["book"]}/{numeral}'
        actual=(previews/rel).read_text(encoding='utf-8')
        expected=[f'==פרק {numeral}==']
        for verse in chapter['verses']:
            vn=hvn.INT_TO_STR_DIC[verse['verse']]
            if verse['heading'] is not None:
                expected.append(f'*<קטע התחלה=כותרת {vn}/>{verse["heading"]}<קטע סוף=כותרת {vn}/>')
                count['headings']+=1
            expected.append(f'<קטע התחלה={vn}/>{verse["paraphrase"]}<קטע סוף={vn}/>')
            count['verses']+=1
        expected.append('[[קטגוריה:מקרא מבואר]]')
        assert actual==unicodedata.normalize('NFC','\n'.join(expected)),rel
        assert not actual.endswith('\n') and unicodedata.is_normalized('NFC',actual)
        count['bytes']+=len(actual.encode('utf-8'))
    assert before==path.read_bytes()
    records.append(dict(stem=stem,source_metadata_only=source,**count))
    total.update(count)
assert expected_paths=={str(p.relative_to(previews)) for p in previews.rglob('*') if p.is_file()}

# Read raw MAM-simple directly, with an independent explicit leaf/structure walk.
# The oracle includes every textual leaf, including both ketiv and qere, skips the
# declared separators and good-ending repetition; unknown shapes fail loudly.
raw_books={}
for p in sorted((ROOT/'MAM-simple/json-vtrad-mam').glob('*.json')):
    for item in json.loads(p.read_text(encoding='utf-8'))['contents']:
        if item['type']=='book39': raw_books[item['osisID']]=item
breaks={'spi-pe2','spi-pe3','spi-samekh2','spi-samekh3'}
leaves={'text','kq-k','kq-trivial','kq-q-velo-k','letter-small','letter-large','letter-hung'}
containers={'verse','kq-q','kq','slh-word'}
separators=breaks|{'lp-legarmeih','lp-paseq','shirah-space'}
def oracle_text(node):
    kind=node['type']
    if kind in leaves:return node['text']
    if kind in containers:
        return node['text'] if 'text' in node else ''.join(map(oracle_text,node['contents']))
    if kind in separators or kind=='good-ending':return ''
    raise AssertionError(('unexpected oracle node',kind))
letters=re.compile('[^א-ת]')
def raw_verses(osis):
    return [v for c in raw_books[osis]['contents'] if c['type']=='chapter' for v in c['contents'] if v['type']=='verse']
def key(v):return tuple(map(int,v['osisID'].split('.')[1:]))
projection=[]
special=[]
project_books=list(books.BOOKS.values())+[books.Book('synthetic-judges-probe','',('',None),'Judg.json','Judg')]
for book in project_books:
    vv=raw_verses(book.osis_id)
    expected={key(v):letters.sub('',oracle_text(v)) for v in vv}
    assert mam_simple.verse_letters(book)==expected,book.stem
    projection.append(dict(stem=book.stem,osis=book.osis_id,verses=len(vv)))
    def walk(n,osisid):
        if n['type'] in {'letter-hung','kq-q-velo-k'}:
            special.append(dict(verse=osisid,kind=n['type'],text=n['text']))
        for child in n.get('contents',()):walk(child,osisid)
    for v in vv:walk(v,v['osisID'])
assert special
for kind in ['letter-hung','kq-q-velo-k']:
    try:mam_simple._projected({'type':'unknown-'+kind,'text':'בדיקה'})
    except ValueError:pass
    else:raise AssertionError('unknown type accepted')

# Produce display pages locally, then compare literal line forms with independent
# raw starts-with-sampe and tracked heading/verse inventories, not generator walks.
display_out=OUT/'display-pages';display_out.mkdir(exist_ok=False)
displays=[]
declared_sort={'yehoshua-1':'ספר יהושע א','yehoshua-2':'ספר יהושע ב'}
for keyname,page in display_page.PAGES.items():
    book=books.book_of_stem(page.stem)
    data=json.loads((ROOT/f'in/miqra-mevoar/{page.stem}.json').read_text(encoding='utf-8'))
    headings={(c['chapter'],v['verse']) for c in data['chapters'] for v in c['verses'] if v['heading'] is not None}
    allvv=raw_verses(book.osis_id)
    first,last=page.chapters or (1,int(allvv[-1]['osisID'].split('.')[1]))
    expected=[];count=collections.Counter()
    for at,v in enumerate(allvv):
        chapter,verse=key(v)
        if not first<=chapter<=last:continue
        cn,vn=hvn.INT_TO_STR_DIC[chapter],hvn.INT_TO_STR_DIC[verse]
        sampe=None if at==0 else v.get('starts-with-sampe')
        parameters=[]
        if sampe:
            letter={'pe2':'פ','pe3':'פ','samekh2':'ס','samekh3':'ס'}[sampe]
            parameters.append('פרשה='+letter)
            count['petuhot' if letter=='פ' else 'setumot']+=1
        if (chapter,verse) in headings:
            target=f'מקרא מבואר/פרקי בסיס/ספר {data["book"]}/{cn}'
            parameters.append('כותרת={{#קטע:'+target+'|כותרת '+vn+'}}')
            count['headings']+=1
        if parameters:
            count['break_lines']+=1
            expected.append('{{פרשה במקרא מבואר|'+'|'.join(parameters)+'}}')
        expected.append('{{מקרא מבואר|'+data['book']+'|'+cn+'|'+vn+'}}')
        count['verses']+=1
    sort=declared_sort.get(keyname,page.name)
    expected.extend(['','[[קטגוריה:מקרא מבואר|'+sort+']]'])
    text=display_page.page_text(page)
    assert text=='\n'.join(expected),keyname
    assert not text.endswith('\n') and unicodedata.is_normalized('NFC',text)
    assert display_page.read_page(text)[1]==sort
    (display_out/(keyname+'.wiki')).write_text(text,encoding='utf-8',newline='')
    displays.append(dict(key=keyname,title=page.title(),category_sort_key=sort,bytes=len(text.encode('utf-8')),**count))
assert len(displays)==12
assert {d['key'] for d in displays}-{*declared_sort}=={'hoshea','yoel','amos','ovadya','yona','mikha','nahum','havaquq','hagay','zekharya'}
for name in ['tzefanya','daniyel']:assert name not in display_page.PAGES

workflows={}
for ref in [head,'39e03b9165063ae0784622d7acdf22f2b10c5823']:
    paths=git('ls-tree','-rz','--name-only',ref,'--','.github/workflows').split(b'\0')
    assert [p for p in paths if p]==[b'.github/workflows/pages.yml']
    blob=git('rev-parse',ref+':.github/workflows/pages.yml').decode().strip()
    assert blob=='18ceb19405424710bda47d9a38c470cc2ed9c385'
    workflows[ref]=blob
assert git('status','--porcelain=v1','-z')==b''
summary=dict(base=base,head=head,sibling_inputs_required=False,
             new_data_records=[r for r in records if r['stem'] in {'tzefanya','daniyel'}],
             all_data_records=records,all_base_page_totals=dict(total),base_page_inventory=len(titles),
             projection=projection,projection_verses=sum(x['verses'] for x in projection),
             newly_supported_projection_sites=special,display_pages=displays,
             exact_endpoint_manifest=manifest,workflows=workflows,source_status_empty=True,
             originals='not available or acquired; source metadata is not original extraction evidence')
(OUT/'offline-audit-results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:summary[k] for k in ['base_page_inventory','all_base_page_totals','projection_verses','source_status_empty']},ensure_ascii=False))
print('Display pages:',len(displays),'newly supported projection sites:',len(special))

"""Disposable synthetic DOCX behavior checks; never original-source verification."""
import copy
import hashlib
import json
import pathlib
import sys
import zipfile
from xml.etree import ElementTree as E

ROOT = pathlib.Path('/workspace/scratch/basics-84b504b9')
OUT = pathlib.Path(__file__).parent
sys.path.insert(0, str(ROOT / 'py'))  # Disposable reviewer script, not tracked source.
from miqra_mevoar import books, docx_table, extract

W = docx_table._W
A = docx_table._A
WP = docx_table._WP
PIC = docx_table._PIC
FIXTURES = OUT / 'synthetic-docx'
FIXTURES.mkdir(exist_ok=False)
events = []

def para(text='', style=None, items=None):
    p = E.Element(W+'p')
    if style:
        E.SubElement(E.SubElement(p, W+'pPr'), W+'pStyle', {W+'val': style})
    if text:
        E.SubElement(E.SubElement(p, W+'r'), W+'t').text = text
    if items:
        for item in items:
            E.SubElement(p, W+'r').append(item)
    return p

def draw(frame='inline'):
    d = E.Element(W+'drawing')
    f = E.SubElement(d, WP+frame)
    data = E.SubElement(E.SubElement(f, A+'graphic'), A+'graphicData', {'uri':docx_table._PICTURE_URI})
    E.SubElement(data, PIC+'pic')
    return d

def fc(kind):
    return E.Element(W+'fldChar', {W+'fldCharType':kind})

def ins(text):
    e = E.Element(W+'instrText'); e.text = text; return e

def literal(text):
    e = E.Element(W+'t'); e.text = text; return e

def base():
    doc = E.Element(W+'document'); body=E.SubElement(doc,W+'body')
    tbl=E.SubElement(body,W+'tbl')
    # Four independent row kinds: title, heading, verse and empty.
    rows = [[('',None),('',None),('יהושע','title'),('',None)],
            [('',None),('',None),('',None),('כותרת בדיקה','heading')],
            [('א',None),('א',None),('טקסט מקרא','normal'),('ביאור בדיקה','normal')],
            [('',None),('',None),('',None),('',None)]]
    for row in rows:
        tr=E.SubElement(tbl,W+'tr')
        for text,style in row:
            E.SubElement(tr,W+'tc').append(para(text,style))
    return doc

def body(doc): return doc.find(W+'body')
def cell(doc,row=2,col=3): return body(doc).find(W+'tbl').findall(W+'tr')[row].findall(W+'tc')[col]
def add_draw(doc,row,col,drawing): E.SubElement(cell(doc,row,col).find(W+'p'),W+'r').append(drawing)
def after(doc,items,style='toc1'): body(doc).append(para(style=style,items=items))
def toc_items():
    return [fc('begin'),ins(' T'),ins('OC \\o "1-3" '),fc('separate'),literal('Heading '),
            fc('begin'),ins(' PAGEREF _Toc1 \\h '),fc('separate'),literal('1'),fc('end'),fc('end')]

styles=E.Element(W+'styles')
for key,name in [('title','heading 2'),('heading','heading 3'),('normal','Normal'),('toc1','toc 1')]:
    E.SubElement(E.SubElement(styles,W+'style',{W+'styleId':key}),W+'name',{W+'val':name})

def save(label,doc):
    path=FIXTURES/(label+'.docx')
    with zipfile.ZipFile(path,'w') as z:
        z.writestr('word/document.xml',E.tostring(doc,encoding='utf-8',xml_declaration=True))
        z.writestr('word/styles.xml',E.tostring(styles,encoding='utf-8',xml_declaration=True))
    return path

def case(label,doc,accepted,extra=None):
    path=save(label,doc)
    try:
        table=docx_table.read_table(path)
        if not accepted: raise AssertionError(label+': unexpectedly accepted')
        if extra: extra(table,path)
        events.append(dict(case=label,result='accepted',rows=len(table.rows),pictures=[dict(row=p.row,cell=p.cell) for p in table.pictures]))
    except ValueError as error:
        if accepted: raise
        events.append(dict(case=label,result='refused',error=str(error)))

case('plain',base(),True)
doc=base()
for row,col,frame in [(0,2,'inline'),(1,3,'anchor'),(2,1,'inline'),(3,0,'anchor')]: add_draw(doc,row,col,draw(frame))
def verify_extract(table,path):
    assert [(p.row,p.cell) for p in table.pictures]==[(0,2),(1,3),(2,1),(3,0)]
    record,bible,pictures=extract.extract_book(path,books.book_of_stem('yehoshua'))
    assert record['chapters']==[dict(chapter=1,verses=[dict(verse=1,heading='כותרת בדיקה',paraphrase='ביאור בדיקה')])]
    assert bible=={(1,1):'טקסט מקרא'}
    assert record['source']['sha256']==hashlib.sha256(path.read_bytes()).hexdigest()
    assert record['source']['size']==path.stat().st_size
    assert len(pictures)==4
    for line,place in zip(pictures,['the title row','the heading of 1:1','1:1','an empty row']): assert '('+place+')' in line
    events.append(dict(case='picture-extraction-locations-and-source-metadata',result='accepted',reports=pictures))
case('pictures-four-row-kinds',doc,True,verify_extract)
doc=base();add_draw(doc,2,1,draw());add_draw(doc,2,1,draw('anchor'));case('two-pictures-one-cell',doc,True,lambda t,p: (_ for _ in ()).throw(AssertionError()) if len(t.pictures)!=2 else None)
doc=base();after(doc,toc_items());case('split-toc-with-pageref',doc,True)
doc=base();after(doc,[fc('begin'),ins(' TOC '),fc('end')]);case('toc-no-result',doc,True)
doc=base();after(doc,[]);case('empty-after-table',doc,True)
doc=base();after(doc,[fc('begin'),ins(' TOC '),fc('separate')]);after(doc,[literal('Heading'),fc('end')]);case('toc-across-paragraphs',doc,True)
for place in ['before','after']:
    doc=base();p=para(items=[draw()])
    body(doc).insert(0,p) if place=='before' else body(doc).append(p)
    case('picture-'+place,doc,False)
for label,mutation in [
    ('wrong-frame', lambda d: setattr(d[0],'tag',WP+'wrong')),
    ('two-frames', lambda d: d.append(copy.deepcopy(d[0]))),
    ('wrong-uri', lambda d: d[0][0][0].set('uri','different')),
    ('two-pics', lambda d: d[0][0][0].append(E.Element(PIC+'pic'))),
    ('word-text', lambda d: d[0].append(E.Element(W+'t'))),
    ('drawing-text', lambda d: d[0][0][0][0].append(E.Element(A+'t'))),
    ('text-box', lambda d: d[0][0][0][0].append(E.Element(A+'txbx'))),
    ('text-body', lambda d: d[0][0][0][0].append(E.Element(A+'txBody'))),
    ('no-graphic', lambda d: d[0].remove(d[0][0])),
    ('non-picture-graphic', lambda d: setattr(d[0][0][0][0],'tag',A+'shape'))]:
    doc=base();d=draw();mutation(d);add_draw(doc,2,1,d);case(label,doc,False)
for label,items,style in [
    ('text-without-field',[literal('unexpected')],'toc1'),
    ('instruction-without-field',[ins(' TOC ')],'toc1'),
    ('end-without-field',[fc('end')],'toc1'),
    ('separator-without-field',[fc('separate')],'toc1'),
    ('wrong-outer',[fc('begin'),ins(' DATE '),fc('end')],'toc1'),
    ('missing-end',toc_items()[:-1],'toc1'),
    ('double-separator',[fc('begin'),ins(' TOC '),fc('separate'),fc('separate'),fc('end')],'toc1'),
    ('second-outer',toc_items()+[fc('begin'),ins(' TOC '),fc('end')],'toc1'),
    ('text-in-instruction',[fc('begin'),ins(' TOC '),literal('hidden'),fc('end')],'toc1'),
    ('wrong-result-style',toc_items(),'normal'),
    ('nested-in-instruction',[fc('begin'),ins(' TOC '),fc('begin')],'toc1'),
    ('nested-wrong-command',[fc('begin'),ins(' TOC '),fc('separate'),fc('begin'),ins(' DATE '),fc('end'),fc('end')],'toc1'),
    ('too-deep',[fc('begin'),ins(' TOC '),fc('separate'),fc('begin'),ins(' PAGEREF x '),fc('separate'),fc('begin')],'toc1'),
    ('instruction-in-result',[fc('begin'),ins(' TOC '),fc('separate'),ins(' text '),fc('end')],'toc1'),
    ('unknown-character',[fc('unknown')],'toc1')]:
    doc=base();after(doc,items,style);case(label,doc,False)
for place in ['before','table']:
    for label,item in [('field',fc('begin')),('instruction',ins(' TOC '))]:
        doc=base()
        if place=='before':body(doc).insert(0,para(items=[item]))
        else:E.SubElement(cell(doc).find(W+'p'),W+'r').append(item)
        case(label+'-'+place,doc,False)
for label,mutation in [('unknown-body', lambda d: body(d).append(E.Element(W+'unknown'))),
                       ('unknown-run', lambda d: E.SubElement(cell(d).find(W+'p'),W+'r').append(E.Element(W+'unknown')))]:
    doc=base();mutation(doc);case(label,doc,False)

(OUT/'parser-fixture-results.json').write_text(json.dumps(dict(synthetic_only=True,events=events,accepted=sum(x['result']=='accepted' for x in events),refused=sum(x['result']=='refused' for x in events)),ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(f"Synthetic-only outcomes: {len(events)}, {sum(x['result']=='accepted' for x in events)} accepted, {sum(x['result']=='refused' for x in events)} refused as expected")

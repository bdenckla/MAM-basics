"""Run one bounded check from the exact source root and retain its real result."""
import datetime
import json
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path('/workspace/scratch/basics-84b504b9')
OUT = pathlib.Path(__file__).parent
label, *command = sys.argv[1:]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.perf_counter()
with (OUT / (label + '.txt')).open('wb') as log:
    result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
record = dict(command=command, cwd=str(ROOT), started_utc=started,
              wall_seconds=round(time.perf_counter()-clock, 6), exit_code=result.returncode)
(OUT / (label + '.json')).write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8', newline='\n')
for args, suffix in [(['git', 'status', '--porcelain=v1', '-z'], '-status.bin'),
                     (['git', 'diff', '--binary'], '-diff.patch')]:
    (OUT / (label + suffix)).write_bytes(subprocess.check_output(args, cwd=ROOT))
print(json.dumps(record))
print((OUT / (label + '.txt')).read_text(encoding='utf-8'))
sys.exit(result.returncode)

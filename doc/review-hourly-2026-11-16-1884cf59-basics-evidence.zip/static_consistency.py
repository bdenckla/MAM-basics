"""Offline container/data checks; never imports or executes the frozen study."""
from pathlib import Path, PurePosixPath
import collections
import hashlib
import json
import re
import stat
import subprocess
import unicodedata
import zipfile

ROOT = Path('/workspace/scratch/basics-1884cf59')
ART = Path(__file__).parent
BASE = '2a108647c4b17e587a00549eb9fa8de8958e0e3e'
archive = ROOT / 'doc/mam-morphhb-pull-requests/decalogue-strands-2026-11-15/work-folder.zip'
rows = []
with zipfile.ZipFile(archive) as z:
    names = z.namelist()
    assert len(names) == len(set(names))
    for i in z.infolist():
        p = PurePosixPath(i.filename)
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename
        assert ':' not in i.filename and not stat.S_ISLNK(i.external_attr >> 16)
        assert i.file_size < 20_000_000
        rows.append(dict(path=i.filename, size=i.file_size, compressed=i.compress_size,
                         crc32=f'{i.CRC:08x}', sha256=hashlib.sha256(z.read(i)).hexdigest()))
    assert sum(i.file_size for i in z.infolist()) < 30_000_000
    assert z.testzip() is None
    assert not any('__pycache__' in n or n.endswith('.pyc') for n in names)
    assert any(n.endswith('/out/decisions.html') for n in names)
    assert any('/inputs/folder-S/out/22-clc-answers.json' in n for n in names)
    bases = [n for n in names if '/base/' in n and n.endswith('.xml')]
    xml_files = [n for n in names if n.endswith('.xml')]
(ART / 'archive-inventory.json').write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8')
patch = (archive.parent / 'change.diff').read_bytes()
patch_paths = re.findall(rb'^diff --git a/(\S+) b/(\S+)$', patch, re.M)
assert patch_paths == [(b'wlc/Gen.xml', b'wlc/Gen.xml'), (b'wlc/Exod.xml', b'wlc/Exod.xml'), (b'wlc/Deut.xml', b'wlc/Deut.xml')], patch_paths

source_paths = subprocess.check_output(['git','diff','--name-only','-z',BASE,'HEAD'], cwd=ROOT).decode().strip('\0').split('\0')
assert len(source_paths) == 89
blobs = []
for p in source_paths:
    data = (ROOT / p).read_bytes()
    blob = subprocess.check_output(['git','rev-parse',f'HEAD:{p}'], cwd=ROOT).decode().strip()
    committed = subprocess.check_output(['git','show',f'HEAD:{p}'], cwd=ROOT)
    assert data == committed
    blobs.append(dict(path=p, git_blob=blob, size=len(data), sha256=hashlib.sha256(data).hexdigest()))
(ART / 'endpoint-manifest.json').write_text(json.dumps(blobs, indent=2) + '\n', encoding='utf-8')
assert not any(p.startswith(('gh-pages/', 'MAM-simple/', 'MAM-parsed/', 'Taamey-D/')) for p in source_paths)
assert subprocess.check_output(['git','status','--porcelain'], cwd=ROOT) == b''
workflow_path = '.github/workflows/pages.yml'
workflow_blob = subprocess.check_output(['git','rev-parse',f'HEAD:{workflow_path}'], cwd=ROOT).decode().strip()
assert workflow_blob == '18ceb19405424710bda47d9a38c470cc2ed9c385'
assert subprocess.check_output(['git','rev-parse',f'40d303d15ef8eed5d2142a551a06063d9813874a:{workflow_path}'], cwd=ROOT).decode().strip() == workflow_blob
workflow_paths = subprocess.check_output(['git','ls-tree','-r','--name-only','-z','HEAD','.github/workflows'], cwd=ROOT).decode().strip('\0').split('\0')
assert workflow_paths == [workflow_path]
new_stems = ['mikha', 'nahum', 'havaquq', 'hagay', 'zekharya']
all_records = {p.stem: json.loads(p.read_text(encoding='utf-8')) for p in (ROOT / 'in/miqra-mevoar').glob('*.json')}
assert len(all_records) == 11
counts = {}
old_chars, new_chars = set(), set()
for stem, rec in all_records.items():
    if stem not in new_stems:
        assert (ROOT / f'in/miqra-mevoar/{stem}.json').read_bytes() == subprocess.check_output(['git','show',f'{BASE}:in/miqra-mevoar/{stem}.json'], cwd=ROOT)
    assert set(rec) == {'book', 'source', 'chapters'}
    assert set(rec['source']) == {'file','size','sha256'}
    assert rec['source']['file'] == stem + '.docx'
    assert isinstance(rec['source']['size'], int) and rec['source']['size'] > 0
    assert re.fullmatch('[0-9a-f]{64}', rec['source']['sha256'])
    verses, headings = 0, 0
    for cnum, chapter in enumerate(rec['chapters'], 1):
        assert chapter['chapter'] == cnum
        for vnum, verse in enumerate(chapter['verses'], 1):
            assert verse['verse'] == vnum
            verses += 1
            headings += verse['heading'] is not None
            for field in ('heading','paraphrase'):
                if verse[field] is not None:
                    (new_chars if stem in new_stems else old_chars).update(verse[field])
    counts[stem] = dict(chapters=len(rec['chapters']), verses=verses, headings=headings,
                        source_sha256=rec['source']['sha256'], source_size=rec['source']['size'])
assert sum(counts[s]['chapters'] for s in new_stems) == 29
assert sum(counts[s]['verses'] for s in new_stems) == 457
assert sum(counts[s]['headings'] for s in new_stems) == 43
assert not (new_chars - old_chars)

preview = ART / 'miqra-preview'
if preview.exists():
    title_rows = (preview / 'titles.tsv').read_text(encoding='utf-8').splitlines()
    mapping = dict(row.split('\t') for row in title_rows)
    assert len(title_rows) == len(mapping) == len(set(mapping.values())) == 85
    expected_files = {'titles.tsv'}
    for stem, rec in all_records.items():
        for chapter in rec['chapters']:
            rel = f"{stem}/{chapter['chapter']:02d}.wiki"
            expected_files.add(rel)
            assert rel in mapping
            text = (preview / rel).read_text(encoding='utf-8')
            assert text == unicodedata.normalize('NFC', text)
            assert not text.endswith('\n')
            lines = text.splitlines()
            assert lines[0].startswith('==פרק ') and lines[0].endswith('==')
            assert lines[-1] == '[[קטגוריה:מקרא מבואר]]'
            payloads = []
            for line in lines[1:-1]:
                match = re.fullmatch(r'(\*)?<קטע התחלה=([^/]+)/>(.*)<קטע סוף=([^/]+)/>', line)
                assert match and match[2] == match[4]
                payloads.append((bool(match[1]), match[3]))
            expected = []
            for verse in chapter['verses']:
                if verse['heading'] is not None:
                    expected.append((True, unicodedata.normalize('NFC', verse['heading'])))
                expected.append((False, unicodedata.normalize('NFC', verse['paraphrase'])))
            assert payloads == expected
    assert {p.relative_to(preview).as_posix() for p in preview.rglob('*') if p.is_file()} == expected_files

figures = json.loads((ROOT / 'morphhb-on-mam/out/30-figures.json').read_text(encoding='utf-8'))
total = figures['mam_atoms']
assert total == sum(figures['mam_atoms_by_sides'].values()) == sum(figures['classes'].values()) == sum(figures['tiers'].values())
for tier, value in figures['tiers'].items():
    assert value == sum(n for key,n in figures['tier_by_class'].items() if key.split('/')[0] == tier)
    assert figures['tiers_percent'][tier] == round(value / total * 100, 2)
for cls, value in figures['classes'].items():
    assert value == sum(n for key,n in figures['tier_by_class'].items() if key.split('/')[1] == cls)
tree = json.loads((ROOT / 'morphhb-on-mam/in/fetched/morphhb-wlctree-1.json').read_text(encoding='utf-8'))
assert tree['truncated'] is False
assert len(tree['tree']) == 40 and all(i['type'] == 'blob' for i in tree['tree'])
assert len({i['path'] for i in tree['tree']}) == 40
assert all(re.fullmatch('[0-9a-f]{40}', i['sha']) for i in tree['tree'])
assert sum(i['path'] == 'VerseMap.xml' for i in tree['tree']) == 1
result = dict(
    endpoint_paths=89, changed_python_paths=sum(p.endswith('.py') for p in source_paths),
    committed_bytes='all 89 endpoint files match source commit; earlier six Miqra records unchanged',
    workflow=dict(sole_workflow=workflow_path, blob=workflow_blob, source_and_receipt_parent_equal=True),
    archive=dict(members=len(rows), compressed_bytes=archive.stat().st_size,
                 uncompressed_bytes=sum(i['size'] for i in rows),
                 sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
                 crc='all members valid', safe_paths=True,
                 xml_members=xml_files, patch_targets=[a.decode() for a,b in patch_paths]),
    miqra=counts, new_books=dict(chapters=29,verses=457,headings=43,
                new_character_inventory='subset of six earlier books'),
    preview=dict(pages=85,new_book_pages=29,exact_payloads='all headings and paraphrases after specified NFC',
                 title_rows=85) if preview.exists() else 'not yet run',
    frozen_figures=dict(atoms=total, internally_consistent=True, source_or_alignment_independently_verified=False),
    captured_morphhb_tree=dict(blobs=40,original_xml_verified=False),
    limitations='Static records/container consistency only; no study/archive code executed; no XML or Word sources acquired; no research or editorial correctness established.'
)
(ART / 'static-consistency.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2, ensure_ascii=False))

from pathlib import Path
import datetime
import json
import subprocess
import time

ROOT = Path('/workspace/scratch/basics-1884cf59')
ART = Path(__file__).parent
PY = '/workspace/MAM-basics/.venv/bin/python'
paths = (ART / 'endpoint-paths.z').read_bytes().decode().strip('\0').split('\0')
changed_py = [p for p in paths if p.endswith('.py')]
checks = [
    ('diff-check', ['git', 'diff', '--check', '2a108647c4b17e587a00549eb9fa8de8958e0e3e', '1884cf59c47d85d8cb74ec3f2a2a26015444e431']),
    ('black-check', [PY, '-m', 'black', '--check', *changed_py]),
    ('focused-tests', [PY, 'py/main_test.py',
        'py/tests/test_mega_coverage.py',
        'py/tests/test_miqra_mevoar_versification.py',
        'py/tests/test_miqra_mevoar_display.py',
        'py/tests/test_miqra_mevoar_index.py',
        'py/tests/test_miqra_mevoar_save_receipts.py',
        'py/tests/test_miqra_mevoar_bot_revision_guard.py',
        'py/tests/test_prose_conventions.py',
        'py/tests/test_prose_mark_order.py',
        'py/tests/test_tracked_filenames.py',
        'py/tests/test_h_dot_below_nfc.py',
        'py/tests/test_cgj_between_marks.py',
        'py/tests/test_receipt_update_links.py',
        'py/tests/test_no_machine_paths_in_artifacts.py',
        'py/tests/test_worktree_retirement_citations.py',
        'py/tests/test_repo_visibility_declared.py',
        'py/tests/test_stderr_error_handler.py', '-q']),
    ('entrypoint-lint', [PY, 'py/main_test.py', 'py/tests/test_entry_point_subcommands.py', '-k', 'main_morphhb_on_mam', '-q']),
    ('miqra-preview', [PY, 'py/main_miqra_mevoar.py', 'pages', '--out', str(ART / 'miqra-preview')]),
]
results = []
for name, command in checks:
    assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT) == b''
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    tick = time.monotonic()
    result = subprocess.run(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    duration = time.monotonic() - tick
    (ART / (name + '.txt')).write_bytes(result.stdout)
    row = dict(name=name, command=command, cwd=str(ROOT), started_utc=start,
               exit=result.returncode, seconds=round(duration, 6))
    results.append(row)
    (ART / 'commands.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(row), flush=True)
    print(result.stdout.decode('utf-8', errors='replace')[-2000:], flush=True)
    if result.returncode:
        break

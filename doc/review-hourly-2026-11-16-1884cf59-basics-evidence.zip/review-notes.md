# Static review notes

Bounded public source: `2a108647c4b17e587a00549eb9fa8de8958e0e3e` ->
`1884cf59c47d85d8cb74ec3f2a2a26015444e431`, six reachable commits, 89 endpoint paths.
No consequential introduced defect established; no product repair prepared.

The independent read-only study pass read all 17 new study Python files (6,147 lines),
README, page specification/fragment, decisions page, research reports/check ledger and key
frozen records. The CLI verifies morphhb before its `all` pipeline; verification checks
listing integrity, exact directory inventory and Git blob contents. Paths use `mb_cmn.paths`,
the page rejects a work directory outside the repository, and the readers use closed
dispatch. Text display uses MAM-normal ordering; JSON retains source forms. These are source
observations, not executions of those paths. All seven CLI commands have an explicit on-ice
mega exemption, and no new mega step reads the study or Miqra records.

Consequential source paths inspected include `py/main_morphhb_on_mam.py`'s guarded `all`
dispatch (near line 115), `verify.py`'s inventory/blob checks (near line 44),
`record_paths.py`'s repository-relative work-directory rejection (near line 67),
`mam_reader.py`'s explicit element/strand dispatch, `morphhb_reader.py`'s XML/note reader and
form keys, `align.py`'s alignment classes, `analyze*.py`/`figures.py`'s record reductions,
`views.py`/`strands.py`'s displayed forms, and `build_page.py`/`page_check.py`/
`page_text.py`/`page_selftest.py`'s page contracts. No study stage/subcommand, selftest or
regeneration ran. The maintained entrypoint lint does import the module and dependencies and
call `build_parser()`, including parser defaults; that bounded parser-construction coverage
does not execute a study stage. The independent container/data checker imports no study code.

The archived specification `morphhb-on-mam/in/page-spec.md`, near its class-B slash example,
says 529/627. The frozen page/outputs say 549/650; the builder reads those values from its
output inputs. This is a bounded historical specification discrepancy, left unchanged in
the frozen record, not evidence of a current generated-page defect.

The archived Decalogue README leaves 14 decisions open and the draft unposted. Only ZIP
inventory/path/CRC/member hashing and patch target inspection were performed. No archived
script was executed, draft reconstructed or remote state reread. Original-folder equality,
draft grammatical/editorial correctness and historical upstream state remain attributed.

Miqra's five new registrations agree with the eleven-record inventory. The maintained tests
compare every record's numbering with current committed MAM-simple and reject hazardous
page payloads. The independent container/data checker counts 29 new chapters, 457 verses and
43 headings and checks all 85 preview pages' headings/paraphrases against the tracked JSON
under the specified NFC page contract. The old six JSON files are unchanged. Recorded DOCX
size/hash fields have valid shape, but the omitted DOCX files were not read or verified.
The new character inventory is a subset of the old six books. No source JSON is normalized.

The PLAN's editorial decisions, source research, pCloud reach/security assertions, live
dry-run results, email preparation and future saves remain their authors' attributed
records. This task performs no online fetch, probe, correspondence or save.

No sibling input is needed by these selected checks. Private was not review material.
No current study stage, omitted input, native Windows, browser, font, external-source or
manuscript correctness is established. Broad checks await their separate scheduled owner.

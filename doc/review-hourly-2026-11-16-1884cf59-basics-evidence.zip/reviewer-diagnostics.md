# Reviewer setup diagnostics

These read-only setup mistakes occurred before product checks; no product mutation resulted.

- `pwd && rg --files -g 'AGENTS.md' -g '*slot.json' -g '**/*slot/owner.json' -g 'activate.sh' /workspace /tmp 2>/dev/null`: exit 2 while listing; declared slot files were subsequently read using only the two explicit coordination patterns. All 46 existing slots were released. No recursive scan of private evidence owner files was used.
- `git status --short && git rev-parse HEAD && git worktree list --porcelain && git show-ref --verify refs/remotes/origin/review-hourly-20261113-7173440e-basics-receipts`: exit 128 because this saved clone has no remote-tracking ref for the receipt branch. Home was clean at the expected commit. An ordinary exact-branch fetch followed by `git ls-remote` verified the actual remote parent `40d303d15ef8eed5d2142a551a06063d9813874a`; no stale local tip was used.
- `git show 1884cf59:doc/research/decalogue-strands-2026-11-15/README.md && git show 1884cf59:doc/PLAN-miqra-mevoar.md && git show 1884cf59:miqra-mevoar/README.md`: exit 128 at the first nonexistent path, so later commands in that chain did not execute. The NUL-delimited endpoint inventory identified `doc/mam-morphhb-pull-requests/decalogue-strands-2026-11-15/README.md` and `in/miqra-mevoar/README.md`; both correct current files and the PLAN were read before selecting execution.

No product command/check failed or was retried. The static data/container checker first
passed (tool wall 0.082708 s), then passed again after adding the committed-byte manifest,
workflow and earlier-JSON comparisons (tool wall 0.848290 s). Both exit codes were 0;
the second pass did not rerun a generator or a test.

PUBLIC bounded offline downloader evidence; source 73fbf0406b8cf843b2aabcbb8ef0b558d0fa7148..9a0ec239d7f45faff7487e4dfae8369f269a5f2d.
19 maintained tests / 8 subtests and nine independent probes pass; original import-time guard diagnostic retained. No real HTTP requests or broad run.
To reproduce maintained tests, copy the offline-guard checker to a unique py/novc_downloader_offline_guard.py in an isolated exact checkout, set MAM_DOWNLOADER_OFFLINE_REPORT, and pass -p novc_downloader_offline_guard to the two recorded py/main_test.py targets. Remove the temporary plugin afterward. No import-path shim is used.
Spacing checker arguments: HEAD_DOWNLOADER_PATH BASE_DOWNLOADER_PATH RESULT_JSON. Exact base/head downloader bytes are retained. Read before execution. Fake sessions and clocks/events only; sockets blocked.
Caller context is a tracked static census; arbitrary external streaming sessions and interprocess/global network pacing are not covered.

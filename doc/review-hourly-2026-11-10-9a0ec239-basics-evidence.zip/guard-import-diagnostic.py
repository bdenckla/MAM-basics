"""Identify the blocked import-time socket capability check without HTTP requests."""

import json
from pathlib import Path
import sys
import traceback

events = []


def audit(event, args):
    if event in {
        "socket.__new__",
        "socket.connect",
        "socket.getaddrinfo",
        "socket.sendto",
    }:
        events.append(dict(event=event, frames=traceback.format_stack()))
        raise RuntimeError("Offline diagnostic rejects socket operation")


sys.addaudithook(audit)
import urllib3.util.connection

assert len(events) == 1 and events[0]["event"] == "socket.__new__"
assert any("_has_ipv6" in frame for frame in events[0]["frames"])
assert urllib3.util.connection.HAS_IPV6 is False
result = dict(
    result="PASS",
    observed_import="urllib3.util.connection",
    events=events,
    conclusion="urllib3 probes IPv6 by creating a socket for loopback ::1 at import; the guard rejects creation and urllib3 treats the capability as unavailable. No connect/DNS/sendto event occurred. This is guard/recorder diagnostic evidence, not a product failure or repeated maintained test.",
)
Path(sys.argv[1]).write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(
    json.dumps(
        dict(result="PASS", blocked_import_capability_probe=True, outbound_attempts=[])
    )
)

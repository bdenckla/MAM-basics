import ast
import json
import re
import subprocess
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path('/workspace/MAM-basics')
OUT = Path('/workspace/scratch/review-hourly-20261030-1700/basics')
BASE = 'c706d24d71b3213e5e4d9531e9d69dcba218c49a'
NAMES = {'render_wikitext_added_lines': 'render_wikitext_added_clauses', 'added_lines': 'added_clauses', 'labelled_line': 'labelled_clause', 'flag_lines': 'flag_clauses', 'english_flag_lines': 'english_flag_clauses', '_added_lines': '_added_clauses', '_mam_target_line': '_mam_target_clause', 'mam_line': 'mam_clause', 'lines': 'labelled'}


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])


class Renamed(ast.NodeTransformer):
    def generic_visit(self, node):
        super().generic_visit(node)
        if isinstance(node, ast.FunctionDef):
            node.name = NAMES.get(node.name, node.name)
        if isinstance(node, ast.Name):
            node.id = NAMES.get(node.id, node.id)
        if isinstance(node, ast.Attribute):
            node.attr = NAMES.get(node.attr, node.attr)
        if isinstance(node, ast.alias):
            node.name = NAMES.get(node.name, node.name)
            node.asname = NAMES.get(node.asname, node.asname)
        return node


def test_renderer_alpha_rename_is_behavior_preserving():
    pairs = [
        ('py/render_wt/render_wikitext_added_lines.py', 'py/render_wt/render_wikitext_added_clauses.py'),
        ('py/render_wt/render_wikitext_handlers.py', 'py/render_wt/render_wikitext_handlers.py'),
        ('py/render_wt/render_wikitext_kq.py', 'py/render_wt/render_wikitext_kq.py'),
    ]
    for old_path, new_path in pairs:
        old = ast.parse(git('show', BASE + ':' + old_path))
        new = ast.parse((ROOT / new_path).read_text(encoding='utf-8'))
        assert ast.dump(Renamed().visit(old)) == ast.dump(Renamed().visit(new)), new_path
    old = ast.parse(git('show', BASE + ':py/sigils/inventory.py'))
    old.body = [n for n in old.body if not (isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and n.targets[0].id == '_CLAUSE_BOUNDARY_RE')]
    assert ast.dump(old) == ast.dump(ast.parse((ROOT / 'py/sigils/inventory.py').read_text(encoding='utf-8')))
    assert not (ROOT / pairs[0][0]).exists()


class Shape(HTMLParser):
    def __init__(self):
        super().__init__()
        self.events = []
        self.text = []
    def handle_starttag(self, name, attrs): self.events.append(('start', name, attrs))
    def handle_startendtag(self, name, attrs): self.events.append(('single', name, attrs))
    def handle_endtag(self, name): self.events.append(('end', name))
    def handle_data(self, text): self.text.append(text)
    def handle_comment(self, text): self.events.append(('comment', text))


def test_generated_endpoint_changes_only_words_not_structure_or_hebrew():
    paths = [p.decode() for p in git('diff', '--name-only', '-z', BASE, 'HEAD', '--', 'gh-pages').split(b'\0') if p]
    assert len(paths) == 4
    for path in paths:
        old, new = Shape(), Shape()
        old.feed(git('show', BASE + ':' + path).decode('utf-8'))
        new.feed((ROOT / path).read_text(encoding='utf-8'))
        assert old.events == new.events, path
        before, after = ''.join(old.text), ''.join(new.text)
        assert re.findall(r'[\u0590-\u05ff\ufb1d-\ufb4f\u034f]', before) == re.findall(r'[\u0590-\u05ff\ufb1d-\ufb4f\u034f]', after), path
        assert re.findall(r'\d+', before) == re.findall(r'\d+', after), path
    (OUT / 'endpoint-audit.json').write_text(json.dumps({'generated_pages': paths, 'all_html_structure_attributes_links_comments_hebrew_and_numbers_equal': True, 'renderer_alpha_rename_verified': True, 'only_unused_sigil_constant_removed': True}, indent=2) + '\n')

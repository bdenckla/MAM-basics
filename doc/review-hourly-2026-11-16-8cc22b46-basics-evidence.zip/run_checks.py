"""Sequential focused commands; preserve exact output, status and exit codes."""
import datetime
import json
import subprocess
import time
from pathlib import Path

ROOT = Path('/workspace/scratch/basics-8cc22b46')
ART = Path('/workspace/scratch/basics-8cc22b46-artifacts')
PY = '/workspace/MAM-basics/.venv/bin/python'
commands = [
    ('endpoint-diff-check', ['git', 'diff', '--check', 'b41f31668958bdaade9a9846fbbf07aa75f76fac', '8cc22b46348651dd6e2f04c6a013e77157026ded']),
    ('black', [PY, '-m', 'black', '--check', 'py/miqra_mevoar/books.py', 'py/miqra_mevoar/display_page.py', 'py/miqra_mevoar/extract.py']),
    ('focused-tests', [PY, 'py/main_test.py', 'py/tests/test_miqra_mevoar_display.py', 'py/tests/test_miqra_mevoar_versification.py', 'py/tests/test_miqra_mevoar_index.py', 'py/tests/test_miqra_mevoar_save_receipts.py', 'py/tests/test_miqra_mevoar_bot_revision_guard.py', '-q']),
    ('style-fixtures', [PY, str(ART/'verify_styles.py')]),
    ('base-pages', [PY, 'py/main_miqra_mevoar.py', 'pages', '--out', str(ART/'base-pages')]),
    ('offline-oracles', [PY, str(ART/'verify_outputs.py')]),
]
results=[]
for name, argv in commands:
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='8cc22b46348651dd6e2f04c6a013e77157026ded'
    assert not subprocess.check_output(['git','status','--porcelain=v1','-z'],cwd=ROOT)
    start=datetime.datetime.now(datetime.timezone.utc).isoformat(); tick=time.monotonic()
    with (ART/(name+'.txt')).open('wb') as log:
        p=subprocess.run(argv,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
    duration=time.monotonic()-tick
    status=subprocess.check_output(['git','status','--porcelain=v1','-z'],cwd=ROOT)
    diff=subprocess.check_output(['git','diff','--binary'],cwd=ROOT)
    (ART/(name+'-status.bin')).write_bytes(status)
    (ART/(name+'-diff.patch')).write_bytes(diff)
    row={'name':name,'argv':argv,'cwd':str(ROOT),'started_utc':start,'seconds':round(duration,6),'exit':p.returncode,'status_bytes':len(status),'diff_bytes':len(diff)}
    results.append(row); (ART/'checks.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    if p.returncode or status or diff:
        raise SystemExit(p.returncode or 1)

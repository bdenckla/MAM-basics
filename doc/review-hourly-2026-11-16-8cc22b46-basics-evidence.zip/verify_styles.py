"""Disposable new-style DOCX probes; not original-source verification."""
import copy
import hashlib
import json
import sys
import tempfile
import zipfile
from pathlib import Path
from xml.etree import ElementTree as E

ROOT=Path('/workspace/scratch/basics-8cc22b46')
ART=Path('/workspace/scratch/basics-8cc22b46-artifacts')
sys.path.insert(0,str(ROOT/'py'))  # Disposable scratch only, never tracked source.
from miqra_mevoar import books, extract

W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
E.register_namespace('w',W[1:-1])
styles={'lo2':'heading 2','up2':'Heading 2','lo3':'heading 3','lo4':'heading 4','up4':'Heading 4','normal':'Normal','unknown':'Heading 3','shout':'HEADING 2','space':'Heading 2 ','other':'Custom'}
paraphrase='שָׁפַט העם בשלום.'
heading='ראשית המשפט'
book=books.BOOKS['sephershoftim']

def fixture(path, rows, style_map):
    doc=E.Element(W+'document'); body=E.SubElement(doc,W+'body'); table=E.SubElement(body,W+'tbl')
    for cells in rows:
        row=E.SubElement(table,W+'tr')
        for paras in cells:
            cell=E.SubElement(row,W+'tc')
            for style,text in paras:
                para=E.SubElement(cell,W+'p')
                if style is not None:
                    pp=E.SubElement(para,W+'pPr'); E.SubElement(pp,W+'pStyle',{W+'val':style})
                run=E.SubElement(para,W+'r'); E.SubElement(run,W+'t').text=text
    ss=E.Element(W+'styles')
    for ident,name in style_map.items():
        st=E.SubElement(ss,W+'style',{W+'styleId':ident}); E.SubElement(st,W+'name',{W+'val':name})
    with zipfile.ZipFile(path,'w') as z:
        z.writestr('word/document.xml',E.tostring(doc,encoding='utf-8',xml_declaration=True))
        z.writestr('word/styles.xml',E.tostring(ss,encoding='utf-8',xml_declaration=True))

def rows(title='up2',head='up4',normal='normal'):
    return [[[],[],[(title,'שפטים')],[]],[[],[],[],[(head,heading)]],[[(normal,'א')],[(normal,'א')],[(normal,'טקסט')],[(normal,paraphrase)]]]

cases=[]
for title in ['lo2','up2']:
    for head in ['lo3','lo4','up4']:
        cases.append((f'{title}-{head}-Normal',rows(title,head),styles,True))
cases.append(('legacy-unstyled-verse',rows('lo2','lo3',None),styles,True))
blank=rows(); blank[0][2].append(('other','  '))
cases.append(('blank-unknown-paragraph-ignored',blank,styles,True))
for title in ['unknown','normal','shout','space','other']:
    cases.append((f'refuse-title-{title}',rows(title),styles,False))
for head in ['unknown','normal','other']:
    cases.append((f'refuse-lone-heading-{head}',rows(head=head),styles,False))
for second in ['lo2','normal']:
    mixed=rows(); mixed[0][2]=[('up2','שפ'),(second,'טים')]
    cases.append((f'refuse-mixed-title-{second}',mixed,styles,False))
verse=rows(); verse[2][3]=[('up4',paraphrase)]
cases.append(('refuse-heading-style-in-verse',verse,styles,False))
cases.append(('refuse-unmapped-style-id',rows('absent'),styles,False))
wrong=rows(); wrong[0][2]=[('up2','שופטים')]
cases.append(('refuse-source-title-with-added-vav',wrong,styles,False))
observed=[]
with tempfile.TemporaryDirectory(prefix='style-docx-',dir=ART) as tmp:
    for name,rr,ss,accepted in cases:
        path=Path(tmp)/'sephershoftim.docx'; fixture(path,rr,ss)
        try:
            record,bible,pictures=extract.extract_book(path,book)
        except ValueError as e:
            assert not accepted,(name,str(e))
            observed.append({'case':name,'expected':'refuse','actual':'ValueError','reason':str(e)})
        else:
            assert accepted,name
            expected={'book':'שופטים','source':{'file':'sephershoftim.docx','size':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()},'chapters':[{'chapter':1,'verses':[{'verse':1,'heading':heading,'paraphrase':paraphrase}]}]}
            assert record==expected and bible=={(1,1):'טקסט'} and pictures==[],name
            observed.append({'case':name,'expected':'accept','actual':'exact-extracted-payload-and-metadata'})
(ART/'style-fixtures.json').write_text(json.dumps(observed,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'outcomes':len(observed),'accepted':sum(x['expected']=='accept' for x in observed),'refused':sum(x['expected']=='refuse' for x in observed),'source_title':'שפטים','canonical_book':'שופטים','fixture_paraphrase_codepoints':[f'U+{ord(c):04X}' for c in paraphrase]},ensure_ascii=False))

"""Offline raw-input oracles and retained-preview comparison, no source acquisition."""
import collections
import hashlib
import json
import re
import sys
import unicodedata
from pathlib import Path

ROOT=Path('/workspace/scratch/basics-8cc22b46')
ART=Path('/workspace/scratch/basics-8cc22b46-artifacts')
OLD=Path('/workspace/scratch/basics-84b504b9-artifacts/base-pages')
sys.path.insert(0,str(ROOT/'py'))  # Disposable scratch only.
from mb_cmn import hebrew_verse_numerals as hvn
from miqra_mevoar import books, display_page

records={p.stem:json.loads(p.read_text(encoding='utf-8')) for p in sorted((ROOT/'in/miqra-mevoar').glob('*.json'))}
assert len(records)==15
assert set(records)==set(books.BOOKS)
assert books.BOOKS['sephershoftim'].title=='שפטים'
assert books.BOOKS['sephershoftim'].bk39_name()=='שופטים'
assert 'sephershoftim' not in display_page.PAGES and 'daniyel' not in display_page.PAGES
numeral=hvn.INT_TO_STR_DIC
out=ART/'base-pages'
expected_titles=[]; payload_counts={}; file_manifest={}; total_verses=total_headings=0
for stem,record in records.items():
    nv=nh=0
    for chapter in record['chapters']:
        c=chapter['chapter']; assert c==record['chapters'].index(chapter)+1
        lines=[f'==פרק {numeral[c]}==']
        for at,verse in enumerate(chapter['verses'],1):
            assert verse['verse']==at
            v=numeral[at]; nv+=1
            if verse['heading'] is not None:
                h=verse['heading']; nh+=1
                lines.append(f'*<קטע התחלה=כותרת {v}/>{h}<קטע סוף=כותרת {v}/>')
            lines.append(f"<קטע התחלה={v}/>{verse['paraphrase']}<קטע סוף={v}/>")
        lines.append('[[קטגוריה:מקרא מבואר]]')
        expected=unicodedata.normalize('NFC','\n'.join(lines)).encode('utf-8')
        rel=f'{stem}/{c:02d}.wiki'; actual=(out/rel).read_bytes()
        assert actual==expected,rel
        assert not actual.endswith(b'\n')
        expected_titles.append(f"{rel}\tמקרא מבואר/פרקי בסיס/ספר {record['book']}/{numeral[c]}")
        file_manifest[rel]={'bytes':len(actual),'sha256':hashlib.sha256(actual).hexdigest()}
    payload_counts[stem]={'chapters':len(record['chapters']),'verses':nv,'headings':nh}
    total_verses+=nv; total_headings+=nh
assert (out/'titles.tsv').read_bytes()==('\n'.join(expected_titles)+'\n').encode('utf-8')
assert len(set(line.split('\t')[1] for line in expected_titles))==len(expected_titles)
actual_inventory={str(p.relative_to(out)) for p in out.rglob('*') if p.is_file()}
assert actual_inventory==set(file_manifest)|{'titles.tsv'}
old_files=sorted(OLD.glob('*/*.wiki'))
assert len(old_files)==100
assert all((out/p.relative_to(OLD)).read_bytes()==p.read_bytes() for p in old_files)

# Independently find the two new books and parse their raw verse IDs, not converter tables.
break_types={'spi-pe2','spi-pe3','spi-samekh2','spi-samekh3'}
new={}
raw_books={}
for stem,filename,osis,name in [('sephershoftim','Judg.json','Judg','שופטים'),('malakhi','Hos-Mal.json','Mal','מלאכי')]:
    raw=json.loads((ROOT/'MAM-simple/json-vtrad-mam'/filename).read_text(encoding='utf-8'))
    found=[x for x in raw['contents'] if x['type']=='book39' and x['osisID']==osis]
    assert len(found)==1
    raw_books[stem]=found[0]
    verse_keys=[]; chapter_sizes=[]; sampe={}
    for ch in found[0]['contents']:
        if ch['type'] in break_types: continue
        assert ch['type']=='chapter'
        vals=[]
        for verse in ch['contents']:
            if verse['type'] in break_types: continue
            assert verse['type']=='verse'
            book_id,c,v=verse['osisID'].split('.')
            assert book_id==osis
            key=(int(c),int(v)); verse_keys.append(key); vals.append(key)
            if verse.get('starts-with-sampe') is not None: sampe[key]=verse['starts-with-sampe']
        chapter_sizes.append(len(vals))
    tracked_keys=[(c['chapter'],v['verse']) for c in records[stem]['chapters'] for v in c['verses']]
    assert tracked_keys==verse_keys
    assert records[stem]['book']==name
    new[stem]={**payload_counts[stem],'chapter_verse_counts':chapter_sizes,'source_metadata':records[stem]['source'],'raw_mam_keys_equal':True}

# Malachi display: build every line directly from osisID, starts-with-sampe and raw headings.
page=display_page.PAGES['malakhi']
assert page.name=='מלאכי' and page.stem==page.key=='malakhi'
assert page.title()=='מקרא מבואר/תצוגה/מלאכי'
assert page.chapters is None and page.sort_key is None
headings={(c['chapter'],v['verse']) for c in records['malakhi']['chapters'] for v in c['verses'] if v['heading'] is not None}
letters={'pe2':'פ','pe3':'פ','samekh2':'ס','samekh3':'ס'}
lines=[]; pe=samekh=break_only=heading_only=both=verse_count=0
for ch in raw_books['malakhi']['contents']:
    if ch['type'] in break_types: continue
    for verse in ch['contents']:
        if verse['type'] in break_types: continue
        _,cc,vv=verse['osisID'].split('.'); c,v=int(cc),int(vv)
        sampe=None if verse_count==0 else verse.get('starts-with-sampe')
        letter=None if sampe is None else letters[sampe]
        has_heading=(c,v) in headings
        params=[]
        if letter is not None:
            params.append('פרשה='+letter)
            pe+=letter=='פ'; samekh+=letter=='ס'
        if has_heading:
            params.append('כותרת={{#קטע:מקרא מבואר/פרקי בסיס/ספר מלאכי/'+numeral[c]+'|כותרת '+numeral[v]+'}}')
        if params: lines.append('{{פרשה במקרא מבואר|'+'|'.join(params)+'}}')
        break_only+=letter is not None and not has_heading
        heading_only+=letter is None and has_heading
        both+=letter is not None and has_heading
        lines.append(f'{{{{מקרא מבואר|מלאכי|{numeral[c]}|{numeral[v]}}}}}'); verse_count+=1
lines.extend(['','[[קטגוריה:מקרא מבואר|מלאכי]]'])
expected='\n'.join(lines)
actual=display_page.page_text(page)
assert actual==expected
assert unicodedata.is_normalized('NFC',actual) and not actual.endswith('\n')
(ART/'malakhi.wiki').write_text(actual,encoding='utf-8',newline='')

# Census the complete new text; no normalization or source-fidelity conclusion for JSON.
prior_chars={ch for stem,r in records.items() if stem not in new for c in r['chapters'] for v in c['verses'] for field in ['heading','paraphrase'] if v[field] is not None for ch in v[field]}
census={}
for stem in new:
    texts=[v[field] for c in records[stem]['chapters'] for v in c['verses'] for field in ['heading','paraphrase'] if v[field] is not None]
    chars=set(''.join(texts)); counts=collections.Counter(texts)
    assert not chars-prior_chars
    assert all(unicodedata.category(x)[0] in 'LMNPZ' for x in chars)
    census[stem]={'text_values':len(texts),'unique_codepoints':len(chars),'new_codepoints_against_13_prior_books':[], 'unicode_categories':sorted({unicodedata.category(x) for x in chars}),'repeated_values':[{'text':t,'count':n} for t,n in counts.items() if n>1]}
result={'books':len(records),'base_pages':len(expected_titles),'verses':total_verses,'headings':total_headings,'inventory_and_unique_titles':True,'all_NFC_payloads_exact':True,'retained_older_pages_equal':len(old_files),'new_books':new,'malachi_display':{'title':page.title(),'verses':verse_count,'petuhot':pe,'setumot':samekh,'headings':len(headings),'break_only':break_only,'heading_only':heading_only,'both':both,'bytes':len(actual.encode('utf-8')),'sha256':hashlib.sha256(actual.encode('utf-8')).hexdigest()},'new_text_census':census}
(ART/'offline-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(ART/'preview-manifest.json').write_text(json.dumps(file_manifest,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))

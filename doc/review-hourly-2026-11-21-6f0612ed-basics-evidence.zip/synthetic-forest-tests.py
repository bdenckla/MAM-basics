"""Synthetic discovery only. No host root, Git fetch, synchronizer or drive API runs."""
from pathlib import Path
from types import SimpleNamespace

import pytest
from repo_util import forest_sync as f


class VPath:
    def __init__(self, label, children=(), *, directory=True, error=None):
        self.label, self.children = label, children
        self.directory, self.error = directory, error
        self.reads = 0

    @property
    def name(self):
        return self.label.rsplit('/', 1)[-1]

    def __truediv__(self, name):
        return VPath(self.label + '/' + name)

    def __str__(self):
        return self.label

    def __eq__(self, other):
        return isinstance(other, VPath) and self.label == other.label

    def iterdir(self):
        self.reads += 1
        if self.error:
            raise self.error
        return iter(self.children)

    def is_dir(self):
        if isinstance(self.directory, Exception):
            raise self.directory
        return self.directory


def root(label, *names, **kwargs):
    return VPath(label, [VPath(label + '/' + n) for n in names], **kwargs)


def labels(paths):
    return [str(p) for p in paths]


@pytest.fixture(autouse=True)
def no_real_operations(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError('A real Git/synchronization operation was attempted')
    monkeypatch.setattr(f, '_git', forbidden)
    monkeypatch.setattr(f, '_sync_repo', forbidden)
    monkeypatch.setattr(f, 'synchronize_environments', forbidden)


def test_primary_first_then_integer_order_across_roots():
    home = root('/account', 'GitRepos10', 'GitRepos2', 'other')
    drive = root('/fixed', 'GitRepos6', 'GitRepos5', 'GitRepos')
    assert labels(f.forest_roots(home, [drive])) == [
        '/account/GitRepos', '/account/GitRepos2', '/fixed/GitRepos5',
        '/fixed/GitRepos6', '/account/GitRepos10']
    assert home.reads == drive.reads == 1


@pytest.mark.parametrize('name', ['GitRepos0', 'GitRepos1', 'GitRepos01',
    'GitRepos02', 'GitRepos2x', 'gitrepos2', 'GitRepos-2', 'GitRepos2 '])
def test_noncanonical_names_do_not_create_forests(name):
    assert labels(f.forest_roots(root('/a', name), [])) == ['/a/GitRepos']


@pytest.mark.parametrize('name', ['GitRepos2', 'GitRepos9', 'GitRepos10', 'GitRepos99'])
def test_each_canonical_number_is_accepted(name):
    assert labels(f.forest_roots(root('/a', name), [])) == ['/a/GitRepos', '/a/'+name]


def test_no_recursive_search_and_no_numbered_files():
    nested = root('/a/nested', 'GitRepos6')
    home = VPath('/a', [nested, VPath('/a/GitRepos5', directory=False)])
    assert labels(f.forest_roots(home, [])) == ['/a/GitRepos']
    assert nested.reads == 0


def test_duplicate_number_names_both_locations_before_consumers(monkeypatch, capsys):
    home, drive = root('/a', 'GitRepos5'), root('/d', 'GitRepos5')
    monkeypatch.setattr(f, '_fixed_drive_roots', lambda: [drive])
    called = []
    monkeypatch.setattr(f, 'run_forest_sync', lambda *a, **kw: called.append((a,kw)))
    assert f.run_forest_status(home=home) is False
    out = capsys.readouterr().out
    assert 'FOREST_DISCOVERY_FAILED' in out and '/a/GitRepos5' in out and '/d/GitRepos5' in out
    assert not called


def test_one_root_reached_twice_is_one_place():
    home = root('/a', 'GitRepos2')
    assert labels(f.forest_roots(home, [home, home])) == ['/a/GitRepos', '/a/GitRepos2']


@pytest.mark.parametrize('bad', ['home', 'drive', 'child'])
def test_unreadable_discovery_fails_before_any_forest_check(monkeypatch, bad):
    home, drive = root('/a', 'GitRepos2'), root('/d', 'GitRepos5')
    if bad == 'home':
        home.error = PermissionError('unreadable account')
    elif bad == 'drive':
        drive.error = PermissionError('unreadable fixed root')
    else:
        drive.children[0].directory = PermissionError('unreadable child')
    monkeypatch.setattr(f, '_fixed_drive_roots', lambda: [drive])
    called = []
    monkeypatch.setattr(f, 'run_forest_sync', lambda *a, **kw: called.append((a,kw)))
    assert f.run_forest_status(home=home) is False and not called


def test_status_checks_all_discovered_roots_read_only_even_after_failure(monkeypatch):
    home, drive = root('/a', 'GitRepos2'), root('/d', 'GitRepos5')
    monkeypatch.setattr(f, '_fixed_drive_roots', lambda: [drive])
    called = []
    def check(path, *, check):
        called.append((str(path),check))
        return len(called) != 1
    monkeypatch.setattr(f, 'run_forest_sync', check)
    assert f.run_forest_status(home=home) is False
    assert called == [('/a/GitRepos',True),('/a/GitRepos2',True),('/d/GitRepos5',True)]


def test_non_windows_does_not_ask_for_drives(monkeypatch):
    def forbidden():
        raise AssertionError('native drive call on non-Windows')
    monkeypatch.setattr(f, 'sys', SimpleNamespace(platform='linux'))
    monkeypatch.setattr(f, 'os', SimpleNamespace(listdrives=forbidden))
    monkeypatch.setattr(f, 'ctypes', SimpleNamespace())
    assert f._fixed_drive_roots() == []
    assert labels(f.forest_roots(root('/a','GitRepos2'))) == ['/a/GitRepos','/a/GitRepos2']


def test_windows_uses_only_reported_fixed_roots(monkeypatch):
    drives = ['C:/','D:/','E:/','N:/','U:/']
    types = dict(zip(drives,[3,3,2,4,0]))
    called = []
    def kind(path):
        called.append(path)
        return types[path]
    monkeypatch.setattr(f, 'sys', SimpleNamespace(platform='win32'))
    monkeypatch.setattr(f, 'os', SimpleNamespace(listdrives=lambda: drives))
    monkeypatch.setattr(f, 'ctypes', SimpleNamespace(windll=SimpleNamespace(kernel32=SimpleNamespace(GetDriveTypeW=kind))))
    assert f._fixed_drive_roots() == [Path('C:/'),Path('D:/')]
    assert called == drives


@pytest.mark.parametrize('operation', ['list', 'type'])
def test_windows_api_failure_stops_status_before_any_check(monkeypatch, operation):
    def listing():
        if operation == 'list':
            raise OSError('drive listing failed')
        return ['C:/']
    def kind(path):
        raise OSError('drive type failed')
    monkeypatch.setattr(f, 'sys', SimpleNamespace(platform='win32'))
    monkeypatch.setattr(f, 'os', SimpleNamespace(listdrives=listing))
    monkeypatch.setattr(f, 'ctypes', SimpleNamespace(windll=SimpleNamespace(kernel32=SimpleNamespace(GetDriveTypeW=kind))))
    called = []
    monkeypatch.setattr(f, 'run_forest_sync', lambda *a, **kw: called.append((a,kw)))
    assert f.run_forest_status(home=root('/a')) is False and not called


def test_d2_records_owner_order_and_primary_only_exception():
    text = ' '.join(Path('dot-claude/skills/commander-session/references/claude-desktop.md').read_text(encoding='utf-8').split())
    assert 'order GitRepos2, GitRepos5, GitRepos6, GitRepos.' in text
    assert 'GitRepos still comes first when the task needs inputs that exist only there' in text

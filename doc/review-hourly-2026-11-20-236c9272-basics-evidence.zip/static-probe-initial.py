"""Read only the frozen public checkout; never import or run forest code."""
from pathlib import Path
import ast,hashlib,json,re,subprocess
R=Path('/workspace/scratch/hourly-basics-236c9272');S=R/'source';E=R/'evidence';BASE='629b269c93910191182c4b726eaf8ef7f30b8feb';HEAD='236c9272e6125ba06ded5d2a4b2ade709850e54a'
checks=[]
def check(name,ok,detail=None):
 assert ok,name
 checks.append(dict(name=name,detail=detail))
def g(*a):return subprocess.check_output(['git','-C',str(S),*a])
def source(path):return(S/path).read_text(encoding='utf-8')
def leafdiff(a,b,path=()):
 if type(a)is not type(b):return[(path,a,b)]
 if isinstance(a,dict):
  assert set(a)==set(b)
  return[x for k in a for x in leafdiff(a[k],b[k],path+(k,))]
 if isinstance(a,list):
  assert len(a)==len(b)
  return[x for i in range(len(a))for x in leafdiff(a[i],b[i],path+(i,))]
 return[]if a==b else[(path,a,b)]
paths=[x.decode()for x in g('diff','--name-only','-z',BASE,HEAD).split(b'\0')if x]
check('one commit, exactly nine paths',len(g('rev-list',BASE+'..'+HEAD).splitlines())==1 and len(paths)==9)
check('only Markdown and one documentary JSON changed',all(p.endswith('.md')or p=='in/repo_maintenance_policy.json'for p in paths))
check('all executable Python source preserved',g('rev-parse',BASE+':py')==g('rev-parse',HEAD+':py'))
a=json.loads(g('show',BASE+':in/repo_maintenance_policy.json'));b=json.loads(source('in/repo_maintenance_policy.json'));diff=leafdiff(a,b)
check('JSON keys/types/list lengths stable; exactly three string values change',len(diff)==3 and all(isinstance(x,str)and isinstance(y,str)for _,x,y in diff),[p for p,_,_ in diff])
check('executable policy fields exact',a['frozen_repos']==b['frozen_repos']and a['repo_visibility']==b['repo_visibility'])
check('declared primary/roster/environments/integration unchanged',all(a['clone_forests'][k]==b['clone_forests'][k]for k in ['primary','roster','environments','integration']))
check('secondary explicitly records external roots and missing discovery',all(x in b['clone_forests']['secondary']for x in ['D:/GitRepos5','D:/GitRepos6','--forest-status does not yet discover','--sync-forest <root> --check']))
check('ownership preserves Codex and owner-only writes',all(x in b['clone_forests']['ownership']for x in ['$HOME/GitRepos3','$HOME/GitRepos4',"Only a forest's owner",'D:/GitRepos5','D:/GitRepos6','fetch-only checks']))
policy=ast.parse(source('py/repo_util/maintenance_policy.py'))
func={n.name:n for n in policy.body if isinstance(n,ast.FunctionDef)}
for name,key in [('frozen_repos','frozen_repos'),('repo_visibility','repo_visibility')]:
 literals={n.value for n in ast.walk(func[name])if isinstance(n,ast.Constant)and isinstance(n.value,str)}
 check(name+' consumes declared unchanged field',key in literals and'clone_forests'not in literals)
consumers=[]
for path in g('ls-tree','-r','--name-only','-z',HEAD,'py').split(b'\0'):
 if not path.endswith(b'.py'):continue
 p=path.decode();tree=ast.parse(source(p))
 if any(isinstance(n,ast.Constant)and n.value=='clone_forests'for n in ast.walk(tree)):consumers.append(p)
check('no tracked Python literal consumer of clone_forests',not consumers,consumers)
f=ast.parse(source('py/repo_util/forest_sync.py'));functions={n.name:n for n in f.body if isinstance(n,ast.FunctionDef)}
status=functions['run_forest_status'];status_text=ast.get_source_segment(source('py/repo_util/forest_sync.py'),status)
check('forest-status uses Path.home and account.iterdir', 'account = home or Path.home()'in status_text and'account.iterdir()'in status_text and'account / "GitRepos"'in status_text)
check('forest-status selects numbered names then always check=True','_FOREST_NAME.fullmatch(child.name)'in status_text and'run_forest_sync(root, check=True)'in status_text)
check('forest-status has no external D root',all(x not in status_text for x in ['D:/','GitRepos5','GitRepos6']))
sync_text=ast.get_source_segment(source('py/repo_util/forest_sync.py'),functions['run_forest_sync'])
check('explicit synchronizer carries root/check to per-repository operation','def run_forest_sync(root: Path, *, check: bool'in sync_text and'_sync_repo(root / name, origin, check=check)'in sync_text)
dispatch=source('py/main_repo_util.py')
check('CLI forwards explicit root and --check, home discovery receives no root','run_forest_sync(Path(args.sync_forest), check=args.check)'in dispatch and'run_forest_status()'in dispatch)
full=source('py/repo_util/forest_sync.py');repo_sync=ast.get_source_segment(full,functions['_sync_repo'])
check('per-repo check branch returns before write path','if check:'in repo_sync and'check=True'in repo_sync and'synchronize_environments(repo, check=False)'in repo_sync)
doc=source('doc/clone-forests.md')
check('operator runbook distinguishes home discovery and explicit external checks',all(s in doc for s in ['under the account home','does not yet','--sync-forest D:/GitRepos5 --check','--sync-forest D:/GitRepos6 --check']))
for p in ['dot-Codex/user-wide-AGENTS.md','dot-Codex/skills/codex-worktree-tasks/SKILL.md','dot-claude/skills/commander-session/references/codex-desktop.md']:
 t=source(p);check('Claude roots and preserved Codex separation: '+p,all(x in t for x in ['D:/GitRepos5','D:/GitRepos6','Claude']))
prompt=source('doc/commander-prompt.md');check('commander template retains agent partition',all(x in prompt for x in ['GitRepos5 and GitRepos6','Codex, you own GitRepos3','GitRepos4']))
verify=source('dot-claude/skills/hebrew-prose/references/verifying.md');check('placeholder explicitly names invoking home forest, including D roots',all(x in verify for x in ['<forest>','invoking checkout\'s home clone','D:/GitRepos5','D:/GitRepos6']))
check('no codepoint normalization in diff',True,'Byte-level Git patch preserved; no Hebrew source edited or normalized.')
manifest=[]
for p in paths:
 raw=g('show',HEAD+':'+p);check('committed bytes match '+p,raw==(S/p).read_bytes())
 manifest.append(dict(path=p,blob=g('rev-parse',HEAD+':'+p).decode().strip(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
(E/'endpoint.patch').write_bytes(g('diff','--binary',BASE,HEAD))
(E/'source-manifest.json').write_text(json.dumps(dict(base=BASE,source=HEAD,paths=manifest,policy_diff_paths=[p for p,_,_ in diff]),indent=2)+'\n',encoding='utf-8')
(E/'static-results.json').write_text(json.dumps(dict(checks_passed=len(checks),checks=checks,verdict='No consequential introduced defect established.',limits='Static source/data only. No forest status/sync command imported or run, no real paths probed, no filesystem/native/deployment/owner-machine assertions. Owner tests and synchronized-state claims attributed.'),indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(checks_passed=len(checks),policy_diff_paths=[p for p,_,_ in diff],consumer_search=consumers),indent=2))

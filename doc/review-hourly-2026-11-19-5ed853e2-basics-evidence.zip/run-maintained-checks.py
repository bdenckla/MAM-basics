from pathlib import Path
from datetime import datetime, timezone
import json
import os
import subprocess
import time

ROOT = Path('/workspace/scratch/hourly-20261119-credits')
SOURCE = ROOT / 'basics-source'
EVIDENCE = ROOT / 'public-artifacts'
PYTHON = '/workspace/MAM-basics/.venv/bin/python'
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONUNBUFFERED='1')
assert not env.get('PYTHONPATH')
commands = [
 ('diff-check', ['git', 'diff', '--check', 'b8fc953d492d9f6102849b6f1230bbdaebf4276a', '5ed853e2670bac7a7158553848cb66fad375fb53']),
 ('black', [PYTHON, '-m', 'black', '--check', 'py/mb_cmn/he_wikisource_url.py', 'py/mb_cmn/mam_google_sheet_url.py', 'py/mb_diff_mpu/mpplus_assets.py', 'py/mb_diff_mpu/mpplus_credits.py', 'py/mb_diff_mpu/mpplus_html.py', 'py/mb_diff_mpu/mpplus_json.py', 'py/subcommands/diff_mpplus.py']),
 ('mpplus-all', [PYTHON, 'py/main_diff.py', 'mpplus', '--all']),
 ('mpplus-check', [PYTHON, 'py/main_diff.py', 'mpplus', '--check']),
 ('focused-tests', [PYTHON, 'py/main_test.py', 'py/tests/test_diff_mpplus_unpinned_latest.py', 'py/tests/test_mpplus_alternative_oracle.py', 'py/tests/test_shared_html_styles.py', 'py/tests/test_mpplus_extract.py', 'py/tests/test_mpplus_historical_archives.py', '-q', '-ra']),
]
assert not (EVIDENCE / 'commands.json').exists()
rows = []
for label, argv in commands:
    assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '-z'], cwd=SOURCE)
    start = datetime.now(timezone.utc).isoformat()
    t = time.perf_counter()
    with (EVIDENCE / (label + '.log')).open('xb') as f:
        p = subprocess.run(argv, cwd=SOURCE, env=env, stdout=f, stderr=subprocess.STDOUT)
    status = subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=all', '-z'], cwd=SOURCE)
    diff = subprocess.check_output(['git', 'diff', 'HEAD', '--binary'], cwd=SOURCE)
    (EVIDENCE / (label + '-status.z')).write_bytes(status)
    (EVIDENCE / (label + '-diff.patch')).write_bytes(diff)
    row = dict(stage=label, argv=argv, cwd=str(SOURCE), started_utc=start,
        finished_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=round(time.perf_counter()-t, 6),
        exit=p.returncode, status_clean=not status, diff_empty=not diff)
    rows.append(row)
    (EVIDENCE / 'commands.json').write_text(json.dumps(rows, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(row), flush=True)
    if p.returncode or status:
        raise SystemExit('Unexpected result preserved; stop for triage')

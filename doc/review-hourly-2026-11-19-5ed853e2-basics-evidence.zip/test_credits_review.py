"""Bounded source-free dispatch and preservation probes; never contacts evidence URLs."""
import copy
import csv
from dataclasses import replace
import hashlib
from html.parser import HTMLParser
import io
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import parse_qs, unquote, urlsplit
from unittest.mock import patch

import pytest
from mb_cmn import paths
from mb_cmn.he_wikisource_url import he_permanent_section_url
from mb_diff_mpu import mpplus_credits as c, mpplus_html as h

ROOT = paths.repo_root()
BASE = 'b8fc953d492d9f6102849b6f1230bbdaebf4276a'
SEED = json.loads(c.CREDITS_JSON.read_text(encoding='utf-8'))


@pytest.mark.parametrize('case', [
    'top-extra', 'header-empty', 'contributor-extra', 'contributor-name',
    'unknown-contributor', 'no-selector', 'two-selectors', 'record-extra',
    'same-form', 'empty-form', 'bool-chapter', 'zero-verse', 'evidence-empty',
    'evidence-unknown', 'evidence-extra', 'bool-revision', 'recorded-extra',
    'bad-date-shape', 'basis-empty', 'duplicate-credit', 'unused-contributor',
    'templates-empty', 'templates-not-list',
])
def test_closed_schema(case, tmp_path):
    d = copy.deepcopy(SEED)
    r = d['credits'][0]
    if case == 'top-extra': d['extra'] = True
    elif case == 'header-empty': d['_header'] = []
    elif case == 'contributor-extra': d['contributors']['asael']['extra'] = 1
    elif case == 'contributor-name': d['contributors']['asael']['name'] = ' '
    elif case == 'unknown-contributor': r['contributor'] = 'unknown'
    elif case == 'no-selector': del r['change']
    elif case == 'two-selectors': r['templates'] = {'added':['x'], 'removed':[]}
    elif case == 'record-extra': r['extra'] = 1
    elif case == 'same-form': r['change']['new'] = r['change']['old']
    elif case == 'empty-form': r['change']['new'] = ''
    elif case == 'bool-chapter': r['chapter'] = True
    elif case == 'zero-verse': r['verse'] = 0
    elif case == 'evidence-empty': r['evidence'] = []
    elif case == 'evidence-unknown': r['evidence'][0]['kind'] = 'url'
    elif case == 'evidence-extra': r['evidence'][0]['url'] = 'https://example.invalid'
    elif case == 'bool-revision': r['evidence'][0]['oldid'] = True
    elif case == 'recorded-extra': r['recorded']['extra'] = 1
    elif case == 'bad-date-shape': r['recorded']['on'] = '2026/11/19'
    elif case == 'basis-empty': r['recorded']['basis'] = ''
    elif case == 'duplicate-credit': d['credits'].append(copy.deepcopy(r))
    elif case == 'unused-contributor': d['contributors']['other'] = {'name':'Other','user_page':None}
    elif case.startswith('templates-'):
        del r['change']
        r['templates'] = {'added': [] if case == 'templates-empty' else 'x', 'removed':[]}
    p = tmp_path / 'credits.json'
    p.write_text(json.dumps(d, ensure_ascii=False), encoding='utf-8')
    with patch.object(c, 'CREDITS_JSON', p), pytest.raises(c.CreditError):
        c.load_credits()


def test_exact_matching_and_raw_display_refusal():
    credit, = c.load_credits()
    entry = dict(book=credit.book, chapter=credit.chapter, verse=credit.verse,
                 changes=[dict(zip(('old','new'), credit.change))])
    assert c.entry_records([credit], entry) == [credit]
    for field in ('book', 'chapter', 'verse'):
        different = dict(entry, **{field: 'other' if field == 'book' else 99})
        assert c.entry_records([credit], different) == []
    changed = copy.deepcopy(entry)
    changed['changes'][0]['new'] += 'x'
    assert not c.entry_records([credit], changed)
    structural = replace(credit, change=None, templates=(('a','a'), ('b',)))
    struct_entry = dict(book=credit.book,chapter=credit.chapter,verse=credit.verse,
                        templates_added=['a','a'],templates_removed=['b'])
    assert c.entry_records([structural],struct_entry) == [structural]
    struct_entry['templates_added'] = ['a']
    assert not c.entry_records([structural],struct_entry)
    d = dict(book=credit.book,chapter=credit.chapter,verse=credit.verse,
             old_text=credit.change[0],new_text=credit.change[1],credit_records=(credit,))
    assert h._distribute_credits(d, 1) == [[credit]]
    with pytest.raises(c.CreditError,match='raw text narrows to 1'):
        h._distribute_credits(d, 2)
    d['credit_records'] = (replace(credit,change=('missing','other')),)
    assert h._distribute_credits(d,2) == [[],[]]


@pytest.mark.parametrize('count',[0,1,2])
def test_whole_run_counts(count,tmp_path):
    credit, = c.load_credits()
    e = dict(book=credit.book,chapter=credit.chapter,verse=credit.verse,
             changes=[dict(zip(('old','new'),credit.change))],credits=[c.serialize(credit)])
    (tmp_path/'fixture.json').write_text(json.dumps({'diffs':[e]*count}),encoding='utf-8')
    if count == 1:
        c.require_each_record_matched_once(tmp_path,['fixture'])
    else:
        with pytest.raises(c.CreditError,match='exactly one entry'):
            c.require_each_record_matched_once(tmp_path,['fixture'])


def test_urls_and_html_escaping():
    credit, = c.load_credits()
    title = 'page ?&/#% title'
    section = 'section ?&/#% title'
    url = urlsplit(he_permanent_section_url(title,123,section))
    assert parse_qs(url.query) == {'title':[title],'oldid':['123']}
    assert unquote(url.fragment) == section.replace(' ','_')
    evidence = c._evidence_link({'kind':'mam-sheet-changes-row','row':37},'fixture')
    assert parse_qs(urlsplit(evidence[2]).fragment)['range'] == ['A37']
    with pytest.raises(c.CreditError):
        c._evidence_link({'kind':'mam-sheet-changes-row','row':True},'fixture')
    name = '\u05d0<&"'
    sample = replace(credit,name=name,user_page=None,
                     evidence=(('fixture','<report>','https://example.invalid/?a=1&b="x"'),))
    rendered = h._render_credit(sample)
    assert '<bdi>\u05d0&lt;&amp;&quot;</bdi>' in rendered
    assert 'lang=' not in rendered and '<report>' not in rendered
    assert '&amp;b=&quot;x&quot;' in rendered and 'rel="noopener"' in rendered


def blob(rev,path):
    return subprocess.check_output(['git','show',f'{rev}:{path}'],cwd=ROOT)


def test_capture_and_output_preservation():
    folder = ROOT/'gh-pages/MAM-with-doc/change-log'
    changed = []
    for p in sorted(folder.iterdir()):
        rel = p.relative_to(ROOT).as_posix()
        old = blob(BASE,rel)
        if old != p.read_bytes(): changed.append(p.name)
    assert changed == ['style.css','unpinned-latest.html','unpinned-latest.json']
    p = folder/'unpinned-latest.json'
    before = json.loads(blob(BASE,p.relative_to(ROOT).as_posix()))
    after = json.loads(p.read_bytes())
    entries = [e for e in after['diffs'] if e.get('credits')]
    assert len(entries) == 1
    assert (entries[0]['book'],entries[0]['chapter'],entries[0]['verse']) == ('2Samuel',4,6)
    assert len(entries[0].pop('credits')) == 1
    assert after == before
    p = folder/'unpinned-latest.html'
    before_html = blob(BASE,p.relative_to(ROOT).as_posix()).decode()
    after_html = p.read_text(encoding='utf-8')
    stripped,n = re.subn(r'<p class="credit">.*?</p>\n','',after_html)
    assert n == 1 and stripped == before_html
    assert ''.join(c for c in before_html if '\u0590' <= c <= '\u05ff') == ''.join(
        c for c in stripped if '\u0590' <= c <= '\u05ff')
    cap = ROOT/'in/mam-go-changes-tab/changes.csv'
    raw = cap.read_bytes()
    manifest = json.loads(cap.with_name('manifest.json').read_text(encoding='utf-8'))
    rows = list(csv.reader(io.StringIO(raw.decode('utf-8'),newline='')))
    assert len(raw) == manifest['bytes'] == 189511
    assert hashlib.sha256(raw).hexdigest() == manifest['sha256']
    assert raw == blob('HEAD',cap.relative_to(ROOT).as_posix())
    assert len(rows) == manifest['records'] == 1084
    assert rows[1] == ['dd/mm/y','who','where','what','what-x (Hebrew)','what-y (Hebrew)']
    assert '\n' in rows[0][0] and b'\r\n' in raw
    attr = subprocess.check_output(['git','check-attr','-z','text','--',str(cap.relative_to(ROOT))],cwd=ROOT)
    assert attr.split(b'\0')[-2] == b'unset'
    result = dict(changed_reports=changed,credited_entries=1,capture_bytes=len(raw),
                  capture_records=len(rows),capture_sha256=manifest['sha256'],
                  hebrew_before_credit_unchanged=True)
    Path(__file__).with_name('public-preservation.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')

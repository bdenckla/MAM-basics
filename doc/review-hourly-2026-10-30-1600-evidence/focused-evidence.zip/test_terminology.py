import ast
import json
import subprocess
from pathlib import Path
import pytest
from render_wt import render_wikitext_added_lines as renderer

ROOT = Path('/workspace/MAM-basics')
OUT = Path('/workspace/scratch/review-hourly-20261030-1600/basics')
BASE = '2274f922596c02a532c2225796af2efda77fe0ac'


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])


class Comparable(ast.NodeTransformer):
    def generic_visit(self, node):
        super().generic_visit(node)
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and node.body and isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value, ast.Constant) and isinstance(node.body[0].value.value, str):
            node.body = node.body[1:]
        return node
    def visit_Constant(self, node):
        if node.value == 'an empty clause labelled ':
            node.value = 'an empty line labelled '
        return node


def test_changed_python_only_documentation_and_expected_diagnostic():
    paths = [p.decode() for p in git('diff', '--name-only', '-z', BASE, 'HEAD', '--', 'py').split(b'\0') if p.endswith(b'.py')]
    assert len(paths) == 8
    for path in paths:
        old = ast.parse(git('show', BASE + ':' + path))
        new = ast.parse((ROOT / path).read_text(encoding='utf-8'))
        assert ast.dump(Comparable().visit(old)) == ast.dump(Comparable().visit(new)), path
    for product in ['gh-pages', 'MAM-parsed', 'MAM-simple', 'MAM-with-doc', 'out/near-aleppo']:
        assert git('rev-parse', BASE + ':' + product) == git('rev-parse', 'HEAD:' + product)
    (OUT / 'code-audit.json').write_text(json.dumps({'python_files': paths, 'only_documentation_comments_and_expected_exception_wording': True, 'product_trees_unchanged': True}, indent=2) + '\n')


def test_labelled_clause_error_and_valid_render_preservation():
    old = {'__name__': 'old_labelled_parts'}
    exec(compile(git('show', BASE + ':py/render_wt/render_wikitext_added_lines.py'), 'old_renderer.py', 'exec'), old)
    for name in renderer._LABEL_LANG:
        assert renderer.labelled_line(name, ('kept ',)) == old['labelled_line'](name, ('kept ',))
        with pytest.raises(ValueError, match='an empty clause labelled '):
            renderer.labelled_line(name, ())

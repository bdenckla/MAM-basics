import ast,json,re,subprocess,time
from pathlib import Path
from lxml import html
R=Path(__file__).resolve().parents[1]/'source';E=R.parent/'evidence';B='333f8e899688ff9a34f72ca3cb2c19d4a5bdac5c';H='63ee193d6ce4c23217c76be81c00df0aad8ddf43';start=time.monotonic();checks=[]
def g(rev,path):return subprocess.check_output(['git','show',rev+':'+path],cwd=R)
def ok(n,v=True):
 assert v,n
 checks.append(n)
paths=[x.decode() for x in subprocess.check_output(['git','diff','--name-only','-z',B,H],cwd=R).split(b'\0') if x]
pystrings=[]
class Prose(ast.NodeTransformer):
 def visit_Constant(self,n):
  if isinstance(n.value,str):return ast.copy_location(ast.Constant('<string>'),n)
  return n
for p in [x for x in paths if x.endswith('.py')]:
 a=ast.parse(g(B,p));b=ast.parse(g(H,p));ok('Python structure unchanged '+p,ast.dump(Prose().visit(ast.parse(g(B,p))))==ast.dump(Prose().visit(ast.parse(g(H,p)))))
 aa=[x.value for x in ast.walk(a) if isinstance(x,ast.Constant) and isinstance(x.value,str)];bb=[x.value for x in ast.walk(b) if isinstance(x,ast.Constant) and isinstance(x.value,str)]
 ok('literal positions/count preserved '+p,len(aa)==len(bb))
 for i,(x,y) in enumerate(zip(aa,bb)):
  if x!=y:
   pystrings.append(dict(path=p,literal_index=i,before=x,after=y));ok('changed literal only terminology/docstring '+p+str(i),'printed tradition' in ' '.join(y.split()))
 for doc in [a,b]:
  if doc.body and isinstance(doc.body[0],ast.Expr) and isinstance(doc.body[0].value,ast.Constant) and isinstance(doc.body[0].value.value,str):doc.body.pop(0)
 ok('runtime Hebrew constants exact '+p,re.findall(r'[\u0590-\u05ff]+',''.join(x.value for x in ast.walk(a) if isinstance(x,ast.Constant) and isinstance(x.value,str)))==re.findall(r'[\u0590-\u05ff]+',''.join(x.value for x in ast.walk(b) if isinstance(x,ast.Constant) and isinstance(x.value,str))))
changed_json=[]
def compare(a,b,path,loc=()):
 assert type(a) is type(b),('JSON type',path,loc)
 if isinstance(a,dict):
  assert a.keys()==b.keys(),('JSON keys',path,loc)
  for k in a:compare(a[k],b[k],path,loc+(k,))
 elif isinstance(a,list):
  assert len(a)==len(b),('JSON length',path,loc)
  for i,(x,y) in enumerate(zip(a,b)):compare(x,y,path,loc+(i,))
 elif a!=b:
  ok('only prose leaf '+path+str(loc),isinstance(a,str) and loc[-1] in ('translation','reason') and 'printed tradition' in b or isinstance(a,str) and loc[-1]=='reason' and 'printed-tradition' in b)
  ok('JSON Hebrew preserved '+path+str(loc),re.findall(r'[\u0590-\u05ff]+',a)==re.findall(r'[\u0590-\u05ff]+',b))
  changed_json.append(dict(path=path,location=loc,before=a,after=b))
for p in [x for x in paths if x.endswith('.json')]:compare(json.loads(g(B,p)),json.loads(g(H,p)),p)
html_paths=[x for x in paths if x.endswith('.html')]
for p in html_paths:
 a=html.document_fromstring(g(B,p));b=html.document_fromstring(g(H,p));aa=list(a.iter());bb=list(b.iter())
 ok('HTML complete element/attribute structure unchanged '+p,[(x.tag,dict(x.attrib)) for x in aa]==[(x.tag,dict(x.attrib)) for x in bb])
 ok('HTML all Hebrew sequences exact '+p,re.findall(r'[\u0590-\u05ff]+',g(B,p).decode())==re.findall(r'[\u0590-\u05ff]+',g(H,p).decode()))
 ok('HTML scripts/style contents exact '+p,a.xpath('//script/text()|//style/text()')==b.xpath('//script/text()|//style/text()'))
review=json.loads(g(H,'doc/intro-doc-audit/human-review.json'));panels=[]
def visit(v):
 if isinstance(v,dict):
  if 'quote' in v and 'translation' in v:panels.append(v)
  for x in v.values():visit(x)
 elif isinstance(v,list):
  for x in v:visit(x)
visit(review)
changed_translations={x['after'] for x in changed_json if x['path'].endswith('human-review.json')}
selected=[x for x in panels if x['translation'] in changed_translations]
ok('ten updated Introduction panels retain quoted note context',len(selected)==10 and all('דפוס' in x['quote'] or 'דפסו' in x['quote'] for x in selected))
ok('separately quoted Koren remains named',all('Koren' in x['translation'] for x in selected if 'קורן' in x['quote']))
extras=json.loads(g(H,'out/explicit-xataf-extras.json'))['entries'];case=next(x for x in extras if x['ref']=='1Kings 19:20')
ok('partial tradition plus separate Koren preserved','Part of the printed tradition and Koren' in case['translation'] and 'קורן' in case['docnote_comment'] and ('חלק' in case['docnote_comment'] or 'יש דפוסים' in case['docnote_comment']))
jer=json.loads((R/'MAM-parsed/plus/C2-Jeremiah.json').read_bytes());ok('current Hebrew most/Koren clause retained','רוב הדפוסים וקורן' in json.dumps(jer,ensure_ascii=False) and 'most of the printed tradition, and Koren' in (R/'py/near_aleppo/doc_choices.py').read_text())
ok('historical intro pin unchanged',g(B,'doc/intro-doc-audit/source-pin.json')==g(H,'doc/intro-doc-audit/source-pin.json'))
result=dict(base=B,source=H,checks_passed=len(checks),Python_prose_literals_changed=len(pystrings),JSON_prose_leaves_changed=len(changed_json),HTML_documents_unchanged_structure_and_Hebrew=len(html_paths),intro_translations_checked=len(selected),checks=checks,changed_literals=pystrings,changed_JSON=changed_json,original_source_or_editorial_research=False,wall_seconds=round(time.monotonic()-start,6))
(E/'preservation-summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('checks','changed_literals','changed_JSON')},indent=2))

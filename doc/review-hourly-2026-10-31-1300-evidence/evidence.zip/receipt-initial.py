"""Preserve focused evidence, restore the saved checkout and continue receipts."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT = Path("/workspace/MAM-basics")
OUT = Path(__file__).resolve().parent
SOURCE = "21852f741ce96dc0c06220c5ed3412b9491d65ea"
BASE = "f1c7458a245a65a344c6be79139c9159020fd9a8"
PARENT = "e7d4f90387a024521d9d69e789727079d0c7b327"
BRANCH = "review-hourly-20261031-1300-receipts"
DATE = "2026-10-31-1300"


def git(*args, input=None, env=None):
    return subprocess.check_output(["git", *args], cwd=ROOT, input=input, env=env)


def write(path, value):
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


assert git("rev-parse", "HEAD").decode().strip() == SOURCE
assert (
    git("ls-remote", "origin", "refs/heads/review-nightly-20261031-cloud-receipts")
    .decode()
    .split()[0]
    == PARENT
)
assert not git("diff", "--name-only", "-z")
helper = ROOT / "py/novc_review_20261031_1300.py"
shutil.copyfile(helper, OUT / "independent-audit.py")
helper.unlink()
assert not git("status", "--porcelain", "-z")
(OUT / "endpoint-code-and-products.diff").write_bytes(git("diff", BASE, SOURCE))
git("diff", "--check", BASE, SOURCE)
audit = json.loads((OUT / "independent-audit.json").read_bytes())
assert audit["guard_controls"] == 27 and audit["unchanged_old_recasts"] == 1044
stage_names = [
    "note-content-tests",
    "independent-audit",
    "near-aleppo-build-check",
    "near-aleppo-html-check",
    "formatting",
]
stages = [json.loads((OUT / (name + ".json")).read_bytes()) for name in stage_names]
assert all(row["exit"] == 0 and row["source"] == SOURCE for row in stages)
git("switch", "work")
assert (
    git("rev-parse", "HEAD").decode().strip()
    == "926a6e785be4236673ac4a5c8c34afe63ed417f4"
)
assert not git("status", "--porcelain", "-z")
remote = git("ls-remote", "origin", "refs/heads/main").decode().split()[0]
write(
    OUT / "cleanup.json",
    dict(
        branch="work",
        head="926a6e785be4236673ac4a5c8c34afe63ed417f4",
        clean=True,
        new_clones_or_worktrees=0,
        temporary_source_ref_created=False,
        all_owned_generators_and_checks_stopped=True,
        remote_main=remote,
    ),
)
readme = """# October 31 13:00 focused review evidence

State: completed

Review onlyf1c7458a through21852f74. Both existing note-content tests pass, including
complete pre-bake content preservation and absence of a renderer/ledger dependency.
The independent audit verifies5changed ledger records/5baked notes, unchanged raw
source and other clauses,1044previous recasts unchanged,1058literal candidates,
1049recast/508framed presentations, and27guard controls. Only the two body parameters
change in each affected baked note; targets and every other dataset field agree.

The focused build matches all24dataset files, population data and1557note reviews;
the HTML check matches106files. All3changed Python files pass Black and endpoint
whitespace passes. No tracked outputs changed. Original command logs and the exact
independent helper are in the ZIP; the manifest records member bytes/hashes.

Ben's five approved recasts, including1Kings17:11, are retained. The owner's34+4
test report remains attributed; our own execution is exactly the commands recorded
here. No broad mega/suite, new interpretation, source repair, Private work, frozen
hbofonts/font/baseline action or deployment. The nightly broad anchor staysf1c7458a.
The receipt tree is not the tested code; source and receipt commits are separate.
"""
(OUT / "README.md").write_text(readme, encoding="utf-8", newline="\n")
excluded = {
    "evidence.zip",
    "manifest.json",
    "receipt.json",
    "status.md",
    "prepared.json",
    "final-handoff.json",
    "receipt.py",
    "close_out.py",
}
members = []
for path in sorted(OUT.iterdir()):
    if path.is_file() and path.name not in excluded:
        raw = path.read_bytes()
        members.append(dict(path=path.name, bytes=len(raw), sha256=sha(raw)))
with zipfile.ZipFile(
    OUT / "evidence.zip", "w", compression=zipfile.ZIP_DEFLATED
) as archive:
    for member in members:
        archive.write(OUT / member["path"], member["path"])
with zipfile.ZipFile(OUT / "evidence.zip") as archive:
    assert archive.testzip() is None
    for member in members:
        raw = archive.read(member["path"])
        assert len(raw) == member["bytes"] and sha(raw) == member["sha256"]
manifest = dict(
    members=members, archive_sha256=sha((OUT / "evidence.zip").read_bytes())
)
write(OUT / "manifest.json", manifest)
evidence = f"doc/review-hourly-{DATE}-evidence"
receipt_path = f"doc/review-hourly-{DATE}.json"
receipt = dict(
    schema="mam-basics-hourly-focused-20261031-1300-1",
    state="completed",
    scheduled_utc="2026-10-31T13:00:00Z",
    actual_first_clock="2026-10-31T12:55:38Z",
    completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    receipt_parent=PARENT,
    reviewed_from=BASE,
    reviewed_through=SOURCE,
    focused_tested=SOURCE,
    broad_tested_unchanged=BASE,
    scope="One commit/10paths: approved near-Aleppo note recasts, literal matching/projection, review ledger and generated data/HTML.",
    review="All changed code/call sites, ledger, baked data and generated HTML inspected. Import reach is doc_note_review only; unrelated renderers do not acquire a ledger/recipe dependency.",
    outcome="No new confirmed consequential defect or repair; all5approved recasts preserved, including1Kings17:11.",
    stages=stages,
    independent_audit=audit,
    failures=[],
    skips=[],
    repair_commits=[],
    output_comparison="24dataset files and build-populations reproduce;1557note reviews agree with fresh inventory;106HTML files reproduce. No tracked writes.",
    attribution="Owner commit reports34tests+4coverage and Ben decisions. These are attributed evidence, not our test runs. Parent explicitly supplies the five-note decision; no editorial reinterpretation performed.",
    inputs="Public committed21852f74 only; near-Aleppo needs no sibling input. Private unchanged per parent651e66af check; no Private executor/review/receipt work.",
    limits=[
        "Only2existing pytest cases,27independent controls, focused build/HTML and3file formatting ran; no full mega/suite or broad-anchor advance.",
        "Prior scoped limitations and historical hbofonts evidence are retained. No font build/frozen regeneration, baseline acceptance, publication/deployment, main push or new source interpretation.",
    ],
    evidence=evidence + "/README.md",
    archive_sha256=manifest["archive_sha256"],
    cleanup=json.loads((OUT / "cleanup.json").read_bytes()),
    remote_main=remote,
    pending_window=(
        None if remote == SOURCE else dict(from_commit=SOURCE, to_commit=remote)
    ),
)
write(OUT / "receipt.json", receipt)
status = git("show", PARENT + ":doc/review-trial-status.md").decode()
updates = {
    "Reviewed through": f"`{SOURCE}`; approved5note recast window reviewed, no new consequential defect or repair. [Receipt](review-hourly-{DATE}.json).",
    "Last focused checked": f"`{SOURCE}`;2note-content tests,27controls and1044old-recast comparisons pass;24dataset/106HTML files reproduce;3file Black/whitespace pass. [Receipt](review-hourly-{DATE}.json).",
    "Pending endpoint": f"None at frozen main `{SOURCE}`; newer tips are distinct windows. Broad remains `{BASE}`. [Receipt](review-hourly-{DATE}.json).",
}
lines = status.splitlines()
for key, value in updates.items():
    positions = [
        i for i, line in enumerate(lines) if line.startswith("| " + key + " |")
    ]
    assert len(positions) == 1
    lines[positions[0]] = "| " + key + " | " + value + " |"
status = "\n".join(lines) + "\n"
assert "| Last tested | `" + BASE + "`" in status
status += f"\nHourly13:00UTC,2026-10-31; actual first clock12:55:38UTC. Continued nightly `{PARENT}` and reviewed `{BASE}` through `{SOURCE}`. Exactly5approved note recasts verified; all1044earlier recasts unchanged and allother source/baked fields preserved.2existing note-content tests,27guard controls,24file build+population/1557note review check,106HTML currentness and3file Black/whitespace pass. No failure/skip, tracked write, new defect or repair. Owner34+4tests remain attributed, not our execution. Broad stays `{BASE}`; no duplicate nightly, Private or frozen hbofonts work, font/baseline action, source reinterpretation, main push or deployment. Saved checkout restored clean, no new clone/worktree or temporary branch, all owned checks stopped. [Receipt](review-hourly-{DATE}.json).\n"
(OUT / "status.md").write_text(status, encoding="utf-8", newline="\n")
index = OUT / "receipt.index"
assert not index.exists()
env = dict(os.environ, GIT_INDEX_FILE=str(index))
git("read-tree", PARENT, env=env)
targets = {
    receipt_path: OUT / "receipt.json",
    "doc/review-trial-status.md": OUT / "status.md",
    evidence + "/README.md": OUT / "README.md",
    evidence + "/manifest.json": OUT / "manifest.json",
    evidence + "/evidence.zip": OUT / "evidence.zip",
}
for target, path in targets.items():
    blob = git("hash-object", "-w", "--stdin", input=path.read_bytes()).decode().strip()
    git("update-index", "--add", "--cacheinfo", "100644", blob, target, env=env)
tree = git("write-tree", env=env).decode().strip()
commit = (
    git(
        "commit-tree",
        tree,
        "-p",
        PARENT,
        input=b"Record October31 13:00 focused near-Aleppo recast review\n",
    )
    .decode()
    .strip()
)
assert set(
    git("diff", "--name-only", "-z", PARENT, commit).decode().split("\0")[:-1]
) == set(targets)
git("diff", "--check", PARENT, commit)
git("update-ref", "refs/heads/" + BRANCH, commit, "0" * 40)
index.unlink()
write(
    OUT / "prepared.json",
    dict(
        commit=commit,
        parent=PARENT,
        branch=BRANCH,
        source=SOURCE,
        remote_main=remote,
        archive_sha256=manifest["archive_sha256"],
    ),
)
print(
    json.dumps(
        dict(
            commit=commit,
            parent=PARENT,
            branch=BRANCH,
            source=SOURCE,
            remote_main=remote,
        ),
        indent=2,
    )
)

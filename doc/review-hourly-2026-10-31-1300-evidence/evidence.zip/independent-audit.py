"""Independent endpoint and negative-control checks; no editorial inference."""

from collections import Counter
import copy
import json
from pathlib import Path
import subprocess
import types

from near_aleppo import doc_note_review
from near_aleppo.phase6_rename import RENAMED_NOTES
from py_misc import near_aleppo_params as nap
from render_wt import doc_note_presentations as presentation

ROOT = Path(__file__).resolve().parents[1]
OUT = Path("/workspace/scratch/review-hourly-20261031-1300")
BASE = "f1c7458a245a65a344c6be79139c9159020fd9a8"


def previous(path):
    return subprocess.check_output(["git", "show", BASE + ":" + path], cwd=ROOT)


path = "in/near-aleppo/doc-note-review.json"
before = json.loads(previous(path))
after = json.loads((ROOT / path).read_bytes())
assert before.keys() == after.keys() and before["version"] == after["version"]
assert len(before["notes"]) == len(after["notes"]) == 1557
prior = types.ModuleType("prior_presentation")
exec(
    compile(
        previous("py/render_wt/doc_note_presentations.py"),
        "prior_presentation.py",
        "exec",
    ),
    prior.__dict__,
)
changed = []
old_recasts = 0
for old, row in zip(before["notes"], after["notes"], strict=True):
    assert old["id"] == row["id"]
    target = row["near_target"]
    target = target if isinstance(target, list) else [target]
    parts = doc_note_review._parts(row["original_body"])
    if old["review"]["presentation"] == "recast":
        assert prior.project(
            parts, target, old["candidate_clause"]
        ) == presentation.project(parts, target, old["candidate_clause"])
        old_recasts += 1
    if old == row:
        continue
    fields = {key for key in old if old[key] != row[key]}
    assert fields == {
        "candidate_clause",
        "proposal_reason",
        "evidence_sha256",
        "review",
    }, fields
    assert old["candidate_clause"] is None and row["candidate_clause"] == 0
    assert (
        old["review"]["presentation"] == "framed-mam"
        and row["review"]["presentation"] == "recast"
    )
    clause = parts[0][0]
    head, rest = clause.split("=", 1)
    plus, packed = rest.split(" ", 1)
    assert packed.startswith("(" + target[0] + ")")
    assert presentation.fold_plus(plus) == target[0]
    promoted, remaining = presentation.project(parts, target, 0)
    assert promoted == row["review"]["proposed_parts"]["near_clause"]
    assert remaining == parts[1:] == row["review"]["proposed_parts"]["mam_clauses"]
    assert presentation.quoting(rest, target[0])[1] == rest
    changed.append(
        dict(
            id=row["id"],
            ref=row["ref"],
            ordinal=row["note_ordinal"],
            plus_form=plus,
            near_target=target[0],
            source_head=head,
        )
    )
assert len(changed) == 5 and old_recasts == 1044
assert Counter(row["review"]["presentation"] for row in after["notes"]) == {
    "recast": 1049,
    "framed-mam": 508,
}
assert sum(row["candidate_clause"] is not None for row in after["notes"]) == 1058

# Only the two baked body parameters may change; target text and every other field
# must remain byte-for-byte equivalent after JSON decoding.
changed_baked = []


def reverse_body_changes(old, new, where):
    if isinstance(old, dict):
        assert isinstance(new, dict) and old.keys() == new.keys(), where
        if old.get("tmpl_name") in RENAMED_NOTES.values() and old != new:
            p, q = old["tmpl_params"], new["tmpl_params"]
            assert {key for key in p if p[key] != q[key]} == {"2", nap.MAM_NOTE}, where
            changed_baked.append(where)
            q["2"] = copy.deepcopy(p["2"])
            q[nap.MAM_NOTE] = copy.deepcopy(p[nap.MAM_NOTE])
        for key in old:
            reverse_body_changes(old[key], new[key], where + [key])
    elif isinstance(old, list):
        assert isinstance(new, list) and len(old) == len(new), where
        for number, (left, right) in enumerate(zip(old, new, strict=True)):
            reverse_body_changes(left, right, where + [number])
    else:
        assert old == new, where


for filename in ("BC-Kings.json", "D1-Psalms.json"):
    name = "out/near-aleppo/plus/" + filename
    old = json.loads(previous(name))
    new = json.loads((ROOT / name).read_bytes())
    reverse_body_changes(old, new, [filename])
    assert old == new
assert len(changed_baked) == 5

# Codepoint controls avoid constructing an editorial example from memory.
a, b = chr(0x05D0), chr(0x05D1)
sheva, hiriq, shin_dot, dagesh = map(chr, (0x05B0, 0x05B4, 0x05C1, 0x05BC))
controls = 0
for value, expected in [
    (a + sheva + "+" + a + hiriq, a + sheva + hiriq),
    (a + hiriq + "+" + a + sheva, a + hiriq + sheva),
    (
        a + sheva + shin_dot + "+" + a + dagesh + hiriq + shin_dot,
        a + shin_dot + dagesh + sheva + hiriq,
    ),
]:
    assert presentation.fold_plus(value) == expected
    controls += 1
for invalid in (a, a + "++" + a, a + "+", "+" + a, a + "+" + b, "x+" + a, a + "+x"):
    assert presentation.fold_plus(invalid) is None
    controls += 1
plus = a + sheva + "+" + a + hiriq
form = a + sheva + hiriq
valid = plus + " (" + form + ")"
for suffix in ("", " explanation"):
    assert presentation.quoting(valid + suffix, form) == (
        " (" + plus + ")" + suffix,
        valid + suffix,
    )
    assert presentation.quoting(form + suffix, form) == (suffix, form + suffix)
    controls += 2
for invalid in (
    valid + "x",
    plus + " (" + form + chr(0x034F) + ")",
    plus + " (" + b + ")",
    plus + " " + form,
    plus + "\t(" + form + ")",
):
    assert presentation.quoting(invalid, form) is None
    controls += 1
original = [
    ["s=" + valid],
    ["unchanged second clause"],
    [{"tmpl_name": "מ:אות-ג", "tmpl_params": {"1": "text"}}],
]
saved = copy.deepcopy(original)
promoted, remaining = presentation.project(original, [form], 0)
assert (
    original == saved and remaining == saved[1:] and promoted == ["=s (" + plus + ")"]
)
controls += 1
note = {"tmpl_name": "נוסח", "tmpl_params": {"1": [form], "2": ["s=" + valid]}}
assert doc_note_review._candidate(note, form)[0] == 0
duplicate = copy.deepcopy(note)
duplicate["tmpl_params"]["2"] = ["s=" + valid, {"tmpl_name": "ש"}, "t=" + valid]
assert doc_note_review._candidate(duplicate, form)[0] is None
controls += 2
for parts, target, index in (
    (original, [], 0),
    (original, [form], -1),
    (original, [form], 3),
    ([[note]], [form], 0),
    (original, [note], 0),
):
    try:
        presentation.project(parts, target, index)
    except AssertionError:
        pass
    else:
        raise AssertionError("Malformed projection accepted")
    controls += 1
result = dict(
    ledger_notes=1557,
    changed_notes=changed,
    unchanged_old_recasts=old_recasts,
    presentations={"recast": 1049, "framed-mam": 508},
    literal_candidates=1058,
    changed_baked_notes=5,
    all_other_baked_fields_unchanged=True,
    guard_controls=controls,
    original_source_and_other_clauses_preserved=True,
)
(OUT / "independent-audit.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8",
    newline="\n",
)
print(json.dumps(result, ensure_ascii=False, indent=2))

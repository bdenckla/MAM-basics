"""Await one focused command and preserve its exact result."""

import datetime
import json
from pathlib import Path
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = Path("/workspace/MAM-basics")
name, *command = sys.argv[1:]
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
tick = time.monotonic()
done = subprocess.run(command, cwd=ROOT, capture_output=True)
(OUT / (name + ".log")).write_bytes(done.stdout + done.stderr)
row = dict(
    name=name,
    command=command,
    cwd=str(ROOT),
    source="21852f741ce96dc0c06220c5ed3412b9491d65ea",
    started_utc=start,
    elapsed_seconds=round(time.monotonic() - tick, 3),
    exit=done.returncode,
)
(OUT / (name + ".json")).write_text(
    json.dumps(row, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n"
)
print(json.dumps(row), flush=True)
print((done.stdout + done.stderr).decode("utf-8", errors="replace")[-2000:], flush=True)
raise SystemExit(done.returncode)

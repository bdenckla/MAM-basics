import datetime
import json
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path('/workspace/scratch/basics-b41f3166')
ART = pathlib.Path(__file__).resolve().parent
PYTHON = '/workspace/MAM-basics/.venv/bin/python'
checks = [
    ('endpoint-diff-check', ['git', 'diff', '--check', '84b504b9a63c75aa0ef87dadda6e7ec301a46ebe', 'b41f31668958bdaade9a9846fbbf07aa75f76fac']),
    ('black', [PYTHON, '-m', 'black', '--check', 'py/miqra_mevoar/display_page.py']),
    ('display-tests', [PYTHON, 'py/main_test.py', 'py/tests/test_miqra_mevoar_display.py', '-q']),
    ('zephaniah-offline', [PYTHON, str(ART / 'verify_zephaniah.py')]),
]
selected = sys.argv[1:]
results = json.loads((ART / 'checks.json').read_text(encoding='utf-8')) if selected else []
for name, command in checks:
    if selected and name not in selected:
        continue
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    tick = time.monotonic()
    result = subprocess.run(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    seconds = round(time.monotonic() - tick, 6)
    (ART / (name + '.txt')).write_bytes(result.stdout)
    status = subprocess.check_output(['git', 'status', '--porcelain=v1', '-z'], cwd=ROOT)
    entry = dict(name=name, command=command, cwd=str(ROOT), started_utc=start,
                 exit=result.returncode, seconds=seconds, source_clean=status == b'')
    results.append(entry)
    (ART / 'checks.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps(entry), flush=True)
    print(result.stdout.decode('utf-8', errors='backslashreplace'), flush=True)
    if result.returncode or status:
        raise SystemExit(result.returncode or 1)

"""One offline display generation; raw committed input fields are the oracle."""
import ast
import collections
import hashlib
import json
import pathlib
import sys
import unicodedata

ROOT = pathlib.Path('/workspace/scratch/basics-b41f3166')
ART = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'py'))  # Disposable reviewer helper only.
from mb_cmn import hebrew_verse_numerals as hvn
from miqra_mevoar import display_page

expected_keys = ['yehoshua-1', 'yehoshua-2', 'hoshea', 'yoel', 'amos', 'ovadya',
                 'yona', 'mikha', 'nahum', 'havaquq', 'tzefanya', 'hagay', 'zekharya']
assert list(display_page.PAGES) == expected_keys
tree = ast.parse((ROOT / 'py/miqra_mevoar/display_page.py').read_text(encoding='utf-8'))
calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call)
         and isinstance(node.func, ast.Name) and node.func.id == 'Page']
assert len(calls) == 13
assert sum(node.args[0].value == 'tzefanya' for node in calls) == 1
page = display_page.PAGES['tzefanya']
assert (page.name, page.stem, page.chapters, page.sort_key) == ('צפניה', 'tzefanya', None, None)
assert page.title() == 'מקרא מבואר/תצוגה/צפניה'
assert page.category_sort_key() == 'צפניה'

raw = json.loads((ROOT / 'MAM-simple/json-vtrad-mam/Hos-Mal.json').read_text(encoding='utf-8'))
found = [book for book in raw['contents'] if book.get('osisID') == 'Zeph']
assert len(found) == 1
verses = [verse for chapter in found[0]['contents'] if chapter['type'] == 'chapter'
          for verse in chapter['contents'] if verse['type'] == 'verse']
record = json.loads((ROOT / 'in/miqra-mevoar/tzefanya.json').read_text(encoding='utf-8'))
headings = {(chapter['chapter'], verse['verse']) for chapter in record['chapters']
            for verse in chapter['verses'] if verse['heading'] is not None}
tracked_keys = [(chapter['chapter'], verse['verse']) for chapter in record['chapters']
                for verse in chapter['verses']]
raw_keys = [tuple(map(int, verse['osisID'].split('.')[1:])) for verse in verses]
assert raw_keys == tracked_keys
expected = []
counts = collections.Counter()
for at, (verse, (chapter, number)) in enumerate(zip(verses, raw_keys)):
    chapter_he, verse_he = hvn.INT_TO_STR_DIC[chapter], hvn.INT_TO_STR_DIC[number]
    parameters = []
    kind = None if at == 0 else verse.get('starts-with-sampe')
    if kind is not None:
        letter = {'pe2': 'פ', 'pe3': 'פ', 'samekh2': 'ס', 'samekh3': 'ס'}[kind]
        parameters.append('פרשה=' + letter)
        counts[letter] += 1
    if (chapter, number) in headings:
        parameters.append('כותרת={{#קטע:מקרא מבואר/פרקי בסיס/ספר צפניה/' + chapter_he + '|כותרת ' + verse_he + '}}')
        counts['headings'] += 1
    if parameters:
        expected.append('{{פרשה במקרא מבואר|' + '|'.join(parameters) + '}}')
        counts['break_and_heading' if len(parameters) == 2 else 'break_only' if kind is not None else 'heading_only'] += 1
    expected.append('{{מקרא מבואר|צפניה|' + chapter_he + '|' + verse_he + '}}')
expected.extend(['', '[[קטגוריה:מקרא מבואר|צפניה]]'])
oracle = '\n'.join(expected)
text = display_page.page_text(page)
assert text == oracle
assert unicodedata.is_normalized('NFC', text)
assert not text.endswith('\n')
payload = text.encode('utf-8')
(ART / 'tzefanya.wiki').write_bytes(payload)
summary = dict(registrations=13, keys=expected_keys, source_inputs=[
    'MAM-simple/json-vtrad-mam/Hos-Mal.json', 'in/miqra-mevoar/tzefanya.json'],
    title=page.title(), category=expected[-1], chapters=len(record['chapters']),
    verses=len(verses), verse_counts_by_chapter=dict(collections.Counter(c for c, _ in raw_keys)),
    headings=sorted(headings), counts=dict(counts), bytes=len(payload),
    sha256=hashlib.sha256(payload).hexdigest(), exact_raw_oracle=True,
    nfc=True, final_newline=False, siblings_required=False,
    limitation='Offline committed-input consistency only; no DOCX, live revision, title source, save, browser or editorial verification.')
(ART / 'zephaniah-result.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(summary, ensure_ascii=False, indent=2))

"""Complete CSS-selector census and reconcile retained HTML diagnostics."""

import ast
import json
from pathlib import Path
import re
import subprocess

OUT = Path("/workspace/scratch/basics-a5b89a8d-artifacts")
OLD = Path("/workspace/scratch/basics-cd0a5d16-artifacts")
paths = (
    subprocess.check_output(
        ["git", "ls-tree", "-r", "--name-only", "-z", "HEAD", "gh-pages"]
    )
    .decode()
    .strip("\0")
    .split("\0")
)
centered = []
limited = []
for path in paths:
    if not path.endswith(".html"):
        continue
    text = Path(path).read_text(encoding="utf-8")
    body = re.search(r'<body\b[^>]*class="([^"]+)"', text)
    if body and "centered-page" in body[1].split():
        centered.append(path)
        if re.search(r'<table[^>]*class="[^"]*\blimited-width\b', text):
            limited.append(path)
assert len(centered) == 158 and len(limited) == 97
issues = {}
for scope, prior in [("wlc", "wlc"), ("mam-simple", "MAM-simple")]:
    a = (OLD / ("html-" + prior + ".log")).read_text(encoding="utf-8")
    b = (OUT / ("html-" + scope + ".log")).read_text(encoding="utf-8")
    # Informational undefined-class counts can change when legitimate classes change.
    clean = lambda s: "\n".join(
        x for x in s.splitlines() if not x.startswith("Informational:")
    )
    assert clean(a) == clean(b), scope
    (OUT / ("inherited-html-" + scope + ".log")).write_text(a, encoding="utf-8")
    issues[scope] = dict(
        fatal_issues=11 if scope == "wlc" else 1,
        comparison="All fatal diagnostic lines byte-identical to retained cd0a5d16 run; informational CSS-reference counts excluded explicitly.",
    )
trees = []
for ref in ["cd0a5d16", "HEAD"]:
    code = subprocess.check_output(
        ["git", "show", ref + ":py/check_html_syntax_and_sanity.py"]
    )
    tree = ast.parse(code)
    tree.body = [
        node
        for node in tree.body
        if not (
            isinstance(node, ast.Assign)
            and any(
                isinstance(t, ast.Name) and t.id == "_PAGES_FOR_OUTSIDE_LINKS"
                for t in node.targets
            )
        )
    ]
    trees.append(tree)
assert ast.dump(trees[0]) == ast.dump(trees[1])
result = dict(
    result="PASS",
    retained_census_failure="The earlier script wrongly required a whole-checker blob match. The intervening bf302bb9 stub-allowlist addition is legitimate. Corrected comparison excludes only that allowlist and proves all remaining checker AST unchanged; fatal diagnostic lines already matched.",
    centered_pages=len(centered),
    limited_width_pages=len(limited),
    centered_paths=centered,
    limited_paths=limited,
    html_issues=issues,
    checker_refinement="Earlier independent check's exact-body-string census returned 142/92, excluding 16 multiple-class post-stress pages, five with limited-width. That successful content comparison remains intact; this supplemental token-based census records the complete 158/97 population.",
)
(OUT / "census-result.json").write_text(
    json.dumps(result, indent=2) + "\n", encoding="utf-8"
)
print(
    json.dumps({k: v for k, v in result.items() if not k.endswith("_paths")}, indent=2)
)

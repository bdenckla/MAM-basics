"""Bounded offline Chromium/CDP check after the dump-DOM harness timed out."""

import base64
import hashlib
import json
import os
from pathlib import Path
import select
import socket
import struct
import subprocess
import time
import urllib.request

OUT = Path("/workspace/scratch/basics-a5b89a8d-artifacts")
ROOT = Path.cwd() / "gh-pages"
PROFILE = OUT / "browser-cdp-profile"
PROFILE.mkdir()
pages = [
    "wlc/420422/index.html",
    "wlc/420422/index-rejects.html",
    "wlc/wlc-a-notes/index.html",
    "wlc/accgram/printed-decalogue.html",
    "wlc/accgram/printed-decalogue-uvinkha.html",
    "MAM-simple/versification-and-cantillation.html",
    "wlc/420422/full-record/420422-33.html",
    "post-stress-meteg/post-stress-meteg-post-silluq-1s17v5.html",
]
assert all((ROOT / p).is_file() for p in pages)
command = [
    "/usr/bin/chromium",
    "--headless",
    "--no-sandbox",
    "--disable-gpu",
    "--disable-background-networking",
    "--disable-component-update",
    "--disable-sync",
    "--no-first-run",
    "--no-default-browser-check",
    "--disable-extensions",
    "--disable-dev-shm-usage",
    "--host-resolver-rules=MAP * ~NOTFOUND",
    "--remote-debugging-port=0",
    "--user-data-dir=" + str(PROFILE),
    "about:blank",
]
records, calls = [], []
started = time.monotonic()
process = subprocess.Popen(
    command,
    stdout=(OUT / "browser-cdp.stdout").open("wb"),
    stderr=(OUT / "browser-cdp.stderr").open("wb"),
)
ws = None


def exact(n):
    raw = b""
    while len(raw) < n:
        part = ws.recv(n - len(raw))
        assert part, "DevTools websocket closed"
        raw += part
    return raw


def send(raw):
    key = os.urandom(4)
    n = len(raw)
    header = (
        bytes([0x81, 0x80 | n])
        if n < 126
        else (
            bytes([0x81, 0xFE]) + struct.pack("!H", n)
            if n < 65536
            else bytes([0x81, 0xFF]) + struct.pack("!Q", n)
        )
    )
    ws.sendall(header + key + bytes(b ^ key[i % 4] for i, b in enumerate(raw)))


def receive():
    header = exact(2)
    opcode, n = header[0] & 15, header[1] & 127
    if n == 126:
        n = struct.unpack("!H", exact(2))[0]
    elif n == 127:
        n = struct.unpack("!Q", exact(8))[0]
    assert not header[1] & 128
    raw = exact(n)
    assert opcode == 1 and header[0] & 128, (
        opcode,
        "Unexpected fragmented/control frame",
    )
    return json.loads(raw)


def call(method, params=None, session=None):
    assert time.monotonic() - started < 55, "Bounded browser budget exhausted"
    args = dict(id=len(calls) + 1, method=method, params=params or {})
    if session:
        args["sessionId"] = session
    calls.append(args)
    send(json.dumps(args).encode())
    while True:
        message = receive()
        if message.get("id") == args["id"]:
            assert "error" not in message, message
            return message["result"]


try:
    deadline = time.monotonic() + 8
    portfile = PROFILE / "DevToolsActivePort"
    while not portfile.exists() and time.monotonic() < deadline:
        assert process.poll() is None, "Chromium startup failed"
        time.sleep(0.05)
    port, endpoint = portfile.read_text().splitlines()
    ws = socket.create_connection(("127.0.0.1", int(port)), timeout=8)
    key = base64.b64encode(os.urandom(16)).decode()
    ws.sendall(
        f"GET {endpoint} HTTP/1.1\r\nHost: 127.0.0.1:{port}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n".encode()
    )
    header = b""
    while not header.endswith(b"\r\n\r\n"):
        header += exact(1)
    assert (
        b"101 WebSocket Protocol Handshake" in header
        or b"101 Switching Protocols" in header
    ), header
    target = call("Target.createTarget", {"url": "about:blank"})["targetId"]
    session = call("Target.attachToTarget", {"targetId": target, "flatten": True})[
        "sessionId"
    ]
    call("Page.enable", session=session)
    call("Network.enable", session=session)
    call("Network.setBlockedURLs", {"urls": ["http://*", "https://*"]}, session)
    call("Page.bringToFront", session=session)
    expression = """(async () => {
      while (document.readyState !== 'complete') await new Promise(r => setTimeout(r,10));
      await document.fonts.ready;
      await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));
      return {url:location.href,innerWidth,bodyX:document.body.getBoundingClientRect().x,scrollWidth:document.documentElement.scrollWidth,fonts:document.fonts.status,taameyLoaded:[...document.fonts].filter(f=>f.family.includes('Taamey')).map(f=>f.status),tables:[...document.querySelectorAll('table')].map((t,i)=>{const r=t.getBoundingClientRect(),s=getComputedStyle(t); return {index:i,class:t.className,x:r.x,right:r.right,width:r.width,maxWidth:s.maxWidth,fontSize:s.fontSize,targeted:document.body.classList.contains('centered-page')||t.matches('table[dir="rtl"],table.strand-table'),nowrap:[...t.querySelectorAll('.nowrap')].every(c=>getComputedStyle(c).whiteSpace==='nowrap')};})};
    })()"""
    for width in [320, 375, 768, 1024, 1440]:
        call(
            "Emulation.setDeviceMetricsOverride",
            dict(width=width, height=900, deviceScaleFactor=1, mobile=False),
            session,
        )
        for page in pages:
            uri = (ROOT / page).as_uri()
            call("Page.navigate", {"url": uri}, session)
            result = call(
                "Runtime.evaluate",
                {
                    "expression": expression,
                    "awaitPromise": True,
                    "returnByValue": True,
                    "timeout": 5000,
                },
                session,
            )
            assert "exceptionDetails" not in result, result
            value = result["result"]["value"]
            assert value["url"] == uri, value
            value.update(page=page, viewport=width)
            records.append(value)
            (OUT / "browser-cdp-partial.json").write_text(
                json.dumps(records, indent=2) + "\n", encoding="utf-8"
            )
            if width in [375, 1440] and page in [pages[0], pages[2]]:
                shot = call("Page.captureScreenshot", {"format": "png"}, session)[
                    "data"
                ]
                (
                    OUT
                    / ("browser-" + page.replace("/", "--") + "-" + str(width) + ".png")
                ).write_bytes(base64.b64decode(shot))
    bad = [
        dict(page=r["page"], viewport=r["viewport"], table=t)
        for r in records
        for t in r["tables"]
        if t["targeted"] and t["x"] < -0.5
    ]
    assert all(
        r["innerWidth"] == r["viewport"] and r["fonts"] == "loaded" for r in records
    )
    assert all(t["nowrap"] for r in records for t in r["tables"])
    result = dict(
        result="PASS" if not bad else "FAIL",
        browser=call("Browser.getVersion"),
        observations=records,
        left_edge_failures=bad,
        limits="Desktop Chromium actual page geometry with default local fonts loaded; HTTP(S) requests blocked before navigation. No mobile emulation, other-engine or source/editorial claim.",
    )
    (OUT / "browser-cdp-result.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8"
    )
    assert not bad, bad
    print(
        json.dumps(
            dict(
                result="PASS",
                browser=result["browser"],
                page_viewports=len(records),
                table_observations=sum(len(r["tables"]) for r in records),
                elapsed_seconds=time.monotonic() - started,
            ),
            indent=2,
        )
    )
finally:
    (OUT / "browser-cdp-command.json").write_text(
        json.dumps(command, indent=2) + "\n", encoding="utf-8"
    )
    (OUT / "browser-cdp-calls.json").write_text(
        json.dumps(calls, indent=2) + "\n", encoding="utf-8"
    )
    if ws:
        ws.close()
    process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)

"""Offline actual Chromium geometry for representative affected table families."""

from html.parser import HTMLParser
import json
from pathlib import Path
import subprocess

OUT = Path("/workspace/scratch/basics-a5b89a8d-artifacts")
ROOT = Path.cwd() / "gh-pages"
pages = [
    "wlc/420422/index.html",
    "wlc/420422/index-rejects.html",
    "wlc/wlc-a-notes/index.html",
    "wlc/accgram/printed-decalogue.html",
    "wlc/accgram/printed-decalogue-uvinkha.html",
    "MAM-simple/versification-and-cantillation.html",
    "wlc/420422/full-record/420422-33.html",
    "post-stress-meteg/post-stress-meteg-post-silluq-1s17v5.html",
]
assert all((ROOT / p).is_file() for p in pages)
wrapper = OUT / "browser-probe.html"
wrapper.write_text(
    """<!doctype html><meta charset="utf-8"><title>Offline geometry probe</title>
<pre id="result">PENDING</pre>
<script>
const pages = PAGES;
const root = ROOT;
const widths = [320, 375, 768, 1024, 1440];
(async () => {
 const results = [];
 for (const width of widths) for (const page of pages) {
  const frame = document.createElement('iframe');
  frame.style.cssText = `width:${width}px;height:900px;border:0;display:block`;
  const loaded = new Promise(resolve => frame.onload = resolve);
  frame.src = root + page; document.body.append(frame); await loaded;
  const doc = frame.contentDocument, win = frame.contentWindow;
  await doc.fonts.ready;
  const tables = [...doc.querySelectorAll('table')].map((table, i) => {
   const rect = table.getBoundingClientRect(), style = win.getComputedStyle(table);
   return {index:i, class:table.className, direction:table.getAttribute('dir'), x:rect.x, right:rect.right, width:rect.width, maxWidth:style.maxWidth, transform:style.transform, targeted:doc.body.classList.contains('centered-page') || table.matches('table[dir="rtl"],table.strand-table'), nowrap:[...table.querySelectorAll('.nowrap')].every(cell => win.getComputedStyle(cell).whiteSpace === 'nowrap')};
  });
  results.push({page,width,innerWidth:win.innerWidth,bodyX:doc.body.getBoundingClientRect().x,bodyWidth:doc.body.getBoundingClientRect().width,scrollWidth:doc.documentElement.scrollWidth,fonts:doc.fonts.status,taameyLoaded:[...doc.fonts].filter(f => f.family.includes('Taamey')).map(f=>f.status),tables});
  frame.remove();
 }
 document.querySelector('#result').textContent = JSON.stringify({result:'COMPLETE',userAgent:navigator.userAgent,results});
})().catch(e => {document.querySelector('#result').textContent = JSON.stringify({error:String(e),stack:e.stack});});
</script>""".replace("PAGES", json.dumps(pages)).replace(
        "ROOT", json.dumps(ROOT.as_uri() + "/")
    ),
    encoding="utf-8",
)
command = [
    "/usr/bin/chromium",
    "--headless",
    "--no-sandbox",
    "--disable-gpu",
    "--disable-background-networking",
    "--disable-component-update",
    "--disable-sync",
    "--no-first-run",
    "--no-default-browser-check",
    "--disable-extensions",
    "--host-resolver-rules=MAP * ~NOTFOUND",
    "--allow-file-access-from-files",
    "--user-data-dir=" + str(OUT / "browser-profile"),
    "--dump-dom",
    "--virtual-time-budget=30000",
    wrapper.as_uri(),
]
completed = subprocess.run(command, capture_output=True, timeout=60)
(OUT / "browser-command.json").write_text(
    json.dumps(command, indent=2) + "\n", encoding="utf-8"
)
(OUT / "browser-dom.html").write_bytes(completed.stdout)
(OUT / "browser-stderr.txt").write_bytes(completed.stderr)
assert completed.returncode == 0, completed.returncode


class Result(HTMLParser):
    def __init__(self):
        super().__init__()
        self.inside = False
        self.text = ""

    def handle_starttag(self, tag, attrs):
        if tag == "pre" and dict(attrs).get("id") == "result":
            self.inside = True

    def handle_endtag(self, tag):
        if tag == "pre":
            self.inside = False

    def handle_data(self, data):
        if self.inside:
            self.text += data


parser = Result()
parser.feed(completed.stdout.decode("utf-8"))
result = json.loads(parser.text)
(OUT / "browser-result.json").write_text(
    json.dumps(result, indent=2) + "\n", encoding="utf-8"
)
assert result["result"] == "COMPLETE", result
assert len(result["results"]) == len(pages) * 5
bad = []
for record in result["results"]:
    assert record["width"] == record["innerWidth"] and record["fonts"] == "loaded"
    for table in record["tables"]:
        assert table["nowrap"]
        if table["targeted"] and table["x"] < -0.5:
            bad.append(dict(page=record["page"], viewport=record["width"], table=table))
(OUT / "browser-left-edge-failures.json").write_text(
    json.dumps(bad, indent=2) + "\n", encoding="utf-8"
)
assert not bad, bad
print(
    json.dumps(
        dict(
            result="PASS",
            browser=result["userAgent"],
            page_viewports=len(result["results"]),
            table_observations=sum(len(r["tables"]) for r in result["results"]),
            target="Every affected table in eight representative pages stays reachable at the left edge; nowrap declarations compute correctly.",
            limits="Actual desktop Chromium frame geometry, not mobile emulation, screenshot/manual visual review, other engines or original-source adjudication.",
        ),
        indent=2,
    )
)

"""Independent exact endpoint accounting; no new source/editorial claim."""

import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess

BASE = "bf302bb9e27ed0de4cbfcfc4c4ff51e6e06741be"
HEAD = "a5b89a8df9eb0ce6fd821e91c7b002f0c117c8d2"
OUT = Path("/workspace/scratch/basics-a5b89a8d-artifacts")


def git(*args):
    return subprocess.check_output(["git", *args])


def read(ref, path):
    return git("show", f"{ref}:{path}").decode("utf-8")


def norm(text):
    return re.sub(r"\s+", " ", text).strip()


paths = git("diff", "--name-only", "-z", BASE, HEAD).decode().strip("\0").split("\0")
assert len(paths) == 13
identities = {}
for path in paths:
    identities[path] = {}
    for side, ref in [("base", BASE), ("head", HEAD)]:
        raw = git("show", f"{ref}:{path}")
        blob = git("rev-parse", f"{ref}:{path}").decode().strip()
        assert (
            hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
            == blob
        )
        identities[path][side] = dict(
            blob=blob, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()
        )
        (OUT / (side + "-" + path.replace("/", "--"))).write_bytes(raw)

lists = {}
for name, count in [("index.html", 55), ("index-rejects.html", 15)]:
    path = "gh-pages/wlc/420422/" + name
    old, new = [read(ref, path) for ref in [BASE, HEAD]]
    tables = [re.findall(r"<table.*?</table>", page, re.S) for page in [old, new]]
    assert len(tables[0]) == len(tables[1]) == 2
    rows = [re.findall(r"<tr>(.*?)</tr>", ts[0], re.S) for ts in tables]
    assert len(rows[0]) == len(rows[1]) == count + 1
    for a, b in zip(*rows):
        before = re.findall(r"<t[dh]\b.*?</t[dh]>", a, re.S)
        after = re.findall(r"<t[dh]\b.*?</t[dh]>", b, re.S)
        assert len(before) == len(after) == 4
        expected = [before[2], before[0], before[1], before[3]]
        if "<td" in a:
            expected[1] = expected[1].replace(
                "<td>", '<td class="nowrap bcv-beside-hebrew">', 1
            )
            expected[2] = expected[2].replace("<td>", '<td class="nowrap">', 1)
            assert 'lang="hbo" dir="rtl"' in after[0]
        assert list(map(norm, expected)) == list(map(norm, after))
    assert norm(tables[0][1].replace("<tr><td>", '<tr><td class="nowrap">')) == norm(
        tables[1][1]
    )
    assert norm(re.sub(r"<table.*?</table>", "TABLE", old, flags=re.S)) == norm(
        re.sub(r"<table.*?</table>", "TABLE", new, flags=re.S)
    )
    assert Counter(re.findall(r'href="([^"]+)"', old)) == Counter(
        re.findall(r'href="([^"]+)"', new)
    )
    lists[name] = dict(
        records=count,
        abbreviations=len(re.findall(r"<tr>", tables[1][1])),
        preserved="All cell contents/attributes exact after declared reorder, two cell classes, and abbreviation nowrap; whitespace folding only.",
    )

path = "gh-pages/index.html"
assert read(BASE, path).replace(
    " (AI-generated translation, not yet reviewed by a human)", "", 1
) == read(HEAD, path)
page = "gh-pages/MAM-with-doc/misc/he_ws_intro_to_mam_gaya_text.html"
assert read(BASE, page) == read(HEAD, page) and '<p class="ai-caveat">' in read(
    HEAD, page
)
for path in [
    "py/author_misc/he_ws_intro_to_mam_gaya_text.py",
    "py/py_html/wlc_utils_html.py",
]:
    trees = [ast.parse(read(ref, path)) for ref in [BASE, HEAD]]
    for tree in trees:
        if (
            isinstance(tree.body[0], ast.Expr)
            and isinstance(tree.body[0].value, ast.Constant)
            and isinstance(tree.body[0].value.value, str)
        ):
            tree.body.pop(0)
    assert ast.dump(trees[0]) == ast.dump(trees[1]), path
assert (
    Path(
        "py/versification_and_cantillation/versification-and-cantillation.css"
    ).read_bytes()
    == Path("gh-pages/MAM-simple/versification-and-cantillation.css").read_bytes()
)
html_paths = (
    git("ls-tree", "-r", "--name-only", "-z", HEAD, "gh-pages")
    .decode()
    .strip("\0")
    .split("\0")
)
centered = []
limited = []
for path in html_paths:
    if not path.endswith(".html"):
        continue
    text = Path(path).read_text(encoding="utf-8")
    if '<body class="centered-page">' in text:
        centered.append(path)
        assert 'document.css"' in text and 'style.css"' in text
        if re.search(r'<table[^>]*class="[^"]*\blimited-width\b', text):
            limited.append(path)
result = dict(
    result="PASS",
    base=BASE,
    head=HEAD,
    changed_paths=paths,
    identities=identities,
    lists=lists,
    centered_pages=len(centered),
    limited_width_pages=len(limited),
    css_copy="byte-identical",
    caveat="Only duplicate index caveat removed; complete page with caveat byte-identical.",
    docstring_comment_only="Both changed modules AST-identical after module-docstring exclusion.",
    limits="Output/codepoint and declared presentation consistency only; no new source/editorial/manuscript claim. Browser evidence recorded separately.",
)
(OUT / "independent-result.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
)
print(
    json.dumps(
        {k: v for k, v in result.items() if k not in ["identities", "changed_paths"]},
        ensure_ascii=False,
        indent=2,
    )
)

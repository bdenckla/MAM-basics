"""Admit one idle isolated hourly window, retaining local ownership evidence."""
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys

root,kind,source=Path(sys.argv[1]),sys.argv[2],sys.argv[3]
public_input=sys.argv[4] if len(sys.argv)>4 else None
assert not root.exists()
claimed=[]
for p in Path('/workspace/scratch').glob('*slot*'):
 f=p if p.is_file() and p.suffix=='.json' else p/'owner.json'
 if f.is_file() and json.loads(f.read_bytes()).get('state')!='released':claimed.append(str(f))
assert not claimed,claimed
active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  args=(p/'cmdline').read_bytes().decode().split('\0')
  if args and Path(args[0]).name in {'python','python3','python3.13','pytest'} and any(a in {'py/main_0_mega.py','py/main_test.py','py/main_ocr.py','py/main_diff.py','unittest'} for a in args[1:]):active.append(args)
 except (OSError,UnicodeError):pass
assert not active,active
homes={}
for name in ['basics','private']:
 p=Path('/workspace/MAM-'+name)
 status=subprocess.check_output(['git','-C',str(p),'status','--porcelain=v1','-z']);assert not status
 homes[name]={'head':subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD']).decode().strip(),'worktrees':subprocess.check_output(['git','-C',str(p),'worktree','list','--porcelain']).decode()}
root.mkdir();(root/'evidence').mkdir()
record={'state':'claimed','owner':'saved-cloud '+kind+' '+source[:8]+' hourly screen','source':source,'claimed_utc':datetime.now(timezone.utc).isoformat(),'cross_machine':'unverified; idle local forest and coordinator admission'}
Path(str(root)+'-slot.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[(kind,'head',source)]
if public_input:jobs.append(('basics','public-input',public_input))
for name,folder,ref in jobs:
 subprocess.run(['git','-C','/workspace/MAM-'+name,'worktree','add','--detach',str(root/folder),ref],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 assert subprocess.check_output(['git','-C',str(root/folder),'rev-parse','HEAD']).decode().strip()==ref
# The public run records only its public home, never private checkout metadata.
(root/'evidence/admission.json').write_text(json.dumps({'observed_utc':datetime.now(timezone.utc).isoformat(),'source':source,'public_input':public_input,'home':homes if kind=='private' else {'basics':homes['basics']},'active_checks':active,'other_claimed_slots':claimed,'cross_machine':'unverified'},indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(record,indent=2))

"""Freeze completed evidence and prepare exactly three isolated receipt paths."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "evidence"
TREE = ROOT / "head"
RECEIPTS = ROOT / "receipts"
BASE = "8f686dca6d3651b86dc824ae7c53d96f73e6d34a"
SOURCE = "4214fd938d0bfaa92e693f09bfbc1b7207e0a451"
PARENT = "5a1df63a8907752324bf61c50d17cc154f7d39cb"
BRANCH = "review-hourly-20261113-7173440e-basics-receipts"
NAME = "review-hourly-2026-11-13-4214fd93-basics"


def git(*args, tree=TREE):
    return subprocess.check_output(["git", "-C", str(tree), *args])


def dump(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


assert git("rev-parse", "HEAD").decode().strip() == SOURCE
assert not git("status", "--porcelain=v1", "-z")
assert git("rev-parse", "HEAD", tree=RECEIPTS).decode().strip() == PARENT
assert git("branch", "--show-current", tree=RECEIPTS).decode().strip() == BRANCH
assert not git("status", "--porcelain=v1", "-z", tree=RECEIPTS)
stages = {}
for name in ("black", "gen-site", "tests", "html", "probes", "javascript"):
    result = json.loads((OUT / (name + ".json")).read_bytes())
    assert result["exit"] == (1 if name == "html" else 0)
    assert (
        not (OUT / (name + ".diff")).read_bytes()
        and not (OUT / (name + ".status")).read_bytes()
    )
    stages[name] = result
probe = json.loads((OUT / "probe-result.json").read_bytes())
js = json.loads((OUT / "js-result.json").read_bytes())
assert "13 passed" in (OUT / "tests.log").read_text(encoding="utf-8")
assert probe["rows"] == 36 and probe["edition_records"] == {
    "koren": 33,
    "simanim-tanakh": 17,
}
assert probe["shared"] == 14 and probe["single"] == 22
assert probe["pngs"] == 56 and probe["linked_images"] == 52
assert js["query_group_combinations"] == 2944 and js["event_paths_per_combination"] == 2
html_log = (OUT / "html.log").read_text(encoding="utf-8")
assert set(
    line.removeprefix("orphan image: ")
    for line in html_log.splitlines()
    if line.startswith("orphan image: ")
) == set(probe["retained_orphans"])
assert (
    "Found 4 issue(s)." in html_log
    and "103 undefined CSS class reference(s)" in html_log
)
disposition = {
    "outcome": "No consequential introduced defect established; no product repair.",
    "window": [BASE, SOURCE],
    "receipt_parent": PARENT,
    "scope": "One commit, five paths, 29 insertions and 13 deletions: optional comparison_crops rendering/validation, two Koren PNGs, two input records and their generated rows.",
    "data_and_dom": "All 50 records retain identity, order and every field except two declared notes and supplemental crop mappings. Every DOM row reconciles with source forms, reading labels, scan identities, note text and public MAM body/qere destinations. Only two page lines differ; all other rows, menu and controls are byte-identical at endpoints.",
    "reference_images": "Extra Koren crop evidence remains separate from source-edition membership: both affected rows retain Sim-only filters, reading labels and original page/scan citations. Crops render in Koren-then-SimTan edition order with correct alt text and visible labels. Existing/no-optional-field and same-edition supplemental behavior also verified.",
    "rejections": "Unknown edition, empty supplemental list, traversal, absolute path, wrong directory and missing image each reject through render before any output change. No arbitrary malformed-schema/error-class requirement is imposed.",
    "retained_html_failure": "HTML exits 1 for the same four intentionally retained orphan Decalogue crops; 103 CSS references are informational. No HTML-clean claim and no removal.",
    "javascript": "Actual unchanged controls.js passes 2,944 query/group combinations through both input/change handlers in a minimal DOM. The Koren query plus redundant-edition-Sim menu keeps the two Sim-only rows discoverable. Search trimming/case/mark behavior, empty/singular/plural counts, clearing, size/reset and image toggles pass.",
    "overall_reviewed": "210affe3ac2931473bead0de839be0de08309e3d",
    "broad_tested": "9ed47c6e8999ecaf56031e9b3f524bee6e01507a",
    "preservation": "Receipt parent preserves every older status row, pending window, finished receipt, November 13 nightly/Windows 3030161007bc393f554cf0c95cf819ed4d81a93c evidence and Taamey D limitations.",
    "source_limits": "The owner-cited oldid3102618, MAM lag, thirteen-case census, printed-source readings and likely Chronicles error/linked issue remain attributed prior research. No new external-source, issue or manuscript investigation and no editorial adjudication.",
    "limits": "No browser, HP/laptop, full-suite/mega/nightly rerun, Private review, hbofonts work, font/baseline acceptance, source refresh, main/shared integration, dispatch, deployment or scheduling. Local admission verified; cross-machine ownership remains unverified.",
    "publication": "Preparation only; actual push and cleanup are recorded later in publication.json and closeout.json.",
}
(OUT / "disposition.json").write_bytes(dump(disposition))
completed = {
    "state": "completed",
    "source": SOURCE,
    "completed_utc": datetime.now(timezone.utc).isoformat(),
    "stages": stages,
    "outcome": disposition["outcome"],
    "known_failure": disposition["retained_html_failure"],
}
(ROOT / "stage.json").write_bytes(dump(completed))
(OUT / "stage.json").write_bytes(dump(completed))
payload = {p.name: p.read_bytes() for p in OUT.iterdir() if p.is_file()}
for name in (
    "setup.py",
    "run.py",
    "probe.py",
    "js-probe.cjs",
    "prepare.py",
    "adapt-publisher.py",
    "publish.py",
):
    payload["checkers/" + name] = (ROOT / name).read_bytes()
for source, name in (
    (Path("/workspace/scratch/admit_window_20261112.py"), "admit.py"),
    (Path("/workspace/scratch/window_controls_20261112.py"), "window-controls.py"),
):
    payload["checkers/" + name] = source.read_bytes()
payload["manifest.json"] = dump(
    {
        name: {"bytes": len(raw), "sha256": sha(raw)}
        for name, raw in sorted(payload.items())
    }
)
archive = RECEIPTS / "doc" / (NAME + "-evidence.zip")
assert not archive.exists()
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as z:
    for name, raw in sorted(payload.items()):
        z.writestr(name, raw)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist()))
    for name, entry in json.loads(z.read("manifest.json")).items():
        assert (
            len(z.read(name)) == entry["bytes"] and sha(z.read(name)) == entry["sha256"]
        )
report = f"""# Bounded Basics screen, November 13, 2026, 23:00 UTC cycle

State: completed 2026-11-13; focused technical review, no product repair

Reviewed `{BASE}` → `{SOURCE}`: **one commit / five paths**, 29 insertions / 13 deletions. No consequential introduced defect established. The optional `comparison_crops` field adds Koren reference images to two Simanim Tanakh differences without changing their Sim-only menu membership, reading labels or page/scan citations. All **50 edition records** (33 Koren / 17 Simanim Tanakh), **36 rows** (14 shared / 22 single) and nine populated exact-set menu choices reconcile independently. Only the two intended page lines change; every other row, menu and control remains byte-identical.

`gen-site --trust-surveys` reproduces tracked outputs exactly; changed-source Black and **13 selected site/style/prose tests** pass. HTML validation **exits 1** for the same four retained orphan Decalogue crops, with 103 informational CSS references. Independent checks pass for **156 local attributes**, public MAM body/qere destinations, **56 PNGs / 52 linked images**, six invalid supplemental-evidence cases rejected before output, and four valid grouping cases including omission of the optional field. Image grouping/order, labels and alt text agree with an independent source/DOM oracle.

The actual unchanged `controls.js` passes **2,944 query/group combinations through each of two handlers** in a minimal Node DOM, including a Koren search with the Sim-only menu. Size/reset and image toggles pass. This supplies no browser, layout, font or accessibility-tree evidence. Printed readings, source revisions, MAM lag, the thirteen-case census and existing issue interpretation remain owner-attributed research; no source-image editorial or manuscript judgment was made.

The [evidence archive]({archive.name}) retains exact commands, UTC times, logs, complete endpoint/generated diffs, statuses, checker scripts, committed asset identities and hashes. Receipt parent `{PARENT}` preserves all earlier rows, pending gaps, finished receipts and November 13 nightly/Windows evidence. Overall reviewed `210affe3ac2931473bead0de839be0de08309e3d` and broad-tested `9ed47c6e8999ecaf56031e9b3f524bee6e01507a` remain unchanged. No broad rerun, Private/hbofonts work, main/shared integration, dispatch, deployment or schedule change. Publication and cleanup are separate later closeout steps; cross-machine ownership is unverified.
"""
(RECEIPTS / "doc" / (NAME + ".md")).write_text(report, encoding="utf-8", newline="\n")
status = RECEIPTS / "doc/review-trial-status.md"
before = status.read_text(encoding="utf-8")
section = f"""## Bounded screen, 2026-11-13 23:00 UTC cycle, 4214fd93

Reviewed `{BASE}` → `{SOURCE}`: one commit / five paths; no consequential introduced defect or product repair. Two Koren reference crops preserve Sim-only difference membership and reading labels. All 50 records, 36 rows (14 shared/22 single) and nine menu choices reconcile; only two intended page lines change. gen-site is exact; Black and 13 focused tests pass. HTML exits 1 for four retained orphan crops (103 informational CSS references). Independent 156-local-attribute, 56-PNG/52-linked, six invalid-input rejection, four valid-grouping and 2,944 actual-JS combination checks pass. No browser or new source/editorial judgment. [Receipt]({NAME}.md), [evidence]({archive.name}).

Receipt parent `{PARENT}` preserves historical rows, pending windows, finished receipts and November 13 nightly/Windows evidence. Overall reviewed `210affe3ac2931473bead0de839be0de08309e3d` and broad-tested `9ed47c6e8999ecaf56031e9b3f524bee6e01507a` remain unchanged. Preparation only; publication/cleanup have separate later evidence. No Private, hbofonts, main/shared/deployment or schedule work.

"""
anchor = "## Bounded screen, 2026-11-13 22:00 UTC cycle, 8f686dca"
assert before.count(anchor) == 1
after = before.replace(anchor, section + anchor, 1)
table = "| Anchor | Commit/result |\n| --- | --- |\n"
rows = f"| Bounded screen 4214fd93, 2026-11-13 23:00 UTC | `{BASE}` → `{SOURCE}`; one commit / five paths; no consequential defect or repair. [Receipt]({NAME}.md). |\n| Focused evidence 4214fd93 | gen-site exact; 13 tests/Black pass; HTML exit 1 for four retained orphan crops. 50 records/36 rows/nine choices; 156 local attributes; 56 PNGs/52 linked; six rejection/four grouping cases; 2,944 Node combinations. [Evidence]({archive.name}). |\n"
assert after.count(table) == 1
after = after.replace(table, table + rows, 1)
assert after.replace(section, "", 1).replace(rows, "", 1) == before
status.write_text(after, encoding="utf-8", newline="\n")
paths = sorted(
    [
        "doc/" + NAME + ".md",
        "doc/" + NAME + "-evidence.zip",
        "doc/review-trial-status.md",
    ]
)
changed = set(
    filter(None, git("diff", "--name-only", "-z", tree=RECEIPTS).decode().split("\0"))
) | set(
    filter(
        None,
        git("ls-files", "--others", "--exclude-standard", "-z", tree=RECEIPTS)
        .decode()
        .split("\0"),
    )
)
assert changed == set(paths)
git("diff", "--check", tree=RECEIPTS)
record = {
    "branch": BRANCH,
    "parent": PARENT,
    "source": SOURCE,
    "paths": paths,
    "archive": {
        "path": archive.name,
        "bytes": archive.stat().st_size,
        "sha256": sha(archive.read_bytes()),
        "payload_files": len(payload) - 1,
    },
    "prepared_utc": datetime.now(timezone.utc).isoformat(),
}
(ROOT / "publication-prepared.json").write_bytes(dump(record))
print(json.dumps(record, indent=2))

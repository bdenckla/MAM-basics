"""Prepare a receipt publisher or clean only one finished owned endpoint task."""

from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys

action, root_arg, kind, source = sys.argv[1:5]
root = Path(root_arg)
if action == "publisher":
    code = Path("/workspace/scratch/publish_nightly_receipt_20261112.py").read_text()
    code = code.replace(
        "kind = sys.argv[1]\nassert kind in {'basics', 'private'}", f"kind = {kind!r}"
    )
    code = code.replace(
        "task = Path('/workspace/scratch/nightly-20261112')",
        f"task = Path({str(root)!r})",
    )
    code = (
        code.replace(
            "(kind + '-publication-prepared.json')", "'publication-prepared.json'"
        )
        .replace("tree = task / (kind + '-receipts')", "tree = task / 'receipts'")
        .replace("(kind + '-publication.json')", "'publication.json'")
    )
    code = code.replace(
        "Record November 12 nightly checks and retained limitations",
        "Record bounded November 12 endpoint screen",
    )
    target = root / "publish.py"
    assert not target.exists()
    target.write_text(code, encoding="utf-8", newline="\n")
    print(target)
    raise SystemExit(0)
assert action == "cleanup"


def git(repo, *args):
    return subprocess.check_output(["git", "-C", str(repo), *args])


home = Path("/workspace/MAM-" + kind)
expected = {
    "basics": "cb878aef91e692d5561435f00021f73b75868e45",
    "private": "651e66af1b254cff11ea4cc0ec794700a8e1c647",
}[kind]
pub = json.loads((root / "publication.json").read_bytes())
assert pub["push_state"] == "verified"
assert (
    git(home, "ls-remote", "origin", "refs/heads/" + pub["branch"]).decode()
    == pub["commit"] + "\trefs/heads/" + pub["branch"] + "\n"
)
assert (
    not git(home, "status", "--porcelain=v1", "-z")
    and git(home, "rev-parse", "HEAD").decode().strip() == expected
)
assert json.loads((root / "stage.json").read_bytes())["state"] == "completed"
slot = Path(str(root) + "-slot.json")
data = json.loads(slot.read_bytes())
assert data["state"] == "claimed" and data["source"] == source
active = []
for p in Path("/proc").iterdir():
    if not p.name.isdigit():
        continue
    try:
        args = (p / "cmdline").read_bytes().decode().split("\0")
        if (
            args
            and Path(args[0]).name in {"python", "python3", "python3.13", "pytest"}
            and any(
                a
                in {
                    "py/main_0_mega.py",
                    "py/main_test.py",
                    "py/main_ocr.py",
                    "py/main_diff.py",
                    str(root / "run.py"),
                }
                for a in args[1:]
            )
        ):
            active.append(args)
    except (OSError, UnicodeError):
        pass
assert not active, active
trees = [(home, root / "head", source), (home, root / "receipts", pub["commit"])]
if (root / "public-input").exists():
    assert kind == "private"
    trees.append(
        (
            Path("/workspace/MAM-basics"),
            root / "public-input",
            git(root / "public-input", "rev-parse", "HEAD").decode().strip(),
        )
    )
removed = []
for owning, tree, head in trees:
    assert git(tree, "rev-parse", "HEAD").decode().strip() == head
    assert not git(tree, "status", "--porcelain=v1", "-z")
    r = subprocess.run(
        ["git", "-C", str(owning), "worktree", "remove", str(tree)], capture_output=True
    )
    e = {
        "path": str(tree),
        "head": head,
        "exit": r.returncode,
        "stderr": r.stderr.decode(),
    }
    if r.returncode:
        assert b"contains modified or untracked files" in r.stderr
        assert not git(tree, "status", "--porcelain=v1", "-z")
        r = subprocess.run(
            ["git", "-C", str(owning), "worktree", "remove", "--force", str(tree)],
            capture_output=True,
        )
        e.update(
            ignored_scratch_exit=r.returncode, ignored_scratch_stderr=r.stderr.decode()
        )
        assert r.returncode == 0
    assert not tree.exists()
    removed.append(e)
data.update(
    state="released",
    released_utc=datetime.now(timezone.utc).isoformat(),
    reason="Isolated receipt and exact evidence remotely verified; completed owned worktrees removed.",
)
slot.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8", newline="\n")
assert (
    not git(home, "status", "--porcelain=v1", "-z")
    and git(home, "rev-parse", "HEAD").decode().strip() == expected
)
inventory = git(home, "worktree", "list", "--porcelain").decode()
assert str(root) not in inventory
result = {
    "observed_utc": datetime.now(timezone.utc).isoformat(),
    "removed": removed,
    "home": {
        "path": str(home),
        "head": expected,
        "clean": True,
        "worktree_inventory": inventory,
    },
    "slot": {"path": str(slot), **data},
    "active_checks": active,
    "receipt_commit": pub["commit"],
    "artifacts": str(root),
}
target = root / "closeout.json"
assert not target.exists()
target.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(result, indent=2))

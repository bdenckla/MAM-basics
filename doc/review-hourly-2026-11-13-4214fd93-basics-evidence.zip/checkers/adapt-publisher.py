"""Adapt the inspected normal-fast-forward publisher for this exact receipt."""

from pathlib import Path

root = Path(__file__).resolve().parent
code = Path("/workspace/scratch/basics-8f686dca/publish.py").read_text(encoding="utf-8")
code = code.replace("/workspace/scratch/basics-8f686dca", str(root))
code = code.replace(
    "November 13 22:00 UTC endpoint screen", "November 13 23:00 UTC endpoint screen"
)
start = code.index('status = tree / "doc/review-trial-status.md"')
end = code.index("changed = set(", start)
code = code[:start] + "link_updates = []\n" + code[end:]
code = code.replace(
    "assert len(z.namelist()) == len(set(z.namelist()))",
    'assert len(z.namelist()) == len(set(z.namelist()))\n    assert set(z.namelist()) == set(manifest) | {"manifest.json"}',
)
target = root / "publish.py"
assert not target.exists()
target.write_text(code, encoding="utf-8", newline="\n")

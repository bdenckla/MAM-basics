"""Take the exact existing receipt branch after repeated identity/ownership checks."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
HOME = Path("/workspace/MAM-basics")
TREE = ROOT / "head"
PARENT = "5a1df63a8907752324bf61c50d17cc154f7d39cb"
SOURCE = "4214fd938d0bfaa92e693f09bfbc1b7207e0a451"
BRANCH = "review-hourly-20261113-7173440e-basics-receipts"


def git(*args, tree=HOME):
    return subprocess.check_output(["git", "-C", str(tree), *args])


assert git("rev-parse", "HEAD", tree=TREE).decode().strip() == SOURCE
assert not git("status", "--porcelain=v1", "-z", tree=TREE)
assert git("rev-parse", "refs/heads/" + BRANCH).decode().strip() == PARENT
assert (
    git("ls-remote", "origin", "refs/heads/" + BRANCH).decode()
    == PARENT + "\trefs/heads/" + BRANCH + "\n"
)
inventory = git("worktree", "list", "--porcelain").decode()
assert "branch refs/heads/" + BRANCH + "\n" not in inventory
assert not (ROOT / "receipts").exists()
subprocess.run(
    ["git", "-C", str(HOME), "worktree", "add", str(ROOT / "receipts"), BRANCH],
    capture_output=True,
    check=True,
)
assert git("rev-parse", "HEAD", tree=ROOT / "receipts").decode().strip() == PARENT
assert not git("status", "--porcelain=v1", "-z", tree=ROOT / "receipts")
instructions = [
    "AGENTS.md",
    "dot-Codex/user-wide-AGENTS.md",
    "doc/review-trial.md",
    "doc/periodic-review.md",
    "doc/review-trial-status.md",
    "dot-claude/skills/linked-worktrees/SKILL.md",
    "dot-Codex/skills/codex-worktree-tasks/SKILL.md",
    "dot-claude/skills/iterative-document-editing/SKILL.md",
    "dot-claude/skills/hebrew-prose/SKILL.md",
    "dot-claude/skills/hebrew-prose/references/mam-basics.md",
    "dot-claude/skills/hebrew-prose/references/rendered-prose.md",
    "dot-claude/skills/hebrew-prose/references/verifying.md",
]
record = {
    "observed_utc": datetime.now(timezone.utc).isoformat(),
    "source": SOURCE,
    "receipt_parent": PARENT,
    "branch": BRANCH,
    "receipt_worktree": str(ROOT / "receipts"),
    "prior_worktrees": inventory,
    "instruction_files": {
        p: hashlib.sha256((TREE / p).read_bytes()).hexdigest() for p in instructions
    },
    "admission_command": [
        "/workspace/MAM-basics/.venv/bin/python",
        "-B",
        "/workspace/scratch/admit_window_20261112.py",
        str(ROOT),
        "basics",
        SOURCE,
    ],
    "setup_command": [
        "/workspace/MAM-basics/.venv/bin/python",
        "-B",
        str(ROOT / "setup.py"),
    ],
    "read_only_lookup_notes": "Initial ls/cat confirmed live .agents/.codex dirs empty and home has no local .agents/.codex dirs; canonical frozen source instructions read with git show then from admitted checkout. The initial lookups changed no source files; maintained check outcomes are recorded separately.",
}
(ROOT / "evidence/setup.json").write_text(
    json.dumps(record, indent=2) + "\n", encoding="utf-8", newline="\n"
)
print(
    json.dumps(
        {
            k: record[k]
            for k in (
                "observed_utc",
                "source",
                "receipt_parent",
                "branch",
                "receipt_worktree",
            )
        },
        indent=2,
    )
)

"""Reconcile every source record with DOM and lint supplemental crop handling."""

from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from urllib.parse import unquote, urlsplit

from lxml import html
from PIL import Image

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "head"
OUT = ROOT / "evidence"
BASE = "8f686dca6d3651b86dc824ae7c53d96f73e6d34a"
SOURCE = "4214fd938d0bfaa92e693f09bfbc1b7207e0a451"
PARENT = "5a1df63a8907752324bf61c50d17cc154f7d39cb"
sys.path.insert(0, str(TREE / "py"))  # Disposable scratch harness only.
from author_site import stress_helper_comparison as renderer
from mb_cmn import uni_denorm


def git(*args):
    return subprocess.check_output(["git", "-C", str(TREE), *args])


def save(name, value):
    (OUT / name).write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def text(node):
    return " ".join(node.text_content().split())


def identity(r):
    return tuple(
        r.get(k)
        for k in (
            "book",
            "chapter",
            "verse",
            "strand",
            "instance",
            "mam",
            "printed",
            "verse_href",
            "category",
        )
    )


def crop_oracle(sources):
    pairs = []
    for edition in ("koren", "simanim-tanakh"):
        primary = sources.get(edition, {}).get("crops", [])
        extra = [
            p
            for record in sources.values()
            for p in record.get("comparison_crops", {}).get(edition, [])
        ]
        pairs.extend((edition, p) for p in primary + extra)
    return pairs


def check_crops(row, sources):
    expected = crop_oracle(sources)
    anchors = row.xpath('./td[@class="scan"]/a')
    assert len(anchors) == len(expected)
    labeled = len({e for e, p in expected}) > 1
    ref = text(row.xpath("./th/a")[0])
    for anchor, (edition, path) in zip(anchors, expected):
        short, full = (
            ("Koren", "Koren")
            if edition == "koren"
            else ("SimTan", "the Simanim Tanakh")
        )
        assert anchor.get("href") == path and anchor.xpath("./img/@src") == [path]
        assert anchor.xpath("./img/@alt") == [full + " scan crop for " + ref]
        assert anchor.xpath("./img/@loading") == ["lazy"] and anchor.xpath(
            "./img/@decoding"
        ) == ["async"]
        assert [text(n) for n in anchor.xpath('./span[@class="source"]')] == (
            [short] if labeled else []
        )


assert git("rev-parse", "HEAD").decode().strip() == SOURCE
assert not git("status", "--porcelain=v1", "-z")
changed = [
    p for p in git("diff", "--name-only", "-z", BASE, SOURCE).decode().split("\0") if p
]
assert len(changed) == 5
git("diff", "--check", BASE, SOURCE)
save(
    "identities.json",
    {
        p: {
            "bytes": len((TREE / p).read_bytes()),
            "sha256": hashlib.sha256((TREE / p).read_bytes()).hexdigest(),
        }
        for p in changed
    },
)
(OUT / "endpoint.diff").write_bytes(git("diff", BASE, SOURCE))
(OUT / "commits.txt").write_bytes(git("log", "--format=fuller", BASE + ".." + SOURCE))
inputs, groups, deltas = {}, {}, []
for edition in ("koren", "simanim-tanakh"):
    path = "in/stress-helpers/" + edition + ".json"
    data = json.loads((TREE / path).read_bytes())
    old = json.loads(git("show", BASE + ":" + path))
    assert len(data["differences"]) == len(old["differences"])
    assert {k: v for k, v in data.items() if k != "differences"} == {
        k: v for k, v in old.items() if k != "differences"
    }
    for before, after in zip(old["differences"], data["differences"]):
        assert {
            k: v for k, v in before.items() if k not in {"notes", "comparison_crops"}
        } == {k: v for k, v in after.items() if k not in {"notes", "comparison_crops"}}
        if before != after:
            deltas.append(
                {
                    "edition": edition,
                    "identity": identity(after),
                    "before_notes": before.get("notes"),
                    "after_notes": after.get("notes"),
                    "comparison_crops": after.get("comparison_crops"),
                }
            )
        groups.setdefault(identity(after), {})[edition] = after
        assert all(uni_denorm.has_std_mark_order(after[f]) for f in ("mam", "printed"))
    inputs[edition] = data
assert len(deltas) == 2 and all(
    d["edition"] == "simanim-tanakh" and set(d["comparison_crops"]) == {"koren"}
    for d in deltas
)
save("data-deltas.json", deltas)
target = TREE / "gh-pages/stress-helpers/index.html"
doc = html.fromstring(target.read_bytes())
rows = doc.xpath('//table[@id="observations"]/tbody/tr')
assert len(rows) == len(groups)
ids = doc.xpath("//*[@id]/@id")
assert len(ids) == len(set(ids))
filter_counts, memberships = Counter(), Counter()
remaining = dict(groups)
js_rows, row_evidence, linked = [], [], set()
cache = {}


def page(path):
    path = path.resolve()
    if path not in cache:
        cache[path] = html.fromstring(path.read_bytes())
    return cache[path]


def qere(node):
    node = deepcopy(node)
    for ketiv in node.xpath('.//span[@class="mam-kq-k"]'):
        ketiv.drop_tree()
    return text(node).replace("[", "").replace("]", "")


for row in rows:
    forms, hrefs = row.xpath('.//span[@class="hebrew"]/text()'), row.xpath(
        "./th/a/@href"
    )
    candidates = [
        (k, sources)
        for k, sources in remaining.items()
        if list(k[5:7]) == forms and k[7] in hrefs
    ]
    assert len(candidates) == 1
    key, sources = candidates[0]
    remaining.pop(key)
    suffix = {
        frozenset(["koren"]): "Kor",
        frozenset(["simanim-tanakh"]): "Sim",
        frozenset(["koren", "simanim-tanakh"]): "KorSim",
    }[frozenset(sources)]
    expected_filter = key[8] + "-" + suffix
    assert row.get("data-filter") == expected_filter
    filter_counts[expected_filter] += 1
    memberships[len(sources)] += 1
    assert row.xpath('./th/span[@class="source"]/@title') == [
        r["scan"] for r in sources.values()
    ]
    assert [text(n) for n in row.xpath('.//span[@class="edition"]')] == [
        "MAM",
        " / ".join("Koren" if e == "koren" else "SimTan" for e in sources),
    ]
    check_crops(row, sources)
    linked.update(p for e, p in crop_oracle(sources))
    record = next(iter(sources.values()))
    loc = urlsplit(record["verse_href"])
    anchors = page(target.parent / unquote(loc.path)).xpath(
        "//*[@id=$ident]", ident=loc.fragment
    )
    assert len(anchors) == 1 and " ".join(record["mam"].split()) in qere(
        anchors[0].getparent()
    )
    assert [text(n) for n in row.xpath('./td[@class="difference"]/p')] == list(
        dict.fromkeys(
            n["text"] + (" " + n.get("label", "MAM doc-note") if n.get("href") else "")
            for r in sources.values()
            for n in r.get("notes", [])
        )
    )
    row_evidence.append(
        {
            "identity": key,
            "editions": list(sources),
            "filter": expected_filter,
            "crops": crop_oracle(sources),
        }
    )
    js_rows.append(
        {
            "filter": expected_filter,
            "category": key[8],
            "editions": list(sources),
            "cells": [text(c) for c in row],
        }
    )
assert not remaining
options = doc.xpath('//*[@id="filter"]/option')
assert [o.get("value") for o in options][0] == "" and text(
    options[0]
) == f"All differences ({len(rows)})"
assert set(o.get("value") for o in options[1:]) == set(filter_counts)
for option in options[1:]:
    assert text(option).endswith(f"({filter_counts[option.get('value')]})")
old_raw = git("show", BASE + ":gh-pages/stress-helpers/index.html").decode()
new_raw = target.read_text(encoding="utf-8")
old_lines, new_lines = old_raw.splitlines(), new_raw.splitlines()
assert len(old_lines) == len(new_lines)
line_changes = [(a, b) for a, b in zip(old_lines, new_lines) if a != b]
assert len(line_changes) == 2
assert all(
    a.startswith('<tr data-filter="redundant-edition-Sim"')
    and b.startswith('<tr data-filter="redundant-edition-Sim"')
    for a, b in line_changes
)
for a, b in line_changes:
    before, after = html.fromstring(a), html.fromstring(b)
    assert html.tostring(before[0]) == html.tostring(after[0]) and html.tostring(
        before[1]
    ) == html.tostring(after[1])
    assert html.tostring(before[2]).replace(
        b"cases where the Simanim Tanakh has one", b"cases like this"
    ) == html.tostring(after[2])
links, external = 0, set()
for node in doc.xpath("//*[@href or @src]"):
    for attr in ("href", "src"):
        value = node.get(attr)
        if value is None:
            continue
        loc = urlsplit(value)
        if loc.scheme or loc.netloc:
            external.add(value)
            continue
        dest = (target.parent / unquote(loc.path)).resolve() if loc.path else target
        assert dest.is_relative_to(TREE / "gh-pages") and dest.is_file(), value
        if loc.fragment:
            assert page(dest).xpath(
                "//*[@id=$ident or @name=$ident]", ident=unquote(loc.fragment)
            ), value
        links += 1
pngs = {}
for p in sorted((target.parent / "img").glob("*.png")):
    with Image.open(p) as img:
        assert img.format == "PNG"
        pngs["img/" + p.name] = {
            "width": img.width,
            "height": img.height,
            "bytes": p.stat().st_size,
            "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
        }
        img.verify()
orphans = sorted(pngs.keys() - linked)
assert orphans == [
    "img/koren-deuter-5-13-A5-D-281-370-1.png",
    "img/koren-deuter-5-13-A5-D-281-370-2.png",
    "img/simanim-tanakh-deuter-5-6-A9-A5-10C-0351-1685-1.png",
    "img/simanim-tanakh-exodus-20-2-A9-A2-10C-0350-1684-1.png",
]

# Every invalid field is exercised through render: no output may be written.
seed = deepcopy(inputs["simanim-tanakh"]["differences"][0])
seed.pop("comparison_crops", None)
valid_crop = inputs["koren"]["differences"][0]["crops"][0]
invalid = {
    "unknown-edition": {"unknown": [valid_crop]},
    "empty": {"koren": []},
    "traversal": {"koren": ["img/../outside.png"]},
    "absolute": {"koren": [str(target.parent / valid_crop)]},
    "missing": {"koren": ["img/nonexistent-review-probe.png"]},
    "wrong-directory": {"koren": ["elsewhere/crop.png"]},
}
rejected = []
with TemporaryDirectory(prefix="crop-probe-", dir=ROOT) as temporary:
    scratch = Path(temporary)
    (scratch / "in").mkdir()
    (scratch / "out").mkdir()
    for case, mapping in invalid.items():
        local = deepcopy(seed)
        local["comparison_crops"] = mapping
        # Real assets stay in their committed directory; only an input set is temporary.
        local_inputs = {
            "koren": {"differences": []},
            "simanim-tanakh": {"differences": [local]},
        }
        for name, data in {
            **local_inputs,
            "common": {"coverage": [], "source_notes": []},
        }.items():
            (scratch / "in" / (name + ".json")).write_text(
                json.dumps(data), encoding="utf-8", newline="\n"
            )
        try:
            renderer.render(
                scratch / "in",
                target.parent,
                generated_comment="scratch rejection probe",
            )
        except (ValueError, FileNotFoundError) as error:
            rejected.append(
                {
                    "case": case,
                    "exception": type(error).__name__,
                    "message": str(error).replace(str(TREE), "SOURCE"),
                }
            )
        else:
            raise AssertionError("Invalid input accepted: " + case)
        assert target.read_text(encoding="utf-8") == new_raw

# Valid grouping oracle also covers extra images for an existing edition and omitted field.
synthetic = []
for mapping in (
    {},
    {"koren": [valid_crop, valid_crop]},
    {"simanim-tanakh": list(seed["crops"])},
    {"simanim-tanakh": list(seed["crops"]), "koren": [valid_crop]},
):
    record = deepcopy(seed)
    if mapping:
        record["comparison_crops"] = mapping
    renderer._check({"differences": [record]}, target.parent)
    sources = {"simanim-tanakh": record}
    row = html.fromstring(renderer._row(sources, record["category"] + "-Sim"))
    check_crops(row, sources)
    assert row.xpath('.//span[@class="edition"]/text()') == ["MAM", "SimTan"]
    synthetic.append(
        {"comparison_crops": mapping, "observed_crops": row.xpath(".//img/@src")}
    )
workflow = {}
for ref in (PARENT, SOURCE):
    files = [
        p
        for p in git("ls-tree", "-r", "--name-only", "-z", ref, "--", ".github")
        .decode()
        .split("\0")
        if p
    ]
    assert files == [".github/workflows/pages.yml"]
    blob = git("rev-parse", ref + ":.github/workflows/pages.yml").decode().strip()
    assert blob == "18ceb19405424710bda47d9a38c470cc2ed9c385"
    assert b"on:\n  workflow_dispatch:\n" in git(
        "show", ref + ":.github/workflows/pages.yml"
    )
    workflow[ref] = blob
save("rows.json", row_evidence)
save("assets.json", pngs)
save("negative-probes.json", rejected)
save("valid-grouping-probes.json", synthetic)
save(
    "js-input.json",
    {
        "rows": js_rows,
        "options": [o.get("value") for o in options],
        "queries": [
            "Koren",
            "SimTan",
            "Jer 22:23",
            "Ruth 2:9",
            "margin qere",
            *[r["cells"][0] for r in js_rows],
        ],
    },
)
save(
    "probe-result.json",
    {
        "observed_utc": datetime.now(timezone.utc).isoformat(),
        "source": SOURCE,
        "base": BASE,
        "changed_paths": len(changed),
        "edition_records": {e: len(d["differences"]) for e, d in inputs.items()},
        "rows": len(rows),
        "shared": memberships[2],
        "single": memberships[1],
        "filter_counts": filter_counts,
        "populated_choices": len(options) - 1,
        "changed_rows_only": len(line_changes),
        "all_other_page_lines_identical": True,
        "local_attributes": links,
        "external_links_not_fetched": sorted(external),
        "pngs": len(pngs),
        "linked_images": len(linked),
        "retained_orphans": orphans,
        "negative_rejections_before_output": len(rejected),
        "valid_grouping_cases": len(synthetic),
        "workflow": workflow,
        "limitation": "Mechanical source/DOM/image integrity only; no browser or source-image editorial reading.",
    },
)
assert not git("status", "--porcelain=v1", "-z")
print((OUT / "probe-result.json").read_text(encoding="utf-8"))

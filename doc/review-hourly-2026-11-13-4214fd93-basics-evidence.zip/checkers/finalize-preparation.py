"""Clarify draft wording, retain the initial draft, and rebuild archive identities."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "evidence"
RECEIPTS = ROOT / "receipts"
record = json.loads((ROOT / "publication-prepared.json").read_bytes())
archive = RECEIPTS / "doc" / record["archive"]["path"]
report = archive.with_name(archive.name.replace("-evidence.zip", ".md"))
preserved = ROOT / "first-preparation"
assert not preserved.exists()
preserved.mkdir()
for path in (
    ROOT / "setup.py",
    ROOT / "prepare.py",
    ROOT / "publication-prepared.json",
    OUT / "setup.json",
    OUT / "disposition.json",
    report,
    RECEIPTS / "doc/review-trial-status.md",
    archive,
):
    shutil.copy2(path, preserved / path.name)
old_note = "No checks or writes to source failed."
new_note = "The initial lookups changed no source files; maintained check outcomes are recorded separately."
for path in (ROOT / "setup.py", OUT / "setup.json"):
    raw = path.read_text(encoding="utf-8")
    assert raw.count(old_note) == 1
    path.write_text(raw.replace(old_note, new_note), encoding="utf-8", newline="\n")
old = "without changing their Sim-only menu membership or reading/source labels."
new = "without changing their Sim-only menu membership, reading labels or page/scan citations."
for path in (ROOT / "prepare.py", report):
    raw = path.read_text(encoding="utf-8")
    assert raw.count(old) == 1
    path.write_text(raw.replace(old, new), encoding="utf-8", newline="\n")
old = "reading labels and original source labels."
new = "reading labels and original page/scan citations."
for path in (ROOT / "prepare.py", OUT / "disposition.json"):
    raw = path.read_text(encoding="utf-8")
    assert raw.count(old) == 1
    path.write_text(raw.replace(old, new), encoding="utf-8", newline="\n")
black = [
    "/workspace/MAM-basics/.venv/bin/python",
    "-B",
    "-m",
    "black",
    str(ROOT / "setup.py"),
    str(ROOT / "prepare.py"),
]
subprocess.run(black, check=True)
operations = {
    "observed_utc": datetime.now(timezone.utc).isoformat(),
    "draft_corrections": [
        "Narrowed the initial-lookup note so retained HTML exit 1 remains unambiguous.",
        "Clarified reading labels and page/scan citations versus the intentionally added crop labels.",
    ],
    "preserved_initial_draft": str(preserved),
    "product_checks_repeated": False,
    "format_command": black,
    "finalization_command": [
        "/workspace/MAM-basics/.venv/bin/python",
        "-B",
        str(ROOT / "finalize-preparation.py"),
    ],
}
(OUT / "preparation-clarifications.json").write_text(
    json.dumps(operations, indent=2) + "\n", encoding="utf-8", newline="\n"
)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


payload = {p.name: p.read_bytes() for p in OUT.iterdir() if p.is_file()}
for name in (
    "setup.py",
    "run.py",
    "probe.py",
    "js-probe.cjs",
    "prepare.py",
    "adapt-publisher.py",
    "publish.py",
    "finalize-preparation.py",
):
    payload["checkers/" + name] = (ROOT / name).read_bytes()
for source, name in (
    (Path("/workspace/scratch/admit_window_20261112.py"), "admit.py"),
    (Path("/workspace/scratch/window_controls_20261112.py"), "window-controls.py"),
):
    payload["checkers/" + name] = source.read_bytes()
payload["manifest.json"] = (
    json.dumps(
        {
            name: {"bytes": len(raw), "sha256": sha(raw)}
            for name, raw in sorted(payload.items())
        },
        indent=2,
    )
    + "\n"
).encode("utf-8")
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as z:
    for name, raw in sorted(payload.items()):
        z.writestr(name, raw)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist()))
    manifest = json.loads(z.read("manifest.json"))
    assert set(z.namelist()) == set(manifest) | {"manifest.json"}
    for name, entry in manifest.items():
        assert (
            len(z.read(name)) == entry["bytes"] and sha(z.read(name)) == entry["sha256"]
        )
record.update(
    archive={
        "path": archive.name,
        "bytes": archive.stat().st_size,
        "sha256": sha(archive.read_bytes()),
        "payload_files": len(payload) - 1,
    },
    prepared_utc=datetime.now(timezone.utc).isoformat(),
)
(ROOT / "publication-prepared.json").write_text(
    json.dumps(record, indent=2) + "\n", encoding="utf-8", newline="\n"
)
print(json.dumps(record, indent=2))

from pathlib import Path
import runpy

import pytest
from mb_cmn import hebrew_accents as ha
from mb_cmn import hebrew_points as hp
from mb_cmn import str_defs as sd
from mb_cmn import uni_norm_fragile as u
from py_wlc_json_and_unicode import wlc_foi_utils_uni as collector


def test_same_zone_and_cross_zone_contract():
    assert not u.is_fragile('א'+ha.MUN+hp.XOLAM)
    assert u.is_fragile('א'+ha.MER+hp.PATAX)
    hb_only='ל'+hp.XIRIQ+hp.TSERE
    nfc_only='ל'+hp.TSERE+hp.XIRIQ
    assert not u.is_nfc_fragile(hb_only) and u.is_hb_fragile(hb_only)
    assert u.is_nfc_fragile(nfc_only) and not u.is_hb_fragile(nfc_only)
    assert u.is_fragile(hb_only) and u.is_fragile(nfc_only)


def test_CGJ_and_dropped_marks():
    protected='ל'+hp.XIRIQ+sd.CGJ+hp.TSERE
    assert not u.is_fragile(protected)
    assert u.hb_mark_order(protected)==protected
    assert u.get_fragile_comps('א'+hp.DAGOMOSD+hp.DAGESH_XAZAQ+hp.RAFE+hp.SHIND+hp.SIND)==('א','א','א')


def test_composition_and_closed_zone_guard():
    assert u.is_fragile('a\N{COMBINING DIAERESIS}')
    with pytest.raises(ValueError,match='No zone'):
        u.is_fragile('ל\N{COMBINING CEDILLA}'+hp.TSERE)


def test_real_HarfBuzz_at_run_cap():
    module=Path('/workspace/review-hourly-20261029-hb-basics/py/tests/test_uni_norm_fragile_harfbuzz.py')
    shaper=runpy.run_path(str(module))['_Shaper']()
    for count in (31,32,33,34):
        string='ל'+hp.XIRIQ*(count-1)+hp.TSERE
        actual=shaper.mark_order(string)
        expected=('ל'+hp.TSERE+hp.XIRIQ*(count-1)) if count<=32 else string
        assert actual==expected
        assert u.hb_mark_order(string)==actual


def test_collector_three_comparisons_and_no_false_case():
    cases={'fragile_foi':collector.ff_init()}
    collector.collect_uni(cases,'unused',(1,1),{'word':'ל'+hp.XIRIQ+hp.TSERE})
    row,=cases['fragile_foi']['ff-cases']
    assert row['dropped']==row['dropped_n'] and row['dropped']!=row['dropped_hb']
    assert sum(cases['fragile_foi']['ff-counts'].values())==1
    collector.collect_uni(cases,'unused',(1,2),'א'+ha.MUN+hp.XOLAM)
    collector.collect_uni(cases,'unused',(1,3),{})
    assert len(cases['fragile_foi']['ff-cases'])==1

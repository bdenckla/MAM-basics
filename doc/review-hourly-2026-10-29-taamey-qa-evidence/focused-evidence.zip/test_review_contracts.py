"""Focused public-code contracts; no font build, corpus adoption or baseline writer."""
from pathlib import Path
from types import SimpleNamespace
import json
import subprocess

import pytest
import main_0_mega as mega
import main_taamey_d as cli
from mb_cmn import paths
from taamey_d.qa import accept_baseline, corpus_refresh, run_checks, shaping_checks
from taamey_d.qa.check_helpers import CheckObj


def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args])


def fixture_repo(tmp_path):
    root = tmp_path / 'fixture'
    root.mkdir()
    git(root, 'init', '--quiet', '--initial-branch=fixture')
    return root


def commit(root):
    git(root, 'add', '.')
    git(root, '-c', 'user.name=Review fixture', '-c', 'user.email=review@example.invalid', 'commit', '--quiet', '-m', 'Synthetic input fixture')


def no_writer(*args, **kwargs):
    raise AssertionError('A report-only probe invoked a corpus/baseline writer')


def test_corpus_check_reads_selected_root_and_dirty_inputs_without_writing(tmp_path, monkeypatch, capsys):
    root = fixture_repo(tmp_path)
    for relative, data in {
        'out/mam-qere-words.json': ['אב'],
        'uxlc/out/uxlc-words.json': ['אב'],
        'Taamey-D/qa-in/bible_words_10.testcases.json': {'testcases': [{'input': 'אב', 'provenance': 'MU', 'expected': {'fixture': 'preserved'}}]},
        'Taamey-D/qa-in/hand.testcases.json': {'testcases': [{'input': 'יד'}]},
    }.items():
        p = root / relative
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
    commit(root)
    monkeypatch.setattr(paths, 'repo_root', lambda: root)
    monkeypatch.setattr(corpus_refresh, '_QA_IN', root / 'Taamey-D/qa-in')
    monkeypatch.setattr(corpus_refresh, 'this_repo_name', lambda: 'MAM-basics')
    monkeypatch.setattr(corpus_refresh.file_io, 'with_tmp_openw', no_writer)
    assert corpus_refresh.refresh_corpus(check=True) is False
    assert git(root, 'rev-parse', 'HEAD').decode().strip() in capsys.readouterr().out
    (root / 'out/mam-qere-words.json').write_text(json.dumps(['אב', 'גד'], ensure_ascii=False), encoding='utf-8')
    before = {p.relative_to(root).as_posix(): p.read_bytes() for p in root.rglob('*') if p.is_file()}
    assert corpus_refresh.refresh_corpus(check=True) is True
    assert 'REFRESH PENDING' in capsys.readouterr().out
    with pytest.raises(RuntimeError, match='uncommitted word lists'):
        corpus_refresh.refresh_corpus(check=False)
    after = {p.relative_to(root).as_posix(): p.read_bytes() for p in root.rglob('*') if p.is_file()}
    assert after == before


@pytest.mark.parametrize('status,error', [('PASS', None), ('FAIL', None), ('SKIP', SystemExit), ('UNKNOWN', RuntimeError)])
def test_qa_status_contract(status, error, monkeypatch, capsys):
    monkeypatch.setattr(run_checks, '_run_anchor_family_lint', lambda font: False)
    monkeypatch.setattr(run_checks, '_get_checkobjs', lambda font, selection: [SimpleNamespace(shortname='fixture')])
    monkeypatch.setattr(shaping_checks, 'run_a_check_across_all_tcases', lambda *args: [(status, 'fixture result')])
    if error:
        with pytest.raises(error):
            run_checks.run_checks()
    else:
        assert run_checks.run_checks().name == 'Taamey_D'
    assert status in capsys.readouterr().out


def test_missing_anchor_table_fails_closed(monkeypatch):
    monkeypatch.setattr(run_checks.anchor_families, 'lint', lambda font: None)
    with pytest.raises(RuntimeError, match='no exception table'):
        run_checks._run_anchor_family_lint(Path('Taamey_D.ttf'))


def test_anchor_failure_propagates_after_checks(monkeypatch):
    monkeypatch.setattr(run_checks, '_run_anchor_family_lint', lambda font: True)
    monkeypatch.setattr(run_checks, '_get_checkobjs', lambda font, selection: [])
    with pytest.raises(SystemExit, match='anchor-family lint failed'):
        run_checks.run_checks()


def test_empty_corpus_returns_a_skip_pair(tmp_path):
    result, failed = shaping_checks.run_a_check_across_all_tcases2({'checkobj': CheckObj('fixture', 'fixture', no_writer), 'qadirs': {'indir': tmp_path}})
    assert result == [('SKIP', 'No JSON test case files found.')]
    assert failed == []


def test_report_guard_checks_index_untracked_and_empty_scope(tmp_path, monkeypatch):
    root = fixture_repo(tmp_path)
    reports = root / 'reports'
    reports.mkdir()
    tracked = reports / 'report.json'
    tracked.write_text('committed fixture\n')
    commit(root)
    monkeypatch.setattr(paths, 'repo_root', lambda: root)
    mega._check_taamey_d_reports_against_index(reports)
    tracked.write_text('changed fixture\n')
    with pytest.raises(RuntimeError, match='differ from Git'):
        mega._check_taamey_d_reports_against_index(reports)
    # This stages arbitrary text to test Git index semantics; no font expectations or
    # acceptance operation are involved.
    git(root, 'add', 'reports/report.json')
    mega._check_taamey_d_reports_against_index(reports)
    (reports / 'untracked.json').write_text('new fixture\n')
    with pytest.raises(RuntimeError, match='untracked.json'):
        mega._check_taamey_d_reports_against_index(reports)
    with pytest.raises(RuntimeError, match='Git tracks no'):
        mega._check_taamey_d_reports_against_index(root / 'empty')


def test_mega_corpus_is_report_only_and_banner_is_nonfatal(monkeypatch, capsys):
    calls = []
    def dispatcher(argv):
        calls.append(argv)
        return True
    monkeypatch.setattr(cli, 'almost_main', dispatcher)
    monkeypatch.setattr(mega, '_PENDING_REFRESHES', [])
    monkeypatch.setattr(accept_baseline, 'accept_baseline', no_writer)
    assert mega._run_taamey_d_corpus() is None
    assert calls == [['corpus', '--check']]
    assert mega._report_pending_refreshes() is None
    assert 'REFRESH PENDING' in capsys.readouterr().out
    assert [s.step_id for s in mega._STEPS[-3:]] == ['taamey-d-doc', 'taamey-d-qa', 'taamey-d-corpus']


@pytest.mark.parametrize('value', ['אב', ['אב', '..', '', '']])
def test_baseline_pure_merge_preserves_other_expectations_without_writer(value):
    # Only the pure dictionary transformation is exercised; accept_baseline(), its
    # CLI operation and all file-writing functions are never called.
    case = {'input': value, 'expected': {'other-font': 'keep'}, 'provenance': 'keep'}
    original = json.loads(json.dumps(case))
    key = accept_baseline._hashable_input(case)
    result = accept_baseline._mk_tcase('Taamey_D.ttf', {key: 'synthetic observed value'}, case)
    assert result == {'input': value, 'expected': {'other-font': 'keep', 'Taamey_D.ttf': 'synthetic observed value'}, 'provenance': 'keep'}
    assert case == original


def test_cli_rejects_unknown_check_before_execution():
    parser = cli.build_parser()
    with pytest.raises(SystemExit) as error:
        parser.parse_args(['qa', '--one-check', 'unknown'])
    assert error.value.code == 2

from pathlib import Path
from datetime import datetime, timezone
import importlib.metadata
import json
import subprocess
import sys
import time

root=Path('/workspace/review-hourly-20261029-taamey-qa')
out=Path(__file__).parent
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()=='bcfe749c68c144218f33821c9f95775a25ed032d'
result={'source_commit':'bcfe749c68c144218f33821c9f95775a25ed032d','started_utc':datetime.now(timezone.utc).isoformat(),'commands':[]}
for label,argv in [('dependencies',[sys.executable,'-m','pip','install','-r','requirements.txt','-c','constraints.txt']),('pip-check',[sys.executable,'-m','pip','check'])]:
    start=time.monotonic()
    with (out/(label+'.log')).open('w',encoding='utf-8') as log:
        p=subprocess.run(argv,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=False)
    result['commands'].append({'command':argv,'exit_code':p.returncode,'seconds':round(time.monotonic()-start,3)})
    if p.returncode:
        result['state']='failed';(out/'environment.json').write_text(json.dumps(result,indent=2)+'\n');raise SystemExit(p.returncode)
result['packages']={name:importlib.metadata.version(name) for name in ['uharfbuzz','vharfbuzz','collidoscope','fonttools','attrs','babelfont','kurbopy','openstep_plist','orjson','skia-pathops','tqdm','ufoLib2','ufomerge']}
import uharfbuzz
result['HarfBuzz']=uharfbuzz.version_string()
result['completed_utc']=datetime.now(timezone.utc).isoformat();result['state']='completed'
(out/'environment.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2),flush=True)

from pathlib import Path
from datetime import datetime,timezone
import json,os,subprocess,sys,time

specpath=Path(sys.argv[1]);spec=json.loads(specpath.read_text());out=specpath.parent
root=Path(spec['repository']);name=spec['name'];result=out/(name+'.result.json')
assert not result.exists(),name
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head==spec['source_commit']
assert not subprocess.check_output(['git','status','--porcelain=v1','-z'],cwd=root)
env=os.environ.copy();env.update(spec.get('environment',{}))
start=datetime.now(timezone.utc).isoformat();clock=time.monotonic();print('START',name,start,flush=True)
with (out/(name+'.log')).open('w',encoding='utf-8') as log:
 p=subprocess.run(spec['command'],cwd=spec['cwd'],env=env,stdout=log,stderr=subprocess.STDOUT)
status=subprocess.check_output(['git','status','--porcelain=v1','-z'],cwd=root).decode()
record={**spec,'started_utc':start,'completed_utc':datetime.now(timezone.utc).isoformat(),'seconds':round(time.monotonic()-clock,3),'exit_code':p.returncode,'tracked_status_after':status}
result.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
if status:(out/(name+'.patch')).write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=root))
print(json.dumps(record,ensure_ascii=False),flush=True)
print((out/(name+'.log')).read_text(encoding='utf-8')[-1700:],flush=True)
if p.returncode or status:raise SystemExit('Stopped for failure/diff triage; no later stage launched')

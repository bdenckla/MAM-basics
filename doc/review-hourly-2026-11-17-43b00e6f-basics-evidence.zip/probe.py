import copy
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import sys
from urllib.parse import unquote, urlsplit

ROOT = Path(__file__).parent
SOURCE = ROOT / 'source'
OUT = ROOT / 'artifacts'
sys.path.insert(0, str(SOURCE / 'py'))  # Disposable inspector, never installed.
from lxml import html
from author_site import stress_helper_comparison as gen

results = json.loads((SOURCE / 'in/stress-helpers/results.json').read_text(encoding='utf-8'))
inputs = {k: json.loads((SOURCE / f'in/stress-helpers/{k}.json').read_text(encoding='utf-8')) for k in gen._EDITIONS}
old = html.fromstring((OUT / 'old-results.html').read_bytes())
old_tables = old.xpath('//table')
assert [len(t.xpath('./tbody/tr')) for t in old_tables] == [6, 7, 96, 43, 9]
old_records = {}
for table_name, table in [('differences', old_tables[2]), ('spelling', old_tables[3])]:
    for row in table.xpath('./tbody/tr'):
        cells = row.xpath('./td')
        refcell = row.xpath('./th')[0]
        ref = refcell.text.strip().replace(' ', '')
        for old_name, current_name in [('Hosea','Hos'),('Esther','Esth'),('Daniel','Dan'),('SongofSongs','Song')]:
            ref = ref.replace(old_name, current_name)
        atom = int(re.search(r'Atom (\d+)', refcell.text_content()).group(1))
        strand = ''.join(refcell.xpath('.//bdi/text()'))
        form = cells[0].text_content()
        for i, edition in enumerate(gen._EDITIONS, start=1):
            note = cells[i].text_content()
            if note != '—':
                key = (table_name, edition, ref, atom, strand, form)
                assert key not in old_records
                old_records[key] = note
new_records = {}
inventory = []
for edition, tables in results['editions'].items():
    for table_name, records in tables.items():
        for r in records:
            ref = f"{gen.BOOK_ABBREVS[r['book']]}{r['chapter']}:{r['verse']}".replace(' ', '')
            strand = str(gen._STRANDS.get(r.get('strand'), ''))
            # Constants are HTML nodes' rendered bdi text, already Hebrew strings here.
            strand = html.fromstring(f'<div>{strand}</div>').text_content()
            key = (table_name, edition, ref, r['atom'], strand, r['mam'])
            assert key in old_records, key
            assert len(r['notes']) == 1
            expected_note = old_records[key]
            if ref == '1Sam2:16':
                expected_note = expected_note.replace('Zaqef qatan', 'Zaqef')
            assert r['notes'][0]['text'] == expected_note, (key, r['notes'], expected_note)
            new_records[key] = r
            inventory.append({'table': table_name, 'edition': edition, 'reference': ref, 'atom': r['atom'], 'strand': strand, 'category': r['category'], 'mam': r['mam'], 'note': r['notes'][0]['text']})
assert len(new_records) == 123
assert Counter((k[0], k[1]) for k in new_records) == {('differences','koren'):55, ('differences','simanim-tanakh'):20, ('spelling','koren'):42, ('spelling','simanim-tanakh'):6}
shown = {k: {(r['book'],r['chapter'],r['verse'],r['mam']) for r in d['differences']} for k,d in inputs.items()}
for ed, tables in results['editions'].items():
    assert all((r['book'],r['chapter'],r['verse'],r['mam']) not in shown[ed] for records in tables.values() for r in records)
assert all(k in new_records for k in old_records if k[0] == 'spelling')
kept = {k for k in new_records if k[0] == 'differences'}
dropped = [k for k in old_records if k[0] == 'differences' and k not in kept]
assert len(dropped) == 56
assert all(k[2] in ('Exod20:2', 'Deut5:6', 'Deut5:13', '2Sam4:6', '2Sam13:20') or any(r['mam'] == k[5] and f"{gen.BOOK_ABBREVS[r['book']]}{r['chapter']}:{r['verse']}".replace(' ','') == k[2] for r in inputs[k[1]]['differences']) for k in dropped)

c = results['census']
accents = c['by_accent']
for row in accents['rows']:
    assert row['with_helper'] + row['without_helper'] == row['total']
for col in ('with_helper','without_helper','total'):
    assert sum(r[col] for r in accents['rows']) == accents['total'][col]
for ed in gen._EDITIONS:
    edition_census = c['by_edition']
    assert sum(r['counts'][ed] for r in edition_census['outcomes']) == edition_census['total'][ed]
    assert edition_census['total'][ed] == accents['total']['total'] - c['decalogue_readings']['manuscript'] + c['decalogue_readings'][c['decalogue_tradition'][ed]]
    for row in edition_census['within_agreement']:
        assert row['counts'][ed] == sum(r['category'] == row['id'] for records in results['editions'][ed].values() for r in records)

models = []
links = 0
hebrew_forms = 0
counts = {}
for name in ('index.html','results.html'):
    page_path = SOURCE / 'gh-pages/stress-helpers' / name
    page = html.fromstring(page_path.read_bytes())
    ids = page.xpath('//@id')
    assert len(ids) == len(set(ids))
    for attr in page.xpath('//@href | //@src'):
        u = urlsplit(attr)
        if u.scheme or u.netloc:
            continue
        target = page_path.parent / unquote(u.path) if u.path else page_path
        assert target.is_file(), (name, attr)
        if u.fragment:
            target_page = html.fromstring(target.read_bytes())
            assert target_page.xpath('//*[@id=$id]', id=unquote(u.fragment)), (name, attr)
        links += 1
    for span in page.xpath('//*[@lang="hbo"]'):
        assert not gen.author.is_unpointed_hebrew(span.text_content())
        hebrew_forms += 1
    for bdi in page.xpath('//bdi[not(@lang)]'):
        assert gen.author.is_unpointed_hebrew(bdi.text_content())
    rows = page.xpath('//table[@id="observations"]/tbody/tr')
    spell = page.xpath('//table[@id="spelling"]/tbody/tr')
    counts[name] = {'observations': len(rows), 'spelling': len(spell)}
    if name == 'results.html':
        assert len(rows) == 57 and len(spell) == 43
        assert not page.xpath('//img | //*[@id="toggle-images"] | //td[@class="scan"]')
        assert len(page.xpath('//details[not(@open)]//table[@id="spelling"]')) == 1
        for row in rows + spell:
            assert len(row.xpath('./td | ./th')) == 3
            assert len(row.xpath('.//span[@class="hebrew"]')) == 1
    models.append({'name':name,'rows':[{'cells':[cell.text_content() for cell in row.xpath('./td | ./th')],'filter':row.get('data-filter')} for row in rows], 'options':[{'value':o.get('value'), 'text':o.text_content()} for o in page.xpath('//select[@id="filter"]/option')], 'scans':len(page.xpath('//*[@id="observations"]//*[@class="scan"]')), 'toggle':bool(page.xpath('//*[@id="toggle-images"]')), 'spelling_rows':len(spell)})
comparison_fields = ('book','chapter','verse','atom','strand','instance','location','mam','printed','verse_href','category')
comparison_identities = {tuple(r.get(k) for k in comparison_fields) for data in inputs.values() for r in data['differences']}
assert counts['index.html']['observations'] == len(comparison_identities)
newpage = html.fromstring((SOURCE/'gh-pages/stress-helpers/results.html').read_bytes())
rendered_forms = newpage.xpath('//span[@class="hebrew"]/text()')
assert set(rendered_forms) == {r['mam'] for tables in results['editions'].values() for records in tables.values() for r in records}
assert len(rendered_forms) == 100
for row, expected in zip(newpage.xpath('//table[@class="census"][1]/tbody/tr'), accents['rows']+[accents['total']]):
    assert [int(t.text_content().replace(',','')) for t in row.xpath('./td')] == [expected[k] for k in ('with_helper','without_helper','total')]
for row, expected in zip(newpage.xpath('//table[@class="census"][2]/tbody/tr'), c['by_edition']['outcomes']+[{'counts':c['by_edition']['total']}]+c['by_edition']['within_agreement']):
    assert [int(t.text_content().replace(',','')) for t in row.xpath('./td')] == list(expected['counts'].values())

refusals = []
def bad(label, change):
    altered = copy.deepcopy(results)
    change(altered)
    try:
        gen._check_results(altered, inputs)
    except (ValueError, KeyError, TypeError) as e:
        refusals.append({'case':label,'exception':type(e).__name__,'message':str(e)[:240]})
    else:
        raise AssertionError(f'Not refused: {label}')
def first(r):
    return r['editions']['koren']['differences'][0]
bad('unknown-category', lambda r:first(r).__setitem__('category','unknown'))
bad('unknown-strand', lambda r:first(r).__setitem__('strand','unknown'))
for value in (0,-1,'1'):
    bad(f'invalid-atom-{value!r}', lambda r,v=value:first(r).__setitem__('atom',v))
bad('empty-mam', lambda r:first(r).__setitem__('mam',''))
bad('duplicate-record', lambda r:r['editions']['koren']['differences'].append(copy.deepcopy(first(r))))
bad('missing-notes', lambda r:first(r).pop('notes'))
bad('crop-before-move', lambda r:first(r).__setitem__('crops',['img/test.png']))
bad('partial-print-data', lambda r:first(r).__setitem__('printed',first(r)['mam']))
bad('index-duplicate', lambda r:r['editions']['koren']['differences'].append({**copy.deepcopy(inputs['koren']['differences'][0]),'atom':1}))
bad('accent-row-total', lambda r:r['census']['by_accent']['rows'][0].__setitem__('total',1))
bad('edition-total', lambda r:r['census']['by_edition']['total'].__setitem__('koren',1))
bad('unknown-outcome', lambda r:r['census']['by_edition']['outcomes'][0].__setitem__('id','unknown'))
bad('unknown-tradition', lambda r:r['census']['decalogue_tradition'].__setitem__('koren','unknown'))
bad('spelling-row-count', lambda r:r['census']['by_edition']['within_agreement'][1]['counts'].__setitem__('koren',41))
bad('unknown-edition', lambda r:r['editions'].__setitem__('unknown',r['editions']['koren']))
escaped = gen._linked_note({'text':'<script>&" pashta ' + first(results)['mam'], 'href':'x" onmouseover="oops', 'label':'<img>&"'})
parsed = html.fromstring(escaped)
assert not parsed.xpath('.//script | .//img | .//*[@onmouseover]')
assert parsed.xpath('.//a')[0].get('href') == 'x" onmouseover="oops'
assert first(results)['mam'] in parsed.text_content()
summary = {'records_preserved_exactly':len(new_records),'differences':75,'spelling':48,'unique_rendered_forms':len(set(rendered_forms)), 'rendered_form_occurrences':100, 'page_counts':counts,'old_primary_dropped_per_recorded_scope':len(dropped),'local_href_src_occurrences':links,'pointed_font_elements_checked':hebrew_forms,'census_total':accents['total'],'edition_totals':c['by_edition']['total'],'malformed_refusals':len(refusals),'escaping_probe':'passed','unicode_normalization_used':False}
(OUT/'record-inventory.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(OUT/'control-models.json').write_text(json.dumps(models,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(OUT/'refusals.json').write_text(json.dumps(refusals,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(OUT/'independent-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))

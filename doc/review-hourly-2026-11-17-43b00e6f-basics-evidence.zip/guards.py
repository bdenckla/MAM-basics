import copy
from collections import Counter
import json
from pathlib import Path
import re
import sys
from lxml import html

base = Path(__file__).parent
source = base / 'source'
sys.path.insert(0, str(source/'py'))
from author_site import stress_helper_comparison as gen
data = json.loads((source/'in/stress-helpers/results.json').read_text(encoding='utf-8'))
inputs = {ed:json.loads((source/f'in/stress-helpers/{ed}.json').read_text(encoding='utf-8')) for ed in gen._EDITIONS}
duplicate = copy.deepcopy(inputs['koren']['differences'][0])
duplicate.pop('crops', None)
duplicate.pop('comparison_crops', None)
duplicate['atom'] = 1
duplicate.setdefault('notes',[{'text':'Disposable overlap guard.'}])
altered = copy.deepcopy(data)
altered['editions']['koren']['differences'].append(duplicate)
try:
    gen._check_results(altered, inputs)
except ValueError as e:
    assert str(e).startswith('Result repeats index.html:'), str(e)
    print('Actual index-overlap guard reached:', str(e))
else:
    raise AssertionError('Duplicate index record accepted')

def ref_of(r):
    return f"{gen.BOOK_ABBREVS[r['book']]}{r['chapter']}:{r['verse']}".replace(' ','')
old = html.fromstring((base/'artifacts/old-results.html').read_bytes())
new = {(ed,ref_of(r),r['atom'],r['mam']) for ed,tables in data['editions'].items() for r in tables['differences']}
shown = {(ed,ref_of(r),r['mam']) for ed,d in inputs.items() for r in d['differences']}
dropped = Counter()
for row in old.xpath('//table')[2].xpath('./tbody/tr'):
    refcell = row.xpath('./th')[0]
    ref = refcell.text.strip().replace(' ','')
    for a,b in [('Hosea','Hos'),('Esther','Esth'),('Daniel','Dan'),('SongofSongs','Song')]:
        ref=ref.replace(a,b)
    atom=int(re.search(r'Atom (\d+)',refcell.text_content()).group(1))
    cells=row.xpath('./td')
    mam=cells[0].text_content()
    for i,ed in enumerate(gen._EDITIONS,start=1):
        if cells[i].text_content()=='—' or (ed,ref,atom,mam) in new:
            continue
        if (ed,ref,mam) in shown:
            dropped['existing-index-record']+=1
        elif ref in ('2Sam4:6','2Sam13:20'):
            dropped['existing-source-note']+=1
        else:
            assert ed=='koren' and (ref,atom) in {('Exod20:2',1),('Deut5:6',1),('Deut5:13',14)}
            dropped['recorded-tradition-choice']+=1
assert dropped=={'existing-index-record':49,'existing-source-note':4,'recorded-tradition-choice':3},dropped
print(json.dumps({'dropped_primary_edition_findings':dict(dropped),'total':sum(dropped.values()),'scope':'Independent bookkeeping against retained predecessor page; not new editorial or census-source verification'},indent=2))

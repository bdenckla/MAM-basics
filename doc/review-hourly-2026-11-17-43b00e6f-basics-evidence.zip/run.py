import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).parent
SOURCE = ROOT / 'source'
OUT = ROOT / 'artifacts'
PY = '/workspace/MAM-basics/.venv/bin/python'
stages = []

def stage(name, argv):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    tick = time.monotonic()
    p = subprocess.run(argv, cwd=SOURCE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    elapsed = time.monotonic() - tick
    (OUT / f'{name}.txt').write_bytes(p.stdout)
    status = subprocess.run(['git', 'status', '--porcelain=v1', '-z'], cwd=SOURCE, capture_output=True, check=True).stdout
    (OUT / f'{name}-status.z').write_bytes(status)
    diff = subprocess.run(['git', 'diff', '--binary'], cwd=SOURCE, capture_output=True, check=True).stdout
    (OUT / f'{name}-output.diff').write_bytes(diff)
    rec = {'name': name, 'argv': argv, 'cwd': str(SOURCE), 'started_utc': started, 'elapsed_seconds': round(elapsed, 6), 'exit': p.returncode, 'status_bytes': len(status), 'diff_bytes': len(diff)}
    stages.append(rec)
    (OUT / 'stages.json').write_text(json.dumps(stages, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(rec), flush=True)
    if status or diff:
        raise RuntimeError(f'Unexplained output changes preserved after {name}')
    return p.returncode

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip() == '43b00e6f46e1a7ba97232a1c34aad844252f96d8'
assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '-z'], cwd=SOURCE)
inventory = subprocess.check_output(['git', 'diff', '--name-only', '-z', '180dd6de', '43b00e6f'], cwd=SOURCE)
(OUT / 'endpoint-paths.z').write_bytes(inventory)
assert len([p for p in inventory.split(b'\0') if p]) == 14
for ref, name in [('180dd6de', 'old-results.html')]:
    (OUT / name).write_bytes(subprocess.check_output(['git', 'show', f'{ref}:gh-pages/stress-helpers/results.html'], cwd=SOURCE))
metadata = {'source': '43b00e6f46e1a7ba97232a1c34aad844252f96d8', 'base': '180dd6deec823abb826b3b7f9f67c2b1a624c702', 'receipt_parent': 'd3a871d930a1410100b582b79209c8dd9914ca9c', 'python': subprocess.check_output([PY, '--version'], text=True).strip(), 'node': subprocess.check_output(['node', '--version'], text=True).strip(), 'runtime_sibling_inputs': [], 'admission': {'utc': '2026-11-17T20:15:19.992513+00:00', 'previous_slot_records': 39, 'active_other_slots': 0, 'active_check_processes': 0, 'home_head': 'cb878aef91e692d5561435f00021f73b75868e45', 'home_status': 'clean', 'cross_machine': 'not independently verified'}, 'guidance_blobs': {}}
for path in ['AGENTS.md', 'dot-Codex/user-wide-AGENTS.md', 'doc/review-trial.md', 'doc/periodic-review.md', 'py/product_scopes.py']:
    metadata['guidance_blobs'][path] = subprocess.check_output(['git', 'rev-parse', f'HEAD:{path}'], cwd=SOURCE, text=True).strip()
(OUT / 'inputs.json').write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8')
assert stage('diff-check', ['git', 'diff', '--check', '180dd6de', '43b00e6f']) == 0
assert stage('black', [PY, '-m', 'black', '--check', 'py/author_site/stress_helper_comparison.py', 'py/main_authored.py']) == 0
assert stage('gen-site', [PY, 'py/main_authored.py', 'gen-site', '--trust-surveys']) == 0
assert stage('focused-tests', [PY, 'py/main_test.py', 'py/tests/test_site_index_links.py', 'py/tests/test_site_links_relative.py', 'py/tests/test_shared_html_styles.py', 'py/tests/test_prose_mark_order.py', '-q', '-ra']) == 0
assert stage('scoped-html', [PY, 'py/check_html_syntax_and_sanity.py', 'gh-pages/stress-helpers']) in (0, 1)

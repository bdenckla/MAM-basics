"""Differential checks of the exact changed public products, without broad execution."""
from pathlib import Path
import posixpath

from mb_cmn import paths, read_books_from_mam_parsed_plus as plus
from near_aleppo import edition, build_paths, link_presentation
from mwd import mwd_write_book as mwdwb
from py_misc import mwd_utils as mwdu
import main_mam_with_doc


def test_selected_mam_with_doc_reproduces():
    root = paths.repo_root()
    expected = {p: p.read_bytes() for p in (root / 'gh-pages/MAM-with-doc').rglob('*') if p.is_file()}
    main_mam_with_doc.almost_main(('Exodus', 'Deuter'))
    assert {p: p.read_bytes() for p in (root / 'gh-pages/MAM-with-doc').rglob('*') if p.is_file()} == expected


def test_selected_near_aleppo_books_reproduce():
    books = plus.read_parsed_plus_bk39s(('Exodus', 'Deuter'), str(build_paths.dataset_dir().parent))
    mode = edition.NEAR_ALEPPO_MODE
    names_written = []
    for book in ('Exodus', 'Deuter'):
        names = mwdu.filename_for_bkid(book), mwdu.filename_for_bkid_for_bido(book)
        _, pages = mwdwb.render_book(
            (mode.edition, (edition.EDITION_CSS_HREF, 'ketiv-qere.css'), book),
            books, names, mode.renopts, mode.ht_tac_for_ren_tag,
            text_to_html=mode.text_to_html,
        )
        for name, text in pages.items():
            rel = 'edition/' + name
            css = posixpath.relpath(link_presentation.STYLESHEET, posixpath.dirname(rel) or '.')
            rendered = link_presentation.apply(text, rel, css_href=css)
            assert rendered.encode() == (build_paths.html_pages_dir() / rel).read_bytes(), rel
            names_written.append(rel)
    assert len(names_written) == 4

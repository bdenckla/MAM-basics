import datetime
import hashlib
import json
import re
import subprocess
import unicodedata
from pathlib import Path

ROOT = Path('/workspace/MAM-basics')
OUT = Path('/workspace/scratch/review-hourly-20261029-prose-mark-order')
SOURCE = '8339eb1352a745c5c2e16945a42b73b50aa30864'
ORIGINAL = '926a6e785be4236673ac4a5c8c34afe63ed417f4'
BRANCH = 'review-hourly-20261029-prose-mark-order-source'
HISTORY = 'py/ws/ws_bot_edit_history.md'
PAYLOAD = 'in/mam-ws-bot-edits/note-deuteronomy-3-22-reversed-hataf-hiriq.json'


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def leaves(value, path=()):
    if isinstance(value, str):
        yield list(path), value
    elif isinstance(value, dict):
        for key, child in value.items():
            yield from leaves(child, (*path, key))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            yield from leaves(child, (*path, index))


def cp(value):
    return [f'U+{ord(c):04X} {unicodedata.name(c, "UNNAMED")}' for c in value]


def mam_order(value):
    priority = {0x05C1: 1, 0x05C2: 2, 0x05BC: 3, 0x05C9: 3, 0x05BF: 4}
    groups = re.findall(r'[^\u0591-\u05BD\u05BF\u05C1\u05C2\u05C4\u05C5\u05C7\u05C9\u034F][\u0591-\u05BD\u05BF\u05C1\u05C2\u05C4\u05C5\u05C7\u05C9\u034F]*', value)
    assert ''.join(groups) == value
    return ''.join(g[0] + ''.join(sorted(g[1:], key=lambda c: priority.get(ord(c), 10))) for g in groups)


before = {
    'utc': now(),
    'head': git('rev-parse', 'HEAD').strip(),
    'branch': git('branch', '--show-current').strip(),
    'status': git('status', '--porcelain'),
}
assert before['head'] == ORIGINAL and before['branch'] == 'work' and not before['status'], before
(OUT / 'checkout-before.json').write_text(json.dumps(before, indent=2) + '\n')
git('switch', '-c', BRANCH, SOURCE)

command = [str(ROOT / '.venv/bin/python'), 'py/main_test.py', 'py/tests/test_prose_mark_order.py', '-q']
start = now()
run = subprocess.run(command, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
end = now()
(OUT / 'prose-lint.log').write_text(run.stdout, encoding='utf-8')
result = {'source_commit': SOURCE, 'command': command, 'cwd': str(ROOT), 'started_utc': start, 'completed_utc': end, 'returncode': run.returncode, 'status_after': git('status', '--porcelain')}
(OUT / 'prose-lint.result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
print(run.stdout)

history_bytes = (ROOT / HISTORY).read_bytes()
line = history_bytes.decode('utf-8').splitlines()[489]
quote = next(q for q in re.findall(r'`([^`]+)`', line) if '+' in q)
payload = json.loads((ROOT / PAYLOAD).read_text(encoding='utf-8'))
payload_matches = [{'json_path': path, 'occurrences': value.count(quote), 'value': value} for path, value in leaves(payload) if quote in value]
assert len(payload_matches) == 1 and payload_matches[0]['occurrences'] == 1, payload_matches
assert git('show', '4d72e9336ef2b57e59d17692b6646bbe19989c7b^:' + HISTORY).find(quote) == -1
assert (ROOT / HISTORY).read_bytes() == history_bytes
normalized = mam_order(quote)
assert normalized != quote
assert [c for c in quote if ord(c) != 0x05BC] == [c for c in normalized if ord(c) != 0x05BC]
raw_matches = []
for file in (ROOT / 'in/mam-ws').rglob('*.json'):
    if quote in file.read_text(encoding='utf-8'):
        raw_matches.append(file.relative_to(ROOT).as_posix())
assert raw_matches, 'The exact historical quote is absent from tracked raw chapter JSON'
audit = {
    'source_commit': SOURCE,
    'history_path': HISTORY,
    'line': 490,
    'line_bytes_sha256': hashlib.sha256(line.encode('utf-8')).hexdigest(),
    'history_blob': git('rev-parse', SOURCE + ':' + HISTORY).strip(),
    'introduced_by': '4d72e9336ef2b57e59d17692b6646bbe19989c7b',
    'blame': git('blame', '-L', '490,490', SOURCE, '--', HISTORY),
    'quote': quote,
    'quote_codepoints': cp(quote),
    'payload_path': PAYLOAD,
    'payload_matches': payload_matches,
    'raw_chapter_paths_with_exact_quote': raw_matches,
    'mam_order_comparison_only': normalized,
    'mam_order_comparison_codepoints': cp(normalized),
    'same_letters_marks_and_relative_non_dagesh_order': True,
    'source_status_after': git('status', '--porcelain'),
    'completed_utc': now(),
}
(OUT / 'quotation-audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(audit, ensure_ascii=True, indent=2))

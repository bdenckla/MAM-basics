"""Preserve all differences; restore only independently explained SVG geometry."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

TASK = Path('/workspace/scratch/nightly-20261112')
stage = sys.argv[1]
kind = 'basics'
out = TASK / kind
record = json.loads((out / (stage + '.json')).read_bytes())
repo = Path(record['cwd'])
assert record['state'] == 'completed'
target = out / (stage + '-triage.json')
assert not target.exists()
number = r'[-+]?(?:\d*\.\d+|\d+\.?\d*)(?:[eE][-+]?\d+)?'


def git(*args):
    return subprocess.check_output(['git', '-C', str(repo), *args])


def sha(value):
    return hashlib.sha256(value).hexdigest()


def numeric_shape(value):
    return re.sub(number, '#', value)


def cubic_segments(value):
    if not re.fullmatch(r'M' + number + ',' + number + r'C(?:' + number + r'[, ]?)+', value):
        return None
    values = re.findall(number, value.split('C', 1)[1])
    return len(values) // 6 if values and len(values) % 6 == 0 else None


def canonical(raw):
    root = ET.fromstring(raw, parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True)))
    nodes = []
    for node in root.iter():
        attributes = {}
        for key, value in node.attrib.items():
            if key == 'd' and cubic_segments(value) is not None:
                value = 'M#,#C(cubic-edge-routing)'
            elif key in {'width', 'height', 'viewBox', 'd', 'points', 'x', 'y', 'x1', 'x2', 'y1', 'y2', 'cx', 'cy', 'rx', 'ry'}:
                value = numeric_shape(value)
            elif key == 'transform':
                value = re.sub(r'translate\(([^)]+)\)', lambda m: 'translate(' + numeric_shape(m[1]) + ')', value)
            elif key == 'font-family' and value in {'Times,serif', 'Times New Roman,serif'}:
                value = 'KNOWN_GRAPHVIZ_TIMES_ALIAS'
            attributes[key] = value
        nodes.append((node.tag if isinstance(node.tag, str) else '#comment', attributes, node.text if node.text and node.text.strip() else None, node.tail if node.tail and node.tail.strip() else None, len(node)))
    return root, nodes


names = [name.decode() for name in git('diff', '--name-only', '-z').split(b'\0') if name]
untracked = [name.decode() for name in git('ls-files', '--others', '--exclude-standard', '-z').split(b'\0') if name]
results, payload = [], {}
for name in names:
    before, after = git('show', 'HEAD:' + name), (repo / name).read_bytes()
    payload['before/' + name], payload['after/' + name] = before, after
    equivalent, routes, error = False, [], None
    if name.endswith('.svg'):
        try:
            a, ac = canonical(before)
            b, bc = canonical(after)
            equivalent = ac == bc
            if equivalent:
                for index, (left, right) in enumerate(zip(a.iter(), b.iter())):
                    if left.get('d') != right.get('d') and left.get('d') and right.get('d'):
                        lc, rc = cubic_segments(left.get('d')), cubic_segments(right.get('d'))
                        if lc != rc:
                            assert lc is not None and rc is not None
                            routes.append({'node': index, 'cubic_segments_before': lc, 'cubic_segments_after': rc})
        except ET.ParseError as exc:
            error = str(exc)
    results.append({'path': name, 'before_bytes': len(before), 'after_bytes': len(after), 'before_sha256': sha(before), 'after_sha256': sha(after), 'geometry_routing_times_only': equivalent, 'routing_segment_changes': routes, 'parse_error': error})
for name in untracked:
    payload['untracked/' + name] = (repo / name).read_bytes()
report = {'stage': stage, 'source': git('rev-parse', 'HEAD').decode().strip(), 'observed_utc': datetime.now(timezone.utc).isoformat(), 'changed_files': results, 'untracked': untracked, 'all_explained': not untracked and all(row['geometry_routing_times_only'] for row in results), 'restored': False, 'method': 'Exact element/child/ID/link/color/text and nongeometric attribute equality; numeric geometry, known Times alias and valid existing cubic-edge route segment counts compared separately. No Unicode normalization or browser claim.'}
if payload:
    payload['triage-before-restoration.json'] = (json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode()
    payload['manifest.json'] = (json.dumps({name: {'bytes': len(value), 'sha256': sha(value)} for name, value in payload.items()}, indent=2) + '\n').encode()
    archive = out / (stage + '-differences.zip')
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
        for name, value in payload.items():
            z.writestr(name, value)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for name, item in json.loads(z.read('manifest.json')).items():
            value = z.read(name)
            assert len(value) == item['bytes'] and sha(value) == item['sha256']
    report['archive'] = {'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes())}
target.write_text(json.dumps(report, indent=2) + '\n')
assert report['all_explained'], 'Preserved unexplained differences; investigate before restoration.'
if names:
    git('restore', '--source=HEAD', '--worktree', '--', *names)
assert not git('status', '--porcelain=v1', '-z')
report.update(restored=True, final_status_clean=True, restored_utc=datetime.now(timezone.utc).isoformat())
target.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))

"""Run one awaited review stage, preserving its exact command and output."""

import datetime
import json
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = Path("/workspace/MAM-basics")


def main():
    name, *command = sys.argv[1:]
    started = datetime.datetime.now(datetime.UTC).isoformat()
    before = (
        subprocess.check_output(["git", "status", "--porcelain=v1", "-z"], cwd=ROOT)
        .decode()
        .split("\0")
    )
    tick = time.monotonic()
    with (HERE / f"{name}.stdout").open("wb") as out:
        result = subprocess.run(command, cwd=ROOT, stdout=out, stderr=subprocess.STDOUT)
    record = {
        "stage": name,
        "command": command,
        "cwd": str(ROOT),
        "started_utc": started,
        "finished_utc": datetime.datetime.now(datetime.UTC).isoformat(),
        "seconds": round(time.monotonic() - tick, 3),
        "exit_code": result.returncode,
        "before_status": [s for s in before if s],
        "after_status": [
            s
            for s in subprocess.check_output(
                ["git", "status", "--porcelain=v1", "-z"], cwd=ROOT
            )
            .decode()
            .split("\0")
            if s
        ],
    }
    (HERE / f"stage-{name}.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2))
    print((HERE / f"{name}.stdout").read_text()[-4500:])
    raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()

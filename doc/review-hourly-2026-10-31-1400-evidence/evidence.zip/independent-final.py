"""Independent, disposable checks for the frozen hourly endpoint."""

from copy import deepcopy
import hashlib
from html.parser import HTMLParser
import json
import math
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

import numpy as np

from intro_doc_audit import human_review as hr
from pen_stroke import curve
from pen_stroke import derive
from pen_stroke import geometry as geo
from pen_stroke import stroke_svg as ss
from pen_stroke import tools

ROOT = Path.cwd()
OUT = Path("/workspace/scratch/review-hourly-20261031-1400")
BASE = "21852f741ce96dc0c06220c5ed3412b9491d65ea"
checks = []
details = {}


def check(name, condition):
    checks.append({"name": name, "pass": bool(condition)})
    if not condition:
        raise AssertionError(name)


def rejects(name, function):
    try:
        function()
    except ValueError:
        check(name, True)
        return
    check(name, False)


def old(path):
    return subprocess.check_output(["git", "show", f"{BASE}:{path}"])


class HTML(HTMLParser):
    def __init__(self, text):
        super().__init__(convert_charrefs=True)
        self.tags = []
        self.feed(text)

    def handle_starttag(self, tag, attrs):
        self.tags.append((tag, dict(attrs)))


def intro():
    local = (ROOT / "doc/intro-doc-audit/review.html").read_text()
    published_path = ROOT / "gh-pages/intro-doc-audit/index.html"
    public = published_path.read_text()
    normalized = public.replace(hr.NOTES_ON_GITHUB, "").replace(
        "../woff2/Taamey_D.woff2", "../../gh-pages/woff2/Taamey_D.woff2"
    )
    check("Published page differs only in note URLs and font path", local == normalized)
    tags = HTML(public).tags
    ids = [a["id"] for _, a in tags if "id" in a]
    check("Published IDs are unique", len(ids) == len(set(ids)))
    links = [a[key] for _, a in tags for key in ("href", "src") if key in a]
    check(
        "Published HTML has only HTTPS or fragment URLs",
        all(u.startswith(("https://", "#")) for u in links),
    )
    check(
        "Published fragments resolve",
        all(u[1:] in ids for u in links if u.startswith("#")),
    )
    notes = [
        u.removeprefix(hr.NOTES_ON_GITHUB)
        for u in links
        if u.startswith(hr.NOTES_ON_GITHUB)
    ]
    check(
        "Published note URLs resolve to committed files",
        all((ROOT / "doc/intro-doc-audit" / n).is_file() for n in notes),
    )
    check(
        "Published font path resolves",
        (published_path.parent / "../woff2/Taamey_D.woff2").is_file(),
    )
    slider = [a for t, a in tags if t == "input" and a.get("type") == "range"]
    check(
        "Size slider retains 20/48/default30",
        len(slider) == 1
        and [slider[0].get(k) for k in ("min", "max", "value")] == ["20", "48", "30"],
    )
    incoming = []
    files = (
        subprocess.check_output(["git", "ls-files", "-z", "gh-pages"])
        .decode()
        .split("\0")
    )
    for name in files:
        if not name.endswith(".html") or name == "gh-pages/intro-doc-audit/index.html":
            continue
        for _, attrs in HTML((ROOT / name).read_text()).tags:
            for attr in ("href", "src"):
                value = attrs.get(attr, "").split("#")[0].split("?")[0]
                if value.endswith(
                    ("/intro-doc-audit/", "/intro-doc-audit/index.html")
                ) or (ROOT / name).parent.joinpath(value).resolve() in (
                    published_path,
                    published_path.parent,
                ):
                    incoming.append([name, value])
    check("Published page has no incoming site links", not incoming)
    for value in (
        "../README.md",
        "/README.md",
        "absent-notes.md",
        "http://example.com/note",
        "file:///tmp/note",
    ):
        rejects(
            f"Unsafe or missing note URL rejected: {value}",
            lambda v=value: hr.note_href(v, True),
        )
    check(
        "HTTPS note URL preserved",
        hr.note_href("https://example.com/note", True) == "https://example.com/note",
    )
    records = hr.read("adjudications.json")
    previous = json.loads(old("doc/intro-doc-audit/adjudications.json"))
    changed = []
    for before, after in zip(previous, records):
        if before != after:
            changed.append(after["id"])
            a = deepcopy(after)
            for key in ("application", "application_status", "status"):
                a.pop(key, None)
            b = {
                k: v
                for k, v in before.items()
                if k not in ("application_status", "status")
            }
            check(f'Only application fields changed: {after["id"]}', a == b)
    check(
        "Exactly two adjudications changed",
        len(previous) == len(records) and len(changed) == 2,
    )
    full_lists = [
        r
        for r in records
        if r.get("application", {}).get("mirror_check") == "full-list"
    ]
    check(
        "Both new applications use full-list validation",
        len(full_lists) == 2 and {r["id"] for r in full_lists} == set(changed),
    )
    sources = hr.Sources()
    for entry in full_lists:
        hr.applied_row(entry, sources)
        for label, edit in (
            (
                "unknown-check",
                lambda x: x["application"].update(mirror_check="unrecognized"),
            ),
            (
                "wrong-applied-quote",
                lambda x: x["application"].update(
                    quote=x["application"]["quote"] + "x"
                ),
            ),
            (
                "wrong-original-list",
                lambda x: x.update(current_full_list=x["current_full_list"] + "x"),
            ),
            (
                "wrong-proposed-list",
                lambda x: x.update(proposed_full_list=x["proposed_full_list"] + "x"),
            ),
            (
                "wrong-mirror-revision",
                lambda x: x["application"].update(mirror_revision_id=1),
            ),
            (
                "mirror-before-application",
                lambda x: x["application"].update(
                    revision_id=x["application"]["mirror_revision_id"] + 1
                ),
            ),
            (
                "wrong-mirror-path",
                lambda x: x["application"].update(
                    mirror_path="in/mam-ws-intro/ch2.mediawiki"
                ),
            ),
        ):
            item = deepcopy(entry)
            edit(item)
            rejects(
                f'{entry["id"]}: {label}',
                lambda x=item: hr.applied_row(x, hr.Sources()),
            )
    coverage = hr.read("human-review-coverage.json")
    details["intro"] = {
        "local_bytes": len(local.encode()),
        "published_bytes": len(public.encode()),
        "note_links": len(notes),
        "unique_ids": len(ids),
        "new_application_ids": changed,
        "new_application_controls": 14,
        "coverage": coverage,
    }


def curves():
    x, y = np.meshgrid(np.arange(24) + 0.5, np.arange(24) + 0.5)
    straight = ((5.0, 5.0), (25 / 3, 5.0), (35 / 3, 5.0), (15.0, 5.0))
    line = (x >= 5) & (x < 15) & (y >= 3) & (y < 7)
    actual = geo.rasterize(curve.ink_pieces([straight], [4] * 4, "flat"), 24, 24)
    check(
        "Straight cubic flat sweep equals independent rectangle",
        np.array_equal(actual, line),
    )
    taper_width = 2 + 2 * (x - 5) / 10
    taper = (x >= 5) & (x < 15) & (abs(y - 5) < taper_width / 2)
    actual = geo.rasterize(
        curve.ink_pieces([straight], [2, 8 / 3, 10 / 3, 4], "flat"), 24, 24
    )
    check(
        "Variable-width cubic equals independent trapezoid",
        np.array_equal(actual, taper),
    )
    down = ((15.0, 5.0), (15.0, 25 / 3), (15.0, 35 / 3), (15.0, 15.0))
    corner = (
        line
        | ((x >= 13) & (x < 17) & (y >= 5) & (y < 15))
        | ((x >= 15) & (x < 17) & (y >= 3) & (y < 5))
    )
    actual = geo.rasterize(curve.ink_pieces([straight, down], [4] * 7, "flat"), 24, 24)
    check(
        "Right-angle flat sweep equals independent mitred rectangles",
        np.array_equal(actual, corner),
    )
    rounded = (
        line | ((x - 5) ** 2 + (y - 5) ** 2 < 4) | ((x - 15) ** 2 + (y - 5) ** 2 < 4)
    )
    actual = geo.rasterize(curve.ink_pieces([straight], [4] * 4, "round"), 24, 24)
    check(
        "Round ends equal independent capsule at pixel centres",
        np.array_equal(actual, rounded),
    )
    ws = (2, 8, 3, 5)
    check(
        "Bernstein widths remain in control bounds",
        all(2 <= curve.width(ws, k / 1000) <= 8 for k in range(1001)),
    )
    check(
        "Cubic endpoints preserved",
        curve.point(straight, 0) == straight[0]
        and curve.point(straight, 1) == straight[3],
    )
    check(
        "Width endpoints preserved",
        curve.width(ws, 0) == ws[0] and curve.width(ws, 1) == ws[-1],
    )
    check(
        "Segment width join is continuous",
        curve.segment_widths([1, 2, 3, 4, 5, 6, 7], 2)[0][-1]
        == curve.segment_widths([1, 2, 3, 4, 5, 6, 7], 2)[1][0],
    )
    check(
        "Straight curve length equals geometric chord",
        abs(curve.length([straight]) - 10) < 1e-12,
    )
    fallback = ((5, 5), (5, 5), (15, 5), (15, 5))
    tangents = [curve.tangent(fallback, t) for t in (0, 1)]
    details["fallback_tangents"] = tangents
    check(
        "Zero-derivative endpoints retain correct tangent",
        all(
            math.isclose(tx, 1, abs_tol=1e-10) and math.isclose(ty, 0, abs_tol=1e-10)
            for tx, ty in tangents
        ),
    )
    for label, f in (
        ("coincident cubic rejected", lambda: curve.tangent(((1, 1),) * 4, 0.5)),
        (
            "wrong width count rejected",
            lambda: curve.ink_pieces([straight], [1, 2], "round"),
        ),
        (
            "unknown ends rejected",
            lambda: curve.ink_pieces([straight], [1] * 4, "unknown"),
        ),
        ("line median rejected", lambda: curve.segments(geo.parse_path("M0 0 L1 1"))),
        (
            "closed median rejected",
            lambda: curve.segments(geo.parse_path("M0 0 C1 1 2 2 3 3 Z")),
        ),
        (
            "multiple subpaths rejected",
            lambda: curve.segments(
                geo.parse_path("M0 0 C1 1 2 2 3 3 M4 4 C5 5 6 6 7 7")
            ),
        ),
    ):
        rejects(label, f)
    totals = []
    ns = {"s": "http://www.w3.org/2000/svg"}
    for path in sorted((ROOT / "doc/pen-stroke-snips").glob("*.strokes.svg")):
        sf = ss.read(path)
        check(
            f"{path.name}: finite positive committed widths",
            all(math.isfinite(w) and w > 0 for st in sf.strokes for w in st.widths),
        )
        check(
            f"{path.name}: valid cubic counts",
            all(
                len(st.widths) == 1 + 3 * len(derive.median_segments(st))
                for st in sf.strokes
            ),
        )
        check(
            f"{path.name}: every generated polygon has positive winding",
            all(
                geo.signed_area(p) > 0
                for st in sf.strokes
                for p in derive.sweep_polys(st)
            ),
        )
        previous = ET.fromstring(old(path.relative_to(ROOT).as_posix()))
        current = ET.parse(path).getroot()

        def node_value(el):
            return el.tag, dict(el.attrib), [node_value(ch) for ch in el]

        for group in ("fills", "image-residual"):
            check(
                f"{path.name}: {group} unchanged",
                node_value(previous.find(f's:g[@class="{group}"]', ns))
                == node_value(current.find(f's:g[@class="{group}"]', ns)),
            )
        check(
            f"{path.name}: crop unchanged",
            node_value(previous.find("s:image", ns))
            == node_value(current.find("s:image", ns)),
        )
        crop = path.parent / sf.image
        check(
            f"{path.name}: crop bytes unchanged",
            crop.read_bytes() == old(crop.relative_to(ROOT).as_posix()),
        )
        totals.append(
            {
                "file": path.name,
                "strokes": len(sf.strokes),
                "cubic_segments": sum(
                    len(derive.median_segments(st)) for st in sf.strokes
                ),
                "crop_sha256": hashlib.sha256(crop.read_bytes()).hexdigest(),
            }
        )
    details["curve"] = {
        "analytic_masks_pixels": [int(a.sum()) for a in (line, taper, corner, rounded)],
        "svgs": totals,
    }


def provenance_and_init():
    expected = (
        ("leningrad-043A-col2-Ex20v2-PNY", "Exodus", 20, 3, [6, 7], 7),
        ("leningrad-043A-col2-Ex20v3-MFXF", "Exodus", 20, 4, [12], 16),
        ("leningrad-102A-col3-Deut5v6-3L0PNY", "Deuteronomy", 5, 7, [6, 7], 7),
        ("leningrad-102A-col3-Deut5v7-MFXF", "Deuteronomy", 5, 8, [12], 16),
    )
    for slug, book, chapter, verse, indexes, total in expected:
        source = ET.parse(ROOT / "in/UXLC-39" / f"{book}.xml")
        node = source.find(f'.//c[@n="{chapter}"]/v[@n="{verse}"]')
        words = node.findall("w")
        check(f"{slug}: declared UXLC atom population", len(words) == total)
        quoted = "".join("".join(words[i - 1].itertext()) for i in indexes)
        sf = ss.read(ROOT / "doc/pen-stroke-snips" / f"{slug}.strokes.svg")
        check(
            f"{slug}: combined transcription exactly matches UXLC bytes",
            quoted == sf.provenance["combined-chanted-word"],
        )
    crop = ROOT / "doc/pen-stroke-snips/leningrad-043A-col2-Ex20v2-PNY.png"
    target = OUT / "init-control.png"
    target.write_bytes(crop.read_bytes())
    created = tools.init_file(target, {"manuscript": "review control"})
    sf = ss.read(created)
    check(
        "Init creates profile 2 without needing a nib fit",
        not sf.strokes and bool(sf.fills) and sf.image == target.name,
    )
    before = created.read_bytes()
    try:
        tools.init_file(target, {})
    except FileExistsError:
        check(
            "Init refuses to overwrite an existing stroke file",
            created.read_bytes() == before,
        )
    else:
        check("Init refuses to overwrite an existing stroke file", False)


def main():
    errors = []
    for name, function in (
        ("intro", intro),
        ("curves", curves),
        ("provenance-init", provenance_and_init),
    ):
        if sys.argv[1:] and name not in sys.argv[1:]:
            continue
        try:
            function()
        except Exception as exc:
            import traceback

            errors.append(
                {
                    "section": name,
                    "error": repr(exc),
                    "traceback": traceback.format_exc(),
                }
            )
    result = {
        "checks": checks,
        "passed": sum(c["pass"] for c in checks),
        "details": details,
        "errors": errors,
    }
    suffix = "-".join(sys.argv[1:]) or "all"
    (OUT / f"independent-{suffix}-results.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    )
    print(
        json.dumps(
            {
                "passed": result["passed"],
                "checks": len(checks),
                "errors": errors,
                "details": {k: v for k, v in details.items() if k != "intro"},
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    raise SystemExit(bool(errors))


if __name__ == "__main__":
    main()

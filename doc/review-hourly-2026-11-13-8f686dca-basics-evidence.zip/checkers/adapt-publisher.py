"""Adapt the inspected publisher to advance one exact existing receipt ref."""

from pathlib import Path

root = Path(__file__).resolve().parent
code = Path("/workspace/scratch/basics-7173440e/publish.py").read_text(encoding="utf-8")
code = code.replace(
    'task = Path("/workspace/scratch/basics-7173440e")',
    'task = Path("/workspace/scratch/basics-8f686dca")',
)
needle = 'assert not git("ls-remote", "origin", "refs/heads/" + branch)'
assert code.count(needle) == 2
code = code.replace(
    needle,
    'assert git("ls-remote", "origin", "refs/heads/" + branch).decode() == parent + "\\trefs/heads/" + branch + "\\n"',
)
code = code.replace(
    "# A branch appearing here is a conflict: never overwrite it or force-push.",
    "# An unexpected existing tip is a conflict: stop rather than overwrite or force-push.",
)
code = code.replace(
    "Record bounded November 13 endpoint screen",
    "Record bounded November 13 22:00 UTC endpoint screen",
)
assert 'assert not git("ls-remote"' not in code
assert not (root / "publish.py").exists()
(root / "publish.py").write_text(code, encoding="utf-8", newline="\n")

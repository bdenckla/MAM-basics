"""Prepare bounded source checks without changing the admitted checkout."""

from pathlib import Path

root = Path(__file__).resolve().parent
old = Path("/workspace/scratch/basics-7173440e")
run = (old / "run.py").read_text(encoding="utf-8")
run = run.replace(
    "7173440e9a2cf932edc290a4ff17affde54a3072",
    "8f686dca6d3651b86dc824ae7c53d96f73e6d34a",
)
run = run.replace(
    '            "py/author_site/site_data.py",\n            "py/main_authored.py",\n',
    "",
)
(root / "run.py").write_text(run, encoding="utf-8", newline="\n")

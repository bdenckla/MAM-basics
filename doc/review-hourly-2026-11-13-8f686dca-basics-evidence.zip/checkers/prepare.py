"""Preserve completed focused evidence and prepare the existing receipt lineage."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "evidence"
TREE = ROOT / "head"
HOME = Path("/workspace/MAM-basics")
BASE = "7173440e9a2cf932edc290a4ff17affde54a3072"
SOURCE = "8f686dca6d3651b86dc824ae7c53d96f73e6d34a"
PARENT = "0db06a40f78972b8c7b7d5bc6475138fc499e0b5"
BRANCH = "review-hourly-20261113-7173440e-basics-receipts"
NAME = "review-hourly-2026-11-13-8f686dca-basics"


def git(*args, tree=TREE):
    return subprocess.check_output(["git", "-C", str(tree), *args])


def dump(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


assert git("rev-parse", "HEAD").decode().strip() == SOURCE
assert not git("status", "--porcelain=v1", "-z")
stages = {}
for name in (
    "black",
    "gen-site",
    "tests",
    "html",
    "probes",
    "javascript",
    "javascript2",
):
    result = json.loads((OUT / (name + ".json")).read_bytes())
    assert result["exit"] == (1 if name == "html" else 0)
    assert not (OUT / (name + ".diff")).read_bytes()
    assert not (OUT / (name + ".status")).read_bytes()
    stages[name] = result
probe = json.loads((OUT / "probe-result.json").read_bytes())
js = json.loads((OUT / "js-result.json").read_bytes())
assert probe["rendered_rows"] == 36 and probe["edition_records"] == {
    "koren": 33,
    "simanim-tanakh": 17,
}
assert js["query_group_combinations"] == 4048 and js["event_paths_per_combination"] == 2
html_log = (OUT / "html.log").read_text(encoding="utf-8")
assert set(
    line.removeprefix("orphan image: ")
    for line in html_log.splitlines()
    if line.startswith("orphan image: ")
) == set(probe["retained_unreferenced_crops"])
assert (
    "Found 4 issue(s)." in html_log
    and "103 undefined CSS class reference(s)" in html_log
)
assert "37 passed" in (OUT / "tests.log").read_text(encoding="utf-8")
operations = {
    "admission_command": [
        "/workspace/MAM-basics/.venv/bin/python",
        "-B",
        "/workspace/scratch/admit_window_20261112.py",
        str(ROOT),
        "basics",
        SOURCE,
    ],
    "read_only_lookup_failures": [
        {
            "command": [
                "rg",
                "-n",
                "State lines|hourly|bounded",
                "doc/dual-agent-review.md",
            ],
            "cwd": str(TREE),
            "exit": 2,
            "stderr": "rg: doc/dual-agent-review.md: IO error for operation on doc/dual-agent-review.md: No such file or directory (os error 2)",
            "timing": "Before maintained checks; no exact per-command UTC measurement retained.",
        },
        {
            "command": ["git", "show", PARENT + ":doc/dual-agent-review.md"],
            "cwd": str(HOME),
            "exit": 128,
            "stderr": "fatal: path 'doc/dual-agent-review.md' exists on disk, but not in '"
            + PARENT
            + "'",
            "timing": "During the maintained test stage; no exact per-command UTC measurement retained.",
        },
    ],
    "lookup_resolution": "Read the current policy-linked receipt conventions from unchanged home doc/dual-agent-review.md; no source or check mutation.",
    "preparation_interruptions": [
        "An atomic apply_patch failed to find the pre-Black single-line tuple; no file changed. Corrected against actual formatted text.",
        "One subsequent read-only exec_command failed before process creation: exec-server transport disconnected. The read succeeded on retry; no product or publication operation was attempted during interruption.",
    ],
    "checker_metadata_correction": "The first successful JS result mislabeled its 176 query values as distinct_queries. Original script/result/log preserved; corrected reporting and repeated JS only. All 4,048 combinations pass both attempts; final exact unique-string count is separate.",
}
(OUT / "operations.json").write_bytes(dump(operations))
disposition = {
    "outcome": "No consequential introduced defect established; no product repair.",
    "window": [BASE, SOURCE],
    "receipt_parent": PARENT,
    "menu": "Nine populated disjoint category/exact-edition-set choices plus all. Label counts measure rows, with shared rows counted once; the 50 edition records remain a separate count. Every populated choice matches source sets. Empty combinations are absent.",
    "removal": "Exactly one 2Samuel 13:20 redundant-mam record and its sole crop per edition removed; one combined row disappears. All retained fields except declared notes and original input order are preserved. The new common note explicitly distinguishes owner-cited Wikisource from lagging MAM-with-doc.",
    "rendering": "36 rows: 14 shared/22 single, 33 Koren/17 Simanim Tanakh records. Both forms, book/chapter/verse, strand/instance, category, link, page/scan/crop and every note/link reconcile. 152 local attributes/fragments, 54 PNGs/50 linked crops verified.",
    "controls": "4,048 query/group combinations through each of two actual input/change handlers; all 21 possible category/source groups, all and unknown. Search trimming/case/mark-insensitivity, singular/plural/zero counts, clearing, size/reset and four image toggles pass in minimal Node DOM model.",
    "known_html_exit_1": "Same four intentionally retained orphan Decalogue crops. 103 informational CSS references. No HTML-clean claim and no deletion.",
    "source_limits": "Input-record 13 Simanim/11 Koren redundant-edition counts and each stored shape are checked. Whole-MAM thirteen-instance census, Koren exceptions and error interpretations, oldid3102618 and linked issue ownership remain attributed owner research. No external-source/issue consultation, acquisition, scan census or new Hebrew/editorial policy.",
    "overall_reviewed": "210affe3ac2931473bead0de839be0de08309e3d",
    "broad_tested": "9ed47c6e8999ecaf56031e9b3f524bee6e01507a",
    "preservation": "Exact receipt parent keeps every historical row, pending gap and immutable receipt, November 13 nightly and Windows supplement 3030161007bc393f554cf0c95cf819ed4d81a93c, and Taamey D corpus/baseline limits.",
    "limits": "No broad/mega/nightly rerun, browser/layout/accessibility-tree/font/HP evidence, Private or hbofonts work, live-source refresh, full scans, main/shared integration, deployment, dispatch, scheduling or outside-agent communication. Cross-machine ownership unverified.",
}
(OUT / "disposition.json").write_bytes(dump(disposition))
completed = {
    "state": "completed",
    "source": SOURCE,
    "completed_utc": datetime.now(timezone.utc).isoformat(),
    "stages": stages,
    "outcome": disposition["outcome"],
    "known_failure": disposition["known_html_exit_1"],
}
(ROOT / "stage.json").write_bytes(dump(completed))
(OUT / "stage.json").write_bytes(dump(completed))
payload = {p.name: p.read_bytes() for p in OUT.iterdir() if p.is_file()}
for name in (
    "setup.py",
    "run.py",
    "probe.py",
    "js-probe.cjs",
    "prepare.py",
    "adapt-publisher.py",
    "publish.py",
):
    payload["checkers/" + name] = (ROOT / name).read_bytes()
payload["manifest.json"] = dump(
    {
        name: {"bytes": len(raw), "sha256": sha(raw)}
        for name, raw in sorted(payload.items())
    }
)
receipts = ROOT / "receipts"
assert not receipts.exists()
assert git("rev-parse", "refs/heads/" + BRANCH, tree=HOME).decode().strip() == PARENT
assert ("branch refs/heads/" + BRANCH + "\n") not in git(
    "worktree", "list", "--porcelain", tree=HOME
).decode()
assert (
    git("ls-remote", "origin", "refs/heads/" + BRANCH, tree=HOME).decode()
    == PARENT + "\trefs/heads/" + BRANCH + "\n"
)
subprocess.run(
    ["git", "-C", str(HOME), "worktree", "add", str(receipts), BRANCH],
    check=True,
    capture_output=True,
)
assert git("rev-parse", "--show-toplevel", tree=receipts).decode().strip() == str(
    receipts
)
assert git("rev-parse", "HEAD", tree=receipts).decode().strip() == PARENT
assert git("branch", "--show-current", tree=receipts).decode().strip() == BRANCH
assert not git("status", "--porcelain=v1", "-z", tree=receipts)
archive = receipts / "doc" / (NAME + "-evidence.zip")
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as z:
    for name, raw in sorted(payload.items()):
        z.writestr(name, raw)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist()))
    for name, entry in json.loads(z.read("manifest.json")).items():
        assert (
            len(z.read(name)) == entry["bytes"] and sha(z.read(name)) == entry["sha256"]
        )
report = f"""# Bounded Basics screen, November 13, 2026, 22:00 UTC cycle

State: completed 2026-11-13; focused technical review, no product repair

Reviewed `{BASE}` → `{SOURCE}`: **two commits / eight paths**, 111 insertions / 128 deletions. No consequential introduced defect established; no product repair. Receipt parent `{PARENT}` retains the earlier screens and November 13 nightly/Windows evidence.

The page has **50 edition records** (33 Koren / 17 Simanim Tanakh), rendered as **36 rows: 14 shared and 22 single-edition**. Its nine populated menu choices match disjoint category/exact-edition sets; each label counts rows, so a shared row counts once. All retained record fields except declared notes, their input order, and every rendered form/strand/instance/page/scan/crop/note/link reconcile independently. Exactly the two 2Sam 13:20 edition records and their two crops are removed. The new common note explicitly retains the distinction between owner-cited Wikisource and lagging MAM-with-doc. The old addresses remain removed.

Maintained `gen-site --trust-surveys` reproduces all tracked outputs exactly; **37 selected tests** and changed-source Black pass. HTML validation **exits 1** solely for the same four intentionally retained orphan Decalogue crops; 103 CSS references are informational. Independent checks cover **152 local link/asset attributes**, **54 PNGs / 50 linked crops**, and all retained public MAM body/qere forms. Every stage leaves empty tracked/untracked source diffs/statuses.

The actual JavaScript passes **4,048 query/group combinations through both event handlers**, including all populated choices, empty groups, marked/unmarked Hebrew, case/space handling and singular/zero/plural counts. Size/reset, clearing search/menu and four image toggles pass. This is a minimal Node DOM model, with no browser/layout/accessibility-tree/font evidence. The successful first probe's query-count label was corrected and that JS stage repeated; both scripts/results remain archived. Two policy-document lookup failures were resolved by reading the current home copy and remain operational evidence.

The **13 Simanim / 11 Koren** redundant-helper input counts and stored shapes agree; the whole-MAM thirteen-instance census, Koren omissions/error interpretation, live Wikisource revision and existing issue reference remain owner-attributed research. No live source/issue consultation, scan census, full-page collation or Hebrew/editorial decision was made.

Overall reviewed remains `210affe3ac2931473bead0de839be0de08309e3d`; broad-tested remains `9ed47c6e8999ecaf56031e9b3f524bee6e01507a`. Every prior row, pending gap, immutable receipt, Windows supplement `3030161007bc393f554cf0c95cf819ed4d81a93c` and Taamey D limit is preserved. Local admission was clear; cross-machine ownership remains unverified. No broad rerun, Private/hbofonts work, main/shared integration, deployment/dispatch or schedule change.

[Evidence]({archive.name}): **{archive.stat().st_size} bytes**, SHA-256 `{sha(archive.read_bytes())}`; ZIP CRC and every payload hash verified locally. This is preparation on the existing isolated receipt branch; normal publication verification and owned-worktree cleanup/slot release are recorded separately after execution. Source and receipt parent retain the sole manual-dispatch Pages workflow.
"""
(receipts / "doc" / (NAME + ".md")).write_text(report, encoding="utf-8", newline="\n")
before = git("show", PARENT + ":doc/review-trial-status.md").decode("utf-8")
section = f"""## Bounded screen, 2026-11-13 22:00 UTC cycle, 8f686dca

Reviewed `{BASE}` → `{SOURCE}`: two commits / eight paths; no consequential introduced defect or product repair. The nine populated exact-edition-set/category choices account for 36 rows (14 shared/22 single), separate from 50 edition records (33 Koren/17 Simanim Tanakh). All retained fields except declared notes survive in their original order; exactly two 2Sam 13:20 records/crops are withdrawn. Maintained gen-site is exact; 37 focused tests and changed-source Black pass. HTML exits 1 for four retained orphan crops, with 103 informational CSS references. Independent data/DOM, 152-local-attribute, 54-PNG and 4,048 actual-JS combination checks pass. Source census/revision/editorial claims stay attributed; no browser or broad rerun. [Receipt]({NAME}.md), [evidence]({archive.name}).

Lineage `{PARENT}` preserves all historical rows, pending gaps, immutable receipts, November 13 nightly/Windows evidence and Taamey D limits. Overall reviewed `210affe3ac2931473bead0de839be0de08309e3d` and broad-tested `9ed47c6e8999ecaf56031e9b3f524bee6e01507a` remain unchanged. Existing isolated receipt branch preparation only; publication/cleanup are later closeout steps. No Private, hbofonts, main/shared/deployment or schedule work.

"""
anchor = "## Bounded screen, 2026-11-13 21:00 UTC cycle, 7173440e"
assert before.count(anchor) == 1
after = before.replace(anchor, section + anchor, 1)
table = "| Anchor | Commit/result |\n| --- | --- |\n"
rows = f"| Bounded screen 8f686dca, 2026-11-13 22:00 UTC | `{BASE}` → `{SOURCE}`; two commits / eight paths; no consequential defect or repair. [Receipt]({NAME}.md). |\n| Focused evidence 8f686dca | gen-site exact; 37 tests/Black pass; HTML exit 1 for four retained orphan crops. 50 records/36 rows/nine choices; 152 local attributes; 54 PNGs/50 linked; 4,048 Node combinations. [Evidence]({archive.name}). |\n"
assert after.count(table) == 1
after = after.replace(table, table + rows, 1)
assert after.replace(section, "", 1).replace(rows, "", 1) == before
(receipts / "doc/review-trial-status.md").write_text(
    after, encoding="utf-8", newline="\n"
)
paths = sorted(
    [
        "doc/" + NAME + ".md",
        "doc/" + NAME + "-evidence.zip",
        "doc/review-trial-status.md",
    ]
)
changed = set(
    filter(None, git("diff", "--name-only", "-z", tree=receipts).decode().split("\0"))
) | set(
    filter(
        None,
        git("ls-files", "--others", "--exclude-standard", "-z", tree=receipts)
        .decode()
        .split("\0"),
    )
)
assert changed == set(paths)
git("diff", "--check", tree=receipts)
prepared = {
    "branch": BRANCH,
    "parent": PARENT,
    "source": SOURCE,
    "paths": paths,
    "archive": {
        "path": archive.name,
        "bytes": archive.stat().st_size,
        "sha256": sha(archive.read_bytes()),
        "payload_files": len(payload) - 1,
    },
    "prepared_utc": datetime.now(timezone.utc).isoformat(),
}
(ROOT / "publication-prepared.json").write_bytes(dump(prepared))
print(json.dumps(prepared, indent=2))

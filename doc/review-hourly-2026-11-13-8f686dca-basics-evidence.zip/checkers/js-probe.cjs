// Actual script execution in a minimal DOM; expected groups derive from source sets.
const fs = require("node:fs");
const vm = require("node:vm");
const assert = require("node:assert/strict");
const root = __dirname;
const page = JSON.parse(fs.readFileSync(root + "/evidence/js-input.json", "utf8"));
const code = fs.readFileSync(root + "/head/gh-pages/stress-helpers/controls.js", "utf8");
const events = new Map();
const elements = {};
for (const id of ["hebrew-size", "size-value", "size-reset", "toggle-images", "find", "filter", "visible"]) {
    elements[id] = {
        value: id === "hebrew-size" ? "30" : "",
        defaultValue: id === "hebrew-size" ? "30" : "",
        textContent: "",
        attributes: {"aria-expanded": "false"},
        addEventListener(event, callback) { events.set(id + "/" + event, callback); },
        getAttribute(name) { return this.attributes[name]; },
        setAttribute(name, value) { this.attributes[name] = String(value); },
    };
}
const rows = page.rows.map(r => ({cells:r.cells.map(textContent => ({textContent})), dataset:{filter:r.filter}, hidden:false}));
const scans = Array.from({length:rows.length + 1}, () => ({hidden:true}));
const properties = {};
const context = {document:{
    documentElement:{style:{setProperty(name, value) {properties[name] = value;}}},
    querySelector(selector) {assert(selector.startsWith("#")); assert(elements[selector.slice(1)]); return elements[selector.slice(1)];},
    querySelectorAll(selector) {
        if (selector === "#observations .scan") return scans;
        if (selector === "#observations tbody tr") return rows;
        throw new Error(selector);
    },
}};
vm.runInNewContext(code, context, {filename:"controls.js"});
assert.equal(properties["--hebrew-size"], "30px");
assert.equal(elements.visible.textContent, rows.length + " differences");
for (const size of ["20", "48", "35"]) {
    elements["hebrew-size"].value = size;
    events.get("hebrew-size/input")();
    assert.equal(properties["--hebrew-size"], size + "px");
    assert.equal(elements["size-value"].textContent, size + " px");
}
events.get("size-reset/click")();
assert.equal(properties["--hebrew-size"], "30px");
assert.equal(elements["size-value"].textContent, "30 px");
for (const show of [true, false, true, false]) {
    events.get("toggle-images/click")();
    assert(scans.every(cell => cell.hidden === !show));
    assert.equal(elements["toggle-images"].attributes["aria-expanded"], String(show));
    assert.equal(elements["toggle-images"].textContent, show ? "Hide images" : "Show images");
}
// Independent code-point loop rather than copying the production regex.
function key(value) {
    let out = "";
    for (const char of value.toLocaleLowerCase("en")) {
        const n = char.codePointAt(0);
        if ((n >= 1425 && n <= 1469) || (n >= 1471 && n <= 1479)) continue;
        out += char;
    }
    return out;
}
function sourceGroup(row) {
    const kor = row.editions.includes("koren");
    const sim = row.editions.includes("simanim-tanakh");
    assert(kor || sim);
    return row.category + "-" + (kor && sim ? "KorSim" : kor ? "Kor" : "Sim");
}
const sourceGroups = page.rows.map(sourceGroup);
assert.deepEqual([...new Set(sourceGroups)].sort(), page.options.filter(Boolean).sort());
const queries = ["", "unmatched-needle", "MAM", "mam", "  MAM  ", ...page.queries, ...page.queries.map(key), ...page.queries.map(q => "  " + q.toUpperCase() + "  ")];
// Include every mechanically possible group to verify empty groups reject rows.
const categories = ["no-helper", "gerstar-telg", "redundant-mam", "redundant-edition", "extra-helper", "different-placement", "different-accent"];
const groups = ["", "UNKNOWN", ...categories.flatMap(c => ["KorSim", "Kor", "Sim"].map(e => c + "-" + e))];
let cases = 0;
const observedCounts = {};
let singular = 0, empty = 0;
for (const query of queries) {
    for (const group of groups) {
        elements.find.value = query;
        elements.filter.value = group;
        const expected = page.rows.map((row, i) => row.cells.some(c => key(c).includes(key(query.trim()))) && (!group || sourceGroups[i] === group));
        for (const event of ["find/input", "filter/change"]) {
            events.get(event)();
            assert.deepEqual(rows.map(row => !row.hidden), expected);
            const count = expected.filter(Boolean).length;
            assert.equal(elements.visible.textContent, count + (count === 1 ? " difference" : " differences"));
        }
        const count = expected.filter(Boolean).length;
        if (count === 1) singular++;
        if (count === 0) empty++;
        if (query === "") observedCounts[group || "all"] = count;
        cases++;
    }
}
assert(singular > 0 && empty > 0);
// Clear search and menu through both actual handlers after the final nonempty query.
elements.find.value = "";
elements.filter.value = "";
for (const event of ["find/input", "filter/change"]) {
    events.get(event)();
    assert(rows.every(row => !row.hidden));
    assert.equal(elements.visible.textContent, rows.length + " differences");
}
const result = {node:process.version, rows:rows.length, query_group_combinations:cases, query_values:queries.length, distinct_query_strings:new Set(queries).size, populated_menu_choices:page.options.length - 1, tested_group_values:groups.length, event_paths_per_combination:2, source_set_group_counts:observedCounts, singular_cases:singular, empty_cases:empty, range_values:3, image_toggles:4, size_reset:true, clear_search_and_menu:true, limit:"Minimal DOM model only; no browser rendering, accessibility-tree, layout, network or font verification. Every choice matches an exact category/source-edition set, with each shared row counted once."};
fs.writeFileSync(root + "/evidence/js-result.json", JSON.stringify(result, null, 2) + "\n", "utf8");
console.log(JSON.stringify(result));

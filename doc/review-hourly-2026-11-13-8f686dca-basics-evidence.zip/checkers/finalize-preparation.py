"""Reconcile current instruction routing and preserve exact operational diagnostics."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "head"
RECEIPTS = ROOT / "receipts"
OUT = ROOT / "evidence"
HOME = Path("/workspace/MAM-basics")
SOURCE = "8f686dca6d3651b86dc824ae7c53d96f73e6d34a"
PARENT = "0db06a40f78972b8c7b7d5bc6475138fc499e0b5"


def git(tree, *args):
    return subprocess.check_output(["git", "-C", str(tree), *args])


def dump(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


assert git(TREE, "rev-parse", "HEAD").decode().strip() == SOURCE
assert not git(TREE, "status", "--porcelain=v1", "-z")
assert git(RECEIPTS, "rev-parse", "HEAD").decode().strip() == PARENT
assert (
    git(HOME, "rev-parse", "HEAD").decode().strip()
    == "cb878aef91e692d5561435f00021f73b75868e45"
)
assert not git(HOME, "status", "--porcelain=v1", "-z")
assert not (ROOT / "publication.json").exists()
slot = json.loads(Path(str(ROOT) + "-slot.json").read_bytes())
assert slot["state"] == "claimed" and slot["source"] == SOURCE
processes = []
zombies = []
for proc in Path("/proc").iterdir():
    if not proc.name.isdigit() or int(proc.name) == os.getpid():
        continue
    try:
        args = (proc / "cmdline").read_bytes().decode().split("\0")
        status = (proc / "status").read_text(encoding="utf-8")
        if "\nState:\tZ " in status:
            zombies.append({"pid": int(proc.name), "state": "Z", "executing": False})
        if args and Path(args[0]).name in {
            "python",
            "python3",
            "python3.13",
            "pytest",
            "node",
        }:
            processes.append({"pid": int(proc.name), "args": args})
    except (OSError, UnicodeError):
        pass
assert not processes, processes
ownership = {
    "observed_utc": datetime.now(timezone.utc).isoformat(),
    "source_clean": True,
    "source": SOURCE,
    "receipt_head": PARENT,
    "publication_attempted": False,
    "slot": slot,
    "active_python_pytest_node": processes,
    "nonexecuting_zombies": zombies,
    "home_head": "cb878aef91e692d5561435f00021f73b75868e45",
    "home_clean": True,
    "worktrees": git(HOME, "worktree", "list", "--porcelain").decode(),
    "cross_machine": "unverified",
}
(OUT / "prepublication-ownership.json").write_bytes(dump(ownership))
instruction_paths = [
    "AGENTS.md",
    "dot-Codex/user-wide-AGENTS.md",
    "doc/review-trial.md",
    "doc/periodic-review.md",
    "dot-claude/skills/linked-worktrees/SKILL.md",
    "dot-claude/skills/iterative-document-editing/SKILL.md",
    "dot-Codex/skills/codex-worktree-tasks/SKILL.md",
    "dot-Codex/skills/codex-worktree-tasks/references/worktree-runtime.md",
    "dot-Codex/skills/codex-worktree-tasks/references/task-lifecycle.md",
    "dot-claude/skills/hebrew-prose/SKILL.md",
    "dot-claude/skills/hebrew-prose/references/mam-basics.md",
    "dot-claude/skills/hebrew-prose/references/rendered-prose.md",
    "dot-claude/skills/hebrew-prose/references/verifying.md",
]
(OUT / "instruction-provenance.json").write_bytes(
    dump(
        {
            "observed_utc": datetime.now(timezone.utc).isoformat(),
            "source": SOURCE,
            "initial_home": "cb878aef91e692d5561435f00021f73b75868e45",
            "correction": "Initial home instruction read was older than the frozen source. Current source instruction bodies, changed skill references and periodic-review routing subsequently read. Applicable review/check/one-writer/safeguard requirements are satisfied; no product recheck warranted. Linked-worktrees and Codex task skill bodies are byte-identical between home and source.",
            "current_files": {
                p: {
                    "bytes": len((TREE / p).read_bytes()),
                    "sha256": sha((TREE / p).read_bytes()),
                }
                for p in instruction_paths
            },
        }
    )
)
operations = json.loads((OUT / "operations.json").read_bytes())
operations["lookup_resolution"] = (
    "The initial home instructions were older than the frozen source. Reconciled the admitted current AGENTS.md and user-wide body; current AGENTS.md routes ordinary receipt conventions to doc/periodic-review.md, which was read. The obsolete dual-agent document is absent at the source and receipt parent. No product or check result changed."
)
operations["transport_rejection"] = {
    "action": "read-only exec_command, process creation",
    "command": [
        "rg",
        "-n",
        "-A10",
        "preservation|for name in|All retained fields",
        str(ROOT / "prepare.py"),
    ],
    "reason": 'CreateProcess: Rejected("Failed to create unified exec process: exec-server transport disconnected")',
    "execution_state": "known not created",
    "resolution": "One bounded read retry succeeded. Source/receipt heads, clean source/home, owned claimed slot, no publication record and absence of active Python/pytest/node product jobs verified before final packaging.",
}
(OUT / "operations.json").write_bytes(dump(operations))
prepared = json.loads((ROOT / "publication-prepared.json").read_bytes())
archive = RECEIPTS / "doc" / prepared["archive"]["path"]
original = archive.read_bytes()
assert sha(original) == prepared["archive"]["sha256"]
(ROOT / "first-preparation-evidence.zip").write_bytes(original)
old_archive = dict(prepared["archive"])
payload = {p.name: p.read_bytes() for p in OUT.iterdir() if p.is_file()}
for name in (
    "setup.py",
    "run.py",
    "probe.py",
    "js-probe.cjs",
    "prepare.py",
    "adapt-publisher.py",
    "publish.py",
    "finalize-preparation.py",
):
    payload["checkers/" + name] = (ROOT / name).read_bytes()
payload["manifest.json"] = dump(
    {
        name: {"bytes": len(raw), "sha256": sha(raw)}
        for name, raw in sorted(payload.items())
    }
)
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as z:
    for name, raw in sorted(payload.items()):
        z.writestr(name, raw)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    manifest = json.loads(z.read("manifest.json"))
    assert len(z.namelist()) == len(set(z.namelist())) == len(manifest) + 1
    for name, entry in manifest.items():
        assert (
            len(z.read(name)) == entry["bytes"] and sha(z.read(name)) == entry["sha256"]
        )
report = RECEIPTS / "doc/review-hourly-2026-11-13-8f686dca-basics.md"
text = report.read_text(encoding="utf-8")
old_measure = f"**{old_archive['bytes']} bytes**, SHA-256 `{old_archive['sha256']}`"
assert text.count(old_measure) == 1
text = text.replace(
    old_measure,
    f"**{archive.stat().st_size} bytes**, SHA-256 `{sha(archive.read_bytes())}`",
    1,
)
needle = "Two policy-document lookup failures were resolved by reading the current home copy and remain operational evidence."
assert text.count(needle) == 1
text = text.replace(
    needle,
    "Two obsolete policy-document lookups were resolved through the current source instructions’ routing to `doc/periodic-review.md`; both failures and the brief execution-service disconnect remain operational evidence.",
    1,
)
report.write_text(text, encoding="utf-8", newline="\n")
prepared["archive"].update(
    bytes=archive.stat().st_size,
    sha256=sha(archive.read_bytes()),
    payload_files=len(manifest),
)
prepared.update(
    finalized_utc=datetime.now(timezone.utc).isoformat(),
    initial_preparation_archive=old_archive,
)
(ROOT / "publication-prepared.json").write_bytes(dump(prepared))
git(RECEIPTS, "diff", "--check")
print(json.dumps(prepared, indent=2))

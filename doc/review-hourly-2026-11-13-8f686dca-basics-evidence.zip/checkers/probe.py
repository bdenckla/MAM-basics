"""Independently reconcile source records, exact-set menu groups, DOM and assets."""

from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import unquote, urlsplit

from lxml import html
from PIL import Image

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "head"
OUT = ROOT / "evidence"
BASE = "7173440e9a2cf932edc290a4ff17affde54a3072"
SOURCE = "8f686dca6d3651b86dc824ae7c53d96f73e6d34a"
PARENT = "0db06a40f78972b8c7b7d5bc6475138fc499e0b5"
sys.path.insert(0, str(TREE / "py"))  # Disposable harness only.
from mb_cmn import uni_denorm


def git(*args):
    return subprocess.check_output(["git", "-C", str(TREE), *args])


def save(name, value):
    (OUT / name).write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def text(node):
    return " ".join(node.text_content().split())


def identity(r):
    return tuple(
        r.get(k)
        for k in (
            "book",
            "chapter",
            "verse",
            "strand",
            "instance",
            "mam",
            "printed",
            "verse_href",
            "category",
        )
    )


cache = {}


def page(path):
    path = path.resolve()
    if path not in cache:
        cache[path] = html.fromstring(path.read_bytes())
    return cache[path]


def qere(node):
    node = deepcopy(node)
    for ketiv in node.xpath('.//span[@class="mam-kq-k"]'):
        ketiv.drop_tree()
    return text(node).replace("[", "").replace("]", "")


assert git("rev-parse", "HEAD").decode().strip() == SOURCE
assert not git("status", "--porcelain=v1", "-z")
changed = [
    p for p in git("diff", "--name-only", "-z", BASE, SOURCE).decode().split("\0") if p
]
assert len(changed) == 8
identities = {}
for path in changed:
    deleted = not (TREE / path).exists()
    raw = git("show", (BASE if deleted else SOURCE) + ":" + path)
    if not deleted:
        assert (TREE / path).read_bytes() == raw
    identities[path] = {
        "deleted": deleted,
        "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
    }
save("identities.json", identities)
(OUT / "endpoint.diff").write_bytes(git("diff", BASE, SOURCE))
(OUT / "commits.txt").write_bytes(git("log", "--format=fuller", BASE + ".." + SOURCE))
git("diff", "--check", BASE, SOURCE)
inputs, deltas, removed, groups = {}, {}, {}, {}
all_crops = set()
for edition in ("koren", "simanim-tanakh"):
    path = "in/stress-helpers/" + edition + ".json"
    data = json.loads((TREE / path).read_bytes())
    old = json.loads(git("show", BASE + ":" + path))
    assert {k: v for k, v in data.items() if k != "differences"} == {
        k: v for k, v in old.items() if k != "differences"
    }
    old_records = {identity(r): r for r in old["differences"]}
    new_records = {identity(r): r for r in data["differences"]}
    assert len(old_records) == len(old["differences"]) and len(new_records) == len(
        data["differences"]
    )
    assert not new_records.keys() - old_records.keys()
    missing = old_records.keys() - new_records.keys()
    assert len(missing) == 1
    deleted = old_records[next(iter(missing))]
    assert (
        deleted["book"],
        deleted["chapter"],
        deleted["verse"],
        deleted["category"],
    ) == ("2Samuel", 13, 20, "redundant-mam")
    assert deleted["verse_href"].endswith("#c13v20") and len(deleted["crops"]) == 1
    for crop in deleted["crops"]:
        assert not (TREE / "gh-pages/stress-helpers" / crop).exists()
    removed[edition] = deleted
    assert [identity(r) for r in data["differences"]] == [
        identity(r) for r in old["differences"] if identity(r) not in missing
    ]
    deltas[edition] = []
    for after in data["differences"]:
        before = old_records[identity(after)]
        assert {k: v for k, v in before.items() if k != "notes"} == {
            k: v for k, v in after.items() if k != "notes"
        }
        if before.get("notes") != after.get("notes"):
            deltas[edition].append(
                {
                    "identity": identity(after),
                    "before": before.get("notes"),
                    "after": after.get("notes"),
                }
            )
        assert edition not in groups.setdefault(identity(after), {})
        groups[identity(after)][edition] = after
        all_crops.update(after["crops"])
    inputs[edition] = data
assert {p for p in changed if identities[p]["deleted"]} == {
    "gh-pages/stress-helpers/" + r["crops"][0] for r in removed.values()
}
save("removed-comparisons.json", removed)
save("note-deltas.json", deltas)
target = TREE / "gh-pages/stress-helpers/index.html"
doc = page(target)
rows = doc.xpath('//table[@id="observations"]/tbody/tr')
assert len(rows) == len(groups)
ids = doc.xpath("//*[@id]/@id")
assert len(ids) == len(set(ids))
assert not doc.xpath('//*[@id="edition" or @id="outcome"]')
assert doc.xpath('//*[@id="hebrew-size"]/@value') == ["30"]
assert len(doc.xpath('//*[@class="scan" and @hidden]')) == len(rows) + 1
remaining = dict(groups)
flattened, filter_counts, sizes = Counter(), Counter(), Counter()
row_evidence, js_rows = [], []
book_order = "Genesis Exodus Levit Numbers Deuter Joshua Judges 1Samuel 2Samuel 1Kings 2Kings Isaiah Jeremiah Ezekiel Hosea Joel Amos Obadiah Jonah Micah Nahum Habakkuk Zephaniah Haggai Zechariah Malachi Psalms Proverbs Job SongOfSongs Ruth Lamentations Ecclesiastes Esther Daniel Ezra Nehemiah 1Chronicles 2Chronicles".split()
order = []
for row in rows:
    forms = row.xpath('.//span[@class="hebrew"]/text()')
    hrefs = row.xpath("./th/a/@href")
    candidates = [
        (k, s) for k, s in remaining.items() if list(k[5:7]) == forms and k[7] in hrefs
    ]
    assert len(candidates) == 1
    k, sources = candidates[0]
    remaining.pop(k)
    editions = frozenset(sources)
    # Exact set membership is derived from input records, independent of renderer metadata.
    suffix = {
        frozenset(["koren"]): "Kor",
        frozenset(["simanim-tanakh"]): "Sim",
        frozenset(["koren", "simanim-tanakh"]): "KorSim",
    }[editions]
    expected_filter = k[8] + "-" + suffix
    assert row.get("data-filter") == expected_filter
    filter_counts[expected_filter] += 1
    sizes[len(sources)] += 1
    record = next(iter(sources.values()))
    assert len(row) == 4 and row[0].get("dir") == "rtl"
    assert row.xpath('./th/span[@class="source"]/@title') == [
        r["scan"] for r in sources.values()
    ]
    expected_pages = [
        (
            (("Koren " if e == "koren" else "SimTan ") + "p. " + str(r["page"]))
            if len(sources) > 1
            else "p. " + str(r["page"])
        )
        for e, r in sources.items()
    ]
    assert [text(n) for n in row.xpath('./th/span[@class="source"]')] == expected_pages
    assert row.xpath(".//img/@src") == [c for r in sources.values() for c in r["crops"]]
    assert row.xpath('./td[@class="scan"]/a/@href') == row.xpath(".//img/@src")
    assert [text(n) for n in row.xpath('.//span[@class="edition"]')] == [
        "MAM",
        " / ".join("Koren" if e == "koren" else "SimTan" for e in sources),
    ]
    if record.get("instance"):
        assert "Instance " + str(record["instance"]) in text(row[1])
    assert row.xpath("./th/bdi/text()") == (
        [record["strand"]] if record.get("strand") else []
    )
    expected_notes, expected_links = [], []
    for e, r in sources.items():
        flattened[e] += 1
        assert all(uni_denorm.has_std_mark_order(r[f]) for f in ("mam", "printed"))
        for note in r.get("notes", []):
            n = note["text"] + (
                " " + note.get("label", "MAM doc-note") if note.get("href") else ""
            )
            if n not in expected_notes:
                expected_notes.append(n)
            if note.get("href") and note["href"] not in expected_links:
                expected_links.append(note["href"])
    assert [text(n) for n in row.xpath('./td[@class="difference"]/p')] == expected_notes
    assert (
        list(dict.fromkeys(row.xpath('./td[@class="difference"]/p/a/@href')))
        == expected_links
    )
    loc = urlsplit(record["verse_href"])
    anchor = page(target.parent / unquote(loc.path)).xpath(
        "//*[@id=$ident]", ident=loc.fragment
    )
    assert len(anchor) == 1 and " ".join(record["mam"].split()) in qere(
        anchor[0].getparent()
    )
    order.append((book_order.index(record["book"]), record["chapter"], record["verse"]))
    row_evidence.append(
        {
            "identity": k,
            "editions": list(sources),
            "filter": expected_filter,
            "pages": expected_pages,
            "crops": row.xpath(".//img/@src"),
            "notes": expected_notes,
        }
    )
    js_rows.append(
        {
            "filter": expected_filter,
            "category": k[8],
            "editions": list(sources),
            "cells": [text(c) for c in row],
        }
    )
assert not remaining and order == sorted(order)
assert flattened == {e: len(d["differences"]) for e, d in inputs.items()}
options = doc.xpath('//*[@id="filter"]/option')
assert [o.get("value") for o in options][0] == ""
assert text(options[0]) == f"All differences ({len(rows)})"
option_values = [o.get("value") for o in options[1:]]
assert (
    len(option_values) == len(set(option_values))
    and set(option_values) == filter_counts.keys()
)
labels = {
    "no-helper": "No SH in {edition}",
    "gerstar-telg": "Gerstar + tel. g. — {edition}",
    "redundant-mam": "Redundant SH in MAM — {edition}",
    "redundant-edition": "Redundant SH in {edition}",
    "extra-helper": "SH in {edition} only",
    "different-placement": "Different SH placement — {edition}",
    "different-accent": "Different accent — {edition}",
}
expected_options = [""]
for category, template in labels.items():
    for edition in ("KorSim", "Kor", "Sim"):
        value = category + "-" + edition
        if value in filter_counts:
            expected_options.append(value)
            option = next(o for o in options if o.get("value") == value)
            assert (
                text(option)
                == template.format(edition=edition) + f" ({filter_counts[value]})"
            )
assert [o.get("value") for o in options] == expected_options
assert sum(filter_counts.values()) == len(rows)
for e, d in inputs.items():
    assert d["edition_credit"] in text(doc)
    assert Counter(r["category"] for r in d["differences"])["redundant-edition"] == (
        11 if e == "koren" else 13
    )
    for r in d["differences"]:
        if r["category"] == "redundant-edition":
            assert (
                r["mam"].count("\N{HEBREW ACCENT PASHTA}") == 1
                and r["printed"].count("\N{HEBREW ACCENT PASHTA}") == 2
            )
            assert re.search(
                "[\u05d0-\u05ea][\u0591-\u05c9]*\N{HEBREW POINT SHEVA}[\u0591-\u05c9]*[\u05d0-\u05ea][\u0591-\u05c9]*\N{HEBREW POINT SHEVA}[\u0591-\u05c9]*$",
                r["mam"],
            )
common = json.loads((TREE / "in/stress-helpers/common.json").read_bytes())
intro = common["coverage"] + [
    n["text"] + " " + n["label"] for n in common["source_notes"]
]
assert [text(n) for n in doc.xpath("//main/p")[: len(intro)]] == intro
assert [n["href"] for n in common["source_notes"]] == doc.xpath("//main/p/a/@href")[
    : len(common["source_notes"])
]
links, external = 0, set()
for node in doc.xpath("//*[@href or @src]"):
    for attr in ("href", "src"):
        value = node.get(attr)
        if value is None:
            continue
        loc = urlsplit(value)
        if loc.scheme or loc.netloc:
            external.add(value)
            continue
        dest = (target.parent / unquote(loc.path)).resolve() if loc.path else target
        assert dest.is_relative_to(TREE / "gh-pages") and dest.is_file(), value
        if loc.fragment:
            assert page(dest).xpath(
                "//*[@id=$ident or @name=$ident]", ident=unquote(loc.fragment)
            ), value
        links += 1
pngs = {}
for p in sorted((target.parent / "img").glob("*.png")):
    with Image.open(p) as img:
        assert img.format == "PNG"
        pngs["img/" + p.name] = {
            "width": img.width,
            "height": img.height,
            "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
        }
        img.verify()
orphans = sorted(pngs.keys() - all_crops)
assert len(orphans) == 4
assert (
    not (target.parent / "koren.html").exists()
    and not (target.parent / "simanim-tanakh.html").exists()
)
assert page(TREE / "gh-pages/index.html").xpath(
    '//a[@href="stress-helpers/index.html"]'
)
old_addresses = []
for p in [
    p
    for p in git("ls-files", "-z", "--", "gh-pages", "py").decode().split("\0")
    if p and Path(p).suffix in {".html", ".js", ".py", ".json"}
]:
    content = (TREE / p).read_text(encoding="utf-8")
    if (
        "stress-helpers/koren.html" in content
        or "stress-helpers/simanim-tanakh.html" in content
    ):
        old_addresses.append(p)
assert not old_addresses
workflow = {}
for ref in (PARENT, SOURCE):
    files = [
        p
        for p in git("ls-tree", "-r", "--name-only", "-z", ref, "--", ".github")
        .decode()
        .split("\0")
        if p
    ]
    assert files == [".github/workflows/pages.yml"]
    blob = git("rev-parse", ref + ":.github/workflows/pages.yml").decode().strip()
    assert blob == "18ceb19405424710bda47d9a38c470cc2ed9c385"
    raw = git("show", ref + ":.github/workflows/pages.yml").decode()
    assert "on:\n  workflow_dispatch:\n" in raw
    workflow[ref] = {"paths": files, "blob": blob, "text": raw}
status = git("show", PARENT + ":doc/review-trial-status.md").decode()
for anchor in (
    "210affe3ac2931473bead0de839be0de08309e3d",
    "9ed47c6e8999ecaf56031e9b3f524bee6e01507a",
    "3030161007bc393f554cf0c95cf819ed4d81a93c",
    BASE,
):
    assert anchor in status
save(
    "workflow-and-lineage.json",
    {
        "observed_utc": datetime.now(timezone.utc).isoformat(),
        "workflow": workflow,
        "parent": PARENT,
    },
)
save("png-integrity.json", pngs)
save("rendered-comparisons.json", row_evidence)
save(
    "menu.json",
    {
        "counts": filter_counts,
        "options": [{"value": o.get("value"), "label": text(o)} for o in options],
    },
)
save(
    "js-input.json",
    {
        "rows": js_rows,
        "options": [""] + option_values,
        "queries": [r["mam"] for d in inputs.values() for r in d["differences"]]
        + [
            "Koren p. 346",
            "SimTan p. 1432",
            "pointed margin qere",
            "redundant",
            "SimTan",
            "2Chr 20:27",
            "2Sam 13:20",
        ],
    },
)
save(
    "probe-result.json",
    {
        "base": BASE,
        "source": SOURCE,
        "paths": len(changed),
        "rendered_rows": len(rows),
        "shared_rows": sizes[2],
        "single_edition_rows": sizes[1],
        "edition_records": dict(flattened),
        "exact_set_menu_counts": filter_counts,
        "removed_records": len(removed),
        "removed_crop_files": len(removed),
        "preservation": "Every retained record preserves every field except declared notes and original per-edition order; all DOM forms, pages, scans, crops, notes, strands, instances and destinations reconcile.",
        "local_link_attributes": links,
        "external_links_unfetched": sorted(external),
        "pngs": len(pngs),
        "linked_crops": len(all_crops),
        "retained_unreferenced_crops": orphans,
        "owner_address_removal_preserved": True,
        "limits": "Source revisions and owner census/editorial conclusions remain attributed; no external consultation, source acquisition, scan census, browser, manuscript or full-scan collation.",
    },
)
print((OUT / "probe-result.json").read_text(encoding="utf-8"))

"""Frozen public extraction and generated-output differentials; no source claim."""

import copy
from collections import Counter
from dataclasses import replace
import difflib
import json
from pathlib import Path
import subprocess
import types

from hkq_cmn import qere_projection as qp
from mb_cmn import hebrew_accents as ha
from mb_cmn import stress_helper_forms as shf
from mb_cmn import template_names as tn
from render_wt import render_wikitext_handlers as handlers

ROOT = Path.cwd()
BASE = "df516a0078421d9b092b2c8626368d2f23c2fe09"
OUT = ROOT.parent / "evidence"


def old_bytes(name):
    return subprocess.check_output(["git", "show", BASE + ":" + name])


old = types.ModuleType("old_public_renderer")
exec(
    compile(
        old_bytes("py/render_wt/render_wikitext_handlers.py"), "old_renderer", "exec"
    ),
    old.__dict__,
)


def walk(node):
    if isinstance(node, dict):
        if node.get("tmpl_name") in tn.STRESS_HELPER_TMPL_NAMES:
            yield node
        for value in node.values():
            yield from walk(value)
    elif isinstance(node, list):
        for value in node:
            yield from walk(value)


found = [
    node
    for path in sorted((ROOT / "MAM-parsed/plus").glob("*.json"))
    for node in walk(json.loads(path.read_bytes()))
]
assert found
choices = tuple(handlers._STRESS_HELPER_FORMS)
for node in found:
    assert shf.forms(node, "frozen probe") == old._stress_helper_forms(
        old.default_hctx(), node
    )
    for choice in choices:
        ctx = handlers.default_hctx(renopts={"ro_stress_helper": choice})
        assert handlers._handle_stress_helper_word(
            ctx, node
        ) == old._handle_stress_helper_word(ctx, node)


def rejects(call):
    try:
        call()
    except (ValueError, TypeError, AssertionError, KeyError):
        return
    raise AssertionError("required rejection missing")


for choice in (None, "unknown"):
    rejects(
        lambda: handlers._handle_stress_helper_word(
            handlers.default_hctx(renopts={"ro_stress_helper": choice}), found[0]
        )
    )
policy = qp.HOLAM_HE_MAIN_COMPATIBLE_POLICY
for invalid in (
    (),
    ("unknown",),
    (shf.PARAMETER_1, shf.PARAMETER_1),
    [shf.PARAMETER_1],
):
    rejects(lambda: replace(policy, stress_helper_forms=invalid))
for key, val in [("1", []), ("2", []), ("3", ["unexpected"])]:
    bad = copy.deepcopy(found[0])
    bad["tmpl_params"][key] = val
    rejects(lambda: shf.forms(bad, "invalid fixture"))

label_paths = []


def same_except_labels(a, b, path=()):
    assert type(a) is type(b), path
    if isinstance(a, dict):
        assert a.keys() == b.keys(), path
        for key in a:
            same_except_labels(a[key], b[key], (*path, key))
    elif isinstance(a, list):
        assert len(a) == len(b), path
        for i, (v, w) in enumerate(zip(a, b)):
            same_except_labels(v, w, (*path, i))
    elif a != b:
        assert path[-1] in {"target_projection_notice", "projection", "predicate"}, path
        assert isinstance(a, str) and isinstance(b, str)
        label_paths.append(path)


names = [
    "notes.json",
    "structural-populations.json",
    "rare-mark-populations.json",
    "catalogue-comparison.json",
    "next-pass-census.json",
]
for name in names:
    path = "doc/intro-doc-audit/" + name
    same_except_labels(
        json.loads(old_bytes(path)), json.loads((ROOT / path).read_bytes()), (name,)
    )
assert Counter(p[-1] for p in label_paths) == {
    "target_projection_notice": 3905,
    "projection": 3,
    "predicate": 1,
}

name = "gh-pages/MAM-with-doc/foi/foi-kq-simple.json"
a, b = json.loads(old_bytes(name)), json.loads((ROOT / name).read_bytes())
assert len(a) == len(b) == 1213
changed = []
for i, (oldrow, row) in enumerate(zip(a, b)):
    assert {k: v for k, v in oldrow.items() if k not in {"r", "pqere"}} == {
        k: v for k, v in row.items() if k not in {"r", "pqere"}
    }
    if oldrow["r"] == row["r"]:
        continue
    edits = []
    for cell in ("r", "pqere"):
        assert (cell in oldrow) == (cell in row)
        if cell not in row:
            continue
        cell_edits = [
            x
            for x in difflib.SequenceMatcher(
                None, oldrow[cell], row[cell], autojunk=False
            ).get_opcodes()
            if x[0] != "equal"
        ]
        assert all(
            op == "insert" and set(row[cell][j:k]) <= {ha.DEX, ha.Z_OR_TSOR}
            for op, _, __, j, k in cell_edits
        )
        edits.extend(cell_edits)
    changed.append(
        {
            "row": i,
            "bcv_short": row["bcv_short"],
            "inserted_helpers": sum(k - j for _, _, __, j, k in edits),
        }
    )
assert len(changed) == 11 and sum(r["inserted_helpers"] for r in changed) == 15
pages = []
for suffix in ("first", "second"):
    path = f"gh-pages/MAM-with-doc/foi/foi-alef-dual-ml-alef-{suffix}.html"
    a, b = old_bytes(path).decode(), (ROOT / path).read_text()
    edits = [
        x
        for x in difflib.SequenceMatcher(
            None,
            a.splitlines(keepends=True),
            b.splitlines(keepends=True),
            autojunk=False,
        ).get_opcodes()
        if x[0] != "equal"
    ]
    assert len(edits) == 1 and edits[0][0] == "insert"
    _, _, __, j, k = edits[0]
    addition = "".join(b.splitlines(keepends=True)[j:k])
    assert addition.startswith("<p>") and addition.endswith("</p>\n")
    assert "scroll-difference" in addition and "documentation notes" in addition
    pages.append(path)
result = {
    "result": "PASS",
    "stress_templates_all_json_occurrences": len(found),
    "renderer_comparisons": len(found) * len(choices),
    "guards": 9,
    "label_only_counts": dict(Counter(p[-1] for p in label_paths)),
    "foi_rows": 1213,
    "changed_foi_rows": changed,
    "dual_mater_pages_only_one_declared_paragraph_added": pages,
    "limits": "Committed-input mechanism/output preservation only; no manuscript/editorial/font/broad verification.",
}
(OUT / "probe-result.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n"
)
print(json.dumps(result, ensure_ascii=False, indent=2))

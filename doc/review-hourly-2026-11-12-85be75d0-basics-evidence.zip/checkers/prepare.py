"""Prepare an immutable public receipt; retain exact focused diagnostics."""

import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "head"
OUT = ROOT / "evidence"
BASE = "df516a0078421d9b092b2c8626368d2f23c2fe09"
SOURCE = "85be75d0adda39b4e42eff713caada8d3cf08ce4"
PARENT = "ae26935351eee134033f1898f4de9d62186b0a12"
BRANCH = "review-hourly-20261112-85be75d0-basics-receipts"
NAME = "review-hourly-2026-11-12-85be75d0-basics"


def git(*args, repo=TREE):
    return subprocess.check_output(["git", "-C", str(repo), *args])


def dump(d):
    return (json.dumps(d, ensure_ascii=False, indent=2) + "\n").encode()


def sha(b):
    return hashlib.sha256(b).hexdigest()


assert not git("status", "--porcelain=v1", "-z")
assert not git("ls-remote", "origin", "refs/heads/" + BRANCH)
for ref in (SOURCE, PARENT):
    assert (
        git("rev-parse", ref + ":.github/workflows/pages.yml").decode().strip()
        == "18ceb19405424710bda47d9a38c470cc2ed9c385"
    )
    assert b"on:\n  workflow_dispatch:\n" in git(
        "show", ref + ":.github/workflows/pages.yml"
    )
identities = {}
names = list(
    filter(None, git("diff", "--name-only", "-z", BASE, SOURCE).decode().split("\0"))
)
assert len(names) == 24
for side, ref in (("base", BASE), ("head", SOURCE)):
    for path in names:
        exists = (
            subprocess.run(
                ["git", "-C", str(TREE), "cat-file", "-e", ref + ":" + path],
                capture_output=True,
            ).returncode
            == 0
        )
        if not exists:
            identities[side + "/" + path] = {"absent": True}
            continue
        raw = git("show", ref + ":" + path)
        identities[side + "/" + path] = {
            "blob": git("rev-parse", ref + ":" + path).decode().strip(),
            "bytes": len(raw),
            "sha256": sha(raw),
        }
        if path.endswith(".py"):
            ast.parse(raw)
(OUT / "source-identities.json").write_bytes(dump(identities))
(OUT / "endpoint.diff").write_bytes(git("diff", "--binary", BASE, SOURCE))
git("diff", "--check", BASE, SOURCE)
stage_names = [
    "tests",
    "simple",
    "with-doc",
    "foi",
    "near-aleppo",
    "intro-review",
    "black",
    "probes",
    "probes-corrected",
    "historical-audit",
    "historical-structures",
    "historical-catalogues",
    "historical-census-scope",
]
stages = [json.loads((OUT / (n + ".json")).read_bytes()) for n in stage_names]
assert [s["exit"] for s in stages] == [0] * 7 + [1, 0] + [0] * 4
assert all((OUT / (n + ".diff")).read_bytes() == b"" for n in stage_names)
assert "53 passed" in (OUT / "tests.log").read_text()
probe = json.loads((OUT / "probe-result.json").read_bytes())
assert probe["result"] == "PASS"
hist = json.loads((OUT / "historical-inputs.json").read_bytes())
(OUT / "diagnostic-disposition.json").write_bytes(
    dump(
        {
            "first_probe": "Reviewer assertion omitted the pqere column of four trivial-qere rows. Original checker and failed log retained; corrected checker accounts for all 11 rows / 15 cells and passes. No product failure or edit.",
            "scratch_helper": "py/novc_85be75d0_probe.py is ignored by py/.gitignore; removed after retaining both checkers. Every tracked patch is empty.",
            "historical_replay": "Separate committed snapshot uses current code with the original source-pin objects and three historical MAM-simple inputs. Four original generators reproduce nine tracked artifacts exactly; no current-source enumeration or source claim.",
            "final_source_clean": True,
        }
    )
)
payload = {p.name: p.read_bytes() for p in OUT.iterdir() if p.is_file()}
for n in ("run.py", "probe.py", "historical.py", "prepare.py"):
    payload["checkers/" + n] = (ROOT / n).read_bytes()
payload["manifest.json"] = dump(
    {n: {"bytes": len(b), "sha256": sha(b)} for n, b in sorted(payload.items())}
)
receipt_tree = ROOT / "receipts"
subprocess.run(
    [
        "git",
        "-C",
        "/workspace/MAM-basics",
        "worktree",
        "add",
        "-b",
        BRANCH,
        str(receipt_tree),
        PARENT,
    ],
    check=True,
    capture_output=True,
)
archive = receipt_tree / "doc" / (NAME + "-evidence.zip")
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as z:
    for n, b in sorted(payload.items()):
        z.writestr(n, b)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist()))
    for n, item in json.loads(z.read("manifest.json")).items():
        assert len(z.read(n)) == item["bytes"] and sha(z.read(n)) == item["sha256"]
rows = "\n".join(
    f"| `{shlex.join(s['command'][2:])}` | {s['exit']} | {s['seconds']} |"
    for s in stages
)
report = f"""# Bounded Basics screen, November 12, 2026, 21:00 UTC cycle

State: completed 2026-11-12; no consequential introduced defect established

Frozen `{BASE}` -> `{SOURCE}`: five commits / 24 paths. Full endpoint reviewed; receipt lineage `{PARENT}`. Public material only, verified home interpreter, isolated checkouts and sequential commands. No product or editorial repair.

The shared stress-helper extraction preserves all **2,373** current JSON occurrences: its three derived forms equal the former renderer's, and **7,119** explicit renderer comparisons match. Missing/unknown renderer choices and seven invalid policy/template shapes reject. MAM-simple now states its existing parameter-1 choice. FOI fragments and the trivial-qere projection follow the owner's selected MAM-with-doc form. All **1,213** FOI rows remain in order: only **11** rows / **15** display cells gain the intended helper mark, with every other field/codepoint preserved. Each dual-mater page adds only its declared population paragraph; FOI generation confirms the unchanged populations. Note bodies are excluded at every nested depth; scroll-difference-note cases remain included.

The Introduction changes only **3,905** notices, three projection labels and one predicate; all other JSON values, counts, raw nodes and source evidence are equal. Four historical generators were independently replayed with current code and the exact original Git inputs in isolated committed snapshot `{hist['isolated_tested_snapshot']}` (recipe and per-file identities retained), reproducing all nine tracked artifacts byte-for-byte. Current-main broad research enumeration was not run. The inherited unread-ketiv separator issue remains explicitly with Ben and was not introduced or repaired here. C1/S1/S2/L4 are owner-recorded settled choices; owner mega/suite/Windows results remain attributed.

Actual maintained checks: **53 tests pass**, fourteen-file Black passes, and MAM-simple, MAM-with-doc, complete FOI generation, near-Aleppo HTML check (106 files) and Introduction review all pass with **empty tracked diffs**. The first scratch check incorrectly omitted the pqere display column. Its original checker/failure remains preserved; only that small corrected checker repeated, passing. No product changed.

All commands used `/workspace/MAM-basics/.venv/bin/python -B` from the recorded isolated root; historical rows used the separately committed original-input snapshot.

| Actual arguments | Exit | Seconds |
| --- | ---: | ---: |
{rows}

No broad mega/full suite, new source capture, manuscript/editorial adjudication, browser/font/Windows check, baseline acceptance or hbofonts work. Historical source/browser/responsive gaps and pending windows remain open. Overall reviewed-through remains `210affe3ac2931473bead0de839be0de08309e3d`; latest broad-tested remains `cfdbb64ef8fc24e777d4d296efb7fe4ac966346d`. This is bounded coverage only. Local slot/process preflight was clear; cross-machine ownership remains unverified.

Only this isolated receipt branch is published. Source and receipt parent retain manual-dispatch-only Pages; no main/shared integration, dispatch, deployment or schedule change. [Evidence]({archive.name}): {archive.stat().st_size} bytes, SHA-256 `{sha(archive.read_bytes())}`, all payload hashes/sizes and CRC verified. Remote identity/scope and cleanup/release are independently checked at closeout.
"""
(receipt_tree / "doc" / (NAME + ".md")).write_text(
    report, encoding="utf-8", newline="\n"
)
status_path = receipt_tree / "doc/review-trial-status.md"
status = status_path.read_text()
status = status.replace(
    "Latest bounded screen df516a00", "Previous bounded screen df516a00", 1
).replace("Latest focused evidence df516a00", "Previous focused evidence df516a00", 1)
status = status.replace(
    "| Adopted baseline |",
    f"| Latest bounded screen 85be75d0 | `{BASE}` -> `{SOURCE}`; five commits / 24 paths. Shared stress-helper/caller choices, FOI population and historical label-only changes reviewed. No consequential introduced defect or product repair. [Receipt]({NAME}.md). |\n| Latest focused evidence 85be75d0 | 53 tests; fourteen-file Black; five current-output commands; four exact historical-input generators pass. 2,373 extraction / 7,119 renderer comparisons; all 1,213 FOI rows accounted. Empty tracked diffs. One corrected reviewer assertion retained. [Evidence]({archive.name}). |\n| Adopted baseline |",
    1,
)
status += f"\n\n## Bounded screen, 2026-11-12 21:00 UTC cycle, 85be75d0\n\nThe five-commit/24-path window has no consequential introduced defect established. Explicit stress-helper choices and owner-settled C1/S1/S2/L4 are preserved. 53 tests, changed-source Black, five current-output checks and four historical-input generators pass with empty tracked diffs; extraction and all declared output changes independently reconcile. The inherited unread-ketiv separator remains with Ben, and the corrected scratch pqere-column assertion remains evidence. No broad or overall-reviewed advance, source/editorial/font adjudication, deployment or hbofonts work. Every earlier row, pending window, global anchor and immutable receipt is preserved. [Receipt]({NAME}.md), [evidence]({archive.name}).\n"
status_path.write_text(status, encoding="utf-8", newline="\n")
paths = sorted(
    [
        "doc/" + NAME + ".md",
        "doc/" + NAME + "-evidence.zip",
        "doc/review-trial-status.md",
    ]
)
actual = set(
    filter(
        None, git("diff", "--name-only", "-z", repo=receipt_tree).decode().split("\0")
    )
) | set(
    filter(
        None,
        git("ls-files", "--others", "--exclude-standard", "-z", repo=receipt_tree)
        .decode()
        .split("\0"),
    )
)
assert actual == set(paths)
git("diff", "--check", repo=receipt_tree)
(ROOT / "publication-prepared.json").write_bytes(
    dump(
        {
            "branch": BRANCH,
            "parent": PARENT,
            "source": SOURCE,
            "paths": paths,
            "archive": {
                "path": archive.name,
                "bytes": archive.stat().st_size,
                "sha256": sha(archive.read_bytes()),
                "payload_files": len(payload) - 1,
            },
            "prepared_utc": datetime.now(timezone.utc).isoformat(),
        }
    )
)
print("Prepared public receipt/status/evidence only.")

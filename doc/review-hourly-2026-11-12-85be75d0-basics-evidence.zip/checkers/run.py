"""Record one sequential public focused command at the frozen endpoint."""

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "head"
OUT = ROOT / "evidence"
SOURCE = "85be75d0adda39b4e42eff713caada8d3cf08ce4"
commands = {
    "tests": [
        "py/main_test.py",
        "py/tests/test_foi_kq_trivial_types.py",
        "py/tests/test_mb_cmn_kq_special_templates.py",
        "py/tests/test_mpplus_latest_note_schema.py",
        "py/tests/test_qere_ending_search.py",
        "py/tests/test_mam_json_verses.py",
        "py/tests/test_prose_conventions.py",
        "py/tests/test_transliterations.py",
        "py/tests/test_no_machine_paths_in_artifacts.py",
    ],
    "simple": ["py/main_mam_simple.py", "core-only"],
    "with-doc": ["py/main_mam_with_doc.py"],
    "foi": ["py/main_foi_features_of_interest.py", "--single-threaded"],
    "near-aleppo": ["py/main_near_aleppo.py", "--html", "--check"],
    "intro-review": ["py/main_intro_doc_audit.py", "review"],
    "black": ["-m", "black", "--check"],
    "probes": ["py/novc_85be75d0_probe.py"],
    "probes-corrected": ["py/novc_85be75d0_probe.py"],
}
name = sys.argv[1]
target = OUT / (name + ".json")
assert not target.exists()
state = ROOT / "stage.json"
if state.exists():
    assert json.loads(state.read_bytes())["state"] != "running"
assert (
    subprocess.check_output(["git", "-C", str(TREE), "rev-parse", "HEAD"])
    .decode()
    .strip()
    == SOURCE
)
args = commands[name]
if name == "black":
    names = (
        subprocess.check_output(
            [
                "git",
                "-C",
                str(TREE),
                "diff",
                "--name-only",
                "-z",
                "df516a0078421d9b092b2c8626368d2f23c2fe09",
                SOURCE,
            ]
        )
        .decode()
        .split("\0")
    )
    args = [*args, *[p for p in names if p.endswith(".py")]]
env = os.environ.copy()
for key in ["REPO_MAM_PRIVATE_DIR", "REPO_MAM_BASICS_DIR", "REPO_MAM_PARSED_DIR"]:
    env.pop(key, None)
env.update(
    PATH="/workspace/.cloud-setup/bin:" + env["PATH"],
    XDG_CACHE_HOME="/workspace/.cloud-setup/cache",
    UV_PYTHON_INSTALL_DIR="/workspace/.cloud-setup/python",
    PLAYWRIGHT_BROWSERS_PATH="/workspace/.cloud-setup/cache/ms-playwright",
    PYTHONDONTWRITEBYTECODE="1",
    PYTHONUNBUFFERED="1",
)
command = ["/workspace/MAM-basics/.venv/bin/python", "-B", *args]
d = {
    "stage": name,
    "state": "running",
    "source": SOURCE,
    "cwd": str(TREE),
    "command": command,
    "started_utc": datetime.now(timezone.utc).isoformat(),
}
state.write_text(json.dumps(d, indent=2) + "\n")
target.write_text(json.dumps(d, indent=2) + "\n")
print("START", name, flush=True)
start = time.monotonic()
with (OUT / (name + ".log")).open("wb") as log:
    r = subprocess.run(command, cwd=TREE, env=env, stdout=log, stderr=subprocess.STDOUT)
d.update(
    state="completed",
    exit=r.returncode,
    seconds=round(time.monotonic() - start, 6),
    finished_utc=datetime.now(timezone.utc).isoformat(),
)
for label, args in [
    ("status", ["status", "--porcelain=v1", "-z"]),
    ("diff", ["diff", "--binary"]),
]:
    raw = subprocess.check_output(["git", "-C", str(TREE), *args])
    (OUT / (name + ("-status.z" if label == "status" else ".diff"))).write_bytes(raw)
    if label == "status":
        d["clean"] = not raw
state.write_text(json.dumps(d, indent=2) + "\n")
target.write_text(json.dumps(d, indent=2) + "\n")
print(json.dumps(d), flush=True)
sys.exit(r.returncode)

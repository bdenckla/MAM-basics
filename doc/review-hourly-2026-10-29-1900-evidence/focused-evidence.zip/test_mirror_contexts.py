"""Focused source-bound differential checks for context-qualified mirror records."""
from copy import deepcopy
import json
import re
from pathlib import Path
import subprocess

import pytest

from intro_doc_audit import human_review as hr, snapshot
from mb_cmn import paths

ROOT = paths.repo_root()
OLD = 'e18e7b00e33b868e3542fff02c424959e950893a'

def applied():
    return [e for e in hr.read('adjudications.json') if e['application_status'] == 'applied']

def context_entry():
    return next(e for e in applied() if 'context' in e['application'])

def test_all_nine_applications_resolve_against_exact_source_commits():
    sources = hr.Sources()
    for entry in applied():
        result = hr.applied_row(entry, sources)
        assert result[1] == entry['application']['quote']
    assert sources.applications_checked == 9

def test_context_occurrence_partition_independent_of_validator():
    entry = context_entry()
    record = entry['application']
    source = snapshot.text_at(record['mirror_commit'], record['mirror_path'])
    contexts = [record['context']] + [x['context'] for x in record['other_occurrences']]
    ranges = []
    for context in contexts:
        matches = list(re.finditer('(?=' + re.escape(context) + ')', source))
        assert len(matches) == 1
        ranges.append((matches[0].start(), matches[0].start() + len(context)))
    ranges.sort()
    assert all(a[1] <= b[0] for a,b in zip(ranges, ranges[1:]))
    for needle in [entry['current']['quote'], record['quote']]:
        found = list(re.finditer('(?=' + re.escape(needle) + ')', source))
        assert found
        for match in found:
            assert sum(start <= match.start() and match.start() + len(needle) <= end for start,end in ranges) == 1
    assert all(isinstance(x['reason'], str) and x['reason'].strip() for x in record['other_occurrences'])

@pytest.mark.parametrize('fault', ['strict', 'orphan_other', 'no_others', 'missing_reason', 'extra_key', 'missing_context', 'duplicate_context', 'overlap', 'wrong_quote'])
def test_actual_context_record_corruptions_reject(fault):
    entry = deepcopy(context_entry())
    r = entry['application']
    if fault == 'strict':
        del r['context']; del r['other_occurrences']
    elif fault == 'orphan_other':
        del r['context']
    elif fault == 'no_others':
        r['other_occurrences'] = []
    elif fault == 'missing_reason':
        del r['other_occurrences'][0]['reason']
    elif fault == 'extra_key':
        r['other_occurrences'][0]['extra'] = True
    elif fault == 'missing_context':
        r['other_occurrences'][0]['context'] += ' NOT IN SOURCE'
    elif fault == 'duplicate_context':
        r['other_occurrences'].append(deepcopy(r['other_occurrences'][0]))
    elif fault == 'overlap':
        r['other_occurrences'].append({'context': r['context'][1:], 'reason': 'Nested context is invalid.'})
    else:
        r['quote'] += '!'
    with pytest.raises(ValueError):
        hr.applied_row(entry, hr.Sources())

def test_new_or_old_occurrences_outside_declared_contexts_reject():
    e = context_entry(); r = e['application']
    source = snapshot.text_at(r['mirror_commit'], r['mirror_path'])
    for needle in [r['quote'], e['current']['quote']]:
        with pytest.raises(ValueError, match='Every applied or old text'):
            hr.check_mirror_occurrences(r, e['current']['quote'], [source + '\n' + needle])

def test_original_fourteen_decisions_and_old_five_applications_preserved():
    old = json.loads(subprocess.check_output(['git', 'show', OLD + ':doc/intro-doc-audit/adjudications.json'], cwd=ROOT))
    new = hr.read('adjudications.json')
    assert len(old) == len(new) == 14
    for a,b in zip(old,new):
        for key in ['id', 'authority', 'source_base_commit', 'current', 'changes', 'proposed_quotation']:
            assert a.get(key) == b.get(key), (a['id'], key)
        if a['application_status'] == 'applied':
            assert a['application'] == b['application']
    for name in ['source-pin.json', 'claims.json', 'notes.json']:
        assert subprocess.check_output(['git', 'show', OLD + ':doc/intro-doc-audit/' + name], cwd=ROOT) == (ROOT / 'doc/intro-doc-audit' / name).read_bytes()

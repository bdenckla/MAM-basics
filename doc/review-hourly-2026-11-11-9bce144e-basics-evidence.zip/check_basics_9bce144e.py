"""Independent frozen FOI DOM/data/link and index-coverage comparison."""

import ast
from collections import Counter
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote, urlsplit

BASE = "a5b89a8df9eb0ce6fd821e91c7b002f0c117c8d2"
HEAD = "9bce144ecc823856cbb0fe417b87dbc8ef474447"
OUT = Path("/workspace/scratch/basics-9bce144e-artifacts")
ROOT = Path.cwd()


def git(*args):
    return subprocess.check_output(["git", *args])


def text(ref, path):
    return git("show", f"{ref}:{path}").decode("utf-8")


class DOM(HTMLParser):
    def __init__(self, page, remove_arrow=False):
        super().__init__()
        self.events, self.hrefs, self.ids = [], [], []
        self.remove_arrow = remove_arrow
        self.feed(page)

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if "id" in a:
            self.ids.append(a["id"])
        if tag == "a" and "href" in a:
            self.hrefs.append(a["href"])
        if (
            self.remove_arrow
            and tag == "link"
            and a.get("href") == "../../near-aleppo/link-presentation.css"
        ):
            return
        if self.remove_arrow:
            attrs = [(k, v) for k, v in attrs if k != "data-na-link"]
        self.events.append(("start", tag, sorted(attrs)))

    def handle_endtag(self, tag):
        self.events.append(("end", tag))

    def handle_data(self, data):
        value = " ".join(data.split())
        if value:
            self.events.append(("text", value))


paths = git("diff", "--name-only", "-z", BASE, HEAD).decode().strip("\0").split("\0")
assert len(paths) == 50
pages = [p for p in paths if p.endswith(".html")]
assert len(pages) == 27
preserved = []
link_count = 0
cache = {}
for path in pages:
    old, new = text(BASE, path), text(HEAD, path)
    a, b = DOM(old), DOM(new, True)
    assert a.hrefs == b.hrefs, path
    assert a.ids == b.ids, path
    assert re.findall(r"[\u0590-\u05ff]+", old) == re.findall(
        r"[\u0590-\u05ff]+", new
    ), path
    for pattern in [r"<script\b.*?</script>", r"<style\b.*?</style>", r"<img\b[^>]*>"]:
        assert re.findall(pattern, old, re.S) == re.findall(pattern, new, re.S), (
            path,
            pattern,
        )
    assert (
        new.count(
            '<link rel="stylesheet" href="../../near-aleppo/link-presentation.css">'
        )
        == 1
    )
    if not path.endswith("/index.html"):
        assert a.events == b.events, path
        preserved.append(path)
    for href in b.hrefs:
        parsed = urlsplit(href)
        if parsed.scheme or parsed.netloc:
            continue
        target = (
            (ROOT / path).parent / unquote(parsed.path) if parsed.path else ROOT / path
        )
        target = target.resolve()
        assert target.is_relative_to(ROOT / "gh-pages") and target.is_file(), (
            path,
            href,
        )
        if parsed.fragment and target.suffix == ".html":
            if target not in cache:
                content = target.read_text(encoding="utf-8")
                cache[target] = set(re.findall(r'\b(?:id|name)="([^"]+)"', content))
            assert unquote(parsed.fragment) in cache[target], (path, href)
        link_count += 1

inventory = []
for item in git("ls-tree", "-r", "-z", HEAD, "gh-pages/MAM-with-doc/foi").split(b"\0"):
    if not item:
        continue
    meta, name = item.decode().split("\t", 1)
    if name.endswith(".json"):
        assert (
            git("rev-parse", BASE + ":" + name).strip() == meta.split()[2].encode()
        ), name
        inventory.append(name)

modules = [p for p in paths if p.endswith(".py")]
for path in modules:
    if path.endswith("foi_finals.py"):
        continue
    trees = [ast.parse(text(ref, path)) for ref in [BASE, HEAD]]
    for tree in trees:
        tree.body = [
            n
            for n in tree.body
            if not (
                isinstance(n, ast.Assign)
                and any(
                    isinstance(t, ast.Name) and t.id.startswith("INDEX_DESCRIPTION")
                    for t in n.targets
                )
            )
        ]
        if path.endswith("sec_yyy_explanations.py"):
            tree.body = [
                n
                for n in tree.body
                if not (
                    isinstance(n, ast.ImportFrom)
                    and n.module in ["accgram.almost_errors_html_shared", "mb_misc"]
                )
            ]
    assert ast.dump(trees[0]) == ast.dump(trees[1]), path

stems = sorted(Path(p).stem.removeprefix("foi-") for p in preserved)
tree = ast.parse(text(HEAD, "py/foi/foi_finals.py"))
description_node = next(
    n.value
    for n in tree.body
    if isinstance(n, ast.Assign)
    and any(
        isinstance(t, ast.Name) and t.id == "_INDEX_DESCRIPTIONS" for t in n.targets
    )
)
keys = [ast.literal_eval(k) for k in description_node.keys]
assert len(stems) == len(keys) == 26 and set(stems) == set(keys)
guard = next(
    n
    for n in tree.body
    if isinstance(n, ast.FunctionDef) and n.name == "_check_index_descriptions"
)
namespace = {"_INDEX_DESCRIPTIONS": dict.fromkeys(keys)}
exec(
    compile(ast.Module(body=[guard], type_ignores=[]), "frozen-coverage-guard", "exec"),
    namespace,
)
outspecs = [(s, ()) for s in stems]
namespace["_check_index_descriptions"](outspecs)
guard_errors = []
for bad in [outspecs[:-1], outspecs + [("unknown-stem", ())]]:
    try:
        namespace["_check_index_descriptions"](bad)
    except ValueError as error:
        guard_errors.append(str(error))
    else:
        raise AssertionError("Index coverage guard failed")
index = text(HEAD, "gh-pages/MAM-with-doc/foi/index.html")
assert len(re.findall(r"<li>", index)) == 26
for stem in stems:
    # Constant-to-HTML equality is verified by the maintained exact regeneration;
    # this independently checks a nonempty readable description at each item.
    item = re.search(
        r'<li><a href="foi-' + re.escape(stem) + r'\.html"[^>]*>.*?</li>', index, re.S
    )[0]
    assert " — " in item and re.sub(r"<[^>]+>", "", item).split(" — ", 1)[1].strip()
result = dict(
    result="PASS",
    base=BASE,
    head=HEAD,
    changed_paths=len(paths),
    python_modules=len(modules),
    html_pages=len(pages),
    preserved_page_DOMs=len(preserved),
    unchanged_json_blobs=len(inventory),
    checked_local_link_occurrences=link_count,
    index_descriptions=len(stems),
    guard_errors=guard_errors,
    finders="All 21 modules outside foi_finals are AST-identical after only new INDEX_DESCRIPTION assignments and the two declared descriptor-only imports are excluded.",
    preservation="All non-index DOM events match after excluding the new shared sheet/data-na-link attributes and folding serializer whitespace; Hebrew runs, script/style/image bytes, IDs and href sequences match on all 27 pages.",
    limits="Committed data/output/link consistency; no new Hebrew/source/editorial adjudication, visual browser check or broad-suite claim.",
)
(OUT / "independent-result.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
)
print(json.dumps(result, ensure_ascii=False, indent=2))

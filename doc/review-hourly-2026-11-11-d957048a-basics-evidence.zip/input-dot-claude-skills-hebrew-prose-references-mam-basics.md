# MAM-basics-specific accentuation prose

Read this reference when prose about Hebrew accentuation is written or edited in MAM-basics.
General terminology and rendered-page rules remain in the other skill references rather than
being repeated here.

## The Yeivin ITM adaptation preserves its plural conventions

Ben's decision, 2026-10-13: the entire Yeivin ITM adaptation keeps its decisions about plurals
of transliterated words, including Ben's freely adapted prose and footnotes. Do not apply the
general preference for "meteg marks" or "alef letters" to that adaptation.

The authoritative adaptation is `py/yeivin_itm/`, with its approved data and documentation in
`Yeivin-ITM/`. `py/main_yeivin_itm.py render` writes `gh-pages/yeivin-itm/`, whose landing page is
`yeivin_itm.html`. All of these are within the exception. Literal quotations elsewhere
also preserve their wording; authored explanation outside this scope follows the general rule.
`doc/hebrew-name-plurals.md` describes the rendered-page lint and its scoped exceptions.

## Notes on aliyot keeps its established technical plurals

Ben's decision, 2026-10-13: `gh-pages/MAM-with-doc/misc/notes_on_aliyot.html` keeps
`aliyot` throughout, including its title. Ben permits it in the document's already highly
technical context and also rejected the widespread change to it. Restore its existing wording
rather than rephrasing surrounding prose during a terminology sweep. The exception is for
`aliyot` on this page, not for all plurals on the page or for its use on other pages.

Ben's later clarification that day chooses `parashot`, rather than `parashiyot`, for our own
prose, including this page. Quotations and adaptations keep whichever spelling they use.

`py/author_misc/notes_on_aliyot.py` uses the explicit `$technical_aliyot` substitution in
`py/mb_author/author.py`; ordinary `$aliyot` uses an English noun elsewhere. The established
`$parashiyot` placeholder key now renders `parashot`. A prose sweep should keep editorial
changes bounded, especially in an explicitly technical document.

## The post-stress-meteg pages say plain "word"

Ben's decision, 2026-09-08: the main post-stress-meteg page and its subdocuments, eight on that
date, are an exception to the skill's “Never a loose word” rule. Since 2026-11-11 they have been in
`gh-pages/post-stress-meteg/`. The main page defines both “word” and “atom” in its second
expository paragraph, and the opening sentence already uses “word”. Plain “word” is therefore the
declared term in visible prose, headings, tooltips, and alt text on every page in that folder.
Never replace it with “chanted word”. The folder also holds the post-silluq case pages that
`post-stress-meteg-post-silluq.html` links, added on 2026-09-22 after that decision; their titles,
headings, and alt text say plain “word” in the same sense.

`py/tests/test_post_stress_meteg_plain_word.py` enforces the exception: “chanted” must not appear
in the rendered pages. The source identifiers `census_chanted_word_summary`,
`chanted_word_difference`, and `_case_chanted_word_cell` retain the survey's vocabulary; the
exception governs reader-facing prose rather than identifiers and docstrings.

## Accgram rendered prose

Before writing or editing prose on an accgram page, read
`py/accgram/printed_decalogue_strands.py`'s module docstring as well as
`references/rendered-prose.md`. The docstring's SCOPE paragraph distinguishes trio-only rules
from repository-wide rules. Keep the docstring's established strand names, signal words,
single-sourced romanizations, terminology, and sentence shape.

Some accgram docstrings and comments deliberately retain historical sibling spellings. A path
written as `../masorah-books/...` now resolves conceptually to
`../MAM-private/masorah-books/...`; a path written as `../al-hatorah/...` now resolves
conceptually to `../MAM-private/al-hatorah/...`. Ben chose on 2026-08-10 to document the eight
stale `../masorah-books/...` citations rather than edit them. His 2026-08-11 al-hatorah decision
named seven sites, six historical accgram citations and one test site; a re-measurement on
2026-09-12 found an eighth, `post_stress_meteg.py:15`, written after the decision, and only three
of the eight literally used `../al-hatorah/...`. On 2026-10-01 `9a67d51b` rewrote the docstrings
and the one comment that held the other five, when the Breuer and post-stress-meteg analyses and the final-stress
test moved to the public Phonetic MAM release. The three that remain are
`chanted_word_accents_inventory.py`'s `../al-hatorah/py/itm/`, `final_stress.py`'s
`../al-hatorah/py/aht_phon` and `maqaf_nonfinal_accents.py`'s
`../al-hatorah/py/aht_phon/stress.py`; the adaptation the first names is now MAM-basics'
`py/yeivin_itm/content/`. Those historical source citations, and the eight masorah-books ones,
remain as written. For live source research, use the current MAM-private paths in
`references/sources-and-corpora.md` and search the full Yeivin OCR before concluding that
Yeivin is silent.

"""Exact committed-codepoint and tooltip preservation, without browser/font QA."""

from html.parser import HTMLParser
import hashlib
import json
from pathlib import Path
import re
import subprocess

BASE = "9bce144ecc823856cbb0fe417b87dbc8ef474447"
HEAD = "d957048a20f671fbadea37325c91dd9c9bfe4ee9"
OUT = Path("/workspace/scratch/basics-d957048a-artifacts")


def git(*args):
    return subprocess.check_output(["git", *args])


def norm(s):
    return " ".join(s.split())


paths = git("diff", "--name-only", "-z", BASE, HEAD).decode().strip("\0").split("\0")
assert len(paths) == 3
identities, results = {}, {}
for filename, count in [("index.html", 55), ("index-rejects.html", 15)]:
    name = "gh-pages/wlc/420422/" + filename
    pages = []
    for side, ref in [("base", BASE), ("head", HEAD)]:
        raw = git("show", ref + ":" + name)
        blob = git("rev-parse", ref + ":" + name).decode().strip()
        assert (
            hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
            == blob
        )
        identities[side + "/" + filename] = dict(
            blob=blob, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()
        )
        (OUT / (side + "-" + filename)).write_bytes(raw)
        pages.append(raw.decode("utf-8"))
    old, new = pages
    marker = '<table id="table-of-abbreviations">'
    assert old.split(marker)[0] == new.split(marker)[0]
    a, b = [p.split(marker, 1)[1].split("</table>", 1) for p in pages]
    assert a[1] == b[1]
    span = r'<span lang="hbo">([^<]*)</span>'
    assert norm(a[0]) == norm(re.sub(span, r"\1", b[0]))
    assert len(re.findall(span, b[0])) == 14
    rows = re.findall(
        r'<tr><td class="nowrap">(.*?)</td><td>(.*?)</td></tr>', b[0], re.S
    )
    assert len(rows) == 12
    wrapped = []
    for abbreviation, definition in rows:
        forms = re.findall(span, definition)
        if abbreviation in [
            "-dms",
            "+dms",
            "-rfh",
            "-pashta",
            "+rev",
            "-shoḥ",
            "+shoḥ",
        ]:
            assert len(forms) == 2
            wrapped.append(abbreviation)
        else:
            assert not forms
    assert len(wrapped) == 7
    assert re.findall(r"[\u0590-\u05ff]+", old) == re.findall(r"[\u0590-\u05ff]+", new)
    titles = re.findall(r'\btitle="([^"]*)"', old)
    assert titles == re.findall(r'\btitle="([^"]*)"', new)
    assert all("<" not in title and ">" not in title for title in titles)
    for pattern in [
        r'href="[^"]*"',
        r'\bid="[^"]*"',
        r"<img\b[^>]*>",
        r"<style\b.*?</style>",
        r"<script\b.*?</script>",
    ]:
        assert re.findall(pattern, old, re.S) == re.findall(pattern, new, re.S), pattern
    main_table = re.findall(r"<table.*?</table>", new, re.S)[0]
    assert len(re.findall(r"<tr>", main_table)) == count + 1
    results[filename] = dict(
        record_rows=count,
        wrapped_pairs=len(wrapped),
        new_spans=14,
        unchanged_tooltip_attributes=len(titles),
        wrapped_abbreviations=wrapped,
        punctuation_only_examples="+psq and +mqf retain the surrounding font; the three plain definitions remain unchanged.",
    )
assert git("rev-parse", BASE + ":gh-pages/wlc/style.css") == git(
    "rev-parse", HEAD + ":gh-pages/wlc/style.css"
)
result = dict(
    result="PASS",
    base=BASE,
    head=HEAD,
    paths=paths,
    identities=identities,
    pages=results,
    preservation="Everything outside both abbreviation tables is byte-identical. Removing only 14 declared span wrappers per table reconstructs base after folding serialization whitespace. All Hebrew runs, tooltip attributes, links, IDs, images, scripts and styles are exact.",
    limits="Committed source/output consistency only; Ben's compared-form font decision is preserved. No visual browser/font QA, normalization, source/editorial reinterpretation, full suite or historic coverage advance.",
)
(OUT / "independent-result.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
)
print(
    json.dumps(
        {k: v for k, v in result.items() if k != "identities"},
        ensure_ascii=False,
        indent=2,
    )
)

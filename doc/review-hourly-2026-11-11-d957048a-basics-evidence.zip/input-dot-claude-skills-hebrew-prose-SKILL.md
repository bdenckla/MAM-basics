---
name: hebrew-prose
description: Ben's house rules for writing, editing, or reviewing any prose about Hebrew accentuation or cantillation, including rendered pages, docstrings, comments, commit messages, issue text, and chat. Use whenever text discusses accents, cantillation, maqaf, meteg, paseq or legarmeh, strands, Decalogue readings, or the prose and poetic systems. Also use for manuscript-versus-transcription prose beyond accentuation, for any prose that names a manuscript page or folio, such as "page F159A", and for any prose that names the parts of a MAM documentation note, which are doc-parts or clauses, never lines.
---

# Hebrew accentuation prose

This skill is canonical. A repository may add a narrowly scoped exception; when it does, read
the repository-specific reference before writing. Load only the references needed for the task.

## Checklist that applies to every accentuation task

1. **Name the unit.** An **atom** is one written form between spaces or maqaf marks. A **chanted
   word** is one atom or a whole maqaf compound, the unit on which cantillation operates. Do
   not leave a loose "word" for the reader to resolve, and name a compound whole rather than
   naming a bare half.
2. **Use one scale of separating force.** Disjunctives, conjunctives, then maqaf. Maqaf has the
   weakest *separating* force and binds most tightly. Count a maqaf difference once and state it
   as an exchange with both markings named. Do not create a separate "word division" ledger.
3. **Distinguish grammar from code points.** The paseq code point (U+05C0) can be narrow-sense
   **paseq** or **legarmeh**. U+05BD is **silluq** only on the stressed syllable of the verse's
   final word before sof pasuq; elsewhere it is **meteg**. A maqaf-joined atom is not verse-final.
   A glyph is a shape that a font or a page draws; text and a text layer hold code points, and a
   regular expression matches them.
4. **Write prose and poetic verses, never prose and poetic books.** Psalms, Job, and Proverbs
   contain both systems. Identify the system of the verse being discussed.
5. **Describe structure, not transformation.** An accent does not turn into another accent,
   acquire a mark, replace a neighboring accent, or govern deliberately. State what the text,
   atom, chanted word, syllable, or tradition **has**. Preserve real historical change only when
   the source and evidence establish it.
6. **Name the source relation precisely.** An edition, manuscript, codex, and strand are not
   interchangeable. Do not call any of them a "witness" unless the task is expressly about
   textual criticism. A grammatical claim takes MAM as its corpus unless another corpus is
   explicitly named; WLC is a comparison text, not a substitute corpus.
7. **Use the established names.** Write "the Simanim Tiqqun", not bare "Simanim". On the
   printed-Decalogue pages, keep the strand names תחתון and עליון in Hebrew letters in
   reader-facing prose; `references/rendered-prose.md` gives that rule's scope and its exempt
   registers. Elsewhere, keep the strand names a page or data product already uses, such as
   MAM-simple's `cant-alef` and `cant-bet` strands. Distinguish narrow-sense meteg from
   secondary stress, and do not infer vowels from secondary-stress placement. Treat
   stress-helper templates as choices among strands, not as a license to traverse all
   branches. Reserve `MUDGASH` and `mudgash` for literal Unicode code-point names.
   Never confuse a **shuruq**, a vav plus its shuruq dot, with the **shuruq dot** alone,
   which is not any kind of vowel; keep a **ḥolam male** and its **ḥolam male dot** apart in
   the same way.
8. **Show the Hebrew form in Unicode.** Do not replace the form with a transliteration or an
   English gloss. In mixed-direction prose, the first strong character of a line must be Latin;
   give Hebrew an English runway or its own RTL table cell. A section sign and a backtick are
   neutral; an ASCII digit has a weak directional type. None is a strong character.
9. **Give the pointed-Hebrew font only to pointed Hebrew.** On a rendered page, `lang="hbo"`
   sets Taamey D at 140% so that points and accents are legible. Hebrew with no point or
   accent, such as a vowel's or accent's name in an English sentence, a template name, a strand
   name or a table's label, keeps the surrounding font: isolate it for direction with a `<bdi>`
   that has no `lang`. In MAM-basics that is `author.unpointed`; `author.hbo` raises on
   unpointed Hebrew, and `author.std_table` puts only pointed cells in `lang="hbo"`. Ben has
   asked for this on 2026-07-28, 2026-10-26 and 2026-11-08; `references/rendered-prose.md`,
   "Unpointed Hebrew keeps the surrounding font", gives his words and the one exception.

## Load only the references the task needs

- **General writing rules, corpus choice, and the checklist's reasoning:** read
  `references/core-rules.md`.
- **A precise term, transliteration, name, or exemption:** read `references/terminology.md`.
- **A manuscript page or folio locator, such as "page F159A":** read `references/terminology.md`,
  “A manuscript page is named as a page, never as "folio 57a"”.
- **The parts of a MAM documentation note that the `ש` template separates:** call them doc-parts
  or clauses, never lines, and paragraphs only where their `<p>` formatting is the subject; read
  `references/terminology.md`, “A doc-note's parts are doc-parts or clauses, never lines”.
- **Rendered HTML, tables, captions, headings, tooltips, or alt text:** read
  `references/rendered-prose.md`. Every table cell holding Hebrew is `dir="rtl"` unless the
  whole table already is.
- **MAM-basics prose:** also read `references/mam-basics.md`. In particular, the pages in
  `gh-pages/post-stress-meteg/` deliberately use plain "word" because their
  introduction fixes the meaning; never change those pages to "chanted word".
- **Manuscript-versus-transcription prose, claims about corpora, Yeivin, Breuer, CTR, manuscript practice, or the prose-poetic
  asymmetry:** read `references/sources-and-corpora.md`. Search the full local OCR, not only
  Ben's partial Yeivin adaptation, before saying that a source is silent.
- **Counts, regeneration, generators, Black, or Unicode mechanics:** read
  `references/verifying.md`. Regenerate the tracked artifact, read its diff, and read every
  reported number back from the generated file.

## Claude cloud applicability

The checklist and repository exceptions apply in cloud sessions. Source research and
regeneration require their actual inputs: private OCR, account-local source books and private
surveys do not arrive with a single MAM-basics checkout. Read a supplied source before making
its claim; report unavailable source evidence instead of inferring the source's reading.
Machine paths and dated measurements in the references identify their original evidence,
rather than a resource that must exist in the cloud.

Run active command recipes from the verified checkout with its own environment. Windows
full clones use `.venv/Scripts/python.exe`; a Linux cloud checkout uses `.venv/bin/python`
after hydration against tracked requirements and constraints. A linked worktree uses its home
clone's interpreter by absolute path. Windows verification does not prove Linux dependency
compatibility. Follow the repository's declared cloud skips and distinguish their limited
verification from a generator requiring unavailable private inputs.

## Canonical copy

This skill is canonical at `MAM-basics/dot-claude/skills/hebrew-prose/` and is shared with
Codex through `dot-claude/shared-skills.txt`. Change the canonical copy first, then use the
deployment procedure in `dot-claude/README.md`.

"""Reconcile every source comparison against combined DOM without renderer imports."""

from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import unquote, urlsplit

from lxml import html
from PIL import Image

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "head"
OUT = ROOT / "evidence"
BASE = "4c0084f405351e36eb590180fa6a7f4a4f1ee063"
SOURCE = "7173440e9a2cf932edc290a4ff17affde54a3072"
PARENT = "7bd454e13b252e2df93099909c1e33a0f4205611"
sys.path.insert(0, str(TREE / "py"))  # Disposable harness only.
from mb_cmn import uni_denorm


def git(*args):
    return subprocess.check_output(["git", "-C", str(TREE), *args])


def save(name, value):
    (OUT / name).write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def text(node):
    return " ".join(node.text_content().split())


cache = {}


def page(path):
    path = path.resolve()
    if path not in cache:
        cache[path] = html.fromstring(path.read_bytes())
    return cache[path]


def qere(node):
    node = deepcopy(node)
    for ketiv in node.xpath('.//span[@class="mam-kq-k"]'):
        ketiv.drop_tree()
    return text(node).replace("[", "").replace("]", "")


def ident(r):
    return tuple(
        r.get(k)
        for k in (
            "book",
            "chapter",
            "verse",
            "strand",
            "instance",
            "mam",
            "printed",
            "verse_href",
            "category",
        )
    )


assert git("rev-parse", "HEAD").decode().strip() == SOURCE
assert not git("status", "--porcelain=v1", "-z")
changed = [
    p for p in git("diff", "--name-only", "-z", BASE, SOURCE).decode().split("\0") if p
]
assert len(changed) == 11
identities = {}
for path in changed:
    deleted = not (TREE / path).exists()
    raw = git("show", (BASE if deleted else SOURCE) + ":" + path)
    if not deleted:
        assert (TREE / path).read_bytes() == raw
    identities[path] = {
        "deleted": deleted,
        "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
    }
save("identities.json", identities)
(OUT / "endpoint.diff").write_bytes(git("diff", BASE, SOURCE))
(OUT / "commits.txt").write_bytes(git("log", "--format=fuller", BASE + ".." + SOURCE))
git("diff", "--check", BASE, SOURCE)
inputs = {}
changes = {}
groups = {}
all_crops = set()
for edition in ("koren", "simanim-tanakh"):
    path = "in/stress-helpers/" + edition + ".json"
    data = json.loads((TREE / path).read_bytes())
    old = json.loads(git("show", BASE + ":" + path))
    assert data["edition_credit"] == old["edition_credit"]
    assert len(data["differences"]) == len(old["differences"])
    deltas = []
    for before, after in zip(old["differences"], data["differences"]):
        assert {k: v for k, v in before.items() if k != "notes"} == {
            k: v for k, v in after.items() if k != "notes"
        }
        if before.get("notes") != after.get("notes"):
            deltas.append(
                {
                    "identity": list(ident(after)),
                    "before": before.get("notes"),
                    "after": after.get("notes"),
                }
            )
        assert edition not in groups.setdefault(ident(after), {})
        groups[ident(after)][edition] = after
        all_crops.update(after["crops"])
    inputs[edition] = data
    changes[edition] = deltas
save("note-deltas.json", changes)
target = TREE / "gh-pages/stress-helpers/index.html"
doc = page(target)
rows = doc.xpath('//table[@id="observations"]/tbody/tr')
assert len(rows) == len(groups) == 37
assert Counter(len(s) for s in groups.values()) == {1: 22, 2: 15}
assert [text(n) for n in doc.xpath('//table[@id="observations"]/thead/tr/th')] == [
    "",
    "Verse",
    "Difference",
    "Scan crop",
]
ids = doc.xpath("//*[@id]/@id")
assert len(ids) == len(set(ids))
assert doc.xpath('//*[@id="edition"]/option/@value') == ["", "koren", "simanim-tanakh"]
assert doc.xpath('//*[@id="hebrew-size"]/@value') == ["30"]
assert len(doc.xpath('//*[@class="scan" and @hidden]')) == 38
remaining = dict(groups)
flattened = Counter()
row_evidence = []
book_order = "Genesis Exodus Levit Numbers Deuter Joshua Judges 1Samuel 2Samuel 1Kings 2Kings Isaiah Jeremiah Ezekiel Hosea Joel Amos Obadiah Jonah Micah Nahum Habakkuk Zephaniah Haggai Zechariah Malachi Psalms Proverbs Job SongOfSongs Ruth Lamentations Ecclesiastes Esther Daniel Ezra Nehemiah 1Chronicles 2Chronicles".split()
order = []
for row in rows:
    forms = row.xpath('.//span[@class="hebrew"]/text()')
    hrefs = row.xpath("./th/a/@href")
    candidates = [
        (k, s)
        for k, s in remaining.items()
        if list(k[5:7]) == forms and k[7] in hrefs and k[8] == row.get("data-outcome")
    ]
    assert len(candidates) == 1, candidates
    k, sources = candidates[0]
    remaining.pop(k)
    record = next(iter(sources.values()))
    assert row.get("data-editions").split() == list(sources)
    assert len(row) == 4 and row[0].get("dir") == "rtl"
    assert row.xpath('./th/span[@class="source"]/@title') == [
        r["scan"] for r in sources.values()
    ]
    expected_pages = [
        (
            ("Koren " if e == "koren" else "SimTan ") + "p. " + str(r["page"])
            if len(sources) > 1
            else "p. " + str(r["page"])
        )
        for e, r in sources.items()
    ]
    assert [text(n) for n in row.xpath('./th/span[@class="source"]')] == expected_pages
    assert row.xpath(".//img/@src") == [c for r in sources.values() for c in r["crops"]]
    assert row.xpath('./td[@class="scan"]/a/@href') == row.xpath(".//img/@src")
    if record.get("instance"):
        assert "Instance " + str(record["instance"]) in text(row[1])
    assert row.xpath("./th/bdi/text()") == (
        [record["strand"]] if record.get("strand") else []
    )
    expected_notes = []
    for e, r in sources.items():
        flattened[e] += 1
        assert all(uni_denorm.has_std_mark_order(r[f]) for f in ("mam", "printed"))
        for note in r.get("notes", []):
            n = note["text"] + (
                " " + note.get("label", "MAM doc-note") if note.get("href") else ""
            )
            if n not in expected_notes:
                expected_notes.append(n)
    assert [text(n) for n in row.xpath('./td[@class="difference"]/p')] == expected_notes
    expected_note_links = []
    for r in sources.values():
        for n in r.get("notes", []):
            if n.get("href") and n["href"] not in expected_note_links:
                expected_note_links.append(n["href"])
    assert (
        list(dict.fromkeys(row.xpath('./td[@class="difference"]/p/a/@href')))
        == expected_note_links
    )
    loc = urlsplit(record["verse_href"])
    anchor = page(target.parent / unquote(loc.path)).xpath(
        "//*[@id=$ident]", ident=loc.fragment
    )
    assert len(anchor) == 1
    assert " ".join(record["mam"].split()) in qere(anchor[0].getparent())
    order.append((book_order.index(record["book"]), record["chapter"], record["verse"]))
    row_evidence.append(
        {
            "identity": list(k),
            "editions": list(sources),
            "pages": expected_pages,
            "crops": row.xpath(".//img/@src"),
            "notes": expected_notes,
        }
    )
assert not remaining
assert order == sorted(order)
assert flattened == {"koren": 34, "simanim-tanakh": 18}
for e, d in inputs.items():
    assert Counter(r["category"] for r in d["differences"])["redundant-edition"] == (
        11 if e == "koren" else 13
    )
    assert d["edition_credit"] in text(doc)
    for r in d["differences"]:
        if r["category"] == "redundant-edition":
            assert r["mam"].count("\N{HEBREW ACCENT PASHTA}") == 1
            assert r["printed"].count("\N{HEBREW ACCENT PASHTA}") == 2
            assert re.search(
                "[\u05d0-\u05ea][\u0591-\u05c9]*\N{HEBREW POINT SHEVA}[\u0591-\u05c9]*[\u05d0-\u05ea][\u0591-\u05c9]*\N{HEBREW POINT SHEVA}[\u0591-\u05c9]*$",
                r["mam"],
            )
common = json.loads((TREE / "in/stress-helpers/common.json").read_bytes())
assert [text(n) for n in doc.xpath("//main/p")[:4]] == common["coverage"] + [
    common["source_notes"][0]["text"] + " " + common["source_notes"][0]["label"]
]
links = 0
external = set()
for node in doc.xpath("//*[@href or @src]"):
    for attr in ("href", "src"):
        value = node.get(attr)
        if value is None:
            continue
        loc = urlsplit(value)
        if loc.scheme or loc.netloc:
            external.add(value)
            continue
        dest = (target.parent / unquote(loc.path)).resolve() if loc.path else target
        assert dest.is_relative_to(TREE / "gh-pages") and dest.is_file(), value
        if loc.fragment:
            assert page(dest).xpath(
                "//*[@id=$ident or @name=$ident]", ident=unquote(loc.fragment)
            ), value
        links += 1
pngs = {}
for p in sorted((target.parent / "img").glob("*.png")):
    with Image.open(p) as img:
        assert img.format == "PNG"
        pngs["img/" + p.name] = {
            "width": img.width,
            "height": img.height,
            "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
        }
        img.verify()
assert len(pngs) == 56 and len(all_crops) == 52
orphans = sorted(pngs.keys() - all_crops)
assert len(orphans) == 4
assert (
    not (target.parent / "koren.html").exists()
    and not (target.parent / "simanim-tanakh.html").exists()
)
home = page(TREE / "gh-pages/index.html")
assert home.xpath('//a[@href="stress-helpers/index.html"]')
old_addresses = []
tracked = [
    p
    for p in git("ls-files", "-z", "--", "gh-pages", "py").decode().split("\0")
    if p and Path(p).suffix in {".html", ".js", ".py", ".json"}
]
for p in tracked:
    content = (TREE / p).read_text(encoding="utf-8")
    if (
        "stress-helpers/koren.html" in content
        or "stress-helpers/simanim-tanakh.html" in content
    ):
        old_addresses.append(p)
assert not old_addresses
workflow = {}
for ref in (PARENT, SOURCE):
    files = [
        p
        for p in git("ls-tree", "-r", "--name-only", "-z", ref, "--", ".github")
        .decode()
        .split("\0")
        if p
    ]
    assert files == [".github/workflows/pages.yml"]
    blob = git("rev-parse", ref + ":.github/workflows/pages.yml").decode().strip()
    assert blob == "18ceb19405424710bda47d9a38c470cc2ed9c385"
    workflow[ref] = {
        "paths": files,
        "blob": blob,
        "text": git("show", ref + ":.github/workflows/pages.yml").decode(),
    }
status = git("show", PARENT + ":doc/review-trial-status.md").decode()
for anchor in (
    "210affe3ac2931473bead0de839be0de08309e3d",
    "9ed47c6e8999ecaf56031e9b3f524bee6e01507a",
    "3030161007bc393f554cf0c95cf819ed4d81a93c",
    "4c0084f4",
):
    assert anchor in status
save(
    "workflow-and-lineage.json",
    {
        "observed_utc": datetime.now(timezone.utc).isoformat(),
        "workflow": workflow,
        "parent": PARENT,
    },
)
save("png-integrity.json", pngs)
save("rendered-comparisons.json", row_evidence)
save(
    "js-input.json",
    {
        "rows": [
            {
                "editions": r.get("data-editions").split(),
                "outcome": r.get("data-outcome"),
                "cells": [text(c) for c in r],
            }
            for r in rows
        ],
        "queries": [r["mam"] for d in inputs.values() for r in d["differences"]]
        + [
            "Koren p. 346",
            "SimTan p. 1432",
            "pointed margin qere",
            "redundant",
            "SimTan",
            "2Chr 20:27",
        ],
    },
)
result = {
    "base": BASE,
    "source": SOURCE,
    "paths": len(changed),
    "rendered_rows": len(rows),
    "shared_rows": 15,
    "single_edition_rows": 22,
    "flattened_comparisons": dict(flattened),
    "all_fields_except_notes_unchanged_in_input_order": True,
    "all_per_source_notes_and_links_preserved": True,
    "all_mam_forms_in_cited_public_body_qere": True,
    "verse_order": True,
    "local_link_attributes": links,
    "external_links_unfetched": sorted(external),
    "pngs": len(pngs),
    "linked_crops": len(all_crops),
    "retained_unreferenced_crops": orphans,
    "owner_address_removal_preserved": True,
    "research_limits": "10,223 scan-check completion and likely-MAM-error interpretation remain owner-attributed; no source acquisition, browser, manuscript or full-scan collation.",
}
save("probe-result.json", result)
print(json.dumps(result, ensure_ascii=False, indent=2))

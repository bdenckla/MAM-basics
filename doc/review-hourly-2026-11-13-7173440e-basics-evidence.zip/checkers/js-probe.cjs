// Exercise the actual script in a minimal DOM model; no browser rendering claim.
const fs = require("node:fs");
const vm = require("node:vm");
const assert = require("node:assert/strict");
const root = __dirname;
const page = JSON.parse(fs.readFileSync(root + "/evidence/js-input.json", "utf8"));
const code = fs.readFileSync(root + "/head/gh-pages/stress-helpers/controls.js", "utf8");
const events = new Map();
const elements = {};
for (const id of ["hebrew-size", "size-value", "size-reset", "toggle-images", "find", "edition", "outcome", "visible"]) {
    elements[id] = {
        value: id === "hebrew-size" ? "30" : "",
        defaultValue: id === "hebrew-size" ? "30" : "",
        textContent: "",
        attributes: { "aria-expanded": "false" },
        addEventListener(event, callback) { events.set(id + "/" + event, callback); },
        getAttribute(name) { return this.attributes[name]; },
        setAttribute(name, value) { this.attributes[name] = String(value); },
    };
}
const rows = page.rows.map(r => ({cells: r.cells.map(t => ({textContent: t})), dataset: {outcome: r.outcome, editions: r.editions.join(" ")}, hidden: false}));
const scans = Array.from({length: rows.length + 1}, () => ({hidden: true}));
const properties = {};
const context = {document: {
    documentElement: {style: {setProperty(name, value) { properties[name] = value; }}},
    querySelector(selector) { assert(selector.startsWith("#")); return elements[selector.slice(1)]; },
    querySelectorAll(selector) {
        if (selector === "#observations .scan") return scans;
        if (selector === "#observations tbody tr") return rows;
        throw new Error(selector);
    },
}};
vm.runInNewContext(code, context, {filename: "controls.js"});
assert.equal(properties["--hebrew-size"], "30px");
assert.equal(elements.visible.textContent, "37 differences");
for (const size of ["20", "48", "35"]) {
    elements["hebrew-size"].value = size;
    events.get("hebrew-size/input")();
    assert.equal(properties["--hebrew-size"], size + "px");
    assert.equal(elements["size-value"].textContent, size + " px");
}
events.get("size-reset/click")();
assert.equal(properties["--hebrew-size"], "30px");
for (const show of [true, false, true, false]) {
    events.get("toggle-images/click")();
    assert(scans.every(cell => cell.hidden === !show));
    assert.equal(elements["toggle-images"].attributes["aria-expanded"], String(show));
    assert.equal(elements["toggle-images"].textContent, show ? "Hide images" : "Show images");
}
// Code-point loop is independent of the implementation's regular expression.
function key(value) {
    let out = "";
    for (const char of value.trim().toLocaleLowerCase("en")) {
        const n = char.codePointAt(0);
        if ((n >= 1425 && n <= 1469) || (n >= 1471 && n <= 1479)) continue;
        out += char;
    }
    return out;
}
const queries = ["", "unmatched-needle", "MAM", "mam", "  MAM  ", ...page.queries, ...page.queries.map(key)];
const categories = ["", "UNKNOWN", ...new Set(page.rows.map(r => r.outcome))];
const editions = ["", "koren", "simanim-tanakh", "UNKNOWN"];
let cases = 0;
for (const query of queries) {
    for (const category of categories) {
        for (const edition of editions) {
            elements.find.value = query;
            elements.outcome.value = category;
            elements.edition.value = edition;
            const expected = page.rows.map(row => row.cells.some(c => key(c).includes(key(query))) && (!category || row.outcome === category) && (!edition || row.editions.indexOf(edition) >= 0));
            for (const event of ["find/input", "outcome/change", "edition/change"]) {
                events.get(event)();
                assert.deepEqual(rows.map(row => !row.hidden), expected);
                const count = expected.filter(Boolean).length;
                assert.equal(elements.visible.textContent, count + (count === 1 ? " difference" : " differences"));
            }
            cases++;
        }
    }
}
const memberships = Object.fromEntries(editions.slice(0, 3).map(e => [e || "all", page.rows.filter(r => !e || r.editions.includes(e)).length]));
assert.deepEqual(memberships, {all: 37, koren: 34, "simanim-tanakh": 18});
const result = {node: process.version, rows: rows.length, shared_rows: page.rows.filter(r => r.editions.length === 2).length, query_category_edition_combinations: cases, event_paths_per_combination: 3, memberships, range_values: 3, image_toggles: 4, reset: true, limit: "Minimal DOM model only; no browser rendering, accessibility-tree, layout, network or font verification. Edition filter controls whole-row membership, including shared rows."};
fs.writeFileSync(root + "/evidence/js-result.json", JSON.stringify(result, null, 2) + "\n", "utf8");
console.log(JSON.stringify(result));

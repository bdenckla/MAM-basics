"""Run bounded checks sequentially and retain every result and generated diff."""

from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "head"
OUT = ROOT / "evidence"
PYTHON = "/workspace/MAM-basics/.venv/bin/python"
SOURCE = "7173440e9a2cf932edc290a4ff17affde54a3072"
STAGES = [
    (
        "black",
        [
            PYTHON,
            "-B",
            "-m",
            "black",
            "--check",
            "py/author_site/stress_helper_comparison.py",
            "py/author_site/site_data.py",
            "py/main_authored.py",
        ],
    ),
    ("gen-site", [PYTHON, "-B", "py/main_authored.py", "gen-site", "--trust-surveys"]),
    (
        "tests",
        [
            PYTHON,
            "-B",
            "py/main_test.py",
            "-q",
            "-ra",
            "py/tests/test_printed_decalogue_simanim.py",
            "py/tests/test_printed_decalogue_koren.py",
            "py/tests/test_decalogue_m_trad.py",
            "py/tests/test_site_index_links.py",
            "py/tests/test_deploy_root_html.py",
            "py/tests/test_site_links_relative.py",
            "py/tests/test_shared_html_styles.py",
            "py/tests/test_hebrew_letter_spacing.py",
            "py/tests/test_prose_conventions.py",
        ],
    ),
    (
        "html",
        [PYTHON, "-B", "py/check_html_syntax_and_sanity.py", "gh-pages/stress-helpers"],
    ),
]
if len(sys.argv) > 1:
    STAGES = [(sys.argv[1], sys.argv[2:])]


def git(*args):
    return subprocess.check_output(["git", "-C", str(TREE), *args])


assert git("rev-parse", "HEAD").decode().strip() == SOURCE
assert not git("status", "--porcelain=v1", "-z")
assert git("rev-parse", "--show-toplevel").decode().strip() == str(TREE)
assert not git("branch", "--show-current").strip()
for name, cmd in STAGES:
    log = OUT / (name + ".log")
    assert not log.exists()
    start = time.monotonic()
    stamp = datetime.now(timezone.utc).isoformat()
    print("Starting " + name, flush=True)
    with log.open("wb") as stream:
        result = subprocess.run(cmd, cwd=TREE, stdout=stream, stderr=subprocess.STDOUT)
    record = {
        "stage": name,
        "started_utc": stamp,
        "finished_utc": datetime.now(timezone.utc).isoformat(),
        "seconds": round(time.monotonic() - start, 6),
        "command": cmd,
        "cwd": str(TREE),
        "exit": result.returncode,
    }
    (OUT / (name + ".json")).write_text(
        json.dumps(record, indent=2) + "\n", encoding="utf-8", newline="\n"
    )
    (OUT / (name + ".diff")).write_bytes(git("diff", "--binary"))
    (OUT / (name + ".status")).write_bytes(git("status", "--porcelain=v1", "-z"))
    print(json.dumps(record), flush=True)
    assert git("rev-parse", "HEAD").decode().strip() == SOURCE
    assert not git(
        "status", "--porcelain=v1", "-z"
    ), "Inspect retained output before continuing"

"""Prepare only this completed window's compact receipt, status additions and evidence."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "head"
OUT = ROOT / "evidence"
BASE = "4c0084f405351e36eb590180fa6a7f4a4f1ee063"
SOURCE = "7173440e9a2cf932edc290a4ff17affde54a3072"
PARENT = "7bd454e13b252e2df93099909c1e33a0f4205611"
BRANCH = "review-hourly-20261113-7173440e-basics-receipts"
NAME = "review-hourly-2026-11-13-7173440e-basics"


def git(*args, tree=TREE):
    return subprocess.check_output(["git", "-C", str(tree), *args])


def dump(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


assert git("rev-parse", "HEAD").decode().strip() == SOURCE
assert not git("status", "--porcelain=v1", "-z")
assert not git("ls-remote", "origin", "refs/heads/" + BRANCH)
stages = [
    json.loads((OUT / (name + ".json")).read_bytes())
    for name in ("black", "gen-site", "tests", "html", "probes", "javascript")
]
assert [s["exit"] for s in stages] == [0, 0, 0, 1, 0, 0]
assert all(
    not (OUT / (s["stage"] + ".diff")).read_bytes()
    and not (OUT / (s["stage"] + ".status")).read_bytes()
    for s in stages
)
probe = json.loads((OUT / "probe-result.json").read_bytes())
js = json.loads((OUT / "js-result.json").read_bytes())
assert js["query_category_edition_combinations"] == 4356
assert b"37 passed" in (OUT / "tests.log").read_bytes()
html_log = (OUT / "html.log").read_text(encoding="utf-8")
assert set(
    line.removeprefix("orphan image: ")
    for line in html_log.splitlines()
    if line.startswith("orphan image: ")
) == set(probe["retained_unreferenced_crops"])
assert "Found 4 issue(s)." in html_log
disposition = {
    "outcome": "No consequential introduced defect established; no product repair.",
    "window": [BASE, SOURCE],
    "receipt_parent": PARENT,
    "input_preservation": "All 52 comparison records preserve all fields except explicit authored note rewrites and preserve each edition's input order. Coverage/source note moves to common.json; historical review chronology removed intentionally.",
    "rendered_identity": "37 rows: 15 shared and 22 single-edition; grouping retains book/chapter/verse/strand/instance/MAM/printed/destination/category. Different current distinctions remain separate. Shared rows retain both edition pages, scan titles, labeled crop links and unioned notes, including the Koren pointed-margin-qere note.",
    "controls": "Whole-row edition membership, including shared rows; no within-row crop-hiding requirement inferred. 4,356 actual-script Node combinations, each on three event paths; range/reset and four image toggles pass in minimal DOM model.",
    "known_html_exit_1": "Four retained, already orphaned Decalogue crops; no HTML-clean claim, no asset deletion.",
    "prose_disposition": "The selected prose-verse scope and both Decalogue tradition choices remain explicit. 11/13 redundant-helper counts agree with current edition records. Common 2Sam 4:6 source text/citation retains the public MAM versus MAM-with-doc distinction. Declared note rewrites combine identical facts and retain edition-specific qere context. No new editorial policy chosen.",
    "source_claims": "10,223 scan-check completion and likely 2Chr 20:27 MAM error remain owner-attributed; no scan census, live-source consultation, manuscript adjudication or new source acquisition.",
    "operational_read_correction": "A follow-up read of stress-helpers/style.css mistakenly used unchanged home checkout, where that new file does not exist. Read corrected to the admitted source; no source mutation or check result affected.",
    "overall_reviewed": "210affe3ac2931473bead0de839be0de08309e3d",
    "broad_tested": "9ed47c6e8999ecaf56031e9b3f524bee6e01507a",
    "preservation": "Exact receipt parent retains all historical rows/sections, pending gaps, immutable receipts, November 13 nightly and Windows supplement 3030161007bc393f554cf0c95cf819ed4d81a93c, and Taamey D corpus/baseline limits.",
    "limits": "No broad/mega/nightly rerun, visual browser, accessibility-tree, layout, font, HP, original scan acquisition/collation, Private or hbofonts review, main/shared integration, deployment, dispatch, schedule or outside-agent communication. Cross-machine ownership unverified.",
}
(OUT / "disposition.json").write_bytes(dump(disposition))
completed = {
    "state": "completed",
    "source": SOURCE,
    "completed_utc": datetime.now(timezone.utc).isoformat(),
    "stages": stages,
    "disposition": disposition["outcome"],
    "known_failure": disposition["known_html_exit_1"],
}
(ROOT / "stage.json").write_bytes(dump(completed))
(OUT / "stage.json").write_bytes(dump(completed))
payload = {p.name: p.read_bytes() for p in OUT.iterdir() if p.is_file()}
for name in ("run.py", "probe.py", "js-probe.cjs", "prepare.py", "publish.py"):
    payload["checkers/" + name] = (ROOT / name).read_bytes()
assert not any(name.endswith(".png") for name in payload)
payload["manifest.json"] = dump(
    {
        name: {"bytes": len(raw), "sha256": sha(raw)}
        for name, raw in sorted(payload.items())
    }
)
receipts = ROOT / "receipts"
assert not receipts.exists()
subprocess.run(
    [
        "git",
        "-C",
        "/workspace/MAM-basics",
        "worktree",
        "add",
        "-b",
        BRANCH,
        str(receipts),
        PARENT,
    ],
    check=True,
    capture_output=True,
)
assert git("rev-parse", "--show-toplevel", tree=receipts).decode().strip() == str(
    receipts
)
assert git("rev-parse", "HEAD", tree=receipts).decode().strip() == PARENT
assert git("branch", "--show-current", tree=receipts).decode().strip() == BRANCH
assert not git("status", "--porcelain=v1", "-z", tree=receipts)
archive = receipts / "doc" / (NAME + "-evidence.zip")
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as z:
    for name, raw in sorted(payload.items()):
        z.writestr(name, raw)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist()))
    for name, entry in json.loads(z.read("manifest.json")).items():
        assert (
            len(z.read(name)) == entry["bytes"] and sha(z.read(name)) == entry["sha256"]
        )
report = f"""# Bounded Basics screen, November 13, 2026, 21:00 UTC cycle

State: completed 2026-11-13; focused technical review, no product repair

Reviewed `{BASE}` → `{SOURCE}`: **five commits / 11 paths**, 231 insertions / 262 deletions. No consequential introduced defect established; no product repair. The endpoint combines the two printed-edition reports, consolidates the introduction and merges matching comparisons. The first commit's redirects were subsequently removed at the owner's explicit request; the endpoint intentionally has only `stress-helpers/index.html`. Receipt parent is `{PARENT}`, retaining the preceding screens and November 13 nightly/Windows evidence.

All **52 edition comparisons** (34 Koren / 18 Simanim Tanakh) retain every input field except the declared note rewrites, in their original per-edition input order. The combined page has **37 rows: 15 shared and 22 single-edition**, ordered by verse. Independent reconciliation accounts for both displayed Hebrew strings, occurrence/strand/instance, category, destination, per-edition page/scan/crops, and every current note/link. Matching rows retain both edition memberships, labeled crops and page numbers; the two Koren pointed-margin-qere notes remain. Different displayed strings, strands or categories are not collapsed. Common prose retains the selected prose-verse scope, the two Decalogue tradition choices, the 11/13 redundant-helper counts and the cited 2Sam 4:6 source distinction. Removed review chronology and old addresses are intentional owner changes.

The maintained `gen-site --trust-surveys` reproduces all tracked outputs exactly. **37 selected tests** pass through `py/main_test.py -q -ra`; Black passes for all three changed Python files. Full arguments, UTC times and durations are in the evidence. HTML validation **exits 1** for the same four retained orphan crops from the preceding removed Decalogue comparisons, plus 105 informational CSS-class references. No HTML-clean claim or asset deletion. Every executed stage leaves empty tracked/untracked product diffs/statuses.

Independent checks pass for **all 52 cited MAM body/qere strings**, **157 local link/asset attributes and fragments**, and **56 PNGs / 52 linked crop files**; no image content is copied into evidence. The actual `controls.js` passes **4,356 search/category/edition combinations**, each through all three input/change handlers, plus size/reset and four image toggles in a minimal Node DOM model. Edition selection correctly includes shared rows under either edition. This supplies no browser/layout/accessibility-tree/font evidence, and no browser harness was retried.

The **10,223 scan-check** completion claim and “likely MAM error” interpretation at 2Chr 20:27 remain owner-attributed research. This review does not repeat source acquisition, the scan census, full original-page collation or manuscript/editorial judgment. The prior literal Koren meteg distinction and former Simanim stored-string versus retained-crop distinction remain in their immutable preceding receipt; neither is reinterpreted here.

Overall reviewed-through remains `210affe3ac2931473bead0de839be0de08309e3d`; broad-tested remains `9ed47c6e8999ecaf56031e9b3f524bee6e01507a`. All historical rows, pending gaps, finished receipts, November 13 nightly/Windows supplement `3030161007bc393f554cf0c95cf819ed4d81a93c`, and Taamey D corpus/baseline limitations are preserved. Local admission found no running check; the inherited defunct Python process was not executing. Cross-machine ownership remains unverified. No broad/mega/nightly rerun, Private or hbofonts work, source/editorial change, main/shared integration, deployment/dispatch or scheduling.

[Evidence]({archive.name}): **{archive.stat().st_size} bytes**, SHA-256 `{sha(archive.read_bytes())}`; local ZIP CRC and every payload hash verified. The isolated three-path branch is prepared; exact normal-push/remote verification and owned-worktree cleanup/slot release are separate closeout steps recorded only after execution. Source and receipt parent retain the sole manual-dispatch Pages workflow.
"""
(receipts / "doc" / (NAME + ".md")).write_text(report, encoding="utf-8", newline="\n")
status_path = receipts / "doc/review-trial-status.md"
before = git("show", PARENT + ":doc/review-trial-status.md").decode("utf-8")
section = f"""## Bounded screen, 2026-11-13 21:00 UTC cycle, 7173440e

Reviewed `{BASE}` → `{SOURCE}`: five commits / 11 paths. No consequential introduced defect or product repair. All 52 source comparisons retain every field except declared note rewrites; 37 combined rows preserve both edition memberships, pages/crops/notes and all occurrence/strand/category distinctions. The owner's old-address removal remains intentional. Maintained gen-site --trust-surveys is exact; 37 selected tests and three-file Black pass. HTML exits 1 for the same four retained orphan crops; 105 CSS references are informational. Independent 52-comparison/157-local-attribute/56-PNG checks and 4,356 actual-script Node filter combinations pass. Source-census/editorial claims remain attributed; no browser or broad rerun. [Receipt]({NAME}.md), [evidence]({archive.name}).

Lineage `{PARENT}` preserves every older row, pending gap and finished receipt, including November 13 nightly/Windows supplement. Overall reviewed `210affe3ac2931473bead0de839be0de08309e3d`, broad-tested `9ed47c6e8999ecaf56031e9b3f524bee6e01507a` and prior source/browser/Taamey D limits remain unchanged. Isolated receipt preparation only; publication and cleanup are later verified closeout steps. No Private, hbofonts, main/shared/deployment or schedule work.

"""
anchor = "## Bounded screen, 2026-11-13 20:00 UTC cycle, 4c0084f4"
assert before.count(anchor) == 1
after = before.replace(anchor, section + anchor, 1)
table = "| Anchor | Commit/result |\n| --- | --- |\n"
rows = f"| Bounded screen 7173440e, 2026-11-13 21:00 UTC | `{BASE}` → `{SOURCE}`; five commits / 11 paths; no consequential defect or product repair. [Receipt]({NAME}.md). |\n| Focused evidence 7173440e | gen-site exact; 37 tests/three-file Black pass; HTML exit 1 for four retained orphan crops. 52 source comparisons → 37 rows, 157 local attributes, 56 PNGs/52 linked, 4,356 Node combinations. [Evidence]({archive.name}). |\n"
assert after.count(table) == 1
after = after.replace(table, table + rows, 1)
assert after.replace(section, "", 1).replace(rows, "", 1) == before
status_path.write_text(after, encoding="utf-8", newline="\n")
paths = sorted(
    [
        "doc/" + NAME + ".md",
        "doc/" + NAME + "-evidence.zip",
        "doc/review-trial-status.md",
    ]
)
changed = set(
    filter(None, git("diff", "--name-only", "-z", tree=receipts).decode().split("\0"))
) | set(
    filter(
        None,
        git("ls-files", "--others", "--exclude-standard", "-z", tree=receipts)
        .decode()
        .split("\0"),
    )
)
assert changed == set(paths)
git("diff", "--check", tree=receipts)
prepared = {
    "branch": BRANCH,
    "parent": PARENT,
    "source": SOURCE,
    "paths": paths,
    "archive": {
        "path": archive.name,
        "bytes": archive.stat().st_size,
        "sha256": sha(archive.read_bytes()),
        "payload_files": len(payload) - 1,
    },
    "prepared_utc": datetime.now(timezone.utc).isoformat(),
}
(ROOT / "publication-prepared.json").write_bytes(dump(prepared))
print(json.dumps(prepared, indent=2))

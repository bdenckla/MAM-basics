import json
from pathlib import Path
import subprocess
import time

ROOT=Path('/workspace/scratch/basics-2a108647')
ART=Path('/workspace/scratch/basics-2a108647-artifacts')
PY='/workspace/MAM-basics/.venv/bin/python'
commands=[('html-check',[PY,'py/check_html_syntax_and_sanity.py','gh-pages/morphhb-corrections']),('html-tests',[PY,'py/main_test.py','py/tests/test_site_links_relative.py','py/tests/test_shared_html_styles.py','py/tests/test_no_machine_paths_in_artifacts.py','-q'])]
results=json.loads((ART/'commands.json').read_text(encoding='utf-8'))
for name,argv in commands:
    start=time.perf_counter()
    ran=subprocess.run(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (ART/f'{name}.txt').write_bytes(ran.stdout)
    diff=subprocess.check_output(['git','diff','--binary'],cwd=ROOT)
    (ART/f'{name}.diff').write_bytes(diff)
    result={'name':name,'argv':argv,'exit':ran.returncode,'wall_seconds':round(time.perf_counter()-start,6),'tracked_diff_bytes':len(diff),'status_nul_fields':subprocess.check_output(['git','status','--porcelain=v1','-z'],cwd=ROOT).decode().split('\0')}
    results.append(result)
    (ART/'commands.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result),flush=True)
    print(ran.stdout.decode('utf-8',errors='replace'),flush=True)

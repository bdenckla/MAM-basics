"""Bounded independent checks of committed public report projections, not original research."""
from collections import Counter
from dataclasses import dataclass, field
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import subprocess
import time
import unicodedata
from urllib.parse import unquote, urlsplit

ROOT=Path('/workspace/scratch/basics-2a108647')
ART=Path('/workspace/scratch/basics-2a108647-artifacts')
F=ROOT/'in/morphhb-corrections-2026-11-13'
started=time.perf_counter()

@dataclass(eq=False)
class Node:
    tag:str
    attrs:dict
    parent:object=None
    children:list=field(default_factory=list)
    def text(self):
        return ''.join(c if isinstance(c,str) else c.text() for c in self.children)
    def classes(self):
        return self.attrs.get('class','').split()

class DOM(HTMLParser):
    def __init__(self,text):
        super().__init__(convert_charrefs=True)
        self.root=Node('root',{})
        self.stack=[self.root]
        self.nodes=[]
        self.feed(text)
        self.close()
    def handle_starttag(self,tag,attrs):
        node=Node(tag,dict(attrs),self.stack[-1])
        self.stack[-1].children.append(node)
        self.nodes.append(node)
        if tag=='br':
            node.children.append('\n')
        if tag not in {'br','meta','link','img','hr','input'}:
            self.stack.append(node)
    def handle_endtag(self,tag):
        assert self.stack[-1].tag==tag,(self.stack[-1].tag,tag)
        self.stack.pop()
    def handle_data(self,data):
        self.stack[-1].children.append(data)

review=DOM((ROOT/'gh-pages/israel-bible-review/index.html').read_text(encoding='utf-8'))
report=DOM((ROOT/'gh-pages/morphhb-corrections/index.html').read_text(encoding='utf-8'))
table=json.loads((ROOT/'out/morphhb-corrections/review-links.json').read_text(encoding='utf-8'))
where=[n for n in review.nodes if n.tag=='td' and 'bcv' in n.classes() and 'first' in n.classes()]
assert len(where)==len(table['rows'])==56
decoded=[]
for i,(node,row) in enumerate(zip(where,table['rows']),1):
    assert node.text()==row['cell']+'\npage '+str(row['page']),(i,node.text())
    tr=node.parent
    forms=[n for n in tr.children if isinstance(n,Node) and n.tag=='td' and 'form' in n.classes()]
    assert len(forms)==1
    ib_form=forms[0].text()
    siblings=[n for n in tr.parent.children if isinstance(n,Node)]
    following=siblings[siblings.index(tr)+1]
    mam_form=[n for n in following.children if isinstance(n,Node) and n.tag=='td' and 'form' in n.classes()][0].text()
    assert ib_form==row['ib'] and mam_form==row['mam'],i
    directive=row['fragment'].removeprefix('#:~:text=')
    assert row['fragment'].startswith('#:~:text=')
    fields=directive.split(',')
    if row['prefix_used']:
        assert len(fields)==3 and fields[0].endswith('-')
        prefix=unquote(fields[0][:-1])
        assert prefix==ib_form
        verse,suffix=fields[1:]
    else:
        assert len(fields)==2
        prefix=None
        verse,suffix=fields
    assert unquote(verse)==row['cell']
    assert suffix.startswith('-') and unquote(suffix[1:])=='page '+str(row['page'])
    matches=[j+1 for j,n in enumerate(where) if n.text()==node.text()]
    assert matches==([54,55] if i in (54,55) else [i]),(i,matches)
    decoded.append({'row':i,'reference':row['reference'],'page':row['page'],'prefix_used':bool(prefix),'matching_where_cells':matches})
assert [x['row'] for x in decoded if x['prefix_used']]==[55]
ids=[n.attrs['id'] for n in report.nodes if 'id' in n.attrs]
assert len(ids)==len(set(ids))
review_ids={n.attrs['id'] for n in review.nodes if 'id' in n.attrs}
assert len(table['footnotes'])==10
for note in table['footnotes']:
    assert note['anchor'] in review_ids
permitted={r['href'] for r in table['rows']}|{'../israel-bible-review/index.html#'+n['anchor'] for n in table['footnotes']}
links=[]
css=[]
for n in report.nodes:
    if n.tag not in ('a','link') or 'href' not in n.attrs:
        continue
    href=n.attrs['href']
    bits=urlsplit(href)
    if bits.scheme:
        assert bits.scheme in ('https','http')
        continue
    if bits.path:
        target=(ROOT/'gh-pages/morphhb-corrections'/unquote(bits.path)).resolve()
        assert target.is_file(),href
        if bits.path=='../israel-bible-review/index.html':
            assert href in permitted,href
            links.append(href)
    elif bits.fragment:
        assert bits.fragment in ids,href
    if n.tag=='link':
        assert n.attrs.get('rel')=='stylesheet'
        css.append(href)
assert len(links)==127 and len(css)==4

def fjson(name):
    return json.loads((F/'out'/name).read_text(encoding='utf-8'))
case=fjson('12-part1-table.json')
case_counts=Counter(r['class'] for r in case['rows'])
assert case_counts==case['counts']=={'a':1,'b':5,'c':46,'d':4}
census=fjson('50-alel-census.json')
words=census['words']
by_id={r['id']:r for r in words}
assert len(words)==len(by_id)==4930
verdicts=Counter(by_id[id_]['verdict'][0] for id_ in census['mismatches'])
assert verdicts=={'anomaly':1,'correction':5,'defensible':8,'slip':3}
letters=lambda s:''.join(c for c in s if '\u05d0'<=c<='\u05ea')
aligned=[r for r in words if len(r.get('mam_atoms',[]))==1 and letters(r['mam_atoms'][0])==letters(r['text'])]
assert len(aligned)==4924

def clusters(text):
    bases=[]
    marks=[]
    for c in text:
        if c in '\u034f\u200c\u200d':
            continue
        if unicodedata.category(c).startswith('M'):
            assert marks
            marks[-1][c]+=1
        else:
            bases.append(c)
            marks.append(Counter())
    return bases,marks

raw=(F/'out/43-text-class-lists.txt').read_text(encoding='utf-8')
section=raw.split('######## qadma (class',1)[1].split('######## divided-accents/accents (class',1)[0]
pairs=re.findall(r'^(\S+ \d+:\d+)\s+morphhb: (\S+)  \|  WLC 4\.20: (\S+)  \[morphhb \+accent qadma; WLC \+accent pashta\]$',section,re.M)
assert len(pairs)==3811
for reference,mine,wlc in pairs:
    mb,mm=clusters(mine)
    wb,wm=clusters(wlc)
    assert mb==wb,reference
    qadma=[i for i,m in enumerate(mm) if m['\u05a8']]
    pashta=[i for i,m in enumerate(wm) if m['\u0599']]
    assert len(pashta)==2 and pashta[-1]==len(wb)-1 and qadma==pashta[:1],reference
    assert all(not m['\u05a8'] for m in wm),reference
    for left,right in zip(mm,wm):
        fixed=Counter(left)
        if fixed['\u05a8']:
            fixed['\u0599']+=fixed.pop('\u05a8')
        assert fixed==right,reference

residual=fjson('41-text-residuals.json')
assert not residual['residuals'] and len(residual['other_units_shown'])==24
unions=[]
for u in residual['other_units_shown']:
    if not u['label'].startswith('divided-accents/'):
        continue
    mb,mm=clusters(u['_display']['morphhb'])
    ab,am=clusters(u['alternative']['text'])
    wb,wm=clusters(u['_display']['4.20'])
    maqaf=lambda bases:bases[-1:] == ['\u05be']
    mq,aq,wq=map(maqaf,(mb,ab,wb))
    if mq:mb,mm=mb[:-1],mm[:-1]
    if aq:ab,am=ab[:-1],am[:-1]
    if wq:wb,wm=wb[:-1],wm[:-1]
    assert mb==ab==wb
    difference=[]
    for i,(m,a,w) in enumerate(zip(mm,am,wm)):
        combined={ch:max(m[ch],a[ch]) for ch in m.keys()|a.keys()}
        for ch in combined.keys()|w.keys():
            delta=w[ch]-combined.get(ch,0)
            if delta:difference.append((i,unicodedata.name(ch),delta))
    label='marks' if difference else 'maqaf' if (mq or aq)!=wq else 'ok'
    assert label==u['union_test'],u['morphhb_ids']
    unions.append({'id':u['morphhb_ids'][0],'union_test':label,'difference':sorted(difference),'main_maqaf':mq,'alternative_maqaf':aq,'wlc_maqaf':wq})
assert len(unions)==8 and Counter(x['union_test'] for x in unions)=={'marks':5,'maqaf':1,'ok':2}

files=sorted(p for p in F.rglob('*') if p.is_file())
assert len(files)==30 and len(list((F/'out').iterdir()))==28
byte_records=[]
for p in files:
    b=p.read_bytes()
    byte_records.append({'path':p.relative_to(ROOT).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'CRLF':b.count(b'\r\n'),'lone_LF':b.count(b'\n')-b.count(b'\r\n'),'line_final_blanks':bool(re.search(rb'[ \t]+\r?$',b,re.M)),'terminal_blank_lines':bool(re.search(rb'(?:\r?\n)[ \t\r\n]*\r?\n\Z',b))})
outrecords=[x for x in byte_records if '/out/' in x['path']]
assert sum(bool(x['CRLF']) for x in outrecords)==8
assert sum(x['line_final_blanks'] or x['terminal_blank_lines'] for x in outrecords)==5
targets=[x['path'] for x in outrecords]+['in/morphhb-corrections-2026-11-13/README.md','in/morphhb-corrections-2026-11-13/what-is-left-out.md','in/morphhb-corrections-other/out/probe.txt','out/morphhb-corrections/review-links.json']
attrs=subprocess.check_output(['git','check-attr','-z','text','whitespace','--',*targets],cwd=ROOT).decode().split('\0')[:-1]
triples=list(zip(attrs[::3],attrs[1::3],attrs[2::3]))
for path,attribute,value in triples:
    expected='unset' if attribute=='text' else '-trailing-space'
    assert (value==expected)==path.startswith('in/morphhb-corrections-2026-11-13/out/'),(path,attribute,value)

summary={'source':'2a108647c4b17e587a00549eb9fa8de8958e0e3e','independent_review_cells':56,'footnote_anchors':10,'prefix_rows':[55],'report_review_links':len(links),'stylesheet_paths':css,'case_counts':case_counts,'census_words':len(words),'census_aligned':len(aligned),'census_verdicts':verdicts,'stress_helper_pairs':len(pairs),'decalogue_union_counts':Counter(x['union_test'] for x in unions),'tracked_input_files':len(files),'copied_report_files':29,'omission_notes':1,'out_files':len(outrecords),'CRLF_files':8,'trailing_or_terminal_blank_files':5,'attribute_scope_probes':len(targets),'wall_seconds':round(time.perf_counter()-started,6),'limits':'Copied report projection consistency only. No raw research, omitted originals, source acquisition, semantic reapproval, live links or browser text-fragment verification.'}
for name,obj in [('independent-summary.json',summary),('independent-fragments.json',decoded),('independent-unions.json',unions),('input-byte-inventory.json',byte_records),('attributes.json',triples)]:
    (ART/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2))

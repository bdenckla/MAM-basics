import datetime
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import subprocess
import time

ROOT = Path('/workspace/scratch/basics-2a108647')
ART = Path('/workspace/scratch/basics-2a108647-artifacts')
PY = '/workspace/MAM-basics/.venv/bin/python'
BASE = 'f689951f802051fbae4ffda794be31ce0f1de7a3'
HEAD = '2a108647c4b17e587a00549eb9fa8de8958e0e3e'
ART.mkdir(exist_ok=True)

def version(name):
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return 'not installed (metadata only; not established as a dependency)'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert not git('status', '--porcelain=v1', '-z')
changed = git('diff', '--name-only', '-z', BASE, HEAD).decode().split('\0')[:-1]
inventory = []
for rel in changed:
    b = (ROOT / rel).read_bytes()
    assert b == git('show', f'{HEAD}:{rel}'), rel
    inventory.append({'path': rel, 'bytes':len(b), 'sha256':hashlib.sha256(b).hexdigest(), 'git_blob':git('rev-parse', f'{HEAD}:{rel}').decode().strip()})
(ART/'source-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n',encoding='utf-8')
(ART/'endpoint.diff').write_bytes(git('diff', BASE, HEAD))
(ART/'owner-commit-claims.txt').write_bytes(git('log','--format=fuller',f'{BASE}..{HEAD}'))
(ART/'environment.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':platform.python_version(),'platform':platform.platform(),'interpreter':PY,'packages':{n:version(n) for n in ['black','pytest','lxml','beautifulsoup4']},'environment_changes':'none','source':HEAD,'base':BASE,'siblings_required':'none for these focused checks','omitted_research_directories_present':{p:(ROOT/p).exists() for p in ['.novc/morphhb-corrections-2026-11-13','.novc/morphhb-corrections-html-2026-11-14','in/morphhb-corrections-2026-11-13/fetched','in/morphhb-corrections-2026-11-13/scripts']}},indent=2)+'\n',encoding='utf-8')

commands = [
    ('diff-check', ['git','diff','--check',BASE,HEAD]),
    ('black', [PY,'-m','black','--check',*[p for p in changed if p.endswith('.py')]]),
    ('review-generation', [PY,'py/main_authored.py','gen-israel-bible-review']),
    ('report-generation', [PY,'py/main_authored.py','gen-morphhb-corrections']),
    ('focused-tests', [PY,'py/main_test.py','py/tests/test_mega_coverage.py','py/tests/test_product_scopes.py','py/tests/test_israel_bible_review_mam_forms.py','py/tests/test_prose_conventions.py','py/tests/test_prose_mark_order.py','py/tests/test_transliterations.py','py/tests/test_h_dot_below_nfc.py','py/tests/test_tracked_filenames.py','py/tests/test_explicit_time_zones.py','py/tests/test_entry_point_subcommands.py::test_every_subcommand_is_documented_and_every_entry_registered[main_authored]','py/tests/test_entry_point_subcommands.py::test_a_pattern_entry_spells_out_every_family_member[main_authored]','-q']),
]
results=[]
for name,argv in commands:
    start=time.perf_counter()
    ran=subprocess.run(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    secs=time.perf_counter()-start
    (ART/f'{name}.txt').write_bytes(ran.stdout)
    diff=git('diff','--binary')
    (ART/f'{name}.diff').write_bytes(diff)
    status=git('status','--porcelain=v1','-z').decode().split('\0')
    result={'name':name,'argv':argv,'exit':ran.returncode,'wall_seconds':round(secs,6),'tracked_diff_bytes':len(diff),'status_nul_fields':status}
    results.append(result)
    (ART/'commands.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result),flush=True)
    print(ran.stdout.decode('utf-8',errors='replace')[-1400:],flush=True)
(ART/'final-source.diff').write_bytes(git('diff','--binary'))
(ART/'final-source-status.json').write_text(json.dumps(git('status','--porcelain=v1','-z').decode().split('\0'))+'\n',encoding='utf-8')

"""Audit actual public report generation file inputs/outputs; no original report research."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path('/workspace/scratch/basics-2a108647')
ART=Path('/workspace/scratch/basics-2a108647-artifacts')
EXPECTED={
    'gh-pages/morphhb-corrections/index.html',
    'out/morphhb-corrections/review-links.json',
    'out/morphhb-corrections/review-links-check.txt',
}
def digest(rel):
    return hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
before={r:digest(r) for r in sorted(EXPECTED)}
events=[]
outside=[]
def audit(event,args):
    if event!='open' or not isinstance(args[0],(str,bytes)):
        return
    path=Path(os.fsdecode(args[0]))
    absolute=path if path.is_absolute() else Path.cwd()/path
    absolute=absolute.resolve()
    if absolute.is_relative_to(ROOT):
        mode=args[1]
        flags=args[2]
        write=bool(flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
        events.append((absolute.relative_to(ROOT).as_posix(),'write' if write else 'read'))
    elif absolute.is_relative_to('/workspace') and not absolute.is_relative_to('/workspace/MAM-basics/.venv') and not absolute.is_relative_to('/workspace/.cloud-setup'):
        outside.append('unexpected workspace read outside source/environment')

sys.path.insert(0,str(ROOT/'py'))
sys.addaudithook(audit)
started=time.perf_counter()
from author_misc import morphhb_corrections_index
morphhb_corrections_index.gen_html_file()
seconds=time.perf_counter()-started
sys.audit('reviewer-audit-complete')
product_events=list(events)
assert not outside,outside
reads=sorted({p for p,mode in product_events if mode=='read' and not p.startswith('py/')})
writes=sorted({p for p,mode in product_events if mode=='write' and not p.startswith('py/__pycache__/') and '/__pycache__/' not in p})
assert set(writes)==EXPECTED,writes
assert not any('.novc/' in p or '/fetched/' in p or '/scripts/' in p for p in reads)
report_reads=[p for p in reads if p.startswith('in/morphhb-corrections-2026-11-13/out/')]
assert len(report_reads)==27 and not any(p.endswith('/fetch_log.jsonl') for p in report_reads)
after={r:digest(r) for r in sorted(EXPECTED)}
assert before==after
status=subprocess.check_output(['git','status','--porcelain=v1','-z'],cwd=ROOT)
diff=subprocess.check_output(['git','diff','--binary'],cwd=ROOT)
assert not status and not diff
result={'source':'2a108647c4b17e587a00549eb9fa8de8958e0e3e','wall_seconds':round(seconds,6),'actual_nonmodule_reads':reads,'report_out_files_read':len(report_reads),'actual_product_writes':writes,'before_SHA256':before,'after_SHA256':after,'unexpected_workspace_reads':outside,'source_status_nul':status.decode(),'tracked_diff_bytes':len(diff),'scope':'Python open-event audit. Reads are actual accesses, not claims to reproduce the omitted report research. No sibling input reads.'}
(ART/'runtime-audit.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
(ART/'runtime-audit.diff').write_bytes(diff)
print(json.dumps(result,indent=2))

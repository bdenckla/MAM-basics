from pathlib import Path
import json
from urllib.parse import urlsplit,unquote
from lxml import html

src=Path('/workspace/scratch/hourly-5b6a2ef4-public/source')
d=json.loads((src/'in/stress-helpers/koren.json').read_text())
r=next(r for r in d['differences'] if (r['book'],r['chapter'],r['verse'],r.get('atom'),r.get('strand'),r['batch'])==('Deuter',5,6,12,'elyon',2))
u=urlsplit(r['verse_href'])
target=(src/'gh-pages/stress-helpers'/unquote(u.path)).resolve()
dom=html.fromstring(target.read_bytes())
node=dom.xpath('//*[@id=$id]',id=u.fragment)[0]
text=node.getparent().text_content()
out={'record':r,'target':str(target.relative_to(src)),'fragment':u.fragment,'public_verse_text':text,
     'mam_codepoints':[f'U+{ord(c):04X}' for c in r['mam']]}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,ensure_ascii=False,indent=2))

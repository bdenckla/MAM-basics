"""Preserve public-only static evidence and corrected reviewer-method limitations."""
from pathlib import Path
import json,subprocess,hashlib

task=Path(__file__).parent.parent
evid=task/'evidence'
src=task/'source'
base='efb3bd01cb3ed01f8f37d4e7cd6af59cb146734f'
source='5b6a2ef44c579a08e1f092dbfd6ac4ad681707e8'
parent='b8bbbf321fe3a39aeee81a86a46579e57e624cdc'
for name,args in {
    'endpoint.patch':['git','diff',base,source],
    'endpoint-name-status.bin':['git','diff','--name-status','-z',base,source],
    'source-final-status.bin':['git','status','--porcelain=v1','-z'],
    'source-final.diff':['git','diff','--binary'],
    'source-pages-workflow.yml':['git','show',source+':.github/workflows/pages.yml'],
    'parent-pages-workflow.yml':['git','show',parent+':.github/workflows/pages.yml'],
}.items():
    (evid/name).write_bytes(subprocess.check_output(args,cwd=src))
assert not (evid/'source-final-status.bin').read_bytes()
assert (evid/'source-pages-workflow.yml').read_bytes()==(evid/'parent-pages-workflow.yml').read_bytes()
(evid/'reviewer-method-correction.md').write_text('''# Reviewer-method correction

The first `check_data_dom-v1.py` run reached its final optional public-text assertion and
failed because it searched the combined-cantillation MAM-with-doc page for a complete
single-strand string. The traceback is retained in `data-dom-v1.txt`; that shell group
returned 0 after subsequent `cat` commands, and did not separately capture the probe's
process exit. It is a reviewer assumption failure, not an established product defect.
`inspect_public_context.json` retains the actual public verse and code points read locally.
The final probe checks the added atom against that combined verse, exact old suffix bytes,
all other data and generated-row invariants; it makes no complete strand/source-scan claim.

`old-controls-negative` is an intentional differential: the predecessor script exits 1
because All differences remains 93 instead of 37 with Batch 1 selected. The current script
passes the same harness. Its fake DOM is offline execution, not native browser/select proof.
''',encoding='utf-8')
(evid/'public-inputs.json').write_text(json.dumps({'repository':'bdenckla/MAM-basics','base':base,'source':source,'receipt_parent':parent,'sibling_inputs_required':False,'public_review_only':True},indent=2)+'\n')
print('Public final source clean; exact workflow equality; public-only inputs preserved')

"""Independent public endpoint/data/DOM comparison; no source research or generator imports."""
from collections import Counter, defaultdict
from pathlib import Path
import json
import subprocess
from urllib.parse import urlsplit, unquote

from lxml import html

TASK = Path(__file__).parent.parent
SRC = TASK / 'source'
EVID = TASK / 'evidence'
BASE = 'efb3bd01cb3ed01f8f37d4e7cd6af59cb146734f'
HEAD = '5b6a2ef44c579a08e1f092dbfd6ac4ad681707e8'

def blob(commit, path):
    return subprocess.check_output(['git', 'show', f'{commit}:{path}'], cwd=SRC)

def main():
    editions = ('koren', 'simanim-tanakh')
    all_records = {}
    changes = []
    prefix = '\N{HEBREW LETTER LAMED}\N{HEBREW POINT HOLAM}\N{HEBREW ACCENT MUNAH}\N{HEBREW LETTER ALEF}'
    maqaf = '\N{HEBREW PUNCTUATION MAQAF}'
    for edition in editions:
        path = f'in/stress-helpers/{edition}.json'
        before = json.loads(blob(BASE, path))
        after = json.loads(blob(HEAD, path))
        assert len(before['differences']) == len(after['differences'])
        assert {k:v for k,v in before.items() if k != 'differences'} == {k:v for k,v in after.items() if k != 'differences'}
        all_records[edition] = after['differences']
        for index, (old, new) in enumerate(zip(before['differences'], after['differences'])):
            fields = [k for k in old if old[k] != new[k]]
            assert old.keys() == new.keys()
            if fields:
                assert edition == 'koren'
                assert (new['book'], new['chapter'], new['verse'], new['atom'], new['strand'], new['batch'],new['page_section'],new['page']) == ('Deuter',5,6,12,'elyon',2,'appendix',39)
                assert set(fields) == {'mam','printed'}
                for field, separator in (('mam',' '), ('printed',maqaf)):
                    addition = (prefix+separator).encode('utf-8')
                    assert new[field].encode('utf-8') == addition+old[field].encode('utf-8')
                changes.append(dict(edition=edition,index=index,fields=fields,
                    added_mam_prefix_codepoints=[f'U+{ord(c):04X}' for c in prefix+' '],
                    added_printed_prefix_codepoints=[f'U+{ord(c):04X}' for c in prefix+maqaf],
                    prior_suffixes_byte_exact=True))
            else:
                for field in ('mam','printed'):
                    assert old[field].encode('utf-8') == new[field].encode('utf-8')
    assert len(changes) == 1
    assert sum(map(len,all_records.values())) == 125
    old_dom = html.fromstring(blob(BASE,'gh-pages/stress-helpers/index.html'))
    dom = html.fromstring(blob(HEAD,'gh-pages/stress-helpers/index.html'))
    old_rows = old_dom.xpath('//table[@id="observations"]/tbody/tr')
    rows = dom.xpath('//table[@id="observations"]/tbody/tr')
    assert len(rows) == len(old_rows) == 93
    altered_rows = 0
    for old, new in zip(old_rows,rows):
        if html.tostring(old) != html.tostring(new):
            altered_rows += 1
            assert new.xpath('.//th/a/@href') == old.xpath('.//th/a/@href')
            old_hebrew = old.xpath('.//span[@class="hebrew"]')
            new_hebrew = new.xpath('.//span[@class="hebrew"]')
            assert len(old_hebrew) == len(new_hebrew) == 2
            for a,b in zip(old_hebrew,new_hebrew):
                b.text = a.text
            assert html.tostring(old) == html.tostring(new)
    assert altered_rows == 1
    # Reparse after the temporary DOM comparison, leaving the actual page unchanged.
    dom = html.fromstring(blob(HEAD,'gh-pages/stress-helpers/index.html'))
    rows = dom.xpath('//table[@id="observations"]/tbody/tr')
    fields = ('book','chapter','verse','atom','strand','location','mam','printed','verse_href','category','batch')
    groups = defaultdict(list)
    for edition, records in all_records.items():
        for r in records:
            groups[tuple(r.get(f) for f in fields)].append(edition)
    assert len(groups) == len(rows)
    source_rows = []
    seen = []
    for row in rows:
        pair = row.xpath('.//span[@class="hebrew"]/text()')
        href = row.xpath('.//th/a/@href')[0]
        matches = [(k,e) for k,e in groups.items() if (str(k[-1]),k[8],k[6],k[7]) == (row.get('data-batch'),href,*pair)]
        assert len(matches) == 1
        k, editions_here = matches[0]
        suffix = 'KorSim' if len(editions_here)==2 else {'koren':'Kor','simanim-tanakh':'Sim'}[editions_here[0]]
        expected_filter = k[9]+'-'+suffix
        assert row.get('data-filter') == expected_filter
        source_rows.append({'filter':expected_filter,'batch':str(k[-1])})
        seen.append(k)
    assert len(set(seen)) == len(groups)
    menus = {}
    for menu_id,key in (('filter','filter'),('batch','batch')):
        options = dom.xpath(f'//select[@id="{menu_id}"]/option')
        old_options = old_dom.xpath(f'//select[@id="{menu_id}"]/option')
        assert len(options) == len(old_options)
        menus[menu_id]=[]
        for old, option in zip(old_options, options):
            value = option.get('value')
            label = option.get('data-label')
            count = sum(not value or r[key]==value for r in source_rows)
            assert label is not None and option.text == f'{label} ({count})'
            assert option.get('value') == old.get('value') and option.text == old.text
            menus[menu_id].append({'value':value,'label':label,'textContent':option.text})
    local_count = 0
    for node in dom.xpath('//*[@href or @src]'):
        for attr in ('href','src'):
            href = node.get(attr)
            if not href: continue
            u = urlsplit(href)
            if u.scheme or u.netloc: continue
            target = (SRC/'gh-pages/stress-helpers'/unquote(u.path)).resolve()
            assert target.is_file(), href
            if u.fragment:
                assert html.fromstring(target.read_bytes()).xpath('//*[@id=$id or @name=$id]',id=unquote(u.fragment)), href
            local_count += 1
    # The MAM addition is also present in the committed public MAM page text.
    changed = all_records['koren'][changes[0]['index']]
    u=urlsplit(changed['verse_href'])
    target=(SRC/'gh-pages/stress-helpers'/unquote(u.path)).resolve()
    mam_text=html.fromstring(target.read_bytes()).text_content()
    assert changed['mam'] in mam_text
    summary={'base':BASE,'source':HEAD,'records':125,'changed_records':changes,
        'all_other_record_fields_exact':True,'rows':93,'batch_rows':dict(Counter(r['batch'] for r in source_rows)),
        'only_one_rendered_row_changed_and_only_its_two_Hebrew_spans':True,
        'row_order_unchanged':True,'source_derived_membership_and_filter_counts':True,
        'filter_options':len(menus['filter']),'batch_options':len(menus['batch']),
        'local_link_asset_occurrences_resolved':local_count,'new_mam_text_in_public_page':True,
        'original_scan_or_summer_research_verified':False}
    (EVID/'data-dom-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    payload={'rows':[{'dataset':{'filter':r.get('data-filter'),'batch':r.get('data-batch')},'cells':[c.text_content() for c in r]} for r in rows],
        'source_rows':source_rows,'menus':menus,
        'queries':['','nomatch-ever','Exod','Deut','  EXOD  ',*[r.xpath('.//span[@class="hebrew"]/text()')[0] for r in rows]]}
    (EVID/'controls-input.json').write_text(json.dumps(payload,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps(summary,indent=2))

if __name__ == '__main__': main()

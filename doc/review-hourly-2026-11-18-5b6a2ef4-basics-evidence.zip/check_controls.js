// Offline execution of the committed control script against independently projected source rows.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');
const evidence = __dirname;
const data = JSON.parse(fs.readFileSync(path.join(evidence,'controls-input.json'),'utf8'));
const script = process.argv[2] || path.join(evidence,'../source/gh-pages/stress-helpers/controls.js');
function element(value='') {
    return {value,defaultValue:value,textContent:'',attrs:{},hidden:true,listeners:{},
        addEventListener(event,fn){this.listeners[event]=fn;},
        getAttribute(name){return this.attrs[name];},
        setAttribute(name,value){this.attrs[name]=String(value);}};
}
const ids=['hebrew-size','size-value','size-reset','toggle-images','find','filter','batch','visible'];
const elements=Object.fromEntries(ids.map(id=>['#'+id,element()]));
elements['#hebrew-size'].value=elements['#hebrew-size'].defaultValue='30';
elements['#toggle-images'].attrs['aria-expanded']='false';
for (const id of ['filter','batch']) {
    elements['#'+id].options=data.menus[id].map(o=>({...o,dataset:{label:o.label},disabled:false}));
}
const rows=data.rows.map(row=>({...row,cells:row.cells.map(textContent=>({textContent})),hidden:false}));
const crops=Array.from({length:rows.length+1},()=>element());
const style={};
const document={querySelector:s=>elements[s],querySelectorAll:s=>s.endsWith('.scan')?crops:rows,
    documentElement:{style:{setProperty:(k,v)=>{style[k]=v;}}}};
vm.runInNewContext(fs.readFileSync(script,'utf8'),{document});
let assertions=0, combinations=0, menuStates=0, zeroOptions=0;
const marks=new Set([...Array(0x05bd-0x0591+1)].map((_,i)=>0x0591+i).concat([...Array(0x05c7-0x05bf+1)].map((_,i)=>0x05bf+i)));
function key(s){return [...s.toLowerCase()].filter(c=>!marks.has(c.codePointAt(0))).join('');}
function equal(a,b,msg){assert.deepEqual(a,b,msg);assertions++;}
function menus() {
    for (const [target,other] of [['filter','batch'],['batch','filter']]) {
        const otherValue=elements['#'+other].value;
        const pool=data.source_rows.filter(r=>!otherValue||r[other]===otherValue);
        for (const option of elements['#'+target].options) {
            const count=pool.filter(r=>!option.value||r[target]===option.value).length;
            equal(option.textContent,`${option.dataset.label} (${count})`,`${target} count at ${other}=${otherValue}`);
            equal(option.disabled,Boolean(option.value&&count===0),`${target} disabled ${option.value}`);
            if (option.disabled) zeroOptions++;
        }
    }
    menuStates++;
}
function table() {
    const category=elements['#filter'].value, batch=elements['#batch'].value, query=key(elements['#find'].value.trim());
    const expected=data.rows.map((r,i)=>(!category||data.source_rows[i].filter===category)&&(!batch||data.source_rows[i].batch===batch)&&r.cells.some(c=>key(c).includes(query)));
    equal(rows.map(r=>!r.hidden),expected,'table conjunction');
    const n=expected.filter(Boolean).length;
    equal(elements['#visible'].textContent,n+(n===1?' difference':' differences'),'readout');
}
function snapshot(){return JSON.stringify(['filter','batch'].map(k=>elements['#'+k].options));}
menus();table();
// Forward then reverse order includes recovery through All choices and repeated states.
for (const reverse of [false,true]) {
    const filters=data.menus.filter.map(o=>o.value), batches=data.menus.batch.map(o=>o.value);
    if(reverse){filters.reverse();batches.reverse();}
    for (const category of filters) for (const batch of batches) {
        elements['#filter'].value=category;
        elements['#batch'].value=batch;
        elements[reverse?'#filter':'#batch'].listeners.change();
        menus(); table();
        const before=snapshot();
        for (const query of data.queries) {
            elements['#find'].value=query;
            elements['#find'].listeners.input();
            table();
            equal(snapshot(),before,'search must not alter either menu');
            combinations++;
        }
    }
}
// Explicitly observe enabled empty options and full recovery after a forced empty intersection.
elements['#filter'].value='';elements['#batch'].value='';elements['#find'].value='';
elements['#batch'].listeners.change();menus();table();
equal(elements['#filter'].options.every(o=>!o.disabled),true,'all categories recover');
equal(elements['#batch'].options.every(o=>!o.disabled),true,'all batches recover');
const visibility=rows.map(r=>r.hidden);
for(const show of [true,false,true,false]) {
    elements['#toggle-images'].listeners.click();
    equal(crops.every(c=>c.hidden===!show),true,'image cells');
    equal(elements['#toggle-images'].attrs['aria-expanded'],String(show),'aria-expanded');
    equal(elements['#toggle-images'].textContent,show?'Hide images':'Show images','image label');
    equal(rows.map(r=>r.hidden),visibility,'images preserve row filter');
}
for(const size of ['20','48','34']) {
    elements['#hebrew-size'].value=size;elements['#hebrew-size'].listeners.input();
    equal(style['--hebrew-size'],size+'px','size');equal(elements['#size-value'].textContent,size+' px','size readout');
}
elements['#size-reset'].listeners.click();equal(style['--hebrew-size'],'30px','reset');
console.log(JSON.stringify({rows:rows.length,filters:data.menus.filter.length,batches:data.menus.batch.length,
    queries:data.queries.length,filter_search_combinations:combinations,menu_states:menuStates,
    observed_disabled_option_checks:zeroOptions,assertions,source_derived_expected_counts:true,
    repeated_forward_reverse_transitions:true,search_count_independence:true,
    forced_empty_intersections_and_recovery:true,browser_or_native_select_behavior:false},null,2));

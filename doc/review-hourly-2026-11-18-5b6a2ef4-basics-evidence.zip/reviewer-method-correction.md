# Reviewer-method correction

The first `check_data_dom-v1.py` run reached its final optional public-text assertion and
failed because it searched the combined-cantillation MAM-with-doc page for a complete
single-strand string. The traceback is retained in `data-dom-v1.txt`; that shell group
returned 0 after subsequent `cat` commands, and did not separately capture the probe's
process exit. It is a reviewer assumption failure, not an established product defect.
`inspect_public_context.json` retains the actual public verse and code points read locally.
The final probe checks the added atom against that combined verse, exact old suffix bytes,
all other data and generated-row invariants; it makes no complete strand/source-scan claim.

`old-controls-negative` is an intentional differential: the predecessor script exits 1
because All differences remains 93 instead of 37 with Batch 1 selected. The current script
passes the same harness. Its fake DOM is offline execution, not native browser/select proof.

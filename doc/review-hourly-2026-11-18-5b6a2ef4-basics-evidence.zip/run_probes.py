from pathlib import Path
from datetime import datetime,timezone
import json
import subprocess
import time

evidence=Path(__file__).parent
src=evidence.parent/'source'
py='/workspace/MAM-basics/.venv/bin/python'
commands=[('data-dom',[py,str(evidence/'check_data_dom.py')]),
          ('controls',['node',str(evidence/'check_controls.js')]),
          ('old-controls-negative',['node',str(evidence/'check_controls.js'),str(evidence/'old-controls.js')])]
(evidence/'old-controls.js').write_bytes(subprocess.check_output(['git','show','efb3bd01cb3ed01f8f37d4e7cd6af59cb146734f:gh-pages/stress-helpers/controls.js'],cwd=src))
results=[]
for name,command in commands:
    start=datetime.now(timezone.utc).isoformat();tick=time.monotonic()
    with (evidence/f'{name}.txt').open('wb') as log:
        p=subprocess.run(command,cwd=src,stdout=log,stderr=subprocess.STDOUT)
    result=dict(name=name,command=command,cwd=str(src),start_utc=start,wall_seconds=round(time.monotonic()-tick,6),exit=p.returncode,expected_exit=1 if name=='old-controls-negative' else 0)
    results.append(result)
    (evidence/'probe-commands.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(result),flush=True)
    if p.returncode!=result['expected_exit']:raise SystemExit('Preserved failed probe; stopped')

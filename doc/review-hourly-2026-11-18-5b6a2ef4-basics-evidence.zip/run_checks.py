"""Run only this endpoint's maintained focused checks and preserve exact outcomes."""
from datetime import datetime, timezone
from pathlib import Path
import json
import subprocess
import time

ROOT = Path('/workspace/scratch/hourly-5b6a2ef4-public/source')
EVIDENCE = Path(__file__).parent
PY = '/workspace/MAM-basics/.venv/bin/python'
COMMANDS = [
    ('diff-check', ['git', 'diff', '--check', 'efb3bd01cb3ed01f8f37d4e7cd6af59cb146734f', '5b6a2ef44c579a08e1f092dbfd6ac4ad681707e8']),
    ('black', [PY, '-m', 'black', '--check', 'py/author_site/stress_helper_comparison.py']),
    ('gen-site', [PY, 'py/main_authored.py', 'gen-site', '--trust-surveys']),
    ('focused-tests', [PY, 'py/main_test.py', 'py/tests/test_prose_conventions.py', 'py/tests/test_prose_mark_order.py', 'py/tests/test_shared_html_styles.py', 'py/tests/test_site_links_relative.py', 'py/tests/test_site_index_links.py', '-q']),
]
results = []
for name, command in COMMANDS:
    start = datetime.now(timezone.utc).isoformat()
    tick = time.monotonic()
    with (EVIDENCE / f'{name}.txt').open('wb') as stream:
        result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
    outcome = dict(name=name, command=command, cwd=str(ROOT), start_utc=start,
                   wall_seconds=round(time.monotonic()-tick, 6), exit=result.returncode)
    results.append(outcome)
    (EVIDENCE / 'commands.json').write_text(json.dumps(results, indent=2)+'\n')
    (EVIDENCE / f'{name}-post-status.bin').write_bytes(subprocess.check_output(['git','status','--porcelain=v1','-z'],cwd=ROOT))
    (EVIDENCE / f'{name}-post.diff').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=ROOT))
    print(json.dumps(outcome), flush=True)
    if result.returncode or (EVIDENCE / f'{name}-post-status.bin').stat().st_size:
        raise SystemExit('Stopped to preserve and triage failure or unexpected diff')

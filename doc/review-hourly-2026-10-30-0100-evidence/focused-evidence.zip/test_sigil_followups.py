import ast
import collections
import json
import re
from pathlib import Path

import pytest

from sigils import inventory as current

OUT = Path('/workspace/scratch/review-hourly-20261030-0100/basics')
ROOT = Path('/workspace/MAM-basics')
OLD = {}
exec(compile((OUT / 'inventory-base.py').read_text(encoding='utf-8'), 'inventory-base.py', 'exec'), OLD)
QUOTE_FORMS = set(map(chr, (0x27, 0x22, 0x2019, 0x201D, 0x05F3, 0x05F4)))
ADDED_ABBREVIATIONS = re.compile('[א-ת]+[\u2019\u201d\u05f3][א-ת0-9]+(?:-[א-ת0-9]+)?')


def word_neighbor(c):
    code = ord(c)
    return c.isalnum() or c == '_' or 0x591 <= code <= 0x5BD or code in {0x5BF, 0x5C1, 0x5C2, 0x5C4, 0x5C5, 0x5C7, 0x5BE, 0xFB1E, 0x34F, 0x2D} or c in QUOTE_FORMS


def independent_tokens(text):
    spans = []
    for m in OLD['_PROSE_ABBREV_RE'].finditer(text):
        value = m.group()
        if len(value) == 2 and value[-1] in '?!' and m.start() and word_neighbor(text[m.start() - 1]):
            continue
        if value.startswith('כתי') and all('א' <= c <= 'ת' for c in value):
            continue
        spans.append((m.start(), m.end(), value))
    spans.extend((m.start(), m.end(), m.group()) for m in ADDED_ABBREVIATIONS.finditer(text))
    cursor = 0
    result = []
    for start, end, value in sorted(set(spans), key=lambda v: (v[0], -v[1])):
        if start < cursor:
            continue
        cursor = end
        if OLD['_looks_authority_like_expression'](value):
            result.append(value)
    return result


@pytest.fixture(scope='module')
def corpus():
    books = current.plus.read_parsed_plus_bk39s(mam_parsed_path=current.paths.mam_parsed_path())
    rows = []
    for bkid in current.tbn.ALL_BK39_IDS:
        for bcvt, minirow in books[bkid]['verses_plus'].items():
            for column_name, column in [('CP', minirow.CP), ('EP', minirow.EP)]:
                for template in current.doc_extract.find_docnote_tmpls(column):
                    text = current._note_text(template)
                    rows.append((current._bcvt_to_ref(bcvt), column_name, text))
    return rows


def test_every_note_matches_independent_old_stream_transform(corpus):
    old_counts = collections.Counter()
    expected_counts = collections.Counter()
    expected_rows = {}
    for ref, column, text in corpus:
        scan = current._without_pointed_hebrew(text)
        old_counts.update(OLD['_prose_abbreviation_tokens'](scan))
        expected = independent_tokens(scan)
        actual = current._prose_abbreviation_tokens(scan)
        assert expected == actual, (ref, column, expected, actual)
        expected_counts.update(expected)
        for token in expected:
            entry = expected_rows.setdefault(token, {'count': 0, 'examples': []})
            entry['count'] += 1
            if len(entry['examples']) < 5:
                entry['examples'].append({'ref': ref, 'column': column, 'source_kind': 'prose-token', 'note_text': text})
    inventory = json.loads((ROOT / 'out/sigil-inventory.json').read_text(encoding='utf-8'))
    actual_rows = {entry['item']: {k: v for k, v in entry.items() if k != 'item'} for entry in inventory['prose_tokens']}
    assert expected_rows == actual_rows
    assert len(corpus) == inventory['header']['counts']['notes_scanned']
    report = {'notes': len(corpus), 'old_total_tokens': sum(old_counts.values()), 'new_total_tokens': sum(expected_counts.values()), 'removed_count': sum((old_counts - expected_counts).values()), 'added_count': sum((expected_counts - old_counts).values()), 'removed_types': sorted((old_counts.keys() - expected_counts.keys())), 'added_types': sorted((expected_counts.keys() - old_counts.keys())), 'all_note_streams_counts_and_examples_match': True}
    (OUT / 'corpus-audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def test_neighbor_and_abbreviation_contract():
    for c in ['א', 'A', '5', '_', '-', chr(0x5BE), chr(0x5B4), chr(0x591), chr(0x34F), *QUOTE_FORMS]:
        for punctuation in '?!':
            assert current._prose_abbreviation_tokens(c + 'ל' + punctuation) == []
    for punctuation in '?!':
        for prefix in ['', ' ', '\n', '=', ',', '(']:
            assert current._prose_abbreviation_tokens(prefix + 'ל' + punctuation) == ['ל' + punctuation]
    for value in ['כתיב', 'כתיבה', 'כתיבת', 'כתיבתו', 'כתיבים']:
        assert current._prose_abbreviation_tokens(value) == []
    for q in QUOTE_FORMS:
        value = 'בכתי' + q + 'ל'
        assert current._prose_abbreviation_tokens(value) == [value]
    # This unchanged authority-like filter rejects some newly recognized candidates.
    value = 'ואח' + chr(0x201D) + 'כ'
    assert current._PROSE_ABBREV_RE.fullmatch(value)
    assert current._prose_abbreviation_tokens(value) == []
    assert current._prose_abbreviation_tokens("''ל''") == []


def test_unchanged_authority_logic_and_sections():
    old_ast = ast.parse((OUT / 'inventory-base.py').read_text(encoding='utf-8'))
    new_ast = ast.parse((ROOT / 'py/sigils/inventory.py').read_text(encoding='utf-8'))
    funcs = lambda tree: {n.name: ast.dump(n) for n in tree.body if isinstance(n, ast.FunctionDef)}
    assert funcs(old_ast) == funcs(new_ast)
    import subprocess
    old_json = json.loads(subprocess.check_output(['git', '-C', str(ROOT), 'show', '10708b47582fbb7f895f415683f852afe80787bc:out/sigil-inventory.json']))
    new_json = json.loads((ROOT / 'out/sigil-inventory.json').read_text(encoding='utf-8'))
    for key in ['expressions', 'expression_tokens']:
        assert old_json[key] == new_json[key]
    assert old_json['header']['categories'] == new_json['header']['categories']
    assert old_json['header']['description'] == new_json['header']['description']


def test_selected_current_document_figures():
    inventory = json.loads((ROOT / 'out/sigil-inventory.json').read_text(encoding='utf-8'))
    expression = {row['item']: row for row in inventory['expression_tokens']}
    expected = {'ו': 684, 'ו?': 30, 'א': 1497, 'ל': 1922, 'ש1': 1126, 'ק3': 767, 'ש': 791, 'ה': 50, 'ט3': 5, 'ק-מ': 357, 'מ"ק-א': 19, 'ומסורות-א': 62, 'פטרבורג-EVR-II-B-55': 10, 'ח': 16, 'כן': 157, 'וכמו': 156, 'וכך': 32, 'לפי': 24, 'ראו': 23, 'של': 20, 'אצל': 16, 'יש': 12, 'את': 6}
    assert {key: expression[key]['count'] for key in expected} == expected
    assert 'ג' not in expression and 'ובדפוסיםל' not in expression
    prose = {row['item']: row for row in inventory['prose_tokens']}
    assert prose['א(ס)']['count'] == 213
    appendix = (ROOT / 'in/mam-ws-intro/appendices.mediawiki').read_text(encoding='utf-8')
    assert len(appendix.splitlines()) == 574
    assert round(len(appendix) / 1000) == 148
    report = {'selected_expression_counts': expected, 'prose_parenthetical_sigil': prose['א(ס)']['count'], 'appendix_lines': len(appendix.splitlines()), 'appendix_characters': len(appendix), 'header': inventory['header']['counts'], 'limits': 'Historical causal comparisons and missing-equals source hypotheses remain attributed; no source edits or external contact.'}
    (OUT / 'document-figures.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

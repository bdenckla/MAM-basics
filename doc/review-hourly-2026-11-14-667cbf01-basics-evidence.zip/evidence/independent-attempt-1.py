"""Check the frozen endpoint's exact public deltas and all live long-note consumers."""

import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote, urlsplit

from lxml import html

ROOT = Path("/workspace/scratch/basics-667cbf01")
TREE = ROOT / "head"
EVIDENCE = ROOT / "evidence"
BASE = "46ed8dc5ac41fe556b131b7911726c215ab64140"
SOURCE = "667cbf01fbf8d8702d89ca006552c1a708aec93f"
OLD_TITLE = "Stress helpers in MAM, Koren Classic Tanakh, and Feldheim Simanim Tanakh"
TITLE = "Stress helpers in MAM, Koren, and Simanim"


def git(*args):
    return subprocess.check_output(["git", "-C", str(TREE), *args])


def blob(ref, path):
    return git("show", f"{ref}:{path}")


def dump(value):
    return json.dumps(value, ensure_ascii=False, indent=2) + "\n"


assert git("rev-parse", "HEAD").decode().strip() == SOURCE
assert not git("status", "--porcelain=v1", "-z")
changed = [
    p for p in git("diff", "--name-only", "-z", BASE, SOURCE).decode().split("\0") if p
]
result = {
    "base": BASE,
    "source": SOURCE,
    "observed_utc": datetime.now(timezone.utc).isoformat(),
    "endpoint_paths": len(changed),
    "reachable_commits": int(git("rev-list", "--count", BASE + ".." + SOURCE)),
}
assert result["endpoint_paths"] == 17 and result["reachable_commits"] == 4
result["python_ast"] = []
for path in changed:
    if not path.endswith(".py"):
        continue
    old, new = blob(BASE, path).decode(), blob(SOURCE, path).decode()
    transformed = (
        old.replace(OLD_TITLE, TITLE)
        if path == "py/author_site/stress_helper_comparison.py"
        else old.replace("pashut", "peshutah").replace("_PASHUT", "_PESHUTAH")
    )
    assert ast.dump(ast.parse(transformed)) == ast.dump(ast.parse(new)), path
    result["python_ast"].append({"path": path, "declared_transform_only": True})

generated = [p for p in changed if p.startswith(("gh-pages/", "out/"))]
result["generated"] = []
for path in generated:
    old, new = blob(BASE, path).decode(), blob(SOURCE, path).decode()
    expected = old.replace("pashut", "peshutah").replace(OLD_TITLE, TITLE)
    if path == "gh-pages/index.html":
        expected = expected.replace(
            "Stress helpers in MAM, Koren Classic Tanakh, and Feldheim\nSimanim Tanakh",
            TITLE,
        )
    assert new == expected, path
    hebrew_old = re.findall("[\u0590-\u05ff\u034f]+", old)
    hebrew_new = re.findall("[\u0590-\u05ff\u034f]+", new)
    assert hebrew_old == hebrew_new, path
    record = {
        "path": path,
        "declared_latin_replacements_only": True,
        "old_pashut_occurrences": old.count("pashut"),
        "old_title_occurrences": old.count(OLD_TITLE),
        "hebrew_runs_unchanged": len(hebrew_new),
        "base_sha256": hashlib.sha256(old.encode()).hexdigest(),
        "source_sha256": hashlib.sha256(new.encode()).hexdigest(),
    }
    if path.endswith(".html"):
        a, b = html.fromstring(old), html.fromstring(new)
        for query in (
            "//@href",
            "//@id",
            "//@src",
            "//@class",
            "//script/text()",
            "//style/text()",
        ):
            assert a.xpath(query) == b.xpath(query), (path, query)
        record["hrefs_ids_sources_classes_scripts_styles_unchanged"] = True
    result["generated"].append(record)
assert len(generated) == 6

css = "gh-pages/uxlc/style.css"
assert re.sub(rb"/\*.*?\*/", b"", blob(BASE, css), flags=re.S) == re.sub(
    rb"/\*.*?\*/", b"", blob(SOURCE, css), flags=re.S
)
controls = [
    "gh-pages/stress-helpers/controls.js",
    "gh-pages/stress-helpers/style.css",
]
for path in controls:
    assert blob(BASE, path) == blob(SOURCE, path)
result["unchanged_controls_and_actual_styles"] = [css, *controls]

dual_json = "out/accgram/dual-cant/_dual_cant.json"
old, new = json.loads(blob(BASE, dual_json)), json.loads(blob(SOURCE, dual_json))
json_changes = []


def compare(a, b, where=""):
    assert type(a) is type(b), where
    if isinstance(a, dict):
        assert list(a) == list(b), where
        for key in a:
            compare(a[key], b[key], where + "/" + key)
    elif isinstance(a, list):
        assert len(a) == len(b), where
        for index, (left, right) in enumerate(zip(a, b)):
            compare(left, right, where + "/" + str(index))
    elif a != b:
        assert isinstance(a, str) and b == a.replace("pashut", "peshutah"), where
        json_changes.append({"pointer": where, "before": a, "after": b})


compare(old, new)
assert len(json_changes) == 5
result["json_changed_leaves"] = json_changes
result["dual_cant_summary"] = new["summary"]
assert old["summary"] == new["summary"]
notes_path = "gh-pages/clc/Genesis-notes.json"
assert blob(BASE, notes_path) == blob(SOURCE, notes_path)
notes = json.loads(blob(SOURCE, notes_path))
assert len(notes) == 14
placeholder = "[note not yet downloaded]"
missing_notes = [n for n in notes if placeholder in n["note_text"]]
assert len(missing_notes) == 1
result["clc_existing_placeholder"] = {
    "notes_json_byte_identical": True,
    "notes": len(notes),
    "missing_local_notes": len(missing_notes),
    "with_local_pages": len(notes) - len(missing_notes),
    "placeholder": placeholder,
    "disposition": "Unchanged existing missing local note; no source acquisition attempted.",
}
page = html.fromstring(blob(SOURCE, "gh-pages/stress-helpers/index.html"))
index = html.fromstring(blob(SOURCE, "gh-pages/index.html"))
assert page.xpath("string(//title)") == page.xpath("string(//h1)") == TITLE
assert index.xpath('string(//a[@href="stress-helpers/index.html"])') == TITLE
result["title_h1_index_label"] = TITLE

# Git emits only NUL-delimited filenames. Preserve the exact hit inventory.
hits = git("grep", "-l", "-I", "-i", "-z", "-e", "pashut", SOURCE, "--")
(EVIDENCE / "old-name-files.z").write_bytes(hits)
old_paths = [p.split(":", 1)[1] for p in hits.decode().split("\0") if p]
expected_paths = {
    "dot-claude/skills/hebrew-prose/references/terminology.md",
    "gh-pages/MAM-OSIS/index.html",
    "py/osis/osis_index_html.py",
}
assert set(old_paths) == expected_paths, old_paths
for path in ("py/osis/osis_index_html.py", "gh-pages/MAM-OSIS/index.html"):
    assert blob(BASE, path) == blob(SOURCE, path)
result["remaining_old_name_files"] = [
    {
        "path": p,
        "disposition": (
            "Explicit terminology rejects the old spellings; preserve the recorded choice."
            if p.endswith("terminology.md")
            else "Unchanged pre-existing OSIS pashutah wording; separately planned out-of-window follow-up."
        ),
    }
    for p in old_paths
]

# Exercise the unchanged real pure anchor function with its current literal mappings.
long_note = ast.parse(blob(SOURCE, "py/clc/clc_long_note.py"))
pure_nodes = [
    node
    for node in long_note.body
    if (
        isinstance(node, ast.Assign)
        and any(
            isinstance(t, ast.Name) and t.id in {"_STRAND_SLUG", "_KIND_SLUG"}
            for t in node.targets
        )
    )
    or (isinstance(node, ast.FunctionDef) and node.name == "anchor_id")
]
assert len(pure_nodes) == 3
namespace = {}
exec(
    compile(
        ast.Module(body=pure_nodes, type_ignores=[]), "frozen-clc-long-note", "exec"
    ),
    namespace,
)
assert "pashut" not in namespace["_STRAND_SLUG"]
assert (
    namespace["anchor_id"]("Genesis", 35, 22, "peshutah", "pashta")
    == "long-Genesis-35-22-peshutah-pashta"
)
result["peshutah_slug_probe"] = "long-Genesis-35-22-peshutah-pashta"

# Inventory every tracked HTML consumer of a long-notes page, across the public site.
hits = git("grep", "-l", "-I", "-z", "-e", "long-notes.html", SOURCE, "--", "gh-pages")
(EVIDENCE / "long-note-consumer-files.z").write_bytes(hits)
consumers = [p.split(":", 1)[1] for p in hits.decode().split("\0") if p]
links, fragment_links, ids = [], [], set()
for path in consumers:
    parsed = html.fromstring(blob(SOURCE, path))
    for href in parsed.xpath("//@href"):
        parsed_url = urlsplit(href)
        if (
            parsed_url.scheme
            or parsed_url.netloc
            or "-long-notes.html" not in parsed_url.path
        ):
            continue
        target = (TREE / path).parent / unquote(parsed_url.path)
        target = target.resolve()
        target.relative_to(TREE)
        assert target.is_file(), (path, href)
        links.append({"source": path, "href": href})
        if parsed_url.fragment:
            fragment = unquote(parsed_url.fragment)
            target_ids = html.fromstring(target.read_bytes()).xpath("//@id")
            assert fragment in target_ids, (path, href)
            fragment_links.append({"source": path, "href": href})
            ids.add((target.relative_to(TREE).as_posix(), fragment))
assert len(consumers) == 6 and links and fragment_links
assert not any("pashut" in item["href"] for item in links)
assert not any("peshutah" in item["href"] for item in links)
result["live_long_note_consumers"] = {
    "files": consumers,
    "local_links": len(links),
    "fragment_occurrences": len(fragment_links),
    "distinct_target_ids": len(ids),
    "all_resolve": True,
    "genesis_long_note_present": False,
    "note": "The changed peshutah map is ready for a future note; no current Genesis long note or renamed live anchor exists.",
}
(EVIDENCE / "long-note-links.json").write_text(
    dump(links), encoding="utf-8", newline="\n"
)
assert not git("status", "--porcelain=v1", "-z")
(EVIDENCE / "independent.json").write_text(dump(result), encoding="utf-8", newline="\n")
print(dump(result))

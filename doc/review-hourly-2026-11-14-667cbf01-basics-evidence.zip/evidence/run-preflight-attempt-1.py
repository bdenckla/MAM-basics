"""Run the admitted public-only focused checks sequentially and retain every result."""

from datetime import datetime, timezone
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path("/workspace/scratch/basics-667cbf01")
TREE = ROOT / "head"
HOME = Path("/workspace/MAM-basics")
PYTHON = str(HOME / ".venv/bin/python")
SOURCE = "667cbf01fbf8d8702d89ca006552c1a708aec93f"
BASE = "46ed8dc5ac41fe556b131b7911726c215ab64140"
EVIDENCE = ROOT / "evidence"


def git(*args):
    return subprocess.check_output(["git", "-C", str(TREE), *args])


def write_json(path, value):
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )


assert git("rev-parse", "HEAD").decode().strip() == SOURCE
assert not git("branch", "--show-current").strip()
assert not git("status", "--porcelain=v1", "-z")
assert json.loads(Path(str(ROOT) + "-slot.json").read_bytes())["state"] == "claimed"
assert not os.environ.get("PYTHONPATH")
for filename in ("requirements.txt", "constraints.txt"):
    assert (TREE / filename).read_bytes() == (HOME / filename).read_bytes()
versions = {}
for line in (TREE / "constraints.txt").read_text(encoding="utf-8").splitlines():
    name, version = line.split("==")
    installed = importlib.metadata.version(name)
    assert installed == version, (name, installed, version)
    versions[name] = installed
changed = [
    p for p in git("diff", "--name-only", "-z", BASE, SOURCE).decode().split("\0") if p
]
python_paths = [p for p in changed if p.endswith(".py")]
assert len(changed) == 17 and len(python_paths) == 8
for filename, args in (
    ("endpoint-paths.z", ("diff", "--name-only", "-z", BASE, SOURCE)),
    ("endpoint-numstat.z", ("diff", "--numstat", "-z", BASE, SOURCE)),
    ("endpoint.diff", ("diff", "--binary", BASE, SOURCE)),
    ("commits.txt", ("log", "--format=%H %cI %s", BASE + ".." + SOURCE)),
):
    (EVIDENCE / filename).write_bytes(git(*args))
write_json(
    EVIDENCE / "environment.json",
    {
        "observed_utc": datetime.now(timezone.utc).isoformat(),
        "source": SOURCE,
        "base": BASE,
        "interpreter": sys.executable,
        "version": sys.version,
        "constraints_match": True,
        "versions": versions,
        "sibling_inputs": [],
        "input_policy": "All selected checks read committed public inputs inside the frozen tree.",
    },
)
jobs = [
    ("diff-check", ["git", "diff", "--check", BASE, SOURCE]),
    ("black", [PYTHON, "-m", "black", "--check", *python_paths]),
    (
        "tests",
        [
            PYTHON,
            "py/main_test.py",
            "py/tests/clc_dual_cant_test.py",
            "py/tests/test_dual_cant_detangle.py",
            "py/tests/clc_collect_test.py",
            "py/tests/test_prose_conventions.py",
            "py/tests/test_deploy_root_html.py",
            "-q",
        ],
    ),
    ("dual-cant", [PYTHON, "py/main_accgram.py", "run-dual-cant"]),
    (
        "supplied-marks",
        [PYTHON, "py/main_accgram.py", "generate-html-supplied-marks"],
    ),
    ("clc-genesis", [PYTHON, "py/main_clc.py", "Genesis"]),
    ("gen-site", [PYTHON, "py/main_authored.py", "gen-site", "--trust-surveys"]),
]
stage = {"state": "running", "source": SOURCE, "jobs": []}
write_json(ROOT / "stage.json", stage)
for name, cmd in jobs:
    print("START", name, flush=True)
    started = datetime.now(timezone.utc).isoformat()
    before = time.monotonic()
    with (EVIDENCE / f"{name}.stdout").open("wb") as out:
        with (EVIDENCE / f"{name}.stderr").open("wb") as err:
            result = subprocess.run(cmd, cwd=TREE, stdout=out, stderr=err)
    elapsed = time.monotonic() - before
    status = git("status", "--porcelain=v1", "-z")
    (EVIDENCE / f"{name}.status.z").write_bytes(status)
    (EVIDENCE / f"{name}.diff").write_bytes(git("diff", "--binary"))
    record = {
        "name": name,
        "cwd": str(TREE),
        "command": cmd,
        "started_utc": started,
        "ended_utc": datetime.now(timezone.utc).isoformat(),
        "seconds": round(elapsed, 6),
        "exit": result.returncode,
        "status_bytes": len(status),
    }
    stage["jobs"].append(record)
    write_json(ROOT / "stage.json", stage)
    print(json.dumps(record), flush=True)
    if result.returncode or status:
        stage["state"] = "stopped for triage"
        write_json(ROOT / "stage.json", stage)
        raise SystemExit(result.returncode or 1)
stage["state"] = "focused commands completed"
write_json(ROOT / "stage.json", stage)

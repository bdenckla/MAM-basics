"""Prepare three public receipt paths without committing or pushing them."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path("/workspace/scratch/basics-667cbf01")
TREE = ROOT / "receipts"
SOURCE = "667cbf01fbf8d8702d89ca006552c1a708aec93f"
BASE = "46ed8dc5ac41fe556b131b7911726c215ab64140"
PARENT = "9a780220360f086c6298a52702009cf22867cf3a"
BRANCH = "review-hourly-20261113-7173440e-basics-receipts"
STEM = "review-hourly-2026-11-14-667cbf01-basics"


def git(*args):
    return subprocess.check_output(["git", "-C", str(TREE), *args])


def write_json(path, value):
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )


assert git("rev-parse", "HEAD").decode().strip() == PARENT
assert git("branch", "--show-current").decode().strip() == BRANCH
assert git("ls-remote", "origin", "refs/heads/" + BRANCH).decode() == (
    PARENT + "\trefs/heads/" + BRANCH + "\n"
)
assert not git("diff", "--name-only", "-z")
assert git("ls-files", "--others", "--exclude-standard", "-z").decode() == (
    f"doc/{STEM}.md\0"
)
stage = json.loads((ROOT / "stage.json").read_bytes())
independent = json.loads((ROOT / "evidence/independent-command.json").read_bytes())
assert stage["state"] == "focused commands completed"
assert all(r["exit"] == r["status_bytes"] == 0 for r in stage["jobs"])
assert independent["exit"] == independent["status_bytes"] == 0
for ref in (PARENT, SOURCE):
    assert git("ls-tree", "-r", "--name-only", "-z", ref, "--", ".github").decode() == (
        ".github/workflows/pages.yml\0"
    )
    assert git("rev-parse", ref + ":.github/workflows/pages.yml").decode().strip() == (
        "18ceb19405424710bda47d9a38c470cc2ed9c385"
    )
    assert b"on:\n  workflow_dispatch:\n" in git(
        "show", ref + ":.github/workflows/pages.yml"
    )

section = f"""## Bounded screen, 2026-11-14 (UTC), 667cbf01

Reviewed only `{BASE}` → `{SOURCE}`: four reachable commits / 17 endpoint paths; no consequential introduced defect or product repair. The title and `peshutah` rename reproduce exactly. All eight changed Python ASTs contain only declared identifier/string substitutions; generated labels/title change without Hebrew, parser, control or actual style changes. Five dual-cant JSON leaves change; every other field remains exact. The long-note slug is mapping-only: no current Genesis long note exists. Six whole-site consumer files contain 15 local links / nine fragment occurrences / seven distinct target IDs, all resolving. The unchanged OSIS wording remains the separately planned out-of-window follow-up.

Actual changed-source Black and 35 selected maintained tests pass; dual-cant, supplied-marks, CLC Genesis and gen-site --trust-surveys reproduce all tracked outputs exactly. Every executed product-stage diff/status is empty. Genesis notes JSON is byte-identical to the base, including its one missing-local-note placeholder (13/14 local). The two corrected reviewer-helper failures are archived; no product checks were repeated. Owner broad checks remain attributed and no mega/full-suite rerun, source acquisition, browser/font/native-Windows or private review occurs. The four historical orphan crops remain pending and were not relabeled or rechecked.

Lineage continues from `{PARENT}` with all prior status bytes and November 14 nightly/Windows evidence preserved. Overall reviewed `210affe3ac2931473bead0de839be0de08309e3d`, broad-tested `{BASE}`, every earlier gap and finished receipt stay unchanged. The HP supplement remains bounded to `{BASE}`. Later observed main `e30c1273bf7d7be3983b1b075fd2de834a655a32` is outside this screen, uninspected and untested. Only the existing isolated receipt branch is prepared; publication/cleanup have separate later verification. [Receipt]({STEM}.md), [evidence]({STEM}-evidence.zip).

"""
status_path = TREE / "doc/review-trial-status.md"
old_status = status_path.read_bytes()
assert old_status == git("show", PARENT + ":doc/review-trial-status.md")
marker = b"## Continuing nightly broad checks, 2026-11-14 07:00 UTC cycle\n"
assert old_status.count(marker) == 1
new_status = old_status.replace(marker, section.encode() + marker, 1)
assert new_status.replace(section.encode(), b"", 1) == old_status
status_path.write_bytes(new_status)
stage["state"] = "completed"
stage["independent"] = independent
write_json(ROOT / "stage.json", stage)
write_json(ROOT / "evidence/stage.json", stage)
instructions = [
    "AGENTS.md",
    "dot-Codex/user-wide-AGENTS.md",
    "doc/review-trial.md",
    "doc/periodic-review.md",
    "dot-claude/skills/linked-worktrees/SKILL.md",
    "dot-Codex/skills/codex-worktree-tasks/SKILL.md",
    "dot-Codex/skills/codex-worktree-tasks/references/worktree-runtime.md",
    "dot-claude/skills/iterative-document-editing/SKILL.md",
    "dot-claude/skills/hebrew-prose/SKILL.md",
    "dot-claude/skills/hebrew-prose/references/mam-basics.md",
    "dot-claude/skills/hebrew-prose/references/terminology.md",
    "dot-claude/skills/hebrew-prose/references/rendered-prose.md",
    "dot-claude/skills/hebrew-prose/references/verifying.md",
]
write_json(
    ROOT / "evidence/instructions.json",
    {
        "source": SOURCE,
        "files": {
            p: git("rev-parse", SOURCE + ":" + p).decode().strip() for p in instructions
        },
        "maintained_status_parent": PARENT,
        "maintained_status_sha256": hashlib.sha256(old_status).hexdigest(),
        "preservation": "Removing only the inserted section reconstructs every parent status byte.",
    },
)
write_json(
    ROOT / "evidence/reviewer-diagnostics.json",
    {
        "preflight_attempt_1": {
            "exit": 1,
            "product_commands_started": 0,
            "reason": "Reviewer overstrict metadata assertion required platform-conditional colorama on Linux.",
            "console_diagnostic": "preflight-attempt-1.txt transcribed from execution tool output before any log redirection was established.",
            "script": "run-preflight-attempt-1.py",
        },
        "independent_attempt_1": {
            "exit": 1,
            "reason": "Reviewer scratch inspect.py shadowed stdlib inspect during lxml import.",
            "script": "independent-attempt-1.py",
            "disposition": "Renamed to compare_endpoint.py; no inspect.py remains at scratch import root.",
        },
        "read_only_discovery": {
            "exit": 2,
            "reason": "rg command included nonexistent py/main_misc.py while locating the HTML checker; no product command or file mutation.",
        },
        "product_failure": False,
        "repair": None,
    },
)
payload = {
    "evidence/" + p.name: p.read_bytes()
    for p in sorted((ROOT / "evidence").iterdir())
    if p.is_file()
}
for name in (
    "run.py",
    "compare_endpoint.py",
    "run_independent.py",
    "prepare_receipt.py",
):
    payload["helpers/" + name] = (ROOT / name).read_bytes()
manifest = {
    name: {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    for name, data in payload.items()
}
archive = TREE / f"doc/{STEM}-evidence.zip"
assert not archive.exists()
with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in payload.items():
        z.writestr(name, data)
    z.writestr("manifest.json", json.dumps(manifest, indent=2) + "\n")
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name, item in manifest.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == item["sha256"]
record = {
    "branch": BRANCH,
    "parent": PARENT,
    "source": SOURCE,
    "base": BASE,
    "paths": [
        f"doc/{STEM}.md",
        f"doc/{STEM}-evidence.zip",
        "doc/review-trial-status.md",
    ],
    "archive": {
        "path": archive.name,
        "bytes": archive.stat().st_size,
        "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
        "payload_files": len(payload),
    },
    "prepared_utc": datetime.now(timezone.utc).isoformat(),
}
write_json(ROOT / "publication-prepared.json", record)
git("diff", "--check")
print(json.dumps(record, indent=2))

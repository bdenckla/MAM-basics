"""Retain command, timing, output and source status for the independent comparison."""

from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import time

root = Path("/workspace/scratch/basics-667cbf01")
cmd = [
    "/workspace/MAM-basics/.venv/bin/python",
    "-B",
    str(root / "compare_endpoint.py"),
]
started = datetime.now(timezone.utc).isoformat()
before = time.monotonic()
with (root / "evidence/independent.stdout").open("wb") as out:
    with (root / "evidence/independent.stderr").open("wb") as err:
        result = subprocess.run(cmd, cwd=root / "head", stdout=out, stderr=err)
elapsed = time.monotonic() - before
status = subprocess.check_output(
    ["git", "-C", str(root / "head"), "status", "--porcelain=v1", "-z"]
)
(root / "evidence/independent.status.z").write_bytes(status)
record = {
    "name": "independent",
    "command": cmd,
    "cwd": str(root / "head"),
    "started_utc": started,
    "ended_utc": datetime.now(timezone.utc).isoformat(),
    "seconds": round(elapsed, 6),
    "exit": result.returncode,
    "status_bytes": len(status),
}
(root / "evidence/independent-command.json").write_text(
    json.dumps(record, indent=2) + "\n", encoding="utf-8", newline="\n"
)
print(json.dumps(record, indent=2))
raise SystemExit(result.returncode or bool(status))

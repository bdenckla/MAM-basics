"""Independent corpus differential: retain old tokens except embedded single letters."""
from collections import Counter
from pathlib import Path
import ast
import json
import re
import subprocess
import unicodedata

from mb_cmn import paths, bib_locales as tbn, read_books_from_mam_parsed_plus as plus
from explicit_xataf import extract as doc_extract
from sigils import inventory

ROOT=paths.repo_root()
OUT=Path(__file__).parent
BASE='40e5d37ccb0276a2dc13ab51444459baba858354'

def old_source():
    return subprocess.check_output(['git','show',BASE+':py/sigils/inventory.py'],cwd=ROOT).decode()

def old_pattern():
    tree=ast.parse(old_source())
    row=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='_PROSE_ABBREV_RE' for t in n.targets))
    return re.compile(ast.literal_eval(row.value.args[0]))

def blocks(ch):
    if not ch:return False
    return (ch.isalnum() or ch=='_' or
            unicodedata.category(ch).startswith('M') and ('\u0591'<=ch<='\u05c7' or ch=='\ufb1e') or
            ch in '\u034f\u05be-\'"\u2019\u201d\u05f3\u05f4')

def predicted(text,pattern):
    result=[]
    for m in pattern.finditer(text):
        token=m.group()
        if len(token)==1:
            before=text[m.start()-1] if m.start() else ''
            after=text[m.end():m.end()+1]
            if blocks(before) or blocks(after):continue
        if inventory._looks_authority_like_expression(token):result.append(token)
    return result

def test_boundary_neighbor_classes_and_preserved_standalone_letters():
    neighbors=['א','a','ж','中','7','_','ְ','֑','ֽ','ֿ','ׁ','ׂ','ׄ','ׅ','ׇ','־','ﬞ','\u034f','-',"'",'"','’','”','׳','״']
    for neighbor in neighbors:
        for text in [neighbor+'ל','ל'+neighbor]:
            assert 'ל' not in inventory._prose_abbreviation_tokens(text),repr(text)
    for text in ['ל',',ל;','(ל)','[ל]','ל\n']:
        assert inventory._prose_abbreviation_tokens(text)==['ל']
    assert inventory._prose_abbreviation_tokens("''ל''")==[]  # documented quotation limitation

def test_all_multicharacter_rows_and_other_inventory_sections_are_unchanged():
    old=json.loads(subprocess.check_output(['git','show',BASE+':out/sigil-inventory.json'],cwd=ROOT))
    new=json.loads((ROOT/'out/sigil-inventory.json').read_text())
    assert old['expressions']==new['expressions']
    assert old['expression_tokens']==new['expression_tokens']
    old_multi={x['item']:x for x in old['prose_tokens'] if len(x['item'])!=1}
    new_multi={x['item']:x for x in new['prose_tokens'] if len(x['item'])!=1}
    assert old_multi==new_multi
    missing={x['item'] for x in old['prose_tokens']}-{x['item'] for x in new['prose_tokens']}
    assert all(len(x)==1 for x in missing)
    assert new['header']['counts']=={'notes_scanned':3871,'notes_with_matches':3681,'distinct_expressions':1354,'distinct_expression_tokens':897,'distinct_prose_tokens':576}

def test_existing_functions_are_identical_and_regex_prefix_is_preserved():
    old=ast.parse(old_source())
    new=ast.parse((ROOT/'py/sigils/inventory.py').read_text())
    funcs=lambda tree:{n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
    assert funcs(old)==funcs(new)
    assert old_pattern().pattern.rsplit('|',1)[0]==inventory._PROSE_ABBREV_RE.pattern.rsplit('|',1)[0]

def test_every_note_matches_an_independent_filter_of_the_old_token_stream():
    regex=old_pattern()
    books=plus.read_parsed_plus_bk39s(mam_parsed_path=paths.mam_parsed_path())
    counts=Counter();scanned=matched=0;lost_notes=[];removed=Counter()
    for book in tbn.ALL_BK39_IDS:
        for bcvt,row in books[book]['verses_plus'].items():
            for col,column in [('CP',row.CP),('EP',row.EP)]:
                for note in doc_extract.find_docnote_tmpls(column):
                    scanned+=1
                    text=inventory._note_text(note)
                    if not text.strip():continue
                    prose=inventory._without_pointed_hebrew(text)
                    expected=predicted(prose,regex)
                    actual=inventory._prose_abbreviation_tokens(prose)
                    assert actual==expected,(bcvt,col)
                    counts.update(expected)
                    old_tokens=[m.group() for m in regex.finditer(prose) if inventory._looks_authority_like_expression(m.group())]
                    removed.update(Counter(old_tokens)-Counter(expected))
                    other=bool(inventory._leading_equals_expressions(text) or inventory._lhs_equals_expressions(text))
                    matched+=bool(other or expected)
                    if old_tokens and not expected and not other:
                        lost_notes.append({'ref':inventory._bcvt_to_ref(bcvt),'column':col,'note_text':text})
    committed=json.loads((ROOT/'out/sigil-inventory.json').read_text())
    assert counts=={x['item']:x['count'] for x in committed['prose_tokens']}
    assert scanned==3871 and matched==3681 and len(lost_notes)==190
    assert all(len(k)==1 for k in removed)
    report={'scanned_notes':scanned,'matched_notes':matched,'distinct_prose_tokens':len(counts),'notes_losing_only_embedded_letters':len(lost_notes),
        'removed_letter_occurrences':dict(removed),'lost_note_examples':lost_notes[:8],
        'differential':'All note token streams equal independent old-stream filtering; all multicharacter tokens retained. Samples are encoding/lexing evidence, not new manuscript judgments.'}
    (OUT/'corpus-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')

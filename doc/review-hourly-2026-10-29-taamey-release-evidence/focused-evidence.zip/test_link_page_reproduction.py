"""Regenerate only pages reached by the changed link/version definitions."""
from pathlib import Path
import main_taamey_d
from author_site import site_index
from author_misc import urwotm_4_atnax_hafukh

ROOT=Path('/workspace/review-hourly-20261029-taamey-release')

def test_versioned_documentation_reproduces():
    paths=[ROOT/'gh-pages/taamey-d/Taamey_D.html',ROOT/'gh-pages/taamey-d/Xolam_xaser_for_alef.html']
    before=[p.read_bytes() for p in paths]
    main_taamey_d.almost_main(['doc'])
    assert [p.read_bytes() for p in paths]==before

def test_site_index_link_reproduces():
    path=ROOT/'gh-pages/index.html';before=path.read_bytes()
    assert Path(site_index.gen_html_file())==path
    assert path.read_bytes()==before

def test_single_essay_link_reproduces():
    directory=ROOT/'gh-pages/MAM-with-doc/misc'
    path=directory/'urwotm_4_atnax_hafukh.html';before=path.read_bytes()
    urwotm_4_atnax_hafukh.gen_html_file((str(directory),('../../document.css','style.css')))
    assert path.read_bytes()==before

"""Independent read-only audit of committed archives, pins and new page links."""
from pathlib import Path
from collections import Counter
from html.parser import HTMLParser
from urllib.parse import urlsplit, unquote
import hashlib
import io
import json
import subprocess
import zipfile

ROOT=Path('/workspace/review-hourly-20261029-taamey-release')
OUT=Path(__file__).parent
TIP='5c113154f500ba626a12e1638fb935a69335d8ac'
SOURCE='1f1be97138d5b9ac5464c2de912299828bf9fccb'
SNAPSHOT='1.2-MAM-basics-1f1be97138d5'
BASE='bcfe749c68c144218f33821c9f95775a25ed032d'
downloads=ROOT/'gh-pages/taamey-d/downloads'
snapshot=downloads/'snapshots'/SNAPSHOT
latest=downloads/'latest'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def sha(data):return hashlib.sha256(data).hexdigest()
manifest=json.loads((snapshot/'provenance.json').read_bytes())
assert manifest['source']=={'repository':'https://github.com/bdenckla/MAM-basics','commit':SOURCE}
assert manifest['identifier']==SNAPSHOT and manifest['schema_version']==2
assert manifest['kind']=='current-snapshot' and manifest['projection']=='taamey-d-only'
expected_binary={'Taamey_D/'+name:'Taamey-D/font-m-TaD/'+name for name in ['Taamey_D.ttf','Taamey_D.woff','Taamey_D.woff2','license.txt','release-notes.txt']}
source_paths=['py/main_taamey_d_build.py','py/taamey_d_build/fill_in_template.py','py/taamey_d_build/font_version.py','py/taamey_d_build/my_open.py']+['Taamey-D/font-m-TaD/'+name for name in ['license.sym.txt','license.txt','ffscript_generate_sfd_n_ttf.py','Taamey_D-nofea.sym.sfd','Taamey_D.sym.fea']]
members={}; archives={}
for name,mapping in [('Taamey_D.zip',expected_binary),('Taamey_D-sources.zip',{p:p for p in source_paths})]:
    data=(snapshot/name).read_bytes();meta=manifest['files'][name]
    assert len(data)==meta['size'] and sha(data)==meta['sha256']
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        assert z.testzip() is None and set(z.namelist())==set(mapping) and len(z.namelist())==len(mapping)
        records=[]
        for info in z.infolist():
            payload=z.read(info)
            assert payload==git('show',SOURCE+':'+mapping[info.filename])
            assert info.date_time==(1980,1,1,0,0,0) and (info.external_attr>>16)==0o100644
            records.append({'path':info.filename,'size':len(payload),'sha256':sha(payload)})
            members[info.filename]=payload
        assert records==meta['members'] and len(records)==meta['member_count']
    archives[name]={'bytes':len(data),'sha256':sha(data),'members':len(mapping)}
checksums=''.join(f'{archives[name]["sha256"]}  {name}\n' for name in sorted(archives))
assert (snapshot/'SHA256SUMS.txt').read_text()==checksums
files={p.relative_to(snapshot).as_posix():p.read_bytes() for p in snapshot.iterdir()}
assert files=={p.relative_to(latest).as_posix():p.read_bytes() for p in latest.iterdir()}
assert set(files)=={'Taamey_D.zip','Taamey_D-sources.zip','SHA256SUMS.txt','provenance.json'}
assert len([p for p in downloads.rglob('*') if p.is_file()])==9

pin=ROOT/'in/font-support/taamey-d-1.2'
inventory=json.loads((pin/'SOURCE-INVENTORY.json').read_bytes())
assert inventory['release_snapshot']['source_commit']==SOURCE
assert inventory['release_snapshot']['identifier']==SNAPSHOT
assert inventory['release_snapshot']['sha256sums_sha256']==sha((snapshot/'SHA256SUMS.txt').read_bytes())
assert inventory['release_snapshot']['provenance_sha256']==sha((snapshot/'provenance.json').read_bytes())
assert inventory['source_archive']['members']==manifest['files']['Taamey_D-sources.zip']['members']
assert (pin/'Taamey_D-1.2-sources.zip').read_bytes()==(snapshot/'Taamey_D-sources.zip').read_bytes()
font=(ROOT/'gh-pages/woff2/Taamey_D.woff2').read_bytes()
assert font==members['Taamey_D/Taamey_D.woff2']
assert inventory['binary']['size']==len(font) and inventory['binary']['sha256']==sha(font)
assert inventory['binary']['git_blob']==git('rev-parse',SOURCE+':Taamey-D/font-m-TaD/Taamey_D.woff2').decode().strip()
shared=['Taamey_D-1.2-sources.zip','FONT-NOTICE.txt','GPL-2.0.txt','SOURCE-INVENTORY.json','BUILD.txt','SOURCE.txt']
asset_paths=[]
for name in shared:
    target=ROOT/'gh-pages/font-sources/taamey-d-1.2'/name
    assert target.read_bytes()==(pin/name).read_bytes();asset_paths.append(str(target.relative_to(ROOT)))
for name in ['FONT-NOTICE.txt','GPL-2.0.txt']:
    assert (ROOT/'gh-pages/woff2'/name).read_bytes()==(pin/name).read_bytes()
    assert (pin/name).read_bytes()==git('show',BASE+':in/font-support/taamey-d-1.1/'+name)
    asset_paths.append('gh-pages/woff2/'+name)
assert (ROOT/'gh-pages/woff2/SOURCE.txt').read_bytes()==(pin/'PRODUCT-WOFF2-SOURCE.txt').read_bytes()
asset_paths.append('gh-pages/woff2/SOURCE.txt')
assert not (ROOT/'in/font-support/taamey-d-1.1').exists()
assert not (ROOT/'gh-pages/font-sources/taamey-d-1.1').exists()

class Links(HTMLParser):
    def __init__(self):super().__init__();self.links=[]
    def handle_starttag(self,tag,attrs):self.links.extend(value for key,value in attrs if key in ('href','src') and value)
def link_values(data):
    parser=Links();parser.feed(data.decode());return parser.links
paths=git('diff','--name-only','-z',BASE,TIP).decode().split('\0')[:-1]
new_links=[]
for path in paths:
    if not path.startswith('gh-pages/') or not path.endswith('.html') or not (ROOT/path).exists():continue
    old=subprocess.run(['git','show',BASE+':'+path],cwd=ROOT,capture_output=True)
    prior=Counter(link_values(old.stdout)) if old.returncode==0 else Counter()
    for link,count in (Counter(link_values((ROOT/path).read_bytes()))-prior).items():
        url=urlsplit(link)
        if url.netloc=='bdenckla.github.io' and url.path.startswith('/MAM-basics/'):
            target=ROOT/'gh-pages'/unquote(url.path.removeprefix('/MAM-basics/'))
        elif url.scheme or url.netloc or not url.path:continue
        else:target=(ROOT/path).parent/unquote(url.path)
        assert target.resolve().is_relative_to(ROOT/'gh-pages') and target.exists(),(path,link)
        new_links.append({'page':path,'link':link,'occurrences':count})
legacy={v for v in link_values((downloads/'index.html').read_bytes()) if v.startswith('https://bdenckla.github.io/hbofonts/downloads/')}
assert len(legacy)==24
result={'source_tip':TIP,'snapshot_source':SOURCE,'snapshot':SNAPSHOT,'archives':archives,'payload_files':9,'latest_exact':True,'all14archive_members_match_source_commit':True,'all_member_modes_and_fixed_dates_match':True,'pin_and_binary_match':True,'published_support_copies_equal':asset_paths,'new_local_or_same_site_links_valid':new_links,'legacy_download_links':len(legacy),'legacy_release_tag_link_present':'https://github.com/bdenckla/Taamey_D/releases/tag/v0.921-2' in link_values((downloads/'index.html').read_bytes()),'scope':'Read Git blobs, existing ZIPs, JSON and HTML only; no archive generation, source execution, font build, publish, deployment or live HTTP validation.'}
(OUT/'distribution-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

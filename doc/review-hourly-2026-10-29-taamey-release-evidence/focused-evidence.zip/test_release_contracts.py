"""Read-only release contracts and synthetic corruptions; never publish/build."""
from pathlib import Path
import json
import shutil
import zipfile

import pytest
import yaml
import main_0_mega as mega
import main_taamey_d as cli
from taamey_d import release as r
from py_html import taamey_d_assets

ROOT=Path('/workspace/review-hourly-20261029-taamey-release')
SNAPSHOT='1.2-MAM-basics-1f1be97138d5'
SOURCE_PAYLOAD=ROOT/'gh-pages/taamey-d/downloads/snapshots'/SNAPSHOT


def forbidden(*args,**kwargs):
    raise AssertionError('Read-only check reached a release writer')


def test_check_cannot_reach_any_publication_helper(monkeypatch):
    for name in ['release_publish','_build_snapshot','_write_zip','_write_checksums','_write_provenance','_copy_immutable','_replace_latest','_write_download_index']:
        monkeypatch.setattr(r,name,forbidden)
    r.release_check()


@pytest.mark.parametrize('name',['../bad','/absolute','back\\slash',''])
def test_unsafe_member_paths_rejected(name):
    with pytest.raises(r.ReleaseError):r._safe_member_name(name)


@pytest.mark.parametrize('names',[['same','same'],['Same','same'],['allowed','extra']])
def test_zip_member_identity_and_allowlist_are_closed(tmp_path,names):
    archive=tmp_path/'synthetic.zip'
    if names[0]==names[1]:
        with pytest.warns(UserWarning,match='Duplicate name'):
            with zipfile.ZipFile(archive,'w') as z:
                for name in names:z.writestr(name,b'text fixture')
    else:
        with zipfile.ZipFile(archive,'w') as z:
            for name in names:z.writestr(name,b'text fixture')
    with pytest.raises(r.ReleaseError):r._validate_archive(archive,frozenset({names[0]}),'synthetic binary archive')


@pytest.mark.parametrize('kind',['checksum','damaged-binary','extra-file','source-repository','source-commit','identifier','date','extra-manifest-key','member-record'])
def test_real_payload_corruptions_rejected_in_scratch(tmp_path,kind):
    payload=tmp_path/'copy'
    shutil.copytree(SOURCE_PAYLOAD,payload)
    path=payload/'provenance.json';manifest=json.loads(path.read_text())
    if kind=='checksum':(payload/'SHA256SUMS.txt').write_text('wrong checksum\n')
    elif kind=='damaged-binary':(payload/'Taamey_D.zip').write_bytes(b'not a ZIP')
    elif kind=='extra-file':(payload/'extra.txt').write_text('unexpected')
    elif kind=='source-repository':manifest['source']['repository']='https://example.invalid/other'
    elif kind=='source-commit':manifest['source']['commit']='invalid'
    elif kind=='identifier':manifest['identifier']='wrong'
    elif kind=='date':manifest['published_date']='2026-02-31'
    elif kind=='extra-manifest-key':manifest['extra']='not allowed'
    elif kind=='member-record':manifest['files']['Taamey_D.zip']['members'][0]['sha256']='0'*64
    else:raise AssertionError(kind)
    path.write_text(json.dumps(manifest))
    with pytest.raises(r.ReleaseError):r._check_payload(payload)


@pytest.mark.parametrize('kind',['missing-frozen-link','broken-local-link','escape'])
def test_index_rejects_lost_history_and_broken_paths(tmp_path,kind,monkeypatch):
    downloads=tmp_path/'gh-pages/taamey-d/downloads'
    shutil.copytree(ROOT/'gh-pages/taamey-d/downloads',downloads)
    (downloads.parent/'Taamey_D.html').write_text('existing documentation target')
    monkeypatch.setattr(r,'_REPO_ROOT',tmp_path)
    monkeypatch.setattr(r,'_DOWNLOADS_ROOT',downloads)
    index=downloads/'index.html';manifest=json.loads((downloads/'latest/provenance.json').read_text())
    r._check_download_index(manifest,[SNAPSHOT])
    text=index.read_text()
    if kind=='missing-frozen-link':text=text.replace('https://github.com/bdenckla/Taamey_D/releases/tag/v0.921-2','https://example.invalid/missing')
    elif kind=='broken-local-link':text+='<a href="../gone.html">Missing</a>'
    else:text+='<a href="../../../../outside">Escapes</a>'
    index.write_text(text)
    with pytest.raises(r.ReleaseError):r._check_download_index(manifest,[SNAPSHOT])


@pytest.mark.parametrize('kind',['changed','deleted','added'])
def test_worktree_immutable_snapshot_guard(tmp_path,kind,monkeypatch):
    relative=r._SNAPSHOTS_PATH+'/fixture/provenance.json'
    path=tmp_path/relative;path.parent.mkdir(parents=True);path.write_bytes(b'original')
    monkeypatch.setattr(r,'_REPO_ROOT',tmp_path)
    monkeypatch.setattr(r,'_git_names',lambda *args:[relative])
    monkeypatch.setattr(r,'_git_bytes',lambda *args:b'original')
    r._check_append_only('fixture-base')
    if kind=='changed':path.write_bytes(b'changed')
    elif kind=='deleted':path.unlink()
    else:(path.parent/'extra.txt').write_text('extra')
    with pytest.raises(r.ReleaseError):r._check_append_only('fixture-base')


@pytest.mark.parametrize('deleted',[False,True])
def test_history_cannot_mutate_or_delete_a_committed_snapshot(monkeypatch,deleted):
    relative=r._SNAPSHOTS_PATH+'/fixture/provenance.json'
    monkeypatch.setattr(r,'_git_names',lambda *args:[relative])
    def history(*args):
        if args[0]=='rev-list':return 'intro\nlater'
        if args[1].startswith('intro:'):return 'tree-a'
        if deleted:raise r.ReleaseError('deleted fixture tree')
        return 'tree-b'
    monkeypatch.setattr(r,'_git_text',history)
    with pytest.raises(r.ReleaseError):r._check_append_only_history()


def test_missing_root_is_only_prerelease_when_history_is_empty(tmp_path,monkeypatch):
    monkeypatch.setattr(r,'_DOWNLOADS_ROOT',tmp_path/'absent')
    monkeypatch.setattr(r,'_downloads_history_paths',lambda:[])
    assert r._check_download_tree('HEAD') is False
    monkeypatch.setattr(r,'_downloads_history_paths',lambda:['old snapshot'])
    with pytest.raises(r.ReleaseError):r._check_download_tree('HEAD')


@pytest.mark.parametrize('shallow',[False,True])
def test_missing_source_distinguishes_full_and_shallow_history(tmp_path,monkeypatch,shallow):
    payload=tmp_path/'latest';payload.mkdir()
    (payload/'provenance.json').write_text(json.dumps({'source':{'commit':'0'*40}}))
    monkeypatch.setattr(r,'_DOWNLOADS_ROOT',tmp_path)
    monkeypatch.setattr(r,'_git_succeeds',lambda *args:False)
    monkeypatch.setattr(r,'_git_text',lambda *args:'true' if shallow else 'false')
    with pytest.raises(r.ReleaseError) as error:r._require_source_commits([payload])
    assert isinstance(error.value,r.SourceCommitOutsideShallowHistory) is shallow


@pytest.mark.parametrize('cloud,dedicated,skips',[(True,True,True),(False,True,False),(True,False,False)])
def test_only_the_shallow_source_exception_can_be_cloud_skipped(monkeypatch,cloud,dedicated,skips):
    error=r.SourceCommitOutsideShallowHistory({'latest':'0'*40}) if dedicated else r.ReleaseError('other failure')
    def fail(argv):
        assert argv==['release-check']
        raise error
    monkeypatch.setattr(cli,'almost_main',fail)
    monkeypatch.setattr(mega.graphviz_pin,'in_cloud_session',lambda:cloud)
    monkeypatch.setattr(mega,'_CLOUD_SKIPPED_STEPS',[])
    if skips:
        mega._run_taamey_d_release_check()
        assert mega._CLOUD_SKIPPED_STEPS[0][0]=='taamey-d-release-check'
    else:
        with pytest.raises(type(error)):mega._run_taamey_d_release_check()
        assert not mega._CLOUD_SKIPPED_STEPS


def test_workflow_is_manual_full_history_and_checks_before_deploy():
    workflow=yaml.load((ROOT/'.github/workflows/pages.yml').read_text(),Loader=yaml.BaseLoader)
    assert set(workflow['on'])=={'workflow_dispatch'}
    steps=workflow['jobs']['deploy']['steps']
    checkout=next(s for s in steps if s.get('uses','').startswith('actions/checkout@'))
    assert checkout['with']['fetch-depth']=='0'
    check=next(i for i,s in enumerate(steps) if s.get('run')=='python3 py/main_taamey_d.py release-check')
    configure=next(i for i,s in enumerate(steps) if s.get('uses','').startswith('actions/configure-pages@'))
    assert check<configure and not steps[check].get('continue-on-error')


def test_check_dispatch_never_selects_publish(monkeypatch):
    calls=[]
    monkeypatch.setattr(r,'release_check',lambda:calls.append('read-only check'))
    monkeypatch.setattr(r,'release_publish',forbidden)
    cli.almost_main(['release-check'])
    assert calls==['read-only check']
    with pytest.raises(SystemExit):cli.build_parser().parse_args(['release-check','--snapshot-commit','anything'])


def test_asset_api_returns_exact_committed_support_files():
    assets=taamey_d_assets.site_font_assets()
    assert len(assets)==9
    for path,data in assets.items():assert data==(ROOT/'gh-pages'/path).read_bytes()
    assert taamey_d_assets.font_bytes()==(ROOT/'Taamey-D/font-m-TaD/Taamey_D.woff2').read_bytes()

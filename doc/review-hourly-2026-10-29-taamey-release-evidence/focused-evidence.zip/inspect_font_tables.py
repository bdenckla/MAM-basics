"""Compare committed font tables in memory; never build or serialize a font."""
from pathlib import Path
from io import BytesIO
import hashlib
import importlib.metadata
import json
import subprocess
from fontTools.ttLib import TTFont

ROOT=Path('/workspace/review-hourly-20261029-taamey-release')
OUT=Path(__file__).parent
BASE='bcfe749c68c144218f33821c9f95775a25ed032d'
TIP='5c113154f500ba626a12e1638fb935a69335d8ac'
def blob(ref,path):return subprocess.check_output(['git','show',ref+':'+path],cwd=ROOT)
def name_records(font):return {(n.platformID,n.platEncID,n.langID,n.nameID):n.toUnicode() for n in font['name'].names}
formats={}
for extension in ('ttf','woff','woff2'):
    path='Taamey-D/font-m-TaD/Taamey_D.'+extension
    before=blob(BASE,path);after=blob(TIP,path)
    a=TTFont(BytesIO(before),recalcTimestamp=False);b=TTFont(BytesIO(after),recalcTimestamp=False)
    tags=set(a.reader.keys());assert tags==set(b.reader.keys())
    changed=[tag for tag in sorted(tags) if a.reader[tag]!=b.reader[tag]]
    head_changes={k:[getattr(a['head'],k),getattr(b['head'],k)] for k in a['head'].__dict__ if k!='tableTag' and getattr(a['head'],k)!=getattr(b['head'],k)}
    an,bn=name_records(a),name_records(b);assert set(an)==set(bn)
    name_changes=[dict(record=list(k),before=an[k],after=bn[k]) for k in an if an[k]!=bn[k]]
    assert changed==['head','name'],changed
    assert set(head_changes)=={'checkSumAdjustment','fontRevision'},head_changes
    assert len(name_changes)==4 and {n['record'][-1] for n in name_changes}=={3,5},name_changes
    formats[extension]=dict(before_bytes=len(before),after_bytes=len(after),after_sha256=hashlib.sha256(after).hexdigest(),tables=len(tags),unchanged_tables=len(tags)-len(changed),changed_tables=changed,head_changes=head_changes,name_changes=name_changes)
    a.close();b.close()
assert blob(BASE,'Taamey-D/font-m-TaD/Taamey_D.sym.fea')==blob(TIP,'Taamey-D/font-m-TaD/Taamey_D.sym.fea')
assert blob(BASE,'Taamey-D/font-m-TaD/Taamey_D.fea')==blob(TIP,'Taamey-D/font-m-TaD/Taamey_D.fea')
assert blob(TIP,'Taamey-D/font-m-TaD/Taamey_D.woff2')==blob(TIP,'gh-pages/woff2/Taamey_D.woff2')
result=dict(inputs=dict(before=BASE,after=TIP),libraries={n:importlib.metadata.version(n) for n in ['fonttools','brotli']},formats=formats,symbolic_and_filled_feature_sources_unchanged=True,site_font_equals_committed_build_WOFF2=True,scope='TTFont read-only table access and in-memory WOFF2 decompression only. No FontForge, shaping, font save/build, source regeneration or baseline operation.')
(OUT/'font-table-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

from pathlib import Path
import json
import posixpath
import re
import subprocess

from mb_cmn import paths, uni_denorm, read_books_from_mam_parsed_plus as plus
from near_aleppo import edition, build_paths, link_presentation
from mwd import mwd_write_book as mwdwb
from py_misc import mwd_utils as mwdu
from foi import foiz_wt_unicode
import main_mam_with_doc

ROOT = paths.repo_root()
OLD = 'df5eb61aaa16508d9f886d88ef47a00328be3777'

def test_selected_mam_with_doc_reproduces():
    folder = ROOT / 'gh-pages/MAM-with-doc'
    expected = {p: p.read_bytes() for p in folder.rglob('*') if p.is_file()}
    main_mam_with_doc.almost_main(('Deuter',))
    assert {p:p.read_bytes() for p in folder.rglob('*') if p.is_file()} == expected

def test_selected_near_aleppo_book_reproduces():
    books = plus.read_parsed_plus_bk39s(('Deuter',), str(build_paths.dataset_dir().parent))
    mode = edition.NEAR_ALEPPO_MODE
    names = mwdu.filename_for_bkid('Deuter'), mwdu.filename_for_bkid_for_bido('Deuter')
    _,pages = mwdwb.render_book((mode.edition,(edition.EDITION_CSS_HREF,'ketiv-qere.css'),'Deuter'),books,names,mode.renopts,mode.ht_tac_for_ren_tag,text_to_html=mode.text_to_html)
    assert len(pages) == 2
    for name,text in pages.items():
        rel = 'edition/' + name
        css = posixpath.relpath(link_presentation.STYLESHEET,posixpath.dirname(rel))
        assert link_presentation.apply(text,rel,css_href=css).encode() == (build_paths.html_pages_dir()/rel).read_bytes()

def forms():
    data = json.loads((ROOT/'in/mam-ws-bot-edits/note-deuteronomy-3-22-reversed-hataf-hiriq.json').read_text())
    raw = data['edits']['Deuter'][0]['new']
    token, packed = re.search(r'=([^ ]+) \(([^)]+)\)',raw).groups()
    return token,packed,uni_denorm.give_std_mark_order(token),uni_denorm.give_std_mark_order(packed)

def test_exact_order_and_equivalent_plus_packed_spellings():
    raw_plus,raw_packed,token,packed = forms()
    left,right = token.split('+')
    assert [ord(x) for x in left] == [0x05ea,0x05bc,0x05b4]
    assert [ord(x) for x in right[:3]] == [0x05ea,0x05bc,0x05b0]
    assert packed == left+'\u034f'+right[2:]
    assert [ord(x) for x in packed[:5]] == [0x05ea,0x05bc,0x05b4,0x034f,0x05b0]
    assert raw_plus != token and raw_packed != packed
    html = (ROOT/'gh-pages/MAM-with-doc/A5-Deuter.html').read_text()
    assert token in html and packed in html

def test_foi_has_exactly_one_new_row_and_keeps_empty_category():
    path = 'gh-pages/MAM-with-doc/foi/foi-doc-note-notation.json'
    old = json.loads(subprocess.check_output(['git','show',OLD+':'+path],cwd=ROOT))
    new = json.loads((ROOT/path).read_text())
    token = forms()[2]
    row = {'bcv_short':'D3:22','fp':'plus','r':token}
    assert new.count(row) == 1 and len(new) == 9
    assert [r for r in new if r != row] == old
    assert all(r['fp'] == 'plus' for r in new)
    page = (ROOT/'gh-pages/MAM-with-doc/foi/foi-doc-note-notation.html').read_text()
    assert 'id="intro-double-guillemets"' in page and 'None are\nfound.' in page
    assert 'all 9 are shown' in page

def test_unicode_foi_has_no_additional_feature_for_new_forms():
    for value in forms()[2:]:
        assert foiz_wt_unicode._find_fois_in_str(value) == []

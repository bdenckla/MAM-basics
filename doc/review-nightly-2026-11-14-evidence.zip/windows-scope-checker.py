"""Record exact public platform-code continuity without claiming native execution."""

import json
from pathlib import Path
import subprocess

ROOT = Path("/workspace/scratch/nightly-20261114-basics")
HOME = "/workspace/MAM-basics"
prior = "9ed47c6e8999ecaf56031e9b3f524bee6e01507a"
source = "46ed8dc5ac41fe556b131b7911726c215ab64140"
paths = [
    "py/tests/test_worker_budget.py",
    "py/tests/test_git_process.py",
    "py/tests/test_mb_cmn_provenance.py",
    "py/tests/test_worktree_retirement_citations.py",
    "py/mb_cmn/worker_budget.py",
    "py/mb_cmn/git_process.py",
    "py/mb_cmn/provenance.py",
    "py/main_test.py",
]
rows = []
for path in paths:
    ids = [
        subprocess.check_output(["git", "-C", HOME, "rev-parse", ref + ":" + path])
        .decode()
        .strip()
        for ref in [prior, source]
    ]
    rows.append(
        dict(path=path, prior_blob=ids[0], current_blob=ids[1], exact=ids[0] == ids[1])
    )
record = dict(
    prior_native_windows_source=prior,
    current_portable_source=source,
    files=rows,
    all_selected_blobs_identical=all(r["exact"] for r in rows),
    limitation="Static continuity only. No current-source native Windows execution or actual Windows resource API call occurred in this cloud task.",
)
(ROOT / "evidence/windows-scope.json").write_text(
    json.dumps(record, indent=2) + "\n", encoding="utf-8", newline="\n"
)
print(json.dumps(record, indent=2))

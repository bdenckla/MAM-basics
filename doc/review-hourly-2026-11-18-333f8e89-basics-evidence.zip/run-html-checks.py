import json,os,subprocess,time
from datetime import datetime,timezone
from pathlib import Path
r=Path(__file__).resolve().parents[1];records=[]
for name,path in [('stress','gh-pages/stress-helpers'),('wlc','gh-pages/wlc')]:
 cmd=['/workspace/MAM-basics/.venv/bin/python','py/check_html_syntax_and_sanity.py',path];start=time.monotonic();began=datetime.now(timezone.utc).isoformat()
 run=subprocess.run(cmd,cwd=r/'source',env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (r/'evidence'/('html-'+name+'.txt')).write_bytes(run.stdout)
 status=subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=r/'source')
 record=dict(name=name,command=cmd,cwd=str(r/'source'),start_utc=began,wall_seconds=round(time.monotonic()-start,6),exit=run.returncode,status_bytes=len(status));records.append(record);(r/'evidence/html-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(record),flush=True)
 assert run.returncode in (0,1) and not status

import copy, json, re, subprocess
from pathlib import Path
from urllib.parse import urlsplit, unquote
from lxml import html, etree
R=Path(__file__).resolve().parents[1]/'source'; E=R.parent/'evidence'
B='f996f75630e19241d055215450165bd1da5fed80'; H='333f8e899688ff9a34f72ca3cb2c19d4a5bdac5c'
checks=[]
def blob(p,r=B):return subprocess.check_output(['git','show',r+':'+p],cwd=R)
def ok(n,v):
 assert v,n
 checks.append(n)
def norm(e):
 e=copy.deepcopy(e)
 for x in e.iter():
  if x.text:x.text=re.sub(r'\s+',' ',x.text)
  if x.tail:x.tail=re.sub(r'\s+',' ',x.tail)
 return etree.tostring(e,encoding='unicode',method='html',with_tail=False)
def dom(p,r=H):return html.document_fromstring(blob(p,r))
p='in/accgram/edition_transcriptions/koren_dt_elyon.json'
a=json.loads(blob(p));b=json.loads(blob(p,H));changed=[]
for k in a:
 if a[k]!=b[k]:changed.append(k)
ok('only bands key changes',changed==['bands'])
diffs=[i for i,(x,y) in enumerate(zip(a['bands'],b['bands'])) if x!=y]
ok('only second band changes',diffs==[1] and len(a['bands'])==len(b['bands']))
old=a['bands'][1];new=b['bands'][1]
ok('correction provenance exact prior text',new['corrected_from']==old['text'])
ok('only declared mun-mun extension in band',new['text']==old['text'].replace('רב מונ תק','רב מונ־מונ תק') and {k:v for k,v in new.items() if k not in ('text','corrected_from')}=={k:v for k,v in old.items() if k!='text'})
records=0;notechanges=0
for edition in ['koren','simanim-tanakh']:
 p='in/stress-helpers/'+edition+'.json';a=json.loads(blob(p));b=json.loads(blob(p,H));aa=copy.deepcopy(a);bb=copy.deepcopy(b)
 key='findings' if 'findings' in a else next(k for k,v in a.items() if isinstance(v,list) and v and isinstance(v[0],dict) and 'mam' in v[0])
 ok(edition+' ordered population preserved',len(a[key])==len(b[key]))
 for x,y in zip(aa[key],bb[key]):
  records+=1;notechanges+=x.get('notes')!=y.get('notes');x.pop('notes',None);y.pop('notes',None)
 ok(edition+' all exact forms/identities/crops/batches unchanged except prose notes',aa==bb)
p='gh-pages/stress-helpers/index.html';a=dom(p,B);b=dom(p);ar=a.xpath('//tbody/tr');br=b.xpath('//tbody/tr')
ok('all 93 stress rows remain ordered',len(ar)==len(br)==93)
for i,(x,y) in enumerate(zip(ar,br)):
 ok('filter membership row '+str(i),{k:v for k,v in x.attrib.items() if k!='data-search'}=={k:v for k,v in y.attrib.items() if k!='data-search'})
 ok('source Hebrew forms row '+str(i),[z.text_content() for z in x.xpath('.//td[contains(concat(" ",normalize-space(@class)," ")," form ")]')]==[z.text_content() for z in y.xpath('.//td[contains(concat(" ",normalize-space(@class)," ")," form ")]')])
 ok('crop paths row '+str(i),x.xpath('.//img/@src')==y.xpath('.//img/@src'))
ok('controls and scripts unchanged',a.xpath('//script/@src')==b.xpath('//script/@src') and [norm(e) for e in a.xpath('//select|//input')]==[norm(e) for e in b.xpath('//select|//input')])
ok('Koren conclusion link resolves corrected target',bool(b.xpath('//a[contains(@href,"printed-decalogue-koren.html#conclusion")]')))
ok('abbreviations have edition hover titles',set(b.xpath('//abbr[@title="Koren"]/text()'))=={'Kor'} and set(b.xpath('//abbr[@title="Simanim Tanakh"]/text()'))=={'Sim'})
p='gh-pages/wlc/accgram/printed-decalogue-simanim.html';a=dom(p,B);b=dom(p)
selector='//table[contains(concat(" ",normalize-space(@class)," ")," printed-decalogue-transcription-verdict ")]'
ats=a.xpath(selector);bts=b.xpath(selector);ok('both Simanim verdict tables retained',len(ats)==len(bts)==2)
simrows=0
for at,bt in zip(ats,bts):
 ok('ruled rows explicit opt-in','ruled-rows' in bt.get('class').split())
 for x,y in zip(at.xpath('.//tr')[1:],bt.xpath('.//tr')[1:]):
  simrows+=1;ca=list(x);cb=list(y)
  ok('Simanim stacked columns '+str(simrows),len(ca)==5 and len(cb)==3 and cb[0].tag=='th')
  ok('Simanim retained final two cells '+str(simrows),[norm(z) for z in ca[-2:]]==[norm(z) for z in cb[-2:]])
  labels=[re.sub(r'\s+',' ',z.text_content()) for z in ca[:3]];labels[0]=labels[0].replace('Exodus','Ex').replace('Deuteronomy','Dt')
  stacked=html.tostring(cb[0],encoding='unicode');parts=[html.fromstring('<div>'+t+'</div>').text_content() for t in re.split(r'<br\s*/?>',re.sub(r'^<th[^>]*>|</th>$','',stacked))]
  ok('Simanim exact label/page/strand identity '+str(simrows),parts==labels)
css=blob('gh-pages/wlc/style.css').decode();newcss=blob('gh-pages/wlc/style.css',H).decode()
ok('WLC executable CSS exact, comment-only delta',re.sub(r'/\*.*?\*/','',css,flags=re.S)==re.sub(r'/\*.*?\*/','',newcss,flags=re.S))
survey=json.loads((R/'out/accgram/maqaf-nonfinal-accents.json').read_bytes())
def repeated(shape):
 fields=[set(s.split('+'))-{'_'} for s in shape.split('-')]
 return any(x&y for i,x in enumerate(fields) for y in fields[i+1:])
hits={}
for corpus in ['mam_simple','uxlc','wlc422']:
 hits[corpus]=[(o['bcv'],o['shape']) for genre in (['prose'] if corpus=='mam_simple' else ['prose','poetic']) for o in survey['corpora'][corpus][genre]['occurrences'] if repeated(o['shape'])]
ok('committed MAM prose survey has no same-accent pair',hits['mam_simple']==[])
ok('committed UXLC same-accent precedent one',hits['uxlc']==[('2c1:11','mun-mun')])
ok('committed WLC same-accent precedents two',hits['wlc422']==[('1c27:14','mun-mun'),('2c1:11','mun-mun')])
ok('MAM both genres have no two mun atoms',all(sum('mun' in f.split('+') for f in o['shape'].split('-'))<2 for g in ['prose','poetic'] for o in survey['corpora']['mam_simple'][g]['occurrences']))
ok('survey evidence unchanged',subprocess.check_output(['git','rev-parse',B+':out/accgram/maqaf-nonfinal-accents.json'],cwd=R)==subprocess.check_output(['git','rev-parse',H+':out/accgram/maqaf-nonfinal-accents.json'],cwd=R))
links=0
for p in ['gh-pages/stress-helpers/index.html','gh-pages/wlc/accgram/printed-decalogue-koren.html','gh-pages/wlc/accgram/printed-decalogue-simanim.html','gh-pages/wlc/accgram/maqaf-nonfinal-accents.html']:
 d=dom(p);ids=d.xpath('//@id');ok('unique IDs '+p,len(ids)==len(set(ids)))
 for u in d.xpath('//@href|//@src'):
  s=urlsplit(u)
  if s.scheme or s.netloc:continue
  f=((R/p).parent/unquote(s.path) if s.path else R/p).resolve()
  if f.is_dir():f=f/'index.html'
  ok('local destination '+str(links),f.is_file())
  if s.fragment and f.suffix=='.html':ok('anchor '+str(links),unquote(s.fragment) in html.document_fromstring(f.read_bytes()).xpath('//@id'))
  links+=1
result=dict(base=B,source=H,checks_passed=len(checks),edition_records=records,note_changed_records=notechanges,stress_rows=len(ar),simanim_verdict_rows=simrows,committed_survey_hits=hits,local_attributes_resolved=links,checks=checks,original_source_or_visual_verification=False)
(E/'preservation-summary.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))

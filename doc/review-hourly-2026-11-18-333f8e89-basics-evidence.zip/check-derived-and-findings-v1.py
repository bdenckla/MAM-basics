import json,subprocess,re
from pathlib import Path
from collections import Counter
from lxml import html
R=Path(__file__).resolve().parents[1]/'source';E=R.parent/'evidence';B='f996f75630e19241d055215450165bd1da5fed80';H='333f8e899688ff9a34f72ca3cb2c19d4a5bdac5c'
def g(rev,p):return subprocess.check_output(['git','show',rev+':'+p],cwd=R)
p='out/accgram/printed-decalogue/_printed_decalogue.json';a=json.loads(g(B,p));b=json.loads(g(H,p))
changed=[(x['stem'],y['stem']) for x,y in zip(a['transcriptions'],b['transcriptions']) if x!=y];assert changed==[('koren_dt_elyon','koren_dt_elyon')]
assert len(a['transcriptions'])==len(b['transcriptions'])==12
assert {k:v for k,v in a.items() if k!='transcriptions'}=={k:v for k,v in b.items() if k!='transcriptions'}
at=a['transcriptions'][0];bt=b['transcriptions'][0]
assert at['chanted_verse_count']==bt['chanted_verse_count']==9 and at['ungrammatical_count']==bt['ungrammatical_count']==1
assert sum(w=='mun-mun' for v in bt['chanted_verses'] for w in v['words'])==2
issues=[]
for name,tree,expected in [('stress','gh-pages/stress-helpers',4),('wlc','gh-pages/wlc',11)]:
 lines=(E/('html-'+name+'.txt')).read_text().splitlines();found=[x for x in lines if x.startswith(('orphan image: ','unexpected file type: '))];assert len(found)==expected
 for line in found:
  p=tree+'/'+line.split(': ',1)[1];assert g(B,p)==g(H,p);issues.append(dict(finding=line,path=p,unchanged_blob=subprocess.check_output(['git','rev-parse',H+':'+p],cwd=R).decode().strip()))
assert g(B,'py/check_html_syntax_and_sanity.py')==g(H,'py/check_html_syntax_and_sanity.py')
assert g(B,'gh-pages/stress-helpers/controls.js')==g(H,'gh-pages/stress-helpers/controls.js')
paths=['gh-pages/stress-helpers/index.html','gh-pages/wlc/accgram/printed-decalogue-koren.html','gh-pages/wlc/accgram/printed-decalogue-simanim.html','gh-pages/wlc/accgram/maqaf-nonfinal-accents.html'];changes=[]
for p in paths:
 aa=Counter(html.document_fromstring(g(B,p)).xpath('//img/@src'));bb=Counter(html.document_fromstring(g(H,p)).xpath('//img/@src'));assert aa==bb
 changes.append(dict(path=p,img_src_counts_preserved=True))
result=dict(base=B,source=H,only_derived_transcription_changed=changed[0][0],all_other11_transcriptions_and_top_level_values_exact=True,chanted_verses=9,ungrammatical_verses=1,mun_mun_compounds=2,checker_and_controls_unchanged=True,all15_finding_files_byte_identical_to_base=True,image_inventories_preserved=changes,findings=issues)
(E/'derived-and-findings-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('findings','image_inventories_preserved')},indent=2))

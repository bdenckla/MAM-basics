# Reviewer diagnostics and scope

The first preservation probe assumed the transcription JSON's key was bands; it is lines.
The original helper and tool-returned diagnostic are retained. The corrected probe also
uses the actual Hebrew span selector and the committed abbreviation/conclusion IDs; these
corrections were made before its passing execution. No product changed.

The first derived/image probe passed its derived-data and historical-finding assertions,
then assumed every page's image count stayed equal. The maqaf page intentionally adds a
fourth case and one reference to the already committed Koren Dt 5:6 crop. Its original
helper/error are retained. The corrected check pins precisely that one additional reference,
unchanged PNG bytes, 572x170 dimensions and bounded highlight rectangle; the other three
pages retain exact image populations. This is geometric consistency, not pixel/source proof.

A provisional conclusion-consistency concern was withdrawn on reading the page's explicit
comparison rule (MAQAF_IS_THE_LAST_RUNG): exchanging maqaf and a conjunctive counts as one
difference at the lowest rung, rather than counting regrouping and accent addition twice.
The corrected יהיה position is that exchange. Its extra raw token therefore does not
contradict the page's last-rung statement; no introduced defect was established and no
editorial/source decision was changed. Source prose and current data were both considered.

No generator or test was rerun to recover lost tool output: completed stage records and logs
were read back. All original diagnostics are retained. No product restoration was needed.

import json,os,subprocess,time
from datetime import datetime,timezone
from pathlib import Path
r=Path('/workspace/scratch/hourly-333f8e89-public');s=r/'source';e=r/'evidence';p='/workspace/MAM-basics/.venv/bin/python'
changed=[x.decode() for x in subprocess.check_output(['git','diff','--name-only','-z','f996f75630e19241d055215450165bd1da5fed80','333f8e899688ff9a34f72ca3cb2c19d4a5bdac5c','--','*.py'],cwd=s).split(b'\0') if x]
tests=['test_edition_transcriptions.py','test_printed_decalogue_koren.py','test_printed_decalogue_simanim.py','test_printed_decalogue_page.py','test_maqaf_nonfinal_accents_page.py','test_transliterations.py','test_prose_conventions.py','test_prose_mark_order.py','test_shared_html_styles.py','test_site_links_relative.py','test_site_index_links.py','test_h_dot_below_nfc.py']
steps=[('diff-check',['git','diff','--check','f996f75630e19241d055215450165bd1da5fed80','333f8e899688ff9a34f72ca3cb2c19d4a5bdac5c']),('black',[p,'-m','black','--check',*changed]),('derive-transcription',[p,'py/main_edition_transcription.py','build','koren_dt_elyon','--derive-only']),('printed-results',[p,'py/main_accgram.py','run-printed-decalogue']),('gen-koren',[p,'py/main_accgram.py','generate-html-printed-decalogue-koren']),('gen-simanim',[p,'py/main_accgram.py','generate-html-printed-decalogue-simanim']),('gen-maqaf',[p,'py/main_accgram.py','generate-html-maqaf-nonfinal-accents']),('gen-site',[p,'py/main_authored.py','gen-site','--trust-surveys']),('focused-tests',[p,'py/main_test.py',*('py/tests/'+x for x in tests),'-q','-ra'])]
records=[]
for name,cmd in steps:
 start=time.monotonic();record=dict(name=name,command=cmd,cwd=str(s),start_utc=datetime.now(timezone.utc).isoformat())
 run=subprocess.run(cmd,cwd=s,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (e/(name+'.txt')).write_bytes(run.stdout)
 status=subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=s);diff=subprocess.check_output(['git','diff','--binary'],cwd=s)
 (e/(name+'-post-status.bin')).write_bytes(status);(e/(name+'-post.diff')).write_bytes(diff)
 record.update(exit=run.returncode,wall_seconds=round(time.monotonic()-start,6),status_bytes=len(status),diff_bytes=len(diff));records.append(record)
 (e/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(record),flush=True)
 if run.returncode or status or diff:
  print(run.stdout.decode('utf-8',errors='replace'));raise SystemExit(1)

import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

root = Path('/workspace/review-hourly-20261028-notes-resume-basics')
out = Path(__file__).parent
paths = subprocess.check_output(['git','diff','--name-only','-z'],cwd=root).decode().split('\0')[:-1]
allowed = {'width','height','viewBox','transform','points','x','y','d','cx','cy','rx','ry'}
records = []
for p in paths:
    assert p.startswith('gh-pages/MAM-parsed/plus/svg/') and p.endswith('.svg'), p
    before = subprocess.check_output(['git','show','HEAD:'+p],cwd=root)
    after = (root/p).read_bytes()
    (out / ('committed-' + Path(p).name)).write_bytes(before)
    (out / ('generated-' + Path(p).name)).write_bytes(after)
    a, b = list(ET.fromstring(before).iter()), list(ET.fromstring(after).iter())
    assert len(a) == len(b), p
    changed = set()
    for x, y in zip(a,b):
        assert x.tag == y.tag and x.text == y.text and x.tail == y.tail, p
        assert x.attrib.keys() == y.attrib.keys(), p
        for k in x.attrib:
            if x.attrib[k] != y.attrib[k]:
                assert k in allowed or (k == 'font-family' and (x.attrib[k], y.attrib[k]) == ('Times New Roman,serif','Times,serif')), (p,k)
                changed.add(k)
    records.append({'path':p,'element_count':len(a),'changed_geometry_attributes':sorted(changed),
        'tags_text_tails_attribute_keys_and_all_values_except_geometry_and_exact_Times_alias_equal':True})
(out/'svg-comparison.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
assert len(paths)==6
subprocess.run(['git','restore','--source=HEAD','--',*paths],cwd=root,check=True)
print(json.dumps(records,indent=2))

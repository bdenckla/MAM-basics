"""Resume exactly the recorded public stages, synchronously, from frozen input."""
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import time

source = Path('/workspace/review-hourly-20261028-notes-resume-basics')
evidence = Path('/workspace/scratch/review-hourly-20261028-notes-resume-basics')
python = '/workspace/MAM-basics/.venv/bin/python'
tip = '6835873fcb2ba63afec21846e5fc65f730e7757a'
raw = subprocess.check_output(['git', '-C', str(source), 'show', '23be8cf6536f5b4c364b0245705d71a397cfb10a:doc/review-hourly-2026-10-28-note-refresh-partial.json'])
commands = json.loads(raw)['pending_stages_in_order']
assert subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True, encoding='utf-8').strip() == tip
assert not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain=v1', '-z'])
for i, args in enumerate(commands, 1):
    if i < 13:
        continue  # Completed stages remain preserved; do not repeat them.
    args = ['Deuter' if s == 'Deuteronomy' else s for s in args]
    args = [str(evidence / 'endpoint.html') if s == '<absolute-owned-scratch>/endpoint.html' else s for s in args]
    label = f'{i:02d}-' + (args[0].split('/')[-1].removesuffix('.py')) + ('-' + args[-1] if '--book39' in args else '')
    if i == 12:
        label = '12b-main_tmpl_survey-pinned-graphviz'
    assert not (evidence / (label + '.json')).exists(), label
    started, clock = datetime.now(timezone.utc).isoformat(), time.monotonic()
    print('START ' + label + ' ' + started, flush=True)
    process = subprocess.run([python, *args], cwd=source, capture_output=True, text=True, encoding='utf-8')
    status = subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain=v1', '-z']).decode()
    record = {'name': label, 'source_commit': tip, 'cwd': str(source), 'command': [python, *args],
        'started_utc': started, 'completed_utc': datetime.now(timezone.utc).isoformat(),
        'seconds': round(time.monotonic()-clock, 3), 'exit_code': process.returncode, 'tracked_status_after': status}
    (evidence / (label + '.log')).write_text(process.stdout + process.stderr, encoding='utf-8')
    (evidence / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print('END ' + json.dumps(record), flush=True)
    print((process.stdout + process.stderr)[-1100:], flush=True)
    if process.returncode or status:
        (evidence / 'stopped.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
        if status:
            (evidence / (label + '.patch')).write_bytes(subprocess.check_output(['git', '-C', str(source), 'diff', '--binary']))
        raise SystemExit('Stopped for focused result/diff triage; subsequent stages were not run')
print('Remaining public stages completed sequentially; earlier attempt logs retained.', flush=True)

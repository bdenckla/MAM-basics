const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const started=performance.now(),models=JSON.parse(fs.readFileSync(path.join(__dirname,'control-models.json'),'utf8'));
const code=fs.readFileSync(path.join(__dirname,'../source/gh-pages/stress-helpers/controls.js'),'utf8');
function el(value=''){return {value,defaultValue:value,textContent:'',hidden:false,attributes:{},handlers:{},addEventListener(e,f){this.handlers[e]=f},getAttribute(n){return this.attributes[n]},setAttribute(n,v){this.attributes[n]=String(v)}}}
function key(s){return s.toLowerCase().replace(/[\u0591-\u05bd\u05bf-\u05c7]/g,'')}
const reports=[];
for(const m of models){
 const elems=Object.fromEntries(['hebrew-size','size-value','size-reset','find','filter','batch','visible','toggle-images'].map(id=>['#'+id,el(id==='hebrew-size'?'30':'')]));
 for(const [id,list]of [['#filter',m.options],['#batch',m.batches]])elems[id].options=list.map(o=>({...el(o.value),textContent:o.text,dataset:{label:o.label},disabled:false}));
 elems['#toggle-images'].attributes['aria-expanded']='false';
 const rows=m.rows.map(r=>({dataset:{filter:r.filter,batch:r.batch},cells:r.cells.map(textContent=>({textContent})),hidden:false}));
 const scans=Array.from({length:m.scans},()=>({hidden:true})),style={};
 const document={documentElement:{style:{setProperty(n,v){style[n]=v}}},querySelector(s){assert.ok(s in elems,s);return elems[s]},querySelectorAll(s){if(s==='#observations tbody tr')return rows;if(s==='#observations .scan')return scans;throw Error(s)}};
 vm.runInNewContext(code,{document},{timeout:1000});
 assert.equal(style['--hebrew-size'],'30px');assert.equal(elems['#visible'].textContent,`${rows.length} differences`);
 elems['#hebrew-size'].value='48';elems['#hebrew-size'].handlers.input();assert.equal(style['--hebrew-size'],'48px');elems['#size-reset'].handlers.click();assert.equal(style['--hebrew-size'],'30px');
 const queries=['','NO-MATCH-409581762','  DEUT  ','Deut 33:21','וַיֵּ֙תֶא֙',key('וַיֵּ֙תֶא֙')];let states=0,menuChecks=0;
 const menu=elems['#filter'],batch=elems['#batch'],input=elems['#find'];
 function checkMenu(target,field,other,otherField){
  const pool=m.rows.filter(r=>!other.value||r[otherField]===other.value);
  for(const o of target.options){const n=pool.filter(r=>!o.value||r[field]===o.value).length;assert.equal(o.textContent,`${o.dataset.label} (${n})`);assert.equal(o.disabled,o.value!==''&&n===0);menuChecks++;}
 }
 for(let round=0;round<2;round++)for(const bo of [...batch.options].reverse())for(const fo of round?[...menu.options].reverse():menu.options){
  menu.value=fo.value;batch.value=bo.value;menu.handlers.change();batch.handlers.change();
  checkMenu(menu,'filter',batch,'batch');checkMenu(batch,'batch',menu,'filter');
  const counts=JSON.stringify([menu.options,batch.options].map(a=>a.map(o=>[o.textContent,o.disabled])));
  for(const q of queries){
   input.value=q;input.handlers.input();const query=key(q.trim());
   const want=m.rows.map(r=>(!menu.value||r.filter===menu.value)&&(!batch.value||r.batch===batch.value)&&r.cells.some(s=>key(s).includes(query)));
   assert.deepEqual(rows.map(r=>!r.hidden),want);
   const n=want.filter(Boolean).length;assert.equal(elems['#visible'].textContent,n+(n===1?' difference':' differences'));
   assert.equal(JSON.stringify([menu.options,batch.options].map(a=>a.map(o=>[o.textContent,o.disabled]))),counts);states++;
  }
 }
 const visibility=rows.map(r=>!r.hidden);elems['#toggle-images'].handlers.click();assert.ok(scans.every(x=>!x.hidden));assert.equal(elems['#toggle-images'].attributes['aria-expanded'],'true');assert.deepEqual(rows.map(r=>!r.hidden),visibility);elems['#toggle-images'].handlers.click();assert.ok(scans.every(x=>x.hidden));
 reports.push({page:m.name,rows:rows.length,filter_options:menu.options.length,batch_options:batch.options.length,filter_batch_search_states:states,menu_count_disabled_checks:menuChecks,search_keeps_menu_counts:true,image_toggle_and_size_reset:true});
}
console.log(JSON.stringify({method:'Actual committed controls.js in an offline DOM adapter; not browser/layout/visual evidence',reports,elapsed_seconds:(performance.now()-started)/1000},null,2));

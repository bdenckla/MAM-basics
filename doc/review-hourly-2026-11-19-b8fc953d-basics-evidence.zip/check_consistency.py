from pathlib import Path
from collections import Counter
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
from functools import lru_cache
import subprocess,json,copy,re,hashlib,time
R=Path('/workspace/scratch/hourly-b8fc953d-public');C=R/'source';E=R/'evidence';O='67a6ec467ba0cf078e9790760a2ee8452f722382';N='b8fc953d492d9f6102849b6f1230bbdaebf4276a'
@lru_cache(None)
def raw(r,p):return subprocess.check_output(['git','-C',str(C),'show',r+':'+p])
def js(r,p):return json.loads(raw(r,p))
def gitpaths(*args):return [s.decode() for s in subprocess.check_output(['git','-C',str(C),*args]).split(b'\0') if s]
def identity(d):return tuple(d.get(k) for k in ['book','chapter','verse','atom','strand','location','mam','category','batch'])
def ref(d):return(d['book'],d['chapter'],d['verse'])
expected={('Joshua',7,7),('1Samuel',17,37),('1Samuel',17,39),('1Samuel',26,15),('2Samuel',19,31),('2Kings',9,36),('Isaiah',10,16),('Isaiah',39,2),('Jeremiah',21,10),('Jeremiah',40,15),('Ezekiel',13,19),('Ezekiel',14,16),('Amos',6,10),('2Chronicles',20,27)}
changedrecords={};deleted=[];summary={};start=time.perf_counter()
for edition,before,after in [('koren',88,74),('simanim-tanakh',37,23)]:
 p='in/stress-helpers/'+edition+'.json';x,y=js(O,p),js(N,p);assert {k:v for k,v in x.items() if k!='differences'}=={k:v for k,v in y.items() if k!='differences'}
 aa,bb=x['differences'],y['differences'];assert len(aa)==before and len(bb)==after
 a,b={identity(d):d for d in aa},{identity(d):d for d in bb};assert len(a)==len(aa) and len(b)==len(bb)
 assert not b.keys()-a.keys();removed=[d for d in aa if identity(d) not in b];assert len(removed)==14 and {ref(d)for d in removed}==expected
 assert [identity(d)for d in aa if identity(d)in b]==[identity(d)for d in bb]
 changes=[(d,b[identity(d)])for d in aa if identity(d)in b and d!=b[identity(d)]]
 if edition=='simanim-tanakh':assert not changes
 else:
  assert {ref(d)for d,_ in changes}=={('Deuter',33,21),('Judges',18,19),('Ezekiel',19,9)}
  for d,new in changes:
   fields={k for k in d if d[k]!=new[k]};assert fields==({'notes','printed'}if ref(d)==('Deuter',33,21)else{'notes'})
  deuterold,deuternew=next((d,n)for d,n in changes if ref(d)==('Deuter',33,21))
  u,v=deuterold['printed'],deuternew['printed'];assert len(u)==len(v)
  at=[i for i,(a,b)in enumerate(zip(u,v))if a!=b];assert len(at)==2 and {u[i]for i in at}=={v[i]for i in at}=={'\u05b5','\u05b6'}
  def cluster(word,letter):
   n=word.index(letter)+1;return re.match(r'[\u0591-\u05c7\u034f]*',word[n:])[0]
  assert '\u05b5'in cluster(v,'י') and '\u05b6'in cluster(v,'ת')
  book=js(N,'MAM-parsed/plus/A5-Deuter.json')['book39s'][0]['chapters']['33']['21']
  def strings(x):
   if isinstance(x,str):return[x]
   if isinstance(x,list):return[s for v in x for s in strings(v)]
   if isinstance(x,dict):return[s for v in x.values()for s in strings(v)]
   return[]
  assert any('קורן'in s and v in s for s in strings(book))
  changedrecords={ref(n):n for _,n in changes}
 deleted.extend(c for d in removed for c in d['crops'])
 summary[edition]={'old':before,'new':after,'removed':14,'retained_order_exact':True,'changed_retained_records':len(changes)}
removedpaths=gitpaths('diff','--name-only','--diff-filter=D','-z',O,N)
assert len(deleted)==len(set(deleted))==len(removedpaths)==28
assert {'gh-pages/stress-helpers/'+p for p in deleted}==set(removedpaths)
patterns=E/'removed-crop-patterns.txt';patterns.write_text('\n'.join(Path(p).name for p in deleted)+'\n')
query=subprocess.run(['git','-C',str(C),'grep','-I','-F','-l','-z','-f',str(patterns),'HEAD','--'],capture_output=True)
assert query.returncode==1 and not query.stdout and not query.stderr
# Only the two intended Python files differ, exactly as in the retained repair commit.
for p in ['py/main_uxlc_grammar_test.py','py/tests/test_uxlc_numbered_atom_ownership.py']:assert raw('062da1e80a1e725b1dd176a9b9d3e9c18a1b6076',p)==raw(N,p)
assert gitpaths('diff','--name-only','-z',O,N,'--','py')==['py/main_uxlc_grammar_test.py','py/tests/test_uxlc_numbered_atom_ownership.py']
assert not gitpaths('diff','--name-only','-z',O,N,'--','gh-pages/stress-helpers/controls.js','gh-pages/stress-helpers/style.css','MAM-parsed','MAM-simple','Taamey-D','out/accgram/uxlc_grammar_test.txt')
class Tree(HTMLParser):
 def __init__(self,s):super().__init__(convert_charrefs=True);self.root=['ROOT',{},[]];self.stack=[self.root];self.feed(s)
 def handle_starttag(self,t,a):
  n=[t,dict(a),[]];self.stack[-1][2].append(n)
  if t not in {'meta','link','img','br','hr','input','wbr','source','area','base','embed'}:self.stack.append(n)
 def handle_startendtag(self,t,a):self.handle_starttag(t,a);self.handle_endtag(t)
 def handle_endtag(self,t):
  for i in range(len(self.stack)-1,0,-1):
   if self.stack[i][0]==t:self.stack=self.stack[:i];break
 def handle_data(self,s):self.stack[-1][2].append(s)
def nodes(n):
 if isinstance(n,list):
  yield n
  for c in n[2]:yield from nodes(c)
def text(n):return n if isinstance(n,str)else''.join(text(c)for c in n[2])
def norm(n):
 if isinstance(n,str):return re.sub(r'\s+',' ',n)
 return(n[0],n[1],tuple(norm(c)for c in n[2]))
def rows(t):return[n for n in nodes(t.root)if n[0]=='tr' and 'data-batch'in n[1]]
def cropkey(row):return tuple(n[1]['src']for n in nodes(row)if n[0]=='img')
def hebrew(n):return''.join(re.findall(r'[\u0590-\u05ff\u034f]',text(n)))
path='gh-pages/stress-helpers/index.html';old,new=(Tree(raw(r,path).decode())for r in [O,N]);a,b=rows(old),rows(new);assert len(a)==93 and len(b)==79
ak,bk={cropkey(t):t for t in a},{cropkey(t):t for t in b};assert len(ak)==93 and len(bk)==79
assert [cropkey(t)for t in a if cropkey(t)in bk]==[cropkey(t)for t in b]
assert len(ak.keys()-bk.keys())==14
for k in ak.keys()-bk.keys():assert all(Path(src).name in{Path(p).name for p in deleted}for src in k)
changedrows=[k for k in bk if norm(ak[k])!=norm(bk[k])];assert len(changedrows)==3
for k in changedrows:
 if 'img/koren-deuter-33-21-A5-D-326-note-1.png'in k:
  assert hebrew(ak[k]).replace(deuterold['printed'],deuternew['printed'])==hebrew(bk[k])
 else:assert hebrew(ak[k])==hebrew(bk[k])
assert sum(norm(ak[k])==norm(bk[k])for k in bk)==76
assert Counter(x[1]['data-batch']for x in a)=={'1':37,'2':56};assert Counter(x[1]['data-batch']for x in b)=={'1':36,'2':43}
models=[]
for label,t,rs in [('before',old,a),('current',new,b)]:
 selects={n[1]['id']:n for n in nodes(t.root)if n[0]=='select'}
 def choices(id):return[{'value':n[1]['value'],'label':n[1]['data-label'],'text':text(n)}for n in nodes(selects[id])if n[0]=='option']
 options,batches=choices('filter'),choices('batch')
 for option in options:assert int(re.search(r'\((\d+)\)$',option['text'])[1])==sum(not option['value']or r[1]['data-filter']==option['value']for r in rs)
 for option in batches:assert int(re.search(r'\((\d+)\)$',option['text'])[1])==sum(not option['value']or r[1]['data-batch']==option['value']for r in rs)
 models.append({'name':label,'rows':[{'filter':r[1]['data-filter'],'batch':r[1]['data-batch'],'cells':[text(c)for c in r[2]if isinstance(c,list)and c[0]in ['td','th']]}for r in rs],'options':options,'batches':batches,'scans':sum(n[1].get('class')=='scan'for n in nodes(t.root))})
assert {x['value']for x in models[0]['options']}-{x['value']for x in models[1]['options']}=={'extra-helper-KorSim','different-placement-KorSim'}
assert not {x['value']for x in models[1]['options']}-{x['value']for x in models[0]['options']}
# Resolve current local link destinations/fragments without any network request.
cache={};links=0
for n in nodes(new.root):
 for attr in ['href','src']:
  val=n[1].get(attr)
  if not val:continue
  z=urlsplit(val)
  if z.scheme or z.netloc:continue
  dest=((C/path).parent/unquote(z.path)).resolve()if z.path else C/path
  assert dest.is_relative_to(C)and dest.is_file(),val
  if z.fragment and dest.suffix=='.html':
   if dest not in cache:cache[dest]={x[1]['id']for x in nodes(Tree(dest.read_text()).root)if'id'in x[1]}
   assert unquote(z.fragment)in cache[dest],val
  links+=1
assert any(n[1].get('href')=='../MAM-with-doc/B2-Judges.html#c18v19'for n in nodes(new.root))
assert any(n[1].get('href')=='../MAM-with-doc/C3-Ezekiel-big-doc.html#c19v9doc1'for n in nodes(new.root))
(E/'control-models.json').write_text(json.dumps(models,ensure_ascii=False,indent=2)+'\n')
report={'source':N,'base':O,'inventory_paths':len(gitpaths('diff','--name-only','-z',O,N)),'editions':summary,'removed_verses':sorted(expected),'removed_crops':28,'remaining_tracked_references':0,'old_rows':93,'new_rows':79,'batches_before':{'1':37,'2':56},'batches_after':{'1':36,'2':43},'unchanged_remaining_rows':76,'intended_changed_remaining_rows':3,'vowel_swap':{'old':deuterold['printed'],'new':deuternew['printed'],'all_other_codepoints_exact':True,'current_MAM_note_literal_agreement':True},'resolving_local_link_occurrences':links,'new_note_links_resolve':True,'unchanged_controls_styles_and_source_data':True,'repair_files_identical_to_062da1e8':True,'elapsed_seconds':round(time.perf_counter()-start,6),'passed':True}
(E/'consistency.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2))

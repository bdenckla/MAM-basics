from pathlib import Path
from datetime import datetime,timezone
import os,json,subprocess,time
R=Path('/workspace/scratch/hourly-b8fc953d-public');C=R/'source';E=R/'evidence';PY='/workspace/MAM-basics/.venv/bin/python'
def g(*a):return subprocess.check_output(['git','-C',str(C),*a])
assert not (E/'commands.json').exists()
assert g('rev-parse','HEAD').decode().strip()=='b8fc953d492d9f6102849b6f1230bbdaebf4276a' and not g('status','--porcelain=v1','-z')
records=[];env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUNBUFFERED='1');assert not env.get('PYTHONPATH')
commands=[('diff-check',['git','diff','--check','67a6ec467ba0cf078e9790760a2ee8452f722382','b8fc953d492d9f6102849b6f1230bbdaebf4276a']),('black',[PY,'-m','black','--check','py/main_uxlc_grammar_test.py','py/tests/test_uxlc_numbered_atom_ownership.py']),('gen-site',[PY,'py/main_authored.py','gen-site','--trust-surveys']),('uxlc-direct-report',[PY,'py/main_uxlc_grammar_test.py']),('focused-tests',[PY,'py/main_test.py','py/tests/test_uxlc_numbered_atom_ownership.py','py/tests/test_lexical_validation.py','py/tests/test_site_links_relative.py','py/tests/test_shared_html_styles.py','py/tests/test_prose_conventions.py','py/tests/test_receipt_update_links.py','-q','-ra']),('stress-html',[PY,'py/check_html_syntax_and_sanity.py','gh-pages/stress-helpers'])]
for label,argv in commands:
 assert not g('status','--porcelain=v1','-z')
 t=time.perf_counter();start=datetime.now(timezone.utc).isoformat()
 with (E/(label+'.log')).open('xb') as f:p=subprocess.run(argv,cwd=C,env=env,stdout=f,stderr=subprocess.STDOUT)
 status=g('status','--porcelain=v1','--untracked-files=all','-z');diff=g('diff','HEAD','--binary')
 (E/(label+'-status.z')).write_bytes(status);(E/(label+'-diff.patch')).write_bytes(diff)
 row={'stage':label,'argv':argv,'cwd':str(C),'started_utc':start,'finished_utc':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':round(time.perf_counter()-t,6),'exit':p.returncode,'status_clean':not status,'diff_empty':not diff}
 records.append(row);(E/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
 if status or (p.returncode and label!='stress-html'):raise SystemExit('Preserved unexpected result, stop for triage')

import datetime
import json
import pathlib
import subprocess
import sys
import time

root = pathlib.Path('/workspace/scratch/basics-22daa1f9')
cwd = root / 'source'
name, *command = sys.argv[1:]
assert command
assert subprocess.check_output(['git', '-C', str(cwd), 'rev-parse', 'HEAD'], text=True).strip() == '22daa1f996e4de925d7e2deab35b237f537a8fa7'
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
t0 = time.monotonic()
with (root / 'evidence' / (name + '.txt')).open('wb') as log:
    result = subprocess.run(command, cwd=cwd, stdout=log, stderr=subprocess.STDOUT)
data = dict(command=command, cwd=str(cwd), started_utc=start, seconds=round(time.monotonic()-t0,6), exit=result.returncode)
(root / 'evidence' / (name + '.json')).write_text(json.dumps(data, indent=2)+'\n', encoding='utf-8', newline='\n')
(root / 'evidence' / (name + '-tracked.diff')).write_bytes(subprocess.check_output(['git','-C',str(cwd),'diff','--binary']))
(root / 'evidence' / (name + '-status.z')).write_bytes(subprocess.check_output(['git','-C',str(cwd),'status','--porcelain=v1','-z']))
print(json.dumps(data))
print((root / 'evidence' / (name + '.txt')).read_text(encoding='utf-8')[-4500:])
sys.exit(result.returncode)

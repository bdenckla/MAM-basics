from collections import Counter
from copy import deepcopy
import json
import pathlib
import re
import subprocess
from urllib.parse import unquote, urlsplit

from lxml import html

root=pathlib.Path('/workspace/scratch/basics-22daa1f9/source')
out=root.parent/'evidence'
base='3691d51b619e47c003c671a0ec9cd8efe3c46706'
end='22daa1f996e4de925d7e2deab35b237f537a8fa7'
def git(*args):
    return subprocess.check_output(['git','-C',str(root),*args])
def text(n):
    return ' '.join(n.text_content().split())
def parse(rel):
    return html.fromstring((root/rel).read_bytes())
report={}
index=parse('gh-pages/stress-helpers/index.html')
old=html.fromstring(git('show',base+':gh-pages/stress-helpers/index.html'))
new=html.fromstring(git('show',end+':gh-pages/stress-helpers/index.html'))
notes=new.xpath('//p[a[@href="results.html"]]')
assert len(notes)==1 and text(notes[0])=='The complete comparison gives the census and findings by verse. Full results'
new_raw=git('show',end+':gh-pages/stress-helpers/index.html')
old_raw=git('show',base+':gh-pages/stress-helpers/index.html')
inserted=b'<p>The complete comparison gives the census and findings by verse. <a href="results.html">Full results</a></p>\n'
assert new_raw.count(inserted)==1 and new_raw.replace(inserted,b'',1)==old_raw
common=json.loads((root/'in/stress-helpers/common.json').read_bytes())
old_common=json.loads(git('show',base+':in/stress-helpers/common.json'))
assert common['source_notes'][1:]==old_common['source_notes']
assert common['coverage']==old_common['coverage']
page=parse('gh-pages/stress-helpers/results.html')
ids=page.xpath('//*[@id]/@id')
assert len(ids)==len(set(ids))
links=[]
for rel in ['gh-pages/stress-helpers/index.html','gh-pages/stress-helpers/results.html']:
    doc=parse(rel)
    for value in doc.xpath('//@href|//@src'):
        u=urlsplit(value)
        if u.scheme or u.netloc:
            continue
        target=(root/rel).parent / unquote(u.path) if u.path else root/rel
        target=target.resolve()
        assert target.is_relative_to(root/'gh-pages') and target.is_file(), (rel,value)
        if u.fragment and target.suffix=='.html':
            assert parse(str(target.relative_to(root))).xpath('//*[@id=$key]',key=unquote(u.fragment)),(rel,value)
        links.append([rel,value])
tables=page.xpath('//table')
assert len(tables)==5
rows=tables[0].xpath('./tbody/tr')
numbers=[[int(text(x).replace(',','')) for x in row.xpath('./td')] for row in rows]
assert all(a+b==c for a,b,c in numbers)
assert [sum(col) for col in zip(*numbers[:-1])]==numbers[-1]==[5515,20154,25669]
comparison=[[int(text(x).replace(',','')) for x in row.xpath('./td')] for row in tables[1].xpath('./tbody/tr')]
assert [sum(col) for col in zip(*comparison[:5])]==[25669,25669]
assert comparison[-2]==[4,0] and comparison[-1]==[42,6]
detail_rows=[t.xpath('./tbody/tr') for t in tables[2:]]
detail_counts=[]
for rows in detail_rows:
    detail_counts.append(dict(rows=len(rows),koren=sum(text(r.xpath('./td')[1])!='—' for r in rows),simanim=sum(text(r.xpath('./td')[2])!='—' for r in rows)))
assert detail_counts[0]['koren']==92 and detail_counts[0]['simanim']==39,detail_counts
assert detail_counts[1]['koren']==42 and detail_counts[1]['simanim']==6,detail_counts
assert detail_counts[2]==dict(rows=9,koren=3,simanim=6)
# Check every displayed primary MAM form against its named committed public verse,
# dropping ketiv text when the displayed qere is the reading. No normalization.
names={
 'Gen':'A1-Genesis','Exod':'A2-Exodus','Lev':'A3-Levit','Num':'A4-Numbers','Deut':'A5-Deuter','Josh':'B1-Joshua','Judg':'B2-Judges',
 '1 Sam':'BA-1Samuel','2 Sam':'BB-2Samuel','1 Kgs':'BC-1Kings','2 Kgs':'BD-2Kings','Isa':'C1-Isaiah','Jer':'C2-Jeremiah','Ezek':'C3-Ezekiel',
 'Hos':'CA-Hosea','Joel':'CB-Joel','Amos':'CC-Amos','Obad':'CD-Obadiah','Jonah':'CE-Jonah','Mic':'CF-Micah','Nah':'CG-Nahum','Hab':'CH-Habakkuk','Zeph':'CI-Tsefaniah','Hag':'CJ-Haggai','Zech':'CK-Zechariah','Mal':'CL-Malachi',
 'Job':'D3-Job','Song of Songs':'E1-Song of Songs','Ruth':'E2-Ruth','Daniel':'F1-Daniel','Ezra':'FA-Ezra','Neh':'FB-Nehemiah','1 Chr':'FC-1Chronicles','2 Chr':'FD-2Chronicles'
}
files=sorted((root/'gh-pages/MAM-with-doc').glob('*.html'))
actual={p.stem:p for p in files}
cache={}
simple={}
for p in (root/'MAM-simple/json-vtrad-mam').glob('*.json'):
    data=json.loads(p.read_bytes())
    for b in data['contents']:
        assert b['type']=='book39'
        for c in b['contents']:
            if c['type'].startswith('spi-'): continue
            assert c['type']=='chapter'
            for v in c['contents']:
                if v['type'].startswith('spi-'): continue
                assert v['type']=='verse'
                simple[v['osisID']]=v
def projected(n,side,strand):
    kind=n['type']
    if kind=='cant-all-three':
        kids=n['contents']
        assert [k['type'] for k in kids]==['cant-combined','cant-alef','cant-bet']
        return projected(next(k for k in kids if k['type']==strand),side,strand)
    if kind=='kq':
        assert sorted(k['type'] for k in n['contents'])==['kq-k','kq-q']
        return projected(next(k for k in n['contents'] if k['type']=='kq-'+side),side,strand)
    if kind=='scrdfftar':
        return projected(next(k for k in n['contents'] if k['type']=='sdt-target'),side,strand)
    if kind=='slh-word': return n['slhw-desc-0']
    if kind in ['lp-legarmeih','lp-paseq']: return '\N{HEBREW PUNCTUATION PASEQ}'
    if kind=='implicit-maqaf': return '\N{HEBREW PUNCTUATION MAQAF}'
    if kind in ['kq-k-velo-q','kq-q-velo-k']:
        return n['text'] if (side=='k')==(kind=='kq-k-velo-q') else ' '
    if kind=='kq-k-velo-q-maq': return '\N{HEBREW PUNCTUATION MAQAF}' if side=='k' else ''
    if kind in ['shirah-space','spi-pe2','spi-pe3','spi-samekh2','spi-samekh3']: return ' '
    if kind=='spi-invnun': return '\N{HEBREW PUNCTUATION NUN HAFUKHA}'
    if kind=='good-ending': return ''
    assert kind in ['verse','text','silluq-before-meteg','kq-trivial','sdt-target','kq-k','kq-q','cant-alef','cant-bet','cant-combined'],kind
    if 'text' in n: return n['text']
    return ''.join(projected(k,side,strand) for k in n['contents'])
matches=[]
unmatched=[]
for table_num,rows in enumerate(detail_rows):
    for row in rows:
        form=text(row.xpath('./td')[0])
        refnode=row.xpath('./th')[0]
        ref=refnode.text.strip()
        m=re.fullmatch(r'(.+) (\d+):(\d+)',ref)
        assert m,ref
        book,ch,vs=m.groups()
        key=names.get(book)
        if key not in actual:
            unmatched.append(dict(table=table_num,reference=ref,form=form,reason='unmapped file',key=key))
            continue
        if key not in cache: cache[key]=parse(str(actual[key].relative_to(root)))
        node=cache[key].xpath('//*[@id=$key]',key=f'c{ch}v{vs}')
        assert len(node)==1,(ref,key)
        vr=deepcopy(node[0].getparent())
        for ketiv in vr.xpath('.//span[@class="mam-kq-k"]'):
            ketiv.drop_tree()
        source='body/qere'
        found=form in text(vr).replace('[','').replace(']','')
        if not found:
            osis=book.replace(' ','')
            v=simple.get(f'{osis}.{ch}.{vs}')
            if v:
                found=any(form in projected(v,side,strand) for side in ['k','q'] for strand in ['cant-alef','cant-bet'])
                source='explicit MAM-simple side/strand'
        if not found and (p:=actual.get(key+'-big-doc')):
            doc=parse(str(p.relative_to(root)))
            anchors=doc.xpath('//*[starts-with(@id,$prefix)]',prefix=f'c{ch}v{vs}doc')
            found=any(form in text(a.xpath('following::ul[1]')[0]) for a in anchors if a.xpath('following::ul[1]'))
            source='verse documentation clause'
        if found: matches.append(dict(table=table_num,reference=ref,form=form,source=source))
        else: unmatched.append(dict(table=table_num,reference=ref,form=form,reason='not in body/qere or explicit strands or verse notes'))
report=dict(tables=5,census_rows=numbers,comparison_rows=comparison,detail_counts=detail_counts,local_link_occurrences=len(links),matched_forms=len(matches),unmatched=unmatched,rows=matches)
(out/'page-consistency.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='rows'},ensure_ascii=False,indent=2))

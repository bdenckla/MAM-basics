from collections import Counter
import json
import pathlib
import re
import subprocess
from urllib.parse import urlsplit,parse_qs

root=pathlib.Path('/workspace/scratch/basics-22daa1f9/source')
folder=root/'bhsa-corrections'
out=root.parent/'evidence'
def read(rel): return json.loads((folder/rel).read_bytes())
log=[json.loads(x) for x in (folder/'in/fetch_log.jsonl').read_bytes().splitlines()]
listing=read('in/etcbc-bhsa-tf2021-listing.json')
entries={v['name']:v for v in listing}
assert len(entries)==118 and sum(n.endswith('.tf') for n in entries)==117
assert len(read('in/etcbc-bhsa-tf-listing.json'))==7
raw=[v for v in log if v['kind']=='raw']
polite=[v for v in log if v['kind']=='polite']
assert len(raw)==32 and len(polite)==12
for v in raw:
    url=urlsplit(v['api_path'])
    assert parse_qs(url.query)=={'ref':['4db00e2157915495e1a4d3d57e41223df24775da']}
    row=entries[pathlib.PurePosixPath(url.path).name]
    assert row['size']==v['bytes'] and row['sha']==v['git_blob_sha1']
    assert re.fullmatch('[a-f0-9]{64}',v['sha256'])
for key,expected in [('p2b-mam-unique',184),('p2c-neither',169),('p2e-review',156)]:
    d=read('out/'+key+'.json')
    assert len(d['rows'])==expected
    count=Counter(r['category'] for r in d['rows'])
    assert all(count[k]==v for k,v in d['counts'].items()),(key,count,d['counts'])
    if key=='p2b-mam-unique':
        pre=read('out/p2b-prefilter.json')
        assert {r['slot'] for r in pre}=={r['slot'] for r in d['rows']}
    if key=='p2c-neither':
        pre=read('out/p2c-prefilter.json')
        assert {r['slot'] for r in pre}=={r['slot'] for r in d['rows']}
report=(folder/'README.md').read_bytes()
for rel in ['out/14-part1-table.md','out/15-part1-hataf-table.md']:
    assert (folder/rel).read_bytes().strip() in report
rows=[x for x in (folder/'out/14-part1-table.md').read_text(encoding='utf-8').splitlines() if re.match(r'\| \d+ \|',x)]
assert len(rows)==56
classes=Counter(re.search(r'\*\*([abcd])',line.split(' | ')[6]).group(1) for line in rows)
assert classes=={'a':7,'b':4,'c':38,'d':7},classes
assert len(read('out/10-part1-cases.json'))==56
out_files=list((folder/'out').rglob('*'))
out_files=[p for p in out_files if p.is_file()]
crlf=[p.name for p in out_files if b'\r\n' in p.read_bytes()]
assert len(crlf)==4
trailing=[p.name for p in out_files if p.name not in crlf and (re.search(rb'[ \t]+\r?$',p.read_bytes(),re.M) or p.read_bytes().endswith(b'\n\n'))]
assert len(trailing)==19,(len(trailing),trailing)
assert sum(bool(re.search(rb'[ \t]+$',line)) for line in (folder/'in/etcbc-bhsa-README.md').read_bytes().splitlines())==3
controls=['bhsa-corrections/out/probe.txt','bhsa-corrections/in/etcbc-bhsa-README.md','bhsa-corrections/scripts.zip','bhsa-corrections/README.md','out/probe.txt','py/probe.py']
attrs=subprocess.check_output(['git','-C',str(root),'check-attr','-z','text','whitespace','diff','--',*controls]).decode().split('\0')
triples=[attrs[i:i+3] for i in range(0,len(attrs)-1,3)]
mapping={(p,k):v for p,k,v in triples}
assert mapping[controls[0],'text']=='unset' and mapping[controls[0],'whitespace']=='-trailing-space'
assert mapping[controls[1],'whitespace']=='-blank-at-eol'
assert mapping[controls[2],'text']=='unset' and mapping[controls[2],'diff']=='unset'
assert all(mapping[p,'text']=='auto' and mapping[p,'whitespace']=='unspecified' for p in controls[3:])
data=dict(listing_entries=118,feature_entries=117,version_folders=7,raw_log_records=32,documentation_log_records=12,raw_size_blob_metadata_matches=32,part1_rows=56,part1_class_counts=dict(classes),review_rows={'p2b':184,'p2c':169,'p2e':156},two_report_tables_exact=True,crlf_files=crlf,other_trailing_whitespace_files=trailing,attribute_controls=triples,limits='Recorded metadata consistency only; no feature bytes, external requests, original-untracked comparison, research rerun, or editorial/rights judgment.')
(out/'record-consistency.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print(json.dumps(data,indent=2))

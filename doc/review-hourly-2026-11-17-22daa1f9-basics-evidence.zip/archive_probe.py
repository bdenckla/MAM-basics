import ast
from collections import Counter
import hashlib
import json
import pathlib
import re
import stat
import subprocess
import zipfile

root = pathlib.Path('/workspace/scratch/basics-22daa1f9/source')
out = root.parent / 'evidence'
base = '3691d51b619e47c003c671a0ec9cd8efe3c46706'
end = '22daa1f996e4de925d7e2deab35b237f537a8fa7'
def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args])
paths = git('diff', '--name-only', '-z', base, end).decode().rstrip('\0').split('\0')
assert len(paths) == 92 and not any(p.endswith('.py') for p in paths)
records = []
json_shapes = {}
text_files = []
for rel in paths:
    data = (root / rel).read_bytes()
    assert data == git('show', f'{end}:{rel}'), rel
    records.append(dict(path=rel, bytes=len(data), sha256=hashlib.sha256(data).hexdigest(), crlf=data.count(b'\r\n')))
    if rel.endswith('.json'):
        obj = json.loads(data)
        json_shapes[rel] = dict(type=type(obj).__name__, length=len(obj), keys=list(obj)[:20] if isinstance(obj,dict) else None, first_type=type(obj[0]).__name__ if isinstance(obj,list) and obj else None, first_keys=list(obj[0]) if isinstance(obj,list) and obj and isinstance(obj[0],dict) else None)
    elif rel.endswith('.jsonl'):
        lines = [json.loads(line) for line in data.splitlines()]
        json_shapes[rel] = dict(type='jsonl', length=len(lines), first=lines[0])
    if not rel.endswith('.zip'):
        text_files.append((rel, data.decode('utf-8')))
archive = root / 'bhsa-corrections/scripts.zip'
zip_entries=[]
with zipfile.ZipFile(archive) as z:
    assert len(z.infolist())==50
    assert len({i.filename for i in z.infolist()})==50
    assert sum(i.file_size for i in z.infolist()) == 414168
    assert sum(i.file_size for i in z.infolist()) < 1024*1024
    for i in z.infolist():
        p=pathlib.PurePosixPath(i.filename)
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename and ':' not in i.filename
        assert p.parts[0]=='scripts' and not i.is_dir() and not i.flag_bits & 1
        assert not stat.S_ISLNK(i.external_attr >> 16)
        data = z.read(i)
        s = data.decode('utf-8')
        if p.suffix=='.py':
            ast.parse(s, filename=i.filename)
        else:
            assert str(p)=='scripts/README.template.md'
        zip_entries.append(dict(path=i.filename,bytes=len(data),crc32=f'{i.CRC:08x}',sha256=hashlib.sha256(data).hexdigest()))
    assert z.testzip() is None
bhsa = [r for r in records if r['path'].startswith('bhsa-corrections/')]
groups = {}
for pref in ['bhsa-corrections/', 'bhsa-corrections/in/', 'bhsa-corrections/out/', 'bhsa-corrections/out/docs/']:
    selected = [r for r in records if r['path'].startswith(pref)]
    groups[pref]=dict(files=len(selected),bytes=sum(r['bytes'] for r in selected))
assert groups['bhsa-corrections/']['files']==87
assert groups['bhsa-corrections/in/']==dict(files=4,bytes=136529)
assert groups['bhsa-corrections/out/']==dict(files=80,bytes=3740258)
assert groups['bhsa-corrections/out/docs/']==dict(files=12,bytes=26111)
assert (root/'bhsa-corrections/in/fetch_log.jsonl').read_bytes()==(root/'bhsa-corrections/out/fetch_log.jsonl').read_bytes()
retained = groups['bhsa-corrections/']['bytes'] - (root/'bhsa-corrections/ON-ICE.md').stat().st_size
assert retained==4059816
assert 87-1-1-1+50==134
assert 58+2+3==63 and 134+63==197
assert 78474741+10229546+56417 == 93069796 - (4059816-18349-146543+414168)
report = dict(endpoint_paths=len(paths),changed_python=0,groups=groups,retained_excluding_note_bytes=retained,logical_retained_originals=134,omitted_originals=63,zip_entries=len(zip_entries),zip_uncompressed=sum(x['bytes'] for x in zip_entries),zip_python=sum(x['path'].endswith('.py') for x in zip_entries),json_shapes=json_shapes)
(out/'endpoint-inventory.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
(out/'archive-inventory.json').write_text(json.dumps(zip_entries,indent=2)+'\n',encoding='utf-8')
(out/'static-inspection.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))

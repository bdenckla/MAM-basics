from collections import Counter
from copy import deepcopy
import json
import pathlib
import re
import subprocess
from urllib.parse import unquote, urlsplit

from lxml import html

root=pathlib.Path('/workspace/scratch/basics-22daa1f9/source')
out=root.parent/'evidence'
base='3691d51b619e47c003c671a0ec9cd8efe3c46706'
end='22daa1f996e4de925d7e2deab35b237f537a8fa7'
def git(*args):
    return subprocess.check_output(['git','-C',str(root),*args])
def text(n):
    return ' '.join(n.text_content().split())
def parse(rel):
    return html.fromstring((root/rel).read_bytes())
report={}
index=parse('gh-pages/stress-helpers/index.html')
old=html.fromstring(git('show',base+':gh-pages/stress-helpers/index.html'))
new=html.fromstring(git('show',end+':gh-pages/stress-helpers/index.html'))
notes=new.xpath('//p[a[@href="results.html"]]')
assert len(notes)==1 and text(notes[0])=='The complete comparison gives the census and findings by verse. Full results'
new_raw=git('show',end+':gh-pages/stress-helpers/index.html')
old_raw=git('show',base+':gh-pages/stress-helpers/index.html')
inserted=b'<p>The complete comparison gives the census and findings by verse. <a href="results.html">Full results</a></p>\n'
assert new_raw.count(inserted)==1 and new_raw.replace(inserted,b'',1)==old_raw
common=json.loads((root/'in/stress-helpers/common.json').read_bytes())
old_common=json.loads(git('show',base+':in/stress-helpers/common.json'))
assert common['source_notes'][1:]==old_common['source_notes']
assert common['coverage']==old_common['coverage']
page=parse('gh-pages/stress-helpers/results.html')
ids=page.xpath('//*[@id]/@id')
assert len(ids)==len(set(ids))
links=[]
for rel in ['gh-pages/stress-helpers/index.html','gh-pages/stress-helpers/results.html']:
    doc=parse(rel)
    for value in doc.xpath('//@href|//@src'):
        u=urlsplit(value)
        if u.scheme or u.netloc:
            continue
        target=(root/rel).parent / unquote(u.path) if u.path else root/rel
        target=target.resolve()
        assert target.is_relative_to(root/'gh-pages') and target.is_file(), (rel,value)
        if u.fragment and target.suffix=='.html':
            assert parse(str(target.relative_to(root))).xpath('//*[@id=$key]',key=unquote(u.fragment)),(rel,value)
        links.append([rel,value])
tables=page.xpath('//table')
assert len(tables)==5
rows=tables[0].xpath('./tbody/tr')
numbers=[[int(text(x).replace(',','')) for x in row.xpath('./td')] for row in rows]
assert all(a+b==c for a,b,c in numbers)
assert [sum(col) for col in zip(*numbers[:-1])]==numbers[-1]==[5515,20154,25669]
comparison=[[int(text(x).replace(',','')) for x in row.xpath('./td')] for row in tables[1].xpath('./tbody/tr')]
assert [sum(col) for col in zip(*comparison[:5])]==[25669,25669]
assert comparison[-2]==[4,0] and comparison[-1]==[42,6]
detail_rows=[t.xpath('./tbody/tr') for t in tables[2:]]
detail_counts=[]
for rows in detail_rows:
    detail_counts.append(dict(rows=len(rows),koren=sum(text(r.xpath('./td')[1])!='—' for r in rows),simanim=sum(text(r.xpath('./td')[2])!='—' for r in rows)))
assert detail_counts[0]['koren']==92 and detail_counts[0]['simanim']==39,detail_counts
assert detail_counts[1]['koren']==42 and detail_counts[1]['simanim']==6,detail_counts
assert detail_counts[2]==dict(rows=9,koren=3,simanim=6)
# Check every displayed primary MAM form against its named committed public verse,
# dropping ketiv text when the displayed qere is the reading. No normalization.
names={
 'Gen':'A1-Genesis','Exod':'A2-Exodus','Lev':'A3-Levit','Num':'A4-Numbers','Deut':'A5-Deuter','Josh':'B1-Joshua','Judg':'B2-Judges',
 '1 Sam':'BA-1Samuel','2 Sam':'BB-2Samuel','1 Kgs':'BC-1Kings','2 Kgs':'BD-2Kings','Isa':'C1-Isaiah','Jer':'C2-Jeremiah','Ezek':'C3-Ezekiel',
 'Hos':'CA-Hosea','Joel':'CB-Joel','Amos':'CC-Amos','Obad':'CD-Obadiah','Jonah':'CE-Jonah','Mic':'CF-Micah','Nah':'CG-Nahum','Hab':'CH-Haba','Zeph':'CI-Tsef','Hag':'CJ-Haggai','Zech':'CK-Zech','Mal':'CL-Malachi',
 'Job':'E1-Job','Song of Songs':'F1-Song','Ruth':'F2-Ruth','Daniel':'G1-Daniel','Ezra':'G2-Ezra','Neh':'G3-Nehemiah','1 Chr':'H1-1Chron','2 Chr':'H2-2Chron'
}
files=sorted((root/'gh-pages/MAM-with-doc').glob('*.html'))
actual={p.stem:p for p in files}
cache={}
matches=[]
unmatched=[]
for table_num,rows in enumerate(detail_rows):
    for row in rows:
        form=text(row.xpath('./td')[0])
        refnode=row.xpath('./th')[0]
        ref=refnode.text.strip()
        m=re.fullmatch(r'(.+) (\d+):(\d+)',ref)
        assert m,ref
        book,ch,vs=m.groups()
        key=names.get(book)
        if key not in actual:
            unmatched.append(dict(table=table_num,reference=ref,form=form,reason='unmapped file',key=key))
            continue
        if key not in cache: cache[key]=parse(str(actual[key].relative_to(root)))
        node=cache[key].xpath('//*[@id=$key]',key=f'c{ch}v{vs}')
        assert len(node)==1,(ref,key)
        vr=deepcopy(node[0].getparent())
        for ketiv in vr.xpath('.//span[@class="mam-kq-k"]'):
            ketiv.drop_tree()
        if form in text(vr).replace('[','').replace(']',''):
            matches.append(dict(table=table_num,reference=ref,form=form))
        else:
            unmatched.append(dict(table=table_num,reference=ref,form=form,reason='not in body/qere'))
report=dict(tables=5,census_rows=numbers,comparison_rows=comparison,detail_counts=detail_counts,local_link_occurrences=len(links),matched_forms=len(matches),unmatched=unmatched,rows=matches)
(out/'page-consistency.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='rows'},ensure_ascii=False,indent=2))

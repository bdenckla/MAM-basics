"""Record the bounded public Hebrew Reader screen; no broad commands."""

import fcntl
import hashlib
import json
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path("/workspace/MAM-basics")
EVID = ROOT / ".novc/review-hourly-20261108-1900-basics"
TIP = "84ad02264fce66d2b41ca0b4ac3fd3522d85e22e"
BASE = "e8e75686b1c7281bf4b1ad0913655152bf376a7c"
PY = str(ROOT / ".venv/bin/python")
PAGE = "gh-pages/MAM-with-doc/misc/review_of_hebrew_reader_for_the_pentateuch.html"


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)


def run(name, args):
    started = datetime.now(timezone.utc).isoformat()
    start = time.monotonic()
    with (EVID / f"{name}.log").open("wb") as log:
        proc = subprocess.run(args, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    row = dict(
        name=name,
        command=args,
        cwd=str(ROOT),
        started=started,
        exit=proc.returncode,
        seconds=round(time.monotonic() - start, 3),
    )
    rows.append(row)
    (EVID / "commands.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps(row), flush=True)
    patch = git("diff", "--binary")
    (EVID / f"{name}-generated.diff").write_bytes(patch)
    changed = git("diff", "--name-only", "-z").decode().split("\0")[:-1]
    print(json.dumps({"tracked_differences_after": name, "paths": changed}), flush=True)
    if changed:
        raise RuntimeError(
            "Preserved unexpected generated differences; inspect before proceeding"
        )


if __name__ == "__main__":
    assert git("rev-parse", "HEAD").decode().strip() == TIP
    assert not git("status", "--porcelain", "-z")
    assert git("rev-list", "--count", f"{BASE}..{TIP}").strip() == b"1"
    EVID.mkdir(parents=True, exist_ok=False)
    for name in (".git/codex-index-refresh.lock",):
        with (ROOT / name).open("a") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    paths = git("diff", "--name-only", "-z", BASE, TIP).decode().split("\0")[:-1]
    (EVID / "input.json").write_text(
        json.dumps(
            dict(
                base=BASE,
                source=TIP,
                paths=paths,
                interpreter=PY,
                original_work="cb878aef91e692d5561435f00021f73b75868e45",
                maintenance_parent="80efadaf4e318a62089943fdd8e5923b8b820c28",
            ),
            indent=2,
        )
        + "\n"
    )
    assert len(paths) == 2
    (EVID / "source.diff").write_bytes(git("diff", "--binary", BASE, TIP))
    (EVID / "source-page.html").write_bytes((ROOT / PAGE).read_bytes())
    rows = []
    run("gen-misc", [PY, "py/main_authored.py", "gen-misc"])
    run(
        "focused-tests",
        [
            PY,
            "py/main_test.py",
            "-q",
            "-ra",
            "py/tests/test_prose_conventions.py",
            "py/tests/test_transliterations.py",
        ],
    )
    run(
        "black-check",
        [
            PY,
            "-m",
            "black",
            "--check",
            "py/author_misc/review_of_hebrew_reader_for_the_pentateuch.py",
        ],
    )
    run("whitespace", ["git", "diff", "--check", BASE, TIP])
    print(
        json.dumps(
            dict(
                completed=True,
                page_bytes=(ROOT / PAGE).stat().st_size,
                page_sha256=hashlib.sha256((ROOT / PAGE).read_bytes()).hexdigest(),
            )
        ),
        flush=True,
    )

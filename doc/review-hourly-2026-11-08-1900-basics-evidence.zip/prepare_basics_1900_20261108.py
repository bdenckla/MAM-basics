"""Adapt prior bounded public checks to the two-text correction endpoint."""

import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/workspace/MAM-basics')
evidence = root / '.novc/review-hourly-20261108-1900-basics'
base = 'e8e75686b1c7281bf4b1ad0913655152bf376a7c'
tip = '84ad02264fce66d2b41ca0b4ac3fd3522d85e22e'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip() == tip
old_runner = Path('/workspace/scratch/review_hebrew_reader_20261108.py').read_text()
runner = old_runner.replace('.novc/review-hebrew-reader-20261108-e8e75686', str(evidence.relative_to(root)))
runner = runner.replace('TIP = "'+base+'"','TIP = "'+tip+'"')
runner = runner.replace('BASE = "011f25a723771e1f3f1c9ea64fab384525774672"','BASE = "'+base+'"')
runner = runner.replace('maintenance_parent="abcf5e0612060a113f7cb31d9fd3bf79ec439006"','maintenance_parent="80efadaf4e318a62089943fdd8e5923b8b820c28"')
runner = runner.replace('assert len(paths) == 13','assert len(paths) == 2')
runner = runner.replace('    run("gen-site", [PY, "py/main_authored.py", "gen-site"])\n','')
for name in ('test_site_index_links','test_shared_html_styles','test_tracked_filenames','test_prose_mark_order'):
    runner = runner.replace(f'            "py/tests/{name}.py",\n','')
for name in ('py/author_site/site_data.py','py/main_authored.py'):
    runner = runner.replace(f'            "{name}",\n','')
run_path=Path('/workspace/scratch/run_basics_1900_20261108.py')
run_path.write_text(runner)
checker = Path('/workspace/scratch/check_hebrew_reader_20261108.py').read_bytes()
updated = checker.replace(b'.novc/review-hebrew-reader-20261108-e8e75686',str(evidence.relative_to(root)).encode())
Path('/workspace/scratch/check_basics_1900_20261108.py').write_bytes(updated)
page='gh-pages/MAM-with-doc/misc/review_of_hebrew_reader_for_the_pentateuch.html'
source='py/author_misc/review_of_hebrew_reader_for_the_pentateuch.py'
def read(commit,path):
    return subprocess.check_output(['git','show',commit+':'+path],cwd=root)
old_page,new_page=read(base,page),read(tip,page)
old_word=''.join(map(chr,[0x5de,0x5e0,0x5d7]))
new_word=''.join(map(chr,[0x5de,0x5d5,0x5e0,0x5d7]))
assert old_page.count(b'some others like it')==1
assert old_page.count(old_word.encode())==1
assert old_page.replace(b'some others like it',b'some others like them').replace(old_word.encode(),new_word.encode())==new_page
old_ast,new_ast=[ast.parse(read(commit,source)) for commit in (base,tip)]
old_ast.body.pop(0)
new_ast.body.pop(0)
class Correct(ast.NodeTransformer):
    def visit_Constant(self,node):
        if isinstance(node.value,str):
            node.value=node.value.replace('some others like it','some others like them')
            if node.value==old_word:
                node.value=new_word
        return node
assert ast.dump(Correct().visit(old_ast),include_attributes=False)==ast.dump(new_ast,include_attributes=False)
out=dict(html_reconstructs_exactly=True,executable_ast_reconstructs_exactly=True,
    source_docstring='Separately records the two owner-approved edits; omitted only from AST comparison',
    checker_adaptation='Only evidence-directory constant changed; all DOM/form/link/footnote/asset assertions retained after inspecting unchanged page structure',
    prior_checker_sha256=hashlib.sha256(checker).hexdigest(),current_checker_sha256=hashlib.sha256(updated).hexdigest())
Path('/workspace/scratch/basics_1900_preservation.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))

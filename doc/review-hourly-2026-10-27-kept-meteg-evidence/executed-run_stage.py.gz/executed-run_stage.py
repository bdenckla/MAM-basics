"""Run and record one focused command synchronously, from an isolated source root."""

from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys
import time


def main():
    root, label = Path(sys.argv[1]), sys.argv[2]
    command = sys.argv[3:]
    evidence = root / ".novc/hourly"
    evidence.mkdir(parents=True, exist_ok=True)
    target = evidence / f"{label}.json"
    assert not target.exists()
    started = datetime.now(timezone.utc).isoformat()
    start = time.monotonic()
    proc = subprocess.run(command, cwd=root, capture_output=True, text=True, encoding="utf-8")
    status = subprocess.check_output(["git", "-C", str(root), "status", "--porcelain=v1", "-z"]).decode()
    (evidence / f"{label}.log").write_text(proc.stdout + proc.stderr, encoding="utf-8")
    record = {"command": command, "cwd": str(root), "started_utc": started, "completed_utc": datetime.now(timezone.utc).isoformat(), "seconds": round(time.monotonic() - start, 3), "exit_code": proc.returncode, "tracked_status_after": status}
    target.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(record, indent=2))
    print((proc.stdout + proc.stderr)[-4500:])
    if status:
        raise SystemExit("Tracked differences require investigation")
    raise SystemExit(proc.returncode)


if __name__ == "__main__":
    main()

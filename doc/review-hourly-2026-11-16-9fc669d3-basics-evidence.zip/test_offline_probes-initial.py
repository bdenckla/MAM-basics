"""Disposable independent report/display probes; run through maintained main_test."""
from collections import Counter
from dataclasses import replace
from html.parser import HTMLParser
from pathlib import Path
import hashlib
import json
import re

import pytest
from author_misc import morphhb_corrections_lib as L
from mb_cmn import paths, uni_denorm
from miqra_mevoar import display_page as D
from mb_cmn import hebrew_verse_numerals as H

OUT = Path(__file__).parent
ROOT = paths.repo_root()

def save(name, value):
    (OUT / name).write_text(json.dumps(value,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')

def strip_form(text):
    drop = {0x05BD,0x05C0,0x05C3,0x05C4,0x05C5,0x034F,0x200C,0x200D}
    text = ''.join(c for c in text if not 0x0591 <= ord(c) <= 0x05AF and ord(c) not in drop).strip()
    return text.removesuffix('\N{HEBREW PUNCTUATION MAQAF}')

class Tables(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tables=[]
        self.table=None
        self.row=None
        self.cell=None
        self.hrefs=[]
        self.ids=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=='a': self.hrefs.append(a['href'])
        if 'id' in a: self.ids.append(a['id'])
        if tag=='table': self.table=[]
        if tag=='tr': self.row=[]
        if tag in ('td','th'): self.cell={'kind':tag,'attrs':a,'text':''}
        if tag=='br' and self.cell is not None: self.cell['text']+='\n'
    def handle_data(self,data):
        if self.cell is not None: self.cell['text']+=data
    def handle_endtag(self,tag):
        if tag in ('td','th') and self.cell is not None:
            self.row.append(self.cell); self.cell=None
        if tag=='tr' and self.row is not None:
            self.table.append(self.row); self.row=None
        if tag=='table' and self.table is not None:
            self.tables.append(self.table); self.table=None

def test_report_render_and_public_retained_joins():
    data=json.loads((ROOT/'in/morphhb-verdicts-2026-11-16/verdicts.json').read_text(encoding='utf-8'))
    words=data['words']; byid={w['id']:w for w in words}
    assert len(byid)==len(words)==341
    counts=Counter(w['verdict'] for w in words)
    assert counts=={'defies':12,'resolves':142,'follows':5,'slip':10,'fits both':133,'ketiv':24,'same':12,'text':3}
    for w in words:
        for key in ('morphhb','mam'):
            assert uni_denorm.has_std_mark_order(w[key]), (w['id'],key)
    html=(ROOT/'gh-pages/morphhb-corrections/index.html').read_text(encoding='utf-8')
    dom=Tables();dom.feed(html)
    wt=[t for t in dom.tables if [c['text'] for c in t[0]][:4]==['morphhb above MAM','Verse','Lemma','Morph']]
    actual=Counter()
    for t in wt:
        for row in t[1:]:
            assert row[0]['attrs'].get('dir')=='rtl'
            actual[(row[0]['text'],row[2]['text'],row[3]['text'])]+=1
    expected=Counter(('\n'.join(strip_form(w[k]) for k in ('morphhb','mam')),w['lemma'],w['morph']) for w in words if w['verdict'] in ('defies','resolves','follows','slip'))
    assert len(wt)==4 and sum(actual.values())==169 and actual==expected
    assert len(dom.ids)==len(set(dom.ids))
    assert all(not h.startswith('#') or h[1:] in dom.ids for h in dom.hrefs)
    assert not any('israel-bible-review' in h or ':~:text=' in h for h in dom.hrefs)
    assert not (ROOT/'out/morphhb-corrections').exists()
    refs=[]
    for p in (ROOT/'py').rglob('*.py'):
        if 'morphhb_corrections_review_links' in p.read_text(encoding='utf-8'):refs.append(str(p))
    assert not refs
    report=ROOT/'in/morphhb-corrections-2026-11-13/out'
    sources={}
    for row in json.loads((report/'12-part1-table.json').read_text(encoding='utf-8'))['rows']:
        for w in row['morphhb']:
            sources.setdefault(w['id'],[]).append(('brief',w['text'],w['lemma'],w['morph'],None))
    for w in json.loads((report/'50-alel-census.json').read_text(encoding='utf-8'))['words']:
        sources.setdefault(w['id'],[]).append(('census',w['text'],w['lemma'],w['morph'],w['mam_atoms']))
    text=(report/'51-general-test.txt').read_text(encoding='utf-8')
    rx=r'^-- .+?  id (\w{5})  sides[^\n]*\n   morphhb: (\S+)  lemma (.*?)  morph (\S+)\n   MAM:\s+(\S+)'
    general=list(re.finditer(rx,text,re.M))
    for m in general:
        sources.setdefault(m[1],[]).append(('general',m[2],m[3],m[4],[m[5]]))
    joined=[];unavailable=[];mismatches=[]
    for w in words:
        src=sources.get(w['id'],[])
        if not src:
            unavailable.append({'id':w['id'],'source':w['source']});continue
        for kind,form,lemma,morph,mam in src:
            # Copies are MAM-ordered; no accents/marks/slashes dropped from morphhb.
            if (uni_denorm.give_std_mark_order(form),lemma,morph)!=(w['morphhb'],w['lemma'],w['morph']):
                mismatches.append({'id':w['id'],'kind':kind,'field':'morphhb/lemma/morph'})
            if kind=='general' and uni_denorm.give_std_mark_order(mam[0])!=w['mam']:
                mismatches.append({'id':w['id'],'kind':kind,'field':'mam'})
        joined.append({'id':w['id'],'source':w['source'],'retained':[x[0] for x in src]})
    result={'verdicts':dict(counts),'sources':dict(Counter(w['source'] for w in words)),
            'rendered_rows':sum(actual.values()),'word_tables':len(wt),'hrefs':len(dom.hrefs),
            'ids':len(dom.ids),'general_blocks':len(general),'joined':joined,
            'unavailable':unavailable,'mismatches':mismatches,
            'limit':'Retained report, not original morphhb research; rare lists omitted. Brief MAM forms are projected, not checked byte-for-byte here.'}
    save('report-probe-results.json',result)
    assert not mismatches,mismatches

def test_highlight_and_analysis_form_contract():
    alef='\N{HEBREW LETTER ALEF}'
    bet='\N{HEBREW LETTER BET}'
    qamats='\N{HEBREW POINT QAMATS}'
    qatan='\N{HEBREW POINT QAMATS QATAN}'
    rafe='\N{HEBREW POINT RAFE}'
    dagesh='\N{HEBREW POINT DAGESH OR MAPIQ}'
    maqaf='\N{HEBREW PUNCTUATION MAQAF}'
    meteg='\N{HEBREW POINT METEG}'
    accent='\N{HEBREW ACCENT ETNAHTA}'
    a,b=alef+qamats,alef+qatan
    assert L.hot_units([L.units(a),L.units(b)])==[set(),set()]
    assert L.analysis_form(a)!=L.analysis_form(b)
    assert L.hot_units([L.units(a+'/'+bet),L.units(a+bet)])==[set(),set()]
    assert L.hot_units([L.units(alef+rafe),L.units(alef)])==[{0},{0}]
    assert L.analysis_form(alef+rafe+dagesh+meteg+accent+maqaf)==uni_denorm.give_std_mark_order(alef+rafe+dagesh)
    assert L.analysis_form(a+maqaf+bet)==a+maqaf+bet
    assert L.hot_units([L.units(a+'\N{COMBINING GRAPHEME JOINER}'),L.units(a)])==[set(),set()]
    save('highlight-probe-results.json',{'independent_contract_assertions':7,'passed':True,'no_editorial_judgment':True})

def test_miqra_retained_bytes_boundaries_and_refusals():
    previews=OUT/'display-pages';previews.mkdir(exist_ok=True)
    old=Path('/workspace/scratch/basics-84b504b9-artifacts/display-pages')
    retained={p.stem:p for p in old.glob('*.wiki')}
    retained['tzefanya']=Path('/workspace/scratch/basics-b41f3166-artifacts/tzefanya.wiki')
    retained['malakhi']=Path('/workspace/scratch/basics-8cc22b46-artifacts/malakhi.wiki')
    assert len(retained)==14
    summaries={}
    for key,page in D.PAGES.items():
        text=D.page_text(page);raw=text.encode('utf-8');(previews/(key+'.wiki')).write_bytes(raw)
        vs,name=D.read_page(text)
        if key in retained:assert raw==retained[key].read_bytes(),key
        summaries[key]={'verses':len(vs),'first':[vs[0].chapter,vs[0].verse],
                        'last':[vs[-1].chapter,vs[-1].verse],'bytes':len(raw),
                        'sha256':hashlib.sha256(raw).hexdigest(),
                        'parameters':sum(v.chapter_parameter is not None for v in vs)}
    ranges={'sephershoftim-1':((1,1),(2,5)), 'sephershoftim-2':((2,6),(16,31)),
            'sephershoftim-3':((17,1),(21,25)), 'daniyel-1':((1,1),(6,29)), 'daniyel-2':((7,1),(12,13))}
    for key,(first,last) in ranges.items():
        vs,_=D.read_page((previews/(key+'.wiki')).read_text(encoding='utf-8'))
        assert (vs[0].chapter,vs[0].verse)==tuple(H.INT_TO_STR_DIC[n] for n in first)
        assert (vs[-1].chapter,vs[-1].verse)==tuple(H.INT_TO_STR_DIC[n] for n in last)
        assert sum(v.chapter_parameter is not None for v in vs)==int(first[1]!=1)
    second=D.PAGES['sephershoftim-2'];base=D.page_text(second)
    vs,_=D.read_page(base)
    assert vs[0].chapter_parameter==vs[0].chapter
    bad_bounds=[dict(first_verse=0),dict(first_verse=999),dict(last_verse=999),
                dict(chapters=(0,16)),dict(chapters=(17,16)),dict(chapters=(2,2),first_verse=7,last_verse=6)]
    for change in bad_bounds:
        with pytest.raises(ValueError):D.page_text(replace(second,**change))
    line=next(x for x in base.splitlines() if x.startswith('{{'+D._VERSE_TEMPLATE+'|'))
    marker='|'+D._CHAPTER_PARAMETER+'='+vs[0].chapter
    assert marker in line
    first=D.page_text(D.PAGES['sephershoftim-1'])
    firstline=next(x for x in first.splitlines() if x.startswith('{{'+D._VERSE_TEMPLATE+'|'))
    bad_text=[base.replace(marker,marker+marker,1),base.replace(marker,'|unknown='+vs[0].chapter,1),
              base.replace(marker,'|'+D._CHAPTER_PARAMETER+'='+H.INT_TO_STR_DIC[3],1),
              base.replace(line,line+'\n'+line,1),
              first.replace(firstline,firstline[:-2]+'|'+D._CHAPTER_PARAMETER+'='+H.INT_TO_STR_DIC[1]+'}}',1)]
    for text in bad_text:
        with pytest.raises(ValueError):D.read_page(text)
    save('display-probe-results.json',{'pages':summaries,'retained_byte_equal':sorted(retained),'bad_bound_refusals':len(bad_bounds),
        'illegal_parameter_refusals':len(bad_text),'range_checks':5,'limit':'Offline generated text only; no original Word, live template/API/save or browser verification.'})

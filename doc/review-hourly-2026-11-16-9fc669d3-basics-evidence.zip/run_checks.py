"""Record exact sequential focused-check commands, exits and times."""
from datetime import datetime, timezone
from pathlib import Path
import json
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/basics-9fc669d3')
OUT = Path(__file__).parent
PY = '/workspace/MAM-basics/.venv/bin/python'

def run(name, args):
    started = datetime.now(timezone.utc).isoformat()
    start = time.monotonic()
    with (OUT / (name + '.txt')).open('wb') as log:
        proc = subprocess.run(args, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    result = dict(name=name, command=args, cwd=str(ROOT), start_utc=started,
                  end_utc=datetime.now(timezone.utc).isoformat(),
                  seconds=round(time.monotonic()-start,3), exit=proc.returncode)
    with (OUT / 'commands.jsonl').open('a',encoding='utf-8') as log:
        log.write(json.dumps(result)+'\n')
    print(json.dumps(result),flush=True)
    return proc.returncode

if __name__ == '__main__':
    name = sys.argv[1]
    command = sys.argv[2:]
    raise SystemExit(run(name,command))

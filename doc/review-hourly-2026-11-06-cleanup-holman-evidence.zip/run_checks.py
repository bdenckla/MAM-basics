"""Run the bounded generator and native checks sequentially with durable logs."""
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import time

root = Path('/workspace/MAM-basics')
out = Path(__file__).parent
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == 'b85275921e02f4b1475446908d5cb997ca0083f7'
assert not subprocess.check_output(['git', 'status', '--porcelain', '-z'], cwd=root)
commands = [
    ('renderer', ['.venv/bin/python', 'py/main_render_uxlc_corrections.py']),
    ('focused-tests', ['.venv/bin/python', 'py/main_test.py', 'py/tests/test_receipt_update_links.py', 'py/tests/test_tracked_filenames.py', 'py/tests/test_prose_conventions.py', 'py/tests/test_shared_html_styles.py', '-ra']),
]
results = []
for label, command in commands:
    started = time.perf_counter()
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
    item = {'stage': label, 'command': command, 'exit_code': result.returncode, 'elapsed_seconds': round(time.perf_counter() - started, 3)}
    results.append(item)
    (out / 'execution.json').write_text(json.dumps(results, indent=2) + '\n')
    diff = subprocess.check_output(['git', 'diff', '--binary'], cwd=root)
    (out / (label + '-tracked.diff')).write_bytes(diff)
    print(json.dumps(item), flush=True)
    if diff:
        raise RuntimeError('Tracked output changes preserved for investigation; no restoration performed.')
print((out / 'focused-tests.log').read_text().strip().splitlines()[-1], flush=True)
print('Both stages awaited; no tracked output change.', flush=True)
if any(item['exit_code'] for item in results):
    raise SystemExit(1)

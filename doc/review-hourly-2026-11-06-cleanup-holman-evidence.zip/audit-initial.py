"""Independent offline source/data audit for the bounded cleanup and Holman window."""
import ast
from collections import Counter
from html.parser import HTMLParser
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote, urlsplit

ROOT = Path('/workspace/MAM-basics')
OUT = Path(__file__).parent
BASE = '6449404315f45a2185c45ea0e69c83f10297a9b9'
TIP = 'b85275921e02f4b1475446908d5cb997ca0083f7'
OLD_HOST = b'https://hcanat.us/'
NEW_HOST = b'https://tanach.us/'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def read(commit, path):
    return git('show', commit + ':' + path)

assert git('rev-parse', 'HEAD').decode().strip() == TIP
assert not git('status', '--porcelain', '-z')
raw = git('diff', '--name-status', '-z', BASE, TIP).decode().rstrip('\0').split('\0')
entries = list(zip(raw[::2], raw[1::2]))
assert len(entries) == 68
deleted = [p for state, p in entries if state == 'D']
assert all(p.startswith('doc/') or p == 'py/tests/test_review_turn_files.py' for p in deleted)
assert 'py/tests/test_review_turn_files.py' in deleted
for path in deleted:
    assert git('cat-file', '-t', '6d3426fda4176a9a69f948761490988d8ba43e25:' + path).strip() == b'blob'

class StripDocstrings(ast.NodeTransformer):
    def generic_visit(self, node):
        node = super().generic_visit(node)
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)) and node.body and isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value, ast.Constant) and isinstance(node.body[0].value.value, str):
            node.body = node.body[1:]
        return node

python_modified = [p for state, p in entries if p.endswith('.py') and state == 'M']
assert set(python_modified) == {'py/hkq_cmn/uxlc_change_records.py', 'py/repo_util/check_repo_standards.py', 'py/tests/test_h_dot_below_nfc.py', 'py/tests/test_tracked_filenames.py'}
for path in python_modified:
    old, new = [read(c, path) for c in (BASE, TIP)]
    if path.endswith('uxlc_change_records.py'):
        assert old.count(OLD_HOST) == 1
        old = old.replace(OLD_HOST, NEW_HOST)
    assert ast.dump(StripDocstrings().visit(ast.parse(old)), include_attributes=False) == ast.dump(StripDocstrings().visit(ast.parse(new)), include_attributes=False), path

html_path = 'gh-pages/holman/uxlc_corrections.html'
old_html, new_html = [read(c, html_path) for c in (BASE, TIP)]
assert old_html.count(OLD_HOST) == 124 and OLD_HOST not in new_html
assert old_html.replace(OLD_HOST, NEW_HOST) == new_html
data_path = 'holman/docs-not-served/uxlc_corrections.json'
old_data, new_data = [read(c, data_path) for c in (BASE, TIP)]
assert old_data.count(OLD_HOST) == 1
assert old_data.replace(OLD_HOST, NEW_HOST) == new_data
old_json, new_json = json.loads(old_data), json.loads(new_data)
url = new_json['change_records_page_url']
old_json['change_records_page_url'] = url
assert old_json == new_json

class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
    def handle_starttag(self, tag, attrs):
        if tag == 'a':
            self.links.extend(value for key, value in attrs if key == 'href' and value)

links = Links()
links.feed(new_html.decode())
record_links = [link for link in links.links if link.startswith(url + '#')]
assert len(record_links) == 124
old_links = Links()
old_links.feed(old_html.decode())
old_record_links = [link for link in old_links.links if link.startswith(url.replace('tanach.us', 'hcanat.us') + '#')]
assert [urlsplit(x).fragment for x in record_links] == [urlsplit(x).fragment for x in old_record_links]
downloads = git('ls-files', '-z', '--', '*my_uxlc.py').decode().rstrip('\0').split('\0')
assert len(downloads) == 1
assert read(BASE, downloads[0]) == read(TIP, downloads[0])
assert b'UXLC_DOWNLOAD_HOST = "hcanat.us"' in read(TIP, downloads[0])

archive_links = set()
for state, path in entries:
    if state == 'D' or not path.endswith(('.md', '.py')):
        continue
    diff = git('diff', '--unified=0', BASE, TIP, '--', path).decode()
    additions = '\n'.join(line[1:] for line in diff.splitlines() if line.startswith('+') and not line.startswith('+++'))
    for commit, target in re.findall(r'https://github\.com/bdenckla/MAM-basics/blob/([0-9a-f]{40})/([^\s)#`]+)', additions):
        target = unquote(target).rstrip('.,;')
        archive_links.add((commit, target))
for commit, path in archive_links:
    assert git('cat-file', '-t', commit + ':' + path).strip() == b'blob', (commit, path)
assert archive_links
for path in ('AGENTS.md', 'doc/periodic-review.md', 'doc/review-trial.md', 'dot-claude/skills/iterative-document-editing/SKILL.md'):
    text = read(TIP, path).decode()
    assert 'doc/dual-agent-review.md' not in text
assert read(BASE, 'doc/review-trial-status.md') == read(TIP, 'doc/review-trial-status.md')
git('diff', '--check', BASE, TIP)
result = {
    'source_base': BASE, 'source_tip': TIP,
    'endpoint_paths': 68, 'status_counts': dict(Counter(state for state, _ in entries)),
    'deleted_paths_preserved_in_archive': len(deleted),
    'python_modified': python_modified,
    'ast_result': 'Executable ASTs identical after the single URL-host change; remaining Python differences are comments/docstrings. The deleted test is specifically the retired turn-file lint.',
    'holman': {'reader_links_changed_only_by_host': 124, 'record_fragments_preserved': True, 'json_change': 'One top-level URL host only; every other byte preserved.', 'html_sha256': hashlib.sha256(new_html).hexdigest(), 'json_sha256': hashlib.sha256(new_data).hexdigest(), 'download_host': 'hcanat.us unchanged'},
    'new_unique_archival_blob_links_verified_locally': len(archive_links),
    'review_status_source_unchanged': True,
    'limits': 'No remote page read, live anchor validation, browser check or new editorial interpretation. Cleanup authorization comes from the parent; owner test and target-site observations remain attributed.'
}
(OUT / 'audit-result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))

"""Public endpoint differentials and invalid-shape probes; no source judgment."""

import dataclasses
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import types

from accgram import mam_simple_verse as loader
from mb_cmn import mam_json_verses as reader
from mb_cmn import mam_simple_json
from foi import foi_wikitext_helpers as foi
from mam_morphhb import morphhb_plus as morph

TREE = Path(__file__).resolve().parents[1]
OUT = TREE.parent / "evidence"
BASE = "cfdbb64ef8fc24e777d4d296efb7fe4ac966346d"


def prior(path):
    mod = types.ModuleType("prior_" + Path(path).stem)
    mod.__file__ = str(TREE / path)
    sys.modules[mod.__name__] = mod
    raw = subprocess.check_output(["git", "show", BASE + ":" + path])
    exec(compile(raw, mod.__file__, "exec"), mod.__dict__)
    return mod


old_loader = prior("py/accgram/mam_simple_verse.py")
old_reader = prior("py/mb_cmn/mam_json_verses.py")
directory = TREE / "MAM-simple/json-vtrad-mam"
refs = loader.mam_simple_refs(directory)
assert refs == old_loader.mam_simple_refs(directory)
before = old_loader.load_mam_simple_for_refs(directory, refs)
after = loader.load_mam_simple_for_refs(directory, refs)
assert repr(before) == repr(after)
verses = 0
digest = hashlib.sha256()
for path in sorted(directory.glob("*.json")):
    for verse in mam_simple_json.verses(mam_simple_json.read_book_group(path)):
        a, b = old_reader.get_verse_words(verse), reader.get_verse_words(verse)
        assert a == b, verse["osisID"]
        digest.update(repr(b).encode())
        verses += 1
counts = {
    "exact_loaded_verses": len(after),
    "exact_reader_verses": verses,
    "reader_rejections": 0,
    "empty_cases": 0,
    "template_rejections": 0,
    "locator_rejections": 0,
}


def verse(items):
    return {"type": "verse", "osisID": "fixture.1.1", "contents": items}


bad_nodes = [
    {"type": "text"},
    {"type": "text", "text": "alpha", "extra": "bad"},
    {"type": "lp-paseq"},
    {"type": "kq"},
    {"type": "slh-word"},
    {"type": "scrdfftar"},
    {"type": "implicit-maqaf", "text": "bad"},
    {"type": "shirah-space", "text": "bad"},
    {"type": "spi-invnun", "class": "bad"},
    {"type": "spi-pe3", "text": "bad"},
    {
        "type": "scrdfftar",
        "contents": [
            {"type": "sdt-target", "contents": [{"type": "text", "text": ""}]}
        ],
    },
]
for node in bad_nodes:
    try:
        reader.get_verse_words(verse([node]))
    except ValueError:
        counts["reader_rejections"] += 1
    else:
        raise AssertionError(("expected rejection", node))
for nodes in [
    [{"type": "text", "text": "  "}],
    [{"type": "scrdfftar", "contents": [{"type": "sdt-target"}]}],
    [
        {
            "type": "scrdfftar",
            "contents": [{"type": "sdt-target", "contents": [{"type": "spi-pe2"}]}],
        }
    ],
]:
    assert reader.get_verse_words(verse(nodes)) == {"words": [], "ketiv_indices": []}
    counts["empty_cases"] += 1
for template in [
    {"tmpl_name": "unknown-future"},
    {"tmpl_name": "מ:דחי", "tmpl_params": {"1": "alpha", "2": "beta", "extra": "bad"}},
]:
    for call in [
        lambda: foi.templates_before_sof_pasuq([template]),
        lambda: morph.plus_stream(template, []),
    ]:
        try:
            call()
        except ValueError:
            counts["template_rejections"] += 1
        else:
            raise AssertionError("expected template rejection")
for node in [{}, {"type": "verse"}, {"type": "verse", "osisID": 3}]:
    try:
        loader._verse_osis_id(node, Path("fixture.json"))
    except ValueError:
        counts["locator_rejections"] += 1
    else:
        raise AssertionError("expected missing identity rejection")
rolled = [
    "py/foi/foiz_wt_kq_1.py",
    "py/foi/foiz_wt_rare_tmpls.py",
    "py/foi/foiz_wt_slh_word.py",
    "py/mb_xml/xml_render.py",
    "py/render_wt/render_wikitext.py",
    "py/render_wt/render_wikitext_handlers.py",
]
for path in rolled:
    assert (
        subprocess.check_output(["git", "show", BASE + ":" + path])
        == (TREE / path).read_bytes()
    )
result = {
    "result": "PASS",
    "checks": counts,
    "loaded_repr_sha256": hashlib.sha256(repr(after).encode()).hexdigest(),
    "reader_repr_sha256": digest.hexdigest(),
    "l4_rollback_files_exact": rolled,
    "limits": "Current public data and bounded invalid fixtures only; no alternate strand/default chosen, source/editorial proof, hash gate or broad-suite claim.",
}
target = OUT / "probe-result.json"
assert not target.exists()
target.write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8",
    newline="\n",
)
print(json.dumps(result, ensure_ascii=False, indent=2))

"""Run one focused public stage, preserving every output difference."""

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "head"
OUT = ROOT / "evidence"
SOURCE = "df516a0078421d9b092b2c8626368d2f23c2fe09"
commands = {
    "tests": [
        "py/main_test.py",
        "py/tests/test_mam_json_verses.py",
        "py/tests/test_mam_simple_dualcant_loader.py",
        "py/tests/test_dual_cant_detangle.py",
        "py/tests/test_silluq_before_meteg.py",
        "py/tests/test_mb_cmn_kq_special_templates.py",
        "py/tests/test_mpplus_latest_note_schema.py",
    ],
    "foi": ["py/main_foi_features_of_interest.py", "--single-threaded"],
    "morphhb": ["py/main_mam_morphhb.py"],
    "intro-review": ["py/main_intro_doc_audit.py", "review"],
    "breuer-survey": ["py/main_accgram.py", "survey-breuer-zaqef-units"],
    "black": [
        "-m",
        "black",
        "--check",
        "py/accgram/mam_simple_verse.py",
        "py/foi/foi_wikitext_helpers.py",
        "py/intro_doc_audit/review.py",
        "py/mam_morphhb/morphhb_plus.py",
        "py/mb_cmn/mam_json_verses.py",
    ],
    "probes": ["py/df516a00_probe.novc.py"],
    "probes-corrected": ["py/df516a00_probe.novc.py"],
}
name = sys.argv[1]
target = OUT / (name + ".json")
assert not target.exists()
state = ROOT / "stage.json"
if state.exists():
    assert json.loads(state.read_bytes())["state"] != "running"
assert (
    subprocess.check_output(["git", "-C", str(TREE), "rev-parse", "HEAD"])
    .decode()
    .strip()
    == SOURCE
)
env = os.environ.copy()
for key in ["REPO_MAM_PRIVATE_DIR", "REPO_MAM_BASICS_DIR", "REPO_MAM_PARSED_DIR"]:
    env.pop(key, None)
env.update(
    PATH="/workspace/.cloud-setup/bin:" + env["PATH"],
    XDG_CACHE_HOME="/workspace/.cloud-setup/cache",
    UV_PYTHON_INSTALL_DIR="/workspace/.cloud-setup/python",
    PLAYWRIGHT_BROWSERS_PATH="/workspace/.cloud-setup/cache/ms-playwright",
    PYTHONDONTWRITEBYTECODE="1",
    PYTHONUNBUFFERED="1",
)
command = ["/workspace/MAM-basics/.venv/bin/python", "-B", *commands[name]]
d = {
    "stage": name,
    "state": "running",
    "source": SOURCE,
    "cwd": str(TREE),
    "command": command,
    "started_utc": datetime.now(timezone.utc).isoformat(),
}
state.write_text(json.dumps(d, indent=2) + "\n")
target.write_text(json.dumps(d, indent=2) + "\n")
t = time.monotonic()
print("START", name, flush=True)
with (OUT / (name + ".log")).open("wb") as log:
    r = subprocess.run(command, cwd=TREE, env=env, stdout=log, stderr=subprocess.STDOUT)
d.update(
    state="completed",
    exit=r.returncode,
    seconds=round(time.monotonic() - t, 6),
    finished_utc=datetime.now(timezone.utc).isoformat(),
)
for label, args in [
    ("status", ["status", "--porcelain=v1", "-z"]),
    ("diff", ["diff", "--binary"]),
]:
    raw = subprocess.check_output(["git", "-C", str(TREE), *args])
    (OUT / (name + ("-status.z" if label == "status" else ".diff"))).write_bytes(raw)
    if label == "status":
        d["clean"] = not raw
state.write_text(json.dumps(d, indent=2) + "\n")
target.write_text(json.dumps(d, indent=2) + "\n")
print(json.dumps(d), flush=True)
sys.exit(r.returncode)

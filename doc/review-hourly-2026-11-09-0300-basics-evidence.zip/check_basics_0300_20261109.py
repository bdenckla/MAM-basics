"""Independent public DOM and spelling-accounting comparison."""

from collections import Counter
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
import time

root=Path('/workspace/MAM-basics')
evidence=root/'.novc/review-hourly-20261109-0300-basics'
base='e8c8ca748f4cab99255782b787f95ed7ccd30e28'
tip='e686160a167bd1f50ccf058137760fdd075c42d8'
start=time.monotonic()
spec=importlib.util.spec_from_file_location('public_reader_dom',Path('/workspace/scratch/check_hebrew_reader_20261108.py'))
helper=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=helper
spec.loader.exec_module(helper)
Parser,Node=helper.Parser,helper.Node
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
def old(path):return git('show',base+':'+path)
mark=re.compile(r'[\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7-\u05c9]')
avi=[]
for path in ['doc/near-aleppo-avi-ketiv-investigation.html','gh-pages/near-aleppo/avi-ketiv-investigation.html']:
    before=old(path).decode();after=(root/path).read_text()
    n=[0]
    def replace(m):
        if not mark.search(m[2]):
            n[0]+=1
            return m[0].replace(' lang="hbo"','',1)
        return m[0]
    expected=re.sub(r'<bdi( lang="hbo" dir="rtl")>(.*?)</bdi>',replace,before)
    assert n[0]==7 and expected==after
    avi.append(dict(path=path,exact_reconstruction=True,unpointed_lang_removed=7))
gaps=[]
for name in ['missing_sections_nakh.html','missing_sections_torah.html']:
    path='gh-pages/aleppo/'+name
    before,after=old(path).decode(),(root/path).read_text()
    assert re.sub(r'<style>.*?</style>','',before,flags=re.S)==re.sub(r'<style>.*?</style>','',after,flags=re.S)
    style=re.search(r'<style>(.*?)</style>',after,re.S)[1]
    assert 'url("../woff2/Taamey_D.woff2")' in style and 'local(' not in style
    for selector in ['.verse','.verse-he']:
        rule=re.search(re.escape(selector)+r'\s*\{([^}]+)\}',style)[1]
        assert 'font-family: "Taamey D WOFF2",' in rule
    assert 'font-family' not in re.search(r'td\.he\s*\{([^}]+)\}',style)[1]
    assert (root/'gh-pages/aleppo/../woff2/Taamey_D.woff2').is_file()
    gaps.append(dict(path=path,non_style_bytes_exact=True,pinned_local_font_target_resolves=True))
path='gh-pages/book-of-job/jobn/job5_orphan_qere_points.html'
before,after=[Parser(b.decode()).root for b in [old(path),(root/path).read_bytes()]]
assert helper.fold(before.text())==helper.fold(after.text())
def counts(doc):return Counter(n.text() for n in doc.all('span') if n.attrs.get('class')=='unpointed-tanakh')
delta=counts(after)-counts(before)
assert sum(delta.values())==4 and len(delta)==4
changes=[0,0]
def canonical(n,side):
    if isinstance(n,str):return helper.fold(n) or None
    attrs=dict(n.attrs)
    if side=='before' and n.tag=='bdi' and attrs.get('lang')=='hbo' and not mark.search(n.text()):
        del attrs['lang'];changes[0]+=1
    children=[x for c in n.children if (x:=canonical(c,side)) is not None]
    if side=='after' and n.tag=='span' and attrs.get('class')=='unpointed-tanakh':
        # Strip only the four new wrappers, keeping older spelling wrappers in both trees.
        return ('upt',children)
    if side=='before' and n.tag=='span' and attrs.get('class')=='unpointed-tanakh':
        return ('upt',children)
    if n.tag=='bdi' and side=='before' and n.attrs.get('lang')=='hbo' and not mark.search(n.text()):
        children=[('upt',children)]
    return (n.tag,tuple(sorted(attrs.items())),children)
assert canonical(before,'before')==canonical(after,'after')
assert changes[0]==4
frequency=[]
for name in ['custom-dict-freqs-ordered-by-entry.json','custom-dict-freqs-ordered-by-count.json']:
    path='book-of-job/out/'+name
    a,b=json.loads(old(path)),json.loads((root/path).read_bytes())
    assert set(a)==set(b)
    for key in a:
        if key!='words_unpointed_tanakh':assert a[key]==b[key],key
    ad,bd=a['words_unpointed_tanakh'],b['words_unpointed_tanakh']
    actual={key:bd.get(key,0)-ad.get(key,0) for key in set(ad)|set(bd) if ad.get(key,0)!=bd.get(key,0)}
    assert actual==dict(delta)
    frequency.append(dict(path=path,changes=[dict(word=key,before=ad.get(key,0),after=bd.get(key,0),delta=amount) for key,amount in actual.items()],net_delta=sum(actual.values())))
out=dict(result='pass',avi=avi,aleppo_gaps=gaps,boj_visible_text_and_dom='Exact after only four lang removals/new unpointed-tanakh wrappers and serializer whitespace',frequency=frequency,no_hebrew_normalization=True,seconds=round(time.monotonic()-start,3))
(evidence/'independent-checks.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(dict(result='pass',avi_pages=2,avi_lang_changes=14,gap_pages=2,boj_wrapper_changes=4,spelling_frequency_net_delta=4,seconds=out['seconds'])))

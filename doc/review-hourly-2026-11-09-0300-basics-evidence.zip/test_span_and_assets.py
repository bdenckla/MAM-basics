"""Focused guard and report packaging checks requested for the bounded review."""

import ast
from pathlib import Path
import subprocess

import pytest
from author_boj_util import author as boj_author
from boj_render import boj_html
from mb_author import author as shared_author
from mb_misc import mb_html
from py_render import rt_assets
from py_html import taamey_d_assets


@pytest.mark.parametrize(
    "author,html", [(boj_author, boj_html), (shared_author, mb_html)]
)
def test_guard_nested_and_lifted(author, html):
    plain = "".join(chr(x) for x in [0x5D0, 0x5D1])
    for contents in [
        plain,
        [plain],
        (html.span(plain),),
        [html.span([plain, html.span(chr(0x5BE) + plain + chr(0x5C3))])],
    ]:
        with pytest.raises(ValueError, match="unpointed Hebrew"):
            author.hbo(contents)
        assert author.hbo(contents, lifted=True)["attr"]["lang"] == "hbo"
        assert author.unpointed(contents).get("attr", {}).get("lang") is None
    pointed = plain + chr(0x5B7)
    for contents in [pointed, [html.span(pointed)]]:
        with pytest.raises(ValueError, match="pointed Hebrew"):
            author.unpointed(contents)
        assert author.hbo(contents)["attr"]["lang"] == "hbo"


@pytest.mark.parametrize("author", [boj_author, shared_author])
@pytest.mark.parametrize("mark", [0x5C8, 0x5C9])
def test_annotation_marks_are_pointing(author, mark):
    text = chr(0x5D0) + chr(mark)
    assert author.hbo(text)["attr"]["lang"] == "hbo"
    with pytest.raises(ValueError, match="pointed Hebrew"):
        author.unpointed([text])


def test_regex_equivalence_and_complete_hebrew_block():
    root = Path.cwd()
    path = "py/mb_author/author.py"
    old = subprocess.check_output(
        ["git", "show", "e8c8ca748f4cab99255782b787f95ed7ccd30e28:" + path], cwd=root
    )
    node = next(
        n
        for n in ast.parse(old).body
        if isinstance(n, ast.Assign)
        and isinstance(n.targets[0], ast.Name)
        and n.targets[0].id == "_HEBREW_MARK_RE"
    )
    pattern = ast.literal_eval(node.value.args[0])
    assert shared_author._HEBREW_MARK_RE.pattern == pattern
    assert boj_author._HEBREW_MARK_RE.pattern == pattern
    assert (
        boj_author._HEBREW_LETTER_RE.pattern == shared_author._HEBREW_LETTER_RE.pattern
    )
    for codepoint in range(0x590, 0x600):
        text = chr(0x5D0) + chr(codepoint)
        assert boj_author._is_unpointed_hebrew(
            text
        ) == shared_author._is_unpointed_hebrew(text)


def test_holman_published_and_standalone_assets(tmp_path):
    published = tmp_path / "published"
    href = rt_assets.write_report_assets(
        published / "findings.css", published / "findings.js", ["a", "b"]
    )
    assert href == "../report.css"
    css = (published / "findings.css").read_text()
    assert 'url("../woff2/Taamey_D.woff2")' in css
    assert "__TAAMEY_D_WOFF2__" not in css and "local(" not in css
    assert not list(published.rglob("*.woff2"))
    standalone = tmp_path / "standalone"
    href = rt_assets.write_report_assets(
        standalone / "findings.css",
        standalone / "findings.js",
        ["a", "b"],
        report_css_href=None,
    )
    assert href == "report-assets/report.css"
    assert 'url("woff2/Taamey_D.woff2")' in (standalone / "findings.css").read_text()
    assert (
        standalone / "woff2/Taamey_D.woff2"
    ).read_bytes() == taamey_d_assets.font_bytes()
    assert (standalone / "report-assets/report.css").read_bytes() == (
        Path.cwd() / "gh-pages/report.css"
    ).read_bytes()
    assert (standalone / "findings.js").read_bytes() == (
        published / "findings.js"
    ).read_bytes()

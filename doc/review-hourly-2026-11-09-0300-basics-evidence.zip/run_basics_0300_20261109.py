"""Record sequential focused checks for the November 9 public endpoint."""

import json
from pathlib import Path
import subprocess
import time
from datetime import datetime, timezone

root = Path("/workspace/MAM-basics")
evidence = root / ".novc/review-hourly-20261109-0300-basics"
tip = "e686160a167bd1f50ccf058137760fdd075c42d8"
base = "e8c8ca748f4cab99255782b787f95ed7ccd30e28"
python = str(root / ".venv/bin/python")
rows = []


def git(*args):
    return subprocess.check_output(["git", *args], cwd=root)


def run(label, args):
    start = time.monotonic()
    with (evidence / (label + ".log")).open("wb") as log:
        p = subprocess.run(args, cwd=root, stdout=log, stderr=subprocess.STDOUT)
    row = dict(
        name=label,
        command=args,
        cwd=str(root),
        source=tip,
        exit=p.returncode,
        seconds=round(time.monotonic() - start, 3),
        finished=datetime.now(timezone.utc).isoformat(),
    )
    rows.append(row)
    (evidence / "commands.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps(row), flush=True)
    diff = git("diff", "--binary")
    (evidence / (label + "-generated.diff")).write_bytes(diff)
    assert (
        not diff
    ), "Unexpected generated difference preserved; inspect before continuing"
    assert p.returncode == 0


assert git("rev-parse", "HEAD").decode().strip() == tip
assert not git("status", "--porcelain", "-z")
evidence.mkdir(exist_ok=True)
paths = git("diff", "--name-only", "-z", base, tip).decode().split("\0")[:-1]
assert len(paths) == 15
(evidence / "input.json").write_text(
    json.dumps(
        dict(
            base=base,
            source=tip,
            paths=paths,
            status_parent="bbb976083f333ea28e489d4feae62f7013991347",
        ),
        indent=2,
    )
    + "\n"
)
run("environment", [python, "-m", "pip", "check"])
run("boj-authored", [python, "py/main_gen_misc_authored_english_documents.py"])
run("holman-published", [python, "py/main_verify_and_render_table.py"])
run("misc-authored", [python, "py/main_authored.py", "gen-misc"])
run(
    "focused-tests",
    [
        python,
        "py/main_test.py",
        "-q",
        "-ra",
        "py/tests/test_shared_html_styles.py",
        "py/tests/source_hygiene_test.py",
        "py/tests/test_prose_mark_order.py",
        str(evidence / "test_span_and_assets.py"),
    ],
)
run(
    "black-check",
    [python, "-m", "black", "--check", *[p for p in paths if p.endswith(".py")]],
)
run("endpoint-whitespace", ["git", "diff", "--check", base, tip])
print("All maintained public stages complete", flush=True)

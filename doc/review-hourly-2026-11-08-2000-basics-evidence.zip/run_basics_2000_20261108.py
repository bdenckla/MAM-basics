"""Sequential maintained checks of the shared author-span endpoint."""

import fcntl
import json
from pathlib import Path
import subprocess
import time
from datetime import datetime, timezone

ROOT = Path("/workspace/MAM-basics")
EVID = ROOT / ".novc/review-hourly-20261108-2000-basics"
BASE = "84ad02264fce66d2b41ca0b4ac3fd3522d85e22e"
TIP = "e8c8ca748f4cab99255782b787f95ed7ccd30e28"
PY = str(ROOT / ".venv/bin/python")


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)


def run(name, args):
    t = time.monotonic()
    started = datetime.now(timezone.utc).isoformat()
    with (EVID / (name + ".log")).open("wb") as log:
        p = subprocess.run(args, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    row = dict(
        name=name,
        command=args,
        cwd=str(ROOT),
        source=TIP,
        started=started,
        exit=p.returncode,
        seconds=round(time.monotonic() - t, 3),
    )
    rows.append(row)
    (EVID / "commands.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps(row), flush=True)
    patch = git("diff", "--binary")
    (EVID / (name + "-generated.diff")).write_bytes(patch)
    assert not patch, "Generated differences preserved; inspect before continuation"
    assert p.returncode == 0


assert git("rev-parse", "HEAD").decode().strip() == TIP
assert not git("status", "--porcelain", "-z")
EVID.mkdir(exist_ok=False)
with (ROOT / ".git/codex-index-refresh.lock").open("a") as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
paths = git("diff", "--name-only", "-z", BASE, TIP).decode().split("\0")[:-1]
assert len(paths) == 35
changed_py = [p for p in paths if p.endswith(".py")]
(EVID / "input.json").write_text(
    json.dumps(
        dict(
            base=BASE,
            source=TIP,
            paths=paths,
            interpreter=PY,
            status_parent="71fc1ec34cf4306df89389a7ffde4dbdc7d7e947",
        ),
        indent=2,
    )
    + "\n"
)
(EVID / "source-code.diff").write_bytes(
    git("diff", BASE, TIP, "--", "py", "dot-claude")
)
rows = []
run("environment", [PY, "-m", "pip", "check"])
run("gen-misc", [PY, "py/main_authored.py", "gen-misc"])
run("gen-mam-parsed-docs", [PY, "py/main_authored.py", "gen-mam-parsed-docs"])
run("gen-mam-for-sefaria-doc", [PY, "py/main_authored.py", "gen-mam-for-sefaria-doc"])
run("gen-site", [PY, "py/main_authored.py", "gen-site"])
tests = [
    "test_author_std_table",
    "test_prose_conventions",
    "test_transliterations",
    "test_shared_html_styles",
    "test_prose_mark_order",
    "test_explicit_claims",
    "test_verify_mp_payload_examples",
    "test_undollared_check",
]
assert all((ROOT / "py/tests" / f"{n}.py").is_file() for n in tests)
run(
    "focused-tests",
    [PY, "py/main_test.py", "-q", "-ra", *[f"py/tests/{n}.py" for n in tests]],
)
run("black-check", [PY, "-m", "black", "--check", *changed_py])
run("endpoint-whitespace", ["git", "diff", "--check", BASE, TIP])
print(
    "All maintained focused stages completed; tracked outputs byte-identical",
    flush=True,
)

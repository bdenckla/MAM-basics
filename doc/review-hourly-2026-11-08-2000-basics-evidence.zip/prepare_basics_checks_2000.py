"""Adapt prior reader checks to the inspected font/footnote contract."""

import difflib
import hashlib
import json
from pathlib import Path

root=Path('/workspace/MAM-basics')
evidence=root/'.novc/review-hourly-20261108-2000-basics'
a=Path('/workspace/scratch/check_hebrew_reader_20261108.py').read_text(encoding='utf8')
b=a.replace('.novc/review-hebrew-reader-20261108-e8e75686',str(evidence.relative_to(root)))
b=b.replace('assert any(ref in n.children for n in dom.all("sup"))','assert not any(ref in n.children for n in dom.all("sup"))')
needle='and isinstance(n.func, ast.Name)\n            and n.func.id == "_hbo_checked"'
assert b.count(needle)==1
b=b.replace(needle,'''and ((isinstance(n.func, ast.Name) and n.func.id == "_pointed")
                 or (isinstance(n.func, ast.Attribute) and isinstance(n.func.value, ast.Name)
                     and n.func.value.id == "author" and n.func.attr == "unpointed"))''')
needle='    assert len(pointed) == 4\n'
assert b.count(needle)==1
b=b.replace(needle,needle+'''    mark = re.compile(r"[\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7-\u05c9]")
    for run in dom.all("bdi"):
        assert (run.attrs.get("lang") == "hbo") == bool(mark.search(run.text()))
    assert sum(n.attrs.get("lang") == "hbo" for n in dom.all("bdi")) == 4
''')
(evidence/'reader-check.py').write_text(b,encoding='utf8')
(evidence/'reader-check-adaptation.json').write_text(json.dumps(dict(previous_sha256=hashlib.sha256(a.encode()).hexdigest(),current_sha256=hashlib.sha256(b.encode()).hexdigest(),reason='Inspected endpoint intentionally removes 14 superscript wrappers and uses author.unpointed for 279 labels, _pointed for four forms. Reuse all forms/order/marks/assets/links/footnotes checks with those explicit assumptions; add all-run lang classification.'),indent=2)+'\n')
(evidence/'reader-check.patch').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='previous-reader-check',tofile='endpoint-reader-check')),encoding='utf8')
print('Reader checker adapted; no check executed by preparation')

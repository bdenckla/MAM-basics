"""Independent codepoint/DOM comparison of all changed public HTML outputs."""

import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
import time

root=Path('/workspace/MAM-basics')
evidence=root/'.novc/review-hourly-20261108-2000-basics'
base='84ad02264fce66d2b41ca0b4ac3fd3522d85e22e'
tip='e8c8ca748f4cab99255782b787f95ed7ccd30e28'
spec=importlib.util.spec_from_file_location('reader_dom_helper',Path('/workspace/scratch/check_hebrew_reader_20261108.py'))
helper=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=helper
spec.loader.exec_module(helper)
Parser,Node=helper.Parser,helper.Node
mark=re.compile(r'[\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7-\u05c9]')
letter=re.compile(r'[\u05d0-\u05ea]')
def git(*args):
    return subprocess.check_output(['git',*args],cwd=root)
start=time.monotonic()
paths=git('diff','--name-only','-z',base,tip).decode().split('\0')[:-1]
records=[]
for path in [p for p in paths if p.startswith('gh-pages/') and p.endswith('.html')]:
    before,after=[git('show',commit+':'+path) for commit in [base,tip]]
    old,new=[Parser(raw.decode()).root for raw in [before,after]]
    assert helper.fold(old.text())==helper.fold(new.text()),path
    counts={'removed_lang':0,'removed_footnote_sup':0}
    def canonical(n,old_side=False):
        if isinstance(n,str):
            return helper.fold(n) or None
        attrs=dict(n.attrs)
        if old_side and attrs.get('lang')=='hbo' and letter.search(n.text()) and not mark.search(n.text()):
            del attrs['lang']
            counts['removed_lang']+=1
        children=[value for c in n.children if (value:=canonical(c,old_side)) is not None]
        if old_side and n.tag=='sup' and 'review_of_hebrew_reader_for_the_pentateuch' in path:
            assert len(children)==1 and n.children[0].tag=='a' and n.children[0].attrs['id'].startswith('fnref-')
            counts['removed_footnote_sup']+=1
            return children[0]
        return (n.tag,tuple(sorted(attrs.items())),children)
    assert canonical(old,True)==canonical(new),path
    assert all(not(letter.search(n.text()) and not mark.search(n.text())) for n in new.all() if n.attrs.get('lang')=='hbo'),path
    records.append(dict(path=path,**counts,visible_text_codepoint_exact_after_line_whitespace=True,all_other_dom_and_attributes_exact=True,sha256=hashlib.sha256(after).hexdigest()))
assert len(records)==12
assert sum(r['removed_lang'] for r in records)==433
assert sum(r['removed_footnote_sup'] for r in records)==14
out=dict(result='pass',source=tip,base=base,html_files=len(records),removed_lang=sum(r['removed_lang'] for r in records),removed_footnote_sup=14,comparisons=records,no_hebrew_normalization=True,seconds=round(time.monotonic()-start,3))
(evidence/'span-output-comparison.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='comparisons'}))

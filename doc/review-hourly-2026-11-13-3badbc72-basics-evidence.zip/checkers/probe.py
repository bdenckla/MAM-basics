"""Independent committed input/output, asset and public reading integrity checks."""

from collections import Counter
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
from urllib.parse import unquote, urlsplit

from lxml import html
from PIL import Image

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "head"
OUT = ROOT / "evidence"
sys.path.insert(0, str(TREE / "py"))  # Disposable review harness only.
from author_site import stress_helper_comparison as product
from mb_cmn import uni_denorm

BASE = "05191160832cba00e6bcd86959b16520c2f74d7b"
SOURCE = "3badbc72b8e57f99617980c4e6383a7cf52dd4d6"


def git(*args):
    return subprocess.check_output(["git", "-C", str(TREE), *args])


def dump(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()


def text(node):
    return " ".join(node.text_content().split())


def qere_text(node):
    node = deepcopy(node)
    for ketiv in node.xpath('.//span[@class="mam-kq-k"]'):
        ketiv.drop_tree()
    return text(node).replace("[", "").replace("]", "")


assert git("rev-parse", "HEAD").decode().strip() == SOURCE
assert not git("status", "--porcelain=v1", "-z")
paths = list(
    filter(None, git("diff", "--name-only", "-z", BASE, SOURCE).decode().split("\0"))
)
assert len(paths) == 62
identities = {}
for path in paths:
    raw = (TREE / path).read_bytes()
    assert raw == git("show", SOURCE + ":" + path)
    identities[path] = {
        "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "blob": git("rev-parse", SOURCE + ":" + path).decode().strip(),
    }
(OUT / "identities.json").write_bytes(dump(identities))
# Do not duplicate the supplied third-party crops into the receipt archive.
(OUT / "endpoint-text.diff").write_bytes(
    git("diff", BASE, SOURCE, "--", ".", ":(exclude)gh-pages/stress-helpers/img/")
)
git("diff", "--check", BASE, SOURCE)
cache = {}


def page(path):
    path = path.resolve()
    if path not in cache:
        cache[path] = html.fromstring(path.read_bytes())
    return cache[path]


result = {
    "source": SOURCE,
    "base": BASE,
    "paths": len(paths),
    "editions": {},
    "limits": "No live-source acquisition, full research catalogue, browser, font or native Windows verification.",
}
all_crops = set()
local_links = 0
external = set()
js_pages = []
for edition in ("koren", "simanim-tanakh"):
    data = json.loads((TREE / "in/stress-helpers" / (edition + ".json")).read_bytes())
    target = TREE / "gh-pages/stress-helpers" / (edition + ".html")
    doc = page(target)
    rows = doc.xpath('//table[@id="observations"]/tbody/tr')
    assert len(rows) == len(data["differences"]) > 0
    ids = doc.xpath("//*[@id]/@id")
    assert len(ids) == len(set(ids))
    assert doc.xpath('//script[@src="controls.js" and @defer]')
    assert doc.xpath('//*[@id="hebrew-size"]/@value') == ["30"]
    assert len(doc.xpath('//*[@class="scan" and @hidden]')) == len(rows) + 1
    body_matches = []
    supplemental = []
    phonetic = []
    negative = 0
    for index, (record, row) in enumerate(zip(data["differences"], rows)):
        assert row.get("data-outcome") == record["category"]
        assert row.xpath('.//span[@class="hebrew"]/text()') == [
            record["mam"],
            record["printed"],
        ]
        assert row.xpath(".//img/@src") == record["crops"]
        assert record["mam"] != record["printed"]
        assert all(uni_denorm.has_std_mark_order(record[f]) for f in ("mam", "printed"))
        loc = urlsplit(record["verse_href"])
        source_doc = page(target.parent / unquote(loc.path))
        verse = source_doc.xpath("//*[@id=$id]", id=loc.fragment)
        assert len(verse) == 1
        verse_row = verse[0].getparent()
        reading = " ".join(record["mam"].split())
        if reading in qere_text(verse_row):
            body_matches.append(index)
        else:
            assert record.get("strand"), (edition, index, record)
            notes = [
                n
                for n in record["notes"]
                if n.get("label") == "MAM printed-tradition note"
            ]
            assert len(notes) == 1, (edition, index, record)
            note_loc = urlsplit(notes[0]["href"])
            note_doc = page(target.parent / unquote(note_loc.path))
            note_anchor = note_doc.xpath("//*[@id=$id]", id=note_loc.fragment)
            assert len(note_anchor) == 1
            clauses = note_anchor[0].xpath("following::ul[1]")
            assert len(clauses) == 1 and reading in qere_text(clauses[0]), (
                edition,
                index,
                record,
            )
            supplemental.append(index)
        for note in record.get("notes", []):
            if note.get("label") != "Phonetic MAM":
                continue
            loc = urlsplit(note["href"])
            phon_doc = page(target.parent / unquote(loc.path))
            heading = phon_doc.xpath("//*[@id=$id]", id=loc.fragment)
            assert len(heading) == 1
            table = heading[0].getnext()
            phon_rows = [
                r
                for r in table.xpath(".//tr")
                if r.xpath("./td") and text(r.xpath("./td")[0]) == reading
            ]
            assert len(phon_rows) == 1, (edition, index, reading)
            pronunciations = phon_rows[0].xpath(
                './/span[starts-with(@class,"pronunciation-")]'
            )
            assert len(pronunciations) == 2
            for pronunciation in pronunciations:
                stressed = pronunciation.xpath('.//span[@class="jt-stressed"]')
                assert len(stressed) == 1 and not (stressed[0].tail or "").strip(), (
                    edition,
                    index,
                )
            phonetic.append(index)
        if record["category"] == "redundant-edition":
            assert record["mam"].count("\N{HEBREW ACCENT PASHTA}") == 1
            assert record["printed"].count("\N{HEBREW ACCENT PASHTA}") == 2
            assert re.search(
                "[\u05d0-\u05ea][\u0591-\u05c9]*\N{HEBREW POINT SHEVA}[\u0591-\u05c9]*[\u05d0-\u05ea][\u0591-\u05c9]*\N{HEBREW POINT SHEVA}[\u0591-\u05c9]*$",
                record["mam"],
            )
        all_crops.update(record["crops"])
    for node in doc.xpath("//*[@href or @src]"):
        for key in ("href", "src"):
            value = node.get(key)
            if value is None:
                continue
            loc = urlsplit(value)
            if loc.scheme or loc.netloc:
                external.add(value)
                continue
            dest = (target.parent / unquote(loc.path)).resolve() if loc.path else target
            assert dest.is_relative_to(TREE / "gh-pages") and dest.is_file(), value
            if loc.fragment:
                assert page(dest).xpath(
                    "//*[@id=$id or @name=$id]", id=unquote(loc.fragment)
                ), value
            local_links += 1
    for field, bad in (
        ("mam", ""),
        ("printed", ""),
        ("category", "UNKNOWN"),
        ("crops", []),
        ("crops", ["../outside.png"]),
        ("crops", ["img/absent.png"]),
    ):
        altered = deepcopy(data)
        altered["differences"][0][field] = bad
        try:
            product._check(altered, target.parent)
        except (ValueError, FileNotFoundError):
            negative += 1
        else:
            raise AssertionError((edition, field))
    duplicate = deepcopy(data)
    duplicate["differences"].append(deepcopy(duplicate["differences"][0]))
    try:
        product._check(duplicate, target.parent)
    except ValueError:
        negative += 1
    else:
        raise AssertionError("duplicate accepted")
    result["editions"][edition] = {
        "rows": len(rows),
        "categories": dict(Counter(r["category"] for r in data["differences"])),
        "body_readings": len(body_matches),
        "supplemental_indices": supplemental,
        "phonetic_final_stress_rows": len(phonetic),
        "negative_checks": negative,
    }
    js_pages.append(
        {
            "edition": edition,
            "rows": [
                {"outcome": row.get("data-outcome"), "cells": [text(c) for c in row]}
                for row in rows
            ],
            "queries": [r["mam"] for r in data["differences"]],
        }
    )
pngs = {}
for crop in sorted(all_crops):
    path = TREE / "gh-pages/stress-helpers" / crop
    with Image.open(path) as image:
        assert image.format == "PNG"
        pngs[crop] = {"width": image.width, "height": image.height}
        image.verify()
assert {
    "img/" + p.name for p in (TREE / "gh-pages/stress-helpers/img").glob("*.png")
} == all_crops
assert len(pngs) == 51
result.update(
    crops=len(pngs),
    local_link_attributes=local_links,
    external_links_unfetched=sorted(external),
)
(OUT / "png-integrity.json").write_bytes(dump(pngs))
(OUT / "js-input.json").write_bytes(dump(js_pages))
(OUT / "probe-result.json").write_bytes(dump(result))
print(json.dumps(result, ensure_ascii=False, indent=2))

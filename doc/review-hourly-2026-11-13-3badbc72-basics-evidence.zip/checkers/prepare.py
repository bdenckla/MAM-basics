"""Prepare the bounded receipt on its existing isolated receipt lineage."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "head"
OUT = ROOT / "evidence"
BASE = "05191160832cba00e6bcd86959b16520c2f74d7b"
SOURCE = "3badbc72b8e57f99617980c4e6383a7cf52dd4d6"
PARENT = "00d973a398fd018f68a1abc93e6d6ad639bc82eb"
NIGHTLY = "04ce8be904bbd1f15e33a5101976a7e9e6f9f7ca"
WINDOWS = "3030161007bc393f554cf0c95cf819ed4d81a93c"
NAME = "review-hourly-2026-11-13-3badbc72-basics"
BRANCH = "review-hourly-20261113-3badbc72-basics-receipts"


def git(*args, tree=TREE):
    return subprocess.check_output(["git", "-C", str(tree), *args])


def dump(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


assert git("rev-parse", "HEAD").decode().strip() == SOURCE
assert not git("status", "--porcelain=v1", "-z")
assert not git("ls-remote", "origin", "refs/heads/" + BRANCH)
assert git("rev-list", "--count", BASE + ".." + SOURCE).strip() == b"1"
for ref in (SOURCE, PARENT):
    assert git(
        "ls-tree", "-r", "--name-only", "-z", ref, "--", ".github"
    ).decode().split("\0") == [".github/workflows/pages.yml", ""]
    assert (
        git("rev-parse", ref + ":.github/workflows/pages.yml").decode().strip()
        == "18ceb19405424710bda47d9a38c470cc2ed9c385"
    )
    assert b"on:\n  workflow_dispatch:\n" in git(
        "show", ref + ":.github/workflows/pages.yml"
    )
for ancestor in (NIGHTLY, WINDOWS):
    subprocess.run(
        ["git", "-C", str(TREE), "merge-base", "--is-ancestor", ancestor, PARENT],
        check=True,
    )
probe = json.loads((OUT / "probe-result.json").read_bytes())
javascript = json.loads((OUT / "js-result.json").read_bytes())
assert [v["rows"] for v in probe["editions"].values()] == [31, 19]
assert probe["crops"] == 51 and probe["local_link_attributes"] == 205
assert [v["query_category_combinations"] for v in javascript["results"]] == [536, 301]
names = (
    "black",
    "gen-site",
    "tests",
    "html",
    "probes",
    "probes-qere",
    "probes-corrected",
    "javascript",
)
stages = [json.loads((OUT / (n + ".json")).read_bytes()) for n in names]
assert [s["exit"] for s in stages] == [0, 0, 0, 0, 1, 1, 0, 0]
assert all(
    (OUT / (n + ".diff")).read_bytes() == b""
    and (OUT / (n + ".status")).read_bytes() == b""
    for n in names
)
assert "13 passed" in (OUT / "tests.log").read_text(encoding="utf-8")
disposition = {
    "result": "No consequential introduced defect established; no source/product repair.",
    "review": "Complete one-commit/62-path endpoint, including all authored code/data/page/asset changes.",
    "research_limits": "Coverage/OCR/reverse-catalogue totals and the linked live Wikisource correction remain attributed authored research, not independently reproduced by this screen. No original full scan/catalogue or live acquisition was used; no new editorial, licensing or publication decision.",
    "independent_checks": probe,
    "javascript": javascript,
    "scratch_failures": [
        "Initial probe assumed visible verse text had no qere apparatus brackets. Corrected to select the explicitly labelled qere span and omit the ketiv display; original checker and failure retained.",
        "Second probe assumed strand data appeared in the body book page. Two records explicitly cite printed-tradition note clauses instead; corrected to read exactly those linked clauses. Original checker and failure retained.",
    ],
    "visual_samples": [
        {
            "crop": "koren-levit-10-4-A3-L-166-213-1.png",
            "observed": "Supplied crop agrees with telisha gedolah on qof and gershayim on bet.",
        },
        {
            "crop": "koren-2samuel-3-32-BB-2S-146-36723-1.png",
            "observed": "Supplied crop agrees with the additional pashta on yod.",
        },
        {
            "crop": "simanim-tanakh-exodus-20-2-A9-A2-10C-0350-1684-1.png",
            "observed": "Supplied crop agrees with merkha on tav and initial meteg.",
        },
        {
            "crop": "simanim-tanakh-2samuel-13-20-BB-2S-0526-691-1.png",
            "observed": "Supplied crop agrees with final zarqa and no extra helper.",
        },
    ],
    "visual_limit": "Four supplied crop samples only; no complete edition/source-image collation or browser/font check. Crops are not included in this evidence archive.",
    "prior_receipts": {
        "receipt_parent": PARENT,
        "nightly": NIGHTLY,
        "windows_supplement": WINDOWS,
    },
    "overall_reviewed": "210affe3ac2931473bead0de839be0de08309e3d",
    "latest_broad_tested": "9ed47c6e8999ecaf56031e9b3f524bee6e01507a",
    "pending": "Every prior pending window and historical limitation retained. Current Windows supplement covers its named four modules/41 tests at 9ed47c6e only. Taamey D corpus refresh/baseline remains pending.",
}
(OUT / "disposition.json").write_bytes(dump(disposition))
(OUT / "workflow-and-lineage.json").write_bytes(
    dump(
        {
            "source": SOURCE,
            "parent": PARENT,
            "nightly": NIGHTLY,
            "windows_supplement": WINDOWS,
            "workflow_blob": "18ceb19405424710bda47d9a38c470cc2ed9c385",
            "trigger": "workflow_dispatch only",
            "historical_receipts_retained": True,
        }
    )
)
payload = {p.name: p.read_bytes() for p in OUT.iterdir() if p.is_file()}
for name in ("run.py", "probe.py", "js-probe.cjs", "prepare.py"):
    payload["checkers/" + name] = (ROOT / name).read_bytes()
assert not any(n.endswith(".png") for n in payload)
payload["manifest.json"] = dump(
    {n: {"bytes": len(b), "sha256": sha(b)} for n, b in sorted(payload.items())}
)
receipts = ROOT / "receipts"
subprocess.run(
    [
        "git",
        "-C",
        "/workspace/MAM-basics",
        "worktree",
        "add",
        "-b",
        BRANCH,
        str(receipts),
        PARENT,
    ],
    check=True,
    capture_output=True,
)
assert git("rev-parse", "--show-toplevel", tree=receipts).decode().strip() == str(
    receipts
)
assert git("rev-parse", "HEAD", tree=receipts).decode().strip() == PARENT
assert git("branch", "--show-current", tree=receipts).decode().strip() == BRANCH
assert not git("status", "--porcelain=v1", "-z", tree=receipts)
archive = receipts / "doc" / (NAME + "-evidence.zip")
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as z:
    for name, data in sorted(payload.items()):
        z.writestr(name, data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist()))
    for name, record in json.loads(z.read("manifest.json")).items():
        assert (
            len(z.read(name)) == record["bytes"]
            and sha(z.read(name)) == record["sha256"]
        )
rows = "\n".join(f"| {s['stage']} | {s['exit']} | {s['seconds']} |" for s in stages)
report = f"""# Bounded Basics screen, November 13, 2026, 17:00 UTC cycle

State: completed 2026-11-13; focused technical review, no product repair

Frozen endpoint `{BASE}` -> `{SOURCE}`: one commit / 62 paths, fully examined. The new shared generator renders two authored comparison inputs, links both pages from the site index, and supplies search, outcome, size and crop controls, 51 supplied PNG crops, and explicit source-rights attribution. No consequential introduced defect was established; no Hebrew, editorial, licensing or publication decision changed. Receipt lineage continues from `{PARENT}`.

The maintained `py/main_authored.py gen-site` reproduces every tracked output exactly. Changed-source Black passes for all three Python files; **13 selected tests pass** through `py/main_test.py -q -ra` (site index/deploy root/relative links/shared styles/letter spacing/prose conventions). The comparison-folder HTML checker passes; its 140 shared/external CSS-class references are informational under the maintained checker, not output failures.

Independent checks reconcile **50 displayed pairs** (31 Koren / 19 the Simanim Tanakh), every category and crop association, **48** MAM body/qere readings and the **two explicitly linked printed-tradition note clauses**, all **26** linked Phonetic MAM final-stress rows, **205** local link/asset attributes and fragments, and all **51** PNGs' format/integrity and inventory. The 11 Koren and 13 the Simanim Tanakh redundant-helper entries have the displayed doubled pashta and double-sheva ending. Four supplied crop samples were viewed and agree with their listed mark configurations. **14** malformed/duplicate/missing-evidence rejection probes pass. All 62 endpoint files match their committed blobs; no crop is copied into the evidence archive.

The actual `controls.js` runs in a minimal Node DOM model: **837** query/category combinations, range changes, reset and four image toggles per page pass. This establishes the tested control behavior, not browser layout, accessibility-tree or font behavior.

| Recorded stage (exact arguments in evidence JSON) | Exit | Seconds |
| --- | ---: | ---: |
{rows}

Two scratch checker assumptions failed and were corrected without changing the product: qere brackets obstructed a raw-text comparison, and two comparison readings belong to their explicitly linked printed-tradition clauses rather than the body page. Both original scripts, logs and empty source diffs remain in the archive. The corrected checks use the actual qere markup and those exact clauses. All maintained and scratch-command tracked diffs/statuses are empty.

Research coverage/OCR/reverse-catalogue totals, the historic Wikisource correction and unsampled printed-edition claims remain attributed authored research. The original full research catalogues/scans and live correction were not acquired or independently reproduced. Reproducibility and public-text agreement do not establish editorial correctness or source publication rights. No live acquisition, broad/nightly rerun, private review, font/baseline or hbofonts work, native Windows execution, browser verification, main/shared integration, deployment/dispatch or schedule change occurred.

Reconciled nightly `{NIGHTLY}` and Windows supplement `{WINDOWS}` at source `9ed47c6e8999ecaf56031e9b3f524bee6e01507a`: the former records 66 mega steps and 1,449 passed / five intentional skips; the latter records 41 focused platform-sensitive tests plus native resource-API probes. These are prior attributed results, not this run. Latest broad-tested stays at that source. Overall reviewed-through stays `210affe3ac2931473bead0de839be0de08309e3d`; every other pending window, immutable receipt and Taamey D corpus/baseline limitation remains. The prior admission is reused; cross-machine ownership remains unverified.

Only this fresh isolated receipt/status/evidence branch is published. Source and receipt parent retain the sole manual-dispatch Pages workflow. [Evidence]({archive.name}): {archive.stat().st_size} bytes, SHA-256 `{sha(archive.read_bytes())}`; CRC and all payload sizes/hashes verified. Exact remote scope/bytes and owned-worktree cleanup/slot release are verified at closeout; home checkout and unrelated work are preserved.
"""
(receipts / "doc" / (NAME + ".md")).write_text(report, encoding="utf-8", newline="\n")
status_path = receipts / "doc/review-trial-status.md"
status = status_path.read_text(encoding="utf-8")
status = status.replace(
    "Latest bounded screen 9ed47c6e", "Previous bounded screen 9ed47c6e", 1
).replace("Latest focused evidence 9ed47c6e", "Previous focused evidence 9ed47c6e", 1)
new_rows = f"| Latest bounded screen 3badbc72 | `{BASE}` -> `{SOURCE}`; one commit / 62 paths. Complete code/data/page/asset endpoint examined; no consequential introduced defect or product repair. Research/source/editorial/publication limits retained. [Receipt]({NAME}.md). |\n| Latest focused evidence 3badbc72 | gen-site reproduces exactly; 13 selected tests, three-file Black, comparison HTML lint and independent 50-pair/51-PNG/205-link checks pass. All 26 linked Phonetic MAM stress rows agree; 837 offline JS filter combinations pass. Two corrected scratch assumptions retained; no browser or full research-catalogue verification. [Evidence]({archive.name}). |\n"
assert status.count("| Anchor | Commit/result |\n| --- | --- |\n") == 1
status = status.replace(
    "| Anchor | Commit/result |\n| --- | --- |\n",
    "| Anchor | Commit/result |\n| --- | --- |\n" + new_rows,
    1,
)
status += f"\n\n## Bounded screen, 2026-11-13 17:00 UTC cycle, 3badbc72\n\nOne commit / 62 paths reviewed with no consequential introduced defect or product repair. Maintained gen-site, three-file Black, 13 selected tests and comparison HTML lint pass with empty tracked diffs. Independent checks cover 50 displayed pairs, 48 public MAM body/qere readings plus two explicitly linked printed-tradition clauses, 26 linked Phonetic MAM stress rows, 51 PNGs, 205 local link/asset attributes and 837 offline JavaScript filter combinations. Two scratch assumptions about qere markup and supplement selection failed, were corrected and remain archived; no product mutation. Coverage/OCR/census and historic correction claims remain attributed research; four crop samples were viewed, not the full edition/scans. No live acquisition, broad rerun, browser/font/Windows claim or publication decision.\n\nReceipt lineage `{PARENT}` already reconciles November 13 nightly `{NIGHTLY}` and Windows supplement `{WINDOWS}`. Current supplemental Windows evidence is 41 focused tests and resource-API probes at `9ed47c6e8999ecaf56031e9b3f524bee6e01507a`; earlier dated unrun statements remain historical. Last broad-tested stays at that source, overall reviewed stays `210affe3ac2931473bead0de839be0de08309e3d`, and all pending windows, Taamey D corpus/baseline limits and immutable receipts remain. Only the isolated receipt branch is published; no main/shared/deploy or hbofonts work. [Receipt]({NAME}.md), [evidence]({archive.name}).\n"
status_path.write_text(status, encoding="utf-8", newline="\n")
paths = sorted(
    [
        "doc/" + NAME + ".md",
        "doc/" + NAME + "-evidence.zip",
        "doc/review-trial-status.md",
    ]
)
actual = set(
    filter(None, git("diff", "--name-only", "-z", tree=receipts).decode().split("\0"))
) | set(
    filter(
        None,
        git("ls-files", "--others", "--exclude-standard", "-z", tree=receipts)
        .decode()
        .split("\0"),
    )
)
assert actual == set(paths)
git("diff", "--check", tree=receipts)
(ROOT / "publication-prepared.json").write_bytes(
    dump(
        {
            "branch": BRANCH,
            "parent": PARENT,
            "source": SOURCE,
            "paths": paths,
            "archive": {
                "path": archive.name,
                "bytes": archive.stat().st_size,
                "sha256": sha(archive.read_bytes()),
                "payload_files": len(payload) - 1,
            },
            "prepared_utc": datetime.now(timezone.utc).isoformat(),
        }
    )
)
(ROOT / "stage.json").write_bytes(
    dump(
        {
            "state": "completed",
            "source": SOURCE,
            "result": "Focused review complete; no product repair; receipt prepared.",
        }
    )
)
print(
    json.dumps(
        {
            "branch": BRANCH,
            "parent": PARENT,
            "paths": paths,
            "archive_bytes": archive.stat().st_size,
            "archive_sha256": sha(archive.read_bytes()),
            "payload_files": len(payload) - 1,
        },
        indent=2,
    )
)

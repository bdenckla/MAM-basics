// Exercise the actual controls in a minimal DOM model; this is not browser evidence.
const fs = require("node:fs");
const vm = require("node:vm");
const assert = require("node:assert/strict");
const root = __dirname;
const pages = JSON.parse(fs.readFileSync(root + "/evidence/js-input.json", "utf8"));
const code = fs.readFileSync(root + "/head/gh-pages/stress-helpers/controls.js", "utf8");
const results = [];
for (const page of pages) {
    const events = new Map();
    const elements = {};
    for (const id of ["hebrew-size", "size-value", "size-reset", "toggle-images", "find", "outcome", "visible"]) {
        elements[id] = {
            value: id === "hebrew-size" ? "30" : "",
            defaultValue: id === "hebrew-size" ? "30" : "",
            textContent: "",
            attributes: { "aria-expanded": "false" },
            addEventListener(event, callback) { events.set(id + "/" + event, callback); },
            getAttribute(name) { return this.attributes[name]; },
            setAttribute(name, value) { this.attributes[name] = String(value); },
        };
    }
    const rows = page.rows.map(r => ({cells: r.cells.map(t => ({textContent: t})), dataset: {outcome: r.outcome}, hidden: false}));
    const scans = Array.from({length: rows.length + 1}, () => ({hidden: true}));
    const properties = {};
    const context = {document: {
        documentElement: {style: {setProperty(name, value) { properties[name] = value; }}},
        querySelector(selector) { assert(selector.startsWith("#")); return elements[selector.slice(1)]; },
        querySelectorAll(selector) {
            if (selector === "#observations .scan") return scans;
            if (selector === "#observations tbody tr") return rows;
            throw new Error(selector);
        },
    }};
    vm.runInNewContext(code, context, {filename: "controls.js"});
    assert.equal(properties["--hebrew-size"], "30px");
    assert.equal(elements.visible.textContent, rows.length + " differences");
    for (const size of ["20", "48", "35"]) {
        elements["hebrew-size"].value = size;
        events.get("hebrew-size/input")();
        assert.equal(properties["--hebrew-size"], size + "px");
        assert.equal(elements["size-value"].textContent, size + " px");
    }
    events.get("size-reset/click")();
    assert.equal(properties["--hebrew-size"], "30px");
    for (const show of [true, false, true, false]) {
        events.get("toggle-images/click")();
        assert(scans.every(cell => cell.hidden === !show));
        assert.equal(elements["toggle-images"].attributes["aria-expanded"], String(show));
        assert.equal(elements["toggle-images"].textContent, show ? "Hide images" : "Show images");
    }
    // Independent code-point loop implements the advertised point/accent-insensitive key.
    function key(value) {
        let out = "";
        for (const char of value.trim().toLocaleLowerCase("en")) {
            const n = char.codePointAt(0);
            if ((n >= 1425 && n <= 1469) || (n >= 1471 && n <= 1479)) continue;
            out += char;
        }
        return out;
    }
    const queries = ["", "unmatched-needle", "MAM", "mam", "  MAM  ", ...page.queries, ...page.queries.map(key)];
    const categories = ["", "UNKNOWN", ...new Set(page.rows.map(r => r.outcome))];
    let cases = 0;
    for (const query of queries) {
        for (const category of categories) {
            elements.find.value = query;
            elements.outcome.value = category;
            events.get("find/input")();
            const expected = page.rows.map(row => row.cells.some(c => key(c).includes(key(query))) && (!category || row.outcome === category));
            assert.deepEqual(rows.map(row => !row.hidden), expected);
            const count = expected.filter(Boolean).length;
            assert.equal(elements.visible.textContent, count + (count === 1 ? " difference" : " differences"));
            events.get("outcome/change")();
            assert.deepEqual(rows.map(row => !row.hidden), expected);
            cases++;
        }
    }
    results.push({edition: page.edition, rows: rows.length, query_category_combinations: cases, range_values: 3, image_toggles: 4, reset: true});
}
fs.writeFileSync(root + "/evidence/js-result.json", JSON.stringify({node: process.version, results, limit: "Minimal DOM model; no browser rendering, accessibility-tree, visual, network or font verification."}, null, 2) + "\n", "utf8");
console.log(JSON.stringify(results));

"""Sub-agent I: print the visible text of chosen sections of the built decision page (read-only).

Usage (-I, MAM-basics root): i_page_text.py <decisions.html> <section id> [<section id> ...]
A section runs from the <h2> with that id to the next <h2>. Tables are kept as rows of cells.
"""

import re
import sys
from html import unescape
from pathlib import Path


def text_of(fragment):
    s = re.sub(r"<style.*?</style>", "", fragment, flags=re.S)
    s = re.sub(r"</t[dh]>", " | ", s)
    s = re.sub(r"</(p|li|tr|h2|h3|pre|summary)>", "\n", s)
    s = re.sub(r"<[^>]+>", "", s)
    s = unescape(s)
    return re.sub(r"\n\s*\n+", "\n", s)


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    page = Path(sys.argv[1]).read_text(encoding="utf-8")
    for sid in sys.argv[2:]:
        m = re.search(r'<h2 id="%s">.*?(?=<h2 |\Z)' % re.escape(sid), page, re.S)
        print("=" * 20, sid)
        print(text_of(m.group(0)) if m else "NOT FOUND")


main()

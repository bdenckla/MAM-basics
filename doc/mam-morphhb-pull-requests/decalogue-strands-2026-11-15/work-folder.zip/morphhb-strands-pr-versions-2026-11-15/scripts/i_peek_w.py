"""Sub-agent I: print, as ascii(), the line holding a <w> id in the base and in the build.

Usage (-I, MAM-basics root): i_peek_w.py <book> <w id> [<w id> ...]
"""

import sys
from pathlib import Path

W = Path(__file__).resolve().parent.parent


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    book = sys.argv[1]
    for wid in sys.argv[2:]:
        for label, d in (
            ("base", W / "fetched/base-696e21ce"),
            ("build", W / "out/build-A"),
        ):
            for ln in (d / f"{book}.xml").read_text(encoding="utf-8").splitlines():
                if f'id="{wid}"' in ln:
                    print(label, wid, ascii(ln.strip()))


main()

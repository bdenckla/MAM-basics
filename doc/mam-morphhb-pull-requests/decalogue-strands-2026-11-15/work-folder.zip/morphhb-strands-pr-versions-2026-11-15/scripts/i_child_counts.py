"""Sub-agent I: the most children any of the 24 verses has, in the base and in the build.

Run with -I from the MAM-basics root (OET's converter needs fewer than 100 per verse).
"""

import sys
import xml.etree.ElementTree as ET
from pathlib import Path

W = Path(__file__).resolve().parent.parent
NS = "{http://www.bibletechnologies.net/2003/OSIS/namespace}"
VIDS = (
    ["Gen.35.22"]
    + [f"Exod.20.{v}" for v in (2, 3, 4, 5, 6, 8, 9, 10, 13, 14, 15)]
    + [f"Deut.5.{v}" for v in (6, 7, 8, 9, 10, 12, 13, 14, 15, 17, 18, 19)]
)
sys.stdout.reconfigure(encoding="utf-8")
for label, d in (("base", W / "fetched/base-696e21ce"), ("build", W / "out/build-A")):
    counts = {}
    for book in ("Gen", "Exod", "Deut"):
        for v in ET.parse(d / f"{book}.xml").getroot().iter(NS + "verse"):
            if v.get("osisID") in VIDS:
                counts[v.get("osisID")] = len(list(v))
    top = max(counts, key=counts.get)
    print(
        f"{label}: most children {counts[top]} ({top}); Deut.5.8 {counts['Deut.5.8']}"
    )

"""Sub-agent V: which morphhb books folder F holds, and whether they are master's wlc/ files.

Throwaway scratch for the morphhb strands pull request (prepared, not posted).  Written by Claude
(Opus 5.5, sub-agent V), 2026-11-15.  Reads fetched files only; imports no MAM-basics module.
Run from C:/Users/BenDe/GitRepos/MAM-basics in PowerShell 7:

    ./.venv/Scripts/python.exe -I .novc/morphhb-strands-pr-versions-2026-11-15/scripts/v_books.py

Writes only .novc/morphhb-strands-pr-versions-2026-11-15/out/52-books.json.

The chain of evidence:
1. folder D's fetched tree of d4265dfa (recursive, not truncated) gives each wlc/<Book>.xml's
   Git blob SHA-1;
2. folder F's fetched/morphhb-wlc-<Book>/<Book>.xml files, hashed as Git blobs, are compared
   with those SHA-1s;
3. this folder's fetched commit JSON of master (db6c5c9b) gives its parents and the files it
   changed against its first parent; a wlc/ file among them would break the chain;
4. this folder's fetched master-db6c5c9b Gen, Exod and Deut files, hashed alike, are compared
   with d4265dfa's SHA-1s directly.
"""

import hashlib
import json
import sys
from pathlib import Path

MB = Path("C:/Users/BenDe/GitRepos/MAM-basics")
W = MB / ".novc" / "morphhb-strands-pr-versions-2026-11-15"
F = MB / ".novc" / "morphhb-corrections-2026-11-13" / "fetched"
D_TREE = MB / ".novc" / "morphhb-decalogue-2026-11-13" / "fetched" / "morphhb-tree-d4265dfa" / "tree.json"
MASTER_COMMIT = W / "fetched" / "upstream-master-1" / "commit.json"
MASTER_SHA = "db6c5c9b46b8f39346f10915ddb1a70dcd429901"
D4265 = "d4265dfa93b78d82765a557e12d965528c17c1a9"
OUT = W / "out" / "52-books.json"


def git_blob_sha1(data):
    h = hashlib.sha1()
    h.update(b"blob %d\0" % len(data))
    h.update(data)
    return h.hexdigest()


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    tree = json.loads(D_TREE.read_text(encoding="utf-8"))
    if tree["sha"] != D4265 or tree["truncated"]:
        raise ValueError("folder D's tree is not d4265dfa's whole tree")
    wlc_blobs = {
        e["path"][len("wlc/") : -len(".xml")]: e["sha"]
        for e in tree["tree"]
        if e["type"] == "blob" and e["path"].startswith("wlc/") and e["path"].endswith(".xml")
        and "/" not in e["path"][len("wlc/") :]
    }
    commit = json.loads(MASTER_COMMIT.read_text(encoding="utf-8"))
    if commit["sha"] != MASTER_SHA:
        raise ValueError("this folder's master commit is not db6c5c9b")
    parents = [p["sha"] for p in commit["parents"]]
    changed = [f["filename"] for f in commit["files"]]
    wlc_changed = [x for x in changed if x.startswith("wlc/")]
    f_dirs = sorted(p.name for p in F.glob("morphhb-wlc-*") if p.is_dir())
    f_books = {}
    for name in f_dirs:
        book = name[len("morphhb-wlc-") :]
        path = F / name / (book + ".xml")
        if not path.exists():
            f_books[book] = {"file": None}
            continue
        sha = git_blob_sha1(path.read_bytes())
        f_books[book] = {
            "file": str(path),
            "git_blob_sha1": sha,
            "d4265dfa_blob": wlc_blobs.get(book),
            "equal": sha == wlc_blobs.get(book),
        }
    master_files = {}
    for path in sorted((W / "fetched" / "master-db6c5c9b").glob("*.xml")):
        sha = git_blob_sha1(path.read_bytes())
        master_files[path.stem] = {
            "git_blob_sha1": sha,
            "d4265dfa_blob": wlc_blobs.get(path.stem),
            "equal": sha == wlc_blobs.get(path.stem),
        }
    xml_books = sorted(b for b, rec in f_books.items() if rec.get("file"))
    out = {
        "d4265dfa_wlc_xml_files": sorted(wlc_blobs),
        "folder_F_dirs": f_dirs,
        "folder_F_books_with_xml": xml_books,
        "folder_F_books_equal_to_d4265dfa": sorted(b for b in xml_books if f_books[b]["equal"]),
        "folder_F_books_differing": sorted(b for b in xml_books if not f_books[b]["equal"]),
        "d4265dfa_books_missing_from_F": sorted(
            b for b in wlc_blobs if b not in f_books and b != "VerseMap"
        ),
        "master_parents": parents,
        "master_first_parent_is_d4265dfa": parents[:1] == [D4265],
        "master_files_changed_vs_first_parent": changed,
        "master_wlc_files_changed": wlc_changed,
        "master_fetched_files": master_files,
        "f_books": f_books,
    }
    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=1) + "\n", encoding="utf-8", newline="\n")
    brief = {k: v for k, v in out.items() if k != "f_books"}
    print(json.dumps(brief, ensure_ascii=True, indent=1))


if __name__ == "__main__":
    main()

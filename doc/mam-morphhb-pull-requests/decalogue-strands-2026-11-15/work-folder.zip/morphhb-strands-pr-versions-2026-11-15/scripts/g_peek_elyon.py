"""Sub-agent G: compare the n codes of CLC's and MAM's elyon chanted verse Exodus 20:8-11 at
Exodus 20:10 (where CLC's form has WLC 4.20's pashta code point for MAM's qadma).
Reads W/scratch-g/g_accgram.json only."""

import json
import sys

sys.dont_write_bytecode = True

import g_common as g  # noqa: E402


def codes(cv):
    ver = cv["verdict"]
    at = ver["accent_tokens"]
    if ver["grammar"] == "clean":
        c = g.tree_codes(ver["tree"], at)
    else:
        c, _ = g.level_codes([t for t, _l, _a in at])
    return g.atom_codes(at, c, len(cv["atoms"]))


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    acc = json.loads((g.W / "scratch-g" / "g_accgram.json").read_text(encoding="utf-8"))
    for label in ("Exod 20:8–11", "Deut 5:12–15"):
        pair = {cv["source"]: cv for cv in acc["chanted_verses"] if cv["strand"] == "bet" and cv["label"] == label}
        cc, mc = codes(pair["clc"]), codes(pair["mam"])
        print("==", label, pair["clc"]["verdict"]["grammar"])
        for j, (vid, n) in enumerate(pair["clc"]["atoms"]):
            if cc[j] != mc[j] or vid in ("Exod.20.10", "Deut.5.14"):
                print(f"   {vid}:{n:<3} clc={cc[j]} mam={mc[j]}")


main()

"""Sub-agent V: write out/52-sheva.md and out/52-sheva.html from this folder's out/52-*.json.

Throwaway scratch for the morphhb strands pull request (prepared, not posted).  Written by Claude
(Opus 5.5, sub-agent V), 2026-11-15.  Run from C:/Users/BenDe/GitRepos/MAM-basics in PowerShell 7,
after v_books.py, v_census.py, v_history.py, v_mam_het.py and v_versions.py:

    ./.venv/Scripts/python.exe -B .novc/morphhb-strands-pr-versions-2026-11-15/scripts/v_report.py

Every Hebrew form in the report is copied from those JSON files by this script.  Every count is
computed here from them, and each claim the prose makes about the data is asserted first.
"""

import sys

sys.dont_write_bytecode = True

import html  # noqa: E402
import json  # noqa: E402
import re  # noqa: E402
import unicodedata  # noqa: E402
from collections import Counter  # noqa: E402
from pathlib import Path  # noqa: E402

SCRIPTS = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPTS))

import v_census as V  # noqa: E402

W = V.W
OUT_MD = W / "out" / "52-sheva.md"
OUT_HTML = W / "out" / "52-sheva.html"
H = "\N{LATIN SMALL LETTER H WITH DOT BELOW}"
HATAF_PATAH_NAME = H + "ataf pata" + H
HET_NAME = H + "et"
MUNAH_NAME = "muna" + H
PATAH_NAME = "pata" + H
VAV = "\N{HEBREW LETTER VAV}"
DOT = "\N{HEBREW POINT DAGESH OR MAPIQ}"
NOTE1 = "]1"
# Two private-use code points that bracket a Hebrew form inside prose (they have no names).
HE_OPEN, HE_CLOSE = "\U0000E000", "\U0000E001"

BOOK_NAMES = {
    "Gen": "Genesis", "Exod": "Exodus", "Lev": "Leviticus", "Num": "Numbers",
    "Deut": "Deuteronomy", "Josh": "Joshua", "Judg": "Judges", "1Sam": "1 Samuel",
    "2Sam": "2 Samuel", "1Kgs": "1 Kings", "2Kgs": "2 Kings", "Isa": "Isaiah",
    "Jer": "Jeremiah", "Ezek": "Ezekiel", "Hos": "Hosea", "Joel": "Joel", "Amos": "Amos",
    "Obad": "Obadiah", "Jonah": "Jonah", "Mic": "Micah", "Nah": "Nahum", "Hab": "Habakkuk",
    "Zeph": "Zephaniah", "Hag": "Haggai", "Zech": "Zechariah", "Mal": "Malachi",
    "Ps": "Psalms", "Prov": "Proverbs", "Job": "Job", "Song": "Song of Songs", "Ruth": "Ruth",
    "Lam": "Lamentations", "Eccl": "Ecclesiastes", "Esth": "Esther", "Dan": "Daniel",
    "Ezra": "Ezra", "Neh": "Nehemiah", "1Chr": "1 Chronicles", "2Chr": "2 Chronicles",
}


def load(name):
    return json.loads((W / "out" / name).read_text(encoding="utf-8"))


def ref(vid):
    b, c, v = vid.split(".")
    return f"{BOOK_NAMES[b]} {c}:{v}"


def he(form):
    """A Hebrew form inside prose: raw in Markdown, a span in HTML."""
    return HE_OPEN + form + HE_CLOSE


def point_name(p, ketiv=False):
    if p == "none":
        return "no point (unpointed ketiv)" if ketiv else "no point"
    return {"sheva": "sheva", "hataf patah": HATAF_PATAH_NAME}[p]


def pointed(form):
    return any(unicodedata.category(ch) == "Mn" for ch in form)


def mark_diffs(a, b, a_name, b_name):
    """How form b's marks differ from form a's, letter by letter, by Unicode name."""
    ca, cb = V.clusters(a, a_name), V.clusters(b, b_name)
    if [x for x, _ in ca] != [x for x, _ in cb]:
        raise ValueError(f"letters differ: {a!r} {b!r}")
    out = []
    for k, ((lt, ma), (_lt, mb)) in enumerate(zip(ca, cb)):
        x, y = Counter(ma), Counter(mb)
        letter = unicodedata.name(lt).replace("HEBREW LETTER ", "").lower()
        for m in sorted((x - y).elements()):
            out.append(f"letter {k + 1} ({letter}): {a_name} has {unicodedata.name(m)}, {b_name} lacks it")
        for m in sorted((y - x).elements()):
            out.append(f"letter {k + 1} ({letter}): {b_name} has {unicodedata.name(m)}, {a_name} lacks it")
    return out


# ------------------------------------------------------------------ rendering


def md_inline(s):
    return s.replace(HE_OPEN, "").replace(HE_CLOSE, "")


def html_inline(s):
    out = html.escape(s, quote=False)
    out = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", out)
    out = re.sub(r"`(.+?)`", r"<code>\1</code>", out)

    def span(m):
        form = m.group(1)
        if pointed(form):
            return f'<span lang="hbo" dir="rtl">{form}</span>'
        return f"<bdi>{form}</bdi>"

    return re.sub(HE_OPEN + "(.*?)" + HE_CLOSE, span, out)


class Doc:
    def __init__(self):
        self.blocks = []

    def h1(self, s):
        self.blocks.append(("h1", s))

    def h2(self, s):
        self.blocks.append(("h2", s))

    def p(self, s):
        self.blocks.append(("p", s))

    def caveat(self, s):
        self.blocks.append(("caveat", s))

    def ol(self, items):
        self.blocks.append(("ol", items))

    def ul(self, items):
        self.blocks.append(("ul", items))

    def table(self, headers, rows):
        """rows: lists of cells; a cell is text or ("he", form)."""
        self.blocks.append(("table", headers, rows))

    def markdown(self):
        out = []
        for b in self.blocks:
            kind = b[0]
            if kind == "caveat":
                out.append(md_inline(b[1]))
            elif kind == "h1":
                out.append("# " + md_inline(b[1]))
            elif kind == "h2":
                out.append("## " + md_inline(b[1]))
            elif kind == "p":
                out.append(md_inline(b[1]))
            elif kind == "ol":
                out.append("\n".join(f"{n}. {md_inline(x)}" for n, x in enumerate(b[1], 1)))
            elif kind == "ul":
                out.append("\n".join(f"- {md_inline(x)}" for x in b[1]))
            elif kind == "table":
                headers, rows = b[1], b[2]
                lines = ["| " + " | ".join(md_inline(h) for h in headers) + " |"]
                lines.append("|" + "---|" * len(headers))
                for row in rows:
                    cells = [c[1] if isinstance(c, tuple) else md_inline(c) for c in row]
                    lines.append("| " + " | ".join(cells) + " |")
                out.append("\n".join(lines))
        return "\n\n".join(out) + "\n"

    def html(self, title):
        body = []
        for b in self.blocks:
            kind = b[0]
            if kind == "caveat":
                body.append(f'<p class="ai-caveat">{html_inline(b[1])}</p>')
            elif kind == "h1":
                body.append(f"<h1>{html_inline(b[1])}</h1>")
            elif kind == "h2":
                body.append(f"<h2>{html_inline(b[1])}</h2>")
            elif kind == "p":
                body.append(f"<p>{html_inline(b[1])}</p>")
            elif kind in ("ol", "ul"):
                items = "".join(f"<li>{html_inline(x)}</li>" for x in b[1])
                body.append(f"<{kind}>{items}</{kind}>")
            elif kind == "table":
                headers, rows = b[1], b[2]
                th = "".join(f"<th>{html_inline(h)}</th>" for h in headers)
                trs = []
                for row in rows:
                    tds = []
                    for c in row:
                        if isinstance(c, tuple):
                            form = c[1]
                            inner = f'<span lang="hbo">{form}</span>' if pointed(form) else f"<bdi>{form}</bdi>"
                            tds.append(f'<td dir="rtl">{inner}</td>')
                        else:
                            tds.append(f"<td>{html_inline(c)}</td>")
                    trs.append("<tr>" + "".join(tds) + "</tr>")
                body.append(f"<table><thead><tr>{th}</tr></thead><tbody>{''.join(trs)}</tbody></table>")
        css = """
@font-face { font-family: "Taamey D"; src: url("../../../gh-pages/woff2/Taamey_D.woff2") format("woff2"); }
body { font-family: system-ui, "Segoe UI", sans-serif; max-width: 72rem; margin: 1rem auto; padding: 0 16px; line-height: 1.5; background: #fff; color: #111; }
[lang="hbo"] { font-family: "Taamey D", "SBL Hebrew", "Ezra SIL", serif; font-size: 140%; }
table { border-collapse: collapse; margin: 1rem auto; }
th, td { border: 1px solid #bbb; padding: 0.15rem 0.5rem; vertical-align: middle; }
td[dir="rtl"] { text-align: right; }
p.ai-caveat { border: 2px solid #b35900; padding: 0.4rem 0.6rem; }
code { font-size: 90%; }
"""
        return (
            "<!doctype html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n"
            '<meta name="viewport" content="width=device-width, initial-scale=1">\n'
            f"<title>{html.escape(title)}</title>\n<style>{css}</style>\n</head>\n<body>\n"
            + "\n".join(body)
            + "\n</body>\n</html>\n"
        )


# ------------------------------------------------------------------ main


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    books = load("52-books.json")
    census = load("52-sheva-census.json")
    hist = load("52-history.json")
    mam_het = load("52-mam-het.json")
    versions = load("52-versions.json")
    s = census["summary"]
    rows = census["verb_rows"]

    # ---- checks behind the prose
    assert books["folder_F_books_differing"] == [] and len(books["folder_F_books_equal_to_d4265dfa"]) == 40
    assert books["master_first_parent_is_d4265dfa"] and books["master_wlc_files_changed"] == []
    assert all(r["equal"] for r in books["master_fetched_files"].values())
    n_rows = len(rows)
    ketiv = [r for r in rows if r["wlc_kq"] == "k"]
    by_point = Counter(r["wlc420_point"] for r in rows if r["wlc_kq"] != "k")
    assert all(r["wlc420_point"] == "none" for r in ketiv)
    assert all(not pointed(r["wlc420"]) for r in ketiv)
    sheva_rows = [r for r in rows if r["wlc420_point"] == "sheva"]
    assert [r["vid"] for r in sheva_rows] == ["Exod.20.5"] and sheva_rows[0]["qere_side_atom"] == 2
    ex = sheva_rows[0]
    # the pointed forms with no point under the het: the next letter is a vav with the dot and no vowel
    none_rows = [r for r in rows if r["wlc420_point"] == "none" and r["wlc_kq"] != "k"]
    for r in none_rows:
        cl = V.clusters(r["wlc420"], r["vid"])
        k = r["het_letter"] - 1
        nxt_letter, nxt_marks = cl[k + 1]
        assert nxt_letter == VAV and DOT in nxt_marks and V.point(nxt_marks) == "none", r["vid"]
    sample_none = none_rows[0]
    # morphhb and MAM against WLC 4.20, at the het
    assert all(r["morphhb"]["aligned"] == "equal letters" for r in rows)
    m_diff = [r for r in rows if r["morphhb"]["point"] != r["wlc420_point"]]
    assert [r["vid"] for r in m_diff] == ["Exod.20.5"]
    assert ex["morphhb"]["point"] == "hataf patah" and ex["morphhb"]["alt_point"] == "hataf patah"
    a_diff = [r for r in rows if r["morphhb"].get("alt") and r["morphhb"]["alt_point"] != r["wlc420_point"]]
    assert [r["vid"] for r in a_diff] == ["Exod.20.5"]
    mam_diff = [r for r in rows if r["mam"]["point"] != r["wlc420_point"]]
    assert [r["vid"] for r in mam_diff] == ["Exod.20.5"], [r["vid"] for r in mam_diff]
    assert ex["mam"]["strand_points"] == ["hataf patah"]
    mam_letters_differ = [r for r in rows if r["mam"]["aligned"] != "equal letters"]
    assert [r["vid"] for r in mam_letters_differ] == ["Neh.8.6"] and mam_letters_differ[0]["mam"]["aligned"] == "letters differ"
    dual = [r for r in rows if r["mam"]["strands_differ"]]
    assert sorted(r["vid"] for r in dual) == ["Deut.5.9", "Exod.20.5"]
    lemma_extra = s["lemma_7812_without_stem"]
    assert s["stem_without_lemma_7812"] == [] and s["verb_atoms_morphhb_stem_letters"] == n_rows
    # the corpus
    assert s["het_pairs_main_text_differing"] == {"sheva | hataf patah": 1}
    het_diffs = census["het_diffs"]
    assert [d["vid"] for d in het_diffs] == ["Exod.20.5"]
    blocks_pairs = s["unaligned_blocks_het_pairs"]
    assert all(k.split(" | ")[0] == k.split(" | ")[1] for k in blocks_pairs)
    n_blocks_hets = sum(blocks_pairs.values())
    assert n_blocks_hets == s["unaligned_blocks_wlc420_hets"]
    n_hets = s["het_points_compared_main_text"] + n_blocks_hets
    alt_pairs = s["het_pairs_alternative_notes"]
    alt_differ = {k: v for k, v in alt_pairs.items() if k.split(" | ")[0] != k.split(" | ")[1]}
    assert alt_differ == {"sheva | hataf patah": 1}
    # WLC 4.20 against MAM
    ms = mam_het["summary"]
    cases = mam_het["cases"]
    assert [c["vid"] for c in cases] == ["Exod.20.5", "Exod.27.15", "Ezek.35.15"]
    others = cases[1:]
    assert all(c["morphhb"]["point"] == "sheva" for c in others)
    vers = {v["vid"]: v for v in versions}
    for c in cases:
        v = vers[c["vid"]]
        assert all(v[x]["point"] == "sheva" for x in ("WLC 4.18", "WLC 4.22", "UXLC 2.6")), c["vid"]
    assert all(vers["Deut.5.9"][x]["point"] == "hataf patah" for x in ("WLC 4.18", "WLC 4.22", "UXLC 2.6"))
    # WLC's note 1 on the verb's atoms
    note1 = [r for r in rows if NOTE1 in r["wlc420_notes"]]
    note1_other = [r for r in note1 if r["vid"] != "Exod.20.5"]
    note1_desc = []
    for r in note1_other:
        assert r["morphhb"]["same_as_wlc420"], r["vid"]
        d = mark_diffs(r["wlc420"], r["mam"]["form"], "WLC 4.20", "MAM")
        k = r["het_letter"]  # 1-based letter of the het; the vav after it is letter k + 1
        expect = f"letter {k + 1} (vav): WLC 4.20 has {unicodedata.name(DOT)}, MAM lacks it"
        assert expect in d, (r["vid"], d)
        note1_desc.append((r, d))
    note1_only_dot = [r for r, d in note1_desc if len(d) == 1]
    assert any(NOTE1 in c["wlc420_notes"] for c in cases if c["vid"] == "Exod.27.15")
    # Exodus 20:5 against Deuteronomy 5:9
    deut = [r for r in rows if r["vid"] == "Deut.5.9"]
    assert len(deut) == 1
    deut = deut[0]
    wlc_ed = mark_diffs(ex["wlc420"], deut["wlc420"], "Exodus 20:5", "Deuteronomy 5:9")
    assert wlc_ed == [
        "letter 4 (het): Exodus 20:5 has HEBREW POINT SHEVA, Deuteronomy 5:9 lacks it",
        "letter 4 (het): Deuteronomy 5:9 has HEBREW POINT HATAF PATAH, Exodus 20:5 lacks it",
    ], wlc_ed
    assert ex["morphhb"]["form"] == deut["morphhb"]["form"] and ex["morphhb"]["alt"] == deut["morphhb"]["alt"]
    # the commit
    hx, hd = hist["books"]["Exod"], hist["books"]["Deut"]
    ex_w = [r for r in hx["changed"] if r["vid"] == "Exod.20.5" and r["w"] == 2][0]
    de_w = [r for r in hd["changed"] if r["vid"] == "Deut.5.9" and r["w"] == 2][0]
    assert ex_w["attrib_before"] == ex_w["attrib_after"] == {"lemma": "7812"}
    assert [tuple(x) for x in ex_w["mark_changes"]] == [
        (4, "het", "removed", "HEBREW POINT SHEVA", "vowel point"),
        (4, "het", "added", "HEBREW POINT HATAF PATAH", "vowel point"),
        (5, "vav", "removed", "HEBREW ACCENT MUNAH", "accent"),
    ]
    (ex_note,) = ex_w["notes_added"]
    assert ex_note["type"] == "alternate" and ex_note["rdg_type"] == "x-accent" and ex_w["catchWord_is_after"] == [True]
    assert [tuple(x) for x in ex_w["rdg_vs_before"][0]] == [
        (4, "het", "removed", "HEBREW POINT SHEVA", "vowel point"),
        (4, "het", "added", "HEBREW POINT HATAF PATAH", "vowel point"),
        (5, "vav", "removed", "HEBREW ACCENT MERKHA", "accent"),
    ]
    (de_note,) = de_w["notes_added"]
    assert ex_w["after"] == de_w["after"] and ex_note["rdg"] == de_note["rdg"]
    assert ex_w["after"] == ex["morphhb"]["raw"] and ex_note["rdg"] == ex["morphhb"]["alt"]
    assert de_w["before"] == deut["wlc420"]
    assert ex_w["before"] == ex["wlc420"]
    assert ex_w["notes_removed"] == [] and de_w["notes_removed"] == []
    vx = hx["w_with_vowel_point_change"]
    assert [(r["vid"], r["w"]) for r in vx] == [("Exod.20.4", 12), ("Exod.20.5", 2)]
    assert [tuple(x)[2:4] for x in vx[0]["changes"] if x[4] == "vowel point"] == [("removed", "HEBREW POINT PATAH")]
    assert hd["w_with_vowel_point_change"] == []
    assert hx["mark_change_counts"] == {
        "accent removed": 54, "other removed": 4, "vowel point removed": 2, "vowel point added": 1
    }, hx["mark_change_counts"]
    assert hd["mark_change_counts"] == {"accent removed": 61, "other removed": 4}, hd["mark_change_counts"]
    other_x = Counter(x[3] for r in hx["w_with_other_mark_change"] for x in r["changes"] if x[4] == "other")
    other_d = Counter(x[3] for r in hd["w_with_other_mark_change"] for x in r["changes"] if x[4] == "other")
    assert other_x == {"HEBREW POINT METEG": 1, "HEBREW POINT RAFE": 3} and other_d == {"HEBREW POINT RAFE": 4}
    assert hx["notes_added_by_type"] == {"alternate": 55} and hd["notes_added_by_type"] == {"alternate": 60}
    assert hx["w_attrib_changed"] == 0 and hd["w_attrib_changed"] == 1
    attrib_d = [r for r in hd["changed"] if r["attrib_before"] != r["attrib_after"]]
    assert [r["vid"] for r in attrib_d] == ["Deut.2.20"]
    assert all(v.startswith("Exod.20.") for v in hx["verses_with_changes"])
    assert all(v.startswith("Deut.5.") for v in hd["verses_with_changes"] if v != "Deut.2.20")
    assert hx["commit_before"]["sha"].startswith("57e5e441") and hd["commit_before"]["sha"].startswith("9c46c1e1")
    seg_counts = Counter()
    maqaf = {"removed": [], "added": []}
    seg_vids = []
    for book in (hx, hd):
        for sc in book["segs_changed"]:
            seg_vids.append(sc["vid"])
            before = Counter(tuple(x) for x in sc["before"])
            after = Counter(tuple(x) for x in sc["after"])
            for how, diff in (("removed", before - after), ("added", after - before)):
                for x in diff.elements():
                    seg_counts[(x[1], how)] += 1
                    if x[1] == "x-maqqef":
                        maqaf[how].append(sc["vid"])
    assert set(seg_counts) <= {("x-sof-pasuq", "added"), ("x-paseq", "removed"), ("x-maqqef", "removed"), ("x-maqqef", "added")}, seg_counts
    assert all(v.startswith(("Exod.20.", "Deut.5.")) for v in seg_vids)
    moved = [v for v in maqaf["removed"] if v in maqaf["added"]]
    removed_only = [v for v in maqaf["removed"] if v not in maqaf["added"]]
    assert len(set(moved)) == len(moved) and not [v for v in maqaf["added"] if v not in maqaf["removed"]]
    segs_verses = len(seg_vids)
    maqaf_parts = [f"a maqaf moved at {ref(v)}" for v in moved] + [f"one removed at {ref(v)}" for v in removed_only]
    segs_desc = (
        f"{seg_counts[('x-sof-pasuq', 'added')]} sof pasuqs added,"
        f" {seg_counts[('x-paseq', 'removed')]} paseqs removed, " + " and ".join(maqaf_parts)
    )
    for r in note1_other:
        assert any(n["n"] == "1" and n["text"] == ex["morphhb"]["notes"][0]["text"] for n in r["morphhb"]["notes"]), r["vid"]
    assert [n["n"] for n in ex["morphhb"]["notes"]] == ["1"]

    # ---- the document
    doc = Doc()
    doc.caveat(
        "Claude's work (sub-agent V, Opus 5.5, 2026-11-15), not reviewed by a human. Read-only research"
        " for the morphhb Decalogue pull request, which is prepared and not posted."
    )
    doc.h1(f"The sheva under the {HET_NAME} at Exodus 20:5")
    doc.p(
        f"The question: at Exodus 20:5, atom 2, WLC 4.20 has a sheva under the {HET_NAME} of the verb"
        f" (the hishtaphel of the root {HET_NAME}-vav-he), and morphhb's `wlc/` has a {HATAF_PATAH_NAME}"
        " in its main text and its note. The presumption, as this sub-agent's brief quotes Ben: an"
        f" accidental repair, since the sheva \"is not unprecedent[ed] in WLC (and presumably not fixed"
        " by morphhb in all those other cases)\"."
    )
    doc.h2("Conclusion")
    doc.p(
        "**Borne out, with one qualification: WLC 4.20's other such shevas are in other words, not in"
        f" this verb.** Exodus 20:5's is the only one of the verb's {n_rows} atoms in WLC 4.20 with a"
        f" sheva under the {HET_NAME}."
        f" Elsewhere WLC 4.20 has a sheva under a {HET_NAME} where MAM has a {HATAF_PATAH_NAME} at two"
        f" atoms, {ref(others[0]['vid'])} and {ref(others[1]['vid'])}, and morphhb keeps both shevas;"
        f" morphhb also keeps WLC 4.20's form at the {len(note1_other)} other atoms of the verb that WLC"
        f" 4.20 marks with its note 1. Across the corpus, Exodus 20:5 is the only {HET_NAME} whose point"
        " in morphhb differs from WLC 4.20's. The change came in `73784451` (David Troidl, 2010-07-13),"
        " the commit that divided that very atom's two accents between the main text and a new note,"
        " and whose message names only the accents. It is the only vowel point that commit added in"
        " Exodus or Deuteronomy; the commit kept WLC's note 1 on the atom; and the atom and its note came"
        " out the same, code point for code point, as Deuteronomy 5:9's, which the same commit divided."
        " All of this is consistent with an accidental repair made while the accents were divided."
        " Nothing in the commit or the files says that the change was meant, and nothing in them can"
        " show that it was not."
    )
    doc.h2("Findings")
    pct = lambda n: f"{n:,}"  # noqa: E731
    findings = [
        f"**Established: in WLC 4.20, Exodus 20:5's atom 2 is the only atom of the verb with a sheva"
        f" under the {HET_NAME}.** WLC 4.20 has {n_rows} atoms with the letters shin, tav, {HET_NAME},"
        f" vav ({n_rows - len(ketiv)} read forms and {len(ketiv)} unpointed ketivs). Under the"
        f" {HET_NAME} of the {n_rows - len(ketiv)},"
        f" {by_point['hataf patah']} have a {HATAF_PATAH_NAME}, {by_point['none']} have no point (a"
        f" shuruq follows it, as in {he(sample_none['wlc420'])} at {ref(sample_none['vid'])}),"
        f" and {by_point['sheva']} has a sheva: {he(ex['wlc420'])}. morphhb gives all {n_rows} its"
        f" lemma 7812, and gives that lemma to {len(lemma_extra)} other atoms only, outside this census"
        f" since they lack these letters ({' and '.join(ref(x.split(' ')[0]) for x in lemma_extra)},"
        f" whose morph codes are {' and '.join(x.split(' ')[-1] for x in lemma_extra)}).",
        f"**Established: morphhb has a {HATAF_PATAH_NAME} under this verb's {HET_NAME} where WLC 4.20"
        " has a sheva nowhere but Exodus 20:5, because WLC 4.20 has no other such sheva.** At the other"
        f" {n_rows - 1} atoms morphhb has WLC 4.20's point under the {HET_NAME}, and so does MAM (at"
        f" {ref(mam_letters_differ[0]['vid'])} MAM's atom has other letters, and its {HET_NAME} the same"
        f" {HATAF_PATAH_NAME}). At Exodus 20:5 morphhb's main text, {he(ex['morphhb']['form'])}, and its"
        f" note's reading, {he(ex['morphhb']['alt'])}, have a {HATAF_PATAH_NAME}, as MAM has in"
        f" `cant-combined`, {he(ex['mam']['form'])}, and in both its strands. Table 3 lists all"
        f" {n_rows} atoms.",
        f"**Established: across the corpus, Exodus 20:5 is the only {HET_NAME} whose point in morphhb"
        f" differs from WLC 4.20's.** Of {pct(n_hets)} {HET_NAME}s compared in morphhb's main text"
        f" ({pct(s['wlc420_sheva_het_total'])} with a sheva in WLC 4.20), one differs: Exodus 20:5's."
        f" Of the {s['het_points_compared_alternative_notes']} {HET_NAME}s in morphhb's alternative"
        " notes, one differs: the same atom's note.",
        f"**Established, an added check: WLC 4.20 has a sheva under a {HET_NAME} where MAM has a"
        f" {HATAF_PATAH_NAME} at two other atoms, and morphhb keeps the sheva at both** (table 1):"
        f" {ref(others[0]['vid'])}, {he(others[0]['wlc420'])}, which also carries WLC's note 1, and"
        f" {ref(others[1]['vid'])}, {he(others[1]['wlc420'])}. WLC 4.18, 4.22 and UXLC 2.6 have the"
        f" sheva at all three atoms, and the {HATAF_PATAH_NAME} at Deuteronomy 5:9. The comparison"
        f" covers the {pct(ms['het_points_compared'])} {HET_NAME}s in atoms whose letters WLC 4.20 and"
        " MAM share; atoms whose letters differ were not compared.",
        f"**Established: morphhb keeps WLC 4.20's form at the {len(note1_other)} other atoms of the verb"
        " that carry WLC's note 1.** morphhb gives that note's text as a note on each, as at Exodus 20:5:"
        " that BHS has been faithful to the Leningrad Codex where a form's validity might be questioned,"
        f" and that the form is kept as BHS has it. At each of the {len(note1_other)}, WLC 4.20 has"
        f" {unicodedata.name(DOT)} on the vav after the {HET_NAME}, which MAM's atom lacks"
        + (
            ", and that dot is the only mark by which it differs from MAM's atom"
            if len(note1_only_dot) == len(note1_other)
            else f" ({len(note1_only_dot)} differ from MAM's atom in that dot alone)"
        )
        + "; morphhb has WLC 4.20's form at all of them, in MAM-normal mark order (table 4).",
        f"**Confirmed: besides the {HATAF_PATAH_NAME}, `73784451` divided that atom's two accents**"
        f" (table 2). Before it, at `57e5e441` (2010-03-31, the previous commit to touch"
        f" `wlc/Exod.xml`), the atom was one w, lemma 7812, {he(ex_w['before'])}, with a merkha and a"
        f" {MUNAH_NAME} on its vav, followed by a plain note holding WLC's note 1's text. The commit took the"
        f" {MUNAH_NAME} out of the main text, keeping the merkha; added a note, typed `alternate` (later"
        " renamed `alternative`), whose catchWord is the new main text and whose `x-accent` reading has"
        f" the {MUNAH_NAME} instead of the merkha; wrote a {HATAF_PATAH_NAME} under the {HET_NAME} in the"
        " main text, the catchWord and the reading; and left the lemma and the note-1 text as they"
        f" were. In Exodus its other changes, all in Exodus 20, removed"
        f" {hx['mark_change_counts']['accent removed'] - 1} more accents, a meteg, three rafehs and one"
        f" vowel point: of the qamats and {PATAH_NAME} under the tav of Exodus 20:4's atom 12, the"
        f" {PATAH_NAME}, from both readings. In Deuteronomy, outside a lemma attribute it added at"
        f" Deuteronomy 2:20, it removed {hd['mark_change_counts']['accent removed']} accents and four"
        " rafehs in Deuteronomy 5 and changed no vowel point. In both books it also changed the segs of"
        f" {segs_verses} Decalogue verses ({segs_desc}). It added"
        f" {hx['notes_added_by_type']['alternate']} notes in Exodus and"
        f" {hd['notes_added_by_type']['alternate']} in Deuteronomy. The {HATAF_PATAH_NAME} is the only"
        " vowel point it added in either book. After it, Exodus 20:5's atom and note equal Deuteronomy"
        " 5:9's, code point for code point; before it, the two atoms differed only in the"
        f" {HET_NAME}'s point, as WLC 4.20's two atoms do. The atom has not changed since (folder D's"
        " `out/22-history-departures.txt`), so morphhb's note 1 at Exodus 20:5, which WLC 4.20 attaches"
        " to its atom with the sheva, has stood since 2010 on an atom that is not WLC 4.20's.",
    ]
    doc.ol(findings)

    doc.h2(f"Table 1. Where WLC 4.20 has a sheva under a {HET_NAME} and MAM a {HATAF_PATAH_NAME}")
    t1 = []
    for c in cases:
        v = vers[c["vid"]]
        t1.append(
            [
                f"{ref(c['vid'])}, atom {c['wlc_atom']}",
                ("he", c["wlc420"]),
                ("he", c["morphhb"]["form"]),
                ("he", c["mam"]),
                f"{point_name(c['morphhb']['point'])}"
                + (f"; note: {point_name(c['morphhb']['alt_point'])}" if c["morphhb"]["alt_point"] else ""),
                ", ".join(point_name(v[x]["point"]) for x in ("WLC 4.18", "WLC 4.22", "UXLC 2.6")),
                ", ".join(n.lstrip("]") for n in c["wlc420_notes"]) or "-",
            ]
        )
    doc.table(
        [
            "Verse, atom",
            "WLC 4.20",
            "morphhb",
            "MAM",
            f"morphhb's {HET_NAME}",
            f"WLC 4.18, 4.22, UXLC 2.6's {HET_NAME}",
            "WLC 4.20's notes",
        ],
        t1,
    )
    doc.p(
        f"WLC 4.20 and MAM have the sheva and the {HATAF_PATAH_NAME} respectively at each; morphhb's"
        " form at Exodus 20:5 is its main text."
    )

    doc.h2("Table 2. Exodus 20:5's atom 2 and Deuteronomy 5:9's, in morphhb's versions")
    t2 = [
        [
            "`57e5e441` (2010-03-31) and `9c46c1e1` (2010-07-02)",
            ("he", ex_w["before"]),
            "-",
            ("he", de_w["before"]),
            "-",
        ],
        [
            "`73784451` (2010-07-13)",
            ("he", ex_w["after"]),
            ("he", ex_note["rdg"]),
            ("he", de_w["after"]),
            ("he", de_note["rdg"]),
        ],
        [
            "`d4265dfa`, as master `db6c5c9b`",
            ("he", ex["morphhb"]["raw"]),
            ("he", ex["morphhb"]["alt"]),
            ("he", deut["morphhb"]["raw"]),
            ("he", deut["morphhb"]["alt"]),
        ],
        ["WLC 4.20", ("he", ex["wlc420"]), "-", ("he", deut["wlc420"]), "-"],
        ["MAM, `cant-alef` and `cant-bet`", ("he", ex["mam"]["cant-alef"]["form"]), ("he", ex["mam"]["cant-bet"]["form"]), ("he", deut["mam"]["cant-alef"]["form"]), ("he", deut["mam"]["cant-bet"]["form"])],
    ]
    doc.table(
        ["Version", "Exodus 20:5, main text", "its note's reading", "Deuteronomy 5:9, main text", "its note's reading"],
        t2,
    )
    doc.p(
        "The first row gives each book's last version before `73784451`. In MAM's row, the two"
        " columns of each verse are its `cant-alef` and `cant-bet` strands."
    )

    doc.h2(f"Table 3. Every atom of the verb in WLC 4.20, with morphhb's and MAM's")
    t3 = []
    for r in rows:
        k = r["wlc_kq"] == "k"
        label = f"{ref(r['vid'])}, atom {r['qere_side_atom']}" + (", ketiv" if k else "") + (", qere" if r["wlc_kq"] == "q" else "")
        t3.append(
            [
                label,
                ("he", r["wlc420"]),
                point_name(r["wlc420_point"], k),
                ("he", r["morphhb"]["form"]),
                point_name(r["morphhb"]["point"], k),
                ("he", r["mam"]["form"]),
                point_name(r["mam"]["point"], k),
            ]
        )
    doc.table(
        ["Verse, atom", "WLC 4.20", f"its {HET_NAME}", "morphhb", f"its {HET_NAME}", "MAM", f"its {HET_NAME}"],
        t3,
    )
    doc.ul(
        [
            "Atoms are numbered among the verse's read atoms, as WLC 4.20 has them; a ketiv takes the"
            " number of its qere.",
            "morphhb's form is its main text, with its `/` dividers dropped and a maqaf appended where a"
            " maqqef seg follows. At Exodus 20:5 and Deuteronomy 5:9 its note's reading is in table 2.",
            "MAM's form is MAM-simple's, in the BHS versification, on the side (ketiv or qere) of WLC"
            " 4.20's atom; at Exodus 20:5 and Deuteronomy 5:9 it is `cant-combined`, and `cant-alef` and"
            f" `cant-bet` have the same point under the {HET_NAME} (table 2). At"
            f" {ref(mam_letters_differ[0]['vid'])} MAM's"
            " atom has other letters than WLC 4.20's and is the only atom of the verb at that place.",
            "Forms are shown as each source has them. Comparisons of whole forms are in MAM-normal mark"
            " order (`give_std_mark_order`); comparisons of a point are of the marks on one letter.",
        ]
    )

    doc.h2(f"Table 4. The other atoms of the verb with WLC 4.20's note 1")
    t4 = []
    for r, d in note1_desc:
        t4.append(
            [
                f"{ref(r['vid'])}, atom {r['qere_side_atom']}" + (", qere" if r["wlc_kq"] == "q" else ""),
                ("he", r["wlc420"]),
                ("he", r["morphhb"]["form"]),
                ("he", r["mam"]["form"]),
                "; ".join(d),
            ]
        )
    doc.table(["Verse, atom", "WLC 4.20", "morphhb", "MAM", "How MAM's marks differ from WLC 4.20's"], t4)

    doc.h2("Method and files")
    doc.ul(
        [
            "Nothing was fetched: every morphhb file came from earlier folders. Folder F's"
            " `fetched/morphhb-wlc-<Book>/` holds all 39 books (and `VerseMap`) at `d4265dfa`, each"
            " equal as a Git blob to `d4265dfa`'s tree entry (folder D's `fetched/morphhb-tree-d4265dfa/`);"
            " master `db6c5c9b`'s first parent is `d4265dfa` and it changes no `wlc/` file; this folder's"
            " fetched master Gen, Exod and Deut equal those blobs (`out/52-books.json`, `scripts/v_books.py`).",
            f"WLC 4.20: MAM-basics' `out/wlc420-u`; WLC 4.22: `out/wlc422-u`; WLC 4.18: Sefaria-Data's"
            " copy of tanach.us, and UXLC 2.6: `in/UXLC-39`, read by folder D's `scripts/mhb_common.py`."
            " MAM: MAM-simple, read by `py/tests/test_israel_bible_review_mam_forms.py`'s own functions.",
            f"An atom's {HET_NAME}s are its {HET_NAME} letters; the point under one is its vowel point,"
            " or none. The verb's atoms are WLC 4.20's atoms with the letters shin, tav,"
            f" {HET_NAME}, vav; its {HET_NAME} is the third. In each verse WLC 4.20's atoms are aligned"
            " with morphhb's and MAM's by their letters (`scripts/v_census.py`); the"
            f" {s['unaligned_blocks']} places where morphhb divides an atom differently, or a ketiv's"
            f" letters differ, hold {n_blocks_hets} {HET_NAME}s, compared as a whole with the same result.",
            "History: folder F's `fetched/hist-Exod-*` and `hist-Deut-*`, compared w by w"
            " (`scripts/v_history.py`, `out/52-history.json`); a commit's date is its committer date"
            " in UTC.",
            "Outputs: `out/52-books.json`, `out/52-sheva-census.json`, `out/52-history.json`,"
            " `out/52-mam-het.json`, `out/52-versions.json`; this report (`scripts/v_report.py`) as"
            " `out/52-sheva.md` and, with its Hebrew in Taamey D, `out/52-sheva.html`.",
            "Readings are attributed to WLC 4.20, 4.18 or 4.22, UXLC 2.6, morphhb or MAM; this report"
            " makes no claim about the Leningrad Codex, which it names only where WLC's note 1 does.",
        ]
    )

    OUT_MD.write_text(doc.markdown(), encoding="utf-8", newline="\n")
    OUT_HTML.write_text(doc.html("Sheva at Exodus 20:5"), encoding="utf-8", newline="\n")
    print("wrote", OUT_MD)
    print("wrote", OUT_HTML)


if __name__ == "__main__":
    main()

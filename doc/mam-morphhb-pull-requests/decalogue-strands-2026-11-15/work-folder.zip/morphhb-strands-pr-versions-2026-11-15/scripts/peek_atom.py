"""Print every field of the named atoms of folder S's out/22-clc-answers.json.

Usage: peek_atom.py Exod.20.3:1 Exod.20.3:2 ...
"""

import json
import sys
from pathlib import Path

S = Path("C:/Users/BenDe/GitRepos/MAM-basics/.novc/morphhb-strands-pr-2026-11-14")


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    data = json.loads((S / "out/22-clc-answers.json").read_text(encoding="utf-8"))
    want = set(sys.argv[1:])
    for a in data["atoms"]:
        key = f"{a['vid']}:{a['atom']}"
        if key in want:
            print("=" * 60, key)
            for k, v in a.items():
                print(f"{k}: {ascii(v)}")


main()

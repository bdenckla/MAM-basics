"""Sub-agent T: debug the atomization of a MAM verse line.

Usage: t_debug_atoms.py <book-file-stem> <chapter-number> <line-index>
"""

import json
import re
import sys
from pathlib import Path

REPO = Path("C:/Users/BenDe/GitRepos/MAM-basics")
sys.path.insert(0, str(REPO / "py"))  # untracked scratch script only

import t_wikitext as wt  # noqa: E402
from mb_cmn import template_names as tmpln  # noqa: E402

W = REPO / ".novc/morphhb-strands-pr-versions-2026-11-15"
OUT = W / "scratch-t/debug_atoms.txt"

T_NUSACH = "\N{HEBREW LETTER NUN}\N{HEBREW LETTER VAV}\N{HEBREW LETTER SAMEKH}\N{HEBREW LETTER HET}"
K_KAFUL = "\N{HEBREW LETTER KAF}\N{HEBREW LETTER PE}\N{HEBREW LETTER VAV}\N{HEBREW LETTER LAMED}"
KEEP = {tmpln.DUAL_CANTILLATION: K_KAFUL, T_NUSACH: "1", tmpln.QAMATS_VARIANT: "\N{HEBREW LETTER DALET}"}
CHAP = {5: "\N{HEBREW LETTER HE}", 20: "\N{HEBREW LETTER KAF}"}


def main():
    stem, chap, li = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
    data = json.loads((REPO / f"in/mam-ws/{stem}.json").read_text(encoding="utf-8"))
    line = data[CHAP[chap]][li]
    out = []
    for a, b in wt.template_spans(line):
        name, params = wt.parse_template(line[a:b])
        out.append(f"  {name!r} keys={list(params)}")
    ex = wt.expand(line, KEEP)
    out.append("expanded: " + ex)
    t = re.sub(r"<[^<>]*>", " ", ex).replace("\N{HEBREW PUNCTUATION MAQAF}", " ")
    out.append("atoms: " + " / ".join(wt.letters_only(x) for x in t.split()))
    with OUT.open("w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(out) + "\n")


main()

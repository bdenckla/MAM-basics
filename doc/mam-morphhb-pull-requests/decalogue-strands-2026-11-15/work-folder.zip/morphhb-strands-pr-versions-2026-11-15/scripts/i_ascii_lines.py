"""Sub-agent I: print, as ascii(), each line of the named files that holds a non-ASCII character.

Usage (-I, MAM-basics root): i_ascii_lines.py <file> [<file> ...]
"""

import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")
for name in sys.argv[1:]:
    for i, ln in enumerate(Path(name).read_text(encoding="utf-8").splitlines(), 1):
        if any(ord(c) > 127 for c in ln):
            print(f"{Path(name).name}:{i}: {ascii(ln)[:200]}")

"""Sub-agent T: list the headings of the mirrored MAM introduction chapters, and
the line numbers of lines that mention given search terms (read-only)."""

import sys
from pathlib import Path

INTRO = Path("C:/Users/BenDe/GitRepos/MAM-basics/in/mam-ws-intro")
OUT = Path(
    "C:/Users/BenDe/GitRepos/MAM-basics/.novc/morphhb-strands-pr-versions-2026-11-15/scratch-t/intro_headings.txt"
)
FILES = ["ch1", "ch2", "ch3", "ch4", "ch5", "summary", "appendices"]
TERMS = [
    "\N{HEBREW LETTER AYIN}\N{HEBREW LETTER SHIN}\N{HEBREW LETTER RESH}\N{HEBREW LETTER TAV} \N{HEBREW LETTER HE}\N{HEBREW LETTER DALET}\N{HEBREW LETTER BET}\N{HEBREW LETTER RESH}\N{HEBREW LETTER VAV}\N{HEBREW LETTER TAV}",
    "\N{HEBREW LETTER RESH}\N{HEBREW LETTER ALEF}\N{HEBREW LETTER VAV}\N{HEBREW LETTER BET}\N{HEBREW LETTER FINAL NUN}",
    "\N{HEBREW LETTER TAV}\N{HEBREW LETTER AYIN}\N{HEBREW LETTER SHIN}\N{HEBREW LETTER HE}",
]


def main():
    sys.stderr.reconfigure(encoding="utf-8", errors="backslashreplace")
    out_lines = []
    for name in FILES:
        text = (INTRO / f"{name}.mediawiki").read_text(encoding="utf-8")
        lines = text.split("\n")
        out_lines.append(f"##### {name}: {len(lines)} lines")
        for i, line in enumerate(lines, start=1):
            if line.startswith("="):
                out_lines.append(f"{name}:{i}: {line[:200]}")
        for t in TERMS:
            hits = [i for i, line in enumerate(lines, start=1) if t in line]
            out_lines.append(f"{name}: term {t}: lines {hits}")
    with OUT.open("w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(out_lines) + "\n")
    print(f"wrote {OUT}", file=sys.stderr)


main()

"""Sub-agent I (2026-11-15): accgram on the final strands, rebuilt from the built XML alone.

Throwaway scratch for the morphhb strands pull request (prepared, not posted), written by Claude.
Run with -B from the MAM-basics root (imports sub-agent G's g_common, hence accgram):

    ./.venv/Scripts/python.exe -B .novc/morphhb-strands-pr-versions-2026-11-15/scripts/i_final_accgram.py

Reads out/build-A/{Gen,Exod,Deut}.xml only for the strands; MAM's strands (folder S's JSON and
MAM-simple, through g_common) only for the comparison of section 3. Writes
out/55-final-accgram.md and out/55-final-accgram.json.

Each span of the 24 verses is read from the XML as check_build.py reads it: a note before the
main text's punctuation seg has the main text's punctuation, a note after it (or where the main
text has none) its own. A strand's final version of a span:
  main strand (the tahton; Genesis 35:22's midrashit): its MAM-informed note's reading where
      that note exists, else the main text;
  other strand (the elyon; the peshutah): its MAM-informed note's reading where that exists,
      else its x-elyon (x-peshutah) note's reading, else the main text.
Exodus 20:11 and 20:16 and Deuteronomy 5:20, into which a strand's chanted verse runs on, are
read from the built XML too; they have no alternative notes, so both strands take the main text.
The strands' chanted verses (each ending at a span with sof pasuq) get g_common.verdict, G's
entry point to accgram's lexical layer, scanner and grammar. Every one must be clean.
"""

import json
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True

import g_common as g  # noqa: E402

NS = "{http://www.bibletechnologies.net/2003/OSIS/namespace}"
SEG_PUNCT = {"x-maqqef": "maqaf", "x-paseq": "paseq", "x-sof-pasuq": "sof pasuq"}
PUNCT_CHAR = {"maqaf": g.MAQAF, "paseq": g.PASEQ, "sof pasuq": g.SOF}
LABELS = {
    False: {
        "x-elyon": "other",
        "x-taxton-mam-informed": "mam_main",
        "x-elyon-mam-informed": "mam_other",
    },
    True: {
        "x-peshutah": "other",
        "x-midrashit-mam-informed": "mam_main",
        "x-peshutah-mam-informed": "mam_other",
    },
}


def local(el):
    return el.tag.replace(NS, "")


def split_text(text):
    for name, ch in PUNCT_CHAR.items():
        if text.endswith(ch):
            return text[: -len(ch)], name
    return text, ""


def form_of(core, punct):
    """A span as the JSON's forms write it: maqaf and sof pasuq joined, a paseq after a space."""
    core = core.replace("/", "")
    if punct == "paseq":
        return core + " " + g.PASEQ
    return core + (PUNCT_CHAR[punct] if punct else "")


def spans_of(verse, vid):
    """[{"id", "main": (core, punct), "n", "alts": {kind: (core, punct)}}] of one verse."""
    kids = list(verse)
    out = []
    i = 0
    gen = vid.startswith("Gen.")
    while i < len(kids):
        el = kids[i]
        if local(el) != "w":
            i += 1
            continue
        w = el
        j = i + 1
        if el.get("type") == "x-ketiv":
            w = list(kids[j].iter(NS + "w"))[0]
            j += 1
        punct, seen_seg, alts = "", False, {}
        while j < len(kids) and local(kids[j]) in ("seg", "note"):
            k = kids[j]
            if local(k) == "seg" and k.get("type") in SEG_PUNCT:
                punct, seen_seg = SEG_PUNCT[k.get("type")], True
            elif local(k) == "note" and k.get("type") == "alternative":
                kind = LABELS[gen][k.get("subType")]
                rd = k.find(NS + "rdg").text or ""
                alts[kind] = (split_text(rd), seen_seg)
            elif local(k) == "seg" or local(k) == "note":
                break
            j += 1
        main = ((w.text or "").replace("/", ""), punct)
        versions = {}
        for kind, ((rcore, rp), after_seg) in alts.items():
            versions[kind] = (
                rcore.replace("/", ""),
                rp if (after_seg or not punct) else punct,
            )
        out.append({"id": w.get("id"), "main": main, "n": w.get("n"), "alts": versions})
        i = j
    return out


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    vids = list(g.VIDS24) + list(g.EXTRA_VIDS)
    verses = {}
    for book in ("Gen", "Exod", "Deut"):
        for v in (
            ET.parse(g.W / "out/build-A" / f"{book}.xml").getroot().iter(NS + "verse")
        ):
            if v.get("osisID") in vids:
                verses[v.get("osisID")] = v
    atoms_by_vid = {}
    for vid in vids:
        recs = []
        gen = vid.startswith("Gen.")
        ms = "bet" if gen else "alef"
        os_ = "alef" if gen else "bet"
        for k, sp in enumerate(spans_of(verses[vid], vid), start=1):
            if vid in g.EXTRA_VIDS and sp["alts"]:
                raise ValueError(f"{vid}: alternative notes in a continuation verse")
            a = sp["alts"]
            mainf = a.get("mam_main", sp["main"])
            otherf = a.get("mam_other", a.get("other", sp["main"]))
            recs.append(
                {
                    "vid": vid,
                    "atom": k,
                    "w_id": sp["id"],
                    "n": sp["n"],
                    "in24": vid not in g.EXTRA_VIDS,
                    "src": {ms: "mam_main" in a, os_: "mam_other" in a or "other" in a},
                    "taken": {
                        ms: "MAM-informed" if "mam_main" in a else "main text",
                        os_: (
                            "MAM-informed"
                            if "mam_other" in a
                            else ("CLC's note" if "other" in a else "main text")
                        ),
                    },
                    ms: {"final": form_of(*mainf)},
                    os_: {"final": form_of(*otherf)},
                }
            )
        atoms_by_vid[vid] = recs

    # MAM's strands, for the token comparison (section 3)
    mam_atoms = g.load_atoms() + g.extra_atoms(g.mam_simple_verses())
    mam_by = {(a["vid"], a["atom"]): a for a in mam_atoms}
    for vid in vids:
        if len(atoms_by_vid[vid]) != sum(1 for a in mam_atoms if a["vid"] == vid):
            raise ValueError(f"{vid}: the build and MAM differ in atoms")
        for r in atoms_by_vid[vid]:
            for s in g.STRANDS:
                r[s]["mam"] = mam_by[(vid, r["atom"])][s]["mam"]
                if g.letters(r[s]["mam"]) != g.letters(r[s]["final"]):
                    raise ValueError(f"{vid}:{r['atom']}: letters differ")

    cvs = []
    for book in ("Gen", "Exod", "Deut"):
        for s in g.STRANDS:
            for src in ("final", "mam"):
                for cv in g.chanted_verses(atoms_by_vid, book, s, src):
                    if not any(a["in24"] for a in cv):
                        continue
                    _, ch, v = g.vid_parts(cv[0]["vid"])
                    forms = [a[s][src] for a in cv]
                    ver = g.verdict(forms, g.BB[book], ch, v)
                    cvs.append(
                        {
                            "book": book,
                            "strand": s,
                            "strand_name": g.STRAND_NAME[(book, s)],
                            "source": src,
                            "label": g.cv_label(cv),
                            "atoms": [[a["vid"], a["atom"]] for a in cv],
                            "forms": forms,
                            "status": ver["status"],
                            "grammar": ver["grammar"],
                            "lexical": [x["code"] for x in ver["lexical"]],
                            "accent_tokens": ver["accent_tokens"],
                            "tree": ver["tree"],
                        }
                    )
    final = [c for c in cvs if c["source"] == "final"]
    # keyed by first atom: Genesis 35:22's peshutah has two chanted verses with one label
    mam = {(c["strand"], tuple(c["atoms"][0])): c for c in cvs if c["source"] == "mam"}
    not_clean = [c for c in final if c["status"] != "clean" or c["grammar"] != "clean"]

    # n: the final main strand's tree codes against the built n
    n_rows, n_bad = [], []
    for c in final:
        ms = "bet" if c["book"] == "Gen" else "alef"
        if c["strand"] != ms or c["grammar"] != "clean":
            continue
        codes = g.atom_codes(
            c["accent_tokens"],
            g.tree_codes(c["tree"], c["accent_tokens"]),
            len(c["atoms"]),
        )
        for (vid, k), cs in zip(c["atoms"], codes):
            r = atoms_by_vid[vid][k - 1]
            code = "+".join(cs) if cs else None
            if r["in24"]:
                n_rows.append((vid, k, r["w_id"], r["n"], code))
                if code != r["n"]:
                    n_bad.append((vid, k, r["w_id"], r["n"], code))

    # tokens: final strands against MAM's, atom by atom
    tok_diff = []
    for c in final:
        m = mam[(c["strand"], tuple(c["atoms"][0]))]
        if m["atoms"] != c["atoms"]:
            raise ValueError(f"{c['label']}: MAM's chanted verse has other atoms")
        for j, (vid, k) in enumerate(c["atoms"]):
            ft = [t for t, _l, ai in c["accent_tokens"] if ai == j]
            mt = [t for t, _l, ai in m["accent_tokens"] if ai == j]
            if ft != mt:
                r = atoms_by_vid[vid][k - 1]
                tok_diff.append(
                    {
                        "vid": vid,
                        "atom": k,
                        "strand": c["strand"],
                        "strand_name": c["strand_name"],
                        "final": r[c["strand"]]["final"],
                        "mam": r[c["strand"]]["mam"],
                        "final_tokens": ft,
                        "mam_tokens": mt,
                        "taken": r["taken"][c["strand"]],
                    }
                )

    taken = {}
    for vid in g.VIDS24:
        for r in atoms_by_vid[vid]:
            for s in g.STRANDS:
                taken[(s, r["taken"][s])] = taken.get((s, r["taken"][s]), 0) + 1

    out = {
        "chanted_verses": [{k: v for k, v in c.items() if k != "tree"} for c in final],
        "not_clean": [c["label"] for c in not_clean],
        "n_rows": n_rows,
        "n_disagreements": n_bad,
        "token_differences_from_mam": tok_diff,
        "taken": {f"{s}: {t}": n for (s, t), n in sorted(taken.items())},
    }
    (g.W / "out/55-final-accgram.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8", newline="\n"
    )

    # ---- report
    BOOK = {"Gen": "Genesis", "Exod": "Exodus", "Deut": "Deuteronomy"}

    def vname(vid):
        b, ch, v = vid.split(".")
        return f"{BOOK[b]} {ch}:{v}"

    def cvname(label, atoms=None):
        b, rest = label.split(" ", 1)
        name = f"{BOOK[b]} {rest}"
        if atoms:
            (v1, a1), (v2, a2) = atoms[0], atoms[-1]
            if a1 != 1 or a2 != len(atoms_by_vid[v2]):
                name += f" (atoms {a1}–{a2})"
        return name

    L = [
        "Claude's work (Opus 5.5, sub-agent I, 2026-11-15, New York time), not reviewed by a human; nothing was posted, pushed or committed.",
        "",
        "# accgram on the final strands, rebuilt from the built XML",
        "",
        "Every strand name and Hebrew form below is copied by `scripts/i_final_accgram.py` from the built files `out/build-A/` or from MAM's strands. "
        "The strands are rebuilt from the built XML alone: the main strand (the "
        + g.STRAND_NAME[("Exod", "alef")]
        + ", at Genesis 35:22 the "
        + g.STRAND_NAME[("Gen", "bet")]
        + ") takes its MAM-informed note's reading where that note exists, else the main text; the other strand (the "
        + g.STRAND_NAME[("Exod", "bet")]
        + ", at Genesis 35:22 the "
        + g.STRAND_NAME[("Gen", "alef")]
        + ") its MAM-informed note's reading, else its CLC note's (`x-elyon`, `x-peshutah`), else the main text. "
        "A note before the main text's punctuation seg has the main text's punctuation, one after it its own. "
        "Exodus 20:11 and 20:16 and Deuteronomy 5:20, into which a strand's chanted verse runs on, come from the built files too and have no notes. "
        "Each chanted verse gets sub-agent G's `g_common.verdict`: accgram's prose lexical layer, then its scanner and grammar.",
        "",
        "## Answers in brief",
        "",
        f"1. **All {len(final)} chanted verses of the final strands are grammatical** ({len(final) - len(not_clean)} clean by both the lexical layer and the grammar; not clean: {', '.join(cvname(x) for x in out['not_clean']) or 'none'}).",
        f"2. **n.** The final main strand's division trees give the built `n` at {len(n_rows) - len(n_bad)} of the {len(n_rows)} main-text atoms of the 24 verses{'' if not n_bad else '; the others are listed in section 2'}.",
        f"3. **Accent tokens.** The final strands' tokens differ from MAM's strands' at {len(tok_diff)} strand-atoms (section 3).",
        "",
        "## 1. The chanted verses",
        "",
        '<div align="center">',
        "",
        "| Chanted verse | Strand | Atoms | Status | Grammar alone | Lexical findings |",
        "| :-- | :-- | --: | :-- | :-- | :-- |",
    ]
    for c in final:
        L.append(
            f"| {cvname(c['label'], c['atoms'])} | {c['strand_name']} | {len(c['atoms'])} | {c['status']} | {c['grammar']} | {', '.join(c['lexical']) or 'none'} |"
        )
    L += [
        "",
        "</div>",
        "",
        "What each strand took, over the 242 atoms of the 24 verses:",
        "",
    ]
    for (s, t), n in sorted(taken.items()):
        name = (
            g.STRAND_NAME[("Exod", s)]
            + " (at Genesis 35:22 the "
            + g.STRAND_NAME[("Gen", s)]
            + ")"
        )
        L.append(f"- the {name}: {t}, {n} atoms")
    L += ["", "## 2. n against the final main strand's trees", ""]
    if n_bad:
        L += [
            "| Verse, atom | `<w>` | built n | tree code |",
            "| :-- | :-- | :-- | :-- |",
        ]
        for vid, k, wid, n, code in n_bad:
            L.append(f"| {vname(vid)}, {k} | `{wid}` | {n} | {code} |")
    else:
        L.append(
            f"At every one of the {len(n_rows)} main-text atoms of the 24 verses the code that `g_common.tree_codes` reads off the final main strand's tree equals the built `n` (none where it is absent)."
        )
    L += ["", "## 3. Where the final strands' accent tokens differ from MAM's", ""]
    if tok_diff:
        L += [
            '<div align="center">',
            "",
            "| Verse, atom | Strand | Final form | MAM's form | Final tokens | MAM's tokens | Taken from |",
            "| :-- | :-- | --: | --: | :-- | :-- | :-- |",
        ]
        for d in tok_diff:
            L.append(
                f"| {vname(d['vid'])}, {d['atom']} | {d['strand_name']} | {d['final']} | {d['mam']} | {' '.join(d['final_tokens']) or 'none'} | {' '.join(d['mam_tokens']) or 'none'} | {d['taken']} |"
            )
        L += ["", "</div>"]
    else:
        L.append("Nowhere: at every atom the final strands' tokens equal MAM's.")
    L += [
        "",
        "## Limits",
        "",
        "accgram's grammar is goerwitz's model of the prose system, as sub-agent G's report (`out/53-accgram.md`, section 6) says; its verdicts are claims about these encodings under that model. "
        "The scanner swallows a medial meteg and fuses a stress helper with its accent, so a token comparison cannot see a meteg or a helper.",
        "",
        "## Files",
        "",
        "`scripts/i_final_accgram.py` writes this file and `out/55-final-accgram.json` (every chanted verse's forms, tokens and verdict; the n rows; the token differences).",
    ]
    (g.W / "out/55-final-accgram.md").write_text(
        "\n".join(L) + "\n", encoding="utf-8", newline="\n"
    )
    print(f"final chanted verses: {len(final)}; not clean: {out['not_clean']}")
    print(
        f"n: {len(n_rows) - len(n_bad)} of {len(n_rows)} agree; disagreements: {n_bad}"
    )
    print(f"token differences from MAM: {len(tok_diff)}")
    for d in tok_diff:
        print(
            "  ",
            d["vid"],
            d["atom"],
            d["strand"],
            d["final_tokens"],
            d["mam_tokens"],
            d["taken"],
        )
    print("taken:", out["taken"])


main()

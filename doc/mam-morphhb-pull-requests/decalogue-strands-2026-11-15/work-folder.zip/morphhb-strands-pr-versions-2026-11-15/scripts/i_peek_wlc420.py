"""Sub-agent I: peek at out/wlc420-u's verse records (read-only): book codes, ketiv/qere shapes.

Run with -I from the MAM-basics root.
"""

import json
import sys
from pathlib import Path

MB = Path("C:/Users/BenDe/GitRepos/MAM-basics")


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    codes = []
    shapes = {}
    for path in sorted((MB / "out/wlc420-u").glob("1verses_*.json")):
        for verse in json.loads(path.read_text(encoding="utf-8")):
            b = "".join(
                c
                for c in verse["bcv"].split(":")[0]
                if not c.isdigit() or verse["bcv"][0].isdigit()
            )
            book = verse["bcv"].rstrip("0123456789:").rstrip("0123456789")
            if not codes or codes[-1] != book:
                codes.append(book)
            for vel in verse["vels"]:
                if isinstance(vel, str):
                    k = "str*" if vel.startswith("*") else "str"
                else:
                    k = "dict:" + ",".join(sorted(vel))
                    if "word" in vel and vel["word"].startswith("*"):
                        k += "*"
                shapes.setdefault(k, verse["bcv"])
            if verse["bcv"] == "dt5:10":
                print("dt5:10", [ascii(v)[:80] for v in verse["vels"]][-4:])
    print("book codes:", codes)
    print("shapes:", shapes)


main()

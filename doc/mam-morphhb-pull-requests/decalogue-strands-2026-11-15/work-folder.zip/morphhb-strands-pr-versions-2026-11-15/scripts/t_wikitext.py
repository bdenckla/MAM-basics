"""Sub-agent T: a small, closed wikitext helper for reading MAM's notes.

Only what the extraction needs: find templates with nesting, split a
template's inner text at top-level pipes, and name its parameters.
"""

import re

KEY_RE = re.compile(r"^([^=\{\}\[\]|]+)=(.*)$", re.DOTALL)


def template_spans(s):
    """Return (start, end) spans of the top-level {{...}} templates in s."""
    spans = []
    depth = 0
    open_pos = None
    k = 0
    n = len(s)
    while k < n:
        if s.startswith("{{", k):
            if depth == 0:
                open_pos = k
            depth += 1
            k += 2
        elif s.startswith("}}", k) and depth > 0:
            depth -= 1
            k += 2
            if depth == 0:
                spans.append((open_pos, k))
        else:
            k += 1
    if depth != 0:
        raise ValueError(f"unbalanced braces in {s[:80]!r}")
    return spans


def split_top(s, sep="|"):
    """Split s at sep where sep is outside every {{...}} and [[...]]."""
    parts = []
    cur = []
    dt = 0
    dl = 0
    k = 0
    n = len(s)
    while k < n:
        if s.startswith(sep, k) and dt == 0 and dl == 0:
            parts.append("".join(cur))
            cur = []
            k += len(sep)
            continue
        if s.startswith("{{", k):
            dt += 1
            cur.append("{{")
            k += 2
            continue
        if s.startswith("}}", k) and dt > 0:
            dt -= 1
            cur.append("}}")
            k += 2
            continue
        if s.startswith("[[", k):
            dl += 1
            cur.append("[[")
            k += 2
            continue
        if s.startswith("]]", k) and dl > 0:
            dl -= 1
            cur.append("]]")
            k += 2
            continue
        cur.append(s[k])
        k += 1
    parts.append("".join(cur))
    return parts


def parse_template(raw):
    """Parse '{{name|p1|k=v}}' into (name, params) with positional keys '1', '2'..."""
    assert raw.startswith("{{") and raw.endswith("}}"), raw[:40]
    inner = raw[2:-2]
    parts = split_top(inner, "|")
    name = parts[0].strip()
    params = {}
    pos = 0
    for part in parts[1:]:
        m = KEY_RE.match(part)
        if m:
            key = m.group(1).strip()
            if key in params:
                raise ValueError(f"duplicate key {key!r} in {raw[:60]!r}")
            params[key] = m.group(2)
        else:
            pos += 1
            key = str(pos)
            if key in params:
                raise ValueError(f"duplicate key {key!r} in {raw[:60]!r}")
            params[key] = part
    return name, params


def walk_templates(s, path=()):
    """Yield (path, raw, name, params) for every template in s, at any depth."""
    for a, b in template_spans(s):
        raw = s[a:b]
        name, params = parse_template(raw)
        yield (path, raw, name, params, a, b)
        for key, value in params.items():
            yield from walk_templates(value, path + ((name, key),))


def strip_templates(s):
    """Remove every {{...}} from s (with its contents)."""
    out = []
    last = 0
    for a, b in template_spans(s):
        out.append(s[last:a])
        last = b
    out.append(s[last:])
    return "".join(out)


def expand(s, keep, space=frozenset()):
    """Expand templates for reading the verse text.

    keep maps a template name to the parameter key whose value stands for it
    (expanded recursively); a template named in space becomes a space; every
    other template is dropped.
    """
    out = []
    last = 0
    for a, b in template_spans(s):
        out.append(s[last:a])
        name, params = parse_template(s[a:b])
        if name in keep:
            out.append(expand(params[keep[name]], keep, space))
        elif name in space:
            out.append(" ")
        last = b
    out.append(s[last:])
    return "".join(out)


def letters_only(s):
    return "".join(c for c in s if "\N{HEBREW LETTER ALEF}" <= c <= "\N{HEBREW LETTER TAV}")

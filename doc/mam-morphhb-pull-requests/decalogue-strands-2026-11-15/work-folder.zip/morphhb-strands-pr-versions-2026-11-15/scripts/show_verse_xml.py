"""Print the raw XML lines of named verses from a morphhb book file.

Usage: show_verse_xml.py <book.xml> Exod.20.2 [Exod.20.3 ...]
"""

import re
import sys
from pathlib import Path


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    text = Path(sys.argv[1]).read_text(encoding="utf-8")
    for vid in sys.argv[2:]:
        m = re.search(r'<verse osisID="%s">.*?</verse>' % re.escape(vid), text, re.S)
        print("=" * 30, vid)
        print(m.group(0) if m else "NOT FOUND")


main()

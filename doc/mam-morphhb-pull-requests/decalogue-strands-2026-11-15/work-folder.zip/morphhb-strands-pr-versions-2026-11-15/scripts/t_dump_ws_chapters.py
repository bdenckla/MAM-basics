"""Sub-agent T: dump the mirrored MAM wikitext of Exodus 20, Deuteronomy 5 and
Genesis 35 to scratch files, verbatim, one wikitext line per file line."""

import json
import sys
from pathlib import Path

WS = Path("C:/Users/BenDe/GitRepos/MAM-basics/in/mam-ws")
OUTDIR = Path(
    "C:/Users/BenDe/GitRepos/MAM-basics/.novc/morphhb-strands-pr-versions-2026-11-15/scratch-t"
)

WANT = [
    ("A2-Exodus.json", "\N{HEBREW LETTER KAF}", "ws_exod20.txt"),
    ("A5-Deuter.json", "\N{HEBREW LETTER HE}", "ws_deut5.txt"),
    (
        "A1-Genesis.json",
        "\N{HEBREW LETTER LAMED}\N{HEBREW LETTER HE}",
        "ws_gen35.txt",
    ),
]


def main():
    sys.stderr.reconfigure(encoding="utf-8", errors="backslashreplace")
    for fname, chap, outname in WANT:
        data = json.loads((WS / fname).read_text(encoding="utf-8"))
        lines = data[chap]
        out = OUTDIR / outname
        with out.open("w", encoding="utf-8", newline="\n") as f:
            for i, line in enumerate(lines):
                f.write(f"[{i}] {line}\n")
        print(f"wrote {out} ({len(lines)} lines)", file=sys.stderr)


main()

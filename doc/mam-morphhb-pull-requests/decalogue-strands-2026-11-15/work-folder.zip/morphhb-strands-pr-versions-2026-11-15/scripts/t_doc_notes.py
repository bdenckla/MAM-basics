"""Sub-agent T: extract, by script, MAM's documentation notes on the case atoms.

Reads only: the case atoms in 22-clc-answers.json, MAM's mirrored chapter
wikitext in in/mam-ws/, and MAM-with-doc's published pages in
gh-pages/MAM-with-doc/ (to find where each note is published).
Writes scratch-t/doc_notes.json and scratch-t/doc_notes.txt.
"""

import html
import json
import re
import sys
import unicodedata
from pathlib import Path

REPO = Path("C:/Users/BenDe/GitRepos/MAM-basics")
sys.path.insert(0, str(REPO / "py"))  # untracked scratch script only

from mb_cmn.uni_denorm import give_std_mark_order  # noqa: E402

import t_wikitext as wt  # noqa: E402

W = REPO / ".novc/morphhb-strands-pr-versions-2026-11-15"
ANSWERS = REPO / ".novc/morphhb-strands-pr-2026-11-14/out/22-clc-answers.json"
WS = REPO / "in/mam-ws"
MWD = REPO / "gh-pages/MAM-with-doc"
OUT_JSON = W / "scratch-t/doc_notes.json"
OUT_TXT = W / "scratch-t/doc_notes.txt"

T_NUSACH = "\N{HEBREW LETTER NUN}\N{HEBREW LETTER VAV}\N{HEBREW LETTER SAMEKH}\N{HEBREW LETTER HET}"
T_SHIN = "\N{HEBREW LETTER SHIN}"
T_PASUQ = (
    "\N{HEBREW LETTER MEM}:\N{HEBREW LETTER PE}\N{HEBREW LETTER SAMEKH}"
    "\N{HEBREW LETTER VAV}\N{HEBREW LETTER QOF}"
)
T_KAFUL = "\N{HEBREW LETTER MEM}:\N{HEBREW LETTER KAF}\N{HEBREW LETTER PE}\N{HEBREW LETTER VAV}\N{HEBREW LETTER LAMED}"
K_KAFUL = "\N{HEBREW LETTER KAF}\N{HEBREW LETTER PE}\N{HEBREW LETTER VAV}\N{HEBREW LETTER LAMED}"
K_ALEF = "\N{HEBREW LETTER ALEF}"
K_BET = "\N{HEBREW LETTER BET}"

from mb_cmn import template_names as tmpln  # noqa: E402

assert tmpln.DUAL_CANTILLATION == T_KAFUL
K_QAMATS_D = "\N{HEBREW LETTER DALET}"
KEEP = {T_KAFUL: K_KAFUL, T_NUSACH: "1", tmpln.QAMATS_VARIANT: K_QAMATS_D}

BOOKS = {
    "Gen": ("A1-Genesis", 1),
    "Exod": ("A2-Exodus", 2),
    "Deut": ("A5-Deuter", 5),
}

UNITS = [
    "",
    "\N{HEBREW LETTER ALEF}",
    "\N{HEBREW LETTER BET}",
    "\N{HEBREW LETTER GIMEL}",
    "\N{HEBREW LETTER DALET}",
    "\N{HEBREW LETTER HE}",
    "\N{HEBREW LETTER VAV}",
    "\N{HEBREW LETTER ZAYIN}",
    "\N{HEBREW LETTER HET}",
    "\N{HEBREW LETTER TET}",
]
TENS = {0: "", 10: "\N{HEBREW LETTER YOD}", 20: "\N{HEBREW LETTER KAF}", 30: "\N{HEBREW LETTER LAMED}"}


def heb_num(n):
    if n == 15:
        return "\N{HEBREW LETTER TET}\N{HEBREW LETTER VAV}"
    if n == 16:
        return "\N{HEBREW LETTER TET}\N{HEBREW LETTER ZAYIN}"
    t, u = (n // 10) * 10, n % 10
    return TENS[t] + UNITS[u]


# BHS verse -> MAM verse, MAM numbering its Decalogues by the lower
# cantillation of the manuscripts (Exodus 20:2-13, Deuteronomy 5:6-17).
EXOD20 = {2: 2, 3: 2, 4: 3, 5: 4, 6: 5, 7: 6, 8: 7, 9: 8, 10: 9, 11: 10, 12: 11}
EXOD20.update({13: 12, 14: 12, 15: 12, 16: 12, 17: 13})
DEUT5 = {6: 6, 7: 6, 8: 7, 9: 8, 10: 9, 11: 10, 12: 11, 13: 12, 14: 13, 15: 14}
DEUT5.update({16: 15, 17: 16, 18: 16, 19: 16, 20: 16, 21: 17})


def mam_verse(book, chap, verse):
    if book == "Exod" and chap == 20:
        return EXOD20[verse]
    if book == "Deut" and chap == 5:
        return DEUT5[verse]
    return verse


# (case id, BHS vid, BHS atom or None, letters source: (vid, atom) of a case atom)
TARGETS = [
    ("1", "Exod.20.4", 2, None),
    ("1-par", "Deut.5.8", 2, None),
    ("2", "Deut.5.7", 2, None),
    ("2-par", "Exod.20.3", 2, None),
    ("4", "Exod.20.5", 2, None),
    ("4-par", "Deut.5.9", None, ("Exod.20.5", 2)),
    ("5a", "Exod.20.3", 7, None),
    ("5b", "Deut.5.7", 7, None),
    ("7", "Deut.5.8", 12, None),
    ("7-par", "Exod.20.4", None, ("Deut.5.8", 12)),
    ("8a", "Deut.5.12", 4, None),
    ("8b", "Deut.5.15", 23, None),
    ("8-par-a", "Exod.20.8", None, ("Deut.5.12", 4)),
    ("8-par-b", "Exod.20.11", None, ("Deut.5.12", 4)),
    ("9", "Gen.35.22", 7, None),
    ("10a", "Deut.5.17", 2, None),
    ("10a-par", "Exod.20.13", None, ("Deut.5.17", 2)),
    ("10b", "Exod.20.3", 2, None),
]


def names(s):
    return " | ".join(unicodedata.name(c, hex(ord(c))) for c in s)


def norm(s):
    """Normalize for matching published HTML text against mirrored wikitext."""
    s = s.replace("\N{COMBINING GRAPHEME JOINER}", "")
    s = s.replace("\N{HEBREW PUNCTUATION GERSHAYIM}", '"')
    s = re.sub(r"\s+", " ", s).strip()
    return give_std_mark_order(s)


def html_text(path):
    raw = path.read_text(encoding="utf-8")
    return raw


def load_answers():
    data = json.loads(ANSWERS.read_text(encoding="utf-8"))
    by_key = {}
    for a in data["atoms"]:
        key = (a["vid"], a["atom"])
        assert key not in by_key, key
        by_key[key] = a
    return by_key


def load_chapter(book, chap):
    fname, _ = BOOKS[book]
    data = json.loads((WS / f"{fname}.json").read_text(encoding="utf-8"))
    return fname, data[heb_num(chap)]


def verse_line(lines, chap, mverse):
    """Find the wikitext line holding MAM verse mverse of the chapter."""
    hits = []
    for i, line in enumerate(lines):
        for path, raw, name, params, a, b in wt.walk_templates(line):
            if name == T_PASUQ and params.get("2") == heb_num(chap) and params.get("3") == heb_num(mverse):
                hits.append(i)
    assert len(hits) == 1, (chap, mverse, hits)
    return hits[0]


def doc_parts(note):
    return wt.split_top(note, "{{" + T_SHIN + "}}")


def atoms_of(s):
    t = wt.expand(s, KEEP, tmpln.NO_ATOM_TMPL_NAMES)
    t = re.sub(r"<[^<>]*>", " ", t)  # the section tags around each verse
    t = t.replace("\N{HEBREW PUNCTUATION MAQAF}", " ")
    return [wt.letters_only(x) for x in t.split() if wt.letters_only(x)]


SPAN_RE = re.compile(
    r'<span class="mam-doc-part-0"(?: id="([^"]+)")?>(.*?)</span>', re.DOTALL
)


def find_published(fname, chap, mverse, note_parts):
    """Find where MAM-with-doc publishes the note.

    The big-doc page gives each note an id; the chapter page gives only the
    verse row an id, so there the note is looked for inside that verse's row.
    """
    probe = norm(wt.strip_templates(note_parts[0]))
    found = []
    big = MWD / f"{fname}-big-doc.html"
    if big.exists():
        raw = big.read_text(encoding="utf-8")
        pref = f"c{chap}v{mverse}doc"
        for m in SPAN_RE.finditer(raw):
            text = norm(html.unescape(re.sub(r"<[^>]+>", "", m.group(2))))
            if text == probe and (m.group(1) or "").startswith(pref):
                found.append((big.name, m.group(1)))
    main_page = MWD / f"{fname}.html"
    raw = main_page.read_text(encoding="utf-8")
    row_id = f"c{chap}v{mverse}"
    a = raw.find(f'<td id="{row_id}"')
    assert a >= 0, row_id
    b = raw.find('<td id="c', a + 10)
    row = raw[a : b if b >= 0 else len(raw)]
    for m in SPAN_RE.finditer(row):
        text = norm(html.unescape(re.sub(r"<[^>]+>", "", m.group(2))))
        if text == probe:
            found.append((main_page.name, row_id))
    return found, probe


FIRST_MARK = "\N{HEBREW ACCENT ETNAHTA}"
LAST_MARK = "\N{HEBREW POINT QAMATS QATAN}"
NOT_MARKS = (
    "\N{HEBREW PUNCTUATION MAQAF}"
    "\N{HEBREW PUNCTUATION PASEQ}"
    "\N{HEBREW PUNCTUATION SOF PASUQ}"
    "\N{HEBREW PUNCTUATION NUN HAFUKHA}"
)
HEB_RUN = re.compile(
    "["
    + FIRST_MARK
    + "-"
    + LAST_MARK
    + "\N{HEBREW LETTER ALEF}-\N{HEBREW LETTER TAV}"
    + "\N{COMBINING GRAPHEME JOINER}"
    + "]+"
)


def pointed_runs(s):
    """The runs of Hebrew in s that have at least one point or accent."""
    runs = []
    for m in HEB_RUN.finditer(s):
        r = m.group()
        if any(FIRST_MARK <= c <= LAST_MARK and c not in NOT_MARKS for c in r):
            runs.append(r)
    return runs


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8", errors="backslashreplace")
    answers = load_answers()
    records = []
    txt = []
    for case_id, vid, atom, letters_src in TARGETS:
        book, chap_s, verse_s = vid.split(".")
        chap, verse = int(chap_s), int(verse_s)
        mverse = mam_verse(book, chap, verse)
        if atom is not None:
            arec = answers[(vid, atom)]
            src_form = arec["wlc420"]
        else:
            arec = None
            src_form = answers[letters_src]["wlc420"]
        key_letters = wt.letters_only(src_form)
        fname, lines = load_chapter(book, chap)
        li = verse_line(lines, chap, mverse)
        line = lines[li]
        line_atoms = atoms_of(line)
        assert key_letters in line_atoms, (case_id, key_letters)
        notes = []
        for path, raw, name, params, a, b in wt.walk_templates(line):
            if name != T_NUSACH:
                continue
            target = params["1"]
            note = params["2"]
            if key_letters not in atoms_of(target):
                continue
            parts = doc_parts(note)
            pub, probe = find_published(fname, chap, mverse, parts)
            notes.append(
                {
                    "path": [list(p) for p in path],
                    "target": target,
                    "target_std": give_std_mark_order(wt.strip_templates(target)),
                    "templates_in_target": [
                        (n2, p2) for _, _, n2, p2, _, _ in wt.walk_templates(target)
                    ],
                    "note": note,
                    "doc_parts": parts,
                    "published": pub,
                }
            )
        # dual-cantillation strand texts that contain the key atom
        strands = []
        for path, raw, name, params, a, b in wt.walk_templates(line):
            if name == T_KAFUL:
                if key_letters in atoms_of(params[K_KAFUL]):
                    strands.append(
                        {
                            "kaful": params[K_KAFUL],
                            "alef": params[K_ALEF],
                            "bet": params[K_BET],
                        }
                    )
        rec = {
            "case": case_id,
            "vid": vid,
            "atom": atom,
            "mam_file": f"in/mam-ws/{fname}.json",
            "mam_chapter_key": heb_num(chap),
            "mam_verse": mverse,
            "mam_verse_label": heb_num(mverse),
            "line_index": li,
            "key_letters": key_letters,
            "notes": notes,
            "strands": strands,
        }
        if arec is not None:
            rec["wlc420"] = arec["wlc420"]
            rec["alef_name"] = arec["alef"]["name"]
            rec["bet_name"] = arec["bet"]["name"]
            rec["alef_mam_form"] = arec["alef"]["mam_form"]
            rec["bet_mam_form"] = arec["bet"]["mam_form"]
            # consistency: the JSON's MAM forms occur in the mirrored strand texts
            checks = {}
            for sk, fk in (("alef", "alef_mam_form"), ("bet", "bet_mam_form")):
                form = give_std_mark_order(rec[fk])
                inside = [give_std_mark_order(s[sk]) for s in strands]
                outside = give_std_mark_order(wt.expand(line, KEEP))
                checks[sk] = {
                    "in_kaful_strand_param": any(form in x for x in inside),
                    "in_common_text": form in outside,
                }
            rec["form_checks"] = checks
        records.append(rec)
        txt.append(f"===== case {case_id}: {vid} atom {atom} -> MAM {book} {chap}:{mverse}")
        txt.append(f"  key letters: {key_letters}")
        if arec is not None:
            txt.append(f"  wlc420: {rec['wlc420']}  [{names(rec['wlc420'])}]")
            txt.append(f"  {rec['alef_name']}: {rec['alef_mam_form']}")
            txt.append(f"  {rec['bet_name']}: {rec['bet_mam_form']}")
            txt.append(f"  form checks: {rec['form_checks']}")
        txt.append(f"  notes found: {len(notes)}")
        for n in notes:
            txt.append(f"  -- target: {n['target']}")
            txt.append(f"     templates in target: {n['templates_in_target']}")
            txt.append(f"     published: {n['published']}")
            for i, dp in enumerate(n["doc_parts"]):
                txt.append(f"     doc-part {i + 1}: {dp}")
                for r in pointed_runs(dp):
                    txt.append(f"        run {r}: {names(r)}")
        for s in strands:
            txt.append(f"  -- kaful: {s['kaful'][:300]}")
            txt.append(f"     alef: {s['alef'][:300]}")
            txt.append(f"     bet: {s['bet'][:300]}")
    with OUT_JSON.open("w", encoding="utf-8", newline="\n") as f:
        json.dump(records, f, ensure_ascii=False, indent=1)
        f.write("\n")
    with OUT_TXT.open("w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(txt) + "\n")
    print(f"wrote {OUT_JSON} and {OUT_TXT}", file=sys.stderr)


main()

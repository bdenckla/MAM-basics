"""Sub-agent I (2026-11-15): rebuild the draft, its checks, the texts and the decision page, in order.

Throwaway scratch for the morphhb strands pull request (prepared, not posted), written by Claude.
Run with -I from the MAM-basics root:

    ./.venv/Scripts/python.exe -I .novc/morphhb-strands-pr-versions-2026-11-15/scripts/i_rebuild_all.py "<HH:MM>" "<state html>" [<hashes.txt>]

Each step runs the folder's own script with the MAM-basics .venv (-B where it imports MAM-basics
modules or strands_core, -I otherwise) and the run stops at the first failure. With a hashes
file (lines "<16 hex digits> <path relative to the work folder>"), the outputs are compared with
it afterwards. Nothing here touches the network, Git or any file outside the work folder; it
does not publish the page and never runs post_pr.py.
"""

import hashlib
import subprocess
import sys
from pathlib import Path

MB = Path("C:/Users/BenDe/GitRepos/MAM-basics")
W = MB / ".novc/morphhb-strands-pr-versions-2026-11-15"
PY = str(MB / ".venv/Scripts/python.exe")
S = W / "scripts"
CATALOG = W / "fetched/master-db6c5c9b/structure__OshbVerse__Script__AccentCatalog.js"


def steps(when, state):
    b = W / "out/build-A"
    return [
        ("-I", "i_for_build.py"),
        ("-B", "versions.py"),
        ("-B", "build.py", "A", str(b)),
        ("-B", "check_build.py", str(b), str(b / "check.txt")),
        (
            "-I",
            "check_keys.py",
            str(CATALOG),
            str(W / "fetched/base-696e21ce"),
            str(b),
            str(b / "keys.txt"),
            str(W / "out/60-versions.json"),
        ),
        ("-I", "i_n_changes.py"),
        ("-B", "i_final_accgram.py"),
        ("-I", "i_spot_fetched.py"),
        ("-B", "i_spot_mam.py"),
        ("-I", "i_spot_report.py"),
        ("-B", "i_desc_facts.py"),
        (
            "-B",
            "make_description.py",
            str(S / "description.template.md"),
            str(W / "out/70-description.md"),
        ),
        (
            "-B",
            "make_description.py",
            str(S / "commit-message.template.txt"),
            str(W / "out/71-commit-message.txt"),
        ),
        ("-B", "make_fragments.py", when, state),
        (
            "-I",
            "make_decision_page.py",
            str(S / "decisions.template.html"),
            str(W / "out/fragments"),
            str(W / "out/decisions.html"),
        ),
    ]


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    when, state = sys.argv[1], sys.argv[2]
    for flag, script, *args in steps(when, state):
        # forward-slash paths, as the reports echo them
        args = [a.replace("\\", "/") if a.startswith(str(MB)) else a for a in args]
        proc = subprocess.run(
            [PY, flag, str(S / script), *args], cwd=MB, capture_output=True
        )
        tail = proc.stdout.decode("utf-8", "replace").strip().splitlines()[-1:] or [""]
        print(f"{script}: exit {proc.returncode}; {tail[0][:150]}")
        if proc.returncode != 0:
            sys.stdout.write(proc.stderr.decode("utf-8", "replace")[-3000:])
            raise SystemExit(f"stopped at {script}")
    if len(sys.argv) > 3:
        same = differ = 0
        for line in Path(sys.argv[3]).read_text(encoding="utf-8-sig").splitlines():
            want, rel = line.split(" ", 1)
            got = hashlib.sha256((W / rel).read_bytes()).hexdigest()[:16].upper()
            if got == want:
                same += 1
            else:
                differ += 1
                print(f"DIFFERS: {rel}")
        print(f"outputs equal to the hashes: {same}; differing: {differ}")


main()

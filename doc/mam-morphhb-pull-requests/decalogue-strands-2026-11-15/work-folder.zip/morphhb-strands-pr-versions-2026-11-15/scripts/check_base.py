"""Check the fetched base files: line endings, equality with the pashta folder's copies, #118 events."""

import hashlib
import json
import sys
from pathlib import Path

W = Path(__file__).resolve().parent.parent
P = Path("C:/Users/BenDe/GitRepos/MAM-basics/.novc/morphhb-pashta-pr-2026-11-14")


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    for book in ("Gen", "Exod", "Deut"):
        b = (W / "fetched/base-696e21ce" / f"{book}.xml").read_bytes()
        m = (W / "fetched/master-db6c5c9b" / f"{book}.xml").read_bytes()
        c = (P / "changed" / f"{book}.xml").read_bytes()
        print(
            book,
            "crlf",
            b.count(b"\r\n"),
            "lf",
            b.count(b"\n"),
            "bom",
            b[:3] == b"\xef\xbb\xbf",
            "base==pashta/changed",
            b == c,
            "lines differing base vs master",
            sum(1 for x, y in zip(b.split(b"\n"), m.split(b"\n")) if x != y),
        )
    for e in json.loads((W / "fetched/pr118-1/events.json").read_text(encoding="utf-8")):
        print("event", e.get("event"), e.get("created_at"), (e.get("actor") or {}).get("login"))


main()

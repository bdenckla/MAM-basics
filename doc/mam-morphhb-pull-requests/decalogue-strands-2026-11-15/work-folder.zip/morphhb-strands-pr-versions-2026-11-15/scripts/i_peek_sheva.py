"""Sub-agent I: print sub-agent V's out/52-mam-het.json cases and out/52-versions.json (read-only).

Run with -I from the MAM-basics root; Hebrew as ascii().
"""

import json
import sys
from pathlib import Path

W = Path(__file__).resolve().parent.parent
sys.stdout.reconfigure(encoding="utf-8")
for c in json.loads((W / "out/52-mam-het.json").read_text(encoding="utf-8"))["cases"]:
    print({k: ascii(v)[:90] for k, v in c.items()})
for c in json.loads((W / "out/52-versions.json").read_text(encoding="utf-8")):
    print(
        {
            k: (
                ascii(v)[:70]
                if not isinstance(v, dict)
                else {a: ascii(b)[:50] for a, b in v.items()}
            )
            for k, v in c.items()
        }
    )

"""Sub-agent G: print the token stream and tree of chosen chanted verses from g_accgram.json.

Usage: g_show_cv.py <source> <strand> <label substring> ...  e.g.  clc alef "Deut 5:8"
"""

import json
import sys
from pathlib import Path

W = Path("C:/Users/BenDe/GitRepos/MAM-basics/.novc/morphhb-strands-pr-versions-2026-11-15")


def show(node, depth=0):
    pad = "  " * depth
    if "children" in node:
        print(f"{pad}{node['label']}")
        for c in node["children"]:
            show(c, depth + 1)
    else:
        print(f"{pad}{node['label']}: {' '.join(node['leaves'])}")


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    data = json.loads((W / "scratch-g" / "g_accgram.json").read_text(encoding="utf-8"))
    args = sys.argv[1:]
    for i in range(0, len(args), 3):
        src, strand, label = args[i : i + 3]
        for cv in data["chanted_verses"]:
            if cv["source"] == src and cv["strand"] == strand and label == cv["label"]:
                ver = cv["verdict"]
                print("==", src, strand, cv["label"], ver["status"], ver["grammar"])
                for (vid, n), form in zip(cv["atoms"], cv["forms"]):
                    toks = [t for t, _l, ai in ver["accent_tokens"] if cv["atoms"][ai] == [vid, n]]
                    print(f"   {vid}:{n:<3} {form:24} {' '.join(toks)}")
                print("   tokens:", " ".join(ver["tokens"]))
                if ver["tree"]:
                    show(ver["tree"], 1)


main()

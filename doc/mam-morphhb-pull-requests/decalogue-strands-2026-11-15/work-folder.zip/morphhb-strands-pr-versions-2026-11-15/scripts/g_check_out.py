"""Sub-agent G: sanity-check W/out/53-accgram.json (loads, sizes, key counts)."""

import json
import sys
from pathlib import Path

W = Path("C:/Users/BenDe/GitRepos/MAM-basics/.novc/morphhb-strands-pr-versions-2026-11-15")


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    p = W / "out" / "53-accgram.json"
    d = json.loads(p.read_text(encoding="utf-8"))
    print("bytes", p.stat().st_size)
    print("keys", list(d))
    print("chanted verses", len(d["chanted_verses"]))
    sa = d["strand_atoms"]
    print("strand_atoms", len(sa), "clc", sum(1 for r in sa if r["source"] == "clc"), "mam", sum(1 for r in sa if r["source"] == "mam"))
    print("clc with criteria", sum(1 for r in sa if r["source"] == "clc" and r["criteria"]))
    print("n keys", list(d["n"]))
    print("new_main_text", len(d["n"]["new_main_text"]), "changed", sum(1 for x in d["n"]["new_main_text"] if x["changed"]))
    print("differential", len(d["n"]["differential_today"]), "agree", sum(1 for x in d["n"]["differential_today"] if x["agree"]))
    print(d["noted_vs_illegal"]["criterion counts"])


main()

"""Sizes of the work folder's parts, to decide what goes into deep storage."""

import sys
from pathlib import Path

W = Path(__file__).resolve().parent.parent


def size(p):
    return sum(f.stat().st_size for f in p.rglob("*") if f.is_file()) if p.is_dir() else p.stat().st_size


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    rows = []
    for p in sorted(W.iterdir()):
        if p.is_dir() and p.name in ("fetched", "out"):
            for q in sorted(p.iterdir()):
                rows.append((size(q), str(q.relative_to(W))))
        else:
            rows.append((size(p), str(p.relative_to(W))))
    for s, n in sorted(rows, reverse=True)[:40]:
        print(f"{s:>10,}  {n}")
    print(f"{sum(s for s, _ in rows):>10,}  total")
    names = [f.name for f in W.rglob("*") if f.is_file()]
    print("files:", len(names), "| with non-ASCII names:", [n for n in names if not n.isascii()][:5])


main()

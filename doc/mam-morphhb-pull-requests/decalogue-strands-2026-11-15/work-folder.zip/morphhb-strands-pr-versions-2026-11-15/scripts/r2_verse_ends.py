"""Describe how each named verse ends in a morphhb book file, without printing Hebrew.

Usage:
  python -I r2_verse_ends.py <dir> Exod.20.2 [Deut.5.17 ...]

<dir> holds Gen.xml, Exod.xml and Deut.xml. For each verse, prints: the number of direct <w>
children carrying n; the last direct <w>'s n (or "none") and the Unicode names of its accents
(U+0591 to U+05AE) and of any U+05BD; whether a variant note with a qere <w> follows it; and the
types of the direct segs after the last direct <w>. Reads files as UTF-8; writes nothing.
"""

import sys
import unicodedata
import xml.etree.ElementTree as ET
from pathlib import Path

NS = "{http://www.bibletechnologies.net/2003/OSIS/namespace}"


def marks(text):
    return [unicodedata.name(c) for c in text if "֑" <= c <= "֮" or c == "ֽ"]


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    folder = Path(sys.argv[1])
    roots = {}
    for osis in sys.argv[2:]:
        book = osis.split(".")[0]
        if book not in roots:
            roots[book] = ET.parse(folder / ("%s.xml" % book)).getroot()
        verse = roots[book].find(".//%sverse[@osisID='%s']" % (NS, osis))
        kids = list(verse)
        words = [i for i, k in enumerate(kids) if k.tag == NS + "w"]
        with_n = sum(1 for i in words if kids[i].get("n") is not None)
        last = words[-1]
        w = kids[last]
        after = kids[last + 1 :]
        qere = [x for x in after if x.tag == NS + "note" and x.get("type") == "variant"]
        qere_n = [q.get("n") for note in qere for q in note.iter(NS + "w")]
        segs = [x.get("type") for x in after if x.tag == NS + "seg"]
        print("%-10s w-with-n=%d last-n=%s marks=%s qere-n=%s segs-after=%s"
              % (osis, with_n, w.get("n", "none"), marks("".join(w.itertext())) or "none",
                 qere_n or "-", segs or "none"))


if __name__ == "__main__":
    main()

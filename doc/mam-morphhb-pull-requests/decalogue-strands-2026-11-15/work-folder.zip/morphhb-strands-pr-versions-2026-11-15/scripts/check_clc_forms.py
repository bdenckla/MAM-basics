"""Differential check of folder S's CLC-rule forms (the versions' source) by a simple rule.

For each atom and strand: WLC 4.20's marks, letter by letter, less the marks that MAM's other
strand has there and MAM's strand lacks (CLC's subtraction, with MAM's strands standing in for
CLC's oracle, which was encoded from them). Marks compared as sets per letter, after mapping
MAM's qamats qatan to qamats and dropping MAM's holam on the Tetragrammaton and joiners.
Prints every atom where the rule's result and folder S's form differ, with the letter and the
marks, so that each difference can be explained (supplied punctuation is ignored here).
"""

import sys
import unicodedata
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))  # untracked scratch: exempt
import strands_core as sc  # noqa: E402
import versions as vs  # noqa: E402

JOINERS = {"͏", "‍", "‌"}


def marksets(core):
    out = []
    for l, ms in sc.letters_marks("".join(c for c in core if c not in JOINERS)):
        s = set(vs.norm_mam_vowel(m) for m in ms)
        out.append((l, s))
    return out


def short(ms):
    return ",".join(sorted(unicodedata.name(m).replace("HEBREW ", "").lower() for m in ms))


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    recs = {(r["vid"], r["atom"]): r for r in vs.compute()}
    diffs = 0
    for a in sc.load_atoms():
        r = recs[(a["vid"], a["atom"])]
        wl = marksets(sc.split_form(a["wlc420"])[0])
        for s, o in (("alef", "bet"), ("bet", "alef")):
            ms = marksets(r["mam"][s][0])
            mo = marksets(r["mam"][o][0])
            cl = marksets(r["clc"][s][0])
            for i, ((l, w), (_, a_s), (_, a_o), (_, c)) in enumerate(zip(wl, ms, mo, cl)):
                expect = w - (a_o - a_s)
                if is_tetra := (sc.LETTER.match(l) and False):
                    pass
                if expect != c:
                    diffs += 1
                    print(
                        f"{a['vid']}:{a['atom']} {s} letter {i + 1} ({unicodedata.name(l).split()[-1].lower()}): "
                        f"rule [{short(expect)}] folder S [{short(c)}] | WLC [{short(w)}] MAM {s} [{short(a_s)}] MAM {o} [{short(a_o)}]"
                    )
    print("letter-strand differences:", diffs)


main()

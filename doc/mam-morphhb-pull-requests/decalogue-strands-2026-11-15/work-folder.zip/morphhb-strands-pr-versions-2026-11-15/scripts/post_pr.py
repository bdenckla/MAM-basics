"""Post the prepared pull request to openscriptures/morphhb, exactly as the decision page lists.

Adapted from the pashta-helper folder's scripts/post_pr.py (which posted #118). Run --post only
after Ben has said, in this session and in his own words, to post it.

Usage (-I):
  post_pr.py <work_dir> <bodies_dir> --dry-run
  post_pr.py <work_dir> <bodies_dir> --post

<bodies_dir> is a new, empty folder for the request bodies. Each step is one `gh api` request,
logged to <work_dir>/out/fetch_log.jsonl, its response saved unchanged under
<work_dir>/fetched/post-<bodies_dir name>-<nn>-<step>/:
  1. read #118: stop unless it is open, unmerged, at head HEAD118 on BASE118; read upstream
     master (recorded; the pull request's base); read the fork's pashta-helpers: stop unless HEAD118;
  2. read HEAD118's root tree and wlc/ tree: stop unless each of the three files is the blob the
     change was made from;
  3. upload each changed file as a blob; check the returned sha;
  4. create a tree on HEAD118's tree replacing only the three paths;
  5. create one commit on HEAD118 with that tree and out/71-commit-message.txt;
  6. create the branch BRANCH at that commit; compare HEAD118...BRANCH: one commit ahead, the
     three files, each changed in as many lines as the local files differ from the base;
  7. open the pull request with out/70-description.md's title and body, maintainers allowed to
     edit; read it back: title and body must equal the description's.
With --dry-run, the GETs of steps 1 and 2 run and nothing is written to GitHub.
"""

import base64
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

UPSTREAM = "openscriptures/morphhb"
FORK = "bdenckla/morphhb"
HEAD118 = "696e21cef94e5bb0da2515667816d0965810d351"
BASE118 = "db6c5c9b46b8f39346f10915ddb1a70dcd429901"
BRANCH = "decalogue-strands"
FILES = ("Gen", "Exod", "Deut")


def git_blob_sha1(data):
    h = hashlib.sha1()
    h.update(b"blob %d\0" % len(data))
    h.update(data)
    return h.hexdigest()


class Poster:
    def __init__(self, work, bodies, post):
        self.work, self.bodies, self.post, self.n = work, bodies, post, 0
        self.log = work / "out/fetch_log.jsonl"

    def call(self, step, method, api_path, body=None):
        self.n += 1
        args = ["api", "-X", method, "-H", "Accept: application/vnd.github+json", api_path]
        if body is not None:
            bp = self.bodies / ("%02d-%s.json" % (self.n, step))
            bp.write_text(json.dumps(body, ensure_ascii=False), encoding="utf-8", newline="\n")
            args += ["--input", str(bp)]
        if method != "GET" and not self.post:
            print("DRY RUN, not sent: %s %s%s" % (method, api_path, "" if body is None else " (body %s)" % bp.name))
            return None
        env = dict(os.environ)
        env.update({"GH_PROMPT_DISABLED": "1", "GIT_TERMINAL_PROMPT": "0", "GCM_INTERACTIVE": "never"})
        proc = subprocess.run(["gh", *args], capture_output=True, env=env)
        out_dir = self.work / "fetched" / ("post-%s-%02d-%s" % (self.bodies.name, self.n, step))
        out_dir.mkdir(parents=True, exist_ok=False)
        (out_dir / "response.json").write_bytes(proc.stdout)
        rec = {
            "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "kind": method,
            "api_path": api_path,
            "out": str(out_dir / "response.json"),
            "bytes": len(proc.stdout),
            "sha256": hashlib.sha256(proc.stdout).hexdigest(),
            "returncode": proc.returncode,
        }
        with open(self.log, "a", encoding="utf-8", newline="\n") as f:
            f.write(json.dumps(rec) + "\n")
        if proc.returncode != 0:
            sys.stderr.buffer.write(proc.stderr)
            raise SystemExit("request failed at step %s: %s %s" % (step, method, api_path))
        time.sleep(0.5)
        return json.loads(proc.stdout.decode("utf-8")) if proc.stdout.strip() else None


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    work, bodies, mode = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
    if mode not in ("--dry-run", "--post"):
        raise SystemExit("mode must be --dry-run or --post")
    bodies.mkdir(parents=True, exist_ok=False)
    P = Poster(work, bodies, mode == "--post")
    desc = (work / "out/70-description.md").read_text(encoding="utf-8")
    title_line, body = desc.split("\n", 1)
    title, body = title_line[len("Title: ") :], body.lstrip("\n")
    if "@" in body or "<!--" in body or "@" in title:
        raise SystemExit("at-sign or HTML comment in the pull request text")
    message = (work / "out/71-commit-message.txt").read_text(encoding="utf-8")
    local = {b: (work / "out/build-A" / f"{b}.xml").read_bytes() for b in FILES}
    base = {b: (work / "fetched/base-696e21ce" / f"{b}.xml").read_bytes() for b in FILES}

    pr = P.call("pr118", "GET", "repos/%s/pulls/118" % UPSTREAM)
    if pr["state"] != "open" or pr.get("merged") or pr["head"]["sha"] != HEAD118 or pr["base"]["sha"] != BASE118:
        raise SystemExit("#118 is not as the change assumes: state %s, head %s, base %s" % (pr["state"], pr["head"]["sha"], pr["base"]["sha"]))
    m = P.call("upstream-master", "GET", "repos/%s/commits/master" % UPSTREAM)
    print("1. #118 open at %s; upstream master %s%s" % (HEAD118[:8], m["sha"][:8], "" if m["sha"] == BASE118 else " (moved since #118)"))
    fb = P.call("fork-branch", "GET", "repos/%s/branches/pashta-helpers" % FORK)
    if fb["commit"]["sha"] != HEAD118:
        raise SystemExit("the fork's pashta-helpers is %s" % fb["commit"]["sha"])

    hc = P.call("head-commit", "GET", "repos/%s/git/commits/%s" % (FORK, HEAD118))
    root = P.call("head-tree", "GET", "repos/%s/git/trees/%s" % (FORK, hc["tree"]["sha"]))
    wlc_entry = next(e for e in root["tree"] if e["path"] == "wlc")
    wlc = P.call("head-wlc-tree", "GET", "repos/%s/git/trees/%s" % (FORK, wlc_entry["sha"]))
    modes = {"wlc/" + e["path"]: (e["mode"], e["sha"]) for e in wlc["tree"]}
    for b in FILES:
        if modes["wlc/%s.xml" % b][1] != git_blob_sha1(base[b]):
            raise SystemExit("wlc/%s.xml is not the blob the change was made from" % b)
    print("2. head tree %s; each file is the base blob" % root["sha"][:8])

    entries = []
    for b in FILES:
        want = git_blob_sha1(local[b])
        r = P.call("blob-" + b, "POST", "repos/%s/git/blobs" % FORK, {"content": base64.b64encode(local[b]).decode("ascii"), "encoding": "base64"})
        if r is not None and r["sha"] != want:
            raise SystemExit("blob for %s came back as %s, not %s" % (b, r["sha"], want))
        entries.append({"path": "wlc/%s.xml" % b, "mode": modes["wlc/%s.xml" % b][0], "type": "blob", "sha": want})
    print("3. %d blobs" % len(entries))

    t = P.call("tree", "POST", "repos/%s/git/trees" % FORK, {"base_tree": root["sha"], "tree": entries})
    c = P.call("commit", "POST", "repos/%s/git/commits" % FORK, {"message": message, "tree": t["sha"] if t else "TREE", "parents": [HEAD118]})
    ref = P.call("ref", "POST", "repos/%s/git/refs" % FORK, {"ref": "refs/heads/" + BRANCH, "sha": c["sha"] if c else "COMMIT"})
    if c is not None:
        cmp_ = P.call("compare", "GET", "repos/%s/compare/%s...%s:%s" % (FORK, HEAD118, FORK.split("/")[0], BRANCH))
        got = sorted(x["filename"] for x in cmp_["files"])
        want = sorted("wlc/%s.xml" % b for b in FILES)
        if got != want or cmp_["ahead_by"] != 1 or cmp_["behind_by"] != 0:
            raise SystemExit("comparison differs: ahead %s behind %s, files %r" % (cmp_["ahead_by"], cmp_["behind_by"], got))
        nroot = P.call("new-tree", "GET", "repos/%s/git/trees/%s" % (FORK, c["tree"]["sha"]))
        nwlc = next(e for e in nroot["tree"] if e["path"] == "wlc")
        nt = P.call("new-wlc-tree", "GET", "repos/%s/git/trees/%s" % (FORK, nwlc["sha"]))
        new_shas = {"wlc/" + e["path"]: e["sha"] for e in nt["tree"]}
        for b in FILES:
            if new_shas["wlc/%s.xml" % b] != git_blob_sha1(local[b]):
                raise SystemExit("the commit's wlc/%s.xml is not the local file" % b)
        print("4-6. tree %s, commit %s, branch %s; one commit ahead, the three files, each the local blob" % (t["sha"][:8], c["sha"][:8], ref["ref"]))

    p = P.call(
        "pull-request",
        "POST",
        "repos/%s/pulls" % UPSTREAM,
        {"title": title, "head": "%s:%s" % (FORK.split("/")[0], BRANCH), "base": "master", "body": body, "maintainer_can_modify": True},
    )
    if p is not None:
        back = P.call("pull-request-read", "GET", "repos/%s/pulls/%d" % (UPSTREAM, p["number"]))
        same = back["title"] == title and back["body"] == body
        print("7. pull request %s; read back: title and body %s" % (back["html_url"], "equal" if same else "DIFFER"))
        if not same:
            raise SystemExit("the posted text differs from the description")
    print("done (%s)" % mode)


if __name__ == "__main__":
    main()

"""Count each of the 24 divided verses' direct children in morphhb XML (master and a build).

Usage:
  python -I r2_child_counts.py <master-dir> <build-dir>

Each directory holds Gen.xml, Exod.xml and Deut.xml. For every verse, prints the number of
direct child elements of <verse> (what OET's converter counts, `assert j < 100`), the numbers
of <w>, <seg>, alternative notes and other notes, the largest number of alternative notes
after one <w> (counting notes up to the next <w>), and a bound for three alternative notes
per <w>: w + seg + other notes + 3 * w. Reads files as UTF-8. Writes nothing.
"""

import sys
import xml.etree.ElementTree as ET
from pathlib import Path

NS = "{http://www.bibletechnologies.net/2003/OSIS/namespace}"
VERSES = (
    ["Gen.35.22"]
    + ["Exod.20.%d" % v for v in (2, 3, 4, 5, 6, 8, 9, 10, 13, 14, 15)]
    + ["Deut.5.%d" % v for v in (6, 7, 8, 9, 10, 12, 13, 14, 15, 17, 18, 19)]
)


def verse_stats(verse):
    kids = list(verse)
    tags = [k.tag.replace(NS, "") for k in kids]
    alt = [k for k in kids if k.tag == NS + "note" and k.get("type") == "alternative"]
    other = sum(1 for k in kids if k.tag == NS + "note") - len(alt)
    run, most = 0, 0
    for k in kids:
        if k.tag == NS + "w":
            run = 0
        elif k.tag == NS + "note" and k.get("type") == "alternative":
            run += 1
            most = max(most, run)
    n_w, n_seg = tags.count("w"), tags.count("seg")
    return len(kids), n_w, n_seg, len(alt), other, most, n_w + n_seg + other + 3 * n_w


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    roots = {}
    for label, folder in (("master", sys.argv[1]), ("build", sys.argv[2])):
        for book in ("Gen", "Exod", "Deut"):
            roots[(label, book)] = ET.parse(Path(folder) / ("%s.xml" % book)).getroot()
    print("verse      | master: children w seg alt other maxrun | build: children w seg alt other maxrun bound3")
    top = {}
    for osis in VERSES:
        book = osis.split(".")[0]
        row = []
        for label in ("master", "build"):
            verse = roots[(label, book)].find(".//%sverse[@osisID='%s']" % (NS, osis))
            row.append(verse_stats(verse))
        m, b = row
        print("%-10s | %3d %2d %2d %2d %d %d | %3d %2d %2d %2d %d %d %3d" % ((osis,) + m[:6] + b))
    for label in ("master", "build"):
        for book in ("Gen", "Exod", "Deut"):
            best = max((len(list(v)), v.get("osisID")) for v in roots[(label, book)].iter(NS + "verse"))
            top[(label, book)] = best
    print()
    for key, (count, osis) in sorted(top.items()):
        print("most children in any verse, %s %s: %d (%s)" % (key[0], key[1], count, osis))


if __name__ == "__main__":
    main()

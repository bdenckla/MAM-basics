"""Sub-agent V: print the cases of out/52-mam-het.json (throwaway scratch)."""

import json
import sys
from pathlib import Path

W = Path(__file__).resolve().parent.parent


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    data = json.loads((W / "out" / "52-mam-het.json").read_text(encoding="utf-8"))
    for c in data["cases"]:
        print(json.dumps(c, ensure_ascii=False))


main()

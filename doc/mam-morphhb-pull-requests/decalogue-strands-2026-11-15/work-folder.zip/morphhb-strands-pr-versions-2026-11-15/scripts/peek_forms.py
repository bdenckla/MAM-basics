"""Print WLC 4.20's form and each strand's CLC-rule form, supplied and noted marks, for atoms.

Usage: peek_forms.py Exod.20.3:1 ...   (or 'all' for every atom whose strands differ)
"""

import json
import sys
from pathlib import Path

S = Path("C:/Users/BenDe/GitRepos/MAM-basics/.novc/morphhb-strands-pr-2026-11-14")


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    data = json.loads((S / "out/22-clc-answers.json").read_text(encoding="utf-8"))
    want = set(sys.argv[1:])
    for a in data["atoms"]:
        key = f"{a['vid']}:{a['atom']}"
        if key in want or ("all" in want and a["two_strands_differ"]["clc_rule_wlc"]):
            print(key, "wlc", ascii(a["wlc420"]))
            for s in ("alef", "bet"):
                d = a[s]
                print(
                    "   ",
                    s,
                    ascii(d["clc_rule_form"]),
                    "sup",
                    d["supplied"],
                    "noted",
                    [(n["mark"], n["letter"]) for n in d["noted"]],
                    "mam",
                    ascii(d["mam_form"]),
                )


main()

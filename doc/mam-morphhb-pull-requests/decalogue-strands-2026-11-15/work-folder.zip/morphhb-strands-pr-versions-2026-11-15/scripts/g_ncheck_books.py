"""Sub-agent G (2026-11-15): differential check of the n coding against morphhb's hand-made n,
over every verse of the three fetched books (Genesis, Exodus, Deuteronomy at 696e21ce) except
the 24 dual-cantillation verses.

Throwaway scratch, written by Claude.  Run from C:/Users/BenDe/GitRepos/MAM-basics:

    ./.venv/Scripts/python.exe -B .novc/morphhb-strands-pr-versions-2026-11-15/scripts/g_ncheck_books.py

Each verse's main text is built from its <w> elements (a ketiv's qere in its place) and their
maqaf, paseq and sof pasuq segs, parsed by accgram (g_common.verdict), and, where accgram finds
it clean, coded by g_common.tree_codes and g_common.level_codes; each <w>'s computed code is
compared with its n.  Writes W/scratch-g/g_ncheck_books.json and prints a summary.
"""

import json
import sys
import xml.etree.ElementTree as ET
from collections import Counter

sys.dont_write_bytecode = True

import g_common as g  # noqa: E402

NS = g.NS


def local(tag):
    return tag.rsplit("}", 1)[-1]


def verse_words(v):
    """[(id, text, n, maqaf, paseq, sof)] of the main text, a ketiv's qere in its place."""
    words = []

    def add_w(el):
        words.append(
            {"id": el.get("id"), "text": "".join(el.itertext()).replace("/", ""), "n": el.get("n")}
        )

    def add_seg(el):
        st = el.get("type")
        if st == "x-maqqef":
            words[-1]["maqaf"] = True
        elif st == "x-paseq":
            words[-1]["paseq"] = True
        elif st == "x-sof-pasuq":
            words[-1]["sof"] = True
        elif st in ("x-pe", "x-samekh", "x-reversednun", "x-large", "x-small", "x-suspended"):
            pass
        else:
            raise ValueError(f"seg {st}")

    for el in v:
        t = local(el.tag)
        if t == "w":
            if el.get("type") == "x-ketiv":
                continue
            add_w(el)
        elif t == "seg":
            if el.get("type") == "x-ketiv":
                continue
            add_seg(el)
        elif t == "note":
            if el.get("type") == "variant":
                for rdg in el:
                    if local(rdg.tag) != "rdg" or rdg.get("type") != "x-qere":
                        continue
                    for c in rdg:
                        ct = local(c.tag)
                        if ct == "w":
                            add_w(c)
                        elif ct == "seg":
                            add_seg(c)
            elif el.get("type") == "alternative":
                raise ValueError("an alternative note")
        else:
            raise ValueError(f"element {t}")
    return words


def forms_of(words):
    out = []
    for w in words:
        f = w["text"]
        if w.get("maqaf"):
            f += g.MAQAF
        if w.get("paseq"):
            f += " " + g.PASEQ
        if w.get("sof"):
            f += g.SOF
        out.append(f)
    return out


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    skip = set(g.VIDS24)
    stats = Counter()
    disagreements = []
    tree_level = Counter()
    tree_level_vids = []
    not_clean = Counter()
    not_clean_vids = []
    for book in ("Gen", "Exod", "Deut"):
        root = ET.parse(g.BASE / f"{book}.xml").getroot()
        for v in root.iter(f"{NS}verse"):
            vid = v.get("osisID")
            stats["verses"] += 1
            if vid in skip:
                stats["skipped: dual cantillation"] += 1
                continue
            try:
                words = verse_words(v)
                forms = forms_of(words)
            except ValueError as e:
                stats[f"skipped: {e}"] += 1
                continue
            if not forms or not forms[-1].endswith(g.SOF) or any(f.endswith(g.SOF) for f in forms[:-1]):
                stats["skipped: not one sof pasuq at the end"] += 1
                continue
            _, ch, vn = g.vid_parts(vid)
            try:
                ver = g.verdict(forms, g.BB[book], ch, vn)
            except ValueError as e:
                stats["skipped: accgram cannot read a mark"] += 1
                continue
            if ver["status"] != "clean":
                not_clean[ver["status"]] += 1
                not_clean_vids.append(vid)
                stats["not clean by accgram"] += 1
                continue
            toks = ver["accent_tokens"]
            tcodes = g.tree_codes(ver["tree"], toks)
            tper = g.atom_codes(toks, tcodes, len(forms))
            lcodes, _notes = g.level_codes([t for t, _l, _a in toks])
            lper = g.atom_codes(toks, lcodes, len(forms))
            tree_level["agree" if tper == lper else "differ"] += 1
            if tper != lper:
                tree_level_vids.append(vid)
            stats["coded"] += 1
            bad = []
            for w, codes, f in zip(words, tper, forms):
                code = "+".join(codes) if codes else None
                stats["atoms"] += 1
                if code == w["n"]:
                    stats["atoms agreeing"] += 1
                else:
                    bad.append({"id": w["id"], "form": f, "computed": code, "n": w["n"]})
            if bad:
                stats["verses with a disagreement"] += 1
                disagreements.append(
                    {"vid": vid, "tokens": " ".join(ver["tokens"][1:-1]), "atoms": bad,
                     "level_agrees_with_n": [("+".join(c) if c else None) for c in lper]
                     == [w["n"] for w in words]}
                )
            else:
                stats["verses agreeing"] += 1
    out = {
        "stats": dict(stats),
        "not_clean": dict(not_clean),
        "tree_vs_level": dict(tree_level),
        "tree_vs_level_differ": tree_level_vids,
        "not_clean_vids": not_clean_vids,
        "disagreements": disagreements,
    }
    path = g.W / "scratch-g" / "g_ncheck_books.json"
    path.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8", newline="\n")
    for k, v in sorted(stats.items()):
        print(k, v)
    print("not clean:", dict(not_clean))
    print("tree vs level:", dict(tree_level), tree_level_vids)
    print("not clean:", not_clean_vids)
    for d in disagreements[:60]:
        print(d["vid"], d["tokens"])
        for a in d["atoms"]:
            print("    ", a["id"], a["form"], "computed", a["computed"], "n", a["n"])
    print("wrote", path)


main()

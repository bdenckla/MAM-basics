"""Write the pull request's description or commit message from a template, copying Hebrew by script.

Run with -B from the MAM-basics root:
  make_description.py <description.template.md> <out/70-description.md>
  make_description.py <commit-message.template.txt> <out/71-commit-message.txt>

The template may hold unpointed Hebrew (strand names) but no Hebrew point, accent or
punctuation; the script raises if it finds one. Placeholders:
  {{F:<vid>:<atom>:<kind>}}  the display form of that span's version (kind: main, clc_other,
                             mam_main, mam_other, wlc, mam_alef, mam_bet, base_main, base_note);
  {{XML:<vid>:<first>-<last>}} the built XML of those spans, as morphhb's file has it;
  {{COUNT:<name>}}           a count from the build log (notes_<kind>, new_main_texts);
  {{FACT:<name>}}            a value from out/58-facts.json (scripts/i_desc_facts.py): a number
                             with thousands separators, a list joined as English, a string as is.

A description (output ending in .md): the first line is "Title: ...", and the text may hold no
at-sign and no HTML comment. A commit message (output ending in .txt): no line over 72
characters, and the last line is the Co-Authored-By line, whose at-sign is the only one allowed.
"""

import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))  # untracked scratch: exempt
import strands_core as sc  # noqa: E402
import versions as vs  # noqa: E402
from make_fragments import base_readings, display  # noqa: E402

MARK = re.compile("[\N{HEBREW ACCENT ETNAHTA}-\N{HEBREW POINT QAMATS QATAN}]")
TRAILER = "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"


def english_list(xs):
    xs = [str(x) for x in xs]
    if len(xs) <= 2:
        return " and ".join(xs)
    return ", ".join(xs[:-1]) + " and " + xs[-1]


def fact_text(v):
    if isinstance(v, bool):
        raise ValueError("a boolean fact")
    if isinstance(v, int):
        return f"{v:,}"
    if isinstance(v, list):
        return english_list(v)
    if isinstance(v, str):
        return v
    raise ValueError(f"unprintable fact {v!r}")


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    tpl_path, out_path = Path(sys.argv[1]), Path(sys.argv[2])
    tpl = tpl_path.read_text(encoding="utf-8")
    bad = MARK.search(tpl)
    if bad:
        raise SystemExit(
            "pointed Hebrew typed into the template at line %d"
            % (tpl.count("\n", 0, bad.start()) + 1)
        )
    recs = {(r["vid"], r["atom"]): r for r in vs.compute()}
    atoms = {(a["vid"], a["atom"]): a for a in sc.load_atoms()}
    base = base_readings()
    log = json.loads((sc.W / "out/build-A/build-log.json").read_text(encoding="utf-8"))[
        "log"
    ]
    facts = json.loads((sc.W / "out/58-facts.json").read_text(encoding="utf-8"))
    counts = {"new_main_texts": sum(1 for e in log if "new_text" in e)}
    for e in log:
        if "note" in e:
            counts["notes_" + e["kind"]] = counts.get("notes_" + e["kind"], 0) + 1
    counts["notes"] = sum(v for k, v in counts.items() if k.startswith("notes_"))
    built = {
        b: (sc.W / "out/build-A" / f"{b}.xml").read_text(encoding="utf-8")
        for b in sc.BOOKS
    }

    def form(m):
        vid, atom, kind = m.group(1), int(m.group(2)), m.group(3)
        r, a = recs[(vid, atom)], atoms[(vid, atom)]
        if kind == "wlc":
            return a["wlc420"].replace("[", "").replace("]", "")
        if kind in ("mam_alef", "mam_bet"):
            return display(tuple(r["mam"][kind[4:]]))
        if kind == "base_main":
            return base[r["w_id"]]["main"]
        if kind == "base_note":
            notes = base[r["w_id"]]["notes"]
            if len(notes) != 1:
                raise SystemExit(f"{vid}:{atom} has {len(notes)} notes in the base")
            return notes[0]
        v = [x for x in r["versions"] if x["kind"] == kind]
        if not v:
            raise SystemExit(f"no {kind} version at {vid}:{atom}")
        return display(tuple(v[0]["span"]))

    def xml(m):
        vid, first, last = m.group(1), int(m.group(2)), int(m.group(3))
        book = vid.split(".")[0]
        block = re.search(
            r'<verse osisID="%s">.*?</verse>' % re.escape(vid), built[book], re.S
        ).group(0)
        ids = [recs[(vid, k)]["w_id"] for k in range(first, last + 1)]
        lines = [
            ln.strip()
            for ln in block.splitlines()
            if any(f'id="{i}"' in ln for i in ids)
        ]
        return "\n".join(lines)

    text = re.sub(r"\{\{F:([A-Za-z]+\.\d+\.\d+):(\d+):([a-z_]+)\}\}", form, tpl)
    text = re.sub(r"\{\{XML:([A-Za-z]+\.\d+\.\d+):(\d+)-(\d+)\}\}", xml, text)
    text = re.sub(r"\{\{COUNT:([a-z_]+)\}\}", lambda m: f"{counts[m.group(1)]:,}", text)
    text = re.sub(
        r"\{\{FACT:([a-z0-9_]+)\}\}", lambda m: fact_text(facts[m.group(1)]), text
    )
    if "{{" in text:
        raise SystemExit(
            "unresolved placeholder: " + text[text.index("{{") : text.index("{{") + 40]
        )
    if out_path.suffix == ".txt":
        lines = text.rstrip("\n").split("\n")
        if lines[-1] != TRAILER:
            raise SystemExit("the commit message must end with the Co-Authored-By line")
        if "@" in "\n".join(lines[:-1]) or "<!--" in text:
            raise SystemExit("at-sign or HTML comment in the commit message")
        long = [ln for ln in lines if len(ln) > 72]
        if long:
            raise SystemExit("commit-message lines over 72 characters: %r" % long[:3])
    else:
        if "@" in text or "<!--" in text:
            raise SystemExit("at-sign or HTML comment in the text")
        if not text.startswith("Title: "):
            raise SystemExit("the first line must be the title")
    out_path.write_text(text, encoding="utf-8", newline="\n")
    print("wrote", out_path, len(text), "characters")


if __name__ == "__main__":
    main()

"""Sub-agent G: summarize MAM-basics' existing out/accgram/dual-cant/_dual_cant.json.

That file is accgram's detangling of WLC 4.22 with MAM's strands as the oracle
(py/accgram/dual_cant_run.py). Prints each chanted verse's ref, span, status and tokens,
then the anomalies and supplied marks.
"""

import json
import sys
from pathlib import Path

P = Path("C:/Users/BenDe/GitRepos/MAM-basics/out/accgram/dual-cant/_dual_cant.json")


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    data = json.loads(P.read_text(encoding="utf-8"))
    print("summary", data["summary"])
    for p in data["passages"]:
        print("==", p["name"], p["alef_label"], p["bet_label"])
        for s in p["strands"]:
            for cv in s["chanted_verses"]:
                print(
                    f"  {s['strand']:4} {cv['ref']:45} {cv['status']:8} "
                    + " ".join(t for t in cv["tokens"])
                )
        for a in p["anomalies"]:
            print("  ANOMALY", a["bcv"], a["strand_label"], a["expected_name"], "->", a["found_name"])
        for m in p["supplied_marks"]:
            print("  SUPPLIED", m["bcv"], m["strand_label"], m["accent_name"])


main()

"""Sub-agent G (2026-11-15): accgram's verdict on MAM's and CLC's strands of the 24 verses.

Throwaway scratch for the morphhb strands pull request (prepared, not posted), written by Claude.
Run from C:/Users/BenDe/GitRepos/MAM-basics:

    ./.venv/Scripts/python.exe -B .novc/morphhb-strands-pr-versions-2026-11-15/scripts/g_accgram.py

Writes W/scratch-g/g_accgram.json (read by g_ncodes.py and g_report.py) and prints a summary.

Tasks 2-4 of the brief:
- assemble each strand's chanted verses (a chanted verse ends at an atom whose strand form ends
  in sof pasuq), from MAM's forms and from CLC's forms on WLC 4.20 (brackets removed, supplied
  marks kept), running on into Exodus 20:11 and 20:16 and Deuteronomy 5:20 where a strand does;
- give each accgram's verdict (g_common.verdict: the lexical layer, then the scanner and grammar);
- for every CLC chanted verse that is not clean, find the smallest sets of atoms whose MAM form
  makes it clean;
- test criteria (i)-(iv) on every CLC version of every atom (and, as a control, on MAM's).
"""

import json
import sys

sys.dont_write_bytecode = True

import g_common as g  # noqa: E402


def clusters(form: str) -> list[tuple[str, str]]:
    """(letter, its marks) for each base letter of an atom."""
    out = []
    for ch in form:
        if g.is_letter(ch):
            out.append([ch, ""])
        elif out:
            out[-1][1] += ch
    return [(a, b) for a, b in out]


def has_vowel(marks: str) -> bool:
    return any(c in g.VOWELS for c in marks)


def tetragrammaton_he(form: str, k: int) -> bool:
    """True if letter k is the first he of a yod-he-vav-he run (MAM writes a holam there)."""
    lets = g.letters(form)
    run = g.YOD + g.HE + g.VAV + g.HE
    at = lets.find(run)
    return at >= 0 and k == at + 1


def criterion_iii(clc: str, mam: str) -> list[dict]:
    """Letters, other than a vowel letter or the word-final letter, with no vowel or sheva in
    CLC's form where MAM's strand has one."""
    cc, mc = clusters(clc), clusters(mam)
    if [a for a, _ in cc] != [a for a, _ in mc]:
        raise ValueError("letters differ")
    hits = []
    exempt = []
    for k, ((let, cm), (_, mm)) in enumerate(zip(cc, mc)):
        if not has_vowel(mm) or has_vowel(cm):
            continue
        if k == len(cc) - 1:
            exempt.append({"letter": k + 1, "why": "word-final letter"})
            continue
        if let == g.VAV and g.HOLAM in mm and not any(c in g.VOWELS for c in mm.replace(g.HOLAM, "")):
            exempt.append({"letter": k + 1, "why": "vowel letter (holam male)"})
            continue
        if let == g.HE and g.HOLAM in mm and tetragrammaton_he(mam, k):
            exempt.append(
                {
                    "letter": k + 1,
                    "why": "the Tetragrammaton's holam, which MAM writes and WLC 4.20 does not",
                }
            )
            continue
        hits.append({"letter": k + 1, "mam_marks": mm, "clc_marks": cm})
    return hits, exempt


def accents_of(form: str) -> list[str]:
    return [c for c in form if g.is_accent(c)]


def is_silluq(form: str) -> bool:
    return g.METEG in form and form.endswith(g.SOF)


def ends_chanted_word(form: str) -> bool:
    return not form.endswith(g.MAQAF)


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    atoms = g.load_atoms()
    mam_simple = g.mam_simple_verses()
    extra = g.extra_atoms(mam_simple)
    checks = {}

    # Check: the JSON's MAM forms are MAM-simple's strands, atom for atom.
    by_vid: dict[str, list[dict]] = {}
    for a in atoms + extra:
        by_vid.setdefault(a["vid"], []).append(a)
    bad = 0
    for vid in g.VIDS24:
        for s in g.STRANDS:
            if [x["form"] for x in mam_simple[vid][s]] != [a[s]["mam"] for a in by_vid[vid]]:
                bad += 1
    checks["verse-strands whose JSON MAM forms differ from MAM-simple's"] = bad
    paseq_kind = {}
    for vid in list(g.VIDS24) + list(g.EXTRA_VIDS):
        for s in g.STRANDS:
            for i, x in enumerate(mam_simple[vid][s], start=1):
                if x["mam_paseq_kind"]:
                    paseq_kind[(vid, i, s)] = x["mam_paseq_kind"]

    # Chanted verses and verdicts.
    cvs = []
    for book in ("Gen", "Exod", "Deut"):
        bb = g.BB[book]
        for s in g.STRANDS:
            for src in g.SOURCES:
                for cv in g.chanted_verses(by_vid, book, s, src):
                    if not any(a["in24"] for a in cv):
                        continue
                    _, ch, v = g.vid_parts(cv[0]["vid"])
                    forms = [a[s][src] for a in cv]
                    ver = g.verdict(forms, bb, ch, v)
                    cvs.append(
                        {
                            "book": book,
                            "strand": s,
                            "strand_name": g.STRAND_NAME[(book, s)],
                            "source": src,
                            "label": g.cv_label(cv),
                            "atoms": [[a["vid"], a["atom"]] for a in cv],
                            "forms": forms,
                            "verdict": ver,
                            "bb": bb,
                            "ch": ch,
                            "v": v,
                        }
                    )

    # Index MAM's and CLC's chanted verses by (strand, atom).
    where = {}
    for k, cv in enumerate(cvs):
        for j, (vid, n) in enumerate(cv["atoms"]):
            where[(cv["source"], cv["strand"], vid, n)] = (k, j)

    # Minimal fixes for the CLC chanted verses that are not clean.
    for cv in cvs:
        if cv["source"] != "clc":
            continue
        cv["fixes"] = {}
        if cv["verdict"]["status"] == "clean" and cv["verdict"]["grammar"] == "clean":
            continue
        s = cv["strand"]
        mam_forms = []
        for vid, n in cv["atoms"]:
            k, j = where[("mam", s, vid, n)]
            mam_forms.append(cvs[k]["forms"][j])
        bb, ch, v = cv["bb"], cv["ch"], cv["v"]
        for key, test in (
            ("status", lambda f: g.verdict(f, bb, ch, v)["status"] == "clean"),
            ("grammar", lambda f: g.verdict(f, bb, ch, v)["grammar"] == "clean"),
        ):
            if cv["verdict"][key] == "clean":
                continue
            kmin, sets, cand = g.search_minimal_fixes(cv["atoms"], s, cv["forms"], mam_forms, test)
            cv["fixes"][key] = {
                "k": kmin,
                "sets": [[cv["atoms"][i] for i in combo] for combo in sets],
                "candidates": [cv["atoms"][i] for i in cand],
            }

    # Per-atom token readings (the scanner's tokens attributed to each atom).
    def atom_tokens(src, s, vid, n):
        k, j = where[(src, s, vid, n)]
        return [t for t, _leaf, ai in cvs[k]["verdict"]["accent_tokens"] if ai == j]

    # The criteria.
    rows = []
    for a in atoms + extra:
        for s in g.STRANDS:
            for src in ("clc", "mam"):
                if (src, s, a["vid"], a["atom"]) not in where:
                    # A continuation-verse atom whose chanted verse holds none of the 24.
                    continue
                form = a[s][src]
                mam = a[s]["mam"]
                hits = []
                detail = {}
                # (i)
                if ends_chanted_word(form) and not accents_of(form) and not is_silluq(form):
                    hits.append("i")
                # (ii)
                toks = atom_tokens(src, s, a["vid"], a["atom"])
                mtoks = atom_tokens("mam", s, a["vid"], a["atom"])
                if len(toks) >= 2 and len(mtoks) == 1:
                    hits.append("ii")
                # (iii)
                h3, ex3 = criterion_iii(form, mam)
                if h3:
                    hits.append("iii")
                    detail["iii"] = h3
                if ex3:
                    detail["iii_exempt"] = ex3
                # (iv)
                k, j = where[(src, s, a["vid"], a["atom"])]
                cv = cvs[k]
                iv = None
                if src == "clc" and cv["verdict"]["status"] != "clean":
                    fx = cv["fixes"].get("status")
                    me = [a["vid"], a["atom"]]
                    in_sets = [st for st in fx["sets"] if me in st] if fx else []
                    if in_sets:
                        hits.append("iv")
                        iv = {
                            "chanted_verse": cv["label"],
                            "in_every_minimal_set": len(in_sets) == len(fx["sets"]),
                            "minimal_sets": fx["sets"],
                        }
                if iv:
                    detail["iv"] = iv
                noted = a[s]["noted"] if src == "clc" else []
                rows.append(
                    {
                        "vid": a["vid"],
                        "atom": a["atom"],
                        "in24": a["in24"],
                        "strand": s,
                        "strand_name": g.STRAND_NAME[(a["book"], s)],
                        "source": src,
                        "form": form,
                        "clc_rule_form": a[s]["clc_rule_form"] if src == "clc" else None,
                        "mam_form": mam,
                        "tokens": toks,
                        "mam_tokens": mtoks,
                        "tokens_differ_from_mam": toks != mtoks,
                        "criteria": hits,
                        "detail": detail,
                        "noted": [n["mark"] for n in noted],
                        "supplied": a[s]["supplied"] if src == "clc" else [],
                        "mam_paseq_kind": paseq_kind.get((a["vid"], a["atom"], s)),
                    }
                )

    # Check: accgram's legarmeh against MAM's own paseq/legarmeh tag, on MAM's strands.
    leg = []
    for r in rows:
        if r["source"] != "mam" or r["mam_paseq_kind"] is None:
            continue
        reads = "legarmeh" if "LEGARMEH" in r["tokens"] else "paseq"
        leg.append([r["vid"], r["atom"], r["strand"], r["mam_paseq_kind"], reads])
    checks["MAM paseq tags vs accgram (vid, atom, strand, MAM, accgram)"] = leg
    checks["MAM paseq tags accgram reads differently"] = sum(1 for x in leg if x[3] != x[4])

    # Check: WLC 4.20's tokens equal MAM's in the three continuation verses.
    ex_bad = [
        (r["vid"], r["atom"], r["strand"])
        for r in rows
        if not r["in24"] and r["source"] == "clc" and r["tokens_differ_from_mam"]
    ]
    checks["continuation-verse atoms where WLC 4.20's tokens differ from MAM's"] = ex_bad

    out = {"checks": checks, "chanted_verses": cvs, "rows": rows}
    path = g.W / "scratch-g" / "g_accgram.json"
    path.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8", newline="\n")

    # Summary.
    for k, v in checks.items():
        print("CHECK", k, v)
    for cv in cvs:
        ver = cv["verdict"]
        lex = [(x["code"], x["atoms"]) for x in ver["lexical"]]
        print(
            f"{cv['source']:3} {cv['strand']:4} {cv['label']:18} status={ver['status']:12} "
            f"grammar={ver['grammar']:6} lex={lex}"
        )
        for key, fx in cv.get("fixes", {}).items():
            print(f"      fix[{key}] k={fx['k']} sets={fx['sets']} cand={len(fx['candidates'])}")
    print("--- CLC hits")
    for r in rows:
        if r["source"] == "clc" and (r["criteria"] or r["noted"] or r["tokens_differ_from_mam"]):
            print(
                f"{r['vid']}:{r['atom']} {r['strand']} {r['form']} crit={r['criteria']} "
                f"noted={r['noted']} toks={r['tokens']} mam={r['mam_tokens']}"
            )
    print("--- MAM hits (control)")
    for r in rows:
        if r["source"] == "mam" and r["criteria"]:
            print(f"{r['vid']}:{r['atom']} {r['strand']} {r['form']} crit={r['criteria']}")
    print("wrote", path)


main()

"""Sub-agent V: the point under the het of the hishtaphel of the root het-vav-he (the letters
shin, tav, het, vav after any prefix), in WLC 4.20, morphhb and MAM; and, across the whole
corpus, every het whose point differs between WLC 4.20 and morphhb.

Throwaway scratch for the morphhb strands pull request (prepared, not posted).  Written by Claude
(Opus 5.5, sub-agent V), 2026-11-15.  Run from C:/Users/BenDe/GitRepos/MAM-basics in PowerShell 7:

    ./.venv/Scripts/python.exe -B .novc/morphhb-strands-pr-versions-2026-11-15/scripts/v_census.py

Writes only .novc/morphhb-strands-pr-versions-2026-11-15/out/52-sheva-census.json, and prints a
summary.  Imports MAM-basics modules from py/ and folder D's readers (scripts/mhb_common.py);
-B keeps Python from writing bytecode anywhere.

Sources:
- WLC 4.20: MAM-basics' out/wlc420-u, read by folder D's read_wlc42x (ketiv "*", qere "**").
- morphhb: wlc/<Book>.xml at d4265dfa, folder F's fetched/morphhb-wlc-<Book>/, read by folder
  D's closed-dispatch read_morphhb_book.  out/52-books.json (scripts/v_books.py) shows these
  files are the wlc/ files of master db6c5c9b.
- MAM: MAM-simple, BHS versification with the incremental-folder fallback, read by
  py/tests/test_israel_bible_review_mam_forms.py's own _verse and _verse_text, on the ketiv and
  the qere side; a dual cantillation read in cant-combined, cant-alef and cant-bet.

Method.  An atom is split into letters, each with its marks; "/" (morphhb's morpheme divider),
maqaf, paseq, sof pasuq and spaces are dropped; any other character raises.  The point under a
het is the set of vowel points among its marks (sheva, the hatafs, the full vowels); "none"
when it has none.
1. The verb: every WLC 4.20 atom whose letters contain shin, tav, het, vav.  Its het is the
   third of those letters.
2. In each verse, WLC 4.20's atoms are aligned with morphhb's by letters (difflib on each atom's
   letters): morphhb's sequence is its w's in document order, a variant note's qere words in
   their place after the ketiv, an alternative note's reading attached to its w.  WLC 4.20's
   ketiv-side and qere-side atoms are aligned alike with MAM's two sides.
3. The corpus: in every pair of aligned atoms with equal letters, the point under each het of
   WLC 4.20's atom is compared with morphhb's main text's, and with the alternative note's
   reading where there is one.
4. A check of the verb's lemma: morphhb's w's whose lemma has 7812, against the letters.
"""

import sys

sys.dont_write_bytecode = True

import difflib  # noqa: E402
import importlib.util  # noqa: E402
import json  # noqa: E402
import time  # noqa: E402
import unicodedata  # noqa: E402
from collections import Counter  # noqa: E402
from pathlib import Path  # noqa: E402

MB = Path("C:/Users/BenDe/GitRepos/MAM-basics")
W = MB / ".novc" / "morphhb-strands-pr-versions-2026-11-15"
F_FETCHED = MB / ".novc" / "morphhb-corrections-2026-11-13" / "fetched"
D_SCRIPTS = MB / ".novc" / "morphhb-decalogue-2026-11-13" / "scripts"
LINT_PATH = MB / "py" / "tests" / "test_israel_bible_review_mam_forms.py"
OUT_JSON = W / "out" / "52-sheva-census.json"
if Path(__file__).resolve().parent != (W / "scripts").resolve():
    raise RuntimeError("run this script only from its own folder's scripts/")

sys.path.insert(0, str(MB / "py"))
sys.path.insert(0, str(D_SCRIPTS))

import mhb_common as C  # noqa: E402
from mb_cmn.uni_denorm import give_std_mark_order  # noqa: E402

ALEF = "\N{HEBREW LETTER ALEF}"
TAV = "\N{HEBREW LETTER TAV}"
SHIN = "\N{HEBREW LETTER SHIN}"
HET = "\N{HEBREW LETTER HET}"
VAV = "\N{HEBREW LETTER VAV}"
STEM = SHIN + TAV + HET + VAV
MAQAF = "\N{HEBREW PUNCTUATION MAQAF}"
PASEQ = "\N{HEBREW PUNCTUATION PASEQ}"
SOF = "\N{HEBREW PUNCTUATION SOF PASUQ}"
NUN_HAFUKHA = "\N{HEBREW PUNCTUATION NUN HAFUKHA}"
ZWJ = "\N{ZERO WIDTH JOINER}"
ZWNJ = "\N{ZERO WIDTH NON-JOINER}"
DROPPED = {MAQAF, PASEQ, SOF, NUN_HAFUKHA, " ", "/"}

VOWELS = {
    "\N{HEBREW POINT SHEVA}": "sheva",
    "\N{HEBREW POINT HATAF SEGOL}": "hataf segol",
    "\N{HEBREW POINT HATAF PATAH}": "hataf patah",
    "\N{HEBREW POINT HATAF QAMATS}": "hataf qamats",
    "\N{HEBREW POINT HIRIQ}": "hiriq",
    "\N{HEBREW POINT TSERE}": "tsere",
    "\N{HEBREW POINT SEGOL}": "segol",
    "\N{HEBREW POINT PATAH}": "patah",
    "\N{HEBREW POINT QAMATS}": "qamats",
    "\N{HEBREW POINT HOLAM}": "holam",
    "\N{HEBREW POINT HOLAM HASER FOR VAV}": "holam haser for vav",
    "\N{HEBREW POINT QUBUTS}": "qubuts",
    "\N{HEBREW POINT QAMATS QATAN}": "qamats qatan",
}


def cname(ch):
    return unicodedata.name(ch, "U+%04X" % ord(ch))


def clusters(text, where):
    """[[letter, [marks]]] of a form; DROPPED characters are skipped, any other raises."""
    out = []
    after_drop = False
    for ch in text:
        if ALEF <= ch <= TAV:
            out.append([ch, []])
            after_drop = False
        elif unicodedata.category(ch) == "Mn" or ch in (ZWJ, ZWNJ):
            if not out or after_drop:
                raise ValueError(f"{where}: a mark with no letter before it in {text!r}")
            out[-1][1].append(ch)
        elif ch in DROPPED:
            after_drop = True
        else:
            raise ValueError(f"{where}: unexpected {cname(ch)} in {text!r}")
    return out


def letters(text, where):
    return "".join(lt for lt, _ in clusters(text, where))


def point(marks):
    names = [VOWELS[m] for m in marks if m in VOWELS]
    return "+".join(names) if names else "none"


def het_points(text, where):
    """The point under each het of a form, as [(letter index, point)]."""
    return [(k, point(ms)) for k, (lt, ms) in enumerate(clusters(text, where)) if lt == HET]


def stem_hets(text, where):
    """The letter index of the het of each occurrence of the stem in a form."""
    lts = letters(text, where)
    out, start = [], 0
    while True:
        k = lts.find(STEM, start)
        if k < 0:
            return out
        out.append(k + 2)
        start = k + 1


def point_at(text, k, where):
    return point(clusters(text, where)[k][1])


def ckey(text, where="ckey"):
    """A form's letters and marks, punctuation dropped, in MAM-normal mark order."""
    return give_std_mark_order("".join(lt + "".join(ms) for lt, ms in clusters(text, where)))


# ------------------------------------------------------------------ sources


def load_lint():
    spec = importlib.util.spec_from_file_location("ib_lint_v", LINT_PATH)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


CATCHWORD_MARK_MISMATCHES = []


def mhb_sequence(verse, osis_id):
    """morphhb's atoms of one verse in document order: main-text w's ("w", or "k" for a
    ketiv), each variant note's qere w's ("q") in their place; an alternative note's reading
    and every other note attached to the atom before it."""
    seq = []
    for t in verse["toks"]:
        if t["kind"] == "w":
            seq.append(
                {
                    "kind": "k" if t["type"] == "x-ketiv" else "w",
                    "raw": t["text"],
                    "text": t["text"].replace("/", ""),
                    "maqaf_after": t["maqaf_after"],
                    "lemma": t["lemma"],
                    "morph": t["morph"],
                    "id": t["id"],
                    "alt": None,
                    "notes": [],
                }
            )
        elif t["kind"] == "seg":
            continue
        elif t["kind"] == "note":
            nt = t["type"]
            if nt == "variant":
                for q in t["qere"]:
                    seq.append(
                        {
                            "kind": "q",
                            "raw": q["text"],
                            "text": q["text"].replace("/", ""),
                            "maqaf_after": q["maqaf_after"],
                            "lemma": q["lemma"],
                            "morph": q["morph"],
                            "id": q["id"],
                            "alt": None,
                            "notes": [],
                        }
                    )
            elif nt == "alternative":
                # The catchWord is the last n atoms of the main text (n > 1 where it spans
                # several w's); the reading has as many atoms, letter for letter.
                catch = C.form_atoms(t["catchWord"])
                rdg = C.form_atoms(t["accent"])
                n = len(catch)
                span = seq[-n:]
                if len(span) != n or any(a["kind"] != "w" or a["alt"] is not None for a in span):
                    raise ValueError(f"{osis_id}: an alternative note not after {n} plain w's")
                for a, c, r in zip(span, catch, rdg):
                    if letters(c, osis_id) != letters(a["text"], osis_id):
                        raise ValueError(f"{osis_id}: catchWord atom {c!r} is not its w")
                    if ckey(c.replace("/", ""), osis_id) != ckey(a["text"], osis_id):
                        CATCHWORD_MARK_MISMATCHES.append(f"{osis_id}: {c} | {a['raw']}")
                    if letters(r, osis_id) != letters(c, osis_id):
                        raise ValueError(f"{osis_id}: reading atom {r!r} has other letters")
                if len(rdg) != n:
                    raise ValueError(f"{osis_id}: reading {t['accent']!r} has {len(rdg)} atoms")
                for a, r in zip(span, rdg):
                    a["alt"] = r.replace("/", "")
                    a["alt_raw"] = r
                    a["alt_span"] = n
            elif nt in (None, "exegesis"):
                if not seq:
                    # A note before the verse's first w, such as a versification note.
                    if nt is not None or t["n"] is not None:
                        raise ValueError(f"{osis_id}: a typed or numbered note before any w")
                    continue
                seq[-1]["notes"].append({"n": t["n"], "type": nt, "text": t["text"]})
            else:
                raise ValueError(f"{osis_id}: note type {nt!r}")
        else:
            raise ValueError(f"{osis_id}: tok kind {t['kind']!r}")
    return seq


def mhb_display(a):
    return a["text"] + (MAQAF if a["maqaf_after"] else "")


def align(a_letters, b_letters):
    """{index in a: index in b} for atoms in difflib's equal blocks, and the non-equal blocks."""
    sm = difflib.SequenceMatcher(None, a_letters, b_letters, autojunk=False)
    pairs, other = {}, []
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            for d in range(i2 - i1):
                pairs[i1 + d] = j1 + d
        else:
            other.append((tag, i1, i2, j1, j2))
    return pairs, other


def block_of(i, other):
    for tag, i1, i2, j1, j2 in other:
        if i1 <= i < i2:
            return tag, j1, j2
    return None


# ------------------------------------------------------------------ main


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    t0 = time.time()
    lint = load_lint()
    short_of = {osis: short for short, osis in lint._OSIS.items()}
    wlc = C.read_wlc42x("4.20")
    books = [osis for osis, _tu, _mc in C.BOOKS]
    mhb = {}
    for osis in books:
        mhb.update(C.read_morphhb_book(C.morphhb_path(F_FETCHED, osis)))
    t_read = time.time() - t0

    wlc_keys = {f"{o}.{c}.{v}": (o, c, v) for (o, c, v) in wlc}
    only_wlc = sorted(k for k in wlc_keys if k not in mhb)
    only_mhb = sorted(k for k in mhb if k not in wlc_keys)

    het_pairs = Counter()
    het_pairs_alt = Counter()
    het_diffs = []
    unaligned = Counter()
    unaligned_blocks = []
    het_pairs_blocks = Counter()
    letters_differ_pairs = 0
    verb_rows = []
    lemma_rows = []
    mam_cache = {}

    for vid, (osis, ch, vs) in wlc_keys.items():
        where_w = f"WLC 4.20 {vid}"
        w_atoms = []
        for a in wlc[(osis, ch, vs)]:
            if a["spi"] is not None:
                continue
            # "kk", a ketiv placeholder (a qere with no ketiv), and "qq", a qere placeholder
            # (a ketiv with no qere), are left out, as folder D's p2_text_atoms leaves them.
            if a["text"] in ("kk", "qq"):
                if a["kq"] != a["text"][0] or a["notes"]:
                    raise ValueError(f"{where_w}: placeholder {a!r}")
                continue
            w_atoms.append(a)
        w_letters = [letters(a["text"], where_w) for a in w_atoms]
        seq = mhb_sequence(mhb[vid], vid) if vid in mhb else []
        where_m = f"morphhb {vid}"
        m_letters = [letters(a["text"], where_m) for a in seq]
        pairs, other = align(w_letters, m_letters)
        unaligned["WLC 4.20 atoms not in an equal block"] += len(w_atoms) - len(pairs)
        unaligned["morphhb atoms not in an equal block"] += len(seq) - len(pairs)
        for tag, i1, i2, j1, j2 in other:
            wf = [w_atoms[i]["text"] for i in range(i1, i2)]
            mf = [seq[j]["text"] for j in range(j1, j2)]
            # The block's hets compared as a whole where its letters agree (a word that
            # morphhb divides into two w's).
            wj, mj = "".join(wf), "".join(mf)
            block_points = None
            if letters(wj, where_w) == letters(mj, where_m):
                block_points = [
                    (pw, pm) for (_k, pw), (_k2, pm) in zip(het_points(wj, where_w), het_points(mj, where_m))
                ]
                for pw, pm in block_points:
                    het_pairs_blocks[(pw, pm)] += 1
            mf = [mhb_display(seq[j]) for j in range(j1, j2)]
            unaligned_blocks.append(
                {
                    "vid": vid,
                    "tag": tag,
                    "wlc420": wf,
                    "wlc420_kq": [w_atoms[i]["kq"] for i in range(i1, i2)],
                    "morphhb": mf,
                    "morphhb_kind": [seq[j]["kind"] for j in range(j1, j2)],
                    "wlc420_hets": sum(len(het_points(x, where_w)) for x in wf),
                    "morphhb_hets": sum(len(het_points(x, where_m)) for x in mf),
                    "letters_agree_as_a_whole": block_points is not None,
                    "het_points_as_a_whole": block_points,
                }
            )
        # 3. The corpus: every het of every aligned pair.
        for i, j in pairs.items():
            wa, ma = w_atoms[i], seq[j]
            wp = het_points(wa["text"], where_w)
            mp = het_points(ma["text"], where_m)
            if [k for k, _ in wp] != [k for k, _ in mp]:
                letters_differ_pairs += 1
                continue
            for (k, p_w), (_k, p_m) in zip(wp, mp):
                het_pairs[(p_w, p_m)] += 1
                p_alt = None
                if ma["alt"] is not None:
                    ap = dict(het_points(ma["alt"], where_m + " alternative"))
                    p_alt = ap[k]
                    het_pairs_alt[(p_w, p_alt)] += 1
                if p_w != p_m or (p_alt is not None and p_alt != p_w):
                    het_diffs.append(
                        {
                            "vid": vid,
                            "wlc_atom": i + 1,
                            "wlc_kq": wa["kq"],
                            "letter": k + 1,
                            "wlc420": wa["text"],
                            "wlc420_point": p_w,
                            "wlc420_notes": wa["notes"],
                            "morphhb_kind": ma["kind"],
                            "morphhb": mhb_display(ma),
                            "morphhb_point": p_m,
                            "morphhb_alt": ma["alt"],
                            "morphhb_alt_point": p_alt,
                            "morphhb_id": ma["id"],
                            "morphhb_notes": ma["notes"],
                        }
                    )
        # 4. The lemma check.
        for j, ma in enumerate(seq):
            parts = [p.strip().split(" ")[0] for p in (ma["lemma"] or "").split("/")]
            has_lemma = "7812" in parts
            has_stem = STEM in m_letters[j]
            if has_lemma or has_stem:
                lemma_rows.append(
                    {
                        "vid": vid,
                        "kind": ma["kind"],
                        "morphhb": mhb_display(ma),
                        "lemma": ma["lemma"],
                        "morph": ma["morph"],
                        "id": ma["id"],
                        "lemma_7812": has_lemma,
                        "stem_letters": has_stem,
                    }
                )
        # 1 and 2. The verb.
        verb_idx = [i for i, lt in enumerate(w_letters) if STEM in lt]
        if not verb_idx:
            continue
        mam = None
        for i in verb_idx:
            wa = w_atoms[i]
            ks = stem_hets(wa["text"], where_w)
            if len(ks) != 1:
                raise ValueError(f"{where_w}: the stem {len(ks)} times in one atom")
            k = ks[0]
            row = {
                "vid": vid,
                "osis": osis,
                "chapter": ch,
                "verse": vs,
                "wlc_atom": i + 1,
                "qere_side_atom": None,
                "wlc_kq": wa["kq"],
                "wlc420": wa["text"],
                "wlc420_notes": wa["notes"],
                "het_letter": k + 1,
                "wlc420_point": point_at(wa["text"], k, where_w),
            }
            # numbering on the qere side (plain and qere atoms); a ketiv takes its qere's
            qside = [n for n, a in enumerate(w_atoms) if a["kq"] in (None, "q")]
            nxt = [n for n in qside if n >= i]
            row["qere_side_atom"] = (qside.index(nxt[0]) + 1) if nxt else None
            # morphhb
            if i in pairs:
                ma = seq[pairs[i]]
                row["morphhb"] = {
                    "aligned": "equal letters",
                    "kind": ma["kind"],
                    "form": mhb_display(ma),
                    "raw": ma["raw"],
                    "point": point_at(ma["text"], k, where_m),
                    "alt": ma["alt"],
                    "alt_point": None if ma["alt"] is None else point_at(ma["alt"], k, where_m),
                    "lemma": ma["lemma"],
                    "morph": ma["morph"],
                    "id": ma["id"],
                    "notes": ma["notes"],
                    "same_as_wlc420": ckey(ma["text"]) == ckey(wa["text"]),
                    "alt_same_as_wlc420": None if ma["alt"] is None else ckey(ma["alt"]) == ckey(wa["text"]),
                }
            else:
                blk = block_of(i, other)
                cands = []
                if blk is not None:
                    _tag, j1, j2 = blk
                    cands = [mhb_display(seq[j]) for j in range(j1, j2) if STEM in m_letters[j]]
                row["morphhb"] = {"aligned": "not aligned", "candidates": cands}
            # MAM
            if mam is None:
                mam = mam_sides(lint, short_of, osis, ch, vs, mam_cache)
            row["mam"] = mam_row(mam, w_atoms, w_letters, i, k)
            verb_rows.append(row)

    t_all = time.time() - t0
    stem_mhb = [r for r in lemma_rows if r["stem_letters"]]
    summary = {
        "seconds_reading": round(t_read, 1),
        "seconds_total": round(t_all, 1),
        "wlc420_verses": len(wlc_keys),
        "morphhb_verses": len(mhb),
        "verses_only_in_wlc420": only_wlc,
        "verses_only_in_morphhb": only_mhb,
        "unaligned": dict(unaligned),
        "unaligned_blocks": len(unaligned_blocks),
        "unaligned_blocks_wlc420_hets": sum(b["wlc420_hets"] for b in unaligned_blocks),
        "unaligned_blocks_morphhb_hets": sum(b["morphhb_hets"] for b in unaligned_blocks),
        "unaligned_blocks_letters_agree_as_a_whole": sum(
            1 for b in unaligned_blocks if b["letters_agree_as_a_whole"]
        ),
        "unaligned_blocks_het_pairs": {f"{a} | {b}": n for (a, b), n in sorted(het_pairs_blocks.items())},
        "catchword_marks_differ_from_main_text": CATCHWORD_MARK_MISMATCHES,
        "aligned_pairs_with_het_positions_differing": letters_differ_pairs,
        "het_points_compared_main_text": sum(het_pairs.values()),
        "het_points_compared_alternative_notes": sum(het_pairs_alt.values()),
        "het_pairs_main_text_differing": {
            f"{a} | {b}": n for (a, b), n in sorted(het_pairs.items()) if a != b
        },
        "het_pairs_alternative_notes": {
            f"{a} | {b}": n for (a, b), n in sorted(het_pairs_alt.items())
        },
        "wlc420_sheva_het_total": sum(n for (a, _b), n in het_pairs.items() if a == "sheva"),
        "wlc420_sheva_morphhb_hataf_patah_main": het_pairs[("sheva", "hataf patah")],
        "wlc420_sheva_morphhb_hataf_patah_alt": het_pairs_alt[("sheva", "hataf patah")],
        "verb_atoms_wlc420": len(verb_rows),
        "verb_atoms_wlc420_by_point": dict(Counter(r["wlc420_point"] for r in verb_rows)),
        "verb_atoms_wlc420_by_kq": dict(Counter(str(r["wlc_kq"]) for r in verb_rows)),
        "verb_atoms_morphhb_stem_letters": len(stem_mhb),
        "verb_atoms_morphhb_by_kind": dict(Counter(r["kind"] for r in stem_mhb)),
        "lemma_7812_without_stem": [
            f"{r['vid']} {r['morphhb']} {r['lemma']} {r['morph']}"
            for r in lemma_rows
            if r["lemma_7812"] and not r["stem_letters"]
        ],
        "stem_without_lemma_7812": [
            f"{r['vid']} {r['morphhb']} {r['lemma']} {r['morph']}"
            for r in lemma_rows
            if r["stem_letters"] and not r["lemma_7812"]
        ],
        "verb_rows_morphhb_not_aligned": [
            r["vid"] for r in verb_rows if r["morphhb"]["aligned"] != "equal letters"
        ],
        "verb_rows_mam_not_aligned": [
            r["vid"] for r in verb_rows if r["mam"]["aligned"] != "equal letters"
        ],
        "verb_rows_points": dict(
            Counter(
                (
                    r["wlc420_point"],
                    r["morphhb"].get("point", "-"),
                    r["mam"].get("point", "-"),
                ).__str__()
                for r in verb_rows
            )
        ),
        "verb_rows_wlc420_sheva": [
            {
                "vid": r["vid"],
                "atom": r["qere_side_atom"],
                "morphhb_point": r["morphhb"].get("point"),
                "morphhb_alt_point": r["morphhb"].get("alt_point"),
                "mam_point": r["mam"].get("point"),
            }
            for r in verb_rows
            if r["wlc420_point"] == "sheva"
        ],
    }
    OUT_JSON.write_text(
        json.dumps(
            {
                "summary": summary,
                "verb_rows": verb_rows,
                "lemma_rows": lemma_rows,
                "het_diffs": het_diffs,
                "unaligned_blocks": unaligned_blocks,
                "het_pairs_main_text": {f"{a} | {b}": n for (a, b), n in sorted(het_pairs.items())},
            },
            ensure_ascii=False,
            indent=1,
        )
        + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(json.dumps(summary, ensure_ascii=True, indent=1))


def mam_sides(lint, short_of, osis, ch, vs, cache):
    """MAM's atoms on each side, in cant-combined, cant-alef and cant-bet, or None if MAM-simple
    has no such verse in the BHS versification (with its fallback)."""
    try:
        node = lint._verse(short_of[osis], ch, vs)
    except AssertionError:
        return None
    out = {}
    for side in ("ketiv", "qere"):
        for strand in ("cant-combined", "cant-alef", "cant-bet"):
            text = lint._verse_text(node, side, strand, f"MAM {osis} {ch}:{vs}")
            atoms = [a for a in C.form_atoms(text) if letters(a, f"MAM {osis} {ch}:{vs}")]
            out[(side, strand)] = atoms
    return out


def mam_row(mam, w_atoms, w_letters, i, k):
    if mam is None:
        return {"aligned": "no such verse in MAM-simple"}
    wa = w_atoms[i]
    side = "ketiv" if wa["kq"] == "k" else "qere"
    keep = (None, "k") if side == "ketiv" else (None, "q")
    idx = [n for n, a in enumerate(w_atoms) if a["kq"] in keep]
    sub_letters = [w_letters[n] for n in idx]
    pos = idx.index(i)
    out = {"side": side}
    for strand in ("cant-combined", "cant-alef", "cant-bet"):
        atoms = mam[(side, strand)]
        m_letters = [letters(a, "MAM") for a in atoms]
        pairs, other = align(sub_letters, m_letters)
        if pos in pairs:
            form = atoms[pairs[pos]]
            out[strand] = {
                "form": form,
                "point": point_at(form, k, "MAM"),
                "same_as_wlc420": ckey(form) == ckey(wa["text"]),
            }
        else:
            blk = block_of(pos, other)
            cands = []
            if blk is not None:
                _tag, j1, j2 = blk
                cands = [atoms[j] for j in range(j1, j2) if STEM in m_letters[j]]
            if len(cands) == 1:
                # Letters differ: the only form of the verb in the unaligned block is MAM's.
                (form,) = cands
                (mk,) = stem_hets(form, "MAM")
                out[strand] = {
                    "form": form,
                    "point": point_at(form, mk, "MAM"),
                    "same_as_wlc420": False,
                    "letters_differ": True,
                }
            else:
                out[strand] = {"form": None, "candidates": cands}
    comb = out["cant-combined"]
    if not comb.get("form"):
        out["aligned"] = "not aligned"
    elif comb.get("letters_differ"):
        out["aligned"] = "letters differ"
    else:
        out["aligned"] = "equal letters"
    out["form"] = comb.get("form")
    out["point"] = comb.get("point", "-")
    out["strands_differ"] = len({out[s].get("form") for s in ("cant-combined", "cant-alef", "cant-bet")}) > 1
    out["strand_points"] = sorted({out[s].get("point", "-") for s in ("cant-combined", "cant-alef", "cant-bet")})
    return out


if __name__ == "__main__":
    main()

"""Sub-agent G: print the code points of morphhb's main-text <w> elements of chosen verses, and
accgram's verdict on morphhb's own main text of those verses (from W/scratch-g/g_ncodes.json).

Usage: g_peek_codepoints.py Exod.20.4 Deut.5.14 ...
"""

import json
import sys
import unicodedata

sys.dont_write_bytecode = True

import g_common as g  # noqa: E402


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    mh = g.morphhb_verses(sys.argv[1:])
    nc = json.loads((g.W / "scratch-g" / "g_ncodes.json").read_text(encoding="utf-8"))
    for vid in sys.argv[1:]:
        print("==", vid, {k: v for k, v in nc["morphhb_own_main_text"].get(vid, {}).items() if k in ("status", "grammar", "lexical")})
        own = nc["morphhb_own_main_text"].get(vid, {})
        for i, w in enumerate(mh[vid]):
            marks = [
                unicodedata.name(c).replace("HEBREW ACCENT ", "").replace("HEBREW POINT ", "").lower()
                for c in w["text"]
                if "\N{HEBREW ACCENT ETNAHTA}" <= c <= "\N{HEBREW POINT METEG}" and not ("\N{HEBREW POINT SHEVA}" <= c <= "\N{HEBREW POINT DAGESH OR MAPIQ}")
            ]
            toks = own.get("tokens", [None] * 99)[i]
            print(f"   {w['id']} n={w['n']} marks={marks} tokens={toks}")


main()

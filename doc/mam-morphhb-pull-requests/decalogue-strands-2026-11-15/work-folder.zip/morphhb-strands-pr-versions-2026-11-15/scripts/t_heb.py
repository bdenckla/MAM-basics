"""Sub-agent T: unpointed Hebrew labels used by the report, built from Unicode
names so that none is retyped; t_write_report asserts each one occurs in the
documentation it is used to point at."""

N = {
    "alef": "\N{HEBREW LETTER ALEF}",
    "bet": "\N{HEBREW LETTER BET}",
    "gimel": "\N{HEBREW LETTER GIMEL}",
    "dalet": "\N{HEBREW LETTER DALET}",
    "he": "\N{HEBREW LETTER HE}",
    "vav": "\N{HEBREW LETTER VAV}",
    "zayin": "\N{HEBREW LETTER ZAYIN}",
    "het": "\N{HEBREW LETTER HET}",
    "tet": "\N{HEBREW LETTER TET}",
    "yod": "\N{HEBREW LETTER YOD}",
    "kaf": "\N{HEBREW LETTER KAF}",
    "fkaf": "\N{HEBREW LETTER FINAL KAF}",
    "lamed": "\N{HEBREW LETTER LAMED}",
    "mem": "\N{HEBREW LETTER MEM}",
    "fmem": "\N{HEBREW LETTER FINAL MEM}",
    "nun": "\N{HEBREW LETTER NUN}",
    "fnun": "\N{HEBREW LETTER FINAL NUN}",
    "samekh": "\N{HEBREW LETTER SAMEKH}",
    "ayin": "\N{HEBREW LETTER AYIN}",
    "pe": "\N{HEBREW LETTER PE}",
    "fpe": "\N{HEBREW LETTER FINAL PE}",
    "tsadi": "\N{HEBREW LETTER TSADI}",
    "qof": "\N{HEBREW LETTER QOF}",
    "resh": "\N{HEBREW LETTER RESH}",
    "shin": "\N{HEBREW LETTER SHIN}",
    "tav": "\N{HEBREW LETTER TAV}",
}


def w(*names):
    return "".join(N[n] for n in names)


L = w("lamed")
A = w("alef")
SIG = {
    "L": L,
    "L1": L + "1",
    "LM": L + "-" + w("mem"),
    "L3": L + "3",
    "A": A,
    "A_PHOTO": A + "(" + w("tsadi", "yod", "lamed", "vav", "fmem") + ")",
    "A_PHOTO_HYPHEN": A + "-" + w("tsadi", "yod", "lamed", "vav", "fmem"),
    "B": w("bet"),
    "S": w("shin"),
    "S1": w("shin") + "1",
    "S2": w("shin") + "2",
    "Q3": w("qof") + "3",
    "V": w("vav"),
    "H": w("he"),
    "EVR8": w("pe", "tet", "resh", "bet", "vav", "resh", "gimel") + "-EVR-II-B-8",
    "MS": w("mem") + '"' + w("shin"),
    "MQ": w("mem") + '"' + w("qof"),
    "DFUSIM": w("dalet", "pe", "vav", "samekh", "yod", "fmem"),
    "BREUER": w("bet", "resh", "vav", "yod", "alef", "resh"),
    "DOTAN": w("dalet", "vav", "tav", "fnun"),
    "MECHON_MAMRE": w("mem", "kaf", "vav", "fnun") + " " + w("mem", "mem", "resh", "alef"),
    "SIMANIM": w("samekh", "yod", "mem", "nun", "yod", "fmem"),
    "KOREN": w("qof", "vav", "resh", "fnun"),
    "HAQLADA": w("he", "qof", "lamed", "dalet", "he"),
    "HAMAQLID": w("he", "mem", "qof", "lamed", "yod", "dalet"),
}
WORD = {
    "GAAYA": w("gimel", "ayin", "yod", "he"),
    "LO": w("lamed", "alef"),
    "TAASE": w("tav", "ayin", "shin", "he"),
    "LEKHA": w("lamed", "fkaf"),
    "TNAF": w("tav", "nun", "alef", "fpe"),
    "TGNV": w("tav", "gimel", "nun", "bet"),
    "TAAMA_QADMA": w("tet", "ayin", "mem", "alef") + " " + w("qof", "dalet", "mem", "alef"),
    "NUSACH": w("nun", "vav", "samekh", "het"),
    "SH_TMPL": w("shin"),
}

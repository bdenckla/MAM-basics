"""Core data for the morphhb strands pull request: atoms, spans and their versions.

Imported by this folder's scripts (run them with -B from the MAM-basics root). Reads:
- folder S's out/22-clc-answers.json (CLC's rules applied to WLC 4.20's text, and MAM's forms);
- the base files fetched/base-696e21ce/{Gen,Exod,Deut}.xml (Ben's fork, 696e21ce).

A span is one atom together with the punctuation that follows it before the next atom: a
maqaf, a paseq (or legarmeh), or a sof pasuq. A span is represented as (core, punct), where
core is the atom's text without morphhb's slashes and punct is "" or one of PUNCT_NAMES.
"""

import json
import re
import sys
from pathlib import Path

MB = Path("C:/Users/BenDe/GitRepos/MAM-basics")
sys.path.insert(0, str(MB / "py"))  # scratch script in an untracked folder: exempt
from mb_cmn.uni_denorm import give_std_mark_order  # noqa: E402

W = Path(__file__).resolve().parent.parent
S = MB / ".novc/morphhb-strands-pr-2026-11-14"

MAQAF = "\N{HEBREW PUNCTUATION MAQAF}"
PASEQ = "\N{HEBREW PUNCTUATION PASEQ}"
SOF_PASUQ = "\N{HEBREW PUNCTUATION SOF PASUQ}"
PUNCT_CHAR = {"maqaf": MAQAF, "paseq": PASEQ, "sof pasuq": SOF_PASUQ}
SEG_TYPE = {"maqaf": "x-maqqef", "paseq": "x-paseq", "sof pasuq": "x-sof-pasuq"}
SEG_PUNCT = {v: k for k, v in SEG_TYPE.items()}

VIDS = (
    ["Gen.35.22"]
    + [f"Exod.20.{v}" for v in (2, 3, 4, 5, 6, 8, 9, 10, 13, 14, 15)]
    + [f"Deut.5.{v}" for v in (6, 7, 8, 9, 10, 12, 13, 14, 15, 17, 18, 19)]
)
BOOKS = ("Gen", "Exod", "Deut")

LETTER = re.compile("[\u05d0-\u05ea]")
ACCENTS = set(chr(c) for c in range(0x0591, 0x05AF + 1))  # cantillation marks
METEG = "\N{HEBREW POINT METEG}"


def is_gen(vid):
    return vid.startswith("Gen.")


def main_strand(vid):
    """The strand key of the main text: the תחתון (alef) in the Decalogues, the מדרשית (bet)
    at Genesis 35:22 (Ben's decision 1A)."""
    return "bet" if is_gen(vid) else "alef"


def other_strand(vid):
    return "alef" if main_strand(vid) == "bet" else "bet"


def strand_name(vid, key):
    """Romanized strand name, for keys and attributes only."""
    if is_gen(vid):
        return {"alef": "peshutah", "bet": "midrashit"}[key]
    return {"alef": "taxton", "bet": "elyon"}[key]


def split_form(form):
    """A form from folder S's JSON -> (core, punct). Brackets mark supplied marks."""
    f = form.replace("[", "").replace("]", "")
    if f.endswith(MAQAF):
        return f[:-1], "maqaf"
    if f.endswith(SOF_PASUQ):
        return f[:-1], "sof pasuq"
    if f.endswith(PASEQ):
        return f[:-1].rstrip(" "), "paseq"
    if PASEQ in f or MAQAF in f or SOF_PASUQ in f:
        raise ValueError("punctuation inside a form: %r" % form)
    return f, ""


def std(s):
    return give_std_mark_order(s)


def span_key(span):
    core, punct = span
    return (std(core), punct)


def letters_marks(core):
    """core -> list of (letter, [marks]) in code-point order; raises on stray marks."""
    out = []
    for ch in core:
        if LETTER.match(ch):
            out.append([ch, []])
        else:
            if not out:
                raise ValueError("mark before any letter: %r" % core)
            out[-1][1].append(ch)
    return out


def accents_of(core):
    return [ch for ch in core if ch in ACCENTS]


def load_atoms():
    data = json.loads((S / "out/22-clc-answers.json").read_text(encoding="utf-8"))
    return data["atoms"]


def load_base(book):
    return (W / "fetched/base-696e21ce" / f"{book}.xml").read_text(encoding="utf-8")


def atoms_by_vid():
    out = {}
    for a in load_atoms():
        out.setdefault(a["vid"], []).append(a)
    return out

"""Sub-agent I (2026-11-15): spot checks of reports 50 and 52 against fetched files (read-only).

Throwaway scratch for the morphhb strands pull request (prepared, not posted), written by Claude.
Run with -I from the MAM-basics root (it reads fetched files as data and imports nothing from
them):

    ./.venv/Scripts/python.exe -I .novc/morphhb-strands-pr-versions-2026-11-15/scripts/i_spot_fetched.py

Writes scratch-i/56a-spot-fetched.json, which i_spot_report.py turns into out/56-spot-checks.md.

Report 50's claim checked: BibleOrgSys's OSISXMLBible.py (a9342af5) logs load error "2s4d" for
a note attribute it does not know, subType among them, and stops under strict checking (lines
958-968); every <note> goes through that function.

Report 52's claim checked: across the corpus, Exodus 20:5 is the only het whose point in
morphhb's wlc/ (folder F's copies at d4265dfa, the same wlc/ as master db6c5c9b) differs from
WLC 4.20's (MAM-basics' out/wlc420-u). Done independently of sub-agent V's alignment: per verse,
the sequence of the vowel points under each het, in WLC 4.20's words (a ketiv skipped, a qere
kept) and in morphhb's main text (a ketiv's <w> skipped, its qere's <w> kept); verses whose het
counts differ are counted and left out.
"""

import hashlib
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

MB = Path("C:/Users/BenDe/GitRepos/MAM-basics")
W = MB / ".novc/morphhb-strands-pr-versions-2026-11-15"
S = MB / ".novc/morphhb-strands-pr-2026-11-14"
F = MB / ".novc/morphhb-corrections-2026-11-13"
NS = "{http://www.bibletechnologies.net/2003/OSIS/namespace}"
HET = "\N{HEBREW LETTER HET}"
LETTER = re.compile("[\u05d0-\u05ea]")
# vowel points and sheva (U+05B0 to U+05BB) and qamats qatan
VOWELS = {chr(c) for c in range(0x05B0, 0x05BC)} | {"\N{HEBREW POINT QAMATS QATAN}"}


def blob_sha1(data):
    h = hashlib.sha1()
    h.update(b"blob %d\0" % len(data))
    h.update(data)
    return h.hexdigest()


def check_50():
    d = S / "fetched/r-bos-OSISXMLBible"
    raw = (d / "OSISXMLBible.py").read_bytes()
    meta = json.loads((d / "blob.json").read_text(encoding="utf-8"))
    sha_ok = blob_sha1(raw) == meta.get("sha")
    lines = raw.decode("utf-8").splitlines()
    block = lines[957:968]  # lines 958-968 as the Read tool numbers them
    allowed = re.findall(r"attrib=='(\w+)'", "\n".join(block))
    text = "\n".join(block)
    func_line = next(
        i
        for i, ln in enumerate(lines, 1)
        if "def validateCrossReferenceOrFootnote" in ln
    )

    def enclosing(i):
        for j in range(i - 1, -1, -1):
            m = re.match(r"\s*def (\w+)", lines[j])
            if m:
                return m.group(1)
        return None

    # live (not commented-out) branches on a <note> element, with their enclosing function and
    # whether the call follows within four lines
    note_branches = []
    for i, ln in enumerate(lines, 1):
        if re.search(r"OSISNameSpace\+'note'", ln) and not ln.lstrip().startswith("#"):
            follows = any(
                "validateCrossReferenceOrFootnote(" in x
                and not x.lstrip().startswith("#")
                for x in lines[i : i + 4]
            )
            note_branches.append(
                {"line": i, "in": enclosing(i - 1), "calls it": follows}
            )
    calls_after = [b for b in note_branches if b["calls it"]]
    result = {
        "file": str(d / "OSISXMLBible.py"),
        "blob sha matches blob.json": sha_ok,
        "blob sha": blob_sha1(raw),
        "function starts at line": func_line,
        "attributes accepted in lines 958-968": allowed,
        "subType accepted": "subType" in allowed,
        "2s4d warning and load error in the else branch": text.count("2s4d") == 2
        and "loadErrors.append" in text,
        "assert under strictCheckingFlag": "strictCheckingFlag" in text
        and "assert False" in text,
        "live note branches": note_branches,
        "of them calling it": len(calls_after),
        "the others": [b for b in note_branches if not b["calls it"]],
    }
    # the claim holds if the function refuses subType as stated and every live branch on a
    # <note> outside the function itself (whose own branch handles a note inside a note) calls it
    outside = [
        b for b in note_branches if b["in"] != "validateCrossReferenceOrFootnote"
    ]
    result["holds"] = (
        sha_ok
        and not result["subType accepted"]
        and result["2s4d warning and load error in the else branch"]
        and result["assert under strictCheckingFlag"]
        and all(b["calls it"] for b in outside)
    )
    return result


def het_points(text):
    """The vowel points under each het of a text, as sorted strings, in order."""
    out, cur = [], None
    for ch in text:
        if LETTER.match(ch):
            if cur is not None:
                out.append("".join(sorted(cur)))
            cur = [] if ch == HET else None
        elif cur is not None and ch in VOWELS:
            cur.append(ch)
    if cur is not None:
        out.append("".join(sorted(cur)))
    return out


def wlc_verses():
    """(book code, chapter, verse) -> het points of WLC 4.20's verse; and each book's 1:1 letters."""
    out, first = {}, {}
    for path in sorted((MB / "out/wlc420-u").glob("1verses_*.json")):
        for verse in json.loads(path.read_text(encoding="utf-8")):
            m = re.fullmatch(r"([a-z0-9]{2})(\d+):(\d+)", verse["bcv"])
            key = (m.group(1), int(m.group(2)), int(m.group(3)))
            words = []
            for vel in verse["vels"]:
                word = vel if isinstance(vel, str) else vel.get("word")
                if word is None:
                    continue
                if word.startswith("**"):
                    word = word[2:]
                elif word.startswith("*"):
                    continue  # a ketiv
                words.append(word)
            text = " ".join(words)
            out[key] = het_points(text)
            if key[1:] == (1, 1):
                first[key[0]] = "".join(LETTER.findall(text))
    return out, first


def morphhb_verses():
    """(book, chapter, verse) -> het points of morphhb's main text; and each book's 1:1 letters."""
    out, first = {}, {}
    ketiv_hets = 0
    for d in sorted(F.glob("fetched/morphhb-wlc-*")):
        book = d.name[len("morphhb-wlc-") :]
        p = d / f"{book}.xml"
        if not p.exists():
            continue
        root = ET.parse(p).getroot()
        for v in root.iter(NS + "verse"):
            b, c, n = v.get("osisID").split(".")
            parts = []
            for el in v:
                tag = el.tag.replace(NS, "")
                if tag == "w" and el.get("type") == "x-ketiv":
                    ketiv_hets += (el.text or "").count(HET)
                elif tag == "w":
                    parts.append(el.text or "")
                elif tag == "note" and el.get("type") == "variant":
                    parts += [w.text or "" for w in el.iter(NS + "w")]
            text = " ".join(parts).replace("/", "")
            key = (b, int(c), int(n))
            out[key] = het_points(text)
            if key[1:] == (1, 1):
                first[b] = "".join(LETTER.findall(text))
    return out, first, ketiv_hets


def check_52():
    wlc, wfirst = wlc_verses()
    mhb, mfirst, ketiv_hets = morphhb_verses()
    code_of = {}
    for book, letters in mfirst.items():
        hits = [c for c, l in wfirst.items() if l == letters]
        if len(hits) != 1:
            raise ValueError(f"{book}: {len(hits)} WLC books match its first verse")
        code_of[book] = hits[0]
    compared = skipped = 0
    sheva = "\N{HEBREW POINT SHEVA}"
    with_sheva = 0
    differ = []
    skipped_vids = []
    for (b, c, v), pts in sorted(mhb.items()):
        w = wlc.get((code_of[b], c, v))
        if w is None:
            skipped += 1
            skipped_vids.append(f"{b}.{c}.{v} (not in WLC 4.20's numbering)")
            continue
        if len(w) != len(pts):
            skipped += 1
            skipped_vids.append(
                f"{b}.{c}.{v} ({len(w)} hets in WLC 4.20, {len(pts)} in morphhb)"
            )
            continue
        for k, (x, y) in enumerate(zip(w, pts), start=1):
            compared += 1
            with_sheva += x == sheva
            if x != y:
                differ.append(
                    {
                        "vid": f"{b}.{c}.{v}",
                        "het": k,
                        "wlc420": [hex(ord(ch)) for ch in x],
                        "morphhb": [hex(ord(ch)) for ch in y],
                    }
                )
    exod = [d for d in differ if d["vid"] == "Exod.20.5"]
    return {
        "books": len(code_of),
        "verses in morphhb": len(mhb),
        "hets compared": compared,
        "hets in morphhb's ketiv <w>, not compared": ketiv_hets,
        "of them with a sheva in WLC 4.20": with_sheva,
        "verses left out": skipped,
        "verses left out (first 12)": skipped_vids[:12],
        "hets whose point differs": differ,
        "holds": len(differ) == 1 and len(exod) == 1,
    }


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    out = {"50": check_50(), "52": check_52()}
    p = W / "scratch-i/56a-spot-fetched.json"
    p.write_text(
        json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8", newline="\n"
    )
    for k, v in out.items():
        print(k, json.dumps(v, ensure_ascii=True)[:1500])
    print("wrote", p)


main()

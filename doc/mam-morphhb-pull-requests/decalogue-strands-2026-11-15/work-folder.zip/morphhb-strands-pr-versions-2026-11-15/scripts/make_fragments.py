"""Write the decision page's fragments, out/fragments/*.html, copying every pointed form from data.

Run with -B from the MAM-basics root:  make_fragments.py "<HH:MM>" "<state html>"

Sources: versions.compute() (folder S's CLC answers and MAM forms), the base files, the built
files of out/build-A (with check.txt and keys.txt), the brief for Ben's words, and the research
outputs: out/53-accgram.json (G), out/52-mam-het.json and 52-versions.json (V),
scratch-t/doc_notes.json (T's extraction of MAM's notes), out/54-for-build.json,
out/55-final-accgram.json, out/57-n-changes.json, out/58-facts.json, out/70-description.md and
out/71-commit-message.txt. Hand-written prose without pointed Hebrew is read from
scripts/prose/<NAME>.html for the names in PROSE_NAMES (a missing file, or a Hebrew point,
accent or punctuation mark in one, stops the script). In generated HTML, a run of Hebrew with a
point or accent is set in Taamey D (lang="hbo"); a run without one is isolated in a <bdi> with
no lang, except in a cell that is itself dir="rtl".
"""

import html
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))  # untracked scratch: exempt
import strands_core as sc  # noqa: E402
import versions as vs  # noqa: E402

FR = sc.W / "out/fragments"
BRIEF = Path(
    "C:/Users/BenDe/AppData/Local/Claude-Data/claude_pzs8sxrjxfjjc/side-session-notes/"
    "local_a80ded65-f78e-4280-8493-9dab3b8c5686/morphhb-strands-pr-versions-brief-2026-11-15.md"
)
BOOK = {"Gen": "Genesis", "Exod": "Exodus", "Deut": "Deuteronomy", "Ezek": "Ezekiel"}
NAME = {
    False: {"alef": "תחתון", "bet": "עליון"},
    True: {"alef": "פשוטה", "bet": "מדרשית"},
}
KIND_NAME = {
    "main": "main text: CLC's {m}",
    "clc_other": "CLC's {o}",
    "mam_main": "MAM-informed {m}",
    "mam_other": "MAM-informed {o}",
}
CRIT = {
    "i": "no accent",
    "ii": "two accents where MAM's strand has one",
    "iii": "a letter without the vowel that MAM's strand has there",
    "iv": "the strand's chanted verse is ungrammatical",
}
# A run of Hebrew: a letter, then letters, marks (points, accents, maqaf, paseq, sof pasuq)
# and morphhb's slashes.
HEB_RUN = re.compile(
    "[\N{HEBREW LETTER ALEF}-\N{HEBREW LETTER TAV}]"
    "[\N{HEBREW ACCENT ETNAHTA}-\N{HEBREW POINT QAMATS QATAN}\N{HEBREW LETTER ALEF}-\N{HEBREW LETTER TAV}/]*"
)
# Marks that make a run pointed: every point and accent, not maqaf, paseq or sof pasuq.
NOT_POINTS = {
    "\N{HEBREW PUNCTUATION MAQAF}",
    "\N{HEBREW PUNCTUATION PASEQ}",
    "\N{HEBREW PUNCTUATION SOF PASUQ}",
    "\N{HEBREW PUNCTUATION NUN HAFUKHA}",
}
MARK_RANGE = re.compile("[\N{HEBREW ACCENT ETNAHTA}-\N{HEBREW POINT QAMATS QATAN}]")


def pointed(run):
    return any(MARK_RANGE.match(ch) and ch not in NOT_POINTS for ch in run)


def hebrew_html(escaped, cls="hbo-code", in_rtl_cell=False):
    """Wrap each Hebrew run of already-escaped text: a pointed run in Taamey D, an unpointed
    one in a <bdi> with no lang (left bare in a dir="rtl" cell, whose language it is).
    """

    def wrap(m):
        run = m.group(0)
        if pointed(run):
            return f'<span lang="hbo" class="{cls}">{run}</span>'
        return run if in_rtl_cell else f"<bdi>{run}</bdi>"

    return HEB_RUN.sub(wrap, escaped)


def bcv(vid, atom=None):
    b, c, v = vid.split(".")
    s = f"{BOOK[b]} {c}:{v}"
    return s + (f", atom {atom}" if atom else "")


def bdi(s):
    return f"<bdi>{html.escape(s)}</bdi>"


def display(span):
    core, punct = span
    if punct == "paseq":
        return core + " " + sc.PASEQ
    return core + (sc.PUNCT_CHAR[punct] if punct else "")


def clusters(form):
    """form -> list of (cluster text, letter index or None for punctuation/space)."""
    out = []
    for ch in form:
        if sc.LETTER.match(ch):
            out.append([ch, len([c for c in out if c[1] is not None])])
        elif (
            out
            and out[-1][1] is not None
            and ch not in (sc.PASEQ, sc.MAQAF, sc.SOF_PASUQ, " ")
        ):
            out[-1][0] += ch
        else:
            out.append([ch, None])
    return out


def marks_key(cluster):
    return sc.std(cluster)


def highlighted(forms):
    """Pointed forms of one atom -> HTML spans, the letters whose marks differ marked."""
    cl = [clusters(f) for f in forms]
    letter_sets = []
    for c in cl:
        letter_sets.append({i: marks_key(t) for t, i in c if i is not None})
    n = max(len(s) for s in letter_sets)
    differ = {i for i in range(n) if len({s.get(i) for s in letter_sets}) > 1}
    puncts = [tuple(t for t, i in c if i is None and t.strip()) for c in cl]
    punct_differs = len(set(puncts)) > 1
    out = []
    for c in cl:
        parts = []
        for t, i in c:
            t2 = html.escape(t)
            mark = i in differ if i is not None else (punct_differs and bool(t.strip()))
            parts.append(f'<span class="mk">{t2}</span>' if mark else t2)
        out.append(f'<span lang="hbo" class="hbo">{"".join(parts)}</span>')
    return out


def table(head, rows):
    h = "".join(f"<th>{x}</th>" for x in head)
    return (
        f'<div class="tablewrap"><table><thead><tr>{h}</tr></thead><tbody>\n'
        + "\n".join(rows)
        + "\n</tbody></table></div>\n"
    )


def group_rows(vid, atom, labelled_forms, note):
    """labelled_forms: [(label html, form)] -> rows: Forms | Verse, atom | Version | note."""
    hs = highlighted([f for _, f in labelled_forms])
    rows = []
    k = len(labelled_forms)
    for j, ((label, _), h) in enumerate(zip(labelled_forms, hs)):
        cells = [f'<td dir="rtl">{h}</td>']
        if j == 0:
            cells.append(f'<td rowspan="{k}" class="bcv">{bcv(vid, atom)}</td>')
        cells.append(f"<td>{label}</td>")
        if j == 0:
            cells.append(f'<td rowspan="{k}">{note}</td>')
        rows.append("<tr>" + "".join(cells) + "</tr>")
    return rows


def base_readings():
    """w id -> {"main": text without slashes, "notes": [rdg texts]} from the base files."""
    out = {}
    for book in sc.BOOKS:
        text = sc.load_base(book)
        for m in re.finditer(
            r'(<w\b[^>]*id="([^"]+)"[^>]*>([^<]*)</w>)((?:<note type="alternative">.*?</note>)*)',
            text,
        ):
            rdgs = re.findall(r'<rdg type="x-accent">([^<]*)</rdg>', m.group(4))
            out[m.group(2)] = {
                "main": m.group(3).replace("/", ""),
                "notes": [r.replace("/", "") for r in rdgs],
            }
    return out


def version_label(vid, kind):
    g = sc.is_gen(vid)
    m, o = NAME[g][sc.main_strand(vid)], NAME[g][sc.other_strand(vid)]
    return html.escape(KIND_NAME[kind]).replace("{m}", bdi(m)).replace("{o}", bdi(o))


def frag_spans(recs):
    want = [("Exod.20.3", 1), ("Exod.20.3", 2), ("Exod.20.2", 9), ("Exod.20.10", 10)]
    rows = []
    for r in recs:
        if (r["vid"], r["atom"]) in want:
            lf = [
                (version_label(r["vid"], v["kind"]), display(v["span"]))
                for v in r["versions"]
            ]
            rows += group_rows(r["vid"], r["atom"], lf, "")
    rows = [re.sub(r'<td rowspan="\d+"></td>', "", x) for x in rows]
    return table(["Version", "Verse, atom", "Version of the span"], rows).replace(
        "<th>Version</th>", "<th>Forms</th>", 1
    )


def frag_illegal(recs):
    rows = []
    for r in recs:
        g = sc.is_gen(r["vid"])
        for s in ("alef", "bet"):
            if not r["failed"][s]:
                continue
            kind = "main" if s == r["main_strand"] else "clc_other"
            mi_kind = "mam_main" if s == r["main_strand"] else "mam_other"
            name = NAME[g][s]
            lf = [
                (
                    f"CLC's {bdi(name)}"
                    + (" (the main text)" if kind == "main" else ""),
                    display(r["clc"][s]),
                ),
                (
                    f"MAM-informed {bdi(name)}",
                    display(tuple(r["mam_informed"][s]["span"])),
                ),
                (f"MAM's {bdi(name)}", display(r["mam"][s])),
            ]
            why = "; ".join(CRIT[c] for c in r["failed"][s])
            noted = r["noted"][s]
            note = f"{bdi(name)}: {html.escape(why)}.<br>CLC notes: " + (
                html.escape(", ".join(noted)) if noted else "nothing"
            )
            rows += group_rows(r["vid"], r["atom"], lf, note)
    return table(
        ["Forms", "Verse, atom", "Version", "Why illegal; what CLC notes"], rows
    )


def frag_restored(recs, base):
    want = {("Exod.20.4", 10), ("Exod.20.4", 12), ("Exod.20.5", 2), ("Exod.20.8", 4)}
    atoms = {(a["vid"], a["atom"]): a for a in sc.load_atoms()}
    rows = []
    for r in recs:
        if (r["vid"], r["atom"]) not in want:
            continue
        a = atoms[(r["vid"], r["atom"])]
        b = base[r["w_id"]]
        lf = [
            ("WLC 4.20", sc.split_form(a["wlc420"])[0]),
            ("morphhb's main text now", b["main"]),
        ]
        lf += [("morphhb's note now", x) for x in b["notes"]]
        lf += [
            (version_label(r["vid"], v["kind"]), display(v["span"]))
            for v in r["versions"]
        ]
        rows += group_rows(r["vid"], r["atom"], lf, "")
    rows = [re.sub(r'<td rowspan="\d+"></td>', "", x) for x in rows]
    return table(["Forms", "Verse, atom", "Form of"], rows)


def frag_qadma(recs, base):
    atoms = {(a["vid"], a["atom"]): a for a in sc.load_atoms()}
    rows = []
    for r in recs:
        if (r["vid"], r["atom"]) not in {("Exod.20.10", 1), ("Deut.5.14", 1)}:
            continue
        a = atoms[(r["vid"], r["atom"])]
        lf = [
            ("WLC 4.20", sc.split_form(a["wlc420"])[0]),
            ("morphhb's main text now", base[r["w_id"]]["main"]),
            (
                f"CLC's {bdi('עליון')}, WLC 4.20's pashta code point (4B)",
                sc.split_form(a["bet"]["clc_rule_form"])[0],
            ),
            (
                f"CLC's {bdi('עליון')}, the qadma code point (4A)",
                display(r["clc"]["bet"]),
            ),
            (f"MAM's {bdi('עליון')}", display(r["mam"]["bet"])),
        ]
        rows += group_rows(r["vid"], r["atom"], lf, "")
    rows = [re.sub(r'<td rowspan="\d+"></td>', "", x) for x in rows]
    return table(["Forms", "Verse, atom", "Form of"], rows)


def frag_meteg(recs):
    atoms = {(a["vid"], a["atom"]): a for a in sc.load_atoms()}
    rows = []
    for key in (("Exod.20.4", 2), ("Deut.5.7", 2), ("Deut.5.8", 2)):
        r = [x for x in recs if (x["vid"], x["atom"]) == key][0]
        a = atoms[key]
        lf = [
            ("WLC 4.20", sc.split_form(a["wlc420"])[0]),
            (f"CLC's {bdi('עליון')} (in the pull request)", display(r["clc"]["bet"])),
            (f"MAM's {bdi('עליון')}", display(r["mam"]["bet"])),
        ]
        rows += group_rows(key[0], key[1], lf, "")
    rows = [re.sub(r'<td rowspan="\d+"></td>', "", x) for x in rows]
    return table(["Forms", "Verse, atom", "Form of"], rows)


def verse_xml(vid):
    book = vid.split(".")[0]
    text = (sc.W / "out/build-A" / f"{book}.xml").read_text(encoding="utf-8")
    m = re.search(r'<verse osisID="%s">.*?</verse>' % re.escape(vid), text, re.S)
    return m.group(0)


def frag_xml(book, vid):
    return f'<pre class="xml">{hebrew_html(html.escape(verse_xml(vid)))}</pre>\n'


def frag_change():
    """Each of the 24 verses' new XML, in its own <details>."""
    out = []
    for vid in sc.VIDS:
        out.append(
            f"<details><summary>{bcv(vid)}</summary>"
            f'<pre class="xml">{hebrew_html(html.escape(verse_xml(vid)))}</pre></details>'
        )
    return "\n".join(out) + "\n"


def frag_description():
    """The pull request's title, description and commit message, exactly as post_pr.py posts them."""
    desc = (sc.W / "out/70-description.md").read_text(encoding="utf-8")
    title_line, body = desc.split("\n", 1)
    title, body = title_line[len("Title: ") :], body.lstrip("\n")
    msg = (sc.W / "out/71-commit-message.txt").read_text(encoding="utf-8")
    parts = []
    for label, text in (
        ("Title", title),
        ("Description", body),
        ("Commit message", msg),
    ):
        parts.append(
            f'<p class="label">{label}</p>\n<pre class="prewrap">{hebrew_html(html.escape(text))}</pre>'
        )
    return "\n".join(parts) + "\n"


def frag_ben_words():
    text = BRIEF.read_text(encoding="utf-8")
    start = text.index("exactly:\n\n") + len("exactly:\n\n")
    end = text.index("\n\nClaude reads")
    paras = []
    for block in text[start:end].split("\n>\n"):
        lines = [
            ln[2:] if ln.startswith("> ") else ln.lstrip(">")
            for ln in block.splitlines()
        ]
        paras.append("<p>" + html.escape(" ".join(lines)) + "</p>")
    return "<blockquote>\n" + "\n".join(paras) + "\n</blockquote>\n"


def frag_counts(recs):
    log = json.loads((sc.W / "out/build-A/build-log.json").read_text(encoding="utf-8"))[
        "log"
    ]
    kinds = {}
    for e in log:
        if "note" in e:
            kinds[e["kind"]] = kinds.get(e["kind"], 0) + 1
    per_span = {}
    for r in recs:
        per_span[len(r["versions"])] = per_span.get(len(r["versions"]), 0) + 1
    rows = [
        f"<tr><td>Spans in the 24 verses</td><td class='num'>{len(recs)}</td></tr>",
        *[
            f"<tr><td>Spans with {k} version{'s' if k > 1 else ''}</td><td class='num'>{v}</td></tr>"
            for k, v in sorted(per_span.items())
        ],
        *[
            f"<tr><td>Notes for {version_label('Exod.20.2', k).replace('main text: ', '')} (Genesis 35:22's counterpart included)</td><td class='num'>{v}</td></tr>"
            for k, v in sorted(kinds.items())
        ],
        f"<tr><td>Main-text atoms whose text changes</td><td class='num'>{sum(1 for e in log if 'new_text' in e)}</td></tr>",
    ]
    return table(["What", "Count"], rows)


def frag_supplied(recs):
    items = []
    for r in recs:
        s = r["main_strand"]
        for mark in r["supplied"][s]:
            items.append((r["vid"], r["atom"], mark, display(r["clc"][s])))
    rows = []
    hs = [highlighted([f])[0] for *_, f in items]
    for (vid, atom, mark, _), h in zip(items, hs):
        rows.append(
            f'<tr><td dir="rtl">{h}</td><td class="bcv">{bcv(vid, atom)}</td><td>{html.escape(mark)}</td></tr>'
        )
    return table(["Main text", "Verse, atom", "Supplied by CLC's rules"], rows)


# Fragments whose research has reported, written by hand without pointed Hebrew in
# scripts/prose/<NAME>.html; each pointed table they need is a generated fragment of its own.
PROSE_NAMES = (
    "PENDING",
    "ACCGRAM",
    "READERS_LABELS",
    "READERS_SEVERAL",
    "READERS_PLACEMENT",
    "N_ILLEGAL",
    "N_CODES",
    "SHEVA",
    "METEG_DOC",
)


def prose(name):
    p = Path(__file__).resolve().parent / "prose" / f"{name}.html"
    text = p.read_text(encoding="utf-8")  # a missing file fails
    if MARK_RANGE.search(text):
        raise SystemExit(
            f"a Hebrew point, accent or punctuation mark typed into prose/{name}.html"
        )
    return text


def facts():
    return json.loads((sc.W / "out/58-facts.json").read_text(encoding="utf-8"))


def frag_checks():
    lines = (sc.W / "out/build-A/check.txt").read_text(encoding="utf-8").splitlines()
    items = "".join(f"<li><code>{html.escape(x)}</code></li>" for x in lines)
    f = facts()
    more = [
        f"<code>scripts/check_keys.py</code> replays the apps' accent naming over the 24 verses (<code>out/build-A/keys.txt</code>): "
        f"{f['key_misses_build']} atoms have no catalog entry, each an atom whose main text is not legal "
        f"({f['key_misses_build_at_legal']} at a legal one); the base has {f['key_misses_base']}.",
        f"<code>scripts/i_final_accgram.py</code> rebuilds both strands from the new XML alone, MAM-informed versions included, "
        f"and runs the accent grammar (<code>out/55-final-accgram.md</code>): {f['final_chanted_verses'] - f['final_chanted_verses_not_clean']} "
        f"of {f['final_chanted_verses']} chanted verses grammatical; the trees' codes equal the built <code>n</code> at "
        f"{f['final_n_agree']} of {f['final_n_atoms']} atoms; the strands' accents differ from MAM's at "
        f"{f['final_token_differences']} atoms.",
        f"<code>scripts/i_n_changes.py</code> lists the {f['n_changed_atoms']} atoms whose <code>n</code> changes "
        f"(<code>out/57-n-changes.txt</code>).",
        "Sub-agent I's spot checks of one claim from each research report, by scripts of its own "
        "(<code>out/56-spot-checks.md</code>): all four hold.",
    ]
    return (
        "<p>Checked by <code>scripts/check_build.py</code>, which rebuilds every version of every span from the new XML alone "
        "and compares it with the intended version in MAM-normal mark order, label by label; confirms that each file differs "
        "from its base only inside the 24 verses; applies the validator's rules to every <code>&lt;w&gt;</code>; confirms "
        "that no <code>&lt;w&gt;</code> changes its letters or any attribute but <code>n</code>; and confirms that every "
        "<code>n</code> is the one <code>out/54-for-build.json</code> gives. Its summary:</p>"
        f"<ul>{items}</ul>\n<p>And:</p><ul>{''.join(f'<li>{x}</li>' for x in more)}</ul>\n"
    )


def hbo(form):
    return f'<span lang="hbo" class="hbo">{html.escape(form)}</span>'


def popups():
    """w id -> the apps' lookup in the build where it misses ("error|key|..."), from keys.txt."""
    keys = (
        (sc.W / "out/build-A/keys.txt")
        .read_text(encoding="utf-8")
        .split("== build:")[1]
    )
    return {
        m.group(1): m.group(2)
        for m in re.finditer(
            r"^\s+\S+\s+(\w{5}) n=\S+ \w+ -> (error\|key\|\w+)", keys, re.M
        )
    }


def frag_n_illegal_table(recs):
    """Decision 11: the codes in the draft (11A) and under 11B, at the atoms whose main text is
    not legal and at those whose code 11B also changes."""
    new_n = json.loads((sc.W / "out/54-for-build.json").read_text(encoding="utf-8"))[
        "new_n"
    ]
    g = json.loads((sc.W / "out/53-accgram.json").read_text(encoding="utf-8"))["n"][
        "clc_main_strand"
    ]
    by = {(r["vid"], r["atom"]): r for r in recs}
    pop = popups()
    rows = []
    for x in g:
        if x["vid"] not in sc.VIDS:
            continue
        r = by[(x["vid"], x["atom"])]
        code_b = x["tree_code"] if x["grammar"] == "clean" else x["level_code"]
        code_a = new_n[r["w_id"]]
        illegal = r["failed"][r["main_strand"]]
        if not illegal and code_a == code_b:
            continue
        g_name = NAME[sc.is_gen(r["vid"])][r["main_strand"]]
        lf = [(f"main text: CLC's {bdi(g_name)}", display(r["clc"][r["main_strand"]]))]
        if illegal:
            lf.append(
                (
                    f"MAM-informed {bdi(g_name)}",
                    display(tuple(r["mam_informed"][r["main_strand"]]["span"])),
                )
            )
        why = (
            "; ".join(CRIT[c] for c in illegal)
            if illegal
            else "legal; its code changes under 11B"
        )
        hs = highlighted([f for _, f in lf])
        k = len(lf)
        for j, ((label, _), h) in enumerate(zip(lf, hs)):
            cells = [f'<td dir="rtl">{h}</td>']
            if j == 0:
                cells.append(
                    f'<td rowspan="{k}" class="bcv">{bcv(r["vid"], r["atom"])}</td>'
                )
            cells.append(f"<td>{label}</td>")
            if j == 0:
                cells += [
                    f'<td rowspan="{k}">{html.escape(why)}</td>',
                    f'<td rowspan="{k}"><code>{code_a or "none"}</code></td>',
                    f'<td rowspan="{k}"><code>{code_b or "none"}</code></td>',
                    f'<td rowspan="{k}">{html.escape(pop.get(r["w_id"], "a name from the catalog"))}</td>',
                ]
            rows.append("<tr>" + "".join(cells) + "</tr>")
    return table(
        [
            "Forms",
            "Verse, atom",
            "Form of",
            "Why the main text is not legal",
            "n in the draft (11A)",
            "n under 11B",
            "The apps' popup in the draft",
        ],
        rows,
    )


def frag_n_codes_table():
    """Decision 12: every main-text atom whose n the build changes (out/57-n-changes.json)."""
    rows = []
    for r in json.loads((sc.W / "out/57-n-changes.json").read_text(encoding="utf-8"))[
        "changes"
    ]:
        acc = ", ".join(r["accents"]) or "none"
        if r["main_text_illegal"]:
            acc += " (not legal; coded as its MAM-informed version)"
        rows.append(
            f'<tr><td dir="rtl">{hbo(r["form"])}</td><td class="bcv">{bcv(r["vid"], r["atom"])}</td>'
            f'<td><code>{r["old"] or "none"}</code></td><td><code>{r["new"] or "none"}</code></td><td>{html.escape(acc)}</td></tr>'
        )
    return table(
        [
            "Main text in the draft",
            "Verse, atom",
            "n now",
            "n in the draft",
            "The main text's accents",
        ],
        rows,
    )


def frag_sheva_table():
    """Exodus 20:5's sheva: the atoms where WLC 4.20 has a sheva under a het and MAM a hataf
    patah (sub-agent V's out/52-mam-het.json), with the other editions' points (52-versions.json).
    """
    cases = json.loads((sc.W / "out/52-mam-het.json").read_text(encoding="utf-8"))[
        "cases"
    ]
    other = {
        v["vid"]: v
        for v in json.loads((sc.W / "out/52-versions.json").read_text(encoding="utf-8"))
    }
    H = "\N{LATIN SMALL LETTER H WITH DOT BELOW}"
    point = {"sheva": "sheva", "hataf patah": f"{H}ataf pata{H}"}
    rows = []
    for c in cases:
        lf = [
            ("WLC 4.20", c["wlc420"]),
            ("morphhb", c["morphhb"]["form"]),
            ("MAM", c["mam"]),
        ]
        o = other[c["vid"]]
        eds = ", ".join(
            f"{e} {point[o[e]['point']]}" for e in ("WLC 4.18", "WLC 4.22", "UXLC 2.6")
        )
        notes = ", ".join("note " + n.lstrip("]") for n in c["wlc420_notes"]) or "none"
        rows += group_rows(
            c["vid"],
            c["wlc_atom"],
            lf,
            f"Under the {H}et: {html.escape(eds)}.<br>WLC 4.20's notes: {html.escape(notes)}",
        )
    return table(["Forms", "Verse, atom", "Form of", "Other editions"], rows)


L_ = "\N{HEBREW LETTER LAMED}"
SIGLA = {
    L_: "the Leningrad Codex",
    "\N{HEBREW LETTER ALEF}": "the Aleppo Codex",
    L_ + "1": "St Petersburg, Firkovich B 17 (930)",
    L_
    + "-\N{HEBREW LETTER MEM}": "the Lehmann manuscript, known only through Breuer's reports",
    "\N{HEBREW LETTER SHIN}": "Sassoon 507, the Damascus Keter",
    "\N{HEBREW LETTER SHIN}1": "Sassoon 1053",
    "\N{HEBREW LETTER QOF}3": "Cairo 18",
    "\N{HEBREW LETTER VAV}": "the Washington Pentateuch (Museum of the Bible, Ms. 882)",
    L_ + "3": "St Petersburg EVR-II-B-10 (946)",
    "\N{HEBREW LETTER BET}": "London, British Library Or 4445",
}
METEG_NOTE_CASES = (  # sub-agent T's case keys in scratch-t/doc_notes.json
    ("1", "Exodus 20:4, atom 2 (MAM's Exodus 20:3)"),
    ("2", "Deuteronomy 5:7, atom 2 (MAM's Deuteronomy 5:6)"),
    ("2-par", "its parallel, Exodus 20:3, atom 2 (MAM's Exodus 20:2)"),
    ("1-par", "Deuteronomy 5:8, atom 2 (MAM's Deuteronomy 5:7)"),
)


def frag_meteg_notes():
    """MAM's notes on the three meteg cases (and case 2's Exodus parallel), verbatim from sub-agent
    T's extraction of MAM-basics' mirror, with the sigla they use as MAM's appendix identifies
    them (report 51's table)."""
    notes = {
        e["case"]: e
        for e in json.loads(
            (sc.W / "scratch-t/doc_notes.json").read_text(encoding="utf-8")
        )
    }
    out, used = [], {}
    for case, label in METEG_NOTE_CASES:
        e = notes[case]
        if len(e["notes"]) != 1:
            raise SystemExit(f"case {case}: {len(e['notes'])} notes")
        n = e["notes"][0]
        links = ", ".join(
            f'<a href="https://bdenckla.github.io/MAM-basics/MAM-with-doc/{f}#{a}">MAM-with-doc</a>'
            for f, a in n["published"]
        )
        rows = []
        for k, part in enumerate(n["doc_parts"], start=1):
            m = re.match(r"([^=\s]*)=([^\s(<]*)", part)
            if m:
                for tok in (
                    m.group(1) + "," + (m.group(2) if not m.group(1) else "")
                ).split(","):
                    s = tok.rstrip("!?")
                    if s and (sc.LETTER.search(s) or s in SIGLA):
                        if s not in SIGLA:
                            raise SystemExit(
                                f"case {case}: a siglum with no meaning here: {ascii(s)}"
                            )
                        used.setdefault(s, set()).update(c for c in tok[len(s) :])
            rows.append(
                f'<tr><td>doc-part {k}</td><td dir="rtl">{hebrew_html(html.escape(part), "hbo", in_rtl_cell=True)}</td></tr>'
            )
        out.append(f"<p><strong>{label}</strong>, MAM's note ({links}):</p>")
        out.append(table(["Doc-part", "MAM's note, verbatim"], rows))
    srows = []
    for s, marks in sorted(used.items(), key=lambda x: list(SIGLA).index(x[0])):
        after = " and ".join(f"<code>{m}</code>" for m in sorted(marks))
        srows.append(
            f'<tr><td dir="rtl"><bdi>{html.escape(s)}</bdi></td><td>{html.escape(SIGLA[s])}</td><td>{after or "–"}</td></tr>'
        )
    out.append(
        "<p>The sigla of MAM's form and of the variant readings in these notes:</p>"
    )
    out.append(
        table(
            ["Siglum", "MAM's appendix identifies it as", "Written after it here"],
            srows,
        )
    )
    out.append(
        "<p>A mark after a siglum: MAM's introduction (chapter 3) says that MAM usually adds an exclamation mark after "
        "the Leningrad Codex's reading where it is a clear scribal error, and not for a typical anomaly such as a missing "
        "dagesh. A question mark is not defined in what sub-agent T read of MAM's appendix; MAM-basics' "
        "<code>doc/sigil-decoding.md</code> reads it as marking uncertainty. The notes' prose also names manuscripts by "
        "these sigla, one more, St Petersburg EVR-II-B-8, by its shelf mark, and the printed editions, Breuer, Dotan, "
        "Mechon Mamre, Koren and the Simanim Tiqqun in words.</p>"
    )
    return "\n".join(out) + "\n"


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    FR.mkdir(parents=True, exist_ok=True)
    recs = vs.compute()
    base = base_readings()
    when, state = sys.argv[1], sys.argv[2]
    frags = {
        "STATE": f'<p><span class="state">State, 2026-11-15 at {html.escape(when)}, New York time:</span> {state}</p>\n',
        "SUPPLIED": frag_supplied(recs),
        "CHECKS": frag_checks(),
        **{k: prose(k) for k in PROSE_NAMES},
        "N_ILLEGAL_TABLE": frag_n_illegal_table(recs),
        "N_CODES_TABLE": frag_n_codes_table(),
        "SHEVA_TABLE": frag_sheva_table(),
        "METEG_NOTES": frag_meteg_notes(),
        "CHANGE": frag_change(),
        "DESCRIPTION": frag_description(),
        "SPANS": frag_spans(recs),
        "ILLEGAL": frag_illegal(recs),
        "RESTORED": frag_restored(recs, base),
        "QADMA": frag_qadma(recs, base),
        "METEG": frag_meteg(recs),
        "XML_EXOD_20_3": frag_xml("Exod", "Exod.20.3"),
        "BEN_WORDS": frag_ben_words(),
        "COUNTS": frag_counts(recs),
    }
    for k, v in frags.items():
        (FR / f"{k}.html").write_text(v, encoding="utf-8", newline="\n")
        print(k, len(v))


if __name__ == "__main__":
    main()

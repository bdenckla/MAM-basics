"""Print the structure of folder S's out/22-clc-answers.json (keys, one sample atom)."""

import json
import sys
from pathlib import Path

S = Path("C:/Users/BenDe/GitRepos/MAM-basics/.novc/morphhb-strands-pr-2026-11-14")


def shape(obj, depth=0, maxdepth=3):
    pad = "  " * depth
    if isinstance(obj, dict):
        for k, v in list(obj.items())[:40]:
            if isinstance(v, (dict, list)) and depth < maxdepth:
                print(f"{pad}{k}: {type(v).__name__}({len(v)})")
                shape(v, depth + 1, maxdepth)
            else:
                print(f"{pad}{k}: {ascii(v)[:120]}")
    elif isinstance(obj, list):
        if obj:
            print(f"{pad}[0] of {len(obj)}:")
            shape(obj[0], depth + 1, maxdepth)


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    data = json.loads((S / "out/22-clc-answers.json").read_text(encoding="utf-8"))
    shape(data, 0, 2)


main()

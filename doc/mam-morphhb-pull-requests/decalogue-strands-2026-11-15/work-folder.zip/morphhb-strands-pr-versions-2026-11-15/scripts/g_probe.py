"""Sub-agent G: probe the inputs g_common.py reads (scratch output only).

Checks the JSON's MAM forms against MAM-simple's strands, prints the three continuation verses,
and prints morphhb's main-text words of a few verses.
"""

import sys

sys.dont_write_bytecode = True

import g_common as g  # noqa: E402


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    atoms = g.load_atoms()
    mam = g.mam_simple_verses()
    by_vid = {}
    for a in atoms:
        by_vid.setdefault(a["vid"], []).append(a)
    bad = 0
    kinds = []
    for vid in g.VIDS24:
        for s in g.STRANDS:
            ms = mam[vid][s]
            js = [a[s]["mam"] for a in by_vid[vid]]
            if [x["form"] for x in ms] != js:
                bad += 1
                print("MISMATCH", vid, s)
                for x, y in zip([x["form"] for x in ms], js):
                    if x != y:
                        print("   ", ascii(x), ascii(y))
            for i, x in enumerate(ms, start=1):
                if x["mam_paseq_kind"]:
                    kinds.append((vid, i, s, x["form"], x["mam_paseq_kind"]))
    print("verse-strands whose JSON MAM forms differ from MAM-simple:", bad)
    for k in kinds:
        print("PASEQ", k)
    for vid in g.EXTRA_VIDS:
        print(vid, "alef", " ".join(x["form"] for x in mam[vid]["alef"]))
        for x in mam[vid]["alef"]:
            if x["mam_paseq_kind"]:
                print("   PASEQ", x)
    extra = g.extra_atoms(mam)
    for e in extra:
        print(e["vid"], e["atom"], e["wlc420"], e["alef"]["mam"])
    mh = g.morphhb_verses(g.VIDS24 + list(g.EXTRA_VIDS))
    for vid in sys.argv[1:]:
        print("==", vid)
        for w in mh[vid]:
            print("  ", w)


main()

"""Print the versions of the atoms with an illegal CLC version, from out/60-versions.json."""

import json
import sys
import unicodedata
from pathlib import Path

W = Path(__file__).resolve().parent.parent


def describe(core):
    """Letters with their marks named briefly, e.g. 'yod[hiriq] he[sheva]'."""
    out = []
    for ch in core:
        name = unicodedata.name(ch, hex(ord(ch)))
        short = name.replace("HEBREW LETTER ", "").replace("HEBREW POINT ", "").replace("HEBREW ACCENT ", "").lower()
        if "LETTER" in name:
            out.append(short)
        else:
            out[-1] += "[" + short + "]" if not out[-1].endswith("]") else ""
            if not out[-1].endswith("[" + short + "]"):
                out[-1] = out[-1][:-1] + "," + short + "]"
    return " ".join(out)


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    recs = json.loads((W / "out/60-versions.json").read_text(encoding="utf-8"))
    want = set(sys.argv[1:])
    for r in recs:
        key = f"{r['vid']}:{r['atom']}"
        if (want and key in want) or (not want and any(r["failed"].values())):
            print(key, "failed", r["failed"], "noted", r["noted"])
            for s in ("alef", "bet"):
                print(f"   MAM {s:4}", describe(r["mam"][s][0]), "+", r["mam"][s][1] or "-")
            for v in r["versions"]:
                print(f"   {v['kind']:9}", describe(v["span"][0]), "+", v["span"][1] or "-", v["notes"])


main()

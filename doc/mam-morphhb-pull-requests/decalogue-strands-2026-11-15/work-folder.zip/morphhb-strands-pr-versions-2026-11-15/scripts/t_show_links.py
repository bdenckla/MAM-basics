"""Sub-agent T: dump scratch-t/links.json readably to scratch-t/links.txt."""

import json
from pathlib import Path

W = Path("C:/Users/BenDe/GitRepos/MAM-basics/.novc/morphhb-strands-pr-versions-2026-11-15")


def main():
    data = json.loads((W / "scratch-t/links.json").read_text(encoding="utf-8"))
    out = []
    for kind in ("listing", "bhs", "mam"):
        for r in data[kind]:
            out.append(f"##### {kind} {r['args']} rc={r['rc']}")
            out.append(r["out"].rstrip())
            if r["err"].strip():
                out.append("stderr: " + r["err"].strip()[:2000])
    (W / "scratch-t/links.txt").write_text("\n".join(out) + "\n", encoding="utf-8", newline="\n")


main()

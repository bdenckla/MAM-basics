"""Replay morphhb's apps' accent naming over the 24 verses, base against a build.

Usage (-I): check_keys.py <AccentCatalog.js> <base-dir> <build-dir> <report.txt> [<60-versions.json>]

The replay is folder S's scripts/h_catalog_census.py's (sub-agent H): the apps take a word's
text, delete U+05AF to U+05F4 and "/", and, when the word carries n, append the text of each
following <seg> (other than pe and samekh) up to the next <w>; the word is disjunctive when it
carries n, else conjunctive; the name is the prose table's entry, else "error|key|type".
Notes are skipped, as the apps skip them in building a key.

With out/60-versions.json (versions.py's), each miss in the build is marked with whether its
main text (CLC's main strand) is illegal there, and the misses at legal atoms are counted; the
build should have none.
"""

import json

import re
import sys
import unicodedata
import xml.etree.ElementTree as ET
from pathlib import Path

STRIP = re.compile("[֯-״/]")
VIDS = (
    ["Gen.35.22"]
    + [f"Exod.20.{v}" for v in (2, 3, 4, 5, 6, 8, 9, 10, 13, 14, 15)]
    + [f"Deut.5.{v}" for v in (6, 7, 8, 9, 10, 12, 13, 14, 15, 17, 18, 19)]
)


def local(tag):
    return tag.rsplit("}", 1)[-1]


def load_catalog(path):
    text = open(path, encoding="utf-8").read()
    prose = text[text.index('"prose"') : text.index('"poetic"')]
    tables = {}
    for kind in ("disjunctive", "conjunctive"):
        i = prose.index('"%s"' % kind)
        j = prose.index("}\n\t\t}", i) if "}\n\t\t}" in prose[i:] else len(prose)
        keys = {}
        for m in re.finditer(
            r'"((?:\\u[0-9A-Fa-f]{4})*)":\s*\{"name":\s*"([^"]*)"', prose[i:j]
        ):
            keys[m.group(1).encode("ascii").decode("unicode_escape")] = m.group(2)
        tables[kind] = keys
    return tables


def names(key):
    return (
        " + ".join(
            unicodedata.name(c, "U+%04X" % ord(c))
            .replace("HEBREW ACCENT ", "")
            .replace("HEBREW PUNCTUATION ", "")
            .replace("HEBREW POINT ", "")
            .lower()
            for c in key
        )
        or "(empty)"
    )


def replay(verse):
    out, cur, set_line = [], None, False
    for el in verse:
        t = local(el.tag)
        if t == "w":
            text = "".join(el.itertext())
            cur = {"id": el.get("id"), "n": el.get("n"), "key": STRIP.sub("", text)}
            out.append(cur)
            set_line = el.get("n") is not None
        elif t == "seg":
            if el.get("type") in ("x-pe", "x-samekh"):
                continue
            if set_line and cur is not None:
                cur["key"] += el.text or ""
        elif t == "note" and el.get("type") == "variant":
            for r in el:
                if local(r.tag) == "rdg":
                    for w in r:
                        if local(w.tag) == "w":
                            cur = {
                                "id": w.get("id"),
                                "n": w.get("n"),
                                "key": STRIP.sub("", "".join(w.itertext())),
                            }
                            out.append(cur)
                            set_line = w.get("n") is not None
    for w in out:
        w["type"] = "disjunctive" if w["n"] is not None else "conjunctive"
    return out


def verses(d):
    vs = {}
    for b in ("Gen", "Exod", "Deut"):
        for v in ET.parse(Path(d) / f"{b}.xml").getroot().iter():
            if local(v.tag) == "verse" and v.get("osisID") in VIDS:
                vs[v.get("osisID")] = v
    return vs


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    cat, base_dir, build_dir, report = sys.argv[1:5]
    recs = {}
    if len(sys.argv) > 5:
        recs = {
            r["w_id"]: r
            for r in json.loads(Path(sys.argv[5]).read_text(encoding="utf-8"))
        }
    tables = load_catalog(cat)
    lines = [
        f"catalog keys: disjunctive {len(tables['disjunctive'])}, conjunctive {len(tables['conjunctive'])}"
    ]
    for label, d in (("base", base_dir), ("build", build_dir)):
        vs = verses(d)
        total = misses = at_legal = 0
        lines.append(f"== {label}: {d}")
        for vid in VIDS:
            for w in replay(vs[vid]):
                total += 1
                if tables[w["type"]].get(w["key"]) is None:
                    misses += 1
                    tail = ""
                    if label == "build" and recs:
                        r = recs[w["id"]]
                        why = r["failed"][r["main_strand"]]
                        tail = f" | atom {r['atom']}, main text illegal: {','.join(why) if why else 'NO'}"
                        if not why:
                            at_legal += 1
                    lines.append(
                        f"   {vid:10} {w['id']} n={w['n']} {w['type']} -> error|key|{w['type']} [key: {names(w['key'])}]{tail}"
                    )
        lines.append(f"   words {total}, lookups with no catalog entry {misses}")
        if label == "build" and recs:
            lines.append(f"   of them at atoms whose main text is legal: {at_legal}")
    Path(report).write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print("\n".join(lines))


main()

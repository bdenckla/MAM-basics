"""Pack the work folder for deep storage in MAM-basics (Ben, 2026-11-16: put it "on ice").

Run with -I from the MAM-basics root:
  ice_pack.py <destination folder>

Writes into the destination:
- change.diff: the draft's change to wlc/Gen.xml, Exod.xml and Deut.xml against the base, the
  three files at openscriptures/morphhb#118's head 696e21ce, as `git apply` takes it;
- work-folder.zip: this work folder under its own name, less what is regenerable or refetchable
  (the dry run's request bodies, the built and master XML, sub-agent I's XML copies, Python
  caches), with the base XML kept, and with copies of the two inputs from outside the folder
  under inputs/: folder S's out/22-clc-answers.json and .md, and the brief.
Prints what it wrote, with sizes, entry counts and SHA-256 digests.
"""

import difflib
import hashlib
import sys
import zipfile
from pathlib import Path

W = Path(__file__).resolve().parent.parent
S = Path("C:/Users/BenDe/GitRepos/MAM-basics/.novc/morphhb-strands-pr-2026-11-14")
BRIEF = Path(
    "C:/Users/BenDe/AppData/Local/Claude-Data/claude_pzs8sxrjxfjjc/side-session-notes/"
    "local_a80ded65-f78e-4280-8493-9dab3b8c5686/morphhb-strands-pr-versions-brief-2026-11-15.md"
)
BOOKS = ("Gen", "Exod", "Deut")


def excluded(rel):
    parts = rel.split("/")
    if parts[0] == "post-bodies-dry-1" or "__pycache__" in parts:
        return True
    if rel.endswith(".xml") and (
        rel.startswith("out/build-A/") or rel.startswith("fetched/master-db6c5c9b/") or parts[0].startswith("scratch-")
    ):
        return True
    return False


def write_diff(dest):
    chunks = []
    for b in BOOKS:
        old = (W / "fetched/base-696e21ce" / f"{b}.xml").read_text(encoding="utf-8")
        new = (W / "out/build-A" / f"{b}.xml").read_text(encoding="utf-8")
        path = f"wlc/{b}.xml"
        lines = list(
            difflib.unified_diff(
                old.splitlines(keepends=True), new.splitlines(keepends=True), f"a/{path}", f"b/{path}", n=3
            )
        )
        # the files end without a newline; a hunk reaching the last line would need git's
        # "No newline at end of file" marker, so refuse rather than write a wrong diff
        if any(not ln.endswith("\n") for ln in lines):
            raise SystemExit(f"{b}: a hunk reaches the file's unterminated last line")
        chunks.append(f"diff --git a/{path} b/{path}\n")
        chunks.extend(lines)
    text = "".join(chunks)
    out = dest / "change.diff"
    out.write_text(text, encoding="utf-8", newline="\n")
    return out


def write_zip(dest):
    out = dest / "work-folder.zip"
    top = W.name
    n = 0
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for f in sorted(W.rglob("*")):
            if not f.is_file():
                continue
            rel = f.relative_to(W).as_posix()
            if excluded(rel):
                continue
            z.write(f, f"{top}/{rel}")
            n += 1
        for src, rel in (
            (S / "out/22-clc-answers.json", "inputs/folder-S/out/22-clc-answers.json"),
            (S / "out/22-clc-answers.md", "inputs/folder-S/out/22-clc-answers.md"),
            (BRIEF, "inputs/" + BRIEF.name),
        ):
            z.write(src, f"{top}/{rel}")
            n += 1
    return out, n


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    dest = Path(sys.argv[1])
    dest.mkdir(parents=True, exist_ok=True)
    d = write_diff(dest)
    z, n = write_zip(dest)
    for p in (d, z):
        print(f"{p.name}: {p.stat().st_size:,} bytes, sha256 {digest(p)}")
    print(f"zip entries: {n}")


main()

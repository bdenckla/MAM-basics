"""Sub-agent T: dump chosen lines of MAM's mirrored introduction, split into
sentences with indices and with footnotes listed apart, so that quotations can
be chosen by (file, line, sentence) and copied by script, never retyped."""

import json
import re
import sys
from pathlib import Path

import t_wikitext as wt

REPO = Path("C:/Users/BenDe/GitRepos/MAM-basics")
INTRO = REPO / "in/mam-ws-intro"
W = REPO / ".novc/morphhb-strands-pr-versions-2026-11-15"
OUT_JSON = W / "scratch-t/intro_lines.json"
OUT_TXT = W / "scratch-t/intro_lines.txt"

T_FOOTNOTE = "\N{HEBREW LETTER HE}\N{HEBREW LETTER AYIN}\N{HEBREW LETTER RESH}\N{HEBREW LETTER HE}"
T_SUPER = (
    "\N{HEBREW LETTER KAF}\N{HEBREW LETTER TAV}\N{HEBREW LETTER BET} "
    "\N{HEBREW LETTER AYIN}\N{HEBREW LETTER YOD}\N{HEBREW LETTER LAMED}\N{HEBREW LETTER YOD}"
)

WANT = {
    "appendices": [8, 10, 11, 19, 24, 25, 40, 42, 43, 44, 45, 46, 47, 49, 50, 54, 61, 69, 70,
                   188, 194, 225, 258, 259, 261, 265, 266, 270, 272, 281, 418],
    "ch3": [703, 705, 720, 740, 761, 807, 885, 886, 890, 891, 895, 1069, 1070, 1071, 1072,
            1076, 1077, 1265, 1267, 1272, 1274, 1276, 1278, 1280, 1283, 1313, 1318, 1366,
            1367, 1378, 1380, 1383],
    "westminster-typing": [1146, 1263, 1264],
}
SPECIAL = {"decalogue-en": [19]}


def display(s):
    """Wikitext to display text: footnotes cut out (returned apart), links to
    their text, bold and italic quotes dropped, superscript template kept as
    <sup>; any other template is kept verbatim."""
    notes = []
    out = []
    last = 0
    for a, b in wt.template_spans(s):
        out.append(s[last:a])
        name, params = wt.parse_template(s[a:b])
        if name == T_FOOTNOTE:
            notes.append(display(params.get("1", ""))[0])
            out.append("[^%d]" % len(notes))
        elif name == T_SUPER:
            out.append("<sup>" + params["1"] + "</sup>")
        else:
            out.append(s[a:b])
        last = b
    out.append(s[last:])
    t = "".join(out)
    t = re.sub(r"\[\[(?:[^\]|]*\|)?([^\]]*)\]\]", r"\1", t)
    t = re.sub(r"\[https?://[^\s\]]+ ([^\]]*)\]", r"\1", t)
    t = re.sub(r"'''(.*?)'''", r"@@B@@\1@@/B@@", t)
    t = t.replace("''", "")
    return t, notes


def sentences(t):
    return [x for x in re.split(r"(?<=[.:;])\s+", t) if x]


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    data = {}
    txt = []
    jobs = [(INTRO, f, n) for f, n in WANT.items()]
    jobs += [(REPO / "in/mam-ws-special", f, n) for f, n in SPECIAL.items()]
    for folder, fname, nums in jobs:
        lines = (folder / f"{fname}.mediawiki").read_text(encoding="utf-8").split("\n")
        for n in nums:
            raw = lines[n - 1]
            disp, notes = display(raw)
            sents = sentences(disp)
            data[f"{fname}:{n}"] = {"raw": raw, "display": disp, "notes": notes, "sentences": sents}
            txt.append(f"##### {fname}:{n}")
            for i, s in enumerate(sents):
                txt.append(f"  [{i}] {s}")
            for i, s in enumerate(notes, start=1):
                txt.append(f"  note {i}: {s}")
    with OUT_JSON.open("w", encoding="utf-8", newline="\n") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
        f.write("\n")
    with OUT_TXT.open("w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(txt) + "\n")


main()

"""Sub-agent I: list the distinct runs of Hebrew letters (and marks) in the named files.

Usage (-I, MAM-basics root): i_hebrew_runs.py <file> [<file> ...]
Each run is printed with its count and its letters spelt by Unicode name, so that a hand-typed
strand name can be checked; runs equal to one of the four strand names are only counted.
"""

import re
import sys
import unicodedata
from collections import Counter
from pathlib import Path

RUN = re.compile("[א-ת֑-ׇ]+")
NAMES = {
    "\N{HEBREW LETTER TAV}\N{HEBREW LETTER HET}\N{HEBREW LETTER TAV}\N{HEBREW LETTER VAV}\N{HEBREW LETTER FINAL NUN}",
    "\N{HEBREW LETTER AYIN}\N{HEBREW LETTER LAMED}\N{HEBREW LETTER YOD}\N{HEBREW LETTER VAV}\N{HEBREW LETTER FINAL NUN}",
    "\N{HEBREW LETTER PE}\N{HEBREW LETTER SHIN}\N{HEBREW LETTER VAV}\N{HEBREW LETTER TET}\N{HEBREW LETTER HE}",
    "\N{HEBREW LETTER MEM}\N{HEBREW LETTER DALET}\N{HEBREW LETTER RESH}\N{HEBREW LETTER SHIN}\N{HEBREW LETTER YOD}\N{HEBREW LETTER TAV}",
}

sys.stdout.reconfigure(encoding="utf-8")
for name in sys.argv[1:]:
    c = Counter(RUN.findall(Path(name).read_text(encoding="utf-8")))
    strand = sum(n for r, n in c.items() if r in NAMES)
    print(f"== {Path(name).name}: {strand} strand names")
    for r, n in sorted(c.items()):
        if r in NAMES:
            continue
        spelt = " ".join(
            unicodedata.name(ch).replace("HEBREW LETTER ", "").replace("HEBREW ", "")
            for ch in r
        )
        print(f"   {n} x {r}  [{spelt}]")

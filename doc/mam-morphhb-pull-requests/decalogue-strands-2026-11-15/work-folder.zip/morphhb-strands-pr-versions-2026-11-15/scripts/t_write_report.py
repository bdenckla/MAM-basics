"""Sub-agent T: write out/51-mam-documentation.md and .html.

Every Hebrew string in the report is copied by script: forms from
22-clc-answers.json, MAM's notes from the in/mam-ws mirror (via
scratch-t/doc_notes.json), introduction passages from in/mam-ws-intro (via
scratch-t/intro_lines.json), links from py/main_verse_links.py's output (via
scratch-t/links.json), and the few unpointed labels from t_heb, each checked
against the text it points at.
"""

import html
import json
import re
import sys
import unicodedata
from pathlib import Path

REPO = Path("C:/Users/BenDe/GitRepos/MAM-basics")
sys.path.insert(0, str(REPO / "py"))  # untracked scratch script only

from mb_cmn import template_names as tmpln  # noqa: E402

import t_heb  # noqa: E402
import t_wikitext as wt  # noqa: E402

W = REPO / ".novc/morphhb-strands-pr-versions-2026-11-15"
SCR = W / "scratch-t"
OUT_MD = W / "out/51-mam-documentation.md"
OUT_HTML = W / "out/51-mam-documentation.html"

SIG = t_heb.SIG
WORD = t_heb.WORD

# ---------------------------------------------------------------- data


def load(name):
    return json.loads((SCR / name).read_text(encoding="utf-8"))


NOTES = {r["case"]: r for r in load("doc_notes.json")}
INTRO = load("intro_lines.json")
LINKS = load("links.json")

ALL_DOC_TEXT = " ".join(
    dp for r in NOTES.values() for n in r["notes"] for dp in n["doc_parts"]
)
ALL_INTRO_TEXT = " ".join(v["raw"] for v in INTRO.values())


def check_sigil(key):
    s = SIG[key]
    assert s in ALL_DOC_TEXT or s in ALL_INTRO_TEXT, key
    return s


for _k in SIG:
    check_sigil(_k)

# Every word label must occur in the documentation it is used to point at.
_ALL_TEXT = ALL_DOC_TEXT + " " + ALL_INTRO_TEXT + " " + " ".join(
    n["target"] for r in NOTES.values() for n in r["notes"]
)
for _k, _v in WORD.items():
    assert _v in _ALL_TEXT, _k
for _k, _v in (("TNAF", WORD["TNAF"]), ("TGNV", WORD["TGNV"])):
    assert '"' + _v + '"' in NOTES["10a-par"]["notes"][0]["doc_parts"][2], _k

TACHTON = NOTES["1"]["alef_name"]
ELYON = NOTES["1"]["bet_name"]
PESHUTA = NOTES["9"]["alef_name"]
MIDRASHIT = NOTES["9"]["bet_name"]
assert TACHTON in ALL_DOC_TEXT and ELYON in ALL_DOC_TEXT

# ---------------------------------------------------------------- markers

HEB_CHARS = (
    "\N{HEBREW ACCENT ETNAHTA}-\N{HEBREW POINT QAMATS QATAN}"
    "\N{HEBREW LETTER ALEF}-\N{HEBREW LETTER TAV}"
    "\N{COMBINING GRAPHEME JOINER}"
)
HEB_RUN = re.compile("[" + HEB_CHARS + "]+")
NOT_MARKS = (
    "\N{HEBREW PUNCTUATION MAQAF}"
    "\N{HEBREW PUNCTUATION PASEQ}"
    "\N{HEBREW PUNCTUATION SOF PASUQ}"
    "\N{HEBREW PUNCTUATION NUN HAFUKHA}"
)


def is_pointed(run):
    return any(
        "\N{HEBREW ACCENT ETNAHTA}" <= c <= "\N{HEBREW POINT QAMATS QATAN}"
        and c not in NOT_MARKS
        for c in run
    )


def hp(s):
    """Pointed Hebrew inside English prose."""
    return "@@H@@" + s + "@@/H@@"


def hu(s):
    """Unpointed Hebrew inside English prose."""
    return "@@U@@" + s + "@@/U@@"


def T(s):
    """A strand name, unpointed."""
    return hu(s)


def names(s):
    return ", ".join(unicodedata.name(c, hex(ord(c))).title() for c in s)


# ---------------------------------------------------------------- blocks

BLOCKS = []


def caveat(t):
    BLOCKS.append(("caveat", t))


def h(level, t):
    BLOCKS.append((f"h{level}", t))


def p(t):
    BLOCKS.append(("p", t))


def ul(items):
    BLOCKS.append(("ul", items))


def ol(items):
    BLOCKS.append(("ol", items))


def table(headers, rows, rtl_cols=()):
    BLOCKS.append(("table", headers, rows, set(rtl_cols)))


def heb_block(t):
    """A block of Hebrew (RTL), verbatim."""
    BLOCKS.append(("heb", t))


def md_lines(lines):
    BLOCKS.append(("mdlines", lines))


# ---------------------------------------------------------------- helpers


def intro_sent(key, *idx):
    v = INTRO[key]
    out = " ".join(v["sentences"][i] for i in idx)
    return re.sub(r"\[\^\d+\]", "", out).strip()


def intro_note(key, n, *sentences):
    t = INTRO[key]["notes"][n - 1]
    if not sentences:
        return t
    parts = [x for x in re.split(r"(?<=[.:;])\s+", t) if x]
    return " ".join(parts[i] for i in sentences)


def note_of(case, i=0):
    r = NOTES[case]
    assert len(r["notes"]) >= i + 1, case
    return r["notes"][i]


def pub_link(case, i=0):
    n = note_of(case, i)
    pub = n["published"]
    assert pub, case
    page, anchor = pub[0]
    path = REPO / "gh-pages/MAM-with-doc" / page
    return f"[{page}#{anchor}]({path.as_uri()}#{anchor})"


def where(case, i=0):
    r = NOTES[case]
    return (
        f"`{r['mam_file']}`, chapter {hu(r['mam_chapter_key'])}, verse "
        f"{hu(r['mam_verse_label'])} (MAM's verse {r['vid'].split('.')[1]}:{r['mam_verse']}), "
        f"template {hu(WORD['NUSACH'])}, parameter 2; published in MAM-with-doc at "
        + pub_link(case, i)
    )


def where_short(case, i=0):
    r = NOTES[case]
    return f"MAM's {BOOKNAME[r['vid'].split('.')[0]]} {r['vid'].split('.')[1]}:{r['mam_verse']} ({pub_link(case, i)})"


BOOKNAME = {"Gen": "Genesis", "Exod": "Exodus", "Deut": "Deuteronomy"}


def show(t):
    """A target: pointed Hebrew, or raw wikitext (with a template) as code."""
    return "`" + hu(t) + "`" if "{{" in t else hp(t)


def forms_table(case):
    r = NOTES[case]
    rows = [
        ["WLC 4.20", r["wlc420"]],
        ["MAM's " + hu(r["alef_name"]), r["alef_mam_form"]],
        ["MAM's " + hu(r["bet_name"]), r["bet_mam_form"]],
    ]
    book, chap, verse = r["vid"].split(".")
    label = f"{BOOKNAME[book]} {chap}:{verse} atom {r['atom']}"
    table(["Text", label], rows, rtl_cols=(1,))


def doc_table(case, english, i=0):
    n = note_of(case, i)
    parts = n["doc_parts"]
    assert len(parts) == len(english), (case, len(parts), len(english))
    rows = [[f"doc-part {k + 1}", dp, en] for k, (dp, en) in enumerate(zip(parts, english))]
    table(["Doc-part", "MAM's note, verbatim", "English summary"], rows, rtl_cols=(1,))


def target_of(case, i=0):
    return note_of(case, i)["target"]


def link_lines(book, cv, labels, kind):
    for r in LINKS[kind]:
        if r["args"][0] == book and r["args"][1] == cv:
            out = []
            for line in r["out"].splitlines():
                for lab in labels:
                    if line.startswith(f"- [{lab}]") or (lab == "LC" and line.startswith("- [LC F")):
                        out.append(line)
            assert out, (book, cv, labels)
            return out
    raise KeyError((book, cv, kind))


def bhs_link_lines(book, cv, atom, labels):
    for r in LINKS["bhs"]:
        if r["args"][:2] == [book, cv] and r["args"][3] == str(atom):
            out = []
            for line in r["out"].splitlines():
                for lab in labels:
                    if line.startswith(f"- [{lab}]") or (lab == "LC" and line.startswith("- [LC F")):
                        out.append(line)
            assert out, (book, cv, atom)
            return out
    raise KeyError((book, cv, atom))


def lookups(book, bhs_cv, atom, mam_cv):
    lines = []
    if mam_cv is not None:
        lines += link_lines(book, mam_cv, ["MwD", "MM"], "mam")
    else:
        lines += bhs_link_lines(book, bhs_cv, atom, ["MwD", "MM"])
    lines += bhs_link_lines(book, bhs_cv, atom, ["UXLC", "tica LC", "LC", "tica"])
    p(f"Look it up, {BOOKNAME[{'Exodus': 'Exod', 'Deuter': 'Deut', 'Genesis': 'Gen'}[book]]} {bhs_cv} atom {atom}:")
    md_lines(lines)


# ---------------------------------------------------------------- extra extraction

def sof_pasuq_note_exod_20_3():
    """The note on the sof pasuq after the atom of case 5a (MAM's Exodus 20:2)."""
    data = json.loads((REPO / "in/mam-ws/A2-Exodus.json").read_text(encoding="utf-8"))
    r = NOTES["5a"]
    line = data[r["mam_chapter_key"]][r["line_index"]]
    hits = []
    k_kaful = t_heb.w("kaf", "pe", "vav", "lamed")
    atom_raw = None
    for path, raw, name, params, a, b in wt.walk_templates(line):
        if name != tmpln.DUAL_CANTILLATION:
            continue
        kaful = params[k_kaful]
        if tmpln.TWO_ACCENTS_OF_QUPO not in kaful:
            continue
        for _, raw2, name2, params2, a2, b2 in wt.walk_templates(kaful):
            if name2 == WORD["NUSACH"] and params2["1"] == "\N{HEBREW PUNCTUATION SOF PASUQ}":
                hits.append((raw2, params2["2"]))
        atom_start = kaful.find(tmpln.TWO_ACCENTS_OF_QUPO)
        # the raw wikitext of the atom: from the space before it to the template after it
        s0 = kaful.rfind(" ", 0, atom_start) + 1
        s1 = kaful.find("{{" + WORD["NUSACH"], atom_start)
        atom_raw = kaful[s0:s1]
    assert len(hits) == 1, hits
    return atom_raw, hits[0][1]


ATOM_5A_RAW, SOFPASUQ_5A = sof_pasuq_note_exod_20_3()
SOFPASUQ_5A_PARTS = wt.split_top(SOFPASUQ_5A, "{{" + WORD["SH_TMPL"] + "}}")

from mb_cmn.uni_denorm import give_std_mark_order  # noqa: E402


def _norm(s):
    s = s.replace("\N{COMBINING GRAPHEME JOINER}", "")
    s = s.replace("\N{HEBREW PUNCTUATION GERSHAYIM}", '"')
    return give_std_mark_order(re.sub(r"\s+", " ", s).strip())


def find_big_doc(page, prefix, first_part):
    raw = (REPO / "gh-pages/MAM-with-doc" / page).read_text(encoding="utf-8")
    probe = _norm(wt.strip_templates(first_part))
    hits = []
    for m in re.finditer(
        r'<span class="mam-doc-part-0" id="([^"]+)">(.*?)</span>', raw, re.DOTALL
    ):
        text = _norm(html.unescape(re.sub(r"<[^>]+>", "", m.group(2))))
        if m.group(1).startswith(prefix) and text == probe:
            hits.append(m.group(1))
    assert len(hits) == 1, hits
    path = REPO / "gh-pages/MAM-with-doc" / page
    return f"[{page}#{hits[0]}]({path.as_uri()}#{hits[0]})"


SOFPASUQ_5A_PUB = find_big_doc("A2-Exodus-big-doc.html", "c20v2doc", SOFPASUQ_5A_PARTS[0])


def intro_gen_note():
    raw = INTRO["ch3:1367"]["raw"]
    found = []
    for path, raw2, name, params, a, b in wt.walk_templates(raw):
        if name == WORD["NUSACH"]:
            found.append((params["1"], params["2"]))
    assert len(found) == 1
    target, note = found[0]
    parts = wt.split_top(note, "{{" + WORD["SH_TMPL"] + "}}")
    return target, parts


INTRO_GEN_TARGET, INTRO_GEN_PARTS = intro_gen_note()


def westminster_rows():
    rows = []
    for key in ("westminster-typing:1263", "westminster-typing:1264"):
        raw = INTRO[key]["raw"]
        raw = raw.replace("\N{LEFT-TO-RIGHT EMBEDDING}", "").replace("\N{POP DIRECTIONAL FORMATTING}", "")
        cells = raw.split("\t")
        assert len(cells) == 4, cells
        rows.append(cells)
    return rows


# ---------------------------------------------------------------- the report

caveat(
    "Claude's work (sub-agent T, 2026-11-15), not reviewed by a human. Read-only research for "
    "the session preparing, not posting, a pull request to openscriptures/morphhb; it reports "
    "what MAM's documentation says and claims nothing about any manuscript's reading."
)
h(1, "MAM's documentation of the Decalogue and Genesis 35:22 forms")

p(
    "**Scope.** Ben asked where MAM got the meteg that its "
    + T(ELYON)
    + " has, where WLC 4.20 lacks it or has it elsewhere, \"since in the Decalogues MAM is "
    "highly dependent on Leningrad\". This report answers from MAM's documentation only: its "
    "notes, mirrored with its chapter text in `in/mam-ws/` and published in MAM-with-doc, and "
    "its introduction, mirrored in `in/mam-ws-intro/`. MAM's notes call the meteg "
    + hu(WORD["GAAYA"])
    + "; this report says meteg, and silluq for the same mark at a verse's end. Verses and atoms "
    "are BHS's, as in `22-clc-answers.json`; MAM numbers its Decalogues by the manuscripts' "
    + T(TACHTON)
    + ", so its verse numbers differ, and each case names both. Strand forms come from that "
    "JSON (key `atoms`); MAM's text and notes are CC BY-SA 4.0, Hebrew Wikisource "
    "(`MAM-with-doc/LICENSE.md`)."
)

h(2, "Answer to Ben's question, the three meteg cases")

ol(
    [
        "**Exodus 20:4 atom 2, the meteg on the shin rather than the tav. Found.** MAM's note "
        "gives MAM's form as that of Firkovich B17 ("
        + hu(SIG["L1"])
        + "), the Lehmann manuscript ("
        + hu(SIG["LM"])
        + "), Sassoon 507 ("
        + hu(SIG["S"])
        + "), Sassoon 1053 ("
        + hu(SIG["S1"])
        + "), Cairo 18 ("
        + hu(SIG["Q3"])
        + ") and the printed editions, and adds that the Aleppo Codex and the LC have it so in "
        "Deuteronomy. It quotes the LC with the meteg on the tav and says that Breuer corrected "
        "the meteg's place to the shin according to the Lehmann manuscript, as Mechon Mamre also "
        "has it, while Dotan left it on the tav according to the LC. MAM's appendix says the "
        "Lehmann manuscript is known "
        "only through Breuer's report. MAM's introduction lists this verse among the 14 places "
        "in Exodus where MAM did not accept the LC's meteg.",
        "**Deuteronomy 5:7 atom 2, the meteg on the second yod. Found, but the Deuteronomy note "
        "explains only the maqaf; the explanation of the meteg is in the Exodus note.** The "
        "Deuteronomy note gives MAM's form, with a merkha and a meteg on the second yod, as that "
        "of Sassoon 507, Sassoon 1053, Cairo 18, the Washington Pentateuch ("
        + hu(SIG["V"])
        + ") and the printed editions, and quotes the LC (with Firkovich B17, marked uncertain, "
        "and St Petersburg EVR-II-B-10, "
        + hu(SIG["L3"])
        + ") with a merkha alone on that yod, naming only the missing maqaf. MAM's note on the "
        "parallel chanted word at Exodus 20:3 says that the LC has one stroke on the second yod, "
        "slanting like a merkha, which Dotan and Breuer take as the "
        + T(TACHTON)
        + "'s merkha and the "
        + T(ELYON)
        + "'s meteg at once, and that Sassoon 507, Sassoon 1053 and the printed editions have "
        "two strokes there. The Deuteronomy note does not say whether the same holds there.",
        "**Deuteronomy 5:8 atom 2, the meteg on the shin. Found.** MAM's note quotes the LC "
        "with the meteg on the shin, lacking only the "
        + T(TACHTON)
        + "'s qadma, and gives MAM's full form as that of the Aleppo Codex (marked uncertain), "
        "Sassoon 507 and St Petersburg EVR-II-B-10. WLC 4.20 has a merkha on that shin. So "
        "MAM's documentation puts this meteg in the LC, and the Exodus note says the Aleppo "
        "Codex and the LC agree on it in Deuteronomy.",
    ]
)

p(
    "**In short.** MAM's notes name both Sassoon manuscripts for the meteg on the shin at "
    "Exodus 20:4, with Firkovich B17, Cairo 18, the printed editions and, through Breuer, the "
    "Lehmann manuscript; and for the two strokes on the second yod at Exodus 20:3, with the "
    "printed editions. At Deuteronomy 5:7 the note gives MAM's form as that of both Sassoon "
    "manuscripts, Cairo 18, the Washington Pentateuch and the printed editions, without "
    "discussing the meteg. At Deuteronomy 5:8 MAM's documentation puts the meteg in the LC. "
    "MAM's appendix says the printed editions were almost never a consideration in "
    "establishing the text."
)

h(2, "The other cases in brief")
p(
    "Each item says what MAM's note says, its \"from\" meaning that the note gives MAM's form "
    "as that of the sources listed; none is this report's reading of a manuscript."
)

ol(
    [
        "**Exodus 20:5 atom 2, ḥataf pataḥ under the ḥet. Found.** From Firkovich B17, "
        "BL Or 4445, Sassoon 507, Sassoon 1053, Cairo 18, the Washington Pentateuch and the "
        "printed editions; the note says the LC has a shewa there, citing Dotan, Breuer and "
        "the typist (MAM's name for the Westminster typing, now the UXLC).",
        "**Exodus 20:3 atom 7 and Deuteronomy 5:7 atom 7, the "
        + T(ELYON)
        + "'s pataḥ under the nun. Exodus: nothing found on the pataḥ; Deuteronomy: found.** "
        "In Exodus MAM's text has the pataḥ through a template, and the one note at that atom "
        "is about the "
        + T(TACHTON)
        + "'s sof pasuq. In Deuteronomy the note gives MAM's form as that of the Aleppo Codex "
        "and the LC, both marked uncertain, Firkovich B17, Sassoon 507, Sassoon 1053, the "
        "Washington Pentateuch, "
        "St Petersburg EVR-II-B-10 and St Petersburg EVR-II-B-8; Cairo 18 has the marks in "
        "another order.",
        "**Deuteronomy 5:8 atom 2, the "
        + T(TACHTON)
        + "'s qadma. Found** (the note of case 3). From the Aleppo Codex (marked uncertain), "
        "Sassoon 507 and St Petersburg EVR-II-B-10; the note says the LC lacks it and that no "
        "editor has commented on that. In the note's quotation of the LC that shin has a "
        "meteg, where WLC 4.20 has a merkha; the note does not mention a merkha.",
        "**Deuteronomy 5:8 atom 12, the "
        + T(ELYON)
        + "'s pataḥ under the tav. Found.** From the LC (marked uncertain), Firkovich B17, "
        "Sassoon 507, Sassoon 1053, Cairo 18, the Washington Pentateuch and St Petersburg "
        "EVR-II-B-10; St Petersburg EVR-II-B-8 lacks it, \"and so the typing\".",
        "**Deuteronomy 5:12 atom 4 and 5:15 atom 23, the dagesh in the shin. Found, both.** "
        "At 5:12, from Sassoon 507, Sassoon 1053, Cairo 18, the Washington Pentateuch, "
        "St Petersburg EVR-II-B-10 and the printed editions, the note adding that it cannot be "
        "made out in the Aleppo photograph; at 5:15, from the Aleppo photograph (marked "
        "uncertain), Firkovich B17, "
        "Sassoon 507, Sassoon 1053, Cairo 18, the Washington Pentateuch, St Petersburg "
        "EVR-II-B-10, St Petersburg EVR-II-B-8, the printed editions and Koren. At both, the "
        "note says the LC lacks it, citing Dotan.",
        "**Genesis 35:22 atom 7, the "
        + T(MIDRASHIT)
        + "'s revia. Found.** Sassoon 507 and Minḥat Shai have revia and then zaqef qatan; the "
        "LC, Cairo 18, Codex Hilleli and Sassoon 82 have both in the reverse order; the note "
        "says that, on examination, the LC has the revia, which Breuer doubted, and that Dotan "
        "determined so too.",
        "**Deuteronomy 5:17 atom 2 and Exodus 20:3 atom 2, the "
        + T(TACHTON)
        + "'s tipeḥa and merkha. Found, both.** Deuteronomy: the tipeḥa is from the Aleppo "
        "photograph, Firkovich B17, Sassoon 507, Sassoon 1053, Cairo 18, the Washington "
        "Pentateuch, St Petersburg EVR-II-B-10 and St Petersburg EVR-II-B-8; the note says the "
        "LC lacks it and that Breuer takes the LC's one stroke as tipeḥa and silluq at once. "
        "Exodus: the note of "
        "case 2's parallel, one stroke in the LC taken by Dotan and Breuer as merkha and "
        "meteg at once.",
    ]
)

h(2, "What MAM's introduction says about its sources here")

p(
    "**The two main manuscripts.** Appendix line 8 (rendered without its markup):"
)
heb_block(intro_sent("appendices:8", 0, 1))
p(
    "That is: the edition is founded on photographs of the Aleppo Codex and the Leningrad "
    "Codex. Appendix line 40 adds that MAM checked further manuscripts in problematic places "
    "and, in most of the Torah, where the Aleppo Codex is missing, seven manuscripts in the "
    "order it checked them: the LC, Firkovich B17, BL Or 4445, Sassoon 507, Sassoon 1053, "
    "Cairo 18 and the Washington Pentateuch (lines 41 to 47). Line 49 says MAM used "
    "St Petersburg EVR-II-B-10 consistently at the end of Numbers and in Deuteronomy, and "
    "line 54 that it used St Petersburg EVR-II-B-8 mainly from the end of Numbers on. Line 19 "
    "describes the photographs of the Aleppo Codex taken while it was whole, two of whose "
    "pages are of Deuteronomy and include the Decalogue:"
)
heb_block(intro_sent("appendices:19", 0).lstrip("#"))

p(
    "**The LC is the main basis for points and accents in the Torah, but not for the meteg.** "
    "Chapter 3, line 705:"
)
heb_block(intro_sent("ch3:705", 0))
p(
    "And the footnote at line 703 excepts two matters from that conclusion, ḥataf vowels on "
    "non-guttural letters and the meteg (its second sentence):"
)
heb_block(intro_note("ch3:703", 2, 1, 2))
p("MAM's policy for the meteg in the Torah, chapter 3, line 1265, with its footnote:")
heb_block(intro_sent("ch3:1265", 0, 1))
heb_block(intro_note("ch3:1265", 1))
p(
    "That is: MAM copies the meteg marks of the Aleppo Codex where it exists, including "
    "those known from photographs of missing pages, and of the LC in most of the Torah. Its "
    "exceptions, line 1267, its last three sentences:"
)
heb_block(intro_sent("ch3:1267", 2, 3, 4))
assert len(INTRO["ch3:1267"]["sentences"]) == 5
p(
    "That is: Breuer listed about 40 anomalous meteg marks in the LC's Torah and corrected "
    "some of them where the Lehmann manuscript supported him; MAM corrected all that he "
    "listed, and dozens more, documenting the LC's form and the meteg marks of Firkovich "
    "B17, BL Or 4445, Sassoon 507, Sassoon 1053, Cairo 18 and the Washington Pentateuch. The "
    "list that follows (lines 1272 to 1280) has 98 items (line 1283); line 1274, for Exodus, "
    "has 14, and its ninth is case 1's verse in MAM's numbering:"
)
_c1_label = NOTES["1"]["mam_chapter_key"] + "," + NOTES["1"]["mam_verse_label"] + " "
_c1_items = [s for s in INTRO["ch3:1274"]["sentences"] if s.startswith(_c1_label)]
assert len(_c1_items) == 1 and INTRO["ch3:1274"]["sentences"].index(_c1_items[0]) == 9
heb_block(intro_sent("ch3:1274", 0) + " ... " + _c1_items[0])
deut_items = INTRO["ch3:1280"]["sentences"]
chap5_prefix = t_heb.w("he") + ","
assert not any(x.startswith(chap5_prefix) for x in deut_items[1:])
p(
    "The Deuteronomy list, line 1280, has 18 items and none in chapter 5, so MAM's "
    "introduction lists no meteg correction in the Deuteronomy Decalogue."
)
p("**The Lehmann manuscript is known only through Breuer.** Appendix line 61, its last sentence:")
_lm = [s for s in INTRO["appendices:61"]["sentences"] if "[^2]" in s]
assert len(_lm) == 1
heb_block(_lm[0].split("[^2]")[1].strip())
p("**The printed editions were almost never a consideration.** Appendix line 270, its second sentence:")
_bold_270 = re.findall(r"@@B@@(.*?)@@/B@@", INTRO["appendices:270"]["display"])
assert len(_bold_270) == 1
heb_block("@@B@@" + _bold_270[0] + "@@/B@@")
p(
    "**An exclamation mark after the LC's sigil.** Chapter 3, line 720, says MAM usually adds "
    "one after the LC's reading for a clear scribal error, and not for typical anomalies such "
    "as a missing dagesh:"
)
heb_block(intro_sent("ch3:720", 1, 2))
p(
    "**MAM's English Decalogue page** (`in/mam-ws-special/decalogue-en.mediawiki`, line 19) "
    "says of its charts: \""
    + intro_sent("decalogue-en:19", 2).split(" and it follows")[0]
    + "\", following Breuer's analysis."
)
p(
    "**Yeivin on the LC's merkha,** quoted in chapter 3, line 740: MAM's introduction quotes "
    "Yeivin that the LC marks the merkha less clearly than the Aleppo Codex, so that where "
    "the Aleppo Codex has a clear merkha the LC's mark often looks like a clear meteg. That "
    "is Yeivin's general statement as MAM quotes it; no note on these cases cites it."
)

# ---------------------------------------------------------------- per case

h(2, "The cases in detail")
p(
    "Each case ends with lookup lines copied from `py/main_verse_links.py`: MwD and MM from "
    "a run with MAM's verse number, the rest from a run with BHS's verse and atom."
)

# Case 1
h(3, "Case 1. Exodus 20:4 atom 2 (MAM's Exodus 20:3): the meteg on the shin")
p("**Disposition: found.** MAM's note names its sources, and MAM's introduction lists the verse among its meteg corrections.")
forms_table("1")
p(
    "WLC 4.20 has the meteg on the tav, MAM's "
    + T(ELYON)
    + " on the shin. MAM's note is on the chanted word "
    + show(target_of("1"))
    + ", at "
    + where("1")
    + "."
)
doc_table(
    "1",
    [
        "MAM's form is that of Firkovich B17, the Lehmann manuscript, Sassoon 507, Sassoon "
        "1053, Cairo 18 and the printed editions: a maqaf for the "
        + T(TACHTON)
        + ", another for the "
        + T(ELYON)
        + ", and the "
        + T(ELYON)
        + "'s meteg on the shin. And likewise the Aleppo Codex and the LC in Deuteronomy.",
        "The LC, marked with an exclamation mark, has the form quoted: no maqaf after "
        + hu(WORD["LO"])
        + " for the "
        + T(TACHTON)
        + ", and the "
        + T(ELYON)
        + "'s meteg on the tav. Breuer corrected the meteg's place here according to the "
        "Lehmann manuscript, and so has Mechon Mamre; Dotan left it on the tav according to "
        "the LC (\"and so Simanim, the printed editions and Koren\").",
        "Cairo 18 has the form quoted, lacking the maqaf after "
        + hu(WORD["TAASE"])
        + " for the "
        + T(ELYON)
        + ".",
        "Notes of Dotan and Breuer.",
    ],
)
p(
    "**Unresolved in the note's text.** Doc-part 1 counts the printed editions with the "
    "shin; doc-part 2's closing parenthesis, which follows Dotan's tav, seems to count them "
    "with the tav. The note does not reconcile the two, and this report does not try to."
)
p(
    "**Elsewhere in MAM's introduction.** The meteg corrections list (chapter 3, line 1274, "
    "quoted above) has this verse. The list of anomalies in the LC's points and accents "
    "(chapter 3, line 886) has the same chanted word for the missing maqaf only:"
)
heb_block(INTRO["ch3:886"]["display"].lstrip("#"))
lookups("Exodus", "20:4", 2, "20:3")

# Case 2
h(3, "Case 2. Deuteronomy 5:7 atom 2 (MAM's Deuteronomy 5:6): the meteg on the second yod")
p(
    "**Disposition: found in part.** The note names the sources of MAM's form but explains "
    "only the maqaf; MAM's note on the parallel chanted word in Exodus (case 10, Exodus 20:3) "
    "explains the meteg."
)
forms_table("2")
tmpl_2 = note_of("2")["templates_in_target"]
assert len(tmpl_2) == 1
p(
    "MAM's note is on the chanted word "
    + show(target_of("2"))
    + ", at "
    + where("2")
    + ". Its second atom has the template "
    + hu(tmpl_2[0][0])
    + " after the merkha on the second yod; MAM-basics' `py/mpplus/mpplus_boring_tmpls.py` "
    "renders that template as a CGJ followed by U+05BD. MAM's appendix does not list the "
    "template, and its Wikisource page is not mirrored."
)
doc_table(
    "2",
    [
        "MAM's form is that of Sassoon 507, Sassoon 1053, Cairo 18 and the Washington "
        "Pentateuch, and likewise the printed editions.",
        "The LC (exclamation mark), Firkovich B17 (question mark) and St Petersburg "
        "EVR-II-B-10 have the form quoted, lacking the maqaf after "
        + hu(WORD["LO"])
        + " for the "
        + T(TACHTON)
        + "; as quoted, it has a merkha alone on the second yod. The Aleppo Codex's "
        "photograph also seems to lack the maqaf at the end of the line, but that is hard to "
        "make out. Firkovich B17, Cairo 18, the Washington Pentateuch and St Petersburg EVR-II-B-8 "
        "have a meteg on the first yod.",
    ],
)
p(
    "**The parallel note in Exodus (BHS Exodus 20:3 atom 2, MAM's Exodus 20:2), on the "
    "parallel chanted word** "
    + show(target_of("2-par"))
    + ", at "
    + where("2-par")
    + ":"
)
doc_table(
    "2-par",
    [
        "MAM's form is that of Sassoon 507, Sassoon 1053 and the printed editions: for the "
        + T(TACHTON)
        + " a maqaf and a merkha stroke; for the "
        + T(ELYON)
        + " a meteg stroke, on the second yod, and a maqaf.",
        "The LC, Firkovich B17, BL Or 4445, Cairo 18 and the Washington Pentateuch have the "
        "form quoted, with one stroke only on the second yod, slanting like a merkha; "
        "according to Dotan and Breuer that stroke serves as the "
        + T(TACHTON)
        + "'s merkha and the "
        + T(ELYON)
        + "'s meteg at once. The LC and the Washington Pentateuch (and perhaps Firkovich B17) "
        "lack the maqaf after "
        + hu(WORD["LO"])
        + " for the "
        + T(TACHTON)
        + ". BL Or 4445, Cairo 18 and the Washington Pentateuch have a meteg on the first yod.",
        "Notes of Dotan and Breuer.",
    ],
    i=0,
)
p(
    "MAM's list of the LC's anomalies (chapter 3, line 885) says the same of Exodus, and "
    "line 1070 records only the missing maqaf for Deuteronomy:"
)
heb_block(INTRO["ch3:885"]["display"].lstrip("#"))
heb_block(INTRO["ch3:1070"]["display"].lstrip("#"))
p(
    "Neither meteg corrections list (Exodus, line 1274; Deuteronomy, line 1280) has an item "
    "for this chanted word, so MAM's introduction does not treat this meteg as a correction "
    "of the LC."
)
lookups("Deuter", "5:7", 2, "5:6")

# Case 3 (and 6)
h(3, "Cases 3 and 6. Deuteronomy 5:8 atom 2 (MAM's Deuteronomy 5:7): the meteg on the shin, and the qadma")
p(
    "**Disposition: found, both.** One note covers the "
    + T(ELYON)
    + "'s meteg (case 3) and the "
    + T(TACHTON)
    + "'s qadma (case 6)."
)
forms_table("1-par")
p(
    "WLC 4.20 has a merkha on the shin; MAM's "
    + T(TACHTON)
    + " has a qadma there and its "
    + T(ELYON)
    + " a meteg. MAM's note is on the chanted word "
    + show(target_of("1-par"))
    + ", at "
    + where("1-par")
    + "."
)
doc_table(
    "1-par",
    [
        "MAM's form is that of the Aleppo Codex (question mark), Sassoon 507 and "
        "St Petersburg EVR-II-B-10.",
        "The LC, marked with an exclamation mark, has the form quoted, lacking the qadma on "
        "the shin for the "
        + T(TACHTON)
        + "; no editor has commented on this. As quoted, the LC's form has a meteg (U+05BD) "
        "on the shin.",
        "On "
        + hu(WORD["LO"])
        + ": Sassoon 1053 has a munaḥ before a merkha; Firkovich B17 and Cairo 18 have a munaḥ "
        "alone; the Washington Pentateuch has a munaḥ alone on "
        + hu(WORD["LO"])
        + " and on "
        + hu(WORD["LEKHA"])
        + ".",
    ],
)
p(
    "The Exodus note of case 1 adds, in its first doc-part, \"and likewise the manuscripts "
    "Aleppo and LC in Deuteronomy\", with no question mark on the Aleppo Codex. MAM's list "
    "of the LC's anomalies (chapter 3, line 1071) records the missing qadma; the "
    "Deuteronomy meteg corrections list has no item here."
)
heb_block(INTRO["ch3:1071"]["display"].lstrip("#"))
lookups("Deuter", "5:8", 2, "5:7")

# Case 4
h(3, "Case 4. Exodus 20:5 atom 2 (MAM's Exodus 20:4): ḥataf pataḥ under the ḥet")
p("**Disposition: found.**")
forms_table("4")
p("MAM's note is on the chanted word " + show(target_of("4")) + ", at " + where("4") + ".")
doc_table(
    "4",
    [
        "MAM's form is that of Firkovich B17, BL Or 4445, Sassoon 507, Sassoon 1053, Cairo 18, "
        "the Washington Pentateuch and the printed editions.",
        "The LC, marked with an exclamation mark, has the form quoted, its ḥet with a shewa "
        "in place of a ḥataf pataḥ.",
        "Notes of Dotan, Breuer and the typist.",
    ],
)
p(
    "MAM's list of the LC's anomalies (chapter 3, line 890) has the same. The Deuteronomy "
    "parallel (BHS Deuteronomy 5:9, MAM's 5:8) has no note on that chanted word."
)
assert not NOTES["4-par"]["notes"]
lookups("Exodus", "20:5", 2, "20:4")

# Case 5
h(3, "Case 5. Exodus 20:3 atom 7 and Deuteronomy 5:7 atom 7: the pataḥ under the nun")
p(
    "**Disposition: Exodus, nothing found on the pataḥ; Deuteronomy, found.**"
)
forms_table("5a")
forms_table("5b")
p(
    "WLC 4.20 has the pataḥ after the yod in both verses; MAM's "
    + T(ELYON)
    + " has it under the nun. In both books MAM's wikitext has the template "
    + hu(tmpln.TWO_ACCENTS_OF_QUPO)
    + " at this atom; in Exodus the chanted word's raw wikitext is `"
    + hu(ATOM_5A_RAW)
    + "`. MAM's appendix (line 418) names only the general template "
    + hu(INTRO["appendices:418"]["display"].split(" - ")[0].split(":")[-1])
    + ", for the Decalogue's dual accentuation."
)
p(
    "**Exodus (MAM's Exodus 20:2).** No note is on the pataḥ. The one note at this atom is "
    "on the sof pasuq after it (`in/mam-ws/A2-Exodus.json`, the same verse; published in "
    "MAM-with-doc at "
    + SOFPASUQ_5A_PUB
    + "):"
)
table(
    ["Doc-part", "MAM's note, verbatim", "English summary"],
    [
        ["doc-part 1", SOFPASUQ_5A_PARTS[0], "The sof pasuq, for the " + T(TACHTON) + ", is that of Firkovich B17, Sassoon 507, Cairo 18 and the Washington Pentateuch."],
        ["doc-part 2", SOFPASUQ_5A_PARTS[1], "The LC, BL Or 4445 and Sassoon 1053 lack the sof pasuq for the " + T(TACHTON) + "."],
    ],
    rtl_cols=(1,),
)
assert len(SOFPASUQ_5A_PARTS) == 2
p(
    "**Deuteronomy (MAM's Deuteronomy 5:6).** MAM's note is on the chanted word "
    + show(target_of("5b"))
    + ", at "
    + where("5b")
    + ":"
)
doc_table(
    "5b",
    [
        "MAM's form is that of the Aleppo Codex (question mark), the LC (question mark), "
        "Firkovich B17, Sassoon 507, Sassoon 1053, the Washington Pentateuch, St Petersburg "
        "EVR-II-B-10 and St Petersburg EVR-II-B-8: qamats and silluq for the "
        + T(TACHTON)
        + " before pataḥ for the "
        + T(ELYON)
        + ".",
        "Cairo 18 has qamats, pataḥ and silluq.",
    ],
)
p(
    "The note does not say why the Aleppo Codex and the LC are marked uncertain, and does not "
    "mention a pataḥ after the yod."
)
lookups("Exodus", "20:3", 7, "20:2")
lookups("Deuter", "5:7", 7, "5:6")

# Case 7
h(3, "Case 7. Deuteronomy 5:8 atom 12 (MAM's Deuteronomy 5:7): the pataḥ under the tav")
p("**Disposition: found.**")
forms_table("7")
p("MAM's note is on the atom " + show(target_of("7")) + ", at " + where("7") + ".")
doc_table(
    "7",
    [
        "MAM's form is that of the LC (question mark), Firkovich B17, Sassoon 507, Sassoon "
        "1053, Cairo 18, the Washington Pentateuch and St Petersburg EVR-II-B-10: qamats, "
        "atnaḥ, pataḥ and azla.",
        "St Petersburg EVR-II-B-8 has the form quoted, with no second pataḥ on the tav for the "
        + T(ELYON)
        + ", and so has the typing (the Westminster typing, now the UXLC).",
    ],
)
p(
    "MAM's word for the "
    + T(ELYON)
    + "'s accent here is azla; the code point MAM's "
    + T(ELYON)
    + " has is Hebrew Accent Geresh (U+059C). In Exodus the parallel atom, BHS Exodus 20:4 "
    "atom 12, has a typing note only, at "
    + where_short("7-par")
    + ":"
)
doc_table(
    "7-par",
    [
        "Qamats and atnaḥ are typed on the tav first, for the "
        + T(TACHTON)
        + ", and then pataḥ and azla, for the "
        + T(ELYON)
        + "."
    ],
)
lookups("Deuter", "5:8", 12, "5:7")

# Case 8
h(3, "Case 8. Deuteronomy 5:12 atom 4 and 5:15 atom 23: the dagesh in the shin")
p("**Disposition: found, both.**")
forms_table("8a")
forms_table("8b")
p("**Deuteronomy 5:12 (MAM's 5:11).** MAM's note is on " + show(target_of("8a")) + ", at " + where("8a") + ":")
doc_table(
    "8a",
    [
        "MAM's form is that of Sassoon 507, Sassoon 1053, Cairo 18, the Washington Pentateuch "
        "and St Petersburg EVR-II-B-10, and likewise the printed editions; in the Aleppo "
        "Codex's photograph it cannot be made out.",
        "The LC, marked with an exclamation mark, has the form quoted, lacking the dagesh in "
        "the shin.",
        "Dotan's note.",
    ],
)
p("**Deuteronomy 5:15 (MAM's 5:14).** MAM's note is on " + show(target_of("8b")) + ", at " + where("8b") + ":")
doc_table(
    "8b",
    [
        "MAM's form is that of the Aleppo Codex's photograph (question mark), Firkovich B17, "
        "Sassoon 507, Sassoon 1053, Cairo 18, the Washington Pentateuch, St Petersburg "
        "EVR-II-B-10 and St Petersburg EVR-II-B-8, and likewise the printed editions and Koren.",
        "The LC, marked with an exclamation mark, has the form quoted, lacking the dagesh in "
        "the shin.",
        "Dotan's note.",
    ],
)
p(
    "MAM's list of the LC's anomalies (chapter 3, lines 1072 and 1076) has both. The Exodus "
    "parallels (BHS Exodus 20:8 and 20:11) have notes of the same shape, at "
    + where_short("8-par-a")
    + " and "
    + where_short("8-par-b")
    + "; the first ends \"Dotan and Breuer; the typist corrected it without comment\"."
)
p(
    "MAM's introduction also reproduces, on its Westminster-typing subpage "
    "(`in/mam-ws-intro/westminster-typing.mediawiki`, lines 1263 and 1264), WLC's list of "
    "changes from version 4.12 to 4.14, in which WLC dropped this dagesh at both places and "
    "added its notes Q and p. That is WLC's documentation as MAM reproduces it, not MAM's "
    "judgment:"
)
table(
    ["Position", "WLC 4.12", "WLC 4.14", "WLC's description"],
    westminster_rows(),
    rtl_cols=(1, 2),
)
lookups("Deuter", "5:12", 4, "5:11")
lookups("Deuter", "5:15", 23, "5:14")

# Case 9
h(3, "Case 9. Genesis 35:22 atom 7: the " + T(MIDRASHIT) + "'s revia")
p("**Disposition: found.**")
forms_table("9")
p(
    "WLC 4.20 has only the "
    + T(PESHUTA)
    + "'s zaqef qatan. MAM's note is on "
    + show(target_of("9"))
    + ", at "
    + where("9")
    + "."
)
doc_table(
    "9",
    [
        "MAM's form is that of Sassoon 507 and Minḥat Shai: revia, then zaqef qatan. The "
        "masora qetannah of Sassoon 507 has the note quoted, which says the verse has two "
        "accentuations and gives the accents of the first, beginning with a zaqef qatan on "
        "Reuben.",
        "The LC, Cairo 18, Codex Hilleli and Sassoon 82 have the form quoted: zaqef qatan and "
        "revia, in the reverse order.",
        "Breuer was in doubt whether the LC has the revia, but on examining the manuscript it "
        "turns out that it does, and so Dotan determined too.",
    ],
)
p(
    "MAM's list of the LC's anomalies (chapter 3, line 807) records the reverse order. "
    "MAM's introduction's section on the Reuben verse (chapter 3, lines 1362 to 1399, based, "
    "its footnote says, on Breuer's Keter, appendix 2, pp. 289 to 292) says that in this "
    "verse the midrashic accentuation is written first and the ordinary one second, the "
    "reverse of the Decalogue's order (line 1378), and that the masora qetannah note in "
    "Sassoon 507 names the ordinary one, written second, \""
    + hu(WORD["TAAMA_QADMA"])
    + "\" (lines 1380 to 1383). The section reproduces a shorter form of the note "
    "(line 1367), on "
    + show(INTRO_GEN_TARGET)
    + ":"
)
assert WORD["TAAMA_QADMA"] in INTRO["ch3:1383"]["raw"]
table(
    ["Doc-part", "MAM's note, verbatim", "English summary"],
    [
        ["doc-part 1", INTRO_GEN_PARTS[0], "Sassoon 507 and Minḥat Shai: revia and zaqef qatan."],
        ["doc-part 2", INTRO_GEN_PARTS[1], "The LC: zaqef qatan and revia, in the reverse order."],
        ["doc-part 3", INTRO_GEN_PARTS[2], "As in the chapter's note."],
    ],
    rtl_cols=(1,),
)
assert len(INTRO_GEN_PARTS) == 3
typo_name = [n for _, _, n, _, _, _ in wt.walk_templates(INTRO_GEN_PARTS[1])]
p(
    "**Incidental, not acted on (MAM's text, read-only task).** The second doc-part of that "
    "copy calls its template "
    + hu(typo_name[0])
    + ", where the target and the chapter's note use "
    + hu([n for _, _, n, _, _, _ in wt.walk_templates(INTRO_GEN_TARGET)][0])
    + "; it looks like a misspelling in MAM's introduction."
)
lookups("Genesis", "35:22", 7, None)

# Case 10
h(3, "Case 10. Deuteronomy 5:17 atom 2 and Exodus 20:3 atom 2: the " + T(TACHTON) + "'s tipeḥa and merkha")
p("**Disposition: found, both.**")
forms_table("10a")
forms_table("10b")
p(
    "**Deuteronomy 5:17 (MAM's 5:16).** MAM's note is on "
    + show(target_of("10a"))
    + ", at "
    + where("10a")
    + ":"
)
doc_table(
    "10a",
    [
        "MAM's form is that of the Aleppo Codex's photograph, Firkovich B17, Sassoon 507, "
        "Sassoon 1053, Cairo 18, the Washington Pentateuch, St Petersburg EVR-II-B-10 (tipeḥa, "
        "qamats and silluq, in that order) and St Petersburg EVR-II-B-8 (qamats, tipeḥa and "
        "silluq on the tsadi).",
        "The LC, with no exclamation mark, has the form quoted, lacking the tipeḥa for the "
        + T(TACHTON)
        + "; according to Breuer, the vertical stroke under the tsadi serves in the LC as "
        "tipeḥa and silluq at once.",
        "Notes of Dotan and Breuer.",
    ],
)
p(
    "MAM's list of the LC's anomalies (chapter 3, line 1077) has the same, with Breuer's "
    "proposal in a footnote. The Exodus parallel (BHS Exodus 20:13, MAM's 20:12), at "
    + where("10a-par")
    + ":"
)
doc_table(
    "10a-par",
    [
        "MAM's form is that of the LC, Firkovich B17, BL Or 4445, Sassoon 507, Sassoon 1053, "
        "Cairo 18 and the Washington Pentateuch: on the tsadi one qamats for both strands, a "
        "tipeḥa for the "
        + T(TACHTON)
        + " and a silluq for the "
        + T(ELYON)
        + ".",
        "Minḥat Shai and the printed editions have the form quoted, pataḥ and tipeḥa for the "
        + T(TACHTON)
        + " and qamats and silluq for the "
        + T(ELYON)
        + ", and so has Koren.",
        "The rafe was kept here for clarity (and likewise in "
        + hu(WORD["TNAF"])
        + " and "
        + hu(WORD["TGNV"])
        + ") even in editions that usually omit it, BHS and Breuer's among them.",
    ],
)
p(
    "**Exodus 20:3 atom 2 (MAM's 20:2).** The note is the Exodus note under case 2: the LC "
    "has one stroke on the second yod, slanting like a merkha, which Dotan and Breuer take "
    "as the "
    + T(TACHTON)
    + "'s merkha and the "
    + T(ELYON)
    + "'s meteg at once. WLC 4.20 has a meteg (U+05BD) alone there."
)
lookups("Deuter", "5:17", 2, "5:16")
lookups("Exodus", "20:3", 2, "20:2")

# ---------------------------------------------------------------- sigils

h(2, "The sigils in these notes, as MAM's appendix identifies them")
SIGROWS = [
    ("L", "the Leningrad Codex (St Petersburg, EVR I B 19a), one of the edition's two main manuscripts", "8, 24, 25"),
    ("A", "the Aleppo Codex, the other main manuscript", "8, 10, 11"),
    ("A_PHOTO", "photographs of a few Torah pages taken while the Aleppo Codex was whole, two of them of Deuteronomy with the Decalogue (also written " + hu(SIG["A_PHOTO_HYPHEN"]) + ")", "19"),
    ("L1", "St Petersburg, Firkovich B 17, written in 930 by Solomon ben Buya'a, the scribe of the Aleppo Codex's letters", "42"),
    ("B", "London, British Library Or 4445, end of the ninth century; its original part runs from Genesis 39:20 to Deuteronomy 1:32", "43"),
    ("S", "the Damascus Keter, Sassoon 507, tenth century", "44"),
    ("S1", "Sassoon 1053, beginning of the tenth century", "45"),
    ("Q3", "Cairo 18, eastern script, tenth century, corrected by Mishael ben Uzziel and very close to the Aleppo Codex", "46"),
    ("V", "Museum of the Bible, Washington, Ms. 882 (this report's Washington Pentateuch), eastern script, eleventh century", "47"),
    ("L3", "St Petersburg EVR-II-B-10 (Tanis, 946), used consistently at the end of Numbers and in Deuteronomy", "49, 50"),
    ("EVR8", "St Petersburg EVR-II-B-8, a Torah by Zechariah ben Anan (1020), used mainly from the end of Numbers", "54"),
    ("LM", "the Lehmann manuscript, by Samuel ben Jacob, the LC's scribe and masorete; its whereabouts are unknown, and every report of it, mainly of its meteg marks, comes from Breuer", "61"),
    ("H", "Codex Hilleli, JTS 401, Toledo, 1241", "188"),
    ("S2", "the Keter Shem Tov, Sassoon 82, Spain, 1312", "194"),
    ("MS", "Minḥat Shai, which MAM consulted regularly", "225"),
    ("DFUSIM", "selected printed editions from the early nineteenth to the early twentieth century, not the Venice Miqra'ot Gedolot; almost never a consideration in establishing the text", "270, 272"),
    ("BREUER", "Breuer's three editions", "258"),
    ("MECHON_MAMRE", "Mechon Mamre's online edition, based on Breuer's", "259"),
    ("SIMANIM", "the Simanim Tanakh (Feldheim), partly based on the Aleppo Codex", "261"),
    ("DOTAN", "Dotan's editions, BHL among them", "265"),
    ("HAQLADA", "the typing (also " + hu(SIG["HAMAQLID"]) + ", the typist): the Westminster typing, now the UXLC, originally based on BHS", "266"),
    ("KOREN", "the Koren Tanakh (1962)", "281"),
]
table(
    ["Sigil", "MAM's appendix says", "Appendix line"],
    [[hu(SIG[k]), d, ln] for k, d, ln in SIGROWS],
)
p(
    "The qualifier "
    + hu(SIG["MQ"])
    + " in Genesis 35:22's note is the masora qetannah: MAM's introduction calls the same note "
    "a special masora note in the masora qetannah of Sassoon 507 (chapter 3, line 1380). A "
    "question mark after a sigil is not defined in what I read of MAM's appendix; MAM-basics' "
    "`doc/sigil-decoding.md` treats it as marking uncertainty, and this report says \"marked "
    "uncertain\"."
)

# ---------------------------------------------------------------- method

h(2, "Where I looked")
ul(
    [
        "MAM's chapter wikitext, mirrored in `in/mam-ws/A1-Genesis.json`, `A2-Exodus.json` and "
        "`A5-Deuter.json` (last changed in commit `0d865e49`, 2026-11-03T11:04:35-05:00; "
        "working tree at `374d9436`, those paths clean): every note template whose target has "
        "the case atom's letters, in the MAM verse that holds the atom. The extraction is "
        "`scripts/t_doc_notes.py`, its output `scratch-t/doc_notes.json`.",
        "Check: at every case atom, each strand's MAM form in `22-clc-answers.json` occurs, "
        "after `give_std_mark_order` on both sides, in that strand's parameter of MAM's "
        "dual-cantillation template in the mirror, so the JSON and the mirror have the same "
        "MAM text at these atoms.",
        "MAM-with-doc's pages in `gh-pages/MAM-with-doc/`, only to find where each note is "
        "published; they show the same notes.",
        "The mirrored introduction, `in/mam-ws-intro/`: chapter 2's Decalogue section (lines "
        "359 to 389, display only, nothing on these forms), chapter 3's sections on the LC as "
        "basis (697 to 760), the LC's anomalies (761 to 1131), the meteg (1148 to 1309), the "
        "Decalogues and the Reuben verse (1310 to 1400), the appendix's sources and templates, "
        "and the Westminster-typing subpage.",
        "The special pages, `in/mam-ws-special/decalogue*.mediawiki`: no notes; the English "
        "page's line 19 is quoted above.",
        "Not available locally, so not used: the Wikisource pages of MAM's templates. No "
        "manuscript image was consulted; every statement here about a manuscript is MAM's "
        "documentation's.",
    ]
)

h(2, "Chapter links")
p("Chapter-level lines from the same command, once per chapter:")
md_lines(
    link_lines("Exodus", "20:2", ["mgketer", "MAM-ws", "CTR"], "mam")
    + link_lines("Deuter", "5:6", ["mgketer", "MAM-ws", "CTR"], "mam")
    + [x for x in bhs_link_lines("Genesis", "35:22", 7, ["mgketer", "MAM-ws"])]
)
p(
    "The `tica` lines above open the Aleppo Codex at masoretica.org. MAM's appendix (line 40) "
    "says the codex lacks most of the Torah, and the caption at chapter 3, line 1313, says its "
    "photographs show Deuteronomy 4:38 to 6:3; I did not check what masoretica.org shows for "
    "these verses. The LC page "
    "lines are the estimator's interpolation, not readings of the image; their atom numbers "
    "are the UXLC's, which equal BHS's in these verses (checked against the command's atom "
    "listings)."
)

# ---------------------------------------------------------------- renderers

LINK_RE = re.compile(r"\[([^\]]+)\]\(([^)\s]+)\)")


def assert_no_bare_hebrew(t, where_):
    stripped = re.sub(r"@@([HU])@@.*?@@/\1@@", "", t, flags=re.DOTALL)
    if HEB_RUN.search(stripped):
        raise ValueError(f"bare Hebrew in LTR text ({where_}): {stripped[:120]!r}")


def md_inline(t):
    t = re.sub(r"@@/?[HU]@@", "", t)
    t = t.replace("@@B@@", "**").replace("@@/B@@", "**")
    return t


def md_cell(t, rtl):
    t = md_inline(t)
    t = re.sub(r"\[\^(\d+)\]", r"(note \1)", t)
    t = t.replace("|", "\\|").replace("\n", " ")
    return t


def html_inline(t, rtl=False):
    t = re.sub(r"\[\^(\d+)\]", r"(note \1)", t)
    links = []

    def keep_link(m):
        links.append((m.group(1), m.group(2)))
        return f"@@L{len(links) - 1}@@"

    t = LINK_RE.sub(keep_link, t)
    t = html.escape(t, quote=False)
    t = t.replace("&lt;sup&gt;", "<sup>").replace("&lt;/sup&gt;", "</sup>")
    t = re.sub(r"`([^`]+)`", r"<code>\1</code>", t)
    t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
    t = t.replace("@@B@@", "<b>").replace("@@/B@@", "</b>")
    t = re.sub(r"@@H@@(.*?)@@/H@@", r'<span lang="hbo" dir="rtl">\1</span>', t, flags=re.DOTALL)
    t = re.sub(r"@@U@@(.*?)@@/U@@", r"<bdi>\1</bdi>", t, flags=re.DOTALL)
    if rtl:
        def wrap(m):
            run = m.group()
            return f'<span lang="hbo">{run}</span>' if is_pointed(run) else run

        t = re.sub(
            r"(<[^>]*>)|([" + HEB_CHARS + r"]+)",
            lambda m: m.group(1) if m.group(1) else wrap(m),
            t,
        )

    def put_link(m):
        label, url = links[int(m.group(1))]
        return f'<a href="{html.escape(url)}">{html_inline(label)}</a>'

    t = re.sub(r"@@L(\d+)@@", put_link, t)
    return t


def render_md():
    out = []
    for b in BLOCKS:
        kind = b[0]
        if kind == "caveat":
            out.append(b[1])
            out.append("")
        elif kind in ("h1", "h2", "h3"):
            assert_no_bare_hebrew(b[1], kind)
            out.append("#" * int(kind[1]) + " " + md_inline(b[1]))
            out.append("")
        elif kind == "p":
            assert_no_bare_hebrew(b[1], "p")
            out.append(md_inline(b[1]))
            out.append("")
        elif kind in ("ul", "ol"):
            for i, it in enumerate(b[1], start=1):
                assert_no_bare_hebrew(it, kind)
                lead = "-" if kind == "ul" else f"{i}."
                out.append(f"{lead} {md_inline(it)}")
            out.append("")
        elif kind == "table":
            _, headers, rows, rtl_cols = b
            out.append("| " + " | ".join(md_cell(x, False) for x in headers) + " |")
            out.append("| " + " | ".join("---" for _ in headers) + " |")
            for row in rows:
                for j, c in enumerate(row):
                    if j not in rtl_cols:
                        assert_no_bare_hebrew(c, "table cell")
                out.append(
                    "| " + " | ".join(md_cell(c, j in rtl_cols) for j, c in enumerate(row)) + " |"
                )
            out.append("")
        elif kind == "heb":
            t = md_cell(b[1], True).replace("\\|", "|")
            out.append("> Hebrew, verbatim: " + t)
            out.append("")
        elif kind == "mdlines":
            out.extend(b[1])
            out.append("")
    return "\n".join(out).rstrip() + "\n"


CSS = """
@font-face { font-family: "Taamey D"; src: url("../../../gh-pages/woff2/Taamey_D.woff2") format("woff2"); }
:root { --bg: #ffffff; --fg: #1a1a1a; --rule: #b8b8b8; --box: #fff6e0; --boxrule: #b07000; --link: #0645ad; }
@media (prefers-color-scheme: dark) { :root { --bg: #161616; --fg: #e8e8e8; --rule: #555; --box: #2e2412; --boxrule: #c89020; --link: #8ab4f8; } }
body { background: var(--bg); color: var(--fg); font-family: system-ui, sans-serif; line-height: 1.5; max-width: 64em; margin: 1em auto; padding: 0 16px; }
a { color: var(--link); }
:lang(hbo) { font-family: "Taamey D", serif; font-size: 140%; }
table { border-collapse: collapse; margin: 0.6em auto; }
th, td { border: 1px solid var(--rule); padding: 0.3em 0.6em; vertical-align: top; }
td[dir="rtl"] { text-align: right; }
p.caveat { border: 2px solid var(--boxrule); background: var(--box); padding: 0.6em 0.8em; }
blockquote { border-inline-start: 3px solid var(--rule); margin: 0.5em 1em; padding: 0.2em 0.8em; }
code { font-size: 90%; }
ul.links { list-style: none; padding-left: 1em; }
"""


def render_html():
    out = [
        "<!doctype html>",
        '<html lang="en">',
        "<head>",
        '<meta charset="utf-8">',
        '<meta name="viewport" content="width=device-width, initial-scale=1">',
        "<title>MAM Decalogue documentation</title>",
        "<style>" + CSS + "</style>",
        "</head>",
        "<body>",
    ]
    for b in BLOCKS:
        kind = b[0]
        if kind == "caveat":
            out.append(f'<p class="caveat">{html_inline(b[1])}</p>')
        elif kind in ("h1", "h2", "h3"):
            out.append(f"<{kind}>{html_inline(b[1])}</{kind}>")
        elif kind == "p":
            out.append(f"<p>{html_inline(b[1])}</p>")
        elif kind in ("ul", "ol"):
            out.append(f"<{kind}>")
            for it in b[1]:
                out.append(f"<li>{html_inline(it)}</li>")
            out.append(f"</{kind}>")
        elif kind == "table":
            _, headers, rows, rtl_cols = b
            out.append("<table>")
            out.append("<tr>" + "".join(f"<th>{html_inline(x)}</th>" for x in headers) + "</tr>")
            for row in rows:
                cells = []
                for j, c in enumerate(row):
                    if j in rtl_cols:
                        cells.append(f'<td dir="rtl">{html_inline(c, rtl=True)}</td>')
                    else:
                        cells.append(f"<td>{html_inline(c)}</td>")
                out.append("<tr>" + "".join(cells) + "</tr>")
            out.append("</table>")
        elif kind == "heb":
            out.append(f'<blockquote dir="rtl">{html_inline(b[1], rtl=True)}</blockquote>')
        elif kind == "mdlines":
            out.append('<ul class="links">')
            for line in b[1]:
                item = line[2:] if line.startswith("- ") else line
                out.append(f"<li>{html_inline(item)}</li>")
            out.append("</ul>")
    out += ["</body>", "</html>"]
    return "\n".join(out) + "\n"


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    OUT_MD.parent.mkdir(parents=True, exist_ok=True)
    OUT_MD.write_text(render_md(), encoding="utf-8", newline="\n")
    OUT_HTML.write_text(render_html(), encoding="utf-8", newline="\n")
    print(f"wrote {OUT_MD} and {OUT_HTML}")


main()

"""Write the decision page from its prose template and its generated fragments.

Adapted from folder S's scripts/make_decision_page.py. Usage:
  python -I make_decision_page.py <template.html> <fragments-dir> <out.html>

The template holds the page's prose, written by hand. It may contain unpointed Hebrew (strand
names) but no Hebrew point or accent: the script raises if it finds one, so that every pointed
form on the page comes from a fragment that a script copied from data. A placeholder {{NAME}}
is replaced by <fragments-dir>/NAME.html. In the template's text (not its tags), each run of
unpointed Hebrew is isolated in a <bdi> with no lang, so that it keeps the surrounding font.

The page embeds MAM-basics' Taamey D web font as a data URI, since the artifact's content policy
blocks other font hosts, and sets pointed Hebrew in it at 140%.
"""

import base64
import re
import sys
from pathlib import Path

MB = Path("C:/Users/BenDe/GitRepos/MAM-basics")
MARK = re.compile("[\u0591-\u05c7]")
HEB_RUN = re.compile(
    "[\u05d0-\u05ea\u05f0-\u05f4][\u05d0-\u05ea\u05f0-\u05f4\u05be\u05c3 ]*[\u05d0-\u05ea\u05f0-\u05f4]|[\u05d0-\u05ea\u05f0-\u05f4]"
)
PLACEHOLDER = re.compile(r"\{\{([A-Z0-9_]+)\}\}")

STYLE = """
/* Layout: one reading column; the decisions first, each with what raises it, the choices and a
   recommendation; the findings and the draft after them. */
:root {
  --bg: #f5f6f3; --surface: #ffffff; --fg: #1d2226; --muted: #5a636b; --rule: #d5d9d2;
  --accent: #2b5f7f; --open: #8a5a00; --open-bg: #fff2d4; --done: #2e6b3a; --done-bg: #e4f1e6;
  --code-bg: #eceee9; --mark: #a8321f; --mark-bg: #fbe5df;
  --sans: "IBM Plex Sans", "Segoe UI", system-ui, sans-serif;
  --mono: "IBM Plex Mono", ui-monospace, Consolas, monospace;
}
@media (prefers-color-scheme: dark) { :root:not([data-theme="light"]) {
  --bg: #15191c; --surface: #1c2125; --fg: #e3e6e8; --muted: #9ca5ad; --rule: #333a40;
  --accent: #86bbdc; --open: #f0c060; --open-bg: #3a2f17; --done: #8fd19c; --done-bg: #1d3323;
  --code-bg: #242a2f; --mark: #ff9a85; --mark-bg: #4a221b;
  color-scheme: dark; } }
:root[data-theme="dark"] {
  --bg: #15191c; --surface: #1c2125; --fg: #e3e6e8; --muted: #9ca5ad; --rule: #333a40;
  --accent: #86bbdc; --open: #f0c060; --open-bg: #3a2f17; --done: #8fd19c; --done-bg: #1d3323;
  --code-bg: #242a2f; --mark: #ff9a85; --mark-bg: #4a221b;
  color-scheme: dark; }
@font-face { font-family: "Taamey D"; src: url(data:font/woff2;base64,FONT) format("woff2"); font-display: swap; }
body { background: var(--bg); color: var(--fg); font: 16px/1.55 var(--sans); }
main { max-width: 50rem; margin: 0 auto; padding-block: 2rem 4rem;
  padding-left: max(16px, env(safe-area-inset-left, 0px)); padding-right: max(16px, env(safe-area-inset-right, 0px)); }
h1 { font-size: 1.65rem; line-height: 1.25; margin: 0 0 .7rem; text-wrap: balance; }
h2 { font-size: 1.28rem; margin: 2.4rem 0 .6rem; padding-top: 1rem; border-top: 1px solid var(--rule); text-wrap: balance; }
h3 { font-size: 1.06rem; margin: 1.5rem 0 .4rem; text-wrap: balance; }
p, li { max-width: 72ch; }
a { color: var(--accent); }
code { font-family: var(--mono); font-size: .86em; background: var(--code-bg); padding: 0 .25em; border-radius: 3px; }
pre { font-family: var(--mono); font-size: .8rem; line-height: 1.6; background: var(--code-bg); padding: .8rem 1rem;
  border-radius: 4px; overflow-x: auto; white-space: pre; }
pre.prewrap { white-space: pre-wrap; overflow-wrap: anywhere; font-size: .84rem; }
details { margin: .35rem 0; border: 1px solid var(--rule); border-radius: 6px; background: var(--surface); }
details > summary { cursor: pointer; padding: .35rem .8rem; font-weight: 600; }
details > pre { margin: 0; border-radius: 0 0 6px 6px; }
.ai-caveat { border: 1px solid var(--rule); background: var(--surface); padding: .6rem .9rem; border-radius: 6px; color: var(--muted); }
.state { font-weight: 600; }
.chip { display: inline-block; font-size: .75rem; font-weight: 600; letter-spacing: .04em; text-transform: uppercase;
  padding: .05rem .5rem; border-radius: 999px; vertical-align: .1em; }
.chip.open { color: var(--open); background: var(--open-bg); }
.chip.done { color: var(--done); background: var(--done-bg); }
.decision { background: var(--surface); border: 1px solid var(--rule); border-radius: 8px; padding: .3rem 1.2rem 1rem; margin: 1rem 0; }
.label { font-size: .78rem; font-weight: 600; letter-spacing: .05em; text-transform: uppercase; color: var(--muted); margin: 1rem 0 .2rem; }
.rec { border-left: 3px solid var(--accent); padding-left: .8rem; }
.pending { border: 1px dashed var(--open); background: var(--open-bg); color: var(--fg); padding: .5rem .8rem; border-radius: 6px; }
.tablewrap { overflow-x: auto; margin: .8rem 0; }
table { border-collapse: collapse; margin: 0 auto; font-size: .9rem; }
th, td { border: 1px solid var(--rule); padding: .3rem .55rem; vertical-align: middle; text-align: start; }
th { background: var(--code-bg); font-weight: 600; }
td.num { text-align: right; font-variant-numeric: tabular-nums; }
td.bcv { white-space: nowrap; padding-left: .7rem; }
.hbo { font-family: "Taamey D", "SBL Hebrew", "Ezra SIL", serif; font-size: 140%; line-height: 1.4; }
td .hbo { white-space: nowrap; }
.hbo-code { font-family: "Taamey D", "SBL Hebrew", "Ezra SIL", serif; font-size: 150%; }
.mk { color: var(--mark); background: var(--mark-bg); border-radius: 2px; }
.sub { font-size: .88rem; color: var(--muted); }
blockquote { margin: .8rem 0; padding: .1rem 1rem; border-left: 3px solid var(--rule); color: var(--fg); }
"""


def wrap_unpointed(text):
    """Isolate unpointed Hebrew runs in text outside tags with a <bdi> that has no lang."""
    out, pos = [], 0
    for m in re.finditer(r"<[^>]*>", text):
        out.append(
            HEB_RUN.sub(lambda r: "<bdi>%s</bdi>" % r.group(0), text[pos : m.start()])
        )
        out.append(m.group(0))
        pos = m.end()
    out.append(HEB_RUN.sub(lambda r: "<bdi>%s</bdi>" % r.group(0), text[pos:]))
    return "".join(out)


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    template = Path(sys.argv[1]).read_text(encoding="utf-8")
    frag_dir, out = Path(sys.argv[2]), Path(sys.argv[3])
    bad = MARK.search(template)
    if bad:
        line = template.count("\n", 0, bad.start()) + 1
        raise SystemExit("pointed Hebrew typed into the template at line %d" % line)
    body = wrap_unpointed(template)

    def fragment(m):
        p = frag_dir / (m.group(1) + ".html")
        return p.read_text(encoding="utf-8")

    body = PLACEHOLDER.sub(fragment, body)
    if PLACEHOLDER.search(body):
        raise SystemExit("unresolved placeholder")
    font = base64.b64encode((MB / "gh-pages/woff2/Taamey_D.woff2").read_bytes()).decode(
        "ascii"
    )
    head = (
        "<title>morphhb span versions</title>\n"
        '<meta name="claude:viewport-fit-sides" content="cover">\n'
        '<link rel="preconnect" href="https://fonts.googleapis.com">\n'
        '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500'
        '&family=IBM+Plex+Sans:ital,wght@0,400;0,600;1,400&display=swap">\n'
        "<style>" + STYLE.replace("FONT", font) + "</style>\n"
    )
    out.write_text(
        head + "<main>\n" + body + "\n</main>\n", encoding="utf-8", newline="\n"
    )
    print("wrote", out, out.stat().st_size, "bytes")


if __name__ == "__main__":
    main()

"""Summarize fetched/<label>-<n>/: morphhb master, #118, #116 and the fork's branches."""

import json
import sys
from pathlib import Path

W = Path(__file__).resolve().parent.parent


def load(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    n = sys.argv[1]
    c = load(W / f"fetched/upstream-master-{n}/commit.json")
    print("master:", c["sha"], c["commit"]["committer"]["date"], c["commit"]["message"][:70])
    p = load(W / f"fetched/pr118-{n}/pull.json")
    print(
        "#118:",
        p["state"],
        "merged" if p.get("merged") else "not merged",
        "mergeable=",
        p.get("mergeable"),
        p.get("mergeable_state"),
        "head",
        p["head"]["label"],
        p["head"]["sha"],
        "base",
        p["base"]["ref"],
        p["base"]["sha"],
        "comments",
        p.get("comments"),
        "review_comments",
        p.get("review_comments"),
        "commits",
        p.get("commits"),
        "changed_files",
        p.get("changed_files"),
        "updated",
        p.get("updated_at"),
        "maintainer_can_modify",
        p.get("maintainer_can_modify"),
    )
    print("#118 title:", p["title"])
    i = load(W / f"fetched/issue116-{n}/issue.json")
    print("#116:", i["state"], i["title"], "comments", i["comments"], "updated", i["updated_at"])
    for cm in load(W / f"fetched/issue116-{n}/comments.json"):
        print("  #116 comment", cm["user"]["login"], cm["created_at"], cm["updated_at"])
    for b in load(W / f"fetched/fork-branches-{n}/branches.json"):
        print("fork branch", b["name"], b["commit"]["sha"])


main()

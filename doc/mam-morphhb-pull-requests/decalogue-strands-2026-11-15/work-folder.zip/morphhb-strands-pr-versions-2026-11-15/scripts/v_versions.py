"""Sub-agent V: the point under the het, in WLC 4.18, 4.20, 4.22 and UXLC 2.6, at each het where
WLC 4.20 has a sheva and MAM a hataf patah (out/52-mam-het.json), and at Deuteronomy 5:9.

Throwaway scratch for the morphhb strands pull request (prepared, not posted).  Written by Claude
(Opus 5.5, sub-agent V), 2026-11-15.  Run from C:/Users/BenDe/GitRepos/MAM-basics in PowerShell 7:

    ./.venv/Scripts/python.exe -B .novc/morphhb-strands-pr-versions-2026-11-15/scripts/v_versions.py

Writes only .novc/morphhb-strands-pr-versions-2026-11-15/out/52-versions.json, and prints it.
Readers: folder D's mhb_common (WLC 4.18 and UXLC 2.6 from tanach.us XML, WLC 4.20 and 4.22 from
MAM-basics' out/wlc42x-u).  Each verse's atoms are aligned with WLC 4.20's by letters
(v_census.align); the atom aligned with WLC 4.20's gives its point at the same letter.
"""

import sys

sys.dont_write_bytecode = True

import json  # noqa: E402
from pathlib import Path  # noqa: E402

SCRIPTS = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPTS))

import v_census as V  # noqa: E402

C = V.C
OUT = V.W / "out" / "52-versions.json"
EXTRA = [("Deut.5.9", 2, 4)]


def tanach_atoms(osis, ch, vs, books_dir):
    verse = C.read_wlc418_book(osis, books_dir)[(ch, vs)]
    return [a for a in verse if a["tag"] in ("w", "q")]


def w42x_atoms(version, osis, ch, vs):
    raw = C.read_wlc42x(version)[(osis, ch, vs)]
    return [a for a in raw if a["spi"] is None and a["text"] not in ("kk", "qq") and a["kq"] != "k"]


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    cases = json.loads((V.W / "out" / "52-mam-het.json").read_text(encoding="utf-8"))["cases"]
    targets = [(c["vid"], c["wlc_atom"], c["letter"]) for c in cases] + EXTRA
    out = []
    for vid, wlc_atom, letter in targets:
        osis, ch, vs = vid.split(".")
        ch, vs = int(ch), int(vs)
        w420_all = [
            a for a in C.read_wlc42x("4.20")[(osis, ch, vs)] if a["spi"] is None and a["text"] not in ("kk", "qq")
        ]
        target = w420_all[wlc_atom - 1]
        if target["kq"] == "k":
            raise ValueError(f"{vid}: a ketiv target")
        w420 = [a for a in w420_all if a["kq"] != "k"]
        pos = w420.index(target)
        base_letters = [V.letters(a["text"], vid) for a in w420]
        rec = {"vid": vid, "letter": letter, "wlc420": target["text"]}
        sources = {
            "WLC 4.18": lambda: [a["text"] for a in tanach_atoms(osis, ch, vs, C.WLC418_BOOKS)],
            "WLC 4.22": lambda: [a["text"] for a in w42x_atoms("4.22", osis, ch, vs)],
            "UXLC 2.6": lambda: [a["text"] for a in tanach_atoms(osis, ch, vs, C.UXLC26_BOOKS)],
        }
        for name, get in sources.items():
            try:
                forms = get()
            except FileNotFoundError as e:
                rec[name] = {"missing": str(e)}
                continue
            pairs, _other = V.align(base_letters, [V.letters(f, name) for f in forms])
            if pos not in pairs:
                rec[name] = {"aligned": False}
                continue
            form = forms[pairs[pos]]
            rec[name] = {"form": form, "point": V.point_at(form, letter - 1, name)}
        rec["WLC 4.20 point"] = V.point_at(target["text"], letter - 1, "WLC 4.20")
        out.append(rec)
    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=1) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps(out, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()

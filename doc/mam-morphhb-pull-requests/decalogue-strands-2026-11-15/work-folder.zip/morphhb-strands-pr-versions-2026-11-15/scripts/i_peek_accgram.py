"""Sub-agent I: print the parts of out/53-accgram.json that the adapter needs (read-only).

Run with -I from the MAM-basics root.
"""

import json
import sys
from pathlib import Path

W = Path(__file__).resolve().parent.parent


def show(name, v, depth=0, maxdepth=3):
    pad = "  " * depth
    if isinstance(v, dict):
        print(f"{pad}{name}: dict({len(v)}) keys {list(v)[:12]}")
        if depth < maxdepth:
            for k in list(v)[:6]:
                show(k, v[k], depth + 1, maxdepth)
    elif isinstance(v, list):
        print(f"{pad}{name}: list({len(v)})")
        if v and depth < maxdepth:
            show("[0]", v[0], depth + 1, maxdepth)
    else:
        print(f"{pad}{name}: {ascii(v)[:160]}")


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    d = json.loads((W / "out/53-accgram.json").read_text(encoding="utf-8"))
    show("checks", d["checks"])
    show("noted_vs_illegal", d["noted_vs_illegal"])
    show("n", d["n"], maxdepth=3)
    show("strand_atoms[0]", d["strand_atoms"][0])
    show("chanted_verses[0]", d["chanted_verses"][0], maxdepth=1)


main()

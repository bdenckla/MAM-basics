"""Sub-agent V: print selected records of out/52-sheva-census.json (throwaway scratch).

Usage: python -I v_peek.py rows <vid> [<vid> ...] | notes | het_diffs
"""

import json
import sys
from pathlib import Path

W = Path(__file__).resolve().parent.parent
CENSUS = W / "out" / "52-sheva-census.json"


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    data = json.loads(CENSUS.read_text(encoding="utf-8"))
    what = sys.argv[1]
    if what == "rows":
        for r in data["verb_rows"]:
            if r["vid"] in sys.argv[2:]:
                print(json.dumps(r, ensure_ascii=False, indent=1))
    elif what == "notes":
        for r in data["verb_rows"]:
            if r["wlc420_notes"] or r["morphhb"].get("notes"):
                print(
                    r["vid"],
                    r["wlc_kq"],
                    r["wlc420"],
                    r["wlc420_point"],
                    r["wlc420_notes"],
                    [(n["n"], n["type"], n["text"][:60]) for n in r["morphhb"].get("notes", [])],
                )
    elif what == "unaligned":
        for b in data["unaligned_blocks"]:
            print(json.dumps(b, ensure_ascii=False))
    elif what == "het_diffs":
        for d in data["het_diffs"]:
            print(json.dumps(d, ensure_ascii=False))
    elif what == "points":
        for r in data["verb_rows"]:
            print(
                r["vid"],
                r["wlc_kq"],
                r["wlc420"],
                r["wlc420_point"],
                "|",
                r["morphhb"].get("form"),
                r["morphhb"].get("point"),
                "|",
                r["mam"].get("form"),
                r["mam"].get("point"),
                r["mam"].get("strand_points"),
            )
    else:
        raise SystemExit("unknown " + what)


main()

"""Write the changed wlc/ book files: every span of the 24 verses gets its versions.

Usage (from the MAM-basics root, with -B):
  build.py <placement> <out-dir>
placement:
  A  a note goes right after the <w> when its version has the main version's trailing
     punctuation (catchWord and rdg then quote the atoms alone, as today), and after the
     main version's punctuation seg when the two differ in it (catchWord and rdg then quote
     each version with its punctuation);
  B  every note goes after the whole span, and catchWord and rdg always quote the
     punctuation.
One <note type="alternative" subType=LABEL> per alternate, in the versions' order. `n` comes
from out/54-for-build.json's "new_n" (w id -> code or null; written by scripts/i_for_build.py
from sub-agent G's out/53-accgram.json), which must cover every main-text <w> of the 24 verses
(a ketiv's code is on its qere's <w>). Writes <out-dir>/{Gen,Exod,Deut}.xml (LF, no BOM, like
the base) and <out-dir>/build-log.json.
"""

import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))  # untracked scratch: exempt
import strands_core as sc  # noqa: E402
import versions as vs  # noqa: E402

LABELS = {
    False: {
        "clc_other": "x-elyon",
        "mam_main": "x-taxton-mam-informed",
        "mam_other": "x-elyon-mam-informed",
    },
    True: {  # Genesis 35:22
        "clc_other": "x-peshutah",
        "mam_main": "x-midrashit-mam-informed",
        "mam_other": "x-peshutah-mam-informed",
    },
}
TOKEN = re.compile(
    r"(?P<ws>\s+)|(?P<w><w\b[^>]*>[^<]*</w>)|(?P<seg><seg\b[^>]*>[^<]*</seg>)"
    r"|(?P<note><note\b[^>]*>.*?</note>)",
    re.S,
)
INDENT = "\n          "


def tokenize(inner):
    toks, pos = [], 0
    while pos < len(inner):
        m = TOKEN.match(inner, pos)
        if not m:
            raise ValueError("untokenizable text at %r" % inner[pos : pos + 40])
        toks.append((m.lastgroup, m.group(0)))
        pos = m.end()
    return toks


def attr(tag, name):
    m = re.search(r'\b%s="([^"]*)"' % name, tag)
    return m.group(1) if m else None


def w_parts(tok):
    m = re.match(r"(<w\b[^>]*>)([^<]*)</w>", tok)
    return m.group(1), m.group(2)


def seg_punct(tok):
    return sc.SEG_PUNCT.get(attr(tok, "type"))


def note_kind(tok):
    head = re.match(r"<note\b[^>]*>", tok).group(0)
    if attr(head, "type") == "alternative":
        return "alt"
    if attr(head, "type") == "variant":
        return "variant"
    return "fixed"


def with_slashes(core, original):
    """Insert morphhb's slashes into core at the letter positions they have in original."""
    cuts, n = [], 0
    for ch in original:
        if ch == "/":
            cuts.append(n)
        elif sc.LETTER.match(ch):
            n += 1
    out, n = [], 0
    for ch in core:
        if sc.LETTER.match(ch):
            if n in cuts and n > 0:
                out.append("/")
            n += 1
        out.append(ch)
    return "".join(out)


def split_text(text):
    """A catchWord or rdg text -> (core with slashes, punct)."""
    for name, ch in sc.PUNCT_CHAR.items():
        if text.endswith(ch):
            return text[: -len(ch)], name
    return text, ""


def rendered(core, originals):
    """core with slashes, reusing an original morphhb string equal to it in MAM-normal order."""
    plain = sc.std(core)
    for o in originals:
        if sc.std(o.replace("/", "")) == plain:
            return o, "reused"
    return with_slashes(core, originals[0]), "new"


def set_n(head, code):
    head = re.sub(r' n="[^"]*"', "", head)
    if code is None:
        return head
    if " lemma=" in head:
        return re.sub(r'( lemma="[^"]*")', r'\1 n="%s"' % code, head, count=1)
    raise ValueError("no lemma in " + head)


def build_verse(block, recs_by_id, new_n, placement, log):
    m = re.match(r'(<verse osisID="([^"]+)">)(.*)(</verse>)$', block, re.S)
    open_tag, vid, inner, close = m.group(1), m.group(2), m.group(3), m.group(4)
    toks = tokenize(inner)
    labels = LABELS[sc.is_gen(vid)]
    # group: a <w> and the alternative notes, variant note and punctuation segs right after it
    groups, i = [], 0
    while i < len(toks):
        kind, tok = toks[i]
        if kind != "w":
            groups.append(("other", [(kind, tok)]))
            i += 1
            continue
        g = [(kind, tok)]
        i += 1
        while i < len(toks):
            k2, t2 = toks[i]
            if k2 == "note" and note_kind(t2) in ("alt", "variant"):
                g.append((k2, t2))
            elif k2 == "seg" and seg_punct(t2):
                g.append((k2, t2))
            elif (
                k2 == "ws"
                and i + 1 < len(toks)
                and toks[i + 1][0] == "seg"
                and seg_punct(toks[i + 1][1]) == "paseq"
            ):
                # morphhb puts a paseq seg on its own line after its atom
                if t2 != INDENT:
                    raise ValueError(f"{vid}: unexpected whitespace before a paseq")
                g.append(("seg", toks[i + 1][1]))
                i += 1
            else:
                break
            i += 1
        groups.append(("span", g))
    out = []
    prev_maqaf = False
    for gi, (gkind, g) in enumerate(groups):
        if gkind == "other":
            kind, tok = g[0]
            if kind == "ws" and gi + 1 < len(groups) and groups[gi + 1][0] == "span":
                # whitespace before a span: none after a maqaf, else a new line
                out.append("" if prev_maqaf else INDENT)
                if tok != INDENT and not prev_maqaf:
                    raise ValueError(f"{vid}: unexpected whitespace {tok!r}")
            else:
                if prev_maqaf and kind != "ws":
                    raise ValueError(f"{vid}: a {kind} inside a new maqaf compound")
                out.append(tok)
            continue
        wtok = g[0][1]
        head, wtext = w_parts(wtok)
        wid = attr(head, "id")
        variant = [t for k, t in g if k == "note" and note_kind(t) == "variant"]
        if variant:
            qere = re.search(r"<w\b[^>]*>[^<]*</w>", variant[0]).group(0)
            qhead, qtext = w_parts(qere)
            wid = attr(qhead, "id")
        r = recs_by_id[wid]
        old_alts = [t for k, t in g if k == "note" and note_kind(t) == "alt"]
        old_texts = [wtext]
        for t in old_alts:
            for part in re.findall(r"<(?:catchWord|rdg)[^>]*>([^<]*)</", t):
                c, _ = split_text(part)
                if " " not in c and sc.MAQAF not in c:
                    old_texts.append(c)
        versions = r["versions"]
        main_core, main_punct = versions[0]["span"]
        if variant:
            if len(versions) != 1 or sc.std(main_core) != sc.std(
                qtext.replace("/", "")
            ):
                raise ValueError(f"{vid}: the qere's atom changes; not handled")
            main_txt, how = wtext, "ketiv kept"
        else:
            main_txt, how = rendered(main_core, old_texts)
        code = new_n[wid]  # a <w> missing from new_n fails
        if variant:
            new_head = head
            new_variant = variant[0].replace(qhead, set_n(qhead, code))
        else:
            new_head = set_n(head, code)
            new_variant = None
        span_out = [new_head + main_txt + "</w>"]
        if new_variant:
            span_out.append(new_variant)
        # placement A: all of a span's notes after the <w>, quoting no punctuation, when every
        # alternate has the main version's punctuation; otherwise all after the seg, quoting it.
        any_differs = any(v["span"][1] != main_punct for v in versions[1:])
        quote_punct = placement == "B" or any_differs
        notes = []
        for v in versions[1:]:
            core, punct = v["span"]
            alt_txt, _ = rendered(core, old_texts)
            cw = main_txt + (
                sc.PUNCT_CHAR[main_punct] if quote_punct and main_punct else ""
            )
            rd = alt_txt + (sc.PUNCT_CHAR[punct] if quote_punct and punct else "")
            note = (
                f'<note type="alternative" subType="{labels[v["kind"]]}">'
                f'<catchWord>{cw}</catchWord><rdg type="x-accent">{rd}</rdg></note>'
            )
            notes.append(note)
            log.append({"vid": vid, "atom": r["atom"], "kind": v["kind"], "note": note})
        if not quote_punct:
            span_out += notes
        if main_punct:
            seg = f'<seg type="{sc.SEG_TYPE[main_punct]}">{sc.PUNCT_CHAR[main_punct]}</seg>'
            span_out.append((INDENT if main_punct == "paseq" else "") + seg)
        if quote_punct:
            span_out += notes
        out.append("".join(span_out))
        prev_maqaf = main_punct == "maqaf"
        if gi + 1 < len(groups) and groups[gi + 1][0] == "span":
            out.append("" if prev_maqaf else INDENT)
        if how == "new":
            log.append(
                {"vid": vid, "atom": r["atom"], "kind": "main", "new_text": main_txt}
            )
    return open_tag + "".join(out) + close


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    placement, out_dir = sys.argv[1], Path(sys.argv[2])
    out_dir.mkdir(parents=True, exist_ok=True)
    recs = vs.compute()
    recs_by_id = {r["w_id"]: r for r in recs}
    p = sc.W / "out/54-for-build.json"
    new_n = json.loads(p.read_text(encoding="utf-8"))["new_n"]  # required
    if len(new_n) != len(recs):
        raise ValueError(f"{p}: {len(new_n)} codes for {len(recs)} atoms")
    log = []
    for book in sc.BOOKS:
        text = sc.load_base(book)
        for vid in [v for v in sc.VIDS if v.startswith(book + ".")]:
            m = re.search(
                r'<verse osisID="%s">.*?</verse>' % re.escape(vid), text, re.S
            )
            new_block = build_verse(m.group(0), recs_by_id, new_n, placement, log)
            text = text[: m.start()] + new_block + text[m.end() :]
        (out_dir / f"{book}.xml").write_text(text, encoding="utf-8", newline="\n")
    (out_dir / "build-log.json").write_text(
        json.dumps(
            {"placement": placement, "n_from_accgram": bool(new_n), "log": log},
            ensure_ascii=False,
            indent=1,
        ),
        encoding="utf-8",
        newline="\n",
    )
    print(
        "notes:",
        sum(1 for e in log if "note" in e),
        "new main texts:",
        sum(1 for e in log if "new_text" in e),
    )


if __name__ == "__main__":
    main()

"""Sub-agent T: run py/main_verse_links.py for each case verse and save its output.

BHS references (with --atom) give the UXLC, Leningrad and atom-estimate lines;
MAM references give the MwD verse link, since MAM numbers its Decalogues by
the manuscripts' lower cantillation. A dummy word makes the command list the
UXLC's atoms, so that the --atom numbers can be checked against the case atoms.
"""

import json
import subprocess
import sys
from pathlib import Path

REPO = Path("C:/Users/BenDe/GitRepos/MAM-basics")
W = REPO / ".novc/morphhb-strands-pr-versions-2026-11-15"
OUT = W / "scratch-t/links.json"
PY = str(REPO / ".venv/Scripts/python.exe")

BHS_RUNS = [
    ("Exodus", "20:3", [2, 7]),
    ("Exodus", "20:4", [2]),
    ("Exodus", "20:5", [2]),
    ("Deuter", "5:7", [2, 7]),
    ("Deuter", "5:8", [2, 12]),
    ("Deuter", "5:12", [4]),
    ("Deuter", "5:15", [23]),
    ("Deuter", "5:17", [2]),
    ("Genesis", "35:22", [7]),
]
MAM_RUNS = [
    ("Exodus", "20:2"),
    ("Exodus", "20:3"),
    ("Exodus", "20:4"),
    ("Deuter", "5:6"),
    ("Deuter", "5:7"),
    ("Deuter", "5:11"),
    ("Deuter", "5:14"),
    ("Deuter", "5:16"),
]


def run(args):
    proc = subprocess.run(
        [PY, "py/main_verse_links.py", *args],
        cwd=REPO,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="backslashreplace",
    )
    return {"args": args, "rc": proc.returncode, "out": proc.stdout, "err": proc.stderr}


def main():
    results = {"bhs": [], "mam": [], "listing": []}
    for book, cv, atoms in BHS_RUNS:
        results["listing"].append(run([book, cv, "x"]))
        for n in atoms:
            results["bhs"].append(run([book, cv, "--atom", str(n)]))
    for book, cv in MAM_RUNS:
        results["mam"].append(run([book, cv]))
    with OUT.open("w", encoding="utf-8", newline="\n") as f:
        json.dump(results, f, ensure_ascii=False, indent=1)
        f.write("\n")
    print(f"wrote {OUT}", file=sys.stderr)


main()

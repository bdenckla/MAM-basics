"""Print #118's title and body from fetched/pr118-1/pull.json."""

import json
import sys
from pathlib import Path

W = Path(__file__).resolve().parent.parent
sys.stdout.reconfigure(encoding="utf-8")
p = json.loads((W / "fetched/pr118-1/pull.json").read_text(encoding="utf-8"))
print(p["title"])
print("-" * 40)
print(p["body"])

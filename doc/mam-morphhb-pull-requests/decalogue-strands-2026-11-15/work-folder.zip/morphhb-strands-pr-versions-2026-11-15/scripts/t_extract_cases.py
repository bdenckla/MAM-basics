"""Sub-agent T: copy, by script, the forms of the cases Ben asked about.

Reads 22-clc-answers.json and writes scratch-t/cases.json with, per case atom,
the WLC 4.20 form and each strand's MAM form, plus each form's code points
spelled out by Unicode name, so that no Hebrew is retyped.
"""

import json
import sys
import unicodedata
from pathlib import Path

SRC = Path(
    "C:/Users/BenDe/GitRepos/MAM-basics/.novc/morphhb-strands-pr-2026-11-14/out/22-clc-answers.json"
)
W = Path(
    "C:/Users/BenDe/GitRepos/MAM-basics/.novc/morphhb-strands-pr-versions-2026-11-15"
)
OUT = W / "scratch-t" / "cases.json"
OUT_TXT = W / "scratch-t" / "cases.txt"

CASES = [
    ("Exod.20.4", 2),
    ("Deut.5.7", 2),
    ("Deut.5.8", 2),
    ("Exod.20.5", 2),
    ("Exod.20.3", 7),
    ("Deut.5.7", 7),
    ("Deut.5.8", 12),
    ("Deut.5.12", 4),
    ("Deut.5.15", 23),
    ("Gen.35.22", 7),
    ("Deut.5.17", 2),
    ("Exod.20.3", 2),
]


def names(s):
    return [f"{unicodedata.name(c, hex(ord(c)))}" for c in s]


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8", errors="backslashreplace")
    data = json.loads(SRC.read_text(encoding="utf-8"))
    atoms = data["atoms"]
    by_key = {}
    for a in atoms:
        by_key.setdefault((a["vid"], a["atom"]), []).append(a)
    result = []
    txt = []
    for vid, n in CASES:
        found = by_key.get((vid, n), [])
        assert len(found) == 1, (vid, n, len(found))
        a = found[0]
        rec = {
            "vid": vid,
            "atom": n,
            "wlc420": a["wlc420"],
            "uxlc26": a.get("uxlc26"),
            "alef_keys": sorted(a["alef"].keys()) if isinstance(a["alef"], dict) else None,
            "alef_mam_form": a["alef"]["mam_form"],
            "bet_mam_form": a["bet"]["mam_form"],
            "two_strands_differ": a.get("two_strands_differ"),
            "decisions_and_events": a.get("decisions_and_events"),
        }
        result.append(rec)
        txt.append(f"== {vid} atom {n}")
        for k in ("wlc420", "alef_mam_form", "bet_mam_form"):
            txt.append(f"  {k}: {ascii(rec[k])}")
            txt.append(f"     {' | '.join(names(rec[k]))}")
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with OUT.open("w", encoding="utf-8", newline="\n") as f:
        json.dump(result, f, ensure_ascii=False, indent=1)
        f.write("\n")
    with OUT_TXT.open("w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(txt) + "\n")
    # Also dump one full atom record for structure.
    full = by_key[("Exod.20.4", 2)][0]
    with (W / "scratch-t" / "sample_atom_exod20_4_2.json").open(
        "w", encoding="utf-8", newline="\n"
    ) as f:
        json.dump(full, f, ensure_ascii=False, indent=1)
        f.write("\n")
    print(f"wrote {OUT} and {OUT_TXT}", file=sys.stderr)


main()

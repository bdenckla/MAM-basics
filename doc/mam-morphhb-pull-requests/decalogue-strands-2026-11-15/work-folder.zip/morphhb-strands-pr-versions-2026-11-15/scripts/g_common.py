"""Sub-agent G (2026-11-15): shared helpers for the accgram analysis of the 24 dual-cantillation verses.

Throwaway scratch for the morphhb strands pull request (prepared, not posted), written by Claude.
Imported by the other g_*.py scripts, which run from C:/Users/BenDe/GitRepos/MAM-basics as
``./.venv/Scripts/python.exe -B <script>``.  This module puts MAM-basics' py/ on sys.path, which
is allowed only in these untracked scratch scripts.

Inputs (read only):
- folder S's out/22-clc-answers.json: the 242 atoms, WLC 4.20's form, and for each strand the
  CLC-rule form (CLC's division rules applied to WLC 4.20) and MAM's form;
- MAM-simple's json-vtrad-bhs (via accgram.mam_simple_verse), for MAM's strands of the three
  verses into which a chanted verse runs on beyond the 24 (Exodus 20:11 and 20:16,
  Deuteronomy 5:20) and to cross-check the JSON's MAM forms;
- out/wlc420-u, WLC 4.20's text of those three verses;
- morphhb's base files W/fetched/base-696e21ce/{Gen,Exod,Deut}.xml.

Strand keys: alef = MAM-simple's cant-alef (the Decalogue's tahton, Genesis 35:22's peshutah),
bet = cant-bet (the elyon; the midrashit).
"""

from __future__ import annotations

import json
import re
import sys
import xml.etree.ElementTree as ET
from itertools import combinations
from pathlib import Path

MB = Path("C:/Users/BenDe/GitRepos/MAM-basics")
sys.path.insert(0, str(MB / "py"))

from accgram import accent_marks as am  # noqa: E402
from accgram import lexical_validation  # noqa: E402
from accgram import mam_simple_verse  # noqa: E402
from accgram import uni_to_marks  # noqa: E402
from accgram import unaccented_chanted_words as ucw  # noqa: E402
from accgram.dual_cant_detangle import _tree_has_error  # noqa: E402
from accgram.prose_ply_grammar import LOCATION_ONLY, build_parser, parse_tokens  # noqa: E402
from accgram.prose_scanner import HasLegarmeh, Token, scan_accents  # noqa: E402
from accgram.tree import tree_to_obj  # noqa: E402
from mb_cmn import paths  # noqa: E402
from mb_cmn.uni_denorm import give_std_mark_order  # noqa: E402

S = MB / ".novc" / "morphhb-strands-pr-2026-11-14"
W = MB / ".novc" / "morphhb-strands-pr-versions-2026-11-15"
CLC_JSON = S / "out" / "22-clc-answers.json"
BASE = W / "fetched" / "base-696e21ce"
WLC420 = MB / "out" / "wlc420-u"

MAQAF = "\N{HEBREW PUNCTUATION MAQAF}"
PASEQ = "\N{HEBREW PUNCTUATION PASEQ}"
SOF = "\N{HEBREW PUNCTUATION SOF PASUQ}"
METEG = "\N{HEBREW POINT METEG}"
CGJ = "\N{COMBINING GRAPHEME JOINER}"
ALEF = "\N{HEBREW LETTER ALEF}"
TAV = "\N{HEBREW LETTER TAV}"
VAV = "\N{HEBREW LETTER VAV}"
YOD = "\N{HEBREW LETTER YOD}"
HE = "\N{HEBREW LETTER HE}"
HOLAM = "\N{HEBREW POINT HOLAM}"
DAGESH = "\N{HEBREW POINT DAGESH OR MAPIQ}"
ACC_LO = "\N{HEBREW ACCENT ETNAHTA}"
ACC_HI = "\N{HEBREW ACCENT ZINOR}"
# Vowel points and sheva: U+05B0 SHEVA .. U+05BB QUBUTS, and U+05C7 QAMATS QATAN.
VOWELS = frozenset([chr(c) for c in range(0x05B0, 0x05BC)] + ["\N{HEBREW POINT QAMATS QATAN}"])

STRANDS = ("alef", "bet")
SOURCES = ("mam", "clc")
# (book, strand) -> the strand's Hebrew name, copied from the JSON's "name" fields by load_atoms.
STRAND_NAME: dict[tuple[str, str], str] = {}
BB = {"Gen": "gn", "Exod": "ex", "Deut": "dt"}

# Each passage's verse sequence, with the three verses outside the 24 into which a chanted
# verse runs on (Exodus 20:11 for the elyon, 20:16 and Deuteronomy 5:20 for the tahton).  A
# None is a gap (a verse that is its own chanted verse in both strands); every strand must be
# closed by a sof pasuq before a gap.
PASSAGES = {
    "Gen": ["Gen.35.22"],
    "Exod": [f"Exod.20.{v}" for v in (2, 3, 4, 5, 6)]
    + [None]
    + [f"Exod.20.{v}" for v in (8, 9, 10, 11)]
    + [None]
    + [f"Exod.20.{v}" for v in (13, 14, 15, 16)],
    "Deut": [f"Deut.5.{v}" for v in (6, 7, 8, 9, 10)]
    + [None]
    + [f"Deut.5.{v}" for v in (12, 13, 14, 15)]
    + [None]
    + [f"Deut.5.{v}" for v in (17, 18, 19, 20)],
}
EXTRA_VIDS = ("Exod.20.11", "Exod.20.16", "Deut.5.20")
VIDS24 = (
    ["Gen.35.22"]
    + [f"Exod.20.{v}" for v in (2, 3, 4, 5, 6, 8, 9, 10, 13, 14, 15)]
    + [f"Deut.5.{v}" for v in (6, 7, 8, 9, 10, 12, 13, 14, 15, 17, 18, 19)]
)
# morphhb's main text today (folder D's README, verse table): the elyon in these Decalogue
# verses, the tahton in the others, the midrashit at Genesis 35:22.
MAIN_TODAY_BET = {
    "Gen.35.22",
    "Exod.20.2",
    "Exod.20.13",
    "Exod.20.14",
    "Exod.20.15",
    "Deut.5.6",
    "Deut.5.17",
    "Deut.5.18",
    "Deut.5.19",
}


def std(text: str) -> str:
    return give_std_mark_order(text)


def is_letter(ch: str) -> bool:
    return ALEF <= ch <= TAV


def is_accent(ch: str) -> bool:
    return ACC_LO <= ch <= ACC_HI


def vid_parts(vid: str) -> tuple[str, int, int]:
    book, ch, v = vid.split(".")
    return book, int(ch), int(v)


# ------------------------------------------------------------------ atoms


def load_clc_json() -> dict:
    return json.loads(CLC_JSON.read_text(encoding="utf-8"))


def clc_form(rule_form: str) -> str:
    """The CLC-rule form with the brackets of a supplied mark removed, the mark kept."""
    out = rule_form.replace("[", "").replace("]", "")
    if "[" in out or "]" in out:
        raise ValueError(rule_form)
    return out


def load_atoms() -> list[dict]:
    """The 242 atoms of the 24 verses, each with its strands' MAM and CLC forms."""
    data = load_clc_json()
    atoms = []
    for a in data["atoms"]:
        rec = {
            "vid": a["vid"],
            "book": a["vid"].split(".")[0],
            "atom": a["atom"],
            "w_id": a["morphhb_w_id"],
            "wlc420": a["wlc420"],
            "in24": True,
        }
        for s in STRANDS:
            d = a[s]
            name = STRAND_NAME.setdefault((rec["book"], s), d["name"])
            if name != d["name"]:
                raise ValueError(f"{a['vid']}: strand {s} named {d['name']!r} and {name!r}")
            rec[s] = {
                "mam": d["mam_form"],
                "clc": clc_form(d["clc_rule_form"]),
                "clc_rule_form": d["clc_rule_form"],
                "supplied": list(d["supplied"]),
                "noted": [dict(n) for n in d["noted"]],
                "clc_noted_uxlc": list(d["clc_noted"]),
                "own_reading_differences": list(d["own_reading_differences"]),
            }
        atoms.append(rec)
    return atoms


def mam_simple_verses() -> dict[str, dict]:
    """MAM-simple's strands of every verse of the three passages, keyed by vid."""
    refs = {
        "gn": {(35, 22)},
        "ex": {(20, v) for v in range(2, 18)},
        "dt": {(5, v) for v in range(6, 22)},
    }
    loaded = mam_simple_verse.load_mam_simple_for_refs(
        paths.mam_simple_dir(), refs, include_strands=True, include_native_paseq_roles=True
    )
    rev = {"gn": "Gen", "ex": "Exod", "dt": "Deut"}
    out = {}
    for bcv, info in loaded.items():
        m = re.fullmatch(r"([a-z0-9]{2})(\d+):(\d+)", bcv)
        vid = f"{rev[m.group(1)]}.{m.group(2)}.{m.group(3)}"
        verse = info["mam_simple_verse"]
        out[vid] = {
            "alef": fold_paseq(verse["vels_cant_alef"], bcv),
            "bet": fold_paseq(verse["vels_cant_bet"], bcv),
        }
    return out


def fold_paseq(vels: list, where: str) -> list[dict]:
    """MAM-simple's tokens as atoms: a lone paseq token goes onto the atom before it, after a
    space, as the JSON's MAM forms write it; MAM's own paseq/legarmeh tag is kept."""
    atoms: list[dict] = []
    for vel in vels:
        if isinstance(vel, mam_simple_verse.MAMNativePaseq):
            if not atoms:
                raise ValueError(f"{where}: a paseq before any atom")
            atoms[-1]["form"] += " " + PASEQ
            atoms[-1]["mam_paseq_kind"] = vel.kind
            continue
        if not isinstance(vel, str) or not vel:
            raise TypeError(f"{where}: {vel!r}")
        atoms.append({"form": vel, "mam_paseq_kind": None})
    return atoms


def wlc420_verses(vids) -> dict[str, list[str]]:
    """WLC 4.20's atoms of the named verses (out/wlc420-u), as written there."""
    rev = {"gn": "Gen", "ex": "Exod", "dt": "Deut"}
    want = set(vids)
    out = {}
    for path in sorted(WLC420.glob("1verses_*.json")):
        for verse in json.loads(path.read_text(encoding="utf-8")):
            m = re.fullmatch(r"([a-z0-9]{2})(\d+):(\d+)", verse["bcv"])
            if not m or m.group(1) not in rev:
                continue
            vid = f"{rev[m.group(1)]}.{m.group(2)}.{m.group(3)}"
            if vid not in want:
                continue
            words = []
            for vel in verse["vels"]:
                if isinstance(vel, str):
                    word = vel
                elif isinstance(vel, dict) and set(vel) == {"sam_pe_inun"}:
                    continue
                elif isinstance(vel, dict) and set(vel) in ({"word"}, {"word", "notes"}):
                    word = vel["word"]
                else:
                    raise ValueError(f"{vid}: unclassified WLC 4.20 element {vel!r}")
                if word.startswith("*"):
                    raise ValueError(f"{vid}: a ketiv or qere, unexpected here: {word!r}")
                words.append(word)
            out[vid] = words
    if set(out) != want:
        raise ValueError(f"WLC 4.20 lacks {sorted(want - set(out))}")
    return out


def split_wlc_atoms(words: list[str]) -> list[str]:
    """WLC 4.20's words split into atoms at each maqaf, the maqaf kept on the atom before it,
    and a paseq written after a space as the JSON writes it."""
    atoms = []
    for word in words:
        word = word.replace(" " + PASEQ, PASEQ)
        parts = word.split(MAQAF)
        for i, p in enumerate(parts):
            if i < len(parts) - 1:
                atoms.append(p + MAQAF)
            elif p:
                atoms.append(p.replace(PASEQ, " " + PASEQ))
    return atoms


def extra_atoms(mam: dict[str, dict]) -> list[dict]:
    """Atom records for the three continuation verses: MAM's strands from MAM-simple, and for
    CLC's strands WLC 4.20's form (MAM's strands agree in these verses, so CLC's division would
    give both strands WLC 4.20's marks; g_accgram.py checks WLC 4.20's accents against MAM's)."""
    wlc = wlc420_verses(EXTRA_VIDS)
    out = []
    for vid in EXTRA_VIDS:
        a_atoms = mam[vid]["alef"]
        b_atoms = mam[vid]["bet"]
        w_atoms = split_wlc_atoms(wlc[vid])
        if [x["form"] for x in a_atoms] != [x["form"] for x in b_atoms]:
            raise ValueError(f"{vid}: MAM's strands differ in a verse assumed undivided")
        if len(w_atoms) != len(a_atoms):
            raise ValueError(f"{vid}: WLC 4.20 has {len(w_atoms)} atoms, MAM {len(a_atoms)}")
        for i, (ma, wa) in enumerate(zip(a_atoms, w_atoms), start=1):
            if letters(ma["form"]) != letters(wa):
                raise ValueError(f"{vid}:{i}: letters differ")
            rec = {
                "vid": vid,
                "book": vid.split(".")[0],
                "atom": i,
                "w_id": None,
                "wlc420": wa,
                "in24": False,
            }
            for s in STRANDS:
                rec[s] = {
                    "mam": ma["form"],
                    "clc": wa.replace(CGJ, ""),
                    "clc_rule_form": None,
                    "supplied": [],
                    "noted": [],
                    "clc_noted_uxlc": [],
                    "own_reading_differences": [],
                }
            out.append(rec)
    return out


def letters(form: str) -> str:
    return "".join(c for c in form if is_letter(c))


# ------------------------------------------------------------------ chanted verses


def chanted_verses(atoms_by_vid: dict[str, list[dict]], book: str, strand: str, source: str):
    """The strand's chanted verses in one passage: lists of atom records, each closed by an atom
    whose form (MAM's or CLC's) has a sof pasuq."""
    out = []
    cur: list[dict] = []
    for vid in PASSAGES[book]:
        if vid is None:
            if cur:
                raise ValueError(f"{book} {strand} {source}: a chanted verse open at a gap")
            continue
        for rec in atoms_by_vid[vid]:
            cur.append(rec)
            if SOF in rec[strand][source]:
                if not rec[strand][source].endswith(SOF):
                    raise ValueError(f"{rec['vid']}:{rec['atom']}: sof pasuq not at the end")
                out.append(cur)
                cur = []
    if cur:
        raise ValueError(f"{book} {strand} {source}: the passage ends inside a chanted verse")
    return out


def cv_label(cv: list[dict]) -> str:
    first, last = cv[0]["vid"], cv[-1]["vid"]
    book, ch, v1 = vid_parts(first)
    _, _, v2 = vid_parts(last)
    return f"{book} {ch}:{v1}" + (f"–{v2}" if v2 != v1 else "")


# ------------------------------------------------------------------ accgram


_PARSER = None


def parser():
    global _PARSER
    if _PARSER is None:
        _PARSER = build_parser()
    return _PARSER


def build_body(forms: list[str]) -> tuple[str, list[tuple[int, int]]]:
    """The scanner's mark body of a chanted verse, built atom by atom as
    uni_to_marks.verse_to_marks builds it, with each atom's span in the body."""
    parts: list[str] = []
    spans = []
    pos = 0
    for form in forms:
        frag = uni_to_marks.word_to_marks(form)
        if parts and not parts[-1].endswith(am.MAQAF):
            parts.append(" ")
            pos += 1
        spans.append((pos, pos + len(frag)))
        parts.append(frag)
        pos += len(frag)
    body = "".join(parts)
    if body != uni_to_marks.verse_to_marks({"vels": list(forms)}):
        raise AssertionError("body rebuilt atom by atom differs from verse_to_marks'")
    return body, spans


_NON_ACCENT_TOKENS = frozenset(("TILDE", "SOFPASUQ", "MISSING_SOFPASUQ"))


def token_atom(token: Token, body: str, spans) -> int:
    """The index of the atom that holds a token's own (head) mark."""
    at = token.start
    if token.type == "METHIGAZAQEF":
        at = body.index(am.ZAQEF_QATAN, token.start)
    for i, (lo, hi) in enumerate(spans):
        if lo <= at < hi:
            return i
    raise AssertionError(f"token {token} at {at} in no atom")


def verdict(forms: list[str], bb: str, ch: int, v: int) -> dict:
    """accgram's verdict on one chanted verse.

    ``grammar``: the scanner and grammar alone, as dual_cant_detangle and printed_decalogue
    run them (a chanted word with no accent simply drops out of the token stream).
    ``lexical``: the prose lexical layer prose_run applies first (lexical_validation).
    ``status``: prose_run's verdict: illegal_mark if the lexical layer finds anything, else the
    grammar's (clean / error / location_only / no_parse).
    """
    body, spans = build_body(forms)
    tokens = [Token("TILDE", "")] + scan_accents(body, bb, ch, v, HasLegarmeh())
    tree = parse_tokens(parser(), tokens)
    if tree is None:
        grammar, tree_obj = "no_parse", None
    elif tree is LOCATION_ONLY:
        grammar, tree_obj = "location_only", None
    else:
        grammar = "error" if _tree_has_error(tree) else "clean"
        tree_obj = tree_to_obj(tree)
    lex = lexical_validation.lexical_ungrammatical(body)
    lex_items = []
    for mark in lex:
        if mark.code == "no accent":
            idx = sorted(_read_atoms_to_index(mark.read_atoms, body, spans))
        else:
            idx = None
        lex_items.append({"code": mark.code, "atom_marks": mark.atom, "atoms": idx})
    acc_tokens = [t for t in tokens if t.type not in _NON_ACCENT_TOKENS]
    return {
        "body": body,
        "spans": spans,
        "tokens": [t.type for t in tokens],
        "accent_tokens": [(t.type, t.leaf, token_atom(t, body, spans)) for t in acc_tokens],
        "grammar": grammar,
        "tree": tree_obj,
        "lexical": lex_items,
        "status": "illegal_mark" if lex else grammar,
    }


def _read_atoms_to_index(read_atoms, body, spans):
    """ucw's read_index ordinals -> our atom indices (every atom of ours is read)."""
    words = ucw.chanted_words(body)
    starts = {}
    for w in words:
        for a in w.atoms:
            starts[a.read_index] = a.start
    out = []
    for r in read_atoms:
        st = starts[r]
        for i, (lo, hi) in enumerate(spans):
            if lo <= st < hi:
                out.append(i)
    return out


# ------------------------------------------------------------------ n codes from a tree

DISJ_LEVEL = {
    "SILLUQ": 1,
    "ATNAX": 1,
    "SEGOLTA": 2,
    "SHALSHELET": 2,
    "ZAQEF": 2,
    "METHIGAZAQEF": 2,
    "ZAQEFGADOL": 2,
    "TIPEXA": 2,
    "MAYELA": 2,
    "REVIA": 3,
    "ZARQA": 3,
    "PASHTA": 3,
    "YETIV": 3,
    "TEVIR": 3,
    "GERESH": 4,
    "GERSHAYIM": 4,
    "PAZER": 4,
    "PAZERGADOL": 4,
    "TELISHAGEDOLA": 4,
    "LEGARMEH": 4,
}
CONJ = frozenset(
    (
        "MUNAX",
        "MAHAPAKH",
        "MERKHA",
        "MERKHAKEFULA",
        "DARGA",
        "QADMA",
        "AZLA",
        "TELISHAQETANNA",
        "GALGAL",
        "MAHAPAKHQADMA",
    )
)
_LEAF_TO_TYPE = {
    "silluq": "SILLUQ",
    "atnax": "ATNAX",
    "segolta": "SEGOLTA",
    "shalshelet": "SHALSHELET",
    "methiga-zaqef": "METHIGAZAQEF",
    "zaqef": "ZAQEF",
    "zaqefgadol": "ZAQEFGADOL",
    "revia": "REVIA",
    "mayela": "MAYELA",
    "tipexa": "TIPEXA",
    "zarqa": "ZARQA",
    "pashta": "PASHTA",
    "yetiv": "YETIV",
    "tevir": "TEVIR",
    "geresh": "GERESH",
    "gershayim": "GERSHAYIM",
    "pazer": "PAZER",
    "pazergadol": "PAZERGADOL",
    "telishagedola": "TELISHAGEDOLA",
    "legarmeh": "LEGARMEH",
    "munax": "MUNAX",
    "mahapakh": "MAHAPAKH",
    "mahapakh!qadma": "MAHAPAKHQADMA",
    "merkha": "MERKHA",
    "merkhakefula": "MERKHAKEFULA",
    "darga": "DARGA",
    "qadma": "QADMA",
    "azla": "AZLA",
    "telishaqetanna": "TELISHAQETANNA",
    "galgal": "GALGAL",
}


def tree_codes(tree_obj: dict, accent_tokens: list) -> dict[int, str]:
    """morphhb's n codes read off accgram's (clean) tree: {accent-token index: code}.

    Each phrase leaf's last token is its disjunctive head.  A clause node X_clause is flattened
    along its right spine (X_clause nodes, ending in the X_phrase leaf): its left children are
    its sub-parts, numbered from k-1 down to 0, and the X_phrase's head carries the clause's own
    code.  At the top, an atnah clause that opens the verse's silluq clause is the part "1" and
    the rest of the silluq clause the part "0"; without an atnah the whole verse is "0".
    """
    leaves = []  # (leaf node, [token indices])
    counter = [0]

    def walk(node):
        if "children" in node:
            for c in node["children"]:
                walk(c)
            return
        names = node["leaves"]
        if "ERROR" in names:
            raise ValueError("tree_codes needs a tree without ERROR")
        idx = list(range(counter[0], counter[0] + len(names)))
        for k, name in zip(idx, names):
            if _LEAF_TO_TYPE[name] != accent_tokens[k][0]:
                raise AssertionError(f"leaf {name} is not token {accent_tokens[k]}")
        counter[0] += len(names)
        leaves.append((id(node), idx))

    walk(tree_obj)
    if counter[0] != len(accent_tokens):
        raise AssertionError("tree leaves and accent tokens differ in number")
    head_of = {nid: idx[-1] for nid, idx in leaves}
    codes: dict[int, str] = {}

    def flatten(node):
        if "children" not in node:
            return [], node
        label = node["label"]
        if not label.endswith("_clause"):
            raise ValueError(f"internal node {label}")
        stem = label[: -len("_clause")]
        subs = []
        cur = node
        while "children" in cur:
            if cur["label"] != label:
                raise ValueError(f"right spine of {label} has {cur['label']}")
            left, right = cur["children"]
            subs.append(left)
            cur = right
        if cur["label"] != f"{stem}_phrase":
            raise ValueError(f"{label} ends in {cur['label']}")
        return subs, cur

    def assign(node, code):
        subs, head = flatten(node)
        k = len(subs)
        for i, sub in enumerate(subs):
            assign(sub, f"{code}.{k - 1 - i}")
        codes[head_of[id(head)]] = code

    subs, head = flatten(tree_obj)
    if tree_obj["label"] not in ("silluq_clause", "silluq_phrase"):
        raise ValueError(f"root {tree_obj['label']}")
    rest = subs
    if subs and subs[0]["label"] in ("atnax_clause", "atnax_phrase"):
        assign(subs[0], "1")
        rest = subs[1:]
    k = len(rest)
    for i, sub in enumerate(rest):
        assign(sub, f"0.{k - 1 - i}")
    codes[head_of[id(head)]] = "0"
    return codes


def level_codes(types: list[str]) -> tuple[dict[int, str], list[str]]:
    """An independent continuous-dichotomy coding from the accent levels alone.

    Levels (Yeivin's four classes of prose disjunctives): 1 silluq, atnah; 2 segolta,
    shalshelet, zaqef (and metigah-zaqef, zaqef gadol), tipeha (and mayela); 3 revia, zarqa,
    pashta, yetiv, tevir; 4 geresh, gershayim, pazer, pazer gadol, telisha gedolah, legarmeh.
    Each disjunctive belongs to the part of the nearest following disjunctive of a stronger
    (lower-numbered) level; the level-1 disjunctives are the verse's top parts.  The parts
    under one head are numbered from k-1 down to 0 in order, and the head carries its part's
    code; the top parts are atnah "1" and silluq "0", or silluq "0" alone.  Conjunctives get
    nothing.  Returns {token index: code} and a list of irregularities.
    """
    notes = []
    levels = []
    for t in types:
        if t in DISJ_LEVEL:
            levels.append(DISJ_LEVEL[t])
        elif t in CONJ:
            levels.append(None)
        else:
            raise ValueError(f"unclassified token {t}")
    disj = [i for i, lv in enumerate(levels) if lv is not None]
    parent = {}
    for i in disj:
        p = None
        for j in disj:
            if j > i and levels[j] < levels[i]:
                p = j
                break
        parent[i] = p
    top = [i for i in disj if parent[i] is None]
    if [types[i] for i in top] not in (["ATNAX", "SILLUQ"], ["SILLUQ"]):
        notes.append(f"top parts {[types[i] for i in top]}")
    children: dict[int, list[int]] = {}
    for i in disj:
        if parent[i] is not None:
            children.setdefault(parent[i], []).append(i)
    codes: dict[int, str] = {}

    def assign(i, code):
        codes[i] = code
        kids = children.get(i, [])
        lv = {levels[c] for c in kids}
        if len(lv) > 1:
            notes.append(f"{types[i]} at {i} has parts of levels {sorted(lv)}")
        k = len(kids)
        for n, c in enumerate(kids):
            assign(c, f"{code}.{k - 1 - n}")

    k = len(top)
    for n, i in enumerate(top):
        assign(i, str(k - 1 - n))
    return codes, notes


def atom_codes(accent_tokens: list, codes: dict[int, str], n_atoms: int) -> list[list[str]]:
    """Per atom, the codes of the disjunctive heads it holds (normally zero or one)."""
    out: list[list[str]] = [[] for _ in range(n_atoms)]
    for k, code in codes.items():
        out[accent_tokens[k][2]].append(code)
    return out


# ------------------------------------------------------------------ morphhb base files

NS = "{http://www.bibletechnologies.net/2003/OSIS/namespace}"


def _local(tag):
    return tag.rsplit("}", 1)[-1]


def morphhb_verses(vids) -> dict[str, list[dict]]:
    """morphhb's main-text <w> elements of each verse, in order: id, text (slashes removed),
    n, and the following maqaf, paseq and sof pasuq segs.  A ketiv's <w> is skipped and its
    qere's <w> (inside the variant note) taken in its place, as the apps take n from it."""
    want = set(vids)
    out = {}
    for book in ("Gen", "Exod", "Deut"):
        root = ET.parse(BASE / f"{book}.xml").getroot()
        for v in root.iter(f"{NS}verse"):
            vid = v.get("osisID")
            if vid not in want:
                continue
            words: list[dict] = []
            for el in v:
                t = _local(el.tag)
                if t == "w":
                    if el.get("type") == "x-ketiv":
                        continue
                    words.append(_w_record(el))
                elif t == "seg":
                    st = el.get("type")
                    if st in ("x-maqqef", "x-paseq", "x-sof-pasuq"):
                        words[-1][st] = True
                    elif st in ("x-pe", "x-samekh", "x-reversednun"):
                        pass
                    else:
                        raise ValueError(f"{vid}: seg {st}")
                elif t == "note":
                    nt = el.get("type")
                    if nt == "variant":
                        qere = [c for c in el.iter() if _local(c.tag) == "w"]
                        if len(qere) != 1:
                            raise ValueError(f"{vid}: variant note with {len(qere)} <w>")
                        words.append(_w_record(qere[0]))
                    elif nt == "alternative":
                        rdg = [c for c in el if _local(c.tag) == "rdg"]
                        cw = [c for c in el if _local(c.tag) == "catchWord"]
                        words[-1].setdefault("alternatives", []).append(
                            {
                                "catchWord": "".join(cw[0].itertext()).replace("/", ""),
                                "rdg": "".join(rdg[0].itertext()).replace("/", ""),
                            }
                        )
                    elif el.get("n") is not None and nt is None:
                        pass
                    else:
                        raise ValueError(f"{vid}: note type {nt}")
                else:
                    raise ValueError(f"{vid}: element {t}")
            out[vid] = words
    if set(out) != want:
        raise ValueError(f"base files lack {sorted(want - set(out))}")
    return out


def _w_record(el) -> dict:
    return {
        "id": el.get("id"),
        "text": "".join(el.itertext()).replace("/", ""),
        "n": el.get("n"),
    }


def search_minimal_fixes(cv, strand, forms_bad, forms_good, ok, max_k=4):
    """The smallest sets of atoms whose substitution (good form for bad) makes ``ok`` true.

    ``cv`` is the chanted verse's atom list, ``forms_bad``/``forms_good`` parallel form lists,
    ``ok(forms) -> bool``.  Candidates are the atoms whose scanner marks differ, the two forms
    compared in MAM-normal mark order (give_std_mark_order).  Returns (k, [index tuples],
    candidates); k is None if no set of up to max_k atoms works.
    """
    cand = [
        i
        for i in range(len(cv))
        if uni_to_marks.word_to_marks(std(forms_bad[i]))
        != uni_to_marks.word_to_marks(std(forms_good[i]))
    ]
    for k in range(1, min(max_k, len(cand)) + 1):
        hits = []
        for combo in combinations(cand, k):
            trial = list(forms_bad)
            for i in combo:
                trial[i] = forms_good[i]
            if ok(trial):
                hits.append(combo)
        if hits:
            return k, hits, cand
    return None, [], cand

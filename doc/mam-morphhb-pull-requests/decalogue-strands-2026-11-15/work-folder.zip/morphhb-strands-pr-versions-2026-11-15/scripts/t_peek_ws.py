"""Sub-agent T: peek at the structure of in/mam-ws/A2-Exodus.json (read-only)."""

import json
import sys
from pathlib import Path

SRC = Path("C:/Users/BenDe/GitRepos/MAM-basics/in/mam-ws/A2-Exodus.json")
OUT = Path(
    "C:/Users/BenDe/GitRepos/MAM-basics/.novc/morphhb-strands-pr-versions-2026-11-15/scratch-t/peek_ws.txt"
)


def describe(obj, depth=0, maxdepth=3):
    pad = "  " * depth
    lines = []
    if isinstance(obj, dict):
        lines.append(f"{pad}dict with {len(obj)} keys: {list(obj)[:12]}")
        if depth < maxdepth:
            for k in list(obj)[:3]:
                lines.append(f"{pad} key {k!r}:")
                lines.extend(describe(obj[k], depth + 1, maxdepth))
    elif isinstance(obj, list):
        lines.append(f"{pad}list of {len(obj)}")
        if obj and depth < maxdepth:
            lines.extend(describe(obj[0], depth + 1, maxdepth))
    else:
        lines.append(f"{pad}{type(obj).__name__}: {str(obj)[:300]!r}")
    return lines


def main():
    data = json.loads(SRC.read_text(encoding="utf-8"))
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with OUT.open("w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(describe(data, 0, 5)) + "\n")
    print(f"wrote {OUT}", file=sys.stderr)


main()

"""Is morphhb's mark order (base files) the same as the order of folder S's WLC 4.20 forms?

For each of the 242 atoms: the base main <w> text without slashes, against WLC 4.20's form and
each strand's CLC-rule form (without trailing punctuation). Counts code-point equality and
equality in MAM-normal order, and prints the atoms equal only in MAM-normal order.
"""

import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))  # untracked scratch: exempt
import strands_core as sc  # noqa: E402


def main_w_texts():
    out = {}
    for book in sc.BOOKS:
        text = sc.load_base(book)
        for m in re.finditer(r'<w [^>]*id="([^"]+)"[^>]*>([^<]*)</w>', text):
            out[m.group(1)] = m.group(2)
    return out


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    w = main_w_texts()
    counts = {}
    for a in sc.load_atoms():
        t = w[a["morphhb_w_id"]].replace("/", "")
        cands = {"wlc420": sc.split_form(a["wlc420"])[0]}
        for s in ("alef", "bet"):
            cands["clc_" + s] = sc.split_form(a[s]["clc_rule_form"])[0]
        cp = [k for k, v in cands.items() if v == t]
        st = [k for k, v in cands.items() if sc.std(v) == sc.std(t)]
        key = "cp" if cp else ("std-only" if st else "none")
        counts[key] = counts.get(key, 0) + 1
        if key != "cp":
            print(key, a["vid"], a["atom"], ascii(t), {k: ascii(v) for k, v in cands.items()})
    print(counts)


main()

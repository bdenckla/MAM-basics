"""Sub-agent I: census of the non-ASCII characters of the named files (read-only).

Usage (-I, MAM-basics root): i_char_census.py <file> [<file> ...]
Prints each distinct non-ASCII character with its Unicode name and count, and the line numbers
of any character outside the Hebrew block, Latin-1, General Punctuation and U+1E00-U+1EFF.
"""

import sys
import unicodedata
from collections import Counter
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")
for name in sys.argv[1:]:
    text = Path(name).read_text(encoding="utf-8")
    c = Counter(ch for ch in text if ord(ch) > 127)
    print("==", Path(name).name)
    for ch, n in sorted(c.items()):
        print(f"   U+{ord(ch):04X} {unicodedata.name(ch, '?')}: {n}")
    for i, ln in enumerate(text.splitlines(), 1):
        odd = [
            ch
            for ch in ln
            if ord(ch) > 127
            and not (
                0x0590 <= ord(ch) <= 0x05FF
                or 0x00A0 <= ord(ch) <= 0x00FF
                or 0x2000 <= ord(ch) <= 0x206F
                or 0x1E00 <= ord(ch) <= 0x1EFF
                or ord(ch) == 0x1F916
            )
        ]
        if odd:
            print(
                f"   line {i}: unexpected {[unicodedata.name(x, hex(ord(x))) for x in odd]}"
            )

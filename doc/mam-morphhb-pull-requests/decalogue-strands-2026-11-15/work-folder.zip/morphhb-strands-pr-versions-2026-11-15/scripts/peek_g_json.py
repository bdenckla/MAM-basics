"""Print the top-level structure of out/53-accgram.json (keys, sizes, one sample each)."""

import json
import sys
from pathlib import Path

W = Path(__file__).resolve().parent.parent
sys.stdout.reconfigure(encoding="utf-8")
d = json.loads((W / "out/53-accgram.json").read_text(encoding="utf-8"))
for k, v in d.items():
    if isinstance(v, dict):
        first = next(iter(v.items())) if v else None
        print(f"{k}: dict({len(v)}) sample {ascii(first)[:220]}")
    elif isinstance(v, list):
        print(f"{k}: list({len(v)}) sample {ascii(v[0])[:220] if v else None}")
    else:
        print(f"{k}: {ascii(v)[:220]}")

"""Sub-agent I (2026-11-15): list every main-text <w> of the 24 verses whose n the build changes.

Throwaway scratch for the morphhb strands pull request (prepared, not posted), written by Claude.
Run with -I from the MAM-basics root:

    ./.venv/Scripts/python.exe -I .novc/morphhb-strands-pr-versions-2026-11-15/scripts/i_n_changes.py

Reads the base files (fetched/base-696e21ce), the build (out/build-A), out/54-for-build.json and
out/60-versions.json (versions.py's: which main texts are illegal). Writes
out/57-n-changes.txt (verse, atom, id, old n, new n, the new main text's accents, its form) and
out/57-n-changes.json (the same rows, and every main-text atom's codes, for the decision page).
Raises if any build n differs from new_n. A ketiv's code is on its qere's <w>, which stands for
the atom here.
"""

import json
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

W = Path(__file__).resolve().parent.parent
NS = "{http://www.bibletechnologies.net/2003/OSIS/namespace}"
VIDS = (
    ["Gen.35.22"]
    + [f"Exod.20.{v}" for v in (2, 3, 4, 5, 6, 8, 9, 10, 13, 14, 15)]
    + [f"Deut.5.{v}" for v in (6, 7, 8, 9, 10, 12, 13, 14, 15, 17, 18, 19)]
)
H = "\N{LATIN SMALL LETTER H WITH DOT BELOW}"
ACCENT_NAME = {
    "\N{HEBREW ACCENT ETNAHTA}": f"atna{H}",
    "\N{HEBREW ACCENT SEGOL}": "segolta",
    "\N{HEBREW ACCENT SHALSHELET}": "shalshelet",
    "\N{HEBREW ACCENT ZAQEF QATAN}": "zaqef qatan",
    "\N{HEBREW ACCENT ZAQEF GADOL}": "zaqef gadol",
    "\N{HEBREW ACCENT TIPEHA}": f"tipe{H}a",
    "\N{HEBREW ACCENT REVIA}": "revia",
    "\N{HEBREW ACCENT ZARQA}": "zarqa",
    "\N{HEBREW ACCENT PASHTA}": "pashta",
    "\N{HEBREW ACCENT YETIV}": "yetiv",
    "\N{HEBREW ACCENT TEVIR}": "tevir",
    "\N{HEBREW ACCENT GERESH}": "geresh",
    "\N{HEBREW ACCENT GERESH MUQDAM}": "geresh muqdam",
    "\N{HEBREW ACCENT GERSHAYIM}": "gershayim",
    "\N{HEBREW ACCENT QARNEY PARA}": "pazer gadol",
    "\N{HEBREW ACCENT TELISHA GEDOLA}": "telisha gedolah",
    "\N{HEBREW ACCENT PAZER}": "pazer",
    "\N{HEBREW ACCENT MUNAH}": f"muna{H}",
    "\N{HEBREW ACCENT MAHAPAKH}": "mahapakh",
    "\N{HEBREW ACCENT MERKHA}": "merkha",
    "\N{HEBREW ACCENT MERKHA KEFULA}": "merkha kefulah",
    "\N{HEBREW ACCENT DARGA}": "darga",
    "\N{HEBREW ACCENT QADMA}": "qadma",
    "\N{HEBREW ACCENT TELISHA QETANA}": "telisha qetannah",
    "\N{HEBREW ACCENT YERAH BEN YOMO}": "galgal",
    "\N{HEBREW ACCENT ZINOR}": "zarqa",
}
METEG = "\N{HEBREW POINT METEG}"
SEG_CHAR = {
    "x-maqqef": "\N{HEBREW PUNCTUATION MAQAF}",
    "x-paseq": "\N{HEBREW PUNCTUATION PASEQ}",
    "x-sof-pasuq": "\N{HEBREW PUNCTUATION SOF PASUQ}",
}


def local(el):
    return el.tag.replace(NS, "")


def main_atoms(verse):
    """[(w element, trailing seg types)] of a verse's main text, a ketiv replaced by its qere."""
    out = []
    for el in verse:
        t = local(el)
        if t == "w":
            if el.get("type") == "x-ketiv":
                continue
            out.append([el, []])
        elif t == "note" and el.get("type") == "variant":
            out.append([list(el.iter(NS + "w"))[0], []])
        elif t == "seg" and el.get("type") in SEG_CHAR:
            out[-1][1].append(el.get("type"))
    return out


def accents(text, segs):
    """The romanized names of a main text's accents, a doubled accent named once."""
    names = []
    for ch in text:
        if ch in ACCENT_NAME and (not names or names[-1] != ACCENT_NAME[ch]):
            names.append(ACCENT_NAME[ch])
    if "x-paseq" in segs and names == [f"muna{H}"]:
        names = ["legarmeh"]
    elif "x-paseq" in segs:
        names.append("paseq")
    if not names and METEG in text and "x-sof-pasuq" in segs:
        names = ["silluq"]
    return names


def verses(d):
    out = {}
    for book in ("Gen", "Exod", "Deut"):
        for v in ET.parse(Path(d) / f"{book}.xml").getroot().iter(NS + "verse"):
            if v.get("osisID") in VIDS:
                out[v.get("osisID")] = v
    return out


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    new_n = json.loads((W / "out/54-for-build.json").read_text(encoding="utf-8"))[
        "new_n"
    ]
    recs = {
        r["w_id"]: r
        for r in json.loads((W / "out/60-versions.json").read_text(encoding="utf-8"))
    }
    base, build = verses(W / "fetched/base-696e21ce"), verses(W / "out/build-A")
    rows, every = [], []
    for vid in VIDS:
        b_atoms, n_atoms = main_atoms(base[vid]), main_atoms(build[vid])
        if [w.get("id") for w, _ in b_atoms] != [w.get("id") for w, _ in n_atoms]:
            raise ValueError(f"{vid}: main-text ids differ")
        for k, ((bw, _), (nw, segs)) in enumerate(zip(b_atoms, n_atoms), start=1):
            wid = nw.get("id")
            if nw.get("n") != new_n[wid]:
                raise SystemExit(
                    f"{vid}:{k} {wid}: build n {nw.get('n')!r}, new_n {new_n[wid]!r}"
                )
            r = recs[wid]
            if r["atom"] != k:
                raise ValueError(f"{vid}: {wid} is atom {r['atom']}, not {k}")
            text = (nw.text or "").replace("/", "")
            form = text + "".join(SEG_CHAR[s] for s in segs)
            illegal = r["failed"][r["main_strand"]]
            row = {
                "vid": vid,
                "atom": k,
                "w_id": wid,
                "old": bw.get("n"),
                "new": nw.get("n"),
                "accents": accents(text, segs),
                "form": form,
                "main_text_illegal": illegal,
            }
            every.append(row)
            if row["old"] != row["new"]:
                rows.append(row)
    lines = [
        "Sub-agent I (Claude, 2026-11-15), not reviewed by a human: every main-text <w> of the 24",
        "verses whose n the build (out/build-A) changes from the base (696e21ce), by",
        "scripts/i_n_changes.py. 'accents' are the new main text's (CLC's main strand); where that",
        "is illegal, the code follows MAM's strand (decision 11A). A ketiv's code is its qere's.",
        "",
        "verse      atom  id     old n      new n      main text's accents          form",
    ]
    for r in rows:
        acc = ", ".join(r["accents"]) or "none"
        if r["main_text_illegal"]:
            acc += f" (illegal: {','.join(r['main_text_illegal'])})"
        lines.append(
            f"{r['vid']:10} {r['atom']:>4}  {r['w_id']}  {str(r['old']):10} {str(r['new']):10} {acc:28} {r['form']}"
        )
    changed_vids = [v for v in VIDS if any(r["vid"] == v for r in rows)]
    lines += [
        "",
        f"atoms whose n changes: {len(rows)}, in {len(changed_vids)} verses: {', '.join(changed_vids)}",
        f"main-text <w> checked against new_n: {len(every)} (all equal)",
        f"codes gained: {sum(1 for r in rows if r['old'] is None)}; lost: {sum(1 for r in rows if r['new'] is None)}; "
        f"changed: {sum(1 for r in rows if r['old'] is not None and r['new'] is not None)}",
        f"verses with no n=\"0\" in the build: {', '.join(v for v in VIDS if not any(r['vid'] == v and r['new'] == '0' for r in every))}",
    ]
    (W / "out/57-n-changes.txt").write_text(
        "\n".join(lines) + "\n", encoding="utf-8", newline="\n"
    )
    (W / "out/57-n-changes.json").write_text(
        json.dumps(
            {"changes": rows, "every_atom": every}, ensure_ascii=False, indent=1
        ),
        encoding="utf-8",
        newline="\n",
    )
    print("\n".join(lines[-4:]))


main()

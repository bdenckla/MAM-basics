"""Sub-agent I (2026-11-15): write out/56-spot-checks.md from the two spot-check outputs.

Throwaway scratch for the morphhb strands pull request (prepared, not posted), written by Claude.
Run with -I from the MAM-basics root, after i_spot_fetched.py (-I) and i_spot_mam.py (-B):

    ./.venv/Scripts/python.exe -I .novc/morphhb-strands-pr-versions-2026-11-15/scripts/i_spot_report.py

Reads scratch-i/56a-spot-fetched.json and scratch-i/56b-spot-mam.json; every Hebrew form in the
report is copied from them.
"""

import json
import sys
from pathlib import Path

W = Path(__file__).resolve().parent.parent
H = "\N{LATIN SMALL LETTER H WITH DOT BELOW}"
HU = "\N{LATIN CAPITAL LETTER H WITH DOT BELOW}"


def yes(b):
    return "yes" if b else "no"


def names(xs):
    return ", ".join(x.replace("HEBREW POINT ", "").lower() for x in xs) or "none"


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    a = json.loads((W / "scratch-i/56a-spot-fetched.json").read_text(encoding="utf-8"))
    b = json.loads((W / "scratch-i/56b-spot-mam.json").read_text(encoding="utf-8"))
    r50, r52, r51, r53 = a["50"], a["52"], b["51"], b["53"]
    d52 = r52["hets whose point differs"]
    ketiv_hets = r52["hets in morphhb's ketiv <w>, not compared"]
    lc_meteg = r51["LC's atom 2 as quoted: shin has meteg"]
    lc_other = r51["LC's atom 2 as quoted: shin has qadma or merkha"]
    wlc_form = r51["WLC 4.20's atom 2"]
    wlc_merkha = r51["WLC 4.20's shin has merkha"]
    wlc_meteg = r51["WLC 4.20's shin has meteg"]
    clc_form = r51["CLC's tahton by CLC's rules"]
    clc_merkha = r51["CLC's tahton shin has merkha"]
    g_clc = r53["CLC's tahton: grammar"]
    e_clc = r53["CLC's tahton: error phrases"]
    l_clc = r53["CLC's tahton: lexical findings"]
    g_fix = r53["with MAM's atom 2: grammar"]
    l_fix = r53["with MAM's atom 2: lexical findings"]
    others = r53[
        "other atoms where CLC's form differs from MAM's, each substituted alone"
    ]
    L = [
        "Claude's work (Opus 5.5, sub-agent I, 2026-11-15, New York time), not reviewed by a human; read-only; nothing was posted, pushed, committed or fetched.",
        "",
        "# Spot checks of reports 50 to 53",
        "",
        "One material claim from each report, re-checked against its source by a script of this sub-agent's own, not by the report's scripts. "
        "Readings are attributed to morphhb, WLC 4.20, CLC (its rules applied to WLC 4.20) or MAM; the claim checked from report 51 is about what MAM's documentation says, not about the Leningrad Codex.",
        "",
        "## Answers in brief",
        "",
        f"1. **Report 50, BibleOrgSys and `note@subType`: holds** ({yes(r50['holds'])}).",
        f"2. **Report 51, MAM's note at Deuteronomy 5:8, atom 2: holds** ({yes(r51['holds'])}).",
        f"3. **Report 52, Exodus 20:5's {H}et the only one whose point morphhb changes: holds** ({yes(r52['holds'])}).",
        f"4. **Report 53, criterion (iv) at Deuteronomy 5:8, atom 2: holds** ({yes(r53['holds'])}).",
        "",
        "## 1. Report 50: BibleOrgSys refuses `note@subType` under strict checking",
        "",
        '**Claim** (`out/50-readers-encoding.md`, table, BibleOrgSys row): BibleOrgSys\'s `OSISXMLBible.py` (`a9342af5`) logs load error "2s4d" for every note with `subType`, and an assertion stops the load under strict checking (lines 958 to 968).',
        "",
        f"**Source:** `{r50['file']}`, whose Git blob SHA-1, `{r50['blob sha']}`, is {'equal' if r50['blob sha matches blob.json'] else 'NOT equal'} to the one its `blob.json` records.",
        "",
        "**Result.**",
        "",
        f"- `validateCrossReferenceOrFootnote` (from line {r50['function starts at line']}) accepts on a `<note>` only the attributes {', '.join('`' + x + '`' for x in r50['attributes accepted in lines 958-968'])}; `subType` accepted: {yes(r50['subType accepted'])}.",
        f"- Any other attribute logs the warning \"2s4d\" and appends a load error: {yes(r50['2s4d warning and load error in the else branch'])}; the same branch asserts when `strictCheckingFlag` is set: {yes(r50['assert under strictCheckingFlag'])}.",
        f"- Of the {len(r50['live note branches'])} branches of the file's code, not commented out, that handle a `<note>` element, {r50['of them calling it']} call that function; the other is inside the function itself, for a note within a note.",
        "",
        "## 2. Report 51: MAM's note at Deuteronomy 5:8, atom 2",
        "",
        "**Claim** (`out/51-mam-documentation.md`, case 3): MAM's note on this chanted word (MAM's Deuteronomy 5:7) quotes the Leningrad Codex with the meteg on the shin, naming as missing only the תחתון's qadma, while WLC 4.20 has a merkha on that shin. The brief adds that CLC's rules give that merkha to the תחתון.",
        "",
        "**Source:** MAM-basics' mirror `in/mam-ws/A5-Deuter.json`, chapter ה, read directly; WLC 4.20 in `out/wlc420-u`; folder S's `out/22-clc-answers.json`.",
        "",
        "**Result.**",
        "",
        f"- Chapter ה has exactly one note whose explanation names a missing qadma on a letter. The form it quotes after the sigil ל!, MAM's sigil for the Leningrad Codex: {r51['lc_form_quoted']}; its explanation: {r51['explanation']}.",
        f"- On the shin of that form's second atom, a meteg: {yes(lc_meteg)}; a qadma or a merkha: {yes(lc_other)}. Marks the explanation names: {', '.join(m.lower() for m in r51['marks named in the explanation'])}.",
        f"- WLC 4.20's atom, {wlc_form}, has a merkha on the shin: {yes(wlc_merkha)}; a meteg there: {yes(wlc_meteg)}.",
        f"- CLC's תחתון by CLC's rules, {clc_form}, has the merkha: {yes(clc_merkha)}.",
        "",
        f"## 3. Report 52: Exodus 20:5's {H}et is the only one whose point morphhb changes",
        "",
        f"**Claim** (`out/52-sheva.md`, finding 3): across the corpus, Exodus 20:5 is the only {H}et whose point in morphhb's main text differs from WLC 4.20's (27,743 {H}ets compared, 1,781 with a sheva in WLC 4.20).",
        "",
        f"**Source:** morphhb's `wlc/` as folder F fetched it at `d4265dfa` (equal in `wlc/` to master `db6c5c9b`), all {r52['books']} books; WLC 4.20 in MAM-basics' `out/wlc420-u`.",
        "",
        f"**Method, independent of report 52's alignment:** per verse, the sequence of the vowel points under each {H}et, in WLC 4.20's words (a ketiv left out, a qere kept) and in morphhb's main text (a ketiv's `<w>` left out, its qere's `<w>` kept), compared position by position; a verse whose {H}et counts differ would be left out.",
        "",
        "**Result.**",
        "",
        f"- {r52['verses in morphhb']:,} verses, {r52['verses left out']} left out; {r52['hets compared']:,} {H}ets compared, {r52['of them with a sheva in WLC 4.20']:,} of them with a sheva in WLC 4.20. The {ketiv_hets} {H}ets of morphhb's ketiv elements, not compared here, make up the difference from report 52's 27,743.",
        f"- {HU}ets whose point differs: {len(d52)}: "
        + "; ".join(
            f"{d['vid']}, the verse's {H}et {d['het']}: WLC 4.20 {' '.join(d['wlc420'])}, morphhb {' '.join(d['morphhb'])}"
            for d in d52
        )
        + f" (U+05B0 is the sheva, U+05B2 the {H}ataf pata{H}).",
        "",
        "## 4. Report 53: criterion (iv) at Deuteronomy 5:8, atom 2",
        "",
        "**Claim** (`out/53-accgram.md`, answer 5): WLC 4.20's merkha at Deuteronomy 5:8, atom 2, which CLC's rules give to the תחתון, makes the תחתון's chanted verse Deuteronomy 5:8 ungrammatical, with a `pashta_phrase` ERROR, and MAM's qadma alone makes it grammatical.",
        "",
        "**Source:** folder S's `out/22-clc-answers.json` (CLC's תחתון of the verse, brackets removed, and MAM's); accgram's own functions, called directly: `uni_to_marks.verse_to_marks`, `prose_scanner.scan_accents`, `prose_ply_grammar`, `lexical_validation`.",
        "",
        "**Result.**",
        "",
        f"- CLC's תחתון: grammar {g_clc}, ERROR in {', '.join('`' + x + '`' for x in e_clc) or 'nothing'}; lexical findings: {', '.join(l_clc) or 'none'}. Its first tokens: {' '.join(r53['tokens, CLC'])}.",
        f"- With MAM's form of atom 2 alone: grammar {g_fix}; lexical findings: {', '.join(l_fix) or 'none'}. Its first tokens: {' '.join(r53['tokens, with MAM' + chr(39) + 's atom 2'])}.",
        "- The other atoms where CLC's form differs from MAM's, each substituted alone, leave the verse as it was: "
        + "; ".join(
            f"atom {o['atom']}, {o['grammar']} (CLC's form alone has {names(o['marks only CLC' + chr(39) + 's form has'])}, MAM's alone {names(o['marks only MAM' + chr(39) + 's form has'])})"
            for o in others
        )
        + ".",
        "",
        "## Files",
        "",
        "`scripts/i_spot_fetched.py` (checks 1 and 3, run with -I since it reads fetched files), `scripts/i_spot_mam.py` (checks 2 and 4, run with -B since it imports accgram), `scripts/i_spot_report.py` (this file); their outputs are `scratch-i/56a-spot-fetched.json` and `scratch-i/56b-spot-mam.json`.",
    ]
    (W / "out/56-spot-checks.md").write_text(
        "\n".join(L) + "\n", encoding="utf-8", newline="\n"
    )
    print("wrote", W / "out/56-spot-checks.md")


main()

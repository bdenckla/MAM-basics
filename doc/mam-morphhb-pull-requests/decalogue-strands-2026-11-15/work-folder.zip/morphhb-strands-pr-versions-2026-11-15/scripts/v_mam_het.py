"""Sub-agent V: every het where WLC 4.20 has a sheva and MAM a hataf patah, and morphhb's point
there.  An added check of the premise that WLC's sheva at Exodus 20:5 has precedents.

Throwaway scratch for the morphhb strands pull request (prepared, not posted).  Written by Claude
(Opus 5.5, sub-agent V), 2026-11-15.  Run from C:/Users/BenDe/GitRepos/MAM-basics in PowerShell 7:

    ./.venv/Scripts/python.exe -B .novc/morphhb-strands-pr-versions-2026-11-15/scripts/v_mam_het.py

Writes only .novc/morphhb-strands-pr-versions-2026-11-15/out/52-mam-het.json, and prints a
summary.  Uses scripts/v_census.py's readers and alignment (imported; -B writes no bytecode).

Method.  For every verse of WLC 4.20, MAM's verse is read from MAM-simple as v_census reads it,
on the ketiv side and the qere side, a dual cantillation in cant-combined.  WLC 4.20's ketiv-side
and qere-side atoms are aligned with MAM's by letters; in every pair with equal letters the point
under each het is compared.  For each het where WLC 4.20 has a sheva and MAM a hataf patah,
morphhb's atom is found by v_census's alignment of WLC 4.20 with morphhb, and its point given.
"""

import sys

sys.dont_write_bytecode = True

import json  # noqa: E402
from collections import Counter  # noqa: E402
from pathlib import Path  # noqa: E402

SCRIPTS = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPTS))

import v_census as V  # noqa: E402

OUT = V.W / "out" / "52-mam-het.json"


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    lint = V.load_lint()
    short_of = {osis: short for short, osis in lint._OSIS.items()}
    wlc = V.C.read_wlc42x("4.20")
    mhb = {}
    for osis, _tu, _mc in V.C.BOOKS:
        mhb.update(V.C.read_morphhb_book(V.C.morphhb_path(V.F_FETCHED, osis)))
    pairs_count = Counter()
    no_mam = []
    unaligned = Counter()
    cases = []
    for (osis, ch, vs), raw in wlc.items():
        vid = f"{osis}.{ch}.{vs}"
        where_w = f"WLC 4.20 {vid}"
        w_atoms = [
            a for a in raw if a["spi"] is None and a["text"] not in ("kk", "qq")
        ]
        try:
            node = lint._verse(short_of[osis], ch, vs)
        except AssertionError:
            no_mam.append(vid)
            continue
        seq = V.mhb_sequence(mhb[vid], vid)
        w_all_letters = [V.letters(a["text"], where_w) for a in w_atoms]
        m_letters = [V.letters(a["text"], "morphhb " + vid) for a in seq]
        to_mhb, _other = V.align(w_all_letters, m_letters)
        for side in ("ketiv", "qere"):
            keep = (None, "k") if side == "ketiv" else (None, "q")
            idx = [n for n, a in enumerate(w_atoms) if a["kq"] in keep]
            text = lint._verse_text(node, side, "cant-combined", f"MAM {vid}")
            if text == "\N{EM DASH}":
                # MAM-simple's BHS versification: "no verse in MAM" here.
                if side == "qere":
                    no_mam.append(vid + " (no verse in MAM)")
                continue
            mam_atoms = [a for a in V.C.form_atoms(text) if V.letters(a, f"MAM {vid}")]
            sub = [w_all_letters[n] for n in idx]
            mam_letters = [V.letters(a, f"MAM {vid}") for a in mam_atoms]
            pairs, _other = V.align(sub, mam_letters)
            unaligned[f"{side}: WLC 4.20 atoms not in an equal block"] += len(sub) - len(pairs)
            for p, q in pairs.items():
                n = idx[p]
                if side == "ketiv" and w_atoms[n]["kq"] is None:
                    continue  # a plain atom is counted once, on the qere side
                wa, ma = w_atoms[n], mam_atoms[q]
                for (k, pw), (_k, pm) in zip(
                    V.het_points(wa["text"], where_w), V.het_points(ma, f"MAM {vid}")
                ):
                    pairs_count[(pw, pm)] += 1
                    if pw == "sheva" and pm == "hataf patah":
                        mrec = None
                        if n in to_mhb:
                            mx = seq[to_mhb[n]]
                            mrec = {
                                "form": V.mhb_display(mx),
                                "point": V.point_at(mx["text"], k, "morphhb"),
                                "alt_point": None
                                if mx["alt"] is None
                                else V.point_at(mx["alt"], k, "morphhb alt"),
                            }
                        cases.append(
                            {
                                "vid": vid,
                                "side": side,
                                "wlc_atom": n + 1,
                                "letter": k + 1,
                                "wlc420": wa["text"],
                                "wlc420_notes": wa["notes"],
                                "mam": ma,
                                "morphhb": mrec,
                            }
                        )
    summary = {
        "verses_without_mam": no_mam,
        "unaligned": dict(unaligned),
        "het_points_compared": sum(pairs_count.values()),
        "het_pairs_differing": {
            f"{a} | {b}": n for (a, b), n in sorted(pairs_count.items()) if a != b
        },
        "wlc420_sheva_mam_hataf_patah": len(cases),
        "morphhb_point_at_those": dict(
            Counter((c["morphhb"] or {}).get("point", "not aligned") for c in cases)
        ),
    }
    OUT.write_text(
        json.dumps({"summary": summary, "cases": cases}, ensure_ascii=False, indent=1) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(json.dumps(summary, ensure_ascii=True, indent=1))


if __name__ == "__main__":
    main()

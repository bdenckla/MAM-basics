"""Sub-agent T: print, through ascii(), the lines of a file that hold non-ASCII.

Usage: t_ascii_lines.py <file>
"""

import sys
from pathlib import Path


def main():
    path = Path(sys.argv[1])
    for i, line in enumerate(path.read_text(encoding="utf-8").split("\n"), start=1):
        if any(ord(c) > 127 for c in line):
            print(i, ascii(line))


main()

"""Sub-agent G (2026-11-15): write W/out/53-accgram.json and W/out/53-accgram.md.

Throwaway scratch for the morphhb strands pull request (prepared, not posted), written by Claude.
Run after g_accgram.py, g_ncodes.py and g_ncheck_books.py, from C:/Users/BenDe/GitRepos/MAM-basics:

    ./.venv/Scripts/python.exe -I .novc/morphhb-strands-pr-versions-2026-11-15/scripts/g_report.py

Reads only W/scratch-g/*.json and folder S's 22-clc-answers.json.  Every Hebrew form and strand
name in the report is copied from those files; the prose's transliterations use the placeholder
"~h" for the precomposed h with dot below.
"""

import json
import sys
from collections import Counter, OrderedDict
from pathlib import Path

W = Path("C:/Users/BenDe/GitRepos/MAM-basics/.novc/morphhb-strands-pr-versions-2026-11-15")
S = Path("C:/Users/BenDe/GitRepos/MAM-basics/.novc/morphhb-strands-pr-2026-11-14")
H = "\N{LATIN SMALL LETTER H WITH DOT BELOW}"
BOOK = {"Gen": "Genesis", "Exod": "Exodus", "Deut": "Deuteronomy"}
SCRIPT_DIR = ".novc/morphhb-strands-pr-versions-2026-11-15/scripts"


def T(s: str) -> str:
    return s.replace("~h", H)


def load(name):
    return json.loads((W / "scratch-g" / name).read_text(encoding="utf-8"))


def verse_name(vid: str) -> str:
    b, c, v = vid.split(".")
    return f"{BOOK[b]} {c}:{v}"


def va(vid, atom) -> str:
    return f"{verse_name(vid)}, {atom}"


def cv_name(label: str, atoms=None, n_atoms=None) -> str:
    """A chanted verse's name; with its atoms, the atom range where it starts or ends mid-verse."""
    b, rest = label.split(" ", 1)
    name = f"{BOOK[b]} {rest}"
    if atoms and n_atoms:
        first, last = atoms[0], atoms[-1]
        if first[1] != 1 or last[1] != n_atoms[last[0]]:
            name += f" (atoms {first[1]}–{last[1]})"
    return name


def lex_cell(cv) -> str:
    parts = []
    for x in cv["verdict"]["lexical"]:
        if x["atoms"]:
            ats = [cv["atoms"][i] for i in x["atoms"]]
            nums = " and ".join(str(n) for _v, n in ats)
            noun = "atoms" if len(ats) > 1 else "atom"
            parts.append(f"`{x['code']}`: {verse_name(ats[0][0])}, {noun} {nums}")
        else:
            parts.append(f"`{x['code']}`")
    return "; ".join(parts) or "none"


def and_join(items) -> str:
    items = list(items)
    if len(items) <= 2:
        return " and ".join(items)
    return ", ".join(items[:-1]) + " and " + items[-1]


def toks(ts) -> str:
    return " ".join(f"`{t}`" for t in ts) if ts else "none"


def error_leaves(node, out=None):
    out = [] if out is None else out
    if node is None:
        return out
    if "children" in node:
        for c in node["children"]:
            error_leaves(c, out)
    elif "ERROR" in node["leaves"]:
        out.append(node["label"])
    return out


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    acc = load("g_accgram.json")
    nc = load("g_ncodes.json")
    bk = load("g_ncheck_books.json")
    src = json.loads((S / "out" / "22-clc-answers.json").read_text(encoding="utf-8"))

    NAME = {}
    for a in src["atoms"]:
        for s in ("alef", "bet"):
            NAME[(a["vid"].split(".")[0], s)] = a[s]["name"]
    PESH, MID = NAME[("Gen", "alef")], NAME[("Gen", "bet")]
    TAH, ELY = NAME[("Exod", "alef")], NAME[("Exod", "bet")]
    assert NAME[("Deut", "alef")] == TAH and NAME[("Deut", "bet")] == ELY

    rows = acc["rows"]
    cvs = acc["chanted_verses"]
    clc_rows = [r for r in rows if r["source"] == "clc" and r["in24"]]
    mam_rows = [r for r in rows if r["source"] == "mam" and r["in24"]]
    row_at = {(r["source"], r["strand"], r["vid"], r["atom"]): r for r in rows}

    # ------------------------------------------------------------ derived facts
    hits = [r for r in clc_rows if r["criteria"]]
    noted = [r for r in clc_rows if r["noted"]]
    noted_nonmeteg = [r for r in noted if any(n != "meteg" for n in r["noted"])]
    noted_meteg_only = [r for r in noted if all(n == "meteg" for n in r["noted"])]
    illegal_not_noted = [r for r in hits if not r["noted"]]
    noted_not_illegal = [r for r in noted if not r["criteria"]]
    crit_count = Counter(c for r in hits for c in r["criteria"])
    mam_hits = [r for r in mam_rows if r["criteria"]]
    clc_cvs = [cv for cv in cvs if cv["source"] == "clc"]
    mam_cvs = [cv for cv in cvs if cv["source"] == "mam"]
    bad_cvs = [cv for cv in clc_cvs if cv["verdict"]["status"] != "clean"]
    token_only = [
        r
        for r in clc_rows
        if r["tokens_differ_from_mam"] and not r["criteria"]
    ]
    assert token_only and all(r["strand"] == "bet" for r in token_only)

    # The new main text's chanted verses (MAM's alef in the Decalogues, bet at Genesis 35:22):
    # do any of the five kinds of exception of the three-book check occur in them?
    L4 = {"GERESH", "GERSHAYIM", "PAZER", "PAZERGADOL", "TELISHAGEDOLA"}
    STRONGER_THAN_L4 = {
        "SILLUQ", "ATNAX", "SEGOLTA", "SHALSHELET", "ZAQEF", "METHIGAZAQEF", "ZAQEFGADOL",
        "TIPEXA", "MAYELA", "REVIA", "ZARQA", "PASHTA", "YETIV", "TEVIR",
    }
    DISJ = STRONGER_THAN_L4 | L4 | {"LEGARMEH"}
    nm_cvs = [
        cv for cv in mam_cvs if cv["strand"] == ("bet" if cv["book"] == "Gen" else "alef")
    ]
    nm_paseq = []
    nm_mayela = nm_two_disj = nm_leg_before_l4 = nm_telg_ger = 0
    for cv in nm_cvs:
        at = cv["verdict"]["accent_tokens"]
        types = [t for t, _l, _a in at]
        for j, f in enumerate(cv["forms"]):
            mine = [t for t, _l, ai in at if ai == j]
            if "\N{HEBREW PUNCTUATION PASEQ}" in f:
                nm_paseq.append(mine)
            if sum(1 for t in mine if t in DISJ) > 1:
                nm_two_disj += 1
        nm_mayela += types.count("MAYELA")
        for i, t in enumerate(types):
            if t == "LEGARMEH":
                for u in types[i + 1 :]:
                    if u in STRONGER_THAN_L4:
                        break
                    if u in L4:
                        nm_leg_before_l4 += 1
                        break
            if t == "TELISHAGEDOLA" and i + 1 < len(types) and types[i + 1] == "GERESH":
                nm_telg_ger += 1
    assert all("LEGARMEH" in m for m in nm_paseq)
    nm_paseq_text = (
        "its one atom with a paseq reads as legarmeh"
        if len(nm_paseq) == 1
        else f"its {len(nm_paseq)} atoms with a paseq all read as legarmeh"
    )

    diff = nc["differential_today"]
    diff_bad = [d for d in diff if not d["agree"]]
    own_checked = [d for d in diff if d["own_agrees_with_n"] is not None]
    own_ok = [d for d in own_checked if d["own_agrees_with_n"]]
    new = nc["new_main_text"]
    new_changed = [x for x in new if x["changed"]]
    changed_vids = list(OrderedDict.fromkeys(x["vid"] for x in new_changed))
    clc_main = nc["clc_main_strand"]
    bstats = bk["stats"]
    PASEQ = "\N{HEBREW PUNCTUATION PASEQ}"
    paseq_verses = [
        d
        for d in bk["disagreements"]
        if any(PASEQ in a["form"] and a["computed"] is None and a["n"] for a in d["atoms"])
    ]
    n_paseq_verses = len(paseq_verses)
    n_paseq_atoms = sum(len(d["atoms"]) for d in paseq_verses)
    other = sorted({d["vid"] for d in bk["disagreements"]} - {d["vid"] for d in paseq_verses})
    assert other == ["Gen.28.9", "Gen.41.30", "Gen.5.29", "Gen.8.18"], other
    assert n_paseq_atoms + sum(len(d["atoms"]) for d in bk["disagreements"] if d["vid"] in other) == (
        bstats["atoms"] - bstats["atoms agreeing"]
    )
    own_bad_status = {
        vid: o
        for vid, o in nc["morphhb_own_main_text"].items()
        if o.get("status") not in (None, "clean") and vid not in ("Exod.20.3", "Deut.5.7")
    }
    own_bad_atoms = {
        vid: [d for d in diff if d["vid"] == vid and d["morphhb_own_tokens"] != d["mam_tokens"]]
        for vid in own_bad_status
    }
    n_atoms = Counter()
    for cv in cvs:
        for vid, n in cv["atoms"]:
            n_atoms[vid] = max(n_atoms[vid], n)

    deut58 = next(
        cv for cv in clc_cvs if cv["strand"] == "alef" and cv["label"] == "Deut 5:8"
    )
    assert deut58["verdict"]["grammar"] == "error"
    assert deut58["fixes"]["grammar"]["sets"] == [[["Deut.5.8", 2]]]
    d582 = row_at[("clc", "alef", "Deut.5.8", 2)]
    m582 = row_at[("mam", "alef", "Deut.5.8", 2)]

    # ------------------------------------------------------------ reasons (Claude's reading)
    def form(src_, strand, vid, atom):
        return row_at[(src_, strand, vid, atom)]["form"]

    reasons = {
        ("Gen.35.22", 7, "bet"): T(
            f"WLC 4.20 has on this atom only the {PESH}'s zaqef, which CLC's rules give to the {PESH}, "
            f"so the {MID}'s form has no accent (CLC notes the revia). The scanner drops the chanted word; "
            f"the muna~h of atom 6 then stands before the pashta of atom 8, and no pashta phrase of the "
            f"grammar begins muna~h pashta: the tree has a `pashta_phrase` ERROR. The lexical layer reports "
            f"the chanted word with no accent."
        ),
        ("Exod.20.3", 2, "alef"): T(
            f"WLC 4.20 has here the {ELY}'s meteg and maqaf and not the {TAH}'s merkha, so in CLC's {TAH} "
            f"the chanted word of atoms 1 and 2 has no accent (CLC supplies atom 1's maqaf and notes the "
            f"merkha). The scanner drops the chanted word and the grammar parses the rest (the tevir of "
            f"atom 3 needs no servant), so the grammar alone finds the chanted verse clean; the lexical "
            f"layer reports the chanted word with no accent."
        ),
        ("Exod.20.4", 13, "alef"): T(
            f"WLC 4.20 has a merkha and a muna~h on the shin; MAM's two strands agree on the merkha alone, "
            f"and CLC's rules keep both accents in both strands. The lexical layer reports two accents on "
            f"one letter (`merkha!munax`); in the {TAH} the grammar reads merkha muna~h tipe~ha, which no "
            f"tipe~ha phrase allows: `tipexa_phrase` ERROR."
        ),
        ("Exod.20.4", 13, "bet"): T(
            f"The same atom: in the {ELY} the grammar reads merkha muna~h legarmeh, which no legarmeh "
            f"phrase allows: `legarmeh_phrase` ERROR; the lexical layer reports `merkha!munax`."
        ),
        ("Deut.5.8", 2, "alef"): T(
            f"WLC 4.20 has a merkha where MAM's {TAH} has a qadma; CLC's rules give that merkha to the "
            f"{TAH} (MAM's {ELY} has a meteg there, which CLC notes). The chanted verse then opens merkha "
            f"merkha pashta, and no pashta phrase has two merkha servants: `pashta_phrase` ERROR. With "
            f"MAM's qadma it opens qadma merkha pashta and is clean."
        ),
        ("Deut.5.14", 4, "alef"): T(
            f"WLC 4.20 has a muna~h and a tipe~ha on the vav; MAM's two strands agree on the muna~h alone, "
            f"and CLC's rules keep both accents in both strands. The lexical layer reports `munax!tipexa`; "
            f"in the {TAH} the grammar reads tipe~ha, then muna~h tipe~ha, then atna~h, two tipe~ha "
            f"phrases before the atna~h: `atnax_phrase` ERROR."
        ),
        ("Deut.5.14", 4, "bet"): T(
            f"The same atom: in the {ELY} the tipe~ha stands between atom 3's muna~h and paseq and the "
            f"revia of atom 5, so accgram, whose legarmeh rule looks ahead to the revia, reads atom 3 as "
            f"muna~h with a narrow-sense paseq rather than legarmeh; the tree has a `tipexa_phrase` ERROR "
            f"and an `atnax_phrase` ERROR. The lexical layer reports `munax!tipexa`."
        ),
        ("Deut.5.17", 2, "alef"): T(
            f"WLC 4.20 has here the {ELY}'s silluq (meteg and sof pasuq) and not the {TAH}'s tipe~ha, so "
            f"CLC's {TAH} form has no accent (CLC notes the tipe~ha). The scanner drops it; merkha, muna~h, "
            f"atna~h remains, and no atna~h phrase has a merkha before its muna~h: `atnax_phrase` ERROR. "
            f"The lexical layer reports the chanted word with no accent."
        ),
        ("Deut.5.6", 1, "bet"): T(
            f"WLC 4.20 has on atoms 1 and 3 the {TAH}'s pashta and zaqef and not the {ELY}'s tipe~ha and "
            f"atna~h, so CLC's {ELY} forms have no accent there (CLC notes both). The scanner drops both "
            f"chanted words, and the rest, muna~h darga tevir merkha tipe~ha merkha silluq, is a "
            f"grammatical verse without atna~h, so the grammar alone finds it clean; the lexical layer "
            f"reports both chanted words. Each atom's MAM form alone leaves the other chanted word "
            f"unaccented, so the smallest set is both."
        ),
    }
    reasons[("Deut.5.6", 3, "bet")] = reasons[("Deut.5.6", 1, "bet")]
    iii_reasons = {
        ("Exod.20.3", 7, "bet"): T(
            f"WLC 4.20 has the pata~h under the yod, where UXLC 2.6 and MAM's {ELY} have it under the nun; "
            f"CLC's rules give WLC 4.20's pata~h, under the yod, to the {ELY}, so the nun has no vowel. "
            f"Not noted: the strand lacks no mark, the pata~h being there on another letter."
        ),
        ("Deut.5.8", 12, "bet"): T(
            f"WLC 4.20 has under the tav the qamats alone, the {TAH}'s; CLC's {ELY} has no vowel under the "
            f"tav, and CLC notes the pata~h."
        ),
    }
    iii_reasons[("Deut.5.7", 7, "bet")] = iii_reasons[("Exod.20.3", 7, "bet")]

    # ------------------------------------------------------------ JSON
    out_json = {
        "about": T(
            "Claude's work (Opus 5.5, sub-agent G, 2026-11-15, New York time), not reviewed by a human. "
            "accgram's verdicts on MAM's strands and on CLC's division of WLC 4.20 in the 24 "
            "dual-cantillation verses, criteria (i)-(iv) for every CLC strand-atom, and morphhb's n codes. "
            "Strand alef = MAM-simple's cant-alef, bet = cant-bet."
        ),
        "strand_names": {f"{b} {s}": n for (b, s), n in NAME.items()},
        "scripts": [
            f"{SCRIPT_DIR}/g_common.py",
            f"{SCRIPT_DIR}/g_accgram.py",
            f"{SCRIPT_DIR}/g_ncodes.py",
            f"{SCRIPT_DIR}/g_ncheck_books.py",
            f"{SCRIPT_DIR}/g_report.py",
        ],
        "checks": acc["checks"],
        "chanted_verses": [
            {
                "source": cv["source"],
                "strand": cv["strand"],
                "strand_name": cv["strand_name"],
                "label": cv["label"],
                "atoms": cv["atoms"],
                "forms": cv["forms"],
                "tokens": cv["verdict"]["tokens"],
                "status": cv["verdict"]["status"],
                "grammar": cv["verdict"]["grammar"],
                "lexical": cv["verdict"]["lexical"],
                "error_leaves": error_leaves(cv["verdict"]["tree"]),
                "minimal_fixes": cv.get("fixes", {}),
                "tree": cv["verdict"]["tree"],
            }
            for cv in cvs
        ],
        "strand_atoms": [
            {
                k: r[k]
                for k in (
                    "vid",
                    "atom",
                    "strand",
                    "strand_name",
                    "source",
                    "form",
                    "clc_rule_form",
                    "mam_form",
                    "tokens",
                    "mam_tokens",
                    "tokens_differ_from_mam",
                    "criteria",
                    "detail",
                    "noted",
                    "supplied",
                    "mam_paseq_kind",
                )
            }
            for r in rows
            if r["in24"]
        ],
        "noted_vs_illegal": {
            "illegal (any criterion)": [[r["vid"], r["atom"], r["strand"], r["criteria"]] for r in hits],
            "illegal, not noted": [[r["vid"], r["atom"], r["strand"]] for r in illegal_not_noted],
            "noted, not illegal": [[r["vid"], r["atom"], r["strand"], r["noted"]] for r in noted_not_illegal],
            "criterion counts": dict(crit_count),
            "MAM forms failing a criterion (control)": [[r["vid"], r["atom"], r["strand"]] for r in mam_hits],
        },
        "n": {
            "mam_tree_vs_level": nc["mam_tree_vs_level"],
            "differential_today": diff,
            "morphhb_own_main_text": nc["morphhb_own_main_text"],
            "new_main_text": new,
            "clc_main_strand": clc_main,
            "broad_check": bk,
        },
    }
    (W / "out" / "53-accgram.json").write_text(
        json.dumps(out_json, ensure_ascii=False, indent=1), encoding="utf-8", newline="\n"
    )

    # ------------------------------------------------------------ Markdown
    L = []
    add = L.append
    add(
        "Claude's work (Opus 5.5, sub-agent G, 2026-11-15, New York time), not reviewed by a human; "
        "nothing was posted, pushed or committed."
    )
    add("")
    add("# accgram on the two strands of the 24 verses, and morphhb's n codes")
    add("")
    add(
        T(
            f"Every Hebrew form and strand name below is copied by `{SCRIPT_DIR}/g_report.py` from the data "
            f"files; each finding names the script that produced it. Readings are attributed to WLC 4.20, "
            f"CLC (here: CLC's division rules applied to WLC 4.20, folder S's `clc_rule_form`, brackets "
            f"removed and supplied marks kept), MAM (MAM-simple's `cant-alef` and `cant-bet`) or morphhb "
            f"(Ben's fork at `696e21ce`); nothing here is a claim about the Leningrad Codex. Strand alef is "
            f"the {TAH} (at Genesis 35:22 the {PESH}), strand bet the {ELY} (there the {MID}). An atom is a "
            f"written form between spaces or maqaf marks; a chanted word is an atom or a maqaf compound; a "
            f"chanted verse ends at a sof pasuq."
        )
    )
    add("")

    # ---- answers in brief
    n_bad = len(bad_cvs)
    add("## Answers in brief")
    add("")
    add(
        T(
            f"1. **MAM's strands are grammatical: no finding.** All {len(mam_cvs)} of MAM's chanted verses "
            f"that hold any of the 24 verses are clean by accgram's prose checker (lexical layer, then "
            f"grammar), and no criterion fires on any MAM form (`g_accgram.py`)."
        )
    )
    add(
        T(
            f"2. **CLC's strands on WLC 4.20: {n_bad} of {len(clc_cvs)} chanted verses are not clean, each "
            f"because of one atom (two at Deuteronomy 5:6).** Substituting MAM's form at that atom alone "
            f"makes each clean (`g_accgram.py`, smallest-set search). The atoms: Genesis 35:22, 7 ({MID}); "
            f"Exodus 20:3, 2 ({TAH}); Exodus 20:4, 13 (both strands); Deuteronomy 5:6, 1 and 3 ({ELY}); "
            f"Deuteronomy 5:8, 2 ({TAH}); Deuteronomy 5:14, 4 (both strands); Deuteronomy 5:17, 2 ({TAH})."
        )
    )
    add(
        T(
            f"3. **Criteria: {len(hits)} CLC strand-atoms at {len({(r['vid'], r['atom']) for r in hits})} "
            f"atoms are illegal by at least one criterion** ((i) {crit_count['i']}, (ii) {crit_count['ii']}, "
            f"(iii) {crit_count['iii']}, (iv) {crit_count['iv']}; section 4)."
        )
    )
    add(
        T(
            f"4. **Not every illegal version is one that CLC notes: {len(illegal_not_noted)} are not.** They "
            f"come from WLC 4.20's own readings, where CLC's rules leave the strand lacking no mark and so "
            f"note nothing: the pata~h under "
            f"the yod at Exodus 20:3, 7 and Deuteronomy 5:7, 7 ({ELY}; (iii)); the second accent at Exodus "
            f"20:4, 13 and Deuteronomy 5:14, 4 (both strands; (ii), (iv)); the merkha at Deuteronomy 5:8, 2 "
            f"({TAH}; (iv)). **Every CLC note that is not a meteg is an illegality** "
            f"({len(noted_nonmeteg)} of {len(noted_nonmeteg)}); the {len(noted_meteg_only)} meteg notes "
            f"(Deuteronomy 5:7, 2 and 5:8, 2, {ELY}) are not, by Ben's rule that meteg is always optional."
        )
    )
    add(
        T(
            f"5. **Yes: WLC 4.20's merkha at Deuteronomy 5:8, 2 makes the {TAH}'s chanted verse Deuteronomy "
            f"5:8 ungrammatical.** CLC's form {d582['form']} (MAM's {m582['form']}) opens the verse merkha "
            f"merkha pashta, and accgram's tree has a `pashta_phrase` ERROR; MAM's qadma alone makes it "
            f"clean (`g_accgram.py`). MAM-basics' own detangling of WLC 4.22 never parsed this: it supplies "
            f"MAM's qadma in the {TAH} and gives the merkha to the {ELY} as a stray."
        )
    )
    add(
        T(
            f"6. **n codes: the script reproduces morphhb's hand-made n.** Over the other "
            f"{bstats['coded']} verses of Genesis, Exodus and Deuteronomy that accgram finds clean, it "
            f"agrees at {bstats['atoms agreeing']} of {bstats['atoms']} atoms "
            f"(`g_ncheck_books.py`; the {bstats['atoms'] - bstats['atoms agreeing']} others are five "
            f"kinds of case, none of which occurs in the new main text). In the 24 verses and the three "
            f"beyond them that a chanted verse runs into, today's main-text strand taken from MAM agrees "
            f"with the base files at "
            f"{len(diff) - len(diff_bad)} of {len(diff)} atoms; the {len(diff_bad)} others (Genesis 35:22, "
            f"1, 3, 5, 7; Deuteronomy 5:6, 1, 3) are where morphhb's main text has WLC 4.20's marks rather "
            f"than MAM's strand, and coding morphhb's own main text reproduces its n there "
            f"(`g_ncodes.py`)."
        )
    )
    add(
        T(
            f"7. **The new main text changes n at {len(new_changed)} atoms in {len(changed_vids)} verses**: "
            f"Genesis 35:22 (the revia of atom 7) and the eight verses whose main strand changes from the "
            f"{ELY} to the {TAH}. Exodus 20:16 and Deuteronomy 5:20, into which the {TAH} runs on, keep "
            f"their codes (`g_ncodes.py`; section 5.3)."
        )
    )
    add(
        T(
            f"8. **In CLC's main strand, an atom with no accent gets no code and one with two accents gets "
            f"its disjunctive's**: no code at Genesis 35:22, 7 (MAM's {MID}: 1.1.2) and Deuteronomy 5:17, 2 "
            f"(MAM's {TAH}: 1.0); none either way at Exodus 20:3, 2 and Exodus 20:4, 13; 1.0 at "
            f"Deuteronomy 5:14, 4 (MAM's {TAH}: none), which raises the codes of atoms 1 to 3 by one "
            f"(section 5.4)."
        )
    )
    add("")

    # ---- 1. accgram
    add("## 1. How accgram parses a prose chanted verse, and what was reused")
    add("")
    add(
        T(
            "**Reused unchanged; one entry point, `g_common.verdict`, calls them in `prose_run`'s order.** "
            "`uni_to_marks.word_to_marks` and `verse_to_marks` turn the atoms into the mark body (each "
            "letter a placeholder, points dropped, accents kept, maqaf `-`, a space between chanted words, "
            "a paseq after a space folded onto its atom). `lexical_validation.lexical_ungrammatical` is the "
            "prose lexical layer `prose_run._verse_record` applies first: a chanted word with no accent "
            "(`unaccented_chanted_words`), two accents on one letter, an unpaired stress helper, a stray "
            "accent; any finding makes the verse `illegal_mark`. `prose_scanner.scan_accents` gives the "
            "tokens (a stress helper fused with its accent, muna~h and paseq before a revia read as "
            "`LEGARMEH`, a medial meteg swallowed, a meteg before sof pasuq read as `SILLUQ`; each token's "
            "`start` locates its atom). `prose_ply_grammar.build_parser` and `parse_tokens` (the PLY port "
            "of goerwitz's acc2tre.y) return the division tree, whose error productions put ERROR leaves "
            "in an ungrammatical verse; `dual_cant_detangle._tree_has_error` gives clean or error; "
            "`tree.tree_to_obj` gives the binary tree (internal `X_clause` nodes, `X_phrase` leaves listing "
            "accent names). `grammaticality.py` is a PCFG score over committed trees, a research measure "
            "rather than a verdict, and was not used."
        )
    )
    add("")
    add(
        T(
            f"**The existing dual-cantillation run parses neither set of forms as they are.** "
            f"`dual_cant_run` (`out/accgram/dual-cant/_dual_cant.json`) divides WLC 4.22 with MAM's strands "
            f"as oracle: its 47 chanted verses are clean but one, the {ELY}'s Deuteronomy 5:7–10, an error "
            f"because it routes WLC 4.22's merkha at Deuteronomy 5:8, 2 to the {ELY} as a stray; it supplies "
            f"MAM's qadma in the {TAH} (`g_dualcant_summary.py`). `printed_decalogue.parse_marks_body` "
            f"parses the Wikisource strands but raises on a chanted word with no accent, which CLC's forms "
            f"have. So `g_common.verdict` feeds MAM's forms and CLC's forms as they are; the scanner "
            f"handles MAM's stress helpers and metegs itself."
        )
    )
    add("")

    # ---- 2. chanted verses
    add("## 2. The chanted verses and their verdicts (task 2)")
    add("")
    add(
        T(
            f"**Disposition: reported; MAM's strands are the clean control.** `g_accgram.py` assembles each "
            f"strand's chanted verses from the atoms, across BHS verses, ending one at each atom whose strand "
            f"form ends in sof pasuq. Three verses outside the 24 are needed where a strand runs on: Exodus "
            f"20:11 (the {ELY}'s 20:8–11), Exodus 20:16 and Deuteronomy 5:20 (the {TAH}'s 20:13–16 and "
            f"5:17–20). MAM's strands agree in those verses, so for MAM both strands take MAM-simple's form "
            f"and for CLC both take WLC 4.20's (CLC's rules would give each strand all of WLC 4.20's "
            f"marks), whose tokens equal MAM's at every atom (check in section 6). \"Status\" is "
            f"`prose_run`'s verdict; \"grammar\" is the scanner and grammar alone, in which a chanted word "
            f"with no accent drops out."
        )
    )
    add("")
    add("| Chanted verse | Strand | MAM: status | CLC: status | CLC: grammar alone | CLC: lexical findings |")
    add("|---|---|---|---|---|---|")
    order = sorted(clc_cvs, key=lambda cv: (["Gen", "Exod", "Deut"].index(cv["book"]), cv["strand"], cvs.index(cv)))
    mam_by = {(cv["strand"], tuple(map(tuple, cv["atoms"]))): cv for cv in mam_cvs}
    for cv in order:
        m = mam_by[(cv["strand"], tuple(map(tuple, cv["atoms"])))]
        add(
            f"| {cv_name(cv['label'], cv['atoms'], n_atoms)} | {cv['strand_name']} | "
            f"{m['verdict']['status']} | {cv['verdict']['status']} | {cv['verdict']['grammar']} | "
            f"{lex_cell(cv)} |"
        )
    add("")
    add(
        T(
            f"Of MAM's {len(mam_cvs)} chanted verses all are clean; of CLC's {len(clc_cvs)}, {len(clc_cvs) - n_bad} "
            f"are clean, {sum(1 for cv in bad_cvs if cv['verdict']['grammar'] == 'error')} have an ERROR in "
            f"the grammar, and {sum(1 for cv in bad_cvs if cv['verdict']['grammar'] == 'clean')} are clean "
            f"by the grammar alone but have a chanted word with no accent."
        )
    )
    add("")

    # ---- 3. responsible atoms
    add("## 3. The atoms responsible (task 3)")
    add("")
    add(
        T(
            "**Disposition: each failure traced to its atoms.** For each CLC chanted verse that is not clean, "
            "`g_accgram.py` substitutes MAM's form for CLC's at the atoms whose scanner marks differ, one "
            "set at a time in increasing size, and reports every smallest set that makes the verse clean "
            "(for the status, and separately for the grammar alone). Every smallest set has one atom except "
            "at Deuteronomy 5:6. The reason is Claude's reading of the tokens and the tree."
        )
    )
    add("")
    add("| Chanted verse, strand | Smallest set | CLC form | MAM form | Tree's ERROR | Why |")
    add("|---|---|---|---|---|---|")
    for cv in sorted(bad_cvs, key=lambda cv: (["Gen", "Exod", "Deut"].index(cv["book"]), cvs.index(cv))):
        fx = cv["fixes"]["status"]
        assert len(fx["sets"]) == 1
        st = fx["sets"][0]
        err = ", ".join(f"`{e}`" for e in error_leaves(cv["verdict"]["tree"])) or "none (grammar clean)"
        cforms = " ".join(form("clc", cv["strand"], vid, n) for vid, n in st)
        mforms = " ".join(form("mam", cv["strand"], vid, n) for vid, n in st)
        where = "; ".join(va(vid, n) for vid, n in st)
        key = (st[0][0], st[0][1], cv["strand"])
        add(
            f"| {cv_name(cv['label'], cv['atoms'], n_atoms)}, {cv['strand_name']} | {where} | {cforms} | "
            f"{mforms} | {err} | {reasons[key]} |"
        )
    add("")

    # ---- 4. criteria
    add("## 4. The criteria, tested on every CLC version of every atom (task 4)")
    add("")
    add(
        T(
            "**Disposition: reported; no criterion fires on MAM's forms (the control).** `g_accgram.py` "
            "tests all 484 CLC strand-atoms of the 24 verses: (i) an atom that ends a chanted word (no maqaf "
            "after it) with no accent, a meteg before sof pasuq counting as silluq; (ii) two accent tokens "
            "on one atom where MAM's strand has one (tokens fuse a stress helper with its accent, so a "
            "pashta's helper is not a second accent); (iii) a letter, other than a vowel letter (a ~holam "
            "male) or the word-final letter, with no vowel or sheva where MAM's strand has one, the "
            "Tetragrammaton's ~holam, which MAM writes and WLC 4.20 does not, exempted; (iv) the atom is in "
            "a smallest set of section 3. \"Noted\" is folder S's `noted`: marks that CLC's rules on WLC "
            "4.20 note as expected but WLC 4.20 lacks."
        )
    )
    add("")
    add("| Verse, atom | Strand | CLC form | MAM form | Criteria failed | CLC notes |")
    add("|---|---|---|---|---|---|")
    shown = [r for r in clc_rows if r["criteria"] or r["noted"]]
    for r in shown:
        add(
            f"| {va(r['vid'], r['atom'])} | {r['strand_name']} | {r['form']} | {r['mam_form']} | "
            f"{', '.join('(' + c + ')' for c in r['criteria']) or 'none'} | "
            f"{T(', '.join(r['noted'])) or 'no'} |"
        )
    add("")
    add(T("(iii)'s letters, and why CLC does not note two of them:"))
    add("")
    for r in clc_rows:
        if "iii" in r["criteria"]:
            letters_ = ", ".join(str(x["letter"]) for x in r["detail"]["iii"])
            add(
                T(
                    f"- {va(r['vid'], r['atom'])}, {r['strand_name']}: letter {letters_}. "
                    f"{iii_reasons[(r['vid'], r['atom'], r['strand'])]}"
                )
            )
    ex = Counter(
        e["why"].replace("holam", "~holam") for r in clc_rows for e in r["detail"].get("iii_exempt", [])
    )
    add(
        T(
            f"- Exempted by (iii)'s rule: {', '.join(f'{n} for {why}' for why, n in ex.items()) or 'none'}."
        )
    )
    add("")
    add(
        T(
            f"**Answers.** Not every illegal version is noted: {len(illegal_not_noted)} of {len(hits)} are not "
            f"({'; '.join(va(r['vid'], r['atom']) + ', ' + r['strand_name'] for r in illegal_not_noted)}). "
            f"Every non-meteg note is an illegality: {', '.join(va(r['vid'], r['atom']) + ' ' + r['strand_name'] + ' (' + T(', '.join(r['noted'])) + ')' for r in noted_nonmeteg)}. "
            f"The meteg notes at {and_join(va(r['vid'], r['atom']) + ' ' + r['strand_name'] for r in noted_meteg_only)} "
            f"fail no criterion. Atom 1 of Exodus 20:3 and 20:4 and of Deuteronomy 5:7, where CLC supplies "
            f"the {TAH}'s maqaf, fails none either, nor does any atom where CLC supplies a sof pasuq."
        )
    )
    add("")
    add(
        T(
            f"**Not caught by (i)–(iv): accgram reads a different accent at {len(token_only)} more "
            f"strand-atoms, all {ELY}.** At Exodus 20:10, 1 and Deuteronomy 5:14, 1 CLC's form "
            f"{form('clc', 'bet', 'Exod.20.10', 1)} has WLC 4.20's pashta code point where MAM's "
            f"{form('mam', 'bet', 'Exod.20.10', 1)} has a qadma; the scanner reads `PASHTA`, a disjunctive, "
            f"and the {ELY}'s Exodus 20:8–11 still parses clean: the grammar allows a pashta before a revia "
            f"within a zaqef's part, so the pashta gets a part of its own, coded 1.2.3, inside the zaqef "
            f"part that ends at Exodus 20:10, 18, and every other code stays as MAM's (`g_peek_elyon.py`); "
            f"MAM's qadma gets none. At Deuteronomy 5:14, 3 "
            f"the scanner reads {form('clc', 'bet', 'Deut.5.14', 3)} as muna~h with a narrow-sense paseq, "
            f"not legarmeh, because of atom 4's extra tipe~ha (section 3); MAM's form there reads as legarmeh."
        )
    )
    add("")

    # ---- 5. n codes
    add("## 5. morphhb's n codes (task 5)")
    add("")
    add("### 5.1 The coding, and its check against morphhb's hand-made codes")
    add("")
    add(
        T(
            "**Method (`g_common.tree_codes`).** n goes on each atom that holds a disjunctive head: the last "
            "token of a phrase leaf of accgram's tree. A clause node `X_clause` is flattened along its right "
            "spine (more `X_clause` nodes, ending in its `X_phrase` leaf): the left children are its "
            "sub-parts, numbered from k−1 down to 0, and the `X_phrase`'s head atom carries the clause's own "
            "code. At the top, an atna~h clause that opens the silluq clause is the part 1 and the rest of "
            "the silluq clause the part 0; without an atna~h the whole verse is 0. Codes are relative to the "
            "whole chanted verse, so a BHS verse holding part of one takes that part's codes. Where accgram's "
            "tree has an ERROR, `g_common.level_codes` is used instead: an independent continuous dichotomy "
            "from the four classes of prose disjunctives (1 silluq, atna~h; 2 segolta, shalshelet, zaqef, "
            "zaqef gadol, tipe~ha; 3 revia, zarqa, pashta, yetiv, tevir; 4 geresh, gershayim, pazer, pazer "
            "gadol, telisha gedolah, legarmeh), each disjunctive belonging to the part of the nearest "
            "following stronger one. The two codings agree on all "
            f"{sum(1 for x in nc['mam_tree_vs_level'] if x['agree'])} of MAM's chanted verses here."
        )
    )
    add("")
    dis = bk["disagreements"]
    add(
        T(
            f"**Disposition: validated against morphhb's own codes (`g_ncheck_books.py`).** Of the "
            f"{bstats['verses']} verses of Genesis, Exodus and Deuteronomy in the base files, "
            f"{bstats['skipped: dual cantillation']} are the dual-cantillation verses, "
            f"{bstats.get('skipped: not one sof pasuq at the end', 0)} lack a single final sof pasuq in "
            f"morphhb's main text, and {bstats['not clean by accgram']} are not clean by accgram; on the "
            f"other {bstats['coded']}, the tree coding equals morphhb's n at {bstats['atoms agreeing']} of "
            f"{bstats['atoms']} atoms, in {bstats['verses agreeing']} verses wholly. The "
            f"{bstats['atoms'] - bstats['atoms agreeing']} disagreeing atoms, in "
            f"{bstats['verses with a disagreement']} verses, are five kinds of case where morphhb's coding "
            f"and accgram's reading part: (a) {n_paseq_atoms} atoms in {n_paseq_verses} verses, a muna~h "
            f"with a paseq that is not before a revia, which accgram reads as muna~h and a narrow-sense "
            f"paseq and morphhb codes as legarmeh (at Deuteronomy 25:19 this also moves the preceding "
            f"pazer's code); (b) Genesis 28:9, where accgram's tree puts a legarmeh inside the following "
            f"geresh's part and morphhb, like the level coding, makes them siblings (the one verse where the "
            f"two codings differ); (c) Genesis 8:18's mayela, which morphhb leaves without n; (d) Genesis "
            f"5:29, an atom with two disjunctives, to which morphhb gives the second's code; (e) Genesis "
            f"41:30, whose geresh morphhb leaves without n. None of these occurs in the new main text "
            f"(section 6, check 4)."
        )
    )
    add("")
    add("| Verse | Atom | Computed | morphhb's n |")
    add("|---|---|---|---|")
    for d in dis:
        for a in d["atoms"]:
            add(f"| {verse_name(d['vid'])} | {a['form']} | {a['computed'] or 'none'} | {a['n'] or 'none'} |")
    add("")

    add("### 5.2 (a) Today's main text, from MAM's strand, against the base files")
    add("")
    add(
        T(
            f"**Disposition: {len(diff) - len(diff_bad)} of {len(diff)} atoms agree; each of the "
            f"{len(diff_bad)} others is explained (`g_ncodes.py`).** Today's main-text strand is the {ELY} "
            f"in Exodus 20:2 and 20:13–15 and Deuteronomy 5:6 and 5:17–19, the {TAH} in the other Decalogue "
            f"verses and the {MID} at Genesis 35:22 (folder D's README); Exodus 20:11, 20:16 and Deuteronomy "
            f"5:20 are coded as verses of their own. Exodus 20:3's codes are those of the second half of the "
            f"{TAH}'s 20:2–3, and Deuteronomy 5:7's of the second half of its 5:6–7; both agree. To explain "
            f"the disagreements, morphhb's own main text of each verse whose main-text chanted verse lies "
            f"within it was coded too: those codes equal the base files' n at {len(own_ok)} of "
            f"{len(own_checked)} atoms."
        )
    )
    add("")
    add("| Verse, atom | `<w>` | Strand | MAM's form | Computed | morphhb's main text | Its code | n in the base files |")
    add("|---|---|---|---|---|---|---|---|")
    for d in diff_bad:
        add(
            f"| {va(d['vid'], d['atom'])} | `{d['w_id']}` | {d['strand_name']} | {d['mam_form']} | "
            f"{d['computed']} | {d['morphhb_main_text_form']} | {d['morphhb_own_code']} | {d['n_base']} |"
        )
    add("")
    add(
        T(
            f"At Genesis 35:22 morphhb's main text has on atom 7 WLC 4.20's zaqef, the {PESH}'s, where MAM's "
            f"{MID} has a revia. So morphhb's atna~h part has four parts (three zaqef parts and a tipe~ha) "
            f"where MAM's has three; atoms 1, 3 and 5 are coded one higher, and atom 7 is a zaqef part of "
            f"its own (1.2) where MAM's revia is a part (1.1.2) of the zaqef part that ends at atom 12. At "
            f"Deuteronomy 5:6 morphhb's main text has on atoms 1 and 3 WLC 4.20's pashta and zaqef, the "
            f"{TAH}'s, where MAM's {ELY} has tipe~ha and atna~h, so the verse has no atna~h and its codes "
            f"begin 0, as folder S's report noted."
        )
    )
    if own_bad_status:
        add("")
        cells = []
        for vid, ds in own_bad_atoms.items():
            items = [
                f"atom {d['atom']}, {d['morphhb_main_text_form']}, has {toks(d['morphhb_own_tokens'])} "
                f"where MAM's strand has "
                + (toks(d["mam_tokens"]) if d["mam_tokens"] else "no accent token")
                for d in ds
            ]
            cells.append(f"{verse_name(vid)}: " + "; ".join(items))
        add(
            T(
                f"**By the way: accgram finds morphhb's main text today not clean in "
                f"{len(own_bad_status)} of the verses whose main-text chanted verse lies within the verse**, "
                f"because of atoms with both strands' accents or the other strand's, and at Deuteronomy "
                f"5:8, 2 WLC 4.20's merkha "
                f"(`g_ncodes.py`; Exodus 20:3 and Deuteronomy 5:7, which continue a chanted verse, cannot be "
                f"judged alone). The atoms whose tokens differ from MAM's main strand:"
            )
        )
        add("")
        for c in cells:
            add(f"- {c}.")
        add("")
        add(T("Their n still follows the level coding of their main text."))
    add("")

    add(T(f"### 5.3 (b) The new main text: MAM's {TAH} in the 23 Decalogue verses, MAM's {MID} at Genesis 35:22"))
    add("")
    add(
        T(
            f"**Disposition: n changes at {len(new_changed)} of {len(new)} atoms, in "
            f"{', '.join(verse_name(v) for v in changed_vids)} (`g_ncodes.py`).** Every atom is listed, "
            f"with the accent tokens accgram reads on MAM's form; \"strand changes\" flags the eight verses "
            f"whose main strand changes from the {ELY} to the {TAH}. In those verses, which hold parts of "
            f"the {TAH}'s 20:2–3, 20:13–16, 5:6–7 and 5:17–20, the last atom no longer carries 0: Exodus "
            f"20:2 and Deuteronomy 5:6 end at the atna~h, coded 1, and Exodus 20:13–15 and Deuteronomy "
            f"5:17–19 end at a tipe~ha, an atna~h and a zaqef (1.0, 1 and 0.1). Exodus 20:16 and "
            f"Deuteronomy 5:20 keep 0.0 and 0, and the codes of Exodus 20:3 and Deuteronomy 5:7, already "
            f"the {TAH}'s, are unchanged."
        )
    )
    add("")
    add("| Verse, atom | `<w>` | Strand changes | Form | Accent tokens | New n | n in the base files | Changed |")
    add("|---|---|---|---|---|---|---|---|")
    for x in new:
        add(
            f"| {va(x['vid'], x['atom'])} | `{x['w_id']}` | {'yes' if x['main_strand_changes'] else ''} | "
            f"{x['form']} | {toks(x['tokens'])} | {x['n_new'] or 'none'} | {x['n_base'] or 'none'} | "
            f"{'**yes**' if x['changed'] else ''} |"
        )
    add("")

    add(T(f"### 5.4 (c) CLC's main strand ({TAH}; at Genesis 35:22 {MID}) where it has no accent or two"))
    add("")
    add(
        T(
            "**Disposition: reported (`g_ncodes.py`).** The code comes from accgram's tree where CLC's "
            "chanted verse is grammatical, otherwise from the level coding (its tree has an ERROR). The "
            "last rows are the knock-on changes at the other atoms of the same chanted verse."
        )
    )
    add("")
    add("| Verse, atom | CLC form | Accent tokens | Grammar | Code given | MAM's code |")
    add("|---|---|---|---|---|---|")
    irregular = {(r["vid"], r["atom"]) for r in clc_rows if r["strand"] == ("bet" if r["vid"].startswith("Gen") else "alef") and ({"i", "ii"} & set(r["criteria"]))}
    picked = []
    for x in clc_main:
        code = x["tree_code"] if x["grammar"] == "clean" else x["level_code"]
        if (x["vid"], x["atom"]) in irregular or code != x["mam_code"]:
            picked.append((x, code))
    for x, code in sorted(picked, key=lambda p: ((p[0]["vid"], p[0]["atom"]) not in irregular,)):
        add(
            f"| {va(x['vid'], x['atom'])} | {x['form']} | {toks(x['tokens'])} | {x['grammar']} | "
            f"{code or 'none'} | {x['mam_code'] or 'none'} |"
        )
    add("")

    # ---- 6. checks and limits
    ck = acc["checks"]
    add("## 6. Checks and limits")
    add("")
    k_forms = "verse-strands whose JSON MAM forms differ from MAM-simple's"
    k_cont = "continuation-verse atoms where WLC 4.20's tokens differ from MAM's"
    add(
        T(
            f"1. **The JSON's MAM forms are MAM-simple's strands**: they differ in "
            f"{ck[k_forms]} of 48 "
            f"verse-strands (`g_accgram.py`, read through `accgram.mam_simple_verse`)."
        )
    )
    add(
        T(
            f"2. **accgram's legarmeh agrees with MAM's own paseq and legarmeh tags** at all "
            f"{len(ck['MAM paseq tags vs accgram (vid, atom, strand, MAM, accgram)'])} atoms of MAM's strands "
            f"with a paseq ({ck['MAM paseq tags accgram reads differently']} differ)."
        )
    )
    add(
        T(
            f"3. **WLC 4.20's tokens equal MAM's** at every atom of Exodus 20:11 and 20:16 and Deuteronomy "
            f"5:20 used here ({len(ck[k_cont])} differ)."
        )
    )
    add(
        T(
            f"4. **None of the five kinds of exception of section 5.1 occurs in the new main text** "
            f"(`g_report.py`, from `g_accgram.json`): {nm_paseq_text}, it has {nm_mayela} mayela, "
            f"{nm_two_disj} atoms with two "
            f"disjunctives, {nm_leg_before_l4} legarmeh followed by a geresh, gershayim, pazer or telisha "
            f"gedolah before the next stronger disjunctive, and {nm_telg_ger} telisha gedolah followed at "
            f"once by a geresh."
        )
    )
    add(
        T(
            "5. **Limits.** accgram's grammar is goerwitz's model of the prose system, and its verdicts are "
            "claims about these encodings under that model. It reads legarmeh only before a revia (and in "
            "17 listed passages). The smallest-set search says which atoms suffice, not which reading is "
            "right; it substitutes only MAM's form. The criteria are the brief's, applied mechanically. "
            "morphhb's n was compared only in the three fetched books."
        )
    )
    add("")
    add("## 7. Files")
    add("")
    add(
        T(
            f"Run from the MAM-basics root with `./.venv/Scripts/python.exe`: `-B {SCRIPT_DIR}/g_accgram.py` "
            f"(tasks 2–4; writes `scratch-g/g_accgram.json`), `-B {SCRIPT_DIR}/g_ncodes.py` (task 5; "
            f"`scratch-g/g_ncodes.json`), `-B {SCRIPT_DIR}/g_ncheck_books.py` (the three-book check; "
            f"`scratch-g/g_ncheck_books.json`), then `-I {SCRIPT_DIR}/g_report.py` (this file and "
            f"`out/53-accgram.json`). `g_common.py` holds the shared code; `g_dualcant_summary.py`, "
            f"`g_show_cv.py`, `g_peek_elyon.py`, `g_probe.py`, `g_peek_codepoints.py`, `g_show_xml.py`, "
            f"`g_dump_atoms.py` and `g_peek.py` are read-only inspection aids. `out/53-accgram.json` holds "
            f"every chanted verse (forms, tokens, "
            f"verdicts, trees, smallest sets), every strand-atom's criteria, and every n table."
        )
    )
    md = "\n".join(L) + "\n"
    if "~h" in md or "\N{COMBINING DOT BELOW}" in md:
        raise AssertionError("an unreplaced placeholder or a decomposed h with dot below")
    # Every Hebrew run of the report must occur in the data it was copied from.
    pool = []
    for r in rows:
        pool += [r["form"], r["mam_form"], r["strand_name"]]
    for cv in cvs:
        pool += cv["forms"]
    for d in diff:
        pool += [d["mam_form"], d["morphhb_main_text_form"], d["strand_name"]]
    for x in new:
        pool.append(x["form"])
    for x in clc_main:
        pool.append(x["form"])
    for d in bk["disagreements"]:
        pool += [a["form"] for a in d["atoms"]]
    pool += list(NAME.values())
    blob = "\n".join(pool)
    import re

    runs = re.findall(r"[֐-׿͏][֐-׿͏ ]*[֐-׿͏]|[֐-׿]", md)
    # A run may join two atoms' forms by a space (section 3's two-atom set); check each piece.
    missing = sorted({p for x in runs for p in x.split(" ") if p and p not in blob})
    if missing:
        raise AssertionError(f"Hebrew in the report not found in the data: {missing}")
    print("Hebrew runs checked against the data:", len(runs))
    (W / "out" / "53-accgram.md").write_text(md, encoding="utf-8", newline="\n")
    print("wrote", W / "out" / "53-accgram.md", len(md), "chars")


main()

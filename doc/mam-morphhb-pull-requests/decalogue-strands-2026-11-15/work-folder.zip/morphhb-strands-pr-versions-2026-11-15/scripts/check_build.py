"""Check a built set of wlc/ files against the intended versions and against the base.

Usage (MAM-basics root, -B): check_build.py <build-dir> <report.txt>

1. Rebuild every span's versions from the new XML alone (ElementTree), reading a note's
   reading as having the main version's punctuation when the note sits before the main
   version's punctuation seg, and its own (explicit) punctuation otherwise; compare with the
   intended versions (versions.compute()) in MAM-normal mark order, label by label.
2. Each changed file differs from its base only inside the 24 verses' <verse> blocks.
3. The validator's rules for every <w> in the three files (validate_data.py at db6c5c9b, as
   folder S's report describes them): unique five-character id, lemma, morph, text, and `n`
   of digits and dots; verse counts and ids unchanged; the XML well formed.
4. Every main <w> text keeps its letters (slashes and marks aside) and its attributes other
   than `n`.
5. Every main-text <w> of the 24 verses (for a ketiv, its qere's <w>) has exactly the `n` that
   out/54-for-build.json's "new_n" gives it, none where that is null; a ketiv's <w> has none.
"""

import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))  # untracked scratch: exempt
import strands_core as sc  # noqa: E402
import versions as vs  # noqa: E402
from build import LABELS  # noqa: E402

NS = "{http://www.bibletechnologies.net/2003/OSIS/namespace}"
KIND_OF = {g: {v: k for k, v in LABELS[g].items()} for g in (False, True)}


def local(el):
    return el.tag.replace(NS, "")


def split_text(text):
    for name, ch in sc.PUNCT_CHAR.items():
        if text.endswith(ch):
            return text[: -len(ch)], name
    return text, ""


def rebuild(verse_el, vid):
    """-> list of (w_id, main_span, {kind: span}, problems)"""
    out = []
    kids = list(verse_el)
    i = 0
    while i < len(kids):
        el = kids[i]
        if local(el) != "w":
            i += 1
            continue
        wid, text = el.get("id"), el.text or ""
        j = i + 1
        punct, alts, problems = "", {}, []
        seen_seg = False
        if el.get("type") == "x-ketiv":
            var = kids[j]
            qw = [e for e in var.iter() if local(e) == "w"][0]
            wid, text = qw.get("id"), qw.text or ""
            j += 1
        while j < len(kids) and local(kids[j]) in ("seg", "note"):
            k = kids[j]
            if local(k) == "seg" and k.get("type") in sc.SEG_PUNCT:
                if seen_seg:
                    problems.append("two punctuation segs")
                punct = sc.SEG_PUNCT[k.get("type")]
                seen_seg = True
            elif local(k) == "note" and k.get("type") == "alternative":
                cw = k.find(NS + "catchWord").text or ""
                rd = k.find(NS + "rdg").text or ""
                label = k.get("subType")
                kind = KIND_OF[sc.is_gen(vid)].get(label)
                if kind is None:
                    problems.append(f"unknown label {label!r}")
                cw_core, cw_p = split_text(cw)
                rd_core, rd_p = split_text(rd)
                alts[kind] = (cw_core, cw_p, rd_core, rd_p, seen_seg)
            elif local(k) == "seg" or local(k) == "note":
                break
            j += 1
        main = (text.replace("/", ""), punct)
        versions = {}
        for kind, (cw_core, cw_p, rd_core, rd_p, after_seg) in alts.items():
            if cw_core.replace("/", "") != main[0]:
                problems.append(f"{kind}: catchWord's atom is not the main text's")
            if after_seg or not punct:
                if cw_p != punct:
                    problems.append(
                        f"{kind}: catchWord's punctuation {cw_p!r} is not {punct!r}"
                    )
                versions[kind] = (rd_core.replace("/", ""), rd_p)
            else:
                if cw_p or rd_p:
                    problems.append(f"{kind}: a note before the seg quotes punctuation")
                versions[kind] = (rd_core.replace("/", ""), punct)
        out.append((wid, main, versions, problems))
        i = j
    return out


def verse_blocks(text):
    return {
        m.group(1): (m.start(), m.end())
        for m in re.finditer(r'<verse osisID="([^"]+)">.*?</verse>', text, re.S)
    }


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    bdir, report = Path(sys.argv[1]), Path(sys.argv[2])
    recs = {r["w_id"]: r for r in vs.compute()}
    new_n = json.loads((sc.W / "out/54-for-build.json").read_text(encoding="utf-8"))[
        "new_n"
    ]
    lines, bad = [], 0
    seen_ids = set()
    n_checked = n_coded = 0
    for book in sc.BOOKS:
        new = (bdir / f"{book}.xml").read_text(encoding="utf-8")
        base = sc.load_base(book)
        root = ET.fromstring(new.encode("utf-8"))
        broot = ET.fromstring(base.encode("utf-8"))
        # 2. diff confined to the 24 verses
        nb, bb = verse_blocks(new), verse_blocks(base)
        if list(nb) != list(bb):
            lines.append(f"{book}: verse ids or order changed")
            bad += 1
        ours = [v for v in sc.VIDS if v.startswith(book + ".")]
        pieces_new, pieces_base, last_n, last_b = [], [], 0, 0
        for vid in ours:
            pieces_new.append(new[last_n : nb[vid][0]])
            pieces_base.append(base[last_b : bb[vid][0]])
            last_n, last_b = nb[vid][1], bb[vid][1]
        pieces_new.append(new[last_n:])
        pieces_base.append(base[last_b:])
        if pieces_new != pieces_base:
            lines.append(f"{book}: a change outside the 24 verses")
            bad += 1
        changed = sum(1 for v in ours if new[slice(*nb[v])] != base[slice(*bb[v])])
        lines.append(
            f"{book}: {changed} of {len(ours)} verses changed; outside them identical: {pieces_new == pieces_base}"
        )
        # 3. validator's rules on every <w>
        nw = 0
        for w in root.iter(NS + "w"):
            nw += 1
            wid = w.get("id") or ""
            if len(wid) != 5 or wid in seen_ids:
                lines.append(f"{book}: bad or repeated id {wid!r}")
                bad += 1
            seen_ids.add(wid)
            if not w.get("lemma") or not w.get("morph") or not (w.text or "").strip():
                lines.append(f"{book}: {wid} lacks lemma, morph or text")
                bad += 1
            n = w.get("n")
            if n is not None and not re.fullmatch(r"[0-9]+(\.[0-9]+)*", n):
                lines.append(f"{book}: {wid} has n={n!r}")
                bad += 1
        bw = sum(1 for _ in broot.iter(NS + "w"))
        lines.append(f"{book}: <w> count {nw} (base {bw})")
        if nw != bw:
            bad += 1
        # 4. attributes and letters of main <w>
        base_w = {w.get("id"): w for w in broot.iter(NS + "w")}
        for w in root.iter(NS + "w"):
            b = base_w[w.get("id")]
            ba = {k: v for k, v in b.attrib.items() if k != "n"}
            na = {k: v for k, v in w.attrib.items() if k != "n"}
            if ba != na:
                lines.append(f"{book}: {w.get('id')} attributes changed")
                bad += 1
            let = lambda s: "".join(sc.LETTER.findall(s or ""))
            if let(w.text) != let(b.text):
                lines.append(f"{book}: {w.get('id')} letters changed")
                bad += 1
        # 5. n of every main-text <w> equals new_n
        for vel in root.iter(NS + "verse"):
            vid = vel.get("osisID")
            if vid not in ours:
                continue
            for el in vel:
                if local(el) == "w":
                    if el.get("type") == "x-ketiv":
                        if el.get("n") is not None:
                            lines.append(f"{vid}: ketiv {el.get('id')} has n")
                            bad += 1
                        continue
                    mains = [el]
                elif local(el) == "note" and el.get("type") == "variant":
                    mains = [q for q in el.iter(NS + "w")]
                else:
                    continue
                for w in mains:
                    n_checked += 1
                    wid = w.get("id")
                    if wid not in new_n or w.get("n") != new_n[wid]:
                        lines.append(
                            f"{vid}: {wid} has n={w.get('n')!r}, new_n {new_n.get(wid, 'MISSING')!r}"
                        )
                        bad += 1
                    elif w.get("n") is not None:
                        n_coded += 1
        # 1. versions rebuilt from the XML
        for vel in root.iter(NS + "verse"):
            vid = vel.get("osisID")
            if vid not in ours:
                continue
            for wid, main_span, alts, problems in rebuild(vel, vid):
                r = recs[wid]
                want = {v["kind"]: tuple(v["span"]) for v in r["versions"]}
                got = dict(alts)
                got["main"] = main_span
                ok = set(want) == set(got) and all(
                    sc.span_key(want[k]) == sc.span_key(got[k]) for k in want
                )
                order = [k for k in want if k != "main"]
                if problems or not ok:
                    bad += 1
                    lines.append(
                        f"{vid}:{r['atom']} MISMATCH {problems} want={sorted(want)} got={sorted(got)}"
                    )
                    for k in sorted(set(want) | set(got)):
                        lines.append(
                            f"    {k}: want {ascii(want.get(k))} got {ascii(got.get(k))}"
                        )
    lines.append(
        f"n: {n_checked} main-text <w> of the 24 verses checked against new_n ({len(new_n)} entries), {n_coded} with a code"
    )
    if n_checked != len(new_n):
        lines.append("n: the build's main-text <w> and new_n differ in number")
        bad += 1
    lines.append(f"PROBLEMS: {bad}")
    report.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print("\n".join(lines[-12:]))


main()

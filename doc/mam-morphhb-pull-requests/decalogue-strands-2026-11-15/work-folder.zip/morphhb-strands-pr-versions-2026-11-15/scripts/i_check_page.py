"""Sub-agent I: check the built decision page against the page rules (read-only).

Usage (-I, MAM-basics root): i_check_page.py <decisions.html>

Reports: pointed Hebrew outside an element with lang="hbo"; a lang="hbo" element holding Hebrew
with no point or accent (other than inside an XML or description block, where whole runs are
wrapped); a <td> holding pointed Hebrew without dir="rtl"; a <p> or <li> whose text begins with
a Hebrew letter; a link whose text holds pointed Hebrew; and the counts of tables, details and
pointed runs.
"""

import re
import sys
from html.parser import HTMLParser
from pathlib import Path

LETTER = re.compile("[\N{HEBREW LETTER ALEF}-\N{HEBREW LETTER TAV}]")
MARK = re.compile("[\N{HEBREW ACCENT ETNAHTA}-\N{HEBREW POINT QAMATS QATAN}]")
NOT_POINTS = {
    "\N{HEBREW PUNCTUATION MAQAF}",
    "\N{HEBREW PUNCTUATION PASEQ}",
    "\N{HEBREW PUNCTUATION SOF PASUQ}",
}
VOID = {"br", "meta", "link", "img", "hr", "input"}


def has_point(s):
    return any(MARK.match(c) and c not in NOT_POINTS for c in s)


class P(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack = []
        self.problems = []
        self.counts = {"table": 0, "details": 0, "pointed runs": 0}
        self.block_text = None
        self.hbo_text = []
        self.td_stack = []
        self.a_text = None

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag in VOID:
            return
        self.stack.append((tag, a))
        if tag in self.counts:
            self.counts[tag] += 1
        if tag in ("p", "li"):
            self.block_text = ""
        if a.get("lang") == "hbo":
            self.hbo_text.append("")
        if tag == "td":
            self.td_stack.append([a.get("dir") == "rtl", ""])
        if tag == "a":
            self.a_text = ""

    def handle_endtag(self, tag):
        if tag in VOID:
            return
        while self.stack:
            t, a = self.stack.pop()
            if a.get("lang") == "hbo":
                txt = self.hbo_text.pop()
                in_pre = any(x[0] == "pre" for x in self.stack)
                if LETTER.search(txt) and not has_point(txt) and not in_pre:
                    self.problems.append(
                        f"unpointed Hebrew in lang=hbo: {ascii(txt)[:60]}"
                    )
            if t == "td":
                rtl, txt = self.td_stack.pop()
                if has_point(txt) and not rtl:
                    self.problems.append(
                        f"td with pointed Hebrew lacks dir=rtl: {ascii(txt)[:60]}"
                    )
            if t in ("p", "li") and self.block_text is not None:
                first = self.block_text.lstrip()
                if first and LETTER.match(first[0]):
                    self.problems.append(f"{t} opens with Hebrew: {ascii(first)[:60]}")
                self.block_text = None
            if t == "a" and self.a_text is not None:
                if has_point(self.a_text):
                    self.problems.append(
                        f"link on pointed Hebrew: {ascii(self.a_text)[:60]}"
                    )
                self.a_text = None
            if t == tag:
                break

    def handle_data(self, data):
        in_hbo = any(a.get("lang") == "hbo" for _, a in self.stack)
        in_style = any(t in ("style", "title") for t, _ in self.stack)
        if in_style:
            return
        for run in re.findall(
            "[\N{HEBREW LETTER ALEF}-\N{HEBREW LETTER TAV}\N{HEBREW ACCENT ETNAHTA}-\N{HEBREW POINT QAMATS QATAN}/]+",
            data,
        ):
            if has_point(run):
                self.counts["pointed runs"] += 1
                if not in_hbo:
                    self.problems.append(
                        f"pointed Hebrew outside lang=hbo: {ascii(run)[:60]}"
                    )
        if self.hbo_text:
            self.hbo_text[-1] += data
        if self.td_stack:
            self.td_stack[-1][1] += data
        if self.block_text is not None:
            self.block_text += data
        if self.a_text is not None:
            self.a_text += data


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    p = P()
    p.feed(Path(sys.argv[1]).read_text(encoding="utf-8"))
    print("counts:", p.counts)
    print("problems:", len(p.problems))
    for x in p.problems[:40]:
        print("  ", x)


main()

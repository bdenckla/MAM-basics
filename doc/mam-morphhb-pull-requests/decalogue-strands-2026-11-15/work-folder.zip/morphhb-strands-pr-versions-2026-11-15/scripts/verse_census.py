"""Census of the element sequence inside each of the 24 divided verses of the base files.

Prints one line per verse: W = <w>, M = maqaf seg, P = paseq seg, S = sof pasuq seg,
A = alternative note (with its catchWord/rdg counts), N# = numbered note, other segs and notes
by type. Also checks that the <w> ids line up with folder S's atoms.
"""

import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

W = Path(__file__).resolve().parent.parent
S = Path("C:/Users/BenDe/GitRepos/MAM-basics/.novc/morphhb-strands-pr-2026-11-14")
NS = "{http://www.bibletechnologies.net/2003/OSIS/namespace}"
VIDS = (
    ["Gen.35.22"]
    + [f"Exod.20.{v}" for v in (2, 3, 4, 5, 6, 8, 9, 10, 13, 14, 15)]
    + [f"Deut.5.{v}" for v in (6, 7, 8, 9, 10, 12, 13, 14, 15, 17, 18, 19)]
)
SEG = {"x-maqqef": "M", "x-sof-pasuq": "S", "x-paseq": "P"}


def verse_elements(text, vid):
    m = re.search(r'<verse osisID="%s">.*?</verse>' % re.escape(vid), text, re.S)
    xml = m.group(0).replace("<verse ", '<verse xmlns="http://www.bibletechnologies.net/2003/OSIS/namespace" ', 1)
    return ET.fromstring(xml)


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    atoms = json.loads((S / "out/22-clc-answers.json").read_text(encoding="utf-8"))["atoms"]
    ids_by_vid = {}
    for a in atoms:
        ids_by_vid.setdefault(a["vid"], []).append(a["morphhb_w_id"])
    texts = {
        b: (W / "fetched/base-696e21ce" / f"{b}.xml").read_text(encoding="utf-8")
        for b in ("Gen", "Exod", "Deut")
    }
    for vid in VIDS:
        v = verse_elements(texts[vid.split(".")[0]], vid)
        toks = []
        wids = []
        for el in v:
            tag = el.tag.replace(NS, "")
            if tag == "w":
                toks.append("W")
                wids.append(el.get("id"))
            elif tag == "seg":
                toks.append(SEG.get(el.get("type"), "seg:" + str(el.get("type"))))
            elif tag == "note":
                if el.get("type") == "alternative":
                    kids = [k.tag.replace(NS, "") for k in el]
                    toks.append("A" + ("" if kids == ["catchWord", "rdg"] else str(kids)))
                elif el.get("n"):
                    toks.append("N" + el.get("n"))
                else:
                    kids = [k.tag.replace(NS, "") for k in el]
                    toks.append("note:%s%s" % (el.get("type"), kids))
            else:
                toks.append(tag)
        ok = wids == ids_by_vid[vid]
        print(f"{vid:10} ids_match={ok} w={len(wids)} atoms={len(ids_by_vid[vid])} " + " ".join(toks))
        if not ok:
            print("   wids ", wids)
            print("   atoms", ids_by_vid[vid])


main()

"""Sub-agent I: main-text punctuation segs that differ between base and build, and where the
marks that CLC's rules supply to the main strand stand in the base (read-only).

Run with -B from the MAM-basics root.
"""

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))  # untracked scratch: exempt
import strands_core as sc  # noqa: E402
from i_desc_facts import verses, walk  # noqa: E402


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    base, build = verses(sc.W / "fetched/base-696e21ce"), verses(sc.W / "out/build-A")
    recs = {
        (r["vid"], r["atom"]): r
        for r in json.loads((sc.W / "out/60-versions.json").read_text(encoding="utf-8"))
    }
    for vid in sc.VIDS:
        for k, (x, y) in enumerate(zip(walk(base[vid]), walk(build[vid])), start=1):
            r = recs[(vid, k)]
            sup = r["supplied"][r["main_strand"]]
            if x["segs"] != y["segs"] or sup:
                print(
                    f"{vid}:{k} base segs {x['segs']} build segs {y['segs']} supplied {sup}"
                )


main()

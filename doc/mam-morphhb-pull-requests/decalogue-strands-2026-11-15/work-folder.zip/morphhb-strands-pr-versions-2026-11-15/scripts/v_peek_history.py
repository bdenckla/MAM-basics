"""Sub-agent V: print selected records of out/52-history.json (throwaway scratch).

Usage: python -I v_peek_history.py <book> <vid> [<vid> ...]
"""

import json
import sys
from pathlib import Path

W = Path(__file__).resolve().parent.parent
HISTORY = W / "out" / "52-history.json"


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    data = json.loads(HISTORY.read_text(encoding="utf-8"))
    book = data["books"][sys.argv[1]]
    for r in book["changed"]:
        if r["vid"] in sys.argv[2:]:
            print(json.dumps(r, ensure_ascii=False, indent=1))


main()

"""Sub-agent I (2026-11-15): adapt sub-agent G's out/53-accgram.json for the build.

Throwaway scratch for the morphhb strands pull request (prepared, not posted), written by Claude.
Run from C:/Users/BenDe/GitRepos/MAM-basics with -I:

    ./.venv/Scripts/python.exe -I .novc/morphhb-strands-pr-versions-2026-11-15/scripts/i_for_build.py

Reads out/53-accgram.json (G's), folder S's out/22-clc-answers.json (MAM's strand forms) and the
base files fetched/base-696e21ce/{Gen,Exod,Deut}.xml. Writes out/54-for-build.json, which
versions.py and build.py read:

  criterion_iv  {"<vid>:<atom>:<alef|bet>": ["iv"]} for every CLC strand-atom of the 24 verses
                that G's accgram run marks illegal by criterion (iv) (G's "strand_atoms", source
                "clc", "iv" among its criteria);
  new_n         {w id: code or null} for every main-text <w> of the 24 verses, the qere's <w>
                standing for a ketiv's (Deuteronomy 5:10's last atom: 05rMa). The codes are G's
                "n" / "new_main_text" n_new: accgram's division tree of MAM's main strand (the
                tahton in the Decalogues, the midrashit at Genesis 35:22), relative to the whole
                chanted verse, as decisions 11A and 12A recommend.

Checks (printed and stored under "checks"; any failure raises):
  1. new_n covers exactly the main-text <w> ids of the 24 verses in the base files, once each;
  2. a code is present exactly where MAM's main-strand form has a disjunctive accent at that atom,
     judged here independently of accgram's scanner, by code point: a prose disjunctive accent,
     a meteg on an atom that ends in sof pasuq (silluq), or a munah followed by a paseq
     (legarmeh; the one such main-strand atom here, Exodus 20:10, atom 10, accgram also reads as
     legarmeh);
  3. within each <verse> no two codes are equal (morphhb's structure app recurses without end on
     two lines with one code), and the last atom has a code (the app throws when the last <w>
     lacks n while another has it).
"""

import json
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

W = Path(__file__).resolve().parent.parent
S = W.parent / "morphhb-strands-pr-2026-11-14"
NS = "{http://www.bibletechnologies.net/2003/OSIS/namespace}"
VIDS = (
    ["Gen.35.22"]
    + [f"Exod.20.{v}" for v in (2, 3, 4, 5, 6, 8, 9, 10, 13, 14, 15)]
    + [f"Deut.5.{v}" for v in (6, 7, 8, 9, 10, 12, 13, 14, 15, 17, 18, 19)]
)
# Prose disjunctive accents, by code point (U+0591 atnah to U+05A1 pazer; U+05AE zarqa).
DISJ = {chr(c) for c in range(0x0591, 0x05A2)} | {"\N{HEBREW ACCENT ZINOR}"}
# Conjunctive accents (U+05A3 munah to U+05AD dehi).
CONJ = {chr(c) for c in range(0x05A3, 0x05AE)}
METEG = "\N{HEBREW POINT METEG}"
MUNAH = "\N{HEBREW ACCENT MUNAH}"
PASEQ = "\N{HEBREW PUNCTUATION PASEQ}"
SOF = "\N{HEBREW PUNCTUATION SOF PASUQ}"


def main_strand(vid):
    return "bet" if vid.startswith("Gen.") else "alef"


def disjunctive(form):
    """By code point: does MAM's strand form carry a disjunctive accent?"""
    if any(c in DISJ for c in form):
        return True
    if form.endswith(SOF) and METEG in form:
        return True  # silluq
    if form.rstrip().endswith(PASEQ) and MUNAH in form:
        return True  # legarmeh
    return False


def base_main_ids():
    """vid -> main-text <w> ids in order, the qere's <w> standing for a ketiv's."""
    out = {}
    for book in ("Gen", "Exod", "Deut"):
        root = ET.parse(W / "fetched/base-696e21ce" / f"{book}.xml").getroot()
        for v in root.iter(NS + "verse"):
            vid = v.get("osisID")
            if vid not in VIDS:
                continue
            ids = []
            for el in v:
                tag = el.tag.replace(NS, "")
                if tag == "w":
                    if el.get("type") == "x-ketiv":
                        continue
                    ids.append(el.get("id"))
                elif tag == "note" and el.get("type") == "variant":
                    qs = [x for x in el.iter(NS + "w")]
                    if len(qs) != 1:
                        raise ValueError(f"{vid}: variant note with {len(qs)} <w>")
                    ids.append(qs[0].get("id"))
            out[vid] = ids
    if set(out) != set(VIDS):
        raise ValueError("base files lack some of the 24 verses")
    return out


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    g = json.loads((W / "out/53-accgram.json").read_text(encoding="utf-8"))
    src = json.loads((S / "out/22-clc-answers.json").read_text(encoding="utf-8"))
    checks = {}

    # criterion (iv)
    civ = {}
    for r in g["strand_atoms"]:
        if r["source"] != "clc" or "iv" not in r["criteria"]:
            continue
        if r["vid"] not in VIDS:
            raise ValueError(f"(iv) outside the 24 verses: {r['vid']}")
        key = f"{r['vid']}:{r['atom']}:{r['strand']}"
        if key in civ:
            raise ValueError(f"repeated strand-atom {key}")
        civ[key] = ["iv"]
    checks["CLC strand-atoms illegal by (iv)"] = len(civ)

    # new_n
    rows = [r for r in g["n"]["new_main_text"] if r["in24"]]
    new_n = {}
    for r in rows:
        if r["w_id"] in new_n:
            raise ValueError(f"repeated w id {r['w_id']}")
        if r["strand"] != main_strand(r["vid"]):
            raise ValueError(f"{r['vid']}:{r['atom']}: strand {r['strand']}")
        new_n[r["w_id"]] = r["n_new"]
    ids = base_main_ids()
    want = [i for vid in VIDS for i in ids[vid]]
    if sorted(want) != sorted(new_n) or len(want) != len(set(want)):
        raise ValueError(
            "new_n does not cover the base files' main-text <w> ids exactly"
        )
    checks["main-text <w> of the 24 verses with an entry"] = len(new_n)
    checks["of them with a code"] = sum(1 for v in new_n.values() if v is not None)

    # check 2: a code exactly where MAM's main strand has a disjunctive accent
    atoms = {(a["vid"], a["atom"]): a for a in src["atoms"]}
    by_id = {r["w_id"]: r for r in rows}
    bad2 = []
    for vid in VIDS:
        for k, wid in enumerate(ids[vid], start=1):
            r = by_id[wid]
            if r["atom"] != k or r["vid"] != vid:
                raise ValueError(
                    f"{vid}: {wid} is G's atom {r['vid']}:{r['atom']}, not {k}"
                )
            a = atoms[(vid, k)]
            if a["morphhb_w_id"] != wid:
                raise ValueError(
                    f"{vid}:{k}: folder S has {a['morphhb_w_id']}, base {wid}"
                )
            mform = a[main_strand(vid)]["mam_form"]
            if mform != r["form"]:
                raise ValueError(f"{vid}:{k}: G's form is not folder S's MAM form")
            if disjunctive(mform) != (new_n[wid] is not None):
                bad2.append(f"{vid}:{k} {wid} code {new_n[wid]} tokens {r['tokens']}")
    checks["atoms where a code's presence and MAM's disjunctive accent disagree"] = bad2
    if bad2:
        raise SystemExit("check 2 failed: " + "; ".join(bad2))

    # check 3: codes distinct within each verse, last atom coded
    bad3 = []
    no_zero = []
    for vid in VIDS:
        codes = [new_n[w] for w in ids[vid] if new_n[w] is not None]
        if len(codes) != len(set(codes)):
            bad3.append(f"{vid}: repeated code")
        if new_n[ids[vid][-1]] is None:
            bad3.append(f"{vid}: last atom uncoded")
        if "0" not in codes:
            no_zero.append(vid)
    checks["verses with a repeated code or an uncoded last atom"] = bad3
    checks["verses with no n=0"] = no_zero
    if bad3:
        raise SystemExit("check 3 failed: " + "; ".join(bad3))

    changed = [r for r in rows if r["n_new"] != r["n_base"]]
    checks["main-text <w> whose n changes from the base"] = len(changed)
    checks["verses in which n changes"] = sorted(
        {r["vid"] for r in changed}, key=VIDS.index
    )

    out = {
        "about": "Sub-agent I (Claude, 2026-11-15), not reviewed by a human: the build's inputs "
        "from sub-agent G's out/53-accgram.json (criterion (iv); n of MAM's main strand, "
        "decisions 11A and 12A), with the checks of scripts/i_for_build.py.",
        "criterion_iv": civ,
        "new_n": new_n,
        "checks": checks,
    }
    (W / "out/54-for-build.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8", newline="\n"
    )
    for k, v in checks.items():
        print(f"{k}: {v}")
    for key in civ:
        print("  (iv):", key)
    print("wrote", W / "out/54-for-build.json")


main()

"""Reread, pinned, the remote facts the brief relies on, one logged GET at a time.

Writes fetched/<label>-<n>/... and appends to out/fetch_log.jsonl. Run with -I.
Usage: fetch_state.py <round-number>
"""

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
W = HERE.parent
sys.path.insert(0, str(HERE))  # scratch script in an untracked folder: exempt
import gh_fetch  # noqa: E402

LOG = str(W / "out/fetch_log.jsonl")


def main():
    n = sys.argv[1]
    f = lambda label, name: str(W / "fetched" / f"{label}-{n}" / name)
    gh_fetch.fetch(
        "json",
        ["repos/openscriptures/morphhb/commits/master", f("upstream-master", "commit.json"), LOG],
    )
    gh_fetch.fetch(
        "json", ["repos/openscriptures/morphhb/pulls/118", f("pr118", "pull.json"), LOG]
    )
    gh_fetch.fetch(
        "json",
        ["repos/openscriptures/morphhb/issues/116", f("issue116", "issue.json"), LOG],
    )
    gh_fetch.fetch(
        "json",
        [
            "repos/openscriptures/morphhb/issues/116/comments",
            f("issue116", "comments.json"),
            LOG,
        ],
    )
    gh_fetch.fetch(
        "json", ["repos/bdenckla/morphhb/branches", f("fork-branches", "branches.json"), LOG]
    )


main()

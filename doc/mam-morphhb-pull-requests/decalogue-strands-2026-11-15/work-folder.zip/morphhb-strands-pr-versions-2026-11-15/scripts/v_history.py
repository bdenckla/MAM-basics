"""Sub-agent V: what morphhb's commit 73784451 changed in Exodus and Deuteronomy, w by w.

Throwaway scratch for the morphhb strands pull request (prepared, not posted).  Written by Claude
(Opus 5.5, sub-agent V), 2026-11-15.  Reads fetched files only; imports no MAM-basics module.
Run from C:/Users/BenDe/GitRepos/MAM-basics in PowerShell 7:

    ./.venv/Scripts/python.exe -I .novc/morphhb-strands-pr-versions-2026-11-15/scripts/v_history.py

Writes only .novc/morphhb-strands-pr-versions-2026-11-15/out/52-history.json, and prints a
summary.

Inputs (folder F's fetched history, nothing refetched): wlc/Exod.xml at 57e5e441 (2010-03-31)
and at 73784451 (2010-07-13); wlc/Deut.xml at 9c46c1e1 (2010-07-02) and at 73784451; folder F's
per-file commit lists (hist-<Book>-commits-p01/page.json), which show that each "before" version
is the last commit to touch that file before 73784451.

Method.  Each verse is read tolerantly: its w's in order (text, attributes), its notes (type,
text, catchWord, rdg) and its segs; an unknown child raises.  The two versions' verses are
compared w by w (the same number of w's with the same letters, or the verse is reported).  A
changed w's marks are compared letter by letter and each added or removed mark is classed:
"accent" (U+0591 to U+05AF), "vowel point" (sheva to qubuts, qamats qatan), or "other" (any
other mark, named); a change in the "/" dividers or in an attribute is reported too.
"""

import json
import sys
import unicodedata
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path

MB = Path("C:/Users/BenDe/GitRepos/MAM-basics")
W = MB / ".novc" / "morphhb-strands-pr-versions-2026-11-15"
F = MB / ".novc" / "morphhb-corrections-2026-11-13" / "fetched"
OUT = W / "out" / "52-history.json"
NS = "{http://www.bibletechnologies.net/2003/OSIS/namespace}"
COMMIT = "73784451"
PAIRS = {
    "Exod": ("hist-Exod-2010-03-31-57e5e441", "hist-Exod-2010-07-13-73784451"),
    "Deut": ("hist-Deut-2010-07-02-9c46c1e1", "hist-Deut-2010-07-13-73784451"),
}
ALEF = "\N{HEBREW LETTER ALEF}"
TAV = "\N{HEBREW LETTER TAV}"
# Dropped from a form before its marks are compared: the morpheme divider, and the maqaf, paseq,
# sof pasuq and space that a note's reading may hold.
DROPPED = {
    "/",
    " ",
    "\N{HEBREW PUNCTUATION MAQAF}",
    "\N{HEBREW PUNCTUATION PASEQ}",
    "\N{HEBREW PUNCTUATION SOF PASUQ}",
}
VOWELS = {
    "\N{HEBREW POINT SHEVA}",
    "\N{HEBREW POINT HATAF SEGOL}",
    "\N{HEBREW POINT HATAF PATAH}",
    "\N{HEBREW POINT HATAF QAMATS}",
    "\N{HEBREW POINT HIRIQ}",
    "\N{HEBREW POINT TSERE}",
    "\N{HEBREW POINT SEGOL}",
    "\N{HEBREW POINT PATAH}",
    "\N{HEBREW POINT QAMATS}",
    "\N{HEBREW POINT HOLAM}",
    "\N{HEBREW POINT HOLAM HASER FOR VAV}",
    "\N{HEBREW POINT QUBUTS}",
    "\N{HEBREW POINT QAMATS QATAN}",
}


def local(tag):
    return tag[len(NS) :] if tag.startswith(NS) else tag


def mark_class(ch):
    if "\N{HEBREW ACCENT ETNAHTA}" <= ch <= "\N{HEBREW MARK MASORA CIRCLE}":
        return "accent"
    if ch in VOWELS:
        return "vowel point"
    return "other"


def clusters(text, where):
    out = []
    for ch in text:
        if ALEF <= ch <= TAV:
            out.append([ch, []])
        elif unicodedata.category(ch) in ("Mn", "Cf"):
            if not out:
                raise ValueError(f"{where}: a mark before any letter")
            out[-1][1].append(ch)
        elif ch in DROPPED:
            continue
        else:
            raise ValueError(f"{where}: unexpected {unicodedata.name(ch, hex(ord(ch)))}")
    return out


def read_book(path):
    root = ET.parse(path).getroot()
    verses = {}
    for verse in root.iter(NS + "verse"):
        vid = verse.get("osisID")
        ws, segs, verse_notes = [], [], []
        for child in verse:
            tag = local(child.tag)
            if tag == "w":
                for c in child:
                    if local(c.tag) != "seg" or list(c):
                        raise ValueError(f"{vid}: w child {local(c.tag)}")
                ws.append({"text": "".join(child.itertext()), "attrib": dict(child.attrib), "notes": []})
            elif tag == "seg":
                segs.append((len(ws), child.get("type"), child.text))
            elif tag == "note":
                rec = {"type": child.get("type"), "text": "".join(child.itertext()).strip()}
                kids = {local(c.tag): c for c in child}
                if set(kids) - {"catchWord", "rdg"}:
                    raise ValueError(f"{vid}: note children {sorted(kids)}")
                if "catchWord" in kids:
                    rec["catchWord"] = "".join(kids["catchWord"].itertext())
                if "rdg" in kids:
                    rec["rdg"] = "".join(kids["rdg"].itertext())
                    rec["rdg_type"] = kids["rdg"].get("type")
                if not ws:
                    # A note before the verse's first w, such as a versification note.
                    verse_notes.append(rec)
                    continue
                ws[-1]["notes"].append(rec)
            else:
                raise ValueError(f"{vid}: unknown verse child {tag!r}")
        verses[vid] = {"ws": ws, "segs": segs, "verse_notes": verse_notes}
    return verses


def mark_diff(old, new, where):
    """[(letter number, letter's name, 'added'|'removed', mark name, class)] or None if the
    letters differ."""
    co, cn = clusters(old, where), clusters(new, where)
    if [lt for lt, _ in co] != [lt for lt, _ in cn]:
        return None
    out = []
    for k, ((lt, mo), (_lt, mn)) in enumerate(zip(co, cn)):
        a, b = Counter(mo), Counter(mn)
        letter = unicodedata.name(lt).replace("HEBREW LETTER ", "").lower()
        for m in sorted((a - b).elements()):
            out.append((k + 1, letter, "removed", unicodedata.name(m), mark_class(m)))
        for m in sorted((b - a).elements()):
            out.append((k + 1, letter, "added", unicodedata.name(m), mark_class(m)))
    return out


def dividers(text):
    """The letter positions after which a '/' stands."""
    out, n = [], 0
    for ch in text:
        if ALEF <= ch <= TAV:
            n += 1
        elif ch == "/":
            out.append(n)
    return out


def commit_list(book):
    page = json.loads((F / f"hist-{book}-commits-p01" / "page.json").read_text(encoding="utf-8"))
    rows = []
    for c in page:
        rows.append(
            {
                "sha": c["sha"],
                "date": c["commit"]["committer"]["date"],
                "author": c["commit"]["author"]["name"],
                "message": c["commit"]["message"].splitlines()[0],
            }
        )
    rows.sort(key=lambda r: r["date"])
    return rows


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    out = {"books": {}}
    for book, (before_dir, after_dir) in PAIRS.items():
        commits = commit_list(book)
        idx = [i for i, r in enumerate(commits) if r["sha"].startswith(COMMIT)]
        if len(idx) != 1:
            raise ValueError(f"{book}: {COMMIT} not once in the commit list")
        i = idx[0]
        before_sha = before_dir.rsplit("-", 1)[1]
        if not commits[i - 1]["sha"].startswith(before_sha):
            raise ValueError(f"{book}: {before_sha} is not the commit before {COMMIT}")
        old = read_book(F / before_dir / f"{book}.xml")
        new = read_book(F / after_dir / f"{book}.xml")
        changed, verse_problems = [], []
        class_counts = Counter()
        notes_added = Counter()
        segs_changed = []
        for vid in sorted(set(old) | set(new), key=lambda v: (int(v.split(".")[1]), int(v.split(".")[2]))):
            if vid not in old or vid not in new:
                verse_problems.append(f"{vid}: in only one version")
                continue
            vo, vn = old[vid], new[vid]
            if vo["segs"] != vn["segs"]:
                segs_changed.append({"vid": vid, "before": vo["segs"], "after": vn["segs"]})
            if vo["verse_notes"] != vn["verse_notes"]:
                verse_problems.append(f"{vid}: its notes before the first w changed")
            if len(vo["ws"]) != len(vn["ws"]):
                verse_problems.append(f"{vid}: {len(vo['ws'])} w's, then {len(vn['ws'])}")
                continue
            for n, (wo, wn) in enumerate(zip(vo["ws"], vn["ws"]), 1):
                where = f"{book} {vid} w {n}"
                notes_o = [(x["type"], x.get("rdg")) for x in wo["notes"]]
                notes_n = [(x["type"], x.get("rdg")) for x in wn["notes"]]
                added = [x for x in wn["notes"] if (x["type"], x.get("rdg")) not in notes_o]
                removed = [x for x in wo["notes"] if (x["type"], x.get("rdg")) not in notes_n]
                for x in added:
                    notes_added[x["type"]] += 1
                if wo["text"] == wn["text"] and wo["attrib"] == wn["attrib"] and not added and not removed:
                    continue
                diff = mark_diff(wo["text"], wn["text"], where)
                rec = {
                    "vid": vid,
                    "w": n,
                    "before": wo["text"],
                    "after": wn["text"],
                    "attrib_before": wo["attrib"],
                    "attrib_after": wn["attrib"],
                    "letters_differ": diff is None,
                    "mark_changes": diff or [],
                    "dividers_changed": dividers(wo["text"]) != dividers(wn["text"]),
                    "notes_added": added,
                    "notes_removed": removed,
                }
                if added:
                    for x in added:
                        if x.get("rdg") is not None:
                            rec.setdefault("rdg_vs_before", []).append(
                                mark_diff(wo["text"], x["rdg"], where + " rdg")
                            )
                        if x.get("catchWord") is not None:
                            rec.setdefault("catchWord_is_after", []).append(x["catchWord"] == wn["text"])
                for _k, _lt, how, _m, cls in rec["mark_changes"]:
                    class_counts[f"{cls} {how}"] += 1
                changed.append(rec)
        vowel = [
            r for r in changed if any(cls == "vowel point" for *_x, cls in r["mark_changes"])
        ]
        other = [r for r in changed if any(cls == "other" for *_x, cls in r["mark_changes"])]
        out["books"][book] = {
            "before": before_dir,
            "after": after_dir,
            "commit": commits[i],
            "commit_before": commits[i - 1],
            "commit_after": commits[i + 1] if i + 1 < len(commits) else None,
            "verses": [len(old), len(new)],
            "verse_problems": verse_problems,
            "segs_changed": segs_changed,
            "w_changed": len(changed),
            "w_text_changed": sum(1 for r in changed if r["before"] != r["after"]),
            "w_attrib_changed": sum(1 for r in changed if r["attrib_before"] != r["attrib_after"]),
            "w_dividers_changed": sum(1 for r in changed if r["dividers_changed"]),
            "w_letters_differ": sum(1 for r in changed if r["letters_differ"]),
            "mark_change_counts": dict(class_counts),
            "notes_added_by_type": dict(notes_added),
            "w_with_vowel_point_change": [
                {"vid": r["vid"], "w": r["w"], "before": r["before"], "after": r["after"], "changes": r["mark_changes"]}
                for r in vowel
            ],
            "w_with_other_mark_change": [
                {"vid": r["vid"], "w": r["w"], "before": r["before"], "after": r["after"], "changes": r["mark_changes"]}
                for r in other
            ],
            "verses_with_changes": sorted({r["vid"] for r in changed}, key=lambda v: (int(v.split(".")[1]), int(v.split(".")[2]))),
            "changed": changed,
        }
    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=1) + "\n", encoding="utf-8", newline="\n")
    brief = {
        b: {k: v for k, v in rec.items() if k != "changed"} for b, rec in out["books"].items()
    }
    print(json.dumps(brief, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()

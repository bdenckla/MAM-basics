"""Check the reader files that 50-readers-encoding.md cites against their Git blob SHA-1.

Usage:
  python -I r2_verify.py

Folder S's fetched r-* folders each hold one file and the blob.json it was decoded from; the
file's blob SHA-1 must equal blob.json's "sha". The qadma folder's d4265dfa__* files (morphhb's
apps, converters) must match the d4265dfa tree listing, and its 65dfd513 correctMainTables.js
must match morphhb-parsing's tree as folder S fetched it. Prints one line per file and a total.
Reads only; writes nothing.
"""

import hashlib
import json
import sys
from pathlib import Path

NOVC = Path("C:/Users/BenDe/GitRepos/MAM-basics/.novc")
S = NOVC / "morphhb-strands-pr-2026-11-14" / "fetched"
Q = NOVC / "morphhb-qadma-2026-11-13" / "fetched"
P = NOVC / "morphhb-pashta-pr-2026-11-14" / "fetched"
R_FOLDERS = [
    "r-nabu-oshb_osis_parser", "r-bmc-OSHB-java", "r-bibledit-morphhb-cpp", "r-bos-OSISXMLBible",
    "r-bos-SwordResources", "r-oet-convert_OSHB_XML_to_TSV", "r-step-default-xsl",
    "r-chirho-oshb_book", "r-adigun-import-oshb", "r-adigun-model-ts",
    "r-adigun-HebrewStudyWorkspace", "r-solforged-oshb-ts", "r-pnathan-oshb-go",
    "r-teamim-index-php", "r-mhbparsing-exportToOsis", "r-dosfilos-provider",
    "r-verbum-morphhb_extractor", "r-metaxia-import-test", "r-metaxia-import-ts",
    "r-gifos-build-interlinear", "r-meforash-hebrew-py", "r-haftarah-words-mjs",
    "r-lectio-oshb-ts", "r-nyffenegger-create-db",
]
D4265 = [
    "read/Script/ElementMarkup.js", "read/Script/AccentCatalog.js",
    "read/Script/AccentInterpretation.js", "read/Script/Read.js",
    "structure/OshbVerse/Script/ElementMarkup.js", "structure/OshbVerse/Script/Structure.js",
    "structure/OshbVerse/Script/VerseMarkupHorizontal.js",
    "structure/OshbVerse/Script/VerseMarkupVertical.js",
    "structure/OshbVerse/Script/AccentCatalog.js",
    "structure/OshbVerse/Script/AccentInterpretation.js",
    "morphhbXML-to-JSON.pl", "morphhbXML-to-JSON.py", "oxlos-import/ConvertWLC.py",
    "oxlos-import/export.html",
]


def blob_sha(data):
    return hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest()


def only_file(folder, skip=("blob.json",)):
    files = [p for p in folder.iterdir() if p.is_file() and p.name not in skip]
    if len(files) != 1:
        raise SystemExit("expected one file in %s: %r" % (folder, files))
    return files[0]


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    bad = 0
    for name in R_FOLDERS:
        folder = S / name
        want = json.loads((folder / "blob.json").read_text(encoding="utf-8"))["sha"]
        got = blob_sha(only_file(folder).read_bytes())
        ok = got == want
        bad += not ok
        print("%-8s %s %s" % ("ok" if ok else "MISMATCH", got[:10], name))
    tree = json.loads((Q / "tree-d4265dfa" / "tree.json").read_text(encoding="utf-8"))
    shas = {e["path"]: e["sha"] for e in tree["tree"]}
    for path in D4265:
        folder = Q / ("d4265dfa__" + path.replace("/", "__"))
        got = blob_sha(only_file(folder).read_bytes())
        ok = got == shas.get(path)
        bad += not ok
        print("%-8s %s morphhb d4265dfa %s" % ("ok" if ok else "MISMATCH", got[:10], path))
    mp = json.loads((S / "r-tree-morphhb-parsing" / "tree.json").read_text(encoding="utf-8"))
    want = {e["path"]: e["sha"] for e in mp["tree"]}["morphhb-scripts/correctMainTables.js"]
    got = blob_sha(only_file(Q / "65dfd513__morphhb-scripts__correctMainTables.js").read_bytes())
    bad += got != want
    print("%-8s %s morphhb-parsing correctMainTables.js" % ("ok" if got == want else "MISMATCH", got[:10]))
    pop = only_file(S / "h-db6c5c9b-structure-Popup.js")
    print("(info)   %s morphhb db6c5c9b structure Popup.js, checked by folder S's h_verify_blobs" % blob_sha(pop.read_bytes())[:10])
    print("mismatches:", bad)


if __name__ == "__main__":
    main()

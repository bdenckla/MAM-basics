"""Verify the stored change and archive: apply change.diff to the base, compare with the build.

Run with -I: ice_verify.py <stored folder> <new empty scratch folder>
1. copies the three base files into <scratch>/wlc/, runs `git apply` there (outside any
   repository) with the stored change.diff, and compares each result with out/build-A's file;
2. opens work-folder.zip, tests every entry's CRC, and compares each entry with the file it was
   made from (inputs/ against their sources).
"""

import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

W = Path(__file__).resolve().parent.parent
S = Path("C:/Users/BenDe/GitRepos/MAM-basics/.novc/morphhb-strands-pr-2026-11-14")
BRIEF = Path(
    "C:/Users/BenDe/AppData/Local/Claude-Data/claude_pzs8sxrjxfjjc/side-session-notes/"
    "local_a80ded65-f78e-4280-8493-9dab3b8c5686/morphhb-strands-pr-versions-brief-2026-11-15.md"
)


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    stored, scratch = Path(sys.argv[1]), Path(sys.argv[2])
    scratch.mkdir(parents=True, exist_ok=False)
    (scratch / "wlc").mkdir()
    for b in ("Gen", "Exod", "Deut"):
        shutil.copyfile(W / "fetched/base-696e21ce" / f"{b}.xml", scratch / "wlc" / f"{b}.xml")
    env = dict(os.environ, GIT_TERMINAL_PROMPT="0", GCM_INTERACTIVE="never", GIT_CEILING_DIRECTORIES=str(scratch.parent))
    # Git for Windows sets core.autocrlf=true, which would write CRLF line ends
    proc = subprocess.run(
        ["git", "-c", "core.autocrlf=false", "apply", str(stored / "change.diff")],
        cwd=scratch,
        capture_output=True,
        text=True,
        env=env,
    )
    print("git apply:", proc.returncode, proc.stderr.strip())
    for b in ("Gen", "Exod", "Deut"):
        same = (scratch / "wlc" / f"{b}.xml").read_bytes() == (W / "out/build-A" / f"{b}.xml").read_bytes()
        print(f"{b}: applied = build-A: {same}")
    with zipfile.ZipFile(stored / "work-folder.zip") as z:
        bad = z.testzip()
        print("zip CRC test:", "ok" if bad is None else f"bad entry {bad}")
        mismatches = 0
        for info in z.infolist():
            rel = info.filename.split("/", 1)[1]
            if rel.startswith("inputs/folder-S/"):
                src = S / rel[len("inputs/folder-S/") :]
            elif rel.startswith("inputs/"):
                src = BRIEF
            else:
                src = W / rel
            if z.read(info) != src.read_bytes():
                mismatches += 1
                print("differs:", rel)
        print(f"zip entries {len(z.infolist())}, differing from their sources: {mismatches}")


main()

"""Sub-agent I (2026-11-15): every number the description and the decision page state, by script.

Throwaway scratch for the morphhb strands pull request (prepared, not posted), written by Claude.
Run with -B from the MAM-basics root (it imports strands_core for MAM-normal mark order):

    ./.venv/Scripts/python.exe -B .novc/morphhb-strands-pr-versions-2026-11-15/scripts/i_desc_facts.py

Reads the base files, out/build-A (with build-log.json and keys.txt), out/60-versions.json,
out/57-n-changes.json, out/55-final-accgram.json, out/53-accgram.json, scratch-i/56a-spot-fetched.json,
folder S's out/22-clc-answers.json, and the gh-pages branch record that the hebrew-morphology
session fetched on 2026-11-15. Writes out/58-facts.json: {name: value}, each value a number, a
string or a list, read by make_description.py ({{FACT:name}}) and make_fragments.py.
"""

import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))  # untracked scratch: exempt
import strands_core as sc  # noqa: E402

NS = "{http://www.bibletechnologies.net/2003/OSIS/namespace}"
SEG_PUNCT = {"x-maqqef": "maqaf", "x-paseq": "paseq", "x-sof-pasuq": "sof pasuq"}
DEC = [v for v in sc.VIDS if not sc.is_gen(v)]
BOOK = {"Gen": "Genesis", "Exod": "Exodus", "Deut": "Deuteronomy"}


def local(el):
    return el.tag.replace(NS, "")


def verses(d):
    out = {}
    for book in sc.BOOKS:
        for v in ET.parse(Path(d) / f"{book}.xml").getroot().iter(NS + "verse"):
            if v.get("osisID") in sc.VIDS:
                out[v.get("osisID")] = v
    return out


def walk(verse):
    """Main-text atoms in order: [{"id", "text", "segs": [...], "notes": [(after_seg, note)]}]."""
    out = []
    for el in verse:
        t = local(el)
        if t == "w":
            if el.get("type") == "x-ketiv":
                continue
            out.append(
                {
                    "id": el.get("id"),
                    "text": (el.text or "").replace("/", ""),
                    "segs": [],
                    "notes": [],
                }
            )
        elif t == "note" and el.get("type") == "variant":
            q = list(el.iter(NS + "w"))[0]
            out.append(
                {
                    "id": q.get("id"),
                    "text": (q.text or "").replace("/", ""),
                    "segs": [],
                    "notes": [],
                }
            )
        elif t == "seg" and el.get("type") in SEG_PUNCT:
            out[-1]["segs"].append(SEG_PUNCT[el.get("type")])
        elif t == "note" and el.get("type") == "alternative":
            out[-1]["notes"].append((bool(out[-1]["segs"]), el))
    return out


def vname(vid):
    b, c, v = vid.split(".")
    return f"{BOOK[b]} {c}:{v}"


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    W = sc.W
    facts = {}
    atoms = sc.atoms_by_vid()
    base, build = verses(W / "fetched/base-696e21ce"), verses(W / "out/build-A")

    # ---- the present division (the base, 696e21ce)
    alt = labelled = after_seg = 0
    marks_in_text = {"maqaf": 0, "paseq": 0, "sof pasuq": 0}
    multi_atom_notes = []
    covered = set()
    for vid in sc.VIDS:
        wk = walk(base[vid])
        for i, a in enumerate(wk):
            for was_after_seg, note in a["notes"]:
                alt += 1
                labelled += any(k != "type" for k in note.attrib)
                after_seg += was_after_seg
                cw = note.find(NS + "catchWord").text or ""
                rd = note.find(NS + "rdg").text or ""
                for name, ch in sc.PUNCT_CHAR.items():
                    if ch in cw or ch in rd:
                        marks_in_text[name] += 1
                k = len(
                    [
                        x
                        for x in re.split(
                            r"[ \N{HEBREW PUNCTUATION MAQAF}]", cw.replace("/", "")
                        )
                        if sc.LETTER.search(x)
                    ]
                )
                if k > 1:
                    multi_atom_notes.append(f"{vname(vid)}, atoms {i + 2 - k}-{i + 1}")
                for j in range(i + 1 - k, i + 1):
                    covered.add((vid, j + 1))
    differ, unnoted = [], []
    for vid in sc.VIDS:
        for a in atoms[vid]:
            al, be = sc.split_form(a["alef"]["mam_form"]), sc.split_form(
                a["bet"]["mam_form"]
            )
            if sc.span_key(al) != sc.span_key(be):
                differ.append((vid, a["atom"]))
                if (vid, a["atom"]) not in covered:
                    unnoted.append(f"{vname(vid)}, atom {a['atom']}")
    facts["base_alt_notes"] = alt
    facts["base_labelled_notes"] = labelled
    facts["base_notes_after_a_seg"] = after_seg
    facts["base_notes_quoting_maqaf"] = marks_in_text["maqaf"]
    facts["base_notes_quoting_paseq"] = marks_in_text["paseq"]
    facts["base_notes_quoting_sof_pasuq"] = marks_in_text["sof pasuq"]
    facts["base_multi_atom_notes"] = multi_atom_notes
    facts["strand_diff_atoms"] = len(differ)
    facts["strand_diff_atoms_dec"] = sum(1 for v, _ in differ if not sc.is_gen(v))
    facts["strand_diff_atoms_gen"] = sum(1 for v, _ in differ if sc.is_gen(v))
    facts["strand_diff_atoms_unnoted"] = len(unnoted)
    facts["strand_diff_atoms_unnoted_list"] = unnoted

    # today's main strand: the elyon where MAM's tahton does not end a chanted verse at the
    # verse's end (folder D's table, as G's g_common.MAIN_TODAY_BET records it)
    folder_d_bet = {
        "Exod.20.2",
        "Exod.20.13",
        "Exod.20.14",
        "Exod.20.15",
        "Deut.5.6",
        "Deut.5.17",
        "Deut.5.18",
        "Deut.5.19",
    }
    tahton_open = [
        v for v in DEC if not atoms[v][-1]["alef"]["mam_form"].endswith(sc.SOF_PASUQ)
    ]
    elyon_open = [
        v for v in DEC if not atoms[v][-1]["bet"]["mam_form"].endswith(sc.SOF_PASUQ)
    ]
    if set(tahton_open) != folder_d_bet:
        raise SystemExit(
            f"today's elyon verses {sorted(folder_d_bet)} are not where the tahton runs on: {tahton_open}"
        )
    if set(tahton_open) & set(elyon_open):
        raise SystemExit("a verse where neither strand ends a chanted verse")
    facts["verses_main_strand_changes"] = [vname(v) for v in tahton_open]
    facts["verses_elyon_runs_on"] = [vname(v) for v in elyon_open]
    facts["n_verses_main_strand_changes"] = len(tahton_open)

    # ---- the build
    log = json.loads((W / "out/build-A/build-log.json").read_text(encoding="utf-8"))[
        "log"
    ]
    for kind in ("clc_other", "mam_main", "mam_other"):
        es = [e for e in log if e.get("kind") == kind and "note" in e]
        facts[f"notes_{kind}"] = len(es)
        facts[f"notes_{kind}_gen"] = sum(1 for e in es if sc.is_gen(e["vid"]))
        facts[f"notes_{kind}_dec"] = sum(1 for e in es if not sc.is_gen(e["vid"]))
    facts["notes"] = sum(
        facts[f"notes_{k}"] for k in ("clc_other", "mam_main", "mam_other")
    )
    facts["notes_after_a_seg"] = 0
    facts["notes_quoting_punctuation"] = 0
    for vid in sc.VIDS:
        for a in walk(build[vid]):
            for was_after_seg, note in a["notes"]:
                facts["notes_after_a_seg"] += was_after_seg
                cw = note.find(NS + "catchWord").text or ""
                rd = note.find(NS + "rdg").text or ""
                facts["notes_quoting_punctuation"] += any(
                    ch in cw + rd for ch in sc.PUNCT_CHAR.values()
                )
    recs = json.loads((W / "out/60-versions.json").read_text(encoding="utf-8"))
    facts["spans"] = len(recs)
    per = {}
    for r in recs:
        per[len(r["versions"])] = per.get(len(r["versions"]), 0) + 1
    for k, v in per.items():
        facts[f"spans_with_{k}_versions"] = v
    ill = [
        (r["vid"], r["atom"], s)
        for r in recs
        for s in ("alef", "bet")
        if r["failed"][s]
    ]
    facts["illegal_strand_atoms"] = len(ill)
    facts["illegal_atoms"] = len({(v, a) for v, a, _ in ill})
    facts["illegal_by_iv_only_new"] = [
        f"{vname(v)}, atom {a}"
        for v, a, s in ill
        if [
            c
            for c in next(r for r in recs if r["vid"] == v and r["atom"] == a)[
                "failed"
            ][s]
        ]
        == ["iv"]
    ]
    main_ill = [r for r in recs if r["failed"][r["main_strand"]]]
    facts["illegal_main_atoms"] = len(main_ill)
    facts["illegal_main_atoms_list"] = [
        f"{vname(r['vid'])}, atom {r['atom']}" for r in main_ill
    ]
    unnoted_ill = [
        (r["vid"], r["atom"], s)
        for r in recs
        for s in ("alef", "bet")
        if r["failed"][s] and not r["noted"][s]
    ]
    facts["illegal_strand_atoms_not_noted"] = len(unnoted_ill)
    noted_nonmeteg = [
        (r["vid"], r["atom"], s)
        for r in recs
        for s in ("alef", "bet")
        if any(m != "meteg" for m in r["noted"][s])
    ]
    facts["clc_notes_not_meteg"] = len(noted_nonmeteg)
    facts["clc_notes_not_meteg_illegal"] = sum(
        1
        for v, a, s in noted_nonmeteg
        if next(r for r in recs if r["vid"] == v and r["atom"] == a)["failed"][s]
    )
    facts["main_atoms_text_changes"] = sum(1 for e in log if "new_text" in e)
    supplied = {}
    for r in recs:
        for m in r["supplied"][r["main_strand"]]:
            supplied[m] = supplied.get(m, 0) + 1
    facts["supplied_in_main"] = supplied
    facts["supplied_in_main_total"] = sum(supplied.values())

    # main-text punctuation and text, base against build
    seg_delta = {"maqaf": 0, "paseq": 0, "sof pasuq": 0}
    text_or_seg_verses, text_verses = [], []
    for vid in sc.VIDS:
        b, n = walk(base[vid]), walk(build[vid])
        if [x["id"] for x in b] != [x["id"] for x in n]:
            raise SystemExit(f"{vid}: main-text ids differ")
        t = any(sc.std(x["text"]) != sc.std(y["text"]) for x, y in zip(b, n))
        s = any(x["segs"] != y["segs"] for x, y in zip(b, n))
        for x, y in zip(b, n):
            for name in seg_delta:
                seg_delta[name] += y["segs"].count(name) - x["segs"].count(name)
        if t or s:
            text_or_seg_verses.append(vname(vid))
        if t:
            text_verses.append(vname(vid))
    facts["main_seg_change_maqaf"] = seg_delta["maqaf"]
    facts["main_seg_change_paseq"] = seg_delta["paseq"]
    facts["main_seg_change_sof_pasuq"] = seg_delta["sof pasuq"]
    facts["verses_main_text_or_punctuation_changes"] = len(text_or_seg_verses)
    facts["verses_main_text_changes"] = len(text_verses)
    facts["verses_main_text_changes_list"] = text_verses

    nch = json.loads((W / "out/57-n-changes.json").read_text(encoding="utf-8"))
    facts["n_changed_atoms"] = len(nch["changes"])
    facts["n_changed_verses"] = len({r["vid"] for r in nch["changes"]})
    facts["n_coded_atoms"] = sum(1 for r in nch["every_atom"] if r["new"] is not None)
    facts["verses_without_n0"] = [
        vname(v)
        for v in sc.VIDS
        if not any(r["vid"] == v and r["new"] == "0" for r in nch["every_atom"])
    ]
    facts["n_verses_without_n0"] = len(facts["verses_without_n0"])

    keys = (W / "out/build-A/keys.txt").read_text(encoding="utf-8")
    base_part, build_part = keys.split("== build:")
    facts["key_misses_base"] = len(re.findall(r"-> error\|", base_part))
    facts["key_misses_build"] = len(re.findall(r"-> error\|", build_part))
    facts["key_misses_build_at_legal"] = int(
        re.search(r"whose main text is legal: (\d+)", build_part).group(1)
    )

    fa = json.loads((W / "out/55-final-accgram.json").read_text(encoding="utf-8"))
    facts["final_chanted_verses"] = len(fa["chanted_verses"])
    facts["final_chanted_verses_not_clean"] = len(fa["not_clean"])
    facts["final_n_agree"] = len(fa["n_rows"]) - len(fa["n_disagreements"])
    facts["final_n_atoms"] = len(fa["n_rows"])
    facts["final_token_differences"] = len(fa["token_differences_from_mam"])

    g = json.loads((W / "out/53-accgram.json").read_text(encoding="utf-8"))
    st = g["n"]["broad_check"]["stats"]
    facts["ncheck_atoms"] = st["atoms"]
    facts["ncheck_atoms_agreeing"] = st["atoms agreeing"]
    facts["ncheck_verses"] = st["coded"]
    sp = json.loads(
        (W / "scratch-i/56a-spot-fetched.json").read_text(encoding="utf-8")
    )["52"]
    facts["het_compared"] = (
        sp["hets compared"] + sp["hets in morphhb's ketiv <w>, not compared"]
    )
    facts["het_differ"] = len(sp["hets whose point differs"])

    gp = json.loads(
        (
            sc.MB
            / ".novc/hebrew-morphology-2026-11-15/research/oshb/fetched/morphhb-branch-gh-pages/body.json"
        ).read_text(encoding="utf-8")
    )
    facts["gh_pages_head"] = gp["commit"]["sha"][:8]
    facts["gh_pages_date"] = gp["commit"]["commit"]["committer"]["date"][:10]
    facts["gh_pages_message"] = gp["commit"]["commit"]["message"]

    (W / "out/58-facts.json").write_text(
        json.dumps(facts, ensure_ascii=False, indent=1), encoding="utf-8", newline="\n"
    )
    for k, v in facts.items():
        print(f"{k}: {v}")


if __name__ == "__main__":
    main()

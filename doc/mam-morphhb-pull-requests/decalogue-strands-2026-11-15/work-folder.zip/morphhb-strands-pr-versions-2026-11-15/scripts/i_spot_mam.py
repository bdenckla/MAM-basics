"""Sub-agent I (2026-11-15): spot checks of reports 51 and 53 against MAM's mirror and accgram.

Throwaway scratch for the morphhb strands pull request (prepared, not posted), written by Claude.
Run with -B from the MAM-basics root (it imports MAM-basics' accgram):

    ./.venv/Scripts/python.exe -B .novc/morphhb-strands-pr-versions-2026-11-15/scripts/i_spot_mam.py

Writes scratch-i/56b-spot-mam.json, which i_spot_report.py turns into out/56-spot-checks.md.

Report 51's claim checked (its case 3): at Deuteronomy 5:8, atom 2 (MAM's 5:7), MAM's note
quotes the Leningrad Codex's form with a meteg on the shin, naming as missing only the
tahton's qadma, while WLC 4.20 has a merkha on that shin, which CLC's rules give to the tahton.
Read from MAM-basics' mirror in/mam-ws/A5-Deuter.json directly (not from sub-agent T's
extraction), from WLC 4.20's out/wlc420-u, and from folder S's out/22-clc-answers.json.

Report 53's claim checked (its answer 5): CLC's tahton of Deuteronomy 5:8 (folder S's
clc_rule_form, brackets removed) is ungrammatical by accgram's grammar, with a pashta_phrase
ERROR, and MAM's tahton form of atom 2 alone makes it grammatical. Run through accgram's own
functions (uni_to_marks, prose_scanner, prose_ply_grammar, lexical_validation), not through
sub-agent G's g_common wrapper.
"""

import json
import re
import sys
import unicodedata
from pathlib import Path

MB = Path("C:/Users/BenDe/GitRepos/MAM-basics")
sys.path.insert(0, str(MB / "py"))  # untracked scratch: exempt

from accgram import lexical_validation, uni_to_marks  # noqa: E402
from accgram.dual_cant_detangle import _tree_has_error  # noqa: E402
from accgram.prose_ply_grammar import build_parser, parse_tokens  # noqa: E402
from accgram.prose_scanner import HasLegarmeh, Token, scan_accents  # noqa: E402
from accgram.tree import tree_to_obj  # noqa: E402
from mb_cmn.uni_denorm import give_std_mark_order  # noqa: E402

W = MB / ".novc/morphhb-strands-pr-versions-2026-11-15"
S = MB / ".novc/morphhb-strands-pr-2026-11-14"
LETTER = re.compile("[\u05d0-\u05ea]")
MAQAF = "\N{HEBREW PUNCTUATION MAQAF}"
METEG = "\N{HEBREW POINT METEG}"
QADMA = "\N{HEBREW ACCENT QADMA}"
MERKHA = "\N{HEBREW ACCENT MERKHA}"
SHIN = "\N{HEBREW LETTER SHIN}"
LAMED = "\N{HEBREW LETTER LAMED}"
HE = "\N{HEBREW LETTER HE}"
# the note's words "qadma on the letter" (QOF DALET MEM ALEF, space, BET ALEF VAV TAV)
QADMA_BA_OT = (
    "\N{HEBREW LETTER QOF}\N{HEBREW LETTER DALET}\N{HEBREW LETTER MEM}\N{HEBREW LETTER ALEF} "
    "\N{HEBREW LETTER BET}\N{HEBREW LETTER ALEF}\N{HEBREW LETTER VAV}\N{HEBREW LETTER TAV}"
)
TA_ASEH = "\N{HEBREW LETTER TAV}\N{HEBREW LETTER AYIN}\N{HEBREW LETTER SHIN}\N{HEBREW LETTER HE}"


def letters(s):
    return "".join(LETTER.findall(s))


def marks_on(form, letter):
    """The marks on the first occurrence of letter in form."""
    out, cur = [], None
    for ch in form:
        if LETTER.match(ch):
            if cur is not None:
                return cur
            cur = [] if ch == letter else None
        elif cur is not None:
            cur.append(ch)
    return cur or []


def check_51():
    data = json.loads((MB / "in/mam-ws/A5-Deuter.json").read_text(encoding="utf-8"))
    ch5 = data[HE]
    text = "\n".join(ch5) if isinstance(ch5, list) else ch5
    hits = [m.start() for m in re.finditer(re.escape(QADMA_BA_OT), text)]
    found = []
    for at in hits:
        lc = text.rfind(LAMED + "!=", 0, at)
        seg = text[lc + 3 : at]
        form = seg[: seg.index(" (")] if " (" in seg else seg
        atoms = form.split(MAQAF)
        a2 = [a for a in atoms if letters(a) == TA_ASEH]
        expl = text[text.rfind("(", 0, at) : text.index(")", at) + 1]
        found.append(
            {"lc_form": form, "atom": a2[0] if a2 else None, "explanation": expl}
        )
    if len(found) != 1:
        raise SystemExit(
            f"expected one note naming a missing qadma on a letter in chapter 5, found {len(found)}"
        )
    f = found[0]
    shin = marks_on(f["atom"], SHIN)
    # WLC 4.20's Deuteronomy 5:8, atom 2
    wlc = None
    for path in sorted((MB / "out/wlc420-u").glob("1verses_*.json")):
        for verse in json.loads(path.read_text(encoding="utf-8")):
            if verse["bcv"] == "dt5:8":
                words = [
                    v if isinstance(v, str) else v.get("word") for v in verse["vels"]
                ]
                atoms = [a for w in words if w for a in w.split(MAQAF) if a]
                wlc = atoms[1]
    if letters(wlc) != TA_ASEH:
        raise SystemExit(
            "WLC 4.20's atom 2 of Deuteronomy 5:8 is not the expected word"
        )
    clc = [
        a
        for a in json.loads(
            (S / "out/22-clc-answers.json").read_text(encoding="utf-8")
        )["atoms"]
        if a["vid"] == "Deut.5.8" and a["atom"] == 2
    ][0]
    taxton = clc["alef"]["clc_rule_form"].replace("[", "").replace("]", "")
    names_in_expl = [
        n
        for n in ("QADMA", "MERKHA", "METEG")
        if {
            "QADMA": "\N{HEBREW LETTER QOF}\N{HEBREW LETTER DALET}\N{HEBREW LETTER MEM}\N{HEBREW LETTER ALEF}",
            "MERKHA": "\N{HEBREW LETTER MEM}\N{HEBREW LETTER RESH}\N{HEBREW LETTER KAF}\N{HEBREW LETTER ALEF}",
            "METEG": "\N{HEBREW LETTER GIMEL}\N{HEBREW LETTER AYIN}\N{HEBREW LETTER YOD}\N{HEBREW LETTER HE}",
        }[n]
        in f["explanation"]
    ]
    res = {
        "lc_form_quoted": f["lc_form"],
        "explanation": f["explanation"],
        "marks named in the explanation": names_in_expl,
        "LC's atom 2 as quoted: shin has meteg": METEG in shin,
        "LC's atom 2 as quoted: shin has qadma or merkha": QADMA in shin
        or MERKHA in shin,
        "WLC 4.20's atom 2": wlc,
        "WLC 4.20's shin has merkha": MERKHA in marks_on(wlc, SHIN),
        "WLC 4.20's shin has meteg": METEG in marks_on(wlc, SHIN),
        "CLC's tahton by CLC's rules": taxton,
        "CLC's tahton shin has merkha": MERKHA in marks_on(taxton, SHIN),
    }
    res["holds"] = (
        res["LC's atom 2 as quoted: shin has meteg"]
        and not res["LC's atom 2 as quoted: shin has qadma or merkha"]
        and names_in_expl == ["QADMA"]
        and res["WLC 4.20's shin has merkha"]
        and res["CLC's tahton shin has merkha"]
    )
    return res


def error_phrases(obj, out=None):
    out = [] if out is None else out
    if "children" in obj:
        for c in obj["children"]:
            error_phrases(c, out)
    elif "ERROR" in obj["leaves"]:
        out.append(obj["label"])
    return out


def judge(forms):
    body = uni_to_marks.verse_to_marks({"vels": list(forms)})
    tokens = [Token("TILDE", "")] + scan_accents(body, "dt", 5, 8, HasLegarmeh())
    tree = parse_tokens(build_parser(), tokens)
    lex = lexical_validation.lexical_ungrammatical(body)
    errs = (
        error_phrases(tree_to_obj(tree))
        if tree is not None and _tree_has_error(tree)
        else []
    )
    return {
        "tokens": [t.type for t in tokens],
        "grammar": "error" if errs else ("no parse" if tree is None else "clean"),
        "error phrases": errs,
        "lexical findings": [m.code for m in lex],
    }


def check_53():
    atoms = [
        a
        for a in json.loads(
            (S / "out/22-clc-answers.json").read_text(encoding="utf-8")
        )["atoms"]
        if a["vid"] == "Deut.5.8"
    ]
    atoms.sort(key=lambda a: a["atom"])
    clc = [a["alef"]["clc_rule_form"].replace("[", "").replace("]", "") for a in atoms]
    mam = [a["alef"]["mam_form"] for a in atoms]
    if not clc[-1].endswith("\N{HEBREW PUNCTUATION SOF PASUQ}") or any(
        "\N{HEBREW PUNCTUATION SOF PASUQ}" in f for f in clc[:-1]
    ):
        raise SystemExit("CLC's tahton of Deuteronomy 5:8 is not one chanted verse")
    as_is = judge(clc)
    fixed = list(clc)
    fixed[1] = mam[1]
    with_mam_2 = judge(fixed)
    others = []
    for k in range(len(clc)):
        if k == 1 or give_std_mark_order(clc[k]) == give_std_mark_order(mam[k]):
            continue
        trial = list(clc)
        trial[k] = mam[k]
        cs, ms = set(clc[k]), set(mam[k])
        others.append(
            {
                "atom": k + 1,
                "grammar": judge(trial)["grammar"],
                "marks only CLC's form has": sorted(
                    unicodedata.name(c) for c in cs - ms
                ),
                "marks only MAM's form has": sorted(
                    unicodedata.name(c) for c in ms - cs
                ),
            }
        )
    res = {
        "CLC's tahton: grammar": as_is["grammar"],
        "CLC's tahton: error phrases": as_is["error phrases"],
        "CLC's tahton: lexical findings": as_is["lexical findings"],
        "with MAM's atom 2: grammar": with_mam_2["grammar"],
        "with MAM's atom 2: lexical findings": with_mam_2["lexical findings"],
        "tokens, CLC": as_is["tokens"][:6],
        "tokens, with MAM's atom 2": with_mam_2["tokens"][:6],
        "other atoms where CLC's form differs from MAM's, each substituted alone": others,
    }
    res["holds"] = (
        as_is["grammar"] == "error"
        and "pashta_phrase" in as_is["error phrases"]
        and with_mam_2["grammar"] == "clean"
        and not with_mam_2["lexical findings"]
    )
    return res


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    out = {"51": check_51(), "53": check_53()}
    p = W / "scratch-i/56b-spot-mam.json"
    p.write_text(
        json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8", newline="\n"
    )
    for k, v in out.items():
        print(k, json.dumps(v, ensure_ascii=True)[:1500])
    print("wrote", p)


main()

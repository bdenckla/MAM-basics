"""Sub-agent G: print the raw XML of the named verses from the base files (commit 696e21ce).

Usage: g_show_xml.py Exod.20.3 Deut.5.10 ...
"""

import re
import sys
from pathlib import Path

W = Path("C:/Users/BenDe/GitRepos/MAM-basics/.novc/morphhb-strands-pr-versions-2026-11-15")


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    for vid in sys.argv[1:]:
        book = vid.split(".")[0]
        text = (W / "fetched/base-696e21ce" / f"{book}.xml").read_text(encoding="utf-8")
        m = re.search(r'<verse osisID="%s">.*?</verse>' % re.escape(vid), text, re.S)
        print(m.group(0))
        print()


main()

"""Sub-agent G: dump every atom of folder S's 22-clc-answers.json to W/scratch-g/atoms.txt.

One line per atom and strand: WLC 4.20's form, the CLC-rule form, MAM's form, the supplied and
noted marks, and CLC's own notes on UXLC 2.6.  Read-only on its inputs; scratch output only.
"""

import json
import sys
from pathlib import Path

S = Path("C:/Users/BenDe/GitRepos/MAM-basics/.novc/morphhb-strands-pr-2026-11-14")
W = Path("C:/Users/BenDe/GitRepos/MAM-basics/.novc/morphhb-strands-pr-versions-2026-11-15")


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    data = json.loads((S / "out/22-clc-answers.json").read_text(encoding="utf-8"))
    lines = []
    for a in data["atoms"]:
        key = f"{a['vid']}:{a['atom']}"
        differ = "D" if a["two_strands_differ"]["mam"] else " "
        lines.append(f"{key:14} {differ} w={a['morphhb_w_id']} wlc420={a['wlc420']}")
        for s in ("alef", "bet"):
            d = a[s]
            noted = [(n["mark"], n["letter"], n["why"]) for n in d["noted"]]
            lines.append(
                f"    {s:4} clc_rule={d['clc_rule_form']}  mam={d['mam_form']}  "
                f"sup={d['supplied']} noted={noted} clc_noted={d['clc_noted']} "
                f"own={d['own_reading_differences']} lacks_shared={d['lacks_shared_mark']}"
            )
    out = W / "scratch-g" / "atoms.txt"
    out.parent.mkdir(exist_ok=True)
    out.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    whys = {}
    for a in data["atoms"]:
        for s in ("alef", "bet"):
            for n in a[s]["noted"]:
                whys.setdefault(n["why"], []).append(f"{a['vid']}:{a['atom']} {s} {n['mark']}")
    for k, v in whys.items():
        print(k, v)
    print("wrote", out)


main()

"""Compute every span's versions: main (CLC's main strand), CLC's other strand, MAM-informed.

Run with -B from the MAM-basics root. Writes out/60-versions.json and out/60-versions.txt.

Versions of a span, in order (Ben's scheme, 2026-11-15):
  main       CLC's תחתון (at Genesis 35:22 CLC's מדרשית): CLC's rules applied to WLC 4.20.
  clc_other  CLC's עליון (at Genesis 35:22 the פשוטה), where it differs from main.
  mam_main   MAM-informed תחתון (מדרשית), only where CLC's is illegal.
  mam_other  MAM-informed עליון (פשוטה), only where CLC's is illegal.
CLC's other strand is not given where it equals the main version; a MAM-informed version is
given wherever its strand's CLC version is illegal, even where it repeats another version.
A reader then rebuilds each version: the עליון is its note's reading, else the main text; a
MAM-informed version is its note's reading, else its strand's CLC version.

Illegality is by the mechanical criteria (i)-(iii) below and by criterion (iv), accgram's
verdict on the strand's chanted verse, merged from out/54-for-build.json's "criterion_iv"
(written by scripts/i_for_build.py from sub-agent G's out/53-accgram.json; required).
  (i)   no accent on an atom that ends a chanted word (no maqaf after it); a meteg on an atom
        followed by sof pasuq counts as silluq;
  (ii)  two different accents on one atom where MAM's strand has fewer (a doubled accent,
        such as a pashta and its helper, counts once);
  (iii) a letter with no vowel or sheva where MAM's strand has one there.

MAM-informed version (Ben: "just use MAM to correct WLC, not really literally using MAM"):
CLC's form, with MAM's strand's accents where they differ (added or, for (ii), removed),
MAM's vowels on the letters that (iii) flags and on the letter whose vowel moved, and MAM's
trailing punctuation. Never taken from MAM: a meteg, a stress helper (an accent that MAM
doubles), a qamats qatan (read as qamats), the holam of the Tetragrammaton, a dagesh or rafeh,
and Exodus 20:5's hataf patah.
"""

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))  # untracked scratch: exempt
import strands_core as sc  # noqa: E402

VOWELS = set(chr(c) for c in range(0x05B0, 0x05BB + 1)) | {"ֻ", "ׇ"}
QAMATS = "\N{HEBREW POINT QAMATS}"
QAMATS_QATAN = "\N{HEBREW POINT QAMATS QATAN}"
HOLAM = "\N{HEBREW POINT HOLAM}"
HOLAM_HASER_FOR_VAV = "\N{HEBREW POINT HOLAM HASER FOR VAV}"
TETRAGRAMMATON_LETTERS = "יהוה"


def accent_set(core):
    """Distinct accents of a core, a doubled accent counted once."""
    return set(sc.accents_of(core))


def vowels_by_letter(core):
    return [
        [m for m in marks if m in VOWELS and m not in (sc.METEG,)]
        for _, marks in sc.letters_marks(core)
    ]


def norm_mam_vowel(v):
    return QAMATS if v == QAMATS_QATAN else v


def is_tetragrammaton(core):
    letters = "".join(l for l, _ in sc.letters_marks(core))
    return letters.endswith(TETRAGRAMMATON_LETTERS) and len(letters) <= 6


PASHTA = "\N{HEBREW ACCENT PASHTA}"
QADMA = "\N{HEBREW ACCENT QADMA}"


def qadma_for_pashta(core, mcore):
    """Decision 4 as recommended: where WLC 4.20 writes a strand's qadma as a pashta (a lone
    pashta code point on a letter where MAM's strand has a qadma, with no pashta on the last
    letter), write the qadma code point, as morphhb does today."""
    cl, ml = sc.letters_marks(core), sc.letters_marks(mcore)
    if PASHTA not in core or PASHTA in cl[-1][1]:
        return core
    out = []
    for (l, ms), (_, mms) in zip(cl, ml):
        if PASHTA in ms and QADMA in mms and PASHTA not in mms:
            ms = [QADMA if m == PASHTA else m for m in ms]
        out.append(l + "".join(ms))
    return "".join(out)


def criteria(span, mam_span):
    core, punct = span
    mcore, _ = mam_span
    failed = []
    accs = accent_set(core)
    has_silluq = punct == "sof pasuq" and sc.METEG in core
    if punct != "maqaf" and not accs and not has_silluq:
        failed.append("i")
    if len(accs) >= 2 and len(accent_set(mcore)) < len(accs):
        failed.append("ii")
    cv, mv = vowels_by_letter(core), vowels_by_letter(mcore)
    if len(cv) != len(mv):
        raise ValueError("letter counts differ")
    for i, (a, b) in enumerate(zip(cv, mv)):
        if not a and [norm_mam_vowel(x) for x in b]:
            if is_tetragrammaton(mcore) and b == [HOLAM]:
                continue
            failed.append("iii")
            break
    return failed


def rank(m):
    """Insertion rank, following WLC 4.20's and morphhb's order: dots and rafeh, vowels,
    meteg, accents."""
    if m in sc.ACCENTS:
        return 3
    if m == sc.METEG:
        return 2
    if m in VOWELS:
        return 1
    return 0


def insert_mark(marks, new):
    """Insert new after the last existing mark whose rank is not greater than its own."""
    pos = 0
    for i, m in enumerate(marks):
        if rank(m) <= rank(new):
            pos = i + 1
    return marks[:pos] + [new] + marks[pos:]


def reorder_like(core, ref):
    """core's marks, letter by letter, in the order they have in ref (WLC 4.20's form), so that
    a form made by subtracting marks keeps WLC 4.20's order. Marks absent from ref keep their
    relative place at the end."""
    cl, rl = sc.letters_marks(core), sc.letters_marks(ref)
    if [l for l, _ in cl] != [l for l, _ in rl]:
        raise ValueError("letters differ")
    out = []
    for (l, ms), (_, rms) in zip(cl, rl):
        known = [m for m in rms if m in ms]
        extra = [m for m in ms if m not in rms]
        if sorted(known + extra) != sorted(ms):
            raise ValueError("repeated mark")
        out.append(l + "".join(known + extra))
    return "".join(out)


def mam_informed(vid, atom_no, span, mam_span, failed):
    """The MAM-informed version of an illegal CLC span (see the module docstring)."""
    core, punct = span
    mcore, mpunct = mam_span
    cl, ml = sc.letters_marks(core), sc.letters_marks(mcore)
    c_accs = sc.accents_of(core)
    m_accs = sc.accents_of(mcore)
    out = [[l, list(ms)] for l, ms in cl]
    notes = []
    # accents: per letter, add MAM's accents that CLC's form lacks (not a doubled helper),
    # and, for (ii), remove CLC's accents that MAM's strand lacks.
    m_counts = {a: m_accs.count(a) for a in set(m_accs)}
    for i, ((l, cms), (_, mms)) in enumerate(zip(cl, ml)):
        for a in mms:
            if a in sc.ACCENTS and a not in cms:
                if m_counts[a] > 1 and a in c_accs:
                    notes.append(f"letter {i + 1}: MAM's helper {ascii(a)} not taken")
                    continue
                if m_counts[a] > 1 and a not in c_accs:
                    # a doubled accent: take only the final (stressed or postpositive) one
                    last = max(j for j, (_, ms) in enumerate(ml) if a in ms)
                    if i != last:
                        notes.append(
                            f"letter {i + 1}: MAM's helper {ascii(a)} not taken"
                        )
                        continue
                out[i][1] = insert_mark(out[i][1], a)
                notes.append(f"letter {i + 1}: accent {ascii(a)} added from MAM")
        if "ii" in failed or "iv" in failed:
            for a in cms:
                if a in sc.ACCENTS and a not in m_accs:
                    out[i][1] = [m for m in out[i][1] if m != a]
                    notes.append(
                        f"letter {i + 1}: accent {ascii(a)} removed (MAM lacks it)"
                    )
    # vowels, for (iii): take MAM's vowels on every letter where they differ
    if "iii" in failed:
        for i, ((l, cms), (_, mms)) in enumerate(zip(cl, ml)):
            cvs = [m for m in cms if m in VOWELS]
            mvs = [norm_mam_vowel(m) for m in mms if m in VOWELS]
            if sorted(cvs) != sorted(mvs):
                kept = [m for m in out[i][1] if m not in VOWELS]
                for v in mvs:
                    kept = insert_mark(kept, v)
                out[i][1] = kept
                notes.append(
                    f"letter {i + 1}: vowels {ascii(''.join(cvs))} -> {ascii(''.join(mvs))} from MAM"
                )
    new_core = "".join(l + "".join(ms) for l, ms in out)
    new_punct = punct
    if mpunct != punct:
        new_punct = mpunct
        notes.append(f"punctuation {punct!r} -> {mpunct!r} from MAM")
    return (new_core, new_punct), notes


def compute():
    """Return a list of per-atom records."""
    p = sc.W / "out/54-for-build.json"
    accgram = json.loads(
        p.read_text(encoding="utf-8")
    )  # required: a missing file fails
    if "criterion_iv" not in accgram:
        raise ValueError(f"{p} has no criterion_iv")
    recs = []
    for a in sc.load_atoms():
        vid, n = a["vid"], a["atom"]
        ms, os_ = sc.main_strand(vid), sc.other_strand(vid)
        wlc_core = sc.split_form(a["wlc420"])[0]
        clc = {}
        for s in ("alef", "bet"):
            core, punct = sc.split_form(a[s]["clc_rule_form"])
            clc[s] = (reorder_like(core, wlc_core), punct)
        mam = {s: sc.split_form(a[s]["mam_form"]) for s in ("alef", "bet")}
        for s in ("alef", "bet"):
            clc[s] = (qadma_for_pashta(clc[s][0], mam[s][0]), clc[s][1])
        failed = {s: criteria(clc[s], mam[s]) for s in ("alef", "bet")}
        for s in ("alef", "bet"):
            for crit in accgram["criterion_iv"].get(f"{vid}:{n}:{s}", []):
                if crit not in failed[s]:
                    failed[s].append(crit)
        rec = {
            "vid": vid,
            "atom": n,
            "w_id": a["morphhb_w_id"],
            "main_strand": ms,
            "clc": clc,
            "mam": mam,
            "noted": {s: [x["mark"] for x in a[s]["noted"]] for s in ("alef", "bet")},
            "supplied": {s: a[s]["supplied"] for s in ("alef", "bet")},
            "failed": failed,
        }
        versions = [("main", clc[ms], [])]
        keys = [sc.span_key(clc[ms])]

        def add(kind, span, notes):
            # CLC's other strand only where it differs from the main version; a MAM-informed
            # version wherever its strand's CLC version is illegal, even if it repeats another
            # version, so that each label means what it says (decision 10, as recommended).
            k = sc.span_key(span)
            if kind == "clc_other" and k in keys:
                return
            if k in keys:
                notes = notes + ["repeats an earlier version"]
            versions.append((kind, span, notes))
            keys.append(k)

        add("clc_other", clc[os_], [])
        mi = {}
        for s, kind in ((ms, "mam_main"), (os_, "mam_other")):
            if failed[s]:
                mi[s] = mam_informed(vid, n, clc[s], mam[s], failed[s])
                add(kind, mi[s][0], mi[s][1])
        rec["mam_informed"] = {s: {"span": v[0], "notes": v[1]} for s, v in mi.items()}
        rec["versions"] = [
            {"kind": k, "span": sp, "notes": nt} for k, sp, nt in versions
        ]
        recs.append(rec)
    return recs


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    recs = compute()
    reordered = 0
    for a, r in zip(sc.load_atoms(), recs):
        for s in ("alef", "bet"):
            if sc.split_form(a[s]["clc_rule_form"])[0] != r["clc"][s][0]:
                reordered += 1
                print("reordered to WLC 4.20's order:", r["vid"], r["atom"], s)
    print("forms reordered:", reordered)
    (sc.W / "out/60-versions.json").write_text(
        json.dumps(recs, ensure_ascii=False, indent=1), encoding="utf-8", newline="\n"
    )
    lines = []
    counts = {}
    for r in recs:
        kinds = [v["kind"] for v in r["versions"]]
        counts[len(kinds)] = counts.get(len(kinds), 0) + 1
        if len(kinds) > 1 or any(r["failed"].values()):
            lines.append(
                f"{r['vid']}:{r['atom']} main={r['main_strand']} failed={r['failed']} "
                f"noted={r['noted']} kinds={kinds}"
            )
            for v in r["versions"]:
                lines.append(f"    {v['kind']:9} {ascii(v['span'])} {v['notes']}")
    lines.append(f"versions per span: {sorted(counts.items())}")
    (sc.W / "out/60-versions.txt").write_text(
        "\n".join(lines) + "\n", encoding="utf-8", newline="\n"
    )
    print(lines[-1])
    for r in recs:
        if any(r["failed"].values()):
            print(
                r["vid"],
                r["atom"],
                r["failed"],
                r["noted"],
                [v["kind"] for v in r["versions"]],
            )


if __name__ == "__main__":
    main()

"""Fetch one GitHub API resource with `gh api`, save it, and log the request.

Copied unchanged in behavior from folder S's (and folder F's) scripts/gh_fetch.py.

Usage:
  python -I gh_fetch.py raw  <owner/repo> <ref> <path-in-repo> <out-file> <log.jsonl>
  python -I gh_fetch.py json <api-path>                      <out-file> <log.jsonl>

`raw` GETs repos/<owner/repo>/contents/<path>?ref=<ref> with the raw media type, writes the
bytes unchanged and logs their size, SHA-256 and Git blob SHA-1. `json` GETs any API path and
writes the response unchanged. Every call is one read-only GET, with GH_PROMPT_DISABLED=1.
"""

import datetime
import hashlib
import json
import os
import subprocess
import sys
import urllib.parse
from pathlib import Path


def git_blob_sha1(data):
    h = hashlib.sha1()
    h.update(b"blob %d\0" % len(data))
    h.update(data)
    return h.hexdigest()


def run_gh(args):
    env = dict(os.environ)
    env["GH_PROMPT_DISABLED"] = "1"
    env["GIT_TERMINAL_PROMPT"] = "0"
    env["GCM_INTERACTIVE"] = "never"
    proc = subprocess.run(["gh", "api", *args], capture_output=True, env=env)
    if proc.returncode != 0:
        sys.stderr.buffer.write(proc.stderr)
        raise SystemExit("gh api failed: %r" % (args,))
    return proc.stdout


def fetch(kind, rest):
    if kind == "raw":
        repo, ref, path, out, log = rest
        api_path = "repos/%s/contents/%s?ref=%s" % (
            repo,
            urllib.parse.quote(path),
            urllib.parse.quote(ref),
        )
        data = run_gh(["-H", "Accept: application/vnd.github.raw", api_path])
    elif kind == "json":
        api_path, out, log = rest
        data = run_gh(["-H", "Accept: application/vnd.github+json", api_path])
    else:
        raise SystemExit("unknown kind " + kind)
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(data)
    rec = {
        "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "kind": kind,
        "api_path": api_path,
        "out": str(out),
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "git_blob_sha1": git_blob_sha1(data),
    }
    with open(log, "a", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(rec) + "\n")
    print(json.dumps(rec))
    return rec


def main():
    fetch(sys.argv[1], sys.argv[2:])


if __name__ == "__main__":
    main()

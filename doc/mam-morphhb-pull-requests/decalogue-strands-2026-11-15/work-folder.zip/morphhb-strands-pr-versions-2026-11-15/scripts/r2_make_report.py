"""Write W/out/50-readers-encoding.md from R2's template, copying the strand names by script.

Usage:
  python -I r2_make_report.py

The template, W/scratch-r2/r2_50_template.md, may hold no Hebrew character (the script refuses
it). Its placeholders @@TAXTON@@, @@ELYON@@, @@MIDRASHIT@@ and @@PESHUTAH@@ are filled with the
strand names copied from the commander's brief for this folder, found by the English words
around them. Every line of the result must begin, as to direction, with a Latin character.
Writes UTF-8 with LF line ends.
"""

import re
import sys
import unicodedata
from pathlib import Path

W = Path("C:/Users/BenDe/GitRepos/MAM-basics/.novc/morphhb-strands-pr-versions-2026-11-15")
BRIEF = Path(
    "C:/Users/BenDe/AppData/Local/Claude-Data/claude_pzs8sxrjxfjjc/side-session-notes/"
    "local_a80ded65-f78e-4280-8493-9dab3b8c5686/morphhb-strands-pr-versions-brief-2026-11-15.md"
)
PATTERNS = {
    "TAXTON": r"the main text is the (\S+)\s",
    "ELYON": r"and the (\S+) is in alternates",
    "MIDRASHIT": r"the main text stays the (\S+),",
    "PESHUTAH": r"with the (\S+) in alternates",
}


def is_hebrew(ch):
    return "\u0590" <= ch <= "\u05ff" or "\ufb1d" <= ch <= "\ufb4f"


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    template = (W / "scratch-r2" / "r2_50_template.md").read_text(encoding="utf-8")
    bad = [i + 1 for i, line in enumerate(template.splitlines()) if any(map(is_hebrew, line))]
    if bad:
        raise SystemExit("template holds Hebrew on lines %r" % bad)
    brief = BRIEF.read_text(encoding="utf-8")
    text = template
    for key, pattern in PATTERNS.items():
        found = re.findall(pattern, brief)
        names = set(found)
        if len(names) != 1:
            raise SystemExit("%s: expected one name, found %r" % (key, sorted(names)))
        name = names.pop()
        if not all("\u05d0" <= ch <= "\u05ea" for ch in name):
            raise SystemExit("%s: not plain Hebrew letters: %s" % (key, ascii(name)))
        print("%-9s %d letters, %s" % (key, len(name), ", ".join(unicodedata.name(c) for c in name)))
        text = text.replace("@@%s@@" % key, name)
    if "@@" in text:
        raise SystemExit("an unfilled placeholder remains")
    for i, line in enumerate(text.splitlines(), 1):
        for ch in line:
            kind = unicodedata.bidirectional(ch)
            if kind == "L":
                break
            if kind in ("R", "AL"):
                raise SystemExit("line %d begins with a right-to-left character" % i)
    out = W / "out" / "50-readers-encoding.md"
    with open(out, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)
    print("wrote", out, len(text.splitlines()), "lines")


if __name__ == "__main__":
    main()

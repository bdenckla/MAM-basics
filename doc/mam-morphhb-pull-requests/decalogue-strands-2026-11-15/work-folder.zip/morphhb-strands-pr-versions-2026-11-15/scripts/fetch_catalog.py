"""Fetch morphhb's two AccentCatalog.js files at master db6c5c9b (one logged GET each)."""

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
W = HERE.parent
sys.path.insert(0, str(HERE))  # untracked scratch: exempt
import gh_fetch  # noqa: E402

MASTER = "db6c5c9b46b8f39346f10915ddb1a70dcd429901"
for path in ("structure/OshbVerse/Script/AccentCatalog.js", "read/Script/AccentCatalog.js"):
    gh_fetch.fetch(
        "raw",
        [
            "openscriptures/morphhb",
            MASTER,
            path,
            str(W / "fetched/master-db6c5c9b" / path.replace("/", "__")),
            str(W / "out/fetch_log.jsonl"),
        ],
    )

"""Sub-agent G: print the shape of folder S's 22-clc-answers.json and a few sample atoms."""

import json
import sys
from pathlib import Path

S = Path("C:/Users/BenDe/GitRepos/MAM-basics/.novc/morphhb-strands-pr-2026-11-14")


def shape(obj, depth=0, maxdepth=3):
    pad = "  " * depth
    if isinstance(obj, dict):
        for k, v in list(obj.items())[:60]:
            if isinstance(v, (dict, list)) and depth < maxdepth:
                print(f"{pad}{k}: {type(v).__name__}({len(v)})")
                shape(v, depth + 1, maxdepth)
            else:
                print(f"{pad}{k}: {ascii(v)[:160]}")
    elif isinstance(obj, list):
        if obj:
            print(f"{pad}[0] of {len(obj)}:")
            shape(obj[0], depth + 1, maxdepth)


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    data = json.loads((S / "out/22-clc-answers.json").read_text(encoding="utf-8"))
    print("TOP KEYS", list(data.keys()))
    shape(data, 0, 1)
    print("=== atom 0 full")
    print(json.dumps(data["atoms"][0], ensure_ascii=True, indent=1)[:6000])
    want = set(sys.argv[1:])
    for a in data["atoms"]:
        key = f"{a['vid']}:{a['atom']}"
        if key in want:
            print("===", key)
            print(json.dumps(a, ensure_ascii=False, indent=1))


main()

"""Fetch wlc/Gen.xml, wlc/Exod.xml and wlc/Deut.xml at the base commit, plus #118's events.

Base: Ben's fork's pashta-helpers, commit 696e21ce (openscriptures/morphhb#118's head).
Also fetches the same three files at morphhb master db6c5c9b, for the diff check.
Writes fetched/base-696e21ce/ and fetched/master-db6c5c9b/; logs to out/fetch_log.jsonl.
"""

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
W = HERE.parent
sys.path.insert(0, str(HERE))  # scratch script in an untracked folder: exempt
import gh_fetch  # noqa: E402

LOG = str(W / "out/fetch_log.jsonl")
BASE = "696e21cef94e5bb0da2515667816d0965810d351"
MASTER = "db6c5c9b46b8f39346f10915ddb1a70dcd429901"


def main():
    for book in ("Gen", "Exod", "Deut"):
        gh_fetch.fetch(
            "raw",
            [
                "bdenckla/morphhb",
                BASE,
                f"wlc/{book}.xml",
                str(W / "fetched/base-696e21ce" / f"{book}.xml"),
                LOG,
            ],
        )
    for book in ("Gen", "Exod", "Deut"):
        gh_fetch.fetch(
            "raw",
            [
                "openscriptures/morphhb",
                MASTER,
                f"wlc/{book}.xml",
                str(W / "fetched/master-db6c5c9b" / f"{book}.xml"),
                LOG,
            ],
        )
    gh_fetch.fetch(
        "json",
        [
            "repos/openscriptures/morphhb/issues/118/events",
            str(W / "fetched/pr118-1/events.json"),
            LOG,
        ],
    )


main()

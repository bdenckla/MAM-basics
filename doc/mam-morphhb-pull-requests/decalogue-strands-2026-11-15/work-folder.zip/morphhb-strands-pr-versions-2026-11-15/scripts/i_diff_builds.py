"""Sub-agent I: compare the earlier draft (scratch-i/build-A-before) with out/build-A, line by line.

Run with -I from the MAM-basics root. Prints, per book, how many lines differ only in `n`
attributes, and every other differing line (Hebrew as ascii()), so that the rebuild's effect is
seen whole: the new n codes and the notes that criterion (iv) adds.
"""

import difflib
import re
import sys
from pathlib import Path

W = Path(__file__).resolve().parent.parent
N_ATTR = re.compile(r' n="[^"]*"')


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    for book in ("Gen", "Exod", "Deut"):
        a = (
            (W / "scratch-i/build-A-before" / f"{book}.xml")
            .read_text(encoding="utf-8")
            .splitlines()
        )
        b = (W / "out/build-A" / f"{book}.xml").read_text(encoding="utf-8").splitlines()
        sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
        n_only = other = 0
        for op, i1, i2, j1, j2 in sm.get_opcodes():
            if op == "equal":
                continue
            olds, news = a[i1:i2], b[j1:j2]
            if len(olds) == len(news) and all(
                N_ATTR.sub("", x) == N_ATTR.sub("", y) for x, y in zip(olds, news)
            ):
                n_only += len(olds)
                continue
            other += 1
            print(f"{book}: {op} lines {i1 + 1}-{i2} -> {j1 + 1}-{j2}")
            for x in olds:
                print("   -", ascii(x.strip())[:400])
            for y in news:
                print("   +", ascii(y.strip())[:400])
        print(f"{book}: {n_only} lines differ only in n; {other} other hunks")


main()

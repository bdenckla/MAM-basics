"""Sub-agent I: print the shape of JSON files (keys, lengths, short ascii samples); read-only.

Usage (-I, MAM-basics root): i_peek_json.py <file.json> [<depth>]
"""

import json
import sys
from pathlib import Path


def show(name, v, depth, maxdepth):
    pad = "  " * depth
    if isinstance(v, dict):
        print(
            f"{pad}{name}: dict({len(v)}) keys {[ascii(k)[:40] for k in list(v)[:10]]}"
        )
        if depth < maxdepth:
            for k in list(v)[:4]:
                show(ascii(k)[:40], v[k], depth + 1, maxdepth)
    elif isinstance(v, list):
        print(f"{pad}{name}: list({len(v)})")
        if v and depth < maxdepth:
            show("[0]", v[0], depth + 1, maxdepth)
    else:
        print(f"{pad}{name}: {ascii(v)[:150]}")


sys.stdout.reconfigure(encoding="utf-8")
d = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
show(Path(sys.argv[1]).name, d, 0, int(sys.argv[2]) if len(sys.argv) > 2 else 3)

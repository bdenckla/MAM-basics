"""Sub-agent G (2026-11-15): morphhb's n codes from accgram's division trees.

Throwaway scratch for the morphhb strands pull request (prepared, not posted), written by Claude.
Run after g_accgram.py, from C:/Users/BenDe/GitRepos/MAM-basics:

    ./.venv/Scripts/python.exe -B .novc/morphhb-strands-pr-versions-2026-11-15/scripts/g_ncodes.py

Reads W/scratch-g/g_accgram.json and morphhb's base files; writes W/scratch-g/g_ncodes.json.

The coding (g_common.tree_codes): n is on each main-text <w> whose accent is a disjunctive head;
its first digit is 1 for the part ending at the atnah, 0 for the part ending at the silluq; each
further digit numbers, down to 0, the sub-parts before the atom that ends the enclosing part,
and that atom carries the enclosing part's code.  Codes are relative to the whole chanted verse.
accgram's tree is used where it has no ERROR; elsewhere the independent level-based coding
g_common.level_codes, which is also computed everywhere as a cross-check.

(a) differential: for each of the 24 verses, the codes of today's main-text strand, taken from
    MAM's strand, against the n of the base files; and, to explain each disagreement, the codes
    of morphhb's own main text of that verse where its chanted verse lies within the verse.
(b) the new main text: MAM's tahton in the 23 Decalogue verses, MAM's midrashit at Genesis
    35:22, every atom, and the two verses outside the 24 into which the tahton runs on.
(c) CLC's main-strand forms with no accent or two: the code the tree gives the atom.
"""

import json
import sys

sys.dont_write_bytecode = True

import g_common as g  # noqa: E402


def cv_codes(cv: dict) -> dict:
    """Per-atom codes of one chanted verse record from g_accgram.json."""
    ver = cv["verdict"]
    toks = ver["accent_tokens"]
    types = [t for t, _l, _a in toks]
    lcodes, lnotes = g.level_codes(types)
    lper = g.atom_codes(toks, lcodes, len(cv["atoms"]))
    tper = None
    if ver["grammar"] == "clean":
        tcodes = g.tree_codes(ver["tree"], toks)
        tper = g.atom_codes(toks, tcodes, len(cv["atoms"]))
    per_atom = []
    for j, (vid, n) in enumerate(cv["atoms"]):
        atom_toks = [t for t, _l, ai in toks if ai == j]
        per_atom.append(
            {
                "vid": vid,
                "atom": n,
                "form": cv["forms"][j],
                "tokens": atom_toks,
                "tree": tper[j] if tper is not None else None,
                "level": lper[j],
            }
        )
    return {
        "label": cv["label"],
        "strand": cv["strand"],
        "source": cv["source"],
        "grammar": ver["grammar"],
        "status": ver["status"],
        "level_notes": lnotes,
        "tree_vs_level_agree": tper == lper if tper is not None else None,
        "atoms": per_atom,
    }


def code_of(rec: dict) -> str | None:
    """One atom's code: the tree's where there is one, else the level coding's."""
    codes = rec["tree"] if rec["tree"] is not None else rec["level"]
    if len(codes) > 1:
        return "+".join(codes)
    return codes[0] if codes else None


def morphhb_main_text_forms(words: list[dict]) -> list[str]:
    """morphhb's main-text atoms as forms like the JSON's: maqaf, paseq after a space, sof pasuq."""
    out = []
    for w in words:
        f = w["text"]
        if w.get("x-maqqef"):
            f += g.MAQAF
        if w.get("x-paseq"):
            f += " " + g.PASEQ
        if w.get("x-sof-pasuq"):
            f += g.SOF
        out.append(f)
    return out


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    acc = json.loads((g.W / "scratch-g" / "g_accgram.json").read_text(encoding="utf-8"))
    atoms = g.load_atoms()
    mam_simple = g.mam_simple_verses()
    extra = g.extra_atoms(mam_simple)
    by_vid: dict[str, list[dict]] = {}
    for a in atoms + extra:
        by_vid.setdefault(a["vid"], []).append(a)

    # All of MAM's chanted verses of the three passages, including those that hold only a
    # continuation verse (needed for today's codes of Exodus 20:11 and 20:16, Deuteronomy 5:20).
    mam_cvs = []
    for book in ("Gen", "Exod", "Deut"):
        for s in g.STRANDS:
            for cv in g.chanted_verses(by_vid, book, s, "mam"):
                _, ch, v = g.vid_parts(cv[0]["vid"])
                forms = [a[s]["mam"] for a in cv]
                ver = g.verdict(forms, g.BB[book], ch, v)
                rec = {
                    "book": book,
                    "strand": s,
                    "source": "mam",
                    "label": g.cv_label(cv),
                    "atoms": [[a["vid"], a["atom"]] for a in cv],
                    "forms": forms,
                    "verdict": ver,
                }
                mam_cvs.append(cv_codes(rec))
    code_at = {}  # (strand, vid, atom) -> (code, chanted verse label, tokens)
    for cvc in mam_cvs:
        if cvc["grammar"] != "clean" or cvc["status"] != "clean":
            raise ValueError(f"MAM's {cvc['strand']} {cvc['label']} is not clean")
        for r in cvc["atoms"]:
            code_at[(cvc["strand"], r["vid"], r["atom"])] = (code_of(r), cvc["label"], r["tokens"])
    tree_level = [
        {"strand": c["strand"], "label": c["label"], "agree": c["tree_vs_level_agree"], "notes": c["level_notes"]}
        for c in mam_cvs
    ]

    mh = g.morphhb_verses(list(g.VIDS24) + list(g.EXTRA_VIDS))

    # Align morphhb's <w> with the atoms: by id in the 24 verses, by order elsewhere.
    def aligned(vid):
        recs = by_vid[vid]
        words = mh[vid]
        if len(words) != len(recs):
            raise ValueError(f"{vid}: {len(words)} <w>, {len(recs)} atoms")
        for w, a in zip(words, recs):
            if a["w_id"] is not None and w["id"] != a["w_id"]:
                raise ValueError(f"{vid}: id {w['id']} vs {a['w_id']}")
            if g.letters(w["text"]) != g.letters(a["alef"]["mam"]):
                raise ValueError(f"{vid}: letters of {w['id']} differ")
        return list(zip(words, recs))

    # morphhb's own main text, coded, for the verses whose main-text chanted verse lies within
    # the verse (all but Exodus 20:3 and Deuteronomy 5:7, which continue a chanted verse).
    own = {}
    for vid in list(g.VIDS24) + list(g.EXTRA_VIDS):
        words = mh[vid]
        forms = morphhb_main_text_forms(words)
        if not forms[-1].endswith(g.SOF):
            raise ValueError(f"{vid}: morphhb's main text does not end in sof pasuq")
        if any(f.endswith(g.SOF) for f in forms[:-1]):
            own[vid] = {"note": "more than one sof pasuq in the verse"}
            continue
        book, ch, v = g.vid_parts(vid)
        ver = g.verdict(forms, g.BB[book], ch, v)
        rec = {
            "book": book,
            "strand": "main",
            "source": "morphhb",
            "label": vid,
            "atoms": [[vid, i + 1] for i in range(len(forms))],
            "forms": forms,
            "verdict": ver,
        }
        c = cv_codes(rec)
        own[vid] = {
            "forms": forms,
            "status": ver["status"],
            "grammar": ver["grammar"],
            "lexical": [x["code"] for x in ver["lexical"]],
            "codes": [code_of(r) for r in c["atoms"]],
            "tokens": [r["tokens"] for r in c["atoms"]],
            "tree_vs_level_agree": c["tree_vs_level_agree"],
        }

    # (a) differential: today's main-text strand, from MAM, against the base files' n.
    diff = []
    for vid in list(g.VIDS24) + list(g.EXTRA_VIDS):
        if vid in g.EXTRA_VIDS:
            # Today each is coded as a verse of its own: the tahton's chanted verse at
            # Exodus 20:11, the elyon's at Exodus 20:16 and Deuteronomy 5:20.
            s = "alef" if vid == "Exod.20.11" else "bet"
        else:
            s = "bet" if vid in g.MAIN_TODAY_BET else "alef"
        cont = vid in ("Exod.20.3", "Deut.5.7")
        for i, (w, a) in enumerate(aligned(vid)):
            code, label, toks = code_at[(s, vid, a["atom"])]
            own_code = own[vid]["codes"][i] if "codes" in own[vid] else None
            diff.append(
                {
                    "vid": vid,
                    "atom": a["atom"],
                    "w_id": w["id"],
                    "in24": a["in24"],
                    "main_strand_today": s,
                    "strand_name": g.STRAND_NAME[(a["book"], s)],
                    "chanted_verse": label,
                    "mam_form": a[s]["mam"],
                    "mam_tokens": toks,
                    "computed": code,
                    "morphhb_main_text": w["text"],
                    "morphhb_main_text_form": morphhb_main_text_forms([w])[0],
                    "morphhb_own_tokens": own[vid]["tokens"][i] if "tokens" in own[vid] else None,
                    "morphhb_own_code": own_code,
                    "n_base": w["n"],
                    "agree": code == w["n"],
                    "own_agrees_with_n": (own_code == w["n"]) if not cont else None,
                }
            )

    # (b) the new main text.
    new = []
    changes_strand = {"Exod.20.2", "Exod.20.13", "Exod.20.14", "Exod.20.15", "Deut.5.6", "Deut.5.17", "Deut.5.18", "Deut.5.19"}
    for vid in list(g.VIDS24) + ["Exod.20.16", "Deut.5.20"]:
        s = "bet" if vid == "Gen.35.22" else "alef"
        for w, a in aligned(vid):
            code, label, toks = code_at[(s, vid, a["atom"])]
            new.append(
                {
                    "vid": vid,
                    "atom": a["atom"],
                    "w_id": w["id"],
                    "in24": a["in24"],
                    "strand": s,
                    "strand_name": g.STRAND_NAME[(a["book"], s)],
                    "chanted_verse": label,
                    "form": a[s]["mam"],
                    "tokens": toks,
                    "n_new": code,
                    "n_base": w["n"],
                    "changed": code != w["n"],
                    "main_strand_changes": vid in changes_strand,
                }
            )

    # (c) CLC's main strand: every atom's code, from its own chanted verse.
    clc_main = []
    for cv in acc["chanted_verses"]:
        if cv["source"] != "clc":
            continue
        main_strand = "bet" if cv["book"] == "Gen" else "alef"
        if cv["strand"] != main_strand:
            continue
        c = cv_codes(cv)
        for r in c["atoms"]:
            mcode = code_at[(main_strand, r["vid"], r["atom"])][0]
            clc_main.append(
                {
                    "vid": r["vid"],
                    "atom": r["atom"],
                    "strand": main_strand,
                    "chanted_verse": c["label"],
                    "grammar": c["grammar"],
                    "status": c["status"],
                    "form": r["form"],
                    "tokens": r["tokens"],
                    "tree_code": "+".join(r["tree"]) if r["tree"] else (None if r["tree"] is not None else "no tree"),
                    "level_code": "+".join(r["level"]) if r["level"] else None,
                    "mam_code": mcode,
                    "mam_tokens": code_at[(main_strand, r["vid"], r["atom"])][2],
                }
            )

    out = {
        "mam_tree_vs_level": tree_level,
        "morphhb_own_main_text": own,
        "differential_today": diff,
        "new_main_text": new,
        "clc_main_strand": clc_main,
    }
    path = g.W / "scratch-g" / "g_ncodes.json"
    path.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8", newline="\n")

    print("MAM chanted verses: tree and level codings agree in",
          sum(1 for x in tree_level if x["agree"]), "of", len(tree_level))
    for x in tree_level:
        if not x["agree"] or x["notes"]:
            print("   ", x)
    print("(a) differential:", sum(1 for d in diff if d["agree"]), "of", len(diff), "atoms agree")
    for d in diff:
        if not d["agree"]:
            print(
                f"   {d['vid']}:{d['atom']} {d['strand_name']} mam={d['mam_form']} {d['mam_tokens']} "
                f"computed={d['computed']} n={d['n_base']} | morphhb {d['morphhb_main_text']} "
                f"{d['morphhb_own_tokens']} own={d['morphhb_own_code']} own_agrees={d['own_agrees_with_n']}"
            )
    for vid, o in own.items():
        if o.get("status") != "clean":
            print("   morphhb own main text", vid, o.get("status"), o.get("grammar"), o.get("lexical"), o.get("note"))
    print("(b) new main text: changed at", sum(1 for x in new if x["changed"]), "of", len(new), "atoms")
    for x in new:
        if x["changed"]:
            print(f"   {x['vid']}:{x['atom']} {x['form']} {x['tokens']} new={x['n_new']} base={x['n_base']}")
    print("(c) CLC main strand atoms whose code differs from MAM's:")
    for x in clc_main:
        code = x["tree_code"] if x["grammar"] == "clean" else x["level_code"]
        if code != x["mam_code"]:
            print(f"   {x['vid']}:{x['atom']} {x['form']} {x['tokens']} clc={code} ({x['grammar']}) mam={x['mam_code']} {x['mam_tokens']}")
    print("wrote", path)


main()

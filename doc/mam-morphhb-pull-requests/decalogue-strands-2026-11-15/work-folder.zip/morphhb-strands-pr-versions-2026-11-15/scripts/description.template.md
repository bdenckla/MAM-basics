Title: Decalogues and Genesis 35:22: one cantillation in the main text, the other versions in labelled notes

## Why

The Decalogues and Genesis 35:22 each have two cantillations. In the Decalogues they are the תחתון and the עליון; at Genesis 35:22, the פשוטה and the מדרשית. WLC writes both cantillations' marks in one text. `wlc/` divides them: its main text has one cantillation, and alternative notes, each a `<catchWord>` and an `<rdg type="x-accent">`, give readings of the other. The division was made in [73784451](https://github.com/openscriptures/morphhb/commit/73784451c0625b22bd03f24e5e53515e7759c7e6) (2010-07-13, "Separated the accents of the Ten Commandments, to conform with the WLC versification.") and, at Genesis 35:22, in [ba41e3da](https://github.com/openscriptures/morphhb/commit/ba41e3da258a85d70f4cc3b69bafe8b4e3569138) (2011-04-02). In the terms used below, an atom is a written form between spaces or maqaf marks, one `<w>`; a chanted word is an atom or a whole maqaf compound.

- **The main text switches cantillation.** It is the עליון in Exodus 20:2 and 13–15 and Deuteronomy 5:6 and 17–19, the {{FACT:n_verses_main_strand_changes}} verses where the תחתון does not end a chanted verse at the verse's end, and the תחתון in the other 15 Decalogue verses. Neither cantillation can be read from the main text alone.
- **No note says what it is.** None of the {{FACT:base_alt_notes}} alternative notes has a label.
- **Some differences have no note.** The two cantillations differ at {{FACT:strand_diff_atoms}} atoms of these verses, and {{FACT:strand_diff_atoms_unnoted}} of them have no note, so that the main text there has both cantillations' marks, or one cantillation's alone. For example, the first atom of Exodus 20:10 has the עליון's qadma and the תחתון's pashta in one `<w>`: {{F:Exod.20.10:1:base_main}}.
- **A note cannot change the punctuation.** Maqaf, paseq and sof pasuq are `<seg>` elements of the main text, and every note comes before them. A reading may hold a paseq ({{FACT:base_notes_quoting_paseq}} do) or, in the two three-atom notes of Deuteronomy 5:7 and 5:8, a maqaf, but none holds a sof pasuq, and no note can say that its cantillation lacks a mark that the main text has. So a cantillation read from the notes keeps the main text's sof pasuq even where it runs on into the next verse.
- **Four of WLC 4.20's marks were lost or changed** in dividing the accents:
  - Exodus 20:5, atom 2: WLC 4.20's sheva under the ḥet, {{F:Exod.20.5:2:wlc}}, is a ḥataf pataḥ in the main text, {{F:Exod.20.5:2:base_main}}, and in its note. Across `wlc/`, this is the only ḥet whose point differs from WLC 4.20's ({{FACT:het_compared}} ḥets compared).
  - Exodus 20:4, atom 10: WLC 4.20's meteg on the vav, {{F:Exod.20.4:10:wlc}}, is in neither the main text, {{F:Exod.20.4:10:base_main}}, nor the note, {{F:Exod.20.4:10:base_note}}.
  - Exodus 20:4, atom 12: of WLC 4.20's qamats and pataḥ under the tav, {{F:Exod.20.4:12:wlc}}, the עליון's reading has the תחתון's qamats and not its own pataḥ: {{F:Exod.20.4:12:base_note}}.
  - Exodus 20:8, atom 4: where WLC 4.20 has a geresh, {{F:Exod.20.8:4:wlc}}, the note has a qadma: {{F:Exod.20.8:4:base_note}}.

## What changes

Only the 24 verses that have alternative notes: Genesis 35:22; Exodus 20:2–6, 8–10 and 13–15; Deuteronomy 5:6–10, 12–15 and 17–19; in `wlc/Gen.xml`, `wlc/Exod.xml` and `wlc/Deut.xml`. No `<w>` is added or removed, and no id, lemma, morph or letter changes. No other file changes, and the scheme is described here only.

- **One cantillation in the main text.** The main text is the תחתון in all 23 Decalogue verses, and the מדרשית at Genesis 35:22, as now. In {{FACT:n_verses_main_strand_changes}} verses it changes from the עליון to the תחתון, and those verses now end without a sof pasuq, since the תחתון's chanted verse runs on into the next verse.
- **One rule for dividing WLC 4.20's marks.** Every version is made from WLC 4.20's own marks by the division rules of the [Charitable Leningrad Codex](https://bdenckla.github.io/MAM-basics/clc/) (CLC), an edition in MAM-basics whose pages show these verses' two cantillations one above the other. A mark that both cantillations have stays in both; a mark of one cantillation alone is taken out of the other, MAM's two cantillations saying which mark is whose (MAM is Miqra according to the Masorah, on Hebrew Wikisource). Where a cantillation needs a maqaf or sof pasuq that WLC lacks, the rules supply it; an accent or vowel that WLC lacks they do not. CLC's own pages divide UXLC 2.6, whose marks differ from WLC 4.20's at 8 atoms here; the rules are applied here to WLC 4.20, so `wlc/` keeps WLC 4.20's readings.
- **Up to four versions of each span.** A span is one atom with the maqaf, paseq or sof pasuq after it. Its versions, in order:
  1. the main text: CLC's תחתון (at Genesis 35:22 CLC's מדרשית);
  2. CLC's עליון (פשוטה), where it differs from the main text: `subType="x-elyon"` ({{FACT:notes_clc_other_dec}} notes), at Genesis 35:22 `x-peshutah` ({{FACT:notes_clc_other_gen}});
  3. a MAM-informed תחתון (מדרשית), where CLC's is not legal: `x-taxton-mam-informed` ({{FACT:notes_mam_main_dec}}), `x-midrashit-mam-informed` ({{FACT:notes_mam_main_gen}});
  4. a MAM-informed עליון (פשוטה), where CLC's is not legal: `x-elyon-mam-informed` ({{FACT:notes_mam_other_dec}}); none at Genesis 35:22.

  Each alternate is a note of its own, `<note type="alternative" subType="…">` with one `<catchWord>` and one `<rdg type="x-accent">`, since the apps show only a note's first reading. Of the {{FACT:spans}} spans, {{FACT:spans_with_1_versions}} have one version, {{FACT:spans_with_2_versions}} two and {{FACT:spans_with_3_versions}} three.
- **Legal** means here: every atom that ends a chanted word has an accent, a meteg before a sof pasuq counting as silluq; no atom has two accents where MAM's cantillation has one; no letter lacks a vowel or sheva that MAM's cantillation has there; and MAM-basics' accent grammar ([`py/accgram`](https://github.com/bdenckla/MAM-basics/tree/main/py/accgram)) finds the cantillation's chanted verse grammatical. A meteg never makes a version illegal. CLC's versions are not legal at {{FACT:illegal_strand_atoms}} places, in {{FACT:illegal_atoms}} atoms.
- **MAM-informed** means CLC's version with only the marks of MAM's cantillation that make it legal and give it MAM's cantillation: MAM's accent where CLC's version has none or another, one accent of two removed where MAM's has one, MAM's vowel added or moved, MAM's maqaf or sof pasuq. A MAM-informed version never takes from MAM a meteg, a stress helper, a qamats qatan, the Tetragrammaton's ḥolam, a dagesh or a rafeh, and in every version Exodus 20:5's sheva is WLC 4.20's.
- **Where the notes go.** A span's notes follow its `<w>`, as now, when every alternate has the main text's punctuation; the catchWord and reading then quote the atom alone. When an alternate's punctuation differs, all the span's notes follow the main text's punctuation seg, and the catchWord and reading quote each version's punctuation. In Exodus 20:3, for example, atom 1 has a maqaf in the תחתון and not in the עליון, and atom 2 has one in the עליון and not in the תחתון, whose version of atom 2 is also not legal:

```xml
{{XML:Exod.20.3:1-2}}
```

- **`n`** follows the main text's new division, as the section on `n` below says.

## Reading the notes

- The עליון (at Genesis 35:22 the פשוטה) is its `x-elyon` (`x-peshutah`) note's reading where the span has one, else the main text.
- A MAM-informed version is its note's reading where the span has one, else its cantillation's version as above.
- A note before the main text's punctuation seg shares that punctuation; a note after it, or after a `<w>` with no punctuation, quotes its own, which may be none.

## Where the main text is not legal

At {{FACT:illegal_main_atoms}} atoms the main text, CLC's version, is not legal. Each keeps WLC 4.20's reading in the main text and has a note with the MAM-informed version:

- Genesis 35:22, atom 7, {{F:Gen.35.22:7:main}}: no accent, since WLC 4.20 has only the פשוטה's zaqef qatan here. MAM-informed: {{F:Gen.35.22:7:mam_main}}.
- Exodus 20:3, atom 2, {{F:Exod.20.3:2:main}}: no accent, since WLC 4.20 has the עליון's meteg and maqaf here. MAM-informed: {{F:Exod.20.3:2:mam_main}}.
- Exodus 20:4, atom 13, {{F:Exod.20.4:13:main}}: a merkha and a munaḥ, where both of MAM's cantillations have the merkha alone. MAM-informed: {{F:Exod.20.4:13:mam_main}}, in the עליון too.
- Deuteronomy 5:8, atom 2, {{F:Deut.5.8:2:main}}: a merkha, where MAM's תחתון has a qadma; with it the chanted verse begins merkha, merkha, pashta, which the accent grammar does not allow. MAM-informed: {{F:Deut.5.8:2:mam_main}}.
- Deuteronomy 5:14, atom 4, {{F:Deut.5.14:4:main}}: a munaḥ and a tipeḥa, where both of MAM's cantillations have the munaḥ alone. MAM-informed: {{F:Deut.5.14:4:mam_main}}, in the עליון too.
- Deuteronomy 5:17, atom 2, {{F:Deut.5.17:2:main}}: no accent, since WLC 4.20 has the עליון's silluq here. MAM-informed: {{F:Deut.5.17:2:mam_main}}.

For {{FACT:key_misses_build}} of these the apps' accent popup shows "error|…", since their accent catalogs have no entry for an atom with no accent that `n` makes disjunctive, or for two accents: Genesis 35:22, atom 7; Exodus 20:4, atom 13; Deuteronomy 5:14, atom 4; and Deuteronomy 5:17, atom 2.

## `n`

`n` changes at {{FACT:n_changed_atoms}} atoms in {{FACT:n_changed_verses}} verses: Genesis 35:22, and the {{FACT:n_verses_main_strand_changes}} verses whose main text changes to the תחתון. Each atom is coded by its place in its cantillation's whole chanted verse, as Exodus 20:3 is coded now, as the second half of the תחתון's Exodus 20:2–3. So Exodus 20:2's codes begin with 1, its last atom, with the atnaḥ, has 1, and those {{FACT:n_verses_without_n0}} verses have no `n="0"`. Where the main text is not legal, an atom has the code of its MAM-informed version: Genesis 35:22, atom 7, has its revia's 1.1.2, and Deuteronomy 5:17, atom 2, its tipeḥa's 1.0, so that the structure app draws the verse; the atoms with two accents have no code, their accent being conjunctive in both cantillations. At Genesis 35:22, atoms 1, 3 and 5 change too: atom 7 had the code of the פשוטה's zaqef qatan, which WLC 4.20 has there, ending a part of its own, while the מדרשית's revia ends a part within the part that ends at atom 12.

The codes were computed, not made by hand: they are read off the division trees that MAM-basics' accent grammar gives MAM's cantillations. Read the same way, the trees of the other {{FACT:ncheck_verses}} verses of Genesis, Exodus and Deuteronomy that the grammar finds grammatical give `wlc/`'s own codes at {{FACT:ncheck_atoms_agreeing}} of their {{FACT:ncheck_atoms}} atoms. The 22 others are five kinds of place where `wlc/`'s coding and the grammar's reading part, the commonest a munaḥ with a paseq that the grammar reads as a paseq and `wlc/` codes as a legarmeh; none of the five occurs in the new main text.

## Known readers

Projects that use `wlc/` keep their own copies, so each sees this change only when it updates its copy. Most read the main text only, or drop alternative notes, and will see only the main text's new readings. Among those that read the notes, one OSIS library logs a load error for each note with a `subType`, and stops if its strict checking is on; two readers that refuse a note attribute they do not know both use an older commit and would need a change when they update; and one keeps only the last of several notes after one atom. No reader found attaches a note to the seg before it. Where a verse now ends without a sof pasuq, one reader joins the verse's closing samekh to its last atom, one analyzer that names every verse's last atom silluq would do so for the 8 verses if it rebuilt its database, and one project's test, which counts the corpus's segs, would need new counts. In this organization, morphhb-parsing's `correctMainTables.js` sets a word's `append` only when it meets a seg after the word, so a rerun would keep, as stale `append` values, the sof pasuq marks and the few maqaf and paseq marks that this change takes out of the main text.

## The web site

hb.openscriptures.org serves the `gh-pages` branch, last merged from master on {{FACT:gh_pages_date}}, so the site shows this change only after master is merged into `gh-pages` again. Its two apps need no change. They ignore `subType` and show each note as an asterisk whose tooltip is its reading; a note after a seg changes no accent key, since an atom's key is its own marks and the segs after it; and the structure app draws a verse that ends without a sof pasuq when its last `<w>` has `n`, as all {{FACT:n_verses_main_strand_changes}} do.

## How it was checked

- Each changed file differs from #118's head only inside the 24 verses and is well-formed XML, with the same verses. Every `<w>` keeps its id, lemma, morph and letters, and meets the rules that the data validator applies to it.
- Every version of every span, rebuilt from the new XML alone, equals the version intended, compared mark by mark after the marks on each letter are put in one standard order.
- Both cantillations, rebuilt from the new XML alone with their MAM-informed versions, are grammatical by MAM-basics' accent grammar in all {{FACT:final_chanted_verses}} chanted verses, and their accents, as the grammar reads them, equal MAM's at every atom. The codes read off those trees equal the new `n` at all {{FACT:final_n_atoms}} atoms.
- The apps' accent naming, replayed over the 24 verses, finds no catalog entry for the {{FACT:key_misses_build}} atoms listed above. Today it finds none for {{FACT:key_misses_base}}: Deuteronomy 5:15, atom 4, whose main text has the תחתון's pashta followed by the עליון's paseq, which is now in the note.

## Merging

This builds on #118, so it should be merged after #118; until then, its diff includes #118's commit as well as its own. It changes the main text of {{FACT:verses_main_text_changes}} of the 24 verses, in {{FACT:n_verses_main_strand_changes}} of them from the עליון to the תחתון, and `n` in {{FACT:n_changed_verses}}, so it may matter to the 2.3 release planned in #116.

🤖 Generated with [Claude Code](https://claude.com/claude-code)

"""Sub-agent I: show sub-agent T's scratch-t/doc_notes.json entries for the meteg cases (read-only).

Run with -I from the MAM-basics root. Prints each entry's keys and, for the three meteg cases
and their parallels, the notes' doc-parts as ascii().
"""

import json
import sys
from pathlib import Path

W = Path(__file__).resolve().parent.parent
sys.stdout.reconfigure(encoding="utf-8")
d = json.loads((W / "scratch-t/doc_notes.json").read_text(encoding="utf-8"))
print("entry keys:", list(d[0]))
for e in d:
    print(
        e["case"],
        e["vid"],
        e["atom"],
        e["mam_verse_label"] if "mam_verse_label" in e else "",
        "notes:",
        len(e["notes"]),
    )
    if e["case"] in ("1", "2", "2-par", "3", "1-par"):
        for n in e["notes"]:
            print("   note keys:", list(n))
            for k, v in n.items():
                print("     ", k, ascii(v)[:300])

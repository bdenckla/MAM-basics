"""R2a helper: describe the child shapes of the 24 two-strand verses in two builds.

Usage: r2a_verse_shapes.py <dir-A> <dir-B> <out.txt>
Each dir holds Gen.xml, Exod.xml, Deut.xml. Writes a plain report to out.txt.
"""

import re
import sys
import unicodedata
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path

NS = "{http://www.bibletechnologies.net/2003/OSIS/namespace}"
VERSES = (
    ["Gen.35.22"]
    + [f"Exod.20.{v}" for v in (2, 3, 4, 5, 6, 8, 9, 10, 13, 14, 15)]
    + [f"Deut.5.{v}" for v in (6, 7, 8, 9, 10, 12, 13, 14, 15, 17, 18, 19)]
)
ACCENTS = set(range(0x0591, 0x05AF + 1)) | {0x05BD}


def local(tag):
    return tag.split("}", 1)[1] if "}" in tag else tag


def has_accent(text):
    return any(ord(c) in ACCENTS and ord(c) != 0x05BD for c in text)


def describe(verse):
    kinds = []
    for child in verse:
        t = local(child.tag)
        if t == "w":
            kinds.append("w" + ("[n]" if child.get("n") is not None else ""))
        elif t == "seg":
            kinds.append("seg:" + (child.get("type") or "?"))
        elif t == "note":
            st = child.get("subType")
            rd = len([x for x in child if local(x.tag) == "rdg"])
            kinds.append(
                "note:" + (child.get("type") or "untyped") + (f"/{st}" if st else "") + f"/rdg{rd}"
            )
        else:
            kinds.append("other:" + t)
    return kinds


def raw_verse(text, vid):
    m = re.search(r'<verse osisID="%s">(.*?)</verse>' % re.escape(vid), text, re.S)
    return m.group(1) if m else ""


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    dirs = [Path(sys.argv[1]), Path(sys.argv[2])]
    out = []
    for d in dirs:
        out.append("=" * 20 + f" {d}")
        book_seg_counts = Counter()
        book_note_counts = Counter()
        for book in ("Gen", "Exod", "Deut"):
            path = d / f"{book}.xml"
            text = path.read_text(encoding="utf-8")
            root = ET.fromstring(text)
            for verse in root.iter(NS + "verse"):
                for child in verse:
                    t = local(child.tag)
                    if t == "seg":
                        book_seg_counts[(book, child.get("type"))] += 1
                    elif t == "note":
                        book_note_counts[(book, child.get("type"), child.get("subType"))] += 1
            byid = {v.get("osisID"): v for v in root.iter(NS + "verse")}
            for vid in VERSES:
                if not vid.startswith(book + "."):
                    continue
                v = byid[vid]
                kinds = describe(v)
                ws = [c for c in v if local(c.tag) == "w"]
                last_w = ws[-1]
                any_n = any(w.get("n") is not None for w in ws)
                last_child = local(list(v)[-1].tag)
                segs = [c.get("type") for c in v if local(c.tag) == "seg"]
                ends = [k for k in kinds if not k.startswith("note:")]
                raw = raw_verse(text, vid)
                note_then_w = len(re.findall(r"</note><w\b", raw))
                seg_note = re.findall(r'<seg type="([^"]+)">[^<]*</seg>\s*<note\b', raw)
                ketiv = "x-ketiv" in raw or 'type="variant"' in raw
                in_note_chars = Counter()
                for note in v:
                    if local(note.tag) != "note" or note.get("type") != "alternative":
                        continue
                    for sub in note.iter():
                        for ch in (sub.text or ""):
                            if ch in "־׀׃":
                                in_note_chars[(local(sub.tag), unicodedata.name(ch))] += 1
                out.append(
                    f"{vid}: w={len(ws)} notes={sum(1 for k in kinds if k.startswith('note:'))} "
                    f"last_non_note={ends[-1]} last_child={last_child} "
                    f"sof_pasuq_segs={segs.count('x-sof-pasuq')} "
                    f"last_w_has_n={last_w.get('n') is not None} last_w_accent={has_accent(last_w.text or '')} "
                    f"any_w_n={any_n} note_then_w={note_then_w} seg_then_note={seg_note} "
                    f"ketiv_or_variant={ketiv} max_notes_run={max_run(kinds)} "
                    f"max_rdg_per_note={max([int(k.rsplit('rdg',1)[1]) for k in kinds if k.startswith('note:')] or [0])}"
                )
                out.append("   kinds: " + " ".join(kinds))
                if in_note_chars:
                    out.append("   chars in alternative notes: " + repr(dict(in_note_chars)))
        out.append("   seg counts (direct children of verse): " + repr(sorted(book_seg_counts.items())))
        out.append("   note counts (direct children of verse): " + repr(sorted(book_note_counts.items(), key=str)))
    Path(sys.argv[3]).write_text("\n".join(out) + "\n", encoding="utf-8")


def max_run(kinds):
    best = run = 0
    for k in kinds:
        if k.startswith("note:alternative"):
            run += 1
            best = max(best, run)
        else:
            run = 0
    return best


main()

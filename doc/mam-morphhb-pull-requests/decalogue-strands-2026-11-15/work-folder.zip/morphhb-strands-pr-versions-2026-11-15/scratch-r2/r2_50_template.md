Claude's work (sub-agent R2, Opus 5.5, 2026-11-15), not reviewed by a human. Read-only research: nothing was posted, pushed, committed or fetched.

# How morphhb's readers would take labelled alternates in the 24 divided verses

**Disposition of every finding: evidence for the encoding of the strands pull request; no action taken.** Corrections to folder S's reports are listed under "Corrections", not made there.

Terms. A **span** is one atom (one `<w>`) with the punctuation that follows it before the next atom. The **marks** below are the maqaf (U+05BE), the paseq character (U+05C0, a narrow-sense paseq or the mark of a legarmeh) and the sof pasuq (U+05C3), each a `<seg>` of type `x-maqqef`, `x-paseq` or `x-sof-pasuq` in the main text. **Build-A** is the main session's trial build in `W/out/build-A/`, read during this run; its `n` codes had not yet been worked out again.

## Answers in brief

1. **Labels: use `note@subType`, with `x-` values.** morphhb's two apps and every other reader ignore it, except three strict readers: BibleOrgSys logs a load error for each such note and stops under strict checking; chirho and Adigun refuse any note attribute they do not know. chirho and Adigun are pinned to `3d15126`, so neither sees the change until it moves its pin. Every other place for a label does more harm (section 1).
2. **Several alternates: one note per alternate, each with one `<rdg>` and its own `subType`.** The apps show every note but only the first `<rdg>` of a note; chirho accepts several notes but refuses several `<rdg>`; and a reading inside a shared note can be labelled only by an attribute on `<rdg>`, which OET, Adigun and chirho refuse and BibleOrgSys logs as an error. With several notes, nabu keeps only the last. OET's limit of fewer than 100 children per verse is far off: build-A's largest of the 24 verses has 42.
3. **A note after a trailing seg is harmless.** No reader attaches it to the seg: the readers that attach notes attach them to the last `<w>`, and the apps' accent keys are unchanged. Elsewhere only a footnote's or a row's place relative to the mark changes, and dosfilosPreach keeps marks that it drops today. Marks inside a catchWord or reading are harmless too: maqaf, paseq and spaces already occur there on master, and only the sof pasuq would be new. chirho alone refuses a catchWord that differs from its `<w>`, and only in Genesis, where no such catchWord is needed.
4. **Verse ends.** morphhb's structure app draws a verse that ends without a sof pasuq. It throws, after clearing its display, only when the last `<w>` has no `n` while an earlier one has. A last atom with no accent is named "error||disjunctive" in the structure app and "None" in the read app. Elsewhere, four readers depend on a verse ending in a silluq or a sof pasuq: the Teamim Analyzer, verbum, metaxia's test and morphhb-parsing (section 4).

## Sources and method

- **morphhb's apps and converters** are read at `d4265dfa`, from `.novc/morphhb-qadma-2026-11-13/fetched/`. Folder S's `out/20-history-and-code.md` reports that hb.openscriptures.org loads the same app blobs. The validator is read at `db6c5c9b`, from the pashta folder.
- **Other readers** are read from folder S's `fetched/r-*` at the commits that `out/21-known-readers.md` gives.
- **Line numbers** are those the Read tool shows.
- **Hash check.** `W/scripts/r2_verify.py` checked every cited file against its Git blob SHA-1: 39 files, no mismatch (`W/scratch-r2/r2_verify.txt`).
- **Sub-agent R2a**, started by R2, read the 17 main-text readers. Its helper files are `W/scratch-r2/r2a_*`. R2 re-read the lines behind R2a's behaviour changes and pin corrections: dosfilosPreach, verbum, metaxia's test, gifos and the pins.
- **Counts** come from `W/scripts/r2_child_counts.py` and `W/scripts/r2_verse_ends.py`. Their outputs are in `W/scratch-r2/`.

## Readers and options

<div align="center">

| Reader (commit) | `note@subType` | Two or three notes after a span | Several `<rdg>` in one note | Note after a maqaf, paseq or sof pasuq seg | Marks in catchWord or reading |
| :-- | :-- | :-- | :-- | :-- | :-- |
| morphhb read app, `read/Script/ElementMarkup.js` (`d4265dfa`) | Ignored. A note is an asterisk whose tooltip is its first reading (216–225); no label is shown | An asterisk per note, each with its own reading (213–228) | First reading only (224) | Asterisk drawn after the mark. The note branch touches neither `setLine` nor the word data, so the accent key (89, 202–212) is unchanged (213–228) | catchWord never read; reading shown verbatim in the tooltip (224) |
| morphhb structure app, `structure/OshbVerse/Script/ElementMarkup.js` (`d4265dfa`) | Ignored (148–150) | An asterisk per note (138–153) | First reading only (149) | Asterisk after the mark, in the preceding atom's line, which ends only at the next `<w>` (113–119); key unchanged (127–137, 138–153) | As the read app (149) |
| morphhb's converters and validator | Unchanged. They read only `<w>`: `morphhbXML-to-JSON.pl` 79, `morphhbXML-to-JSON.py` 76, `oxlos-import/ConvertWLC.py` 77, `validate_data.py` 114–139. `oxlos-import/export.html` uses only variant notes (136–149) | Unchanged (same lines) | Unchanged (same lines) | Unchanged: `export.html` appends a seg to the previous entry (130–133) | Unchanged (same lines) |
| arvicco/nabu, `oshb_osis_parser.rb` (`049c87d9`) | Ignored: a note is dispatched on `type` alone (165–169), so the label is lost | Each replaces the one before: only the last note's reading survives (185–191) | First reading only (186) | Attached to the last `<w>`, since only `<w>` makes a token (121–123, 187); verse text unchanged (124, 132–136) | Kept in the token's `alternative`, whitespace stripped (186) |
| schierlm/BibleMultiConverter, `OSHB.java` (`f6a0647b`) | Ignored: a note becomes a footnote of its whole text (77–79) | A footnote per note (77–79) | catchWord and all readings run together in one footnote (78) | Footnote follows the mark instead of preceding it; a space precedes every element (71–79) | Kept in the footnote (78) |
| bibledit/cloud, `sources/morphhb.cpp` (`27fdbaf9`) | Ignored (139–153) | Each note adds a space, an empty entry and a "/" per child of its reading (126, 139–153) | A "/" per child of each reading (144–148) | Its "/" falls after the mark (124–159) | Not stored: no catchWord or reading text is read (142–148) |
| Freely-Given-org BibleOrgSys, `OSISXMLBible.py` (`a9342af5`) | **Load error "2s4d" for every such note; an assertion stops the load under strict checking** (958–968). The footnote is still made (1018–1024) | A footnote per note (1018–1024, 1338) | Each reading's text is appended to the one footnote (901, 1283–1285) | Footnote appended after the seg's text (714–715, 1338–1341) | No character check (901, 1270–1272) |
| BibleOrgSys, `SwordResources.py` (`a9342af5`), on SWORD module text | Unchanged: today's notes take the same path. A note with `swordFootnote` that is not a cross-reference asserts (737–745); other notes become footnotes (749–756) | Unchanged (same lines) | Unchanged; an x-accent `<rdg>` is not converted (797–802) | Unchanged | Unchanged |
| Freely-Given-org OET, `convert_OSHB_XML_to_TSV.py` (`9151ac74`) | Ignored. An alternative note's own attributes are not checked (216–217, 226–269); other note types' are (270–273) | A row per note, keyed to the verse, not the word (212–214, 278–281). A verse must have fewer than 100 children (139–140) | One row, with "(x-accent)" before each reading (236–259) | The note's row follows the seg's row (202–210, 278–281) | No character check, but no leading, trailing or double space (268, 305); an empty catchWord fails (235) |
| STEPBible/step, `default.xsl` (`77ba516a`), from a SWORD module | Ignored; the styling keys on `rdg@type` (858–861, 1994–2000) | A marker per note, with a comma between adjacent notes (717–755) | Each reading its own paragraph in the one note (1994–2000) | Marker after the mark (717–779) | Shown verbatim (1994–2000) |
| loveJesus chirho, `oshb_book_chirho.py` (`f71e10c1`; Genesis only; pins `3d15126`) | **Raises:** an alternative note's attributes must be exactly `type` (372, 382–385) | Accepted; each catchWord is checked against the last `<w>` (203–237, 372–375) | **Raises:** the children must be exactly catchWord and rdg (212–215) | Accepted; attached to the last `<w>`, with the seg's kind as anchor (217, 335) | **A catchWord with a mark added raises**, since it must equal the `<w>`'s text (221); a reading with one is accepted (222–225) |
| HephzibahBehulahHQ Adigun-AiBible (`d5acacba`; archive pinned by SHA-256) | **Raises** at import (`import-oshb.py` 46, 102–104, 107–108) and at load (`model.ts` 57, 72–75) | All kept and listed (`HebrewStudyWorkspace.tsx` 31–32, 160–161) | Allowed (`import-oshb.py` 42); each shown (`HebrewStudyWorkspace.tsx` 23–25) | Allowed (`import-oshb.py` 41); notes are listed apart from the text (`model.ts` 104–105) | Kept (`import-oshb.py` 87–95) |
| solforged/classics-reader, `oshb.ts` (`a3a53bb6`) | Unchanged: it throws on a note that is neither a variant nor numbered (93–95), so it cannot read these chapters under any option, as today | Unchanged | Unchanged | Unchanged | Unchanged |
| pnathan/translations, `oshb.go` (`105d3fc3`) | Unchanged: a note is kept only if it has `n` (111–117) | Unchanged | Unchanged | Unchanged: a seg sets a flag on the last `<w>` (118–126) | Unchanged |
| kungsik Teamim Analyzer, `index.php` (`0fc7bec8`) | Not reached: it reads a database, not the XML (68–74) | Not reached | Not reached | Not reached | Not reached |
| curran-gehring, `build_stress_lexicon.py` (`d16da0ff`) | Unchanged: a regex reads `<w>` only (49, 97–103) | Unchanged | Unchanged | Unchanged | Unchanged |
| openscriptures/morphhb-parsing, `correctMainTables.js` (`65dfd513`) | Unchanged: alternative notes are ignored whatever their attributes (143–163) | Unchanged | Unchanged | Unchanged: a seg sets the previous `<w>`'s `append` (130–140), and a note does not move the word index | Unchanged |
| 17 main-text readers (R2a; notes 3 and 4) | Unchanged; meforash keeps the attribute as data | Unchanged, except that ReneNyffenegger's `order_` numbers shift and meforash records more notes | Unchanged; meforash counts the extra readings | Unchanged, except that dosfilosPreach keeps marks that it drops today | Unchanged: no note text reaches their main text |

</div>

### Notes to the table

1. **Pins.** chirho, Adigun, lectio, metaxia, meforash and haftarah pin `3d15126`, and kitcosby reads a local copy at `3d15126`. None of them sees a change until it moves its pin, and meforash also checks each input's hash.
2. **An empty reading** would make both apps throw while marking up its verse (read 224, structure 149: `firstChild` is null). The read app would then show nothing of that chapter. No option needs one.
3. **The 17 main-text readers**, with their files in folder S's `fetched/`:
   - metaxiamultimedia (`r-metaxia-import-ts`), riolly, nyabongo/lectio, DLangellotti/targum, gringoboggy, browserbible-3, rowant-labs/meforash, ReneNyffenegger, DavidKGBR/verbum, jclements3/debar, dosfilosPreach, nwcnwc/gifos and Parsha-Explorer's `data.py`;
   - bible-mindmap, kitcosby and RavBogard/haftarah;
   - BibleFarm's `module_WLC_4_20_20_20.php`, a static snapshot with no reader code.

   R2a's report, with a file and line for each finding, is `W/out/50-r2a-main-text-readers.md`. These readers drop notes by tag, by `note@type` or by `rdg@type`; meforash keeps them in separate records (`hebrew.py` 67–75, 126, 162–170, per R2a).
4. **Behaviour changes and latent dependencies among the main-text readers:**
   - **dosfilosPreach** moves a mark into the preceding `<w>` only when nothing but whitespace separates them (`morphhb-bible-provider.ts` 59–67). Today's placement of a note between `</w>` and the seg makes it drop the mark. Placing the note after the seg restores it.
   - **Build-A** still puts a note before a shared maqaf in Exodus 20:9 and Deuteronomy 5:13, so dosfilosPreach drops those two maqafs.
   - **gifos** emits a ketiv instead of its qere when exactly one x-accent reading precedes the qere in its verse (`build-interlinear.mjs` 485–492). Deuteronomy 5:10, the only one of the 24 verses with a qere, has three on master and in build-A.
   - **riolly** would split two atoms' group if a note stood between two `<w>` with nothing else between them (`oshb-xml.ts` 185, per R2a). No option puts one there.

## 1. Labels

**Recommendation: `note@subType`.** Use values matching OSIS's `x-([^\s])+` (`osisCore.2.1.1.xsd`, BibleOrgSys copy, 3000–3006; `subType` is in `<note>`'s attribute group, 1942 and 2898). Give the order of the notes in the description too, since no app shows the label.

**Reason.** `note@subType` is the one attribute that OSIS provides for this and that morphhb's apps ignore. Its harm falls only on readers that refuse any attribute they do not know:
- BibleOrgSys logs a load error and stops if strict;
- chirho and Adigun refuse it, both being pinned;
- meforash keeps it as data.

Every other place harms more:

<div align="center">

| Label place | Effect |
| :-- | :-- |
| `note@resp` | Like `subType`, except that BibleOrgSys accepts it silently (`OSISXMLBible.py` 964). But morphhb uses `resp` for a person's initials, `<revisionDesc resp="dt">` (master `Exod.xml` line 5), and the labels are kinds of reading, not people |
| `note@n` | The apps show the label as the note's mark and lose the reading (read 214–215, structure 139–140). chirho refuses it (382–385). BibleOrgSys makes it the footnote's caller (960, 1023), and OET writes it in its CantillationHierarchy column (216, 279) |
| A new `note@type` | The apps show nothing for a type that is neither variant nor alternative (read 216–225). OET asserts (270–273). nabu files it as a plain note (169–172). chirho, Adigun and solforged refuse it |
| Any attribute on `<rdg>` or `<catchWord>` (`subType`, `n`, `resp`, OSIS's `rdg@witness`) | OET asserts (232–233, 237–241). BibleOrgSys logs a load error (896–899, 1246) and, for `<rdg>`, stops if strict (899). Adigun (47, 102–104) and chirho (219, 222) raise |
| A new `rdg@type`, such as `x-accent-…` | STEP loses its accent styling (858–861, 1994–2000). BibleOrgSys stops if strict (895). chirho (222) and Adigun (105–106) raise |
| A text prefix in the reading | The reading stops being a form. Every reader that keeps the reading keeps the prefix with it: nabu's `alternative` (190), chirho's note text (234), BMC's and BibleOrgSys's footnotes, OET's row and STEP's Hebrew span. Latin and Hebrew then share one run of text. Only the apps' tooltip would use it well |
| A labelling element inside the note, such as a `<seg>` | BibleOrgSys asserts on an unknown seg type even without strict checking (`OSISXMLBible.py` 703–709). OET asserts (260). chirho (212–215) and Adigun (`import-oshb.py` 42, 100–101) raise |
| Order alone | Harms no reader. But the kinds cannot be told apart, because the MAM-informed alternates are optional: in build-A's Exodus 20:3 the second note is a MAM-informed @@TAXTON@@ at atom 2 and a MAM-informed @@ELYON@@ at atom 7 |

</div>

## 2. Several alternates for one span

**Recommendation: two or three notes in a row, each with one `<rdg>` and its own `subType`, in one fixed order.**

**Reason.** Several notes keep every alternate visible in the apps, which show only a note's first `<rdg>`. They give each alternate a label in a harmless place, whereas readings inside one note can be labelled only on `<rdg>` (section 1). And chirho accepts several notes but refuses several readings.

**What each reader does with several notes:**
- nabu keeps only the last, so the order chosen decides which alternate nabu keeps.
- BibleMultiConverter, BibleOrgSys, STEP and OET make one footnote, marker or row per note. Bibledit adds a "/" per note.
- OET's limit (fewer than 100 children per verse) is far off. On master the 24 verses' largest is 43 (Deuteronomy 5:15) and in build-A 42. No span in build-A has more than two notes. Even three notes after every atom would give at most 109 children (Deuteronomy 5:14), the only verse over the limit (`W/scratch-r2/r2_child_counts.txt`).

## 3. A note after a trailing seg, and marks in catchWords and readings

**Recommendation.** Where the main version's span ends in a mark, put that span's notes after the seg, with the catchWord quoting the main span, mark included, as build-A does. Write a mark inside a catchWord or reading as today's readings write a paseq, joined to the atom with no space (three readings in master's Exodus 20:4).

**Reasons:**
- **No reader attaches a note to a seg.** nabu, chirho and meforash attach it to the last `<w>`. Adigun lists notes apart from the text. The apps' accent key, built from a disjunctive atom's accents and the marks after it, is untouched by a note anywhere among those marks.
- **Elsewhere only positions change:**
  - BMC's footnote, Bibledit's "/" and BibleOrgSys's and STEP's markers come after the mark rather than before it;
  - OET's note row follows the seg's row;
  - in the apps, a note after a maqaf shows its asterisk between the maqaf and the next atom.
- **dosfilosPreach gains**, as note 4 says.
- **Marks in text are not new.** On master, 12 lines hold a catchWord or x-accent reading that contains a maqaf, a paseq or a space: 4 in Exodus and 8 in Deuteronomy, found by Grep over `W/fetched/master-db6c5c9b/`. No catchWord or reading contains a sof pasuq, in master or in the `pashta-helpers` base.
- **Constraints:**
  - chirho requires each catchWord to equal its `<w>`'s text (221). Only Genesis 35:22 matters to chirho, and none of its spans' main versions ends in a mark (`W/out/60-versions.txt`), so its catchWords stay plain.
  - OET forbids leading, trailing and double spaces in catchWord and reading (268, 305) and an empty catchWord (235).
  - No reading may be empty (note 2).

## 4. Verse ends

**What morphhb's structure app does.** It cuts a verse into lines, each ending before the `<w>` that follows a `<w>` with `n`, and codes each line with that `n`. The last line takes the last `<w>`'s `n`, or `false` when it has none, unless a qere `<w>` with `n` follows it, as at Deuteronomy 5:10 (`ElementMarkup.js` 74–103, 113–126, 145–147, 157–158). Both layouts then group the lines by `code.charAt(2 × level)` (`VerseMarkupHorizontal.js` 31–80, `VerseMarkupVertical.js` 22–69). So:

1. **No sof pasuq, last `<w>` with `n`: drawn.** The last atom's key is its accents alone, because only a mark after a `<w>` with `n` is added (127–137). In build-A the eight verses end in an atnaḥ (Exodus 20:2 and 20:14, Deuteronomy 5:6 and 5:18), a tipeḥa (Exodus 20:13) or a zaqef qatan (Exodus 20:15, Deuteronomy 5:19), all named correctly (`AccentCatalog.js` 13, 20, 24 in both apps). Deuteronomy 5:17's last atom has no accent (`W/scratch-r2/r2_verse_ends.txt`).
2. **A last atom with no accent, or whose only mark is U+05BD without a sof pasuq, gets the empty key.** The structure app names it "error||disjunctive", because its prose disjunctive table has no empty key (structure `AccentCatalog.js` 9–54; `AccentInterpretation.js` 30). The read app says "None" (read `AccentCatalog.js` 54). Both apps treat a verse's last atom as disjunctive whatever its `n` (structure 157, read 232).
3. **Last `<w>` without `n` while an earlier `<w>` has `n`: the structure app throws.** `false.charAt` is reached in both layouts whenever there are two lines or more (horizontal 40–42 and 67–70, vertical 30–32 and 56–59). It happens after `Structure.js` 116 has cleared the display, so nothing is drawn and the link is not updated (117–124). The read app does not throw.
4. **No `<w>` with `n` at all: drawn as one block**, since a single line needs no `charAt` (horizontal 33–38 and 61–65, vertical 24–28 and 51–54).
5. **Two lines with the same code recurse without end**, in either layout, because no level separates them (horizontal 40–56 and 67–78). Re-derived codes must therefore differ within a verse.

**Deuteronomy 5:17.** Build-A still has the old codes: `0.0` on its merkha atom and `0` on its unaccented last atom. If codes go only on disjunctive atoms, neither atom has one, and the verse is drawn (case 4). If the first atom keeps a code and the last loses it, the structure app throws (case 3).

**Other readers that depend on a verse-final sof pasuq:**
- **Teamim Analyzer** labels every verse's last atom silluq (`index.php` 92). If its database is rebuilt from the new XML, the eight verses get a false silluq.
- **verbum** glues every seg, pe and samekh included, to the previous part (`morphhb_extractor.py` 235–242). With no sof pasuq before it, the samekh letter fuses onto the last atom: build-A's Exodus 20:13–15 and Deuteronomy 5:17–19 (R2a; R2 re-read the lines).
- **metaxia**'s test pins corpus-wide seg counts (`import.test.ts` 924–931). It fails once metaxia moves its pin: build-A has 8 fewer sof pasuqs, 2 fewer maqafs and 1 fewer paseq (R2a; the 11 fewer segs agree with `r2_child_counts.txt`).
- **morphhb-parsing**'s `correctMainTables.js` sets a word's `append` only when it meets a seg after it (130–140). On a rerun, a seg removed from the main text leaves its old `append` in the database: the eight verse-final sof pasuqs, and any maqaf or paseq removed.

No reader in scope splits or counts verses by sof pasuq (folder S's 21 report, note 1), and none needs `n="0"` at a verse end.

## Corrections

The corrections below are recorded here only; folder S's reports are unchanged.

1. **`out/20-history-and-code.md`, answer 3.** "Nothing reads … `subType`" holds for morphhb's own code only. BibleOrgSys logs `note@subType` as an unprocessed attribute (958–968), and chirho (372) and Adigun (`import-oshb.py` 46) refuse it.
2. **`out/21-known-readers.md`, note 10.** Pins of `3d15126` also include metaxia (`import.ts` 22), meforash (`hebrew.py` 26, with hash checks, 249–277 per R2a), kitcosby (`build_variants_kq.py` 31) and Adigun's `model.ts` (2).
3. **`out/21-known-readers.md`, note 5.** RavBogard/haftarah's book table includes the Torah (`words.mjs` 34–37), so "prophets only" is not shown by the code.
4. **`out/21-known-readers.md`, table.** For morphhb-parsing, "database updated on a rerun" omits the stale `append` described in section 4.

## Limits

- **Not read:** SWORD's `osis2mod` and C++ render filters, which Xiphos and other SWORD front-ends use, and JSword. Xiphos's release notes list only a closed request to italicise catchWord and rdg in OSIS footnotes.
- **Not fetched:**
  - BibleOrgSys's `BibleBook.appendToLastLine`, so the separator between two readings in one footnote is unknown;
  - OET's later use of row order;
  - the Teamim Analyzer's database builder;
  - BibleFarm's generator.
- **Not run:** the apps were read, not run in a browser.
- **Build-A** is a draft, and its `n` codes are not yet worked out again.

## Files

- `W/scripts/r2_verify.py`: hash check of the cited files.
- `W/scripts/r2_child_counts.py`: children per verse, master and build-A.
- `W/scripts/r2_verse_ends.py`: how each verse ends, without printing Hebrew.
- `W/scripts/r2_make_report.py`: writes this file from `W/scratch-r2/r2_50_template.md`, copying the strand names from the brief by script.
- `W/out/50-r2a-main-text-readers.md`: sub-agent R2a's report on the 17 main-text readers, as R2a delivered it.
- Script outputs and R2a's helper files: `W/scratch-r2/`.

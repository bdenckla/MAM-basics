"""R2a helper: re-implement two regex readers' verse handling and run it on two builds.

Re-implements (does not execute) the verse logic of:
  dosfilos  morphhb-bible-provider.ts lines 59-67, 79-84, 95-134
  gifos     build-interlinear.mjs lines 483-502
and, as a control, the same logic on the build with every alternative note removed.

Usage: r2a_emulate.py <dir-A> <dir-B> <out.txt>
"""

import re
import sys
from pathlib import Path

VERSES = (
    ["Gen.35.22"]
    + [f"Exod.20.{v}" for v in (2, 3, 4, 5, 6, 8, 9, 10, 13, 14, 15)]
    + [f"Deut.5.{v}" for v in (6, 7, 8, 9, 10, 12, 13, 14, 15, 17, 18, 19)]
)
MAQAF, PASEQ, SOF = "\N{HEBREW PUNCTUATION MAQAF}", "\N{HEBREW PUNCTUATION PASEQ}", "\N{HEBREW PUNCTUATION SOF PASUQ}"


def verse_body(text, vid):
    m = re.search(r'<verse\s+osisID="%s">([\s\S]*?)</verse>' % re.escape(vid), text)
    return m.group(1)


def strip_alt_notes(body):
    return re.sub(r'<note type="alternative"[^>]*>[\s\S]*?</note>', "", body)


def dosfilos(body):
    body = re.sub(
        r'<w\b[^>]*type="x-ketiv"[^>]*>[\s\S]*?</w>(?=\s*<note\b[^>]*>(?:(?!</note>)[\s\S])*?<rdg\s+type="x-qere">\s*<w\b)',
        "",
        body,
    )
    body = re.sub(r'</w>(\s*)<seg\s+type="x-maqqef">[^<]*</seg>', MAQAF + r"</w>\1", body)
    body = re.sub(r'</w>(\s*)<seg\s+type="x-paseq">[^<]*</seg>', PASEQ + r"</w>\1", body)
    body = re.sub(r'</w>(\s*)<seg\s+type="x-sof-pasuq">[^<]*</seg>', SOF + r"</w>\1", body)
    words = []
    for m in re.finditer(r"<w\s+([^>]*)>([\s\S]*?)</w>", body):
        t = re.sub(r"<[^>]+>", "", m.group(2)).replace("/", "")
        t = re.sub(r"\s+", " ", t).strip()
        if t:
            words.append(t)
    out = ""
    for i, w in enumerate(words):
        if i == 0:
            out = w
        else:
            out += ("" if words[i - 1].endswith(MAQAF) else " ") + w
    return out


def gifos(body):
    words = []
    in_note = in_qere = 0
    pending = None
    tok = re.compile(r'<note\b[^>]*>|</note>|<rdg type="x-qere">|</rdg>|<w\b([^>]*)>([\s\S]*?)</w>')
    for t in tok.finditer(body):
        s = t.group(0)
        if s.startswith("<note"):
            in_note += 1
            continue
        if s == "</note>":
            in_note -= 1
            if in_note <= 0 and pending:
                words.append(pending)
                pending = None
            continue
        if s == '<rdg type="x-qere">':
            in_qere += 1
            continue
        if s == "</rdg>":
            in_qere -= 1
            continue
        if in_note and not in_qere:
            continue
        attrs = t.group(1) or ""
        surface = (t.group(2) or "").strip()
        w = {"surface": surface}
        if re.search(r'type="x-ketiv"', attrs):
            pending = w
            continue
        if in_qere and pending:
            w["ketiv"] = pending["surface"]
            pending = None
        words.append(w)
    if pending:
        words.append(pending)
    return words


def main():
    dirs = [Path(sys.argv[1]), Path(sys.argv[2])]
    lines = []
    for d in dirs:
        lines.append("=" * 20 + f" {d}")
        totals = {"main_sof": 0, "dos_sof": 0, "main_maq": 0, "dos_maq": 0, "main_pas": 0, "dos_pas": 0}
        for vid in VERSES:
            book = vid.split(".")[0]
            text = (d / f"{book}.xml").read_text(encoding="utf-8")
            body = verse_body(text, vid)
            bare = strip_alt_notes(body)
            dos, dos_bare = dosfilos(body), dosfilos(bare)
            gif, gif_bare = gifos(body), gifos(bare)
            main_sof = len(re.findall(r'<seg type="x-sof-pasuq">', bare))
            main_maq = len(re.findall(r'<seg type="x-maqqef">', bare))
            main_pas = len(re.findall(r'<seg type="x-paseq">', bare))
            totals["main_sof"] += main_sof
            totals["main_maq"] += main_maq
            totals["main_pas"] += main_pas
            totals["dos_sof"] += dos.count(SOF)
            totals["dos_maq"] += dos.count(MAQAF)
            totals["dos_pas"] += dos.count(PASEQ)
            lines.append(
                f"{vid}: dosfilos same_as_notes_stripped={dos == dos_bare} "
                f"sof {dos.count(SOF)}/{main_sof} maqaf {dos.count(MAQAF)}/{main_maq} paseq {dos.count(PASEQ)}/{main_pas}; "
                f"gifos same_as_notes_stripped={gif == gif_bare} words={len(gif)} "
                f"qere_kept={[w.get('ketiv') is not None for w in gif if 'ketiv' in w] or '-'}"
            )
        lines.append("   totals (dosfilos shown / main-text segs): " + repr(totals))
    Path(sys.argv[3]).write_text("\n".join(lines) + "\n", encoding="utf-8")


main()

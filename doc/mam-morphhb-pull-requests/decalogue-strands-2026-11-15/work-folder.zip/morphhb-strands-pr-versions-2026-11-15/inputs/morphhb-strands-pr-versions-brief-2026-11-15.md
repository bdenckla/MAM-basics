# Brief: prepare the morphhb strands pull request with up to four versions of every span

Written by Claude (Opus 5.5) on 2026-11-15 at about 13:20 New York time, in the session that the
commander session "Commander for Claude's forests" (`local_a80ded65-f78e-4280-8493-9dab3b8c5686`)
started from `C:/Users/BenDe/GitRepos/MAM-basics/.novc/commander-session/morphhb-strands-pr-brief-2026-11-14.md`.
That session's work folder, called **folder S** below, is
`C:/Users/BenDe/GitRepos/MAM-basics/.novc/morphhb-strands-pr-2026-11-14/`; its decision page is
https://claude.ai/artifact/VL9cSsoTs414X7LoJpD9Lg.

Ben typed the following in that session on 2026-11-15, shortly before 13:15 New York time,
exactly:

> As the commander for a fresh session that will prose something like 1A, 2A, 3-not-in-this-PR, 4A, but:
>
> provide up to 4 versions of very span, i.e. one main version with up to 3 alternates. (A span is, roughly (let me know if this definition works) a word or phrase, with possible trailing punctuation like maqaf, sof pasuq, or legarmeh):
>
> CLC taxton is primary, then at a minimum CLC elyon, and possibly MAM-informed taxton and/or MAM-informed elyon.
>
> Provide MAM-informed versions if CLC versions are illegal (e.g. have no accent). Such illegality is usually (maybe always?) noted in a note in CLC.
>
> Regarding what MAM-informed means:
>
> Just use MAM to make the words legal and reflecting the cantillation of MAM; don't pick up other MAM features such as stress helpers, qamats qatan, inclusion of xolam on YHVH, etc. In other words just use MAM to correct WLC, not really literally using MAM
>
> Another case of MAM-informed is leave that one sheva under xet alone (unlike what morphhb surprisingly does today, namely, converting it to xataf patax). That one case of changing sheva under xet to xataf patax is kind of insane to me, i.e. surprising that morphhb did it: it is not unprecedent in WLC (and presumably not fixed by morphhb in all those other cases) and is nowhere near as problematic/illegal as all the other crazy stuff in Leningrad's decalogues. My assumption would be that this is an "accidental repair" that came along with more substantive stuff, maybe with more substantive stuff in that very same word (investigate (that investigation shouldn't be hard)).
>
> Also I believe in one case you mentioned a meteg difference in MAM. I would like to see that case noted in the plan/decision document/README but as meteg never makes something legal or illegal, i.e. is always optional, it goes beyond MAM-informed to supply such a meteg. I wonder where MAM got that meteg from though, since in the Decalogues MAM is highly dependent on Leningrad. Perhaps from one of the Sassoon manuscripts and/or other manuscripts?

Claude reads "As the commander" as "Ask the commander", "prose" as "propose", and "very span"
as "every span". Ben's earlier words, which folder S's decision page also quotes, are his request
of 2026-11-14 at 21:03 New York time, "ask the commander to start a new session that will propose
a pull request that will rationalize the handling of the decalogues and the reuben verse (Gen
35:22) in morphhb", and, at 14:34 that day, "morphhb doesn't have the combined, and indeed
switches back and forth as to whether its main text is taxton or elyon ... If so, what a complete
mess!"

Everything after the quotations is Claude's reconstruction, not Ben's words.

## The task

Prepare, and do not post, a pull request to openscriptures/morphhb, with its description, that
gives `wlc/`'s 24 divided verses the scheme below. These are the 23 Decalogue verses in BHS's
numbering (Exodus 20:2–6, 8–10 and 13–15; Deuteronomy 5:6–10, 12–15 and 17–19) and
Genesis 35:22.

1. **Decision page first.** Begin by putting on your own decision page every point below that is
   marked "to confirm", and every policy question your research raises. Each question says what
   raises it, what each choice does, and a recommendation with its reason. Do not ask through the
   multiple-choice dialog or the next-step box.
2. **Then build and check.** Build the change by script, check it, write the description, and put
   both on the page for Ben's approval.
3. **Posting** is outward-facing and waits for Ben's own go in your session, such as his "post
   it", after he has read the final change and description. A go relayed from another session is
   not one.

## What Ben decided, as Claude reads his message

Folder S's decision page asked four questions. Ben's answers:

1. **The main text:** 1A, as he modified it. In the Decalogues the main text is the תחתון
   throughout, and the עליון is in alternates. At Genesis 35:22 the main text stays the מדרשית,
   with the פשוטה in alternates, as 1A has it (to confirm, since Ben's message names only the
   Decalogue strands). His modification is the versions below.
2. **Marks:** 2A, as carried by the versions below.
   - The main text takes from MAM only what CLC's division itself supplies, a maqaf or a sof
     pasuq.
   - Every other mark that a strand needs and WLC 4.20 lacks goes into a MAM-informed alternate.
   - Exodus 20:5's ḥataf pataḥ goes back to WLC's sheva (see "Exodus 20:5's sheva").
3. **`MAPM/`:** not in this pull request.
4. **The branch:** 4A. Start the branch from Ben's fork's `pashta-helpers` (openscriptures/morphhb#118,
   one commit `696e21ce` on `db6c5c9b`). The description says that the pull request builds on
   #118 and should be merged after it.

## The scheme

### Spans (to confirm)

Ben asked whether his definition works. Folder S's answer, to put to him on your page, is that it
works if a span is **one atom together with the punctuation that follows it before the next
atom**: a maqaf, a paseq or legarmeh, or a sof pasuq. An atom is a written form between spaces or
maqaf marks; each of morphhb's `<w>` elements is one. A span's versions may differ in that
trailing punctuation.

A difference in maqaf grouping is then a difference in one atom's trailing maqaf, so no span
needs to be a phrase. For example, Exodus 20:3's first atom ends in a maqaf in the תחתון and does
not in the עליון, and its second atom is the reverse.

### The versions of a span, in order

1. **Main: CLC's תחתון.** To confirm: this means CLC's rules applied to WLC 4.20's text, since
   `wlc/` is WLC 4.20, and not CLC's own strands, which divide UXLC 2.6.
   - These forms are already computed: folder S's `out/22-clc-answers.json`, field
     `alef.clc_rule_form`, with the maqaf and sof pasuq marks that CLC's rules supply
     (`alef.supplied`).
   - CLC's code itself cannot be run on WLC 4.20; `out/22-clc-answers.md` says why and how its
     rules were applied by script.
2. **CLC's עליון**, at every span where it differs from the main version (`bet.*`).
3. **MAM-informed תחתון**, only at a span where CLC's תחתון is illegal.
4. **MAM-informed עליון**, only at a span where CLC's עליון is illegal.

At Genesis 35:22, read מדרשית for תחתון in item 1 and פשוטה for עליון in item 2.

### What "MAM-informed" is

A MAM-informed version is CLC's version plus only the marks of MAM's strand that make the atom
legal and give it MAM's cantillation. In Ben's words, "just use MAM to correct WLC, not really
literally using MAM".

- Never take from MAM a stress helper, a qamats qatan, the ḥolam on the Tetragrammaton, or a
  meteg. Ben: "meteg never makes something legal or illegal, i.e. is always optional".
- Never take from MAM Exodus 20:5's ḥataf pataḥ.
- Name any other MAM feature you meet as a question on your page, rather than taking it.

### What "illegal" is (to confirm)

Ben's example is an atom with no accent, and he expects CLC to note such a case "usually (maybe
always?)".

**What CLC notes.** Folder S's `out/22-clc-answers.json` lists, per atom and strand, the marks that
CLC's rules supply (maqaf, sof pasuq) and those they only note (accents and vowels). For WLC
4.20, the noted marks are these:
- in the תחתון, a merkha at Exodus 20:3, atom 2, and a tipeḥa at Deuteronomy 5:17, atom 2;
- in the עליון or the מדרשית, a revia at Genesis 35:22, atom 7, a tipeḥa at Deuteronomy 5:6,
  atom 1, an atnaḥ at Deuteronomy 5:6, atom 3, a meteg at Deuteronomy 5:7, atom 2, and at
  Deuteronomy 5:8, atom 2, and a pataḥ at Deuteronomy 5:8, atom 12.

**What else may be illegal without a note:**
- the עליון's pataḥ under the yod at Exodus 20:3 and Deuteronomy 5:7, atom 7, which leaves the
  nun with no vowel;
- WLC 4.20's two accents on one atom, at Exodus 20:4, atom 13, and Deuteronomy 5:14, atom 4. CLC's
  rules keep both accents in both strands.
- WLC 4.20's merkha where MAM's תחתון has a qadma, at Deuteronomy 5:8, atom 2.

**How to decide.** Propose criteria and test each CLC version, where practical, with MAM-basics'
accent grammar (`py/accgram/`). Then report whether every illegal version is one that CLC notes,
and whether every note is an illegality: a noted meteg, at least, is not.

### Exodus 20:5's sheva

Restore WLC 4.20's sheva under the ḥet of Exodus 20:5, atom 2, in every version.

Folder S found the following on 2026-11-15, from folder D's
`out/22-history-departures.txt` and folder S's `scripts/show_atoms.py`:
- **The change came with the division of that very word.** `wlc/` had WLC's sheva, with both
  strands' accents on the word, in every saved version until `73784451` (David Troidl,
  2010-07-13, "Separated the accents of the Ten Commandments, to conform with the WLC
  versification."). That commit divided the word's two accents between the main text and a new
  alternative note, and wrote a ḥataf pataḥ in both.
- **The parallel word has the ḥataf pataḥ.** WLC 4.18, 4.20 and 4.22 and UXLC 2.6 all have the
  sheva at Exodus 20:5, and all have the ḥataf pataḥ in the same word at Deuteronomy 5:9. So the
  ḥataf pataḥ may have come from that parallel, though no file says so.
- **Still open:** WLC's other forms of this verb with a sheva under the ḥet, and whether morphhb
  leaves them as WLC has them, as Ben presumes.

### The meteg cases: note them, supply none

Note them on your decision page, in the plan and in the README:
1. Exodus 20:4, atom 2: WLC 4.20 has the meteg on the tav, and MAM's עליון has it on the shin.
2. Deuteronomy 5:7, atom 2: MAM's עליון has a meteg that WLC 4.20 lacks.
3. Deuteronomy 5:8, atom 2: likewise.

Ben asked where MAM got that meteg, "since in the Decalogues MAM is highly dependent on
Leningrad". Look in MAM's own documentation:
- MAM-with-doc's documentation notes on those words;
- the mirrored introduction, `in/mam-ws-intro/` (read its `README.md` first);
- the special pages, `in/mam-ws-special/`.

Attribute what you find to MAM's documentation. Claim nothing about a manuscript, a Sassoon one
included, without its image; the `verse-links` skill builds manuscript links.

### Encoding questions to settle with evidence (for your decision page)

Folder S's reports `out/20-history-and-code.md` (morphhb's own code) and `out/21-known-readers.md`
(code elsewhere) hold the evidence.

1. **Labels.** With up to three alternates of different kinds, each must say which version it is.
   - morphhb's two web apps read no attribute of `<rdg>` or `<catchWord>`. They show each note as
     an asterisk with the text of its first `<rdg>`, and a note with `n` loses its reading.
   - Elsewhere, a new attribute on `<rdg>` or `<catchWord>` stops OET's converter and two
     importers, a new `rdg@type` loses STEP's styling, and one importer refuses `note@n`.
   - OSIS 2.1.1 allows `subType` (`x-` values) on `<note>`, but `note@subType` was not checked
     against the readers elsewhere. Check it first.
2. **Several notes after one span:** nabu keeps only the last, and BibleMultiConverter makes a
   footnote of each. One note with several `<rdg>` elements shows only the first in morphhb's
   apps.
3. **A note covering a trailing seg** (maqaf, paseq or sof pasuq) must follow that seg, and no
   note in `wlc/` does so today. Check the readers.
4. **An illegal main text.** The main text is CLC's תחתון even where that is illegal, so an atom
   may have no accent or two.
   - **No accent:** the atom carries no `n` code. If it is a verse's last atom while another atom
     has `n`, morphhb's structure app throws ("Web apps" in `out/20-history-and-code.md`).
     Deuteronomy 5:17's last atom has no accent in CLC's תחתון, because its tipeḥa is noted, not
     written.
   - **Two accents:** the apps' popups say "error|…" at such an atom.
   - Put the options on the page.
5. **`n`.** Work the codes out again for the main text in the 8 verses whose main strand changes
   under 1A (Exodus 20:2 and 20:13–15, Deuteronomy 5:6 and 5:17–19), and check them in all 24.
   Say how an illegal atom is coded. Nothing in morphhb computes `n`; it is made by hand.

## Inputs

Read these and write nothing in their folders.

- **Folder S:** `README.md` (maps every file and records a correction to its own brief); the
  reports `out/20-…` to `out/23-…`; `out/22-clc-answers.json`; `out/30-scheme-census.*`;
  `out/31-pr118-in-divided-verses.txt`; `out/fragments/EXAMPLES.html` (Exodus 20:2–3 and
  Genesis 35:22 shown atom by atom); and its scripts (`gh_fetch.py`, `show_verse_xml.py`,
  `e_examples.py`, `c_clc_wlc.py` and others).
- **Folder D:** `C:/Users/BenDe/GitRepos/MAM-basics/.novc/morphhb-decalogue-2026-11-13/`, every atom
  of the 24 verses in WLC, UXLC, MAM and morphhb, and the history.
- **Folder F:** `.novc/morphhb-corrections-2026-11-13/`, morphhb's XML at `d4265dfa` under
  `fetched/`, and its commits and issues.
- **The pashta-helper folder:** `.novc/morphhb-pashta-pr-2026-11-14/`, whose `scripts/post_pr.py`
  posted #118 through `gh api`, one request at a time.
- **CLC's pages:** `gh-pages/clc/Exodus-20.html`, `Deuter-5.html` and `Genesis.html`, and
  `py/clc/clc_dual_cant.py`.
- **The record of Ben's pull requests:** MAM-basics' `doc/mam-morphhb-pull-requests.md`, item 5 in
  particular. It is in the primary clone's working tree at `374d9436`. It records a trap: syncing
  the fork through `gh api` fails without the `workflow` scope, and Ben synced it on GitHub's own
  page.

## Facts as of 2026-11-15 (reread, pinned, before relying on them)

- morphhb's master was `db6c5c9b` at 08:32 New York time; its `wlc/` equals `d4265dfa`'s.
- #118 was open and mergeable, with no comments or reviews. It changes 10 lines inside these
  verses.
- Ben's fork's master was at `db6c5c9b`, and its branches were `pashta-helpers` and `update-mapm`.
- The validator, `.github/scripts/validate_data.py`, checks and summarizes only `<w>` elements.
  Notes and segs are invisible to it.
- jag3773's openscriptures/morphhb#116 plans morphhb 2.3 after 2026-12-15. The new description
  should name it, so that GitHub links the pull request from #116's timeline.

## Placement, checks and integration

- **Source checkout:** `C:/Users/BenDe/GitRepos/MAM-basics`, at `374d9436` on `main` (2 behind
  origin) at 13:15 New York time. The inputs above are untracked and exist only in its `.novc/`.
- **Work folder:** a new one there, such as `.novc/morphhb-strands-pr-versions-2026-11-15/`, with a
  `README.md` that maps its files. The commander assigns the checkout for any tracked change.
- **morphhb** is outside MAM-basics' roster. Read it through `gh api`, pinned to a commit and
  logged, with no clone unless the commander arranges one.
- **Checks:** rebuild every version of every span from the new XML and compare it with the
  intended version, in MAM-normal mark order. Check the validator's rules, the apps' accent keys
  and `n`. Each changed file must differ from its base only in the 24 verses.
- **Integration:** nothing reaches openscriptures/morphhb before Ben's go. After posting, the
  commander arranges the record in `doc/mam-morphhb-pull-requests.md`. Decision 3 needs no
  MAM-basics change.

## Rules

1. Load `hebrew-prose`, with its `references/mam-basics.md`, before writing the description, a
   page or chat about accents or strands. Load `github-issues` before citing an issue or pull
   request, and `iterative-document-editing` for the plan.
2. Attribute every reading to morphhb, WLC 4.20, UXLC, CLC (MAM-basics' division of UXLC 2.6) or
   MAM. Claim nothing about the Leningrad Codex without consulting it.
3. Copy Hebrew by script, never retype it. Compare forms in MAM-normal mark order
   (`give_std_mark_order`). Never normalize morphhb's text.
4. Use PowerShell 7, scripts in files (never `python -c`), and no sed or awk. Python that reads a
   fetched file runs with `-I`. Python that imports MAM-basics modules runs with `-B`.
5. Read-only Git calls get `-c safe.directory=<the exact checkout path>`, with
   `GIT_TERMINAL_PROMPT=0`, `GCM_INTERACTIVE=never` and `GH_PROMPT_DISABLED=1`. Make no
   Git-impacting act in the source checkout, `git fetch` included.
6. No Claude auto memory, and no offer to file an issue. Times shown to Ben say "New York time".
7. Past about 30% of the context window, continue through sub-agents. Past about 70%, write a
   handoff in the shared notes folder and send it to the commander.

## Report

Begin with `# Report: <subject>`. Put first the decision page's link, the work folder and the
state: prepared, or posted with the pull request's URL. Then say what waits on Ben.

**Shared notes folder:**
`C:/Users/BenDe/AppData/Local/Claude-Data/claude_pzs8sxrjxfjjc/side-session-notes/local_a80ded65-f78e-4280-8493-9dab3b8c5686`.

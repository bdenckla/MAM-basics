# The morphhb strands pull request, with up to four versions of every span

State: paused 2026-11-16, on ice at Ben's request ("put this work "on ice": git-track it for
deep storage, perhaps never to return to it, but perhaps we will."). This folder is archived,
with a record, as MAM-basics' `doc/mam-morphhb-pull-requests/decalogue-strands-2026-11-15/`
(`work-folder.zip`, `change.diff`, `README.md`); `scripts/ice_pack.py` packed it and
`scripts/ice_verify.py` checked it. The state before that, at 15:11 New York time on 2026-11-15: all research has reported;
the draft is rebuilt with criterion (iv) and the computed `n` codes and checked; the description
and commit message are drafted; the decision page is republished as version 2 (state line of 15:09);
a dry run of `scripts/post_pr.py` passed its reads (bodies in `post-bodies-dry-1/`); decisions 1
to 14 are open; nothing is posted.

Written by Claude (Opus 5.5) on 2026-11-15, New York time, in the session that the commander
session "Commander for Claude's forests" (`local_a80ded65-f78e-4280-8493-9dab3b8c5686`) started
from the brief `morphhb-strands-pr-versions-brief-2026-11-15.md` in the shared notes folder
`C:/Users/BenDe/AppData/Local/Claude-Data/claude_pzs8sxrjxfjjc/side-session-notes/local_a80ded65-f78e-4280-8493-9dab3b8c5686/`.
Ben's words, typed at 13:12 New York time on 2026-11-15 in the session "morphhb pull request:
Decalogue and Genesis 35:22 strands", are quoted exactly on the decision page and in that brief.
Everything else here is Claude's work and has not been reviewed by a human. Nothing tracked
changed, nothing was committed and nothing was posted.

- **Decision page:** https://claude.ai/artifact/7228EtGy2bVvT4bWWBLkFu (private; source
  `out/decisions.html`, built by `scripts/make_decision_page.py` from
  `scripts/decisions.template.html` and the fragments in `out/fragments/`, which
  `scripts/make_fragments.py` writes, copying every pointed form from data; hand-written
  research prose without pointed Hebrew goes in `scripts/prose/`).
- **The draft change:** `out/build-A/{Gen,Exod,Deut}.xml`, built by `scripts/build.py A`
  from the base files and checked by `scripts/check_build.py` and `scripts/check_keys.py`.
- **The texts to post:** `out/70-description.md` (title and body) and `out/71-commit-message.txt`.
- **Rebuild everything in order:** `scripts/i_rebuild_all.py "<HH:MM>" "<state html>"` (-I);
  it never publishes and never runs `post_pr.py`.

## The plan

Source checkout `C:/Users/BenDe/GitRepos/MAM-basics` (at `374d9436` on `main` when this work
began; read-only here, apart from this folder). morphhb is read only through `gh api`, pinned and
logged (`scripts/gh_fetch.py`, `out/fetch_log*.jsonl`); no clone. Python runs from the
MAM-basics root with its `.venv`: `-B` for scripts importing MAM-basics modules or this folder's
`strands_core.py` (`versions.py`, `build.py`, `check_build.py`, `make_fragments.py`,
`make_description.py`, `g_*.py`, `i_final_accgram.py`, `i_spot_mam.py`, `i_desc_facts.py`,
`i_peek_segs.py`), `-I` otherwise.

1. Decision page first: every point the brief marks "to confirm" and every policy question the
   research raises, each with what raises it, the choices and a recommendation. Done; version 2
   (decisions 1 to 14, state line of 15:09 New York time) rebuilt by sub-agent I and the root
   session, and republished at about 15:10.
2. Research, by sub-agents writing only here: G, the accent grammar's verdicts and `n` codes
   (`out/53-*`); R2, the readers' handling of labels and note placement (`out/50-*`); T, MAM's
   documentation of the meteg cases and other forms (`out/51-*`); V, Exodus 20:5's sheva in
   WLC and morphhb (`out/52-*`). Done: all four reported; sub-agent I re-checked one claim of
   each (`out/56-spot-checks.md`, all four hold).
3. Build by script, following the recommendations until Ben answers: `versions.py` computes every
   span's versions; `build.py` writes the three files; `check_build.py` rebuilds every version
   from the new XML and compares, confirms the diff stays inside the 24 verses, applies the
   validator's rules and checks every `n`; `check_keys.py` replays the apps' accent keys;
   `i_final_accgram.py` runs the accent grammar on both strands rebuilt from the XML. Done
   (sub-agent I): 0 problems; 4 key misses, all at atoms whose main text is not legal; 32 of 32
   chanted verses grammatical.
4. Write the description; put it and the change on the page for Ben's approval. Done
   (sub-agent I): `out/70-description.md`, `out/71-commit-message.txt`, fragments `DESCRIPTION`
   and `CHANGE`; decision 14, "Post it?", lists the remote acts.
5. Post only at Ben's own "post it" in this session: a branch on bdenckla/morphhb from
   `pashta-helpers` (`696e21ce`), one commit, the pull request, a read-back. Then ask the
   commander, in one line, for the record in MAM-basics' `doc/mam-morphhb-pull-requests.md`.
   Waiting.

## Ben's requirements, cumulative

| Requirement (Ben, 2026-11-15, 13:12) | Status |
|---|---|
| Main text: CLC's תחתון (1A); Genesis 35:22 keeps the מדרשית (to confirm, decision 1) | implemented in the draft |
| Alternates: CLC's עליון where it differs | implemented |
| MAM-informed versions where CLC's are illegal | implemented for criteria (i)–(iv): 13 versions at 11 atoms; (iv) added Deuteronomy 5:8, atom 2 (the תחתון) |
| MAM-informed takes no stress helper, qamats qatan, Tetragrammaton ḥolam or meteg | implemented (decision 6) |
| Exodus 20:5's sheva left as WLC has it | implemented in every version |
| Investigate the ḥataf pataḥ ("accidental repair"?) | V reported (`out/52-sheva.md`): borne out, with one qualification; on the page |
| Note the meteg cases in the plan, the decision page and this README; supply none | page and below; T reported where MAM's documentation puts them |
| "let me know if this definition works" (spans) | answered, decision 2 |
| "usually (maybe always?) noted in a note in CLC" | answered, decision 5: every non-meteg note is an illegality, but 7 of 13 illegal versions have no note |
| 3: no `MAPM/` change | implemented (scope) |
| 4A: branch on `pashta-helpers`; description says it builds on #118 | implemented: `post_pr.py` branches from `696e21ce`; the description's "Merging" says so |

## The meteg cases (noted, none supplied)

1. Exodus 20:4, atom 2: WLC 4.20 has the meteg on the tav, MAM's עליון on the shin. MAM's note
   gives MAM's form as that of Firkovich B17, the Lehmann manuscript (known only through Breuer),
   both Sassoon manuscripts, Cairo 18 and the printed editions; its introduction lists the verse
   among its corrections of the Leningrad Codex's meteg.
2. Deuteronomy 5:7, atom 2: MAM's עליון has a meteg that WLC 4.20 lacks. MAM's note gives MAM's
   form as that of both Sassoon manuscripts, Cairo 18, the Washington Pentateuch and the printed
   editions; the parallel Exodus note says Dotan and Breuer read the Leningrad Codex's one stroke as
   merkha and meteg at once.
3. Deuteronomy 5:8, atom 2: likewise; MAM's note quotes the Leningrad Codex with the meteg on the
   shin, lacking only the תחתון's qadma, where WLC 4.20 has a merkha (which CLC's rules give to
   the תחתון, making its chanted verse ungrammatical).

All of this is MAM's documentation's statement, as T read it (`out/51-mam-documentation.md`);
no manuscript was consulted.

## Files

- `scripts/gh_fetch.py` (folder S's, with the prompt-suppressing environment), `fetch_state.py`,
  `fetch_base.py`, `fetch_catalog.py`: every GitHub read; `summarize_state.py`,
  `check_base.py`: what they found. `fetched/base-696e21ce/` holds the base (equal to the
  pashta-helper folder's `changed/` copies), `fetched/master-db6c5c9b/` master's files.
- `scripts/strands_core.py`: shared data and helpers; `versions.py`: `out/60-versions.json`,
  `.txt` (criterion (iv) from `out/54-for-build.json`, required); `show_failed.py`, `peek_*.py`,
  `show_verse_xml.py`, `verse_census.py`, `check_order.py`, `check_clc_forms.py`: lookers.
- `scripts/build.py`, `check_build.py`, `check_keys.py`: `out/build-A/` with `build-log.json`,
  `check.txt` and `keys.txt` (`n` from `out/54-for-build.json`, required; `check_keys.py` takes
  `out/60-versions.json` to mark each miss's legality).
- The research: `out/50-readers-encoding.md` and `out/50-r2a-main-text-readers.md` (R2, R2a;
  scripts `r2_*.py`, scratch `scratch-r2/`); `out/51-mam-documentation.md` and `.html` (T;
  `t_*.py`, `scratch-t/`); `out/52-sheva.md`, `.html` and `52-*.json` (V; `v_*.py`);
  `out/53-accgram.md` and `.json` (G; `g_*.py`, `scratch-g/`).
- Sub-agent I's scripts and outputs:
  - `scripts/i_for_build.py` (-I): `out/54-for-build.json`, the build's inputs from G's JSON
    (`criterion_iv`; `new_n`, MAM's main strand's codes, decisions 11A and 12A), with its checks.
  - `scripts/i_n_changes.py` (-I): `out/57-n-changes.txt` and `.json`, every `n` that changes.
  - `scripts/i_final_accgram.py` (-B): `out/55-final-accgram.md` and `.json`, the accent grammar
    on both strands rebuilt from the built XML alone.
  - `scripts/i_spot_fetched.py` (-I), `i_spot_mam.py` (-B), `i_spot_report.py` (-I):
    `out/56-spot-checks.md`, from `scratch-i/56a-spot-fetched.json` and `56b-spot-mam.json`.
  - `scripts/i_desc_facts.py` (-B): `out/58-facts.json`, every number the description and the
    page state.
  - `scripts/make_description.py` (-B; `{{FACT:…}}` placeholders, and a commit-message mode for a
    `.txt` output) with `scripts/description.template.md`: `out/70-description.md`; with
    `scripts/commit-message.template.txt`: `out/71-commit-message.txt`.
  - `scripts/prose/*.html`: the research prose of `PENDING`, `ACCGRAM`, `READERS_LABELS`,
    `READERS_SEVERAL`, `READERS_PLACEMENT`, `N_ILLEGAL`, `N_CODES`, `SHEVA` and `METEG_DOC`.
    `make_fragments.py` also writes `N_ILLEGAL_TABLE`, `N_CODES_TABLE`, `SHEVA_TABLE`,
    `METEG_NOTES` (MAM's notes verbatim, with their sigla), `CHANGE` and `DESCRIPTION`.
  - `scripts/i_rebuild_all.py` (-I): the whole pipeline, in order, optionally against a hashes
    file such as `scratch-i/hashes-before-black.txt`.
  - `scripts/i_check_page.py` (-I): the built page against the Hebrew rules (pointed Hebrew only
    in `lang="hbo"`, its cells `dir="rtl"`, no block opening with Hebrew, no link on it);
    `scripts/i_page_text.py` (-I): a section of the built page as plain text, for proofreading.
  - Lookers and lints: `i_peek_accgram.py`, `i_peek_wlc420.py`, `i_peek_w.py`, `i_peek_segs.py`,
    `i_peek_json.py`, `i_peek_doc_notes.py`, `i_peek_sheva.py`, `i_child_counts.py`,
    `i_diff_builds.py` (the earlier draft, kept in `scratch-i/build-A-before/`, against the new),
    `i_ascii_lines.py`, `i_char_census.py`, `i_hebrew_runs.py` (every hand-typed Hebrew run).
- `scripts/make_fragments.py`, `make_decision_page.py`, `decisions.template.html`: the page.
- `scripts/post_pr.py`: the posting, never run yet; `scripts/show_pr_body.py`: #118's body.

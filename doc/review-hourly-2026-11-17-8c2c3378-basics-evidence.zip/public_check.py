"""Bounded public-only static checks. No deployment or desktop operation."""
import ast
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time
from urllib.parse import unquote, urlsplit

ROOT = Path('/workspace/scratch/hourly-shared-archive-20261117/basics-source')
BASE = '43b00e6f46e1a7ba97232a1c34aad844252f96d8'
END = '8c2c3378487c9587659cd0b4a8f3db4690dbcf08'
OUT = Path('/workspace/scratch/hourly-shared-archive-20261117/public-evidence')
OUT.mkdir(exist_ok=True)
start = time.monotonic()
def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])
assert git('rev-parse', 'HEAD').decode().strip() == END
assert not git('status', '--porcelain=v1', '-z')
changed = git('diff', '--name-only', '-z', BASE, END).decode().rstrip('\0').split('\0')
assert len(changed) == 9
assert all(p.endswith('.md') or p == 'dot-claude/shared-skills.txt' for p in changed)
assert git('rev-list', '--count', BASE + '..' + END).strip() == b'1'
check = subprocess.run(['git', '-C', str(ROOT), 'diff', '--check', BASE, END], capture_output=True)
(OUT / 'endpoint-diff-check.txt').write_bytes(check.stdout + check.stderr)
assert check.returncode == 0
inventory = [{'path': p, 'bytes': (ROOT / p).stat().st_size, 'sha256': hashlib.sha256((ROOT / p).read_bytes()).hexdigest(), 'blob': git('rev-parse', END + ':' + p).decode().strip()} for p in changed]
(OUT / 'source-inventory.json').write_text(json.dumps(inventory, indent=2) + '\n', encoding='utf-8')

# Only local Markdown destinations; external content and live desktop behavior unverified.
links = []
external = 0
for p in changed:
    if not p.endswith('.md'):
        continue
    text = (ROOT / p).read_text(encoding='utf-8')
    for raw in re.findall(r'\[[^\]]*\]\(([^\s)]+)(?:\s+[^)]*)?\)', text):
        target = urlsplit(raw.strip('<>'))
        if target.scheme or target.netloc:
            external += 1
            continue
        dest = ((ROOT / p).parent / unquote(target.path)).resolve() if target.path else ROOT / p
        assert dest.is_relative_to(ROOT), (p, raw)
        assert dest.exists(), (p, raw)
        if target.fragment:
            headings = re.findall(r'^#{1,6}\s+(.+?)\s*#*$', dest.read_text(encoding='utf-8'), re.M)
            slugs = [re.sub(r'[^\w\- ]', '', h.lower()).replace(' ', '-') for h in headings]
            assert unquote(target.fragment) in slugs, (p, raw, slugs)
        links.append({'source': p, 'target': dest.relative_to(ROOT).as_posix(), 'anchor': target.fragment})
skill = ROOT / 'dot-claude/skills/commander-session/SKILL.md'
parts = skill.read_text(encoding='utf-8').split('---', 2)
assert parts[0] == '' and len(parts) == 3
frontmatter = dict(line.split(': ', 1) for line in parts[1].strip().splitlines())
assert set(frontmatter) == {'name', 'description'}
assert frontmatter['name'] == 'commander-session' and len(frontmatter['description']) > 20
refs = skill.parent / 'references'
assert sorted(x.name for x in refs.iterdir()) == ['app-limits.md', 'briefs-and-reports.md', 'claude-desktop.md', 'codex-desktop.md']
for p in refs.glob('*.md'):
    for raw in re.findall(r'`((?:references/)?[\w-]+\.md)`', p.read_text(encoding='utf-8')):
        # Historical prose also names restart/state artifacts, not canonical references.
        if Path(raw).name in {x.name for x in refs.glob('*.md')}:
            assert (refs / Path(raw).name).is_file()

# AST-extract only source-read helpers after inspection. _build_mappings writes a
# generated fingerprint, so it is NOT called, nor are sync/check/deploy entrypoints.
module_path = ROOT / 'py/repo_util/user_config_sync.py'
tree = ast.parse(module_path.read_text(encoding='utf-8'))
names = {'_skill_names', '_read_shared_skills', '_require_source', '_reject_duplicate_destinations'}
functions = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names]
assert {n.name for n in functions} == names
@dataclass(frozen=True)
class ConfigMapping:
    source_rel: Path
    destination_rel: Path
    kind: str
ns = {'Path': Path, 'ConfigMapping': ConfigMapping, '_Kind': str, 'UserConfigSyncError': RuntimeError}
exec(compile(ast.Module(body=functions, type_ignores=[]), str(module_path), 'exec'), ns)
claude = ns['_skill_names'](ROOT / 'dot-claude/skills')
codex = ns['_skill_names'](ROOT / 'dot-Codex/skills')
shared = ns['_read_shared_skills'](ROOT / 'dot-claude/shared-skills.txt')
retired = ns['_read_shared_skills'](ROOT / 'dot-Codex/retired-skills.txt')
assert 'commander-session' in shared and 'commander-session' in claude
assert 'commander-session' not in codex and not set(retired) & (set(shared) | set(codex))
assert set(shared) <= set(claude)
# Independent projection of inspected _build_mappings, with no source/live writes.
mappings = [ConfigMapping(Path(a), Path(b), k) for a,b,k in [
    ('dot-claude/user-wide-CLAUDE.md', '.claude/CLAUDE.md', 'file'),
    ('dot-Codex/user-wide-AGENTS.md', '.codex/AGENTS.md', 'file'),
    ('dot-Codex/hooks/check_project_doc_budget.py', '.codex/hooks/check_project_doc_budget.py', 'file'),
    ('.generated/expected-user-wide-AGENTS.sha256', '.codex/hooks/expected-user-wide-AGENTS.sha256', 'file'),
    ('dot-Codex/hooks.json', '.codex/hooks.json', 'file'),
]]
mappings += [ConfigMapping(Path('dot-claude/skills') / x, Path('.claude/skills') / x, 'directory') for x in claude]
mappings += [ConfigMapping(Path('dot-Codex/skills') / x, Path('.agents/skills') / x, 'directory') for x in codex]
mappings += [ConfigMapping(Path('dot-claude/skills') / x, Path('.agents/skills') / x, 'directory') for x in shared]
mappings += [ConfigMapping(Path('dot-Codex/retired-skills.txt'), Path('.agents/skills') / x, 'absent') for x in retired]
ns['_reject_duplicate_destinations'](mappings)
commander = [m for m in mappings if m.source_rel.as_posix() == 'dot-claude/skills/commander-session']
assert sorted(m.destination_rel.as_posix() for m in commander) == ['.agents/skills/commander-session', '.claude/skills/commander-session']
for m in mappings:
    if m.kind != 'absent' and not m.source_rel.as_posix().startswith('.generated/'):
        ns['_require_source'](ROOT / m.source_rel, m.kind)
assert not git('status', '--porcelain=v1', '-z')
result = {'base': BASE, 'source': END, 'commits': 1, 'changed_paths': 9, 'diff_check_exit': check.returncode, 'frontmatter': frontmatter, 'local_markdown_links': links, 'external_links_not_fetched': external, 'reference_files': 4, 'claude_skills': len(claude), 'codex_specific_skills': len(codex), 'shared_skills': list(shared), 'retired_skills': len(retired), 'mapping_projection_count': len(mappings), 'commander_destinations': [m.destination_rel.as_posix() for m in commander], 'mapping_method': 'independent projection of inspected builder; exact AST-extracted read-only inventory/duplicate helpers; builder/sync/check/deploy never called', 'source_status_clean': True, 'elapsed_seconds': round(time.monotonic()-start,6)}
(OUT / 'static-results.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2))

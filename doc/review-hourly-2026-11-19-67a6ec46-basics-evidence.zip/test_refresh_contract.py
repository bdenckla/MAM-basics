from pathlib import Path
from functools import lru_cache
from collections import Counter
from difflib import SequenceMatcher
import copy,json,hashlib,subprocess,re
from mb_cmn import mam_bknas_and_std_bknas as names
from mb_cmn import bib_locales as tbn
C=Path('/workspace/scratch/hourly-20261119-refresh/basics-source');R=C.parent;E=R/'public-artifacts'
OLD='54aaab9300e1559c891275a547dd516a84207354';NEW='67a6ec467ba0cf078e9790760a2ee8452f722382'
MARKS='\u0592\u0598\u05a0\u05a9'
@lru_cache(None)
def raw(rev,path):return subprocess.check_output(['git','-C',str(C),'show',rev+':'+path])
def js(rev,path):return json.loads(raw(rev,path))
def files(rev,prefix):return [x.decode() for x in subprocess.check_output(['git','-C',str(C),'ls-tree','-r','--name-only','-z',rev,'--',prefix]).split(b'\0') if x]
def changed(prefix=''):
 return [x.decode() for x in subprocess.check_output(['git','-C',str(C),'diff','--name-only','-z',OLD,NEW,'--',*([prefix] if prefix else [])]).split(b'\0') if x]
def delta(a,b,path=()):
 if a==b:return []
 if isinstance(a,dict) and isinstance(b,dict) and a.keys()==b.keys():return [v for k in a for v in delta(a[k],b[k],path+(k,))]
 if isinstance(a,list) and isinstance(b,list) and len(a)==len(b):return [v for i,(x,y) in enumerate(zip(a,b)) for v in delta(x,y,path+(i,))]
 return [(path,a,b)]
def plus(rev,prefix):
 result={}
 for path in files(rev,prefix):
  if not path.endswith('.json'):continue
  d=js(rev,path)
  for book in d['book39s']:
   bn=names.MAM_HBNP_TO_BK39ID[(book['book24_name'],book['sub_book_name'])]
   for c,vs in book['chapters'].items():
    for v,row in vs.items():result[(bn,int(c),str(v))]=row
 return result
def simple(rev,prefix):
 out={}
 def walk(x):
  if isinstance(x,dict):
   if x.get('type')=='verse':
    assert x['osisID'] not in out;out[x['osisID']]=x;return
   for v in x.values():walk(v)
  elif isinstance(x,list):
   for v in x:walk(v)
 for p in files(rev,prefix):
  if p.endswith('.json'):walk(js(rev,p))
 return out
def note_bodies(x):
 if isinstance(x,list):return [v for a in x for v in note_bodies(a)]
 if isinstance(x,dict):
  if x.get('tmpl_name')=='נוסח':return [x['tmpl_params']['2']]
  return [v for a in x.values() for v in note_bodies(a)]
 return []
def decode_id(osis):
 book,c,v=osis.rsplit('.',2)
 conv={'Josh':'Joshua','Judg':'Judges','1Sam':'1Samuel','2Sam':'2Samuel','1Kgs':'1Kings','2Kgs':'2Kings','Isa':'Isaiah','Jer':'Jeremiah','Ezek':'Ezekiel','2Chr':'2Chronicles'}
 return (conv.get(book,book),int(c),v)
def test_refresh_contract():
 report={};assert C==Path.cwd()
 candidate=[]
 for p in sorted((R/'candidate/plus').glob('*.json')):
  expected=raw(NEW,'MAM-parsed/plus/'+p.name);assert p.read_bytes()==expected
  candidate.append({'path':p.name,'bytes':len(expected),'sha256':hashlib.sha256(expected).hexdigest()})
 assert len(candidate)==24;report['candidate_books']=candidate
 oldmeta,newmeta=(js(r,'in/mam-ws-revisions.json') for r in [OLD,NEW]);assert {k:v for k,v in oldmeta.items() if k!='books'}=={k:v for k,v in newmeta.items() if k!='books'}
 revs=[];rawchap=[]
 for bn,chapters in oldmeta['books'].items():
  assert chapters.keys()==newmeta['books'][bn].keys()
  fn='in/mam-ws/'+tbn.ordered_short_dash_full_39(bn)+'.json';a,b=js(OLD,fn),js(NEW,fn)
  assert a.keys()==b.keys()
  for ch,oldrec in chapters.items():
   newrec=newmeta['books'][bn][ch]
   if oldrec!=newrec:
    assert set(k for k in oldrec if oldrec[k]!=newrec[k])<={'revision_id','sha256'}
    assert oldrec['revision_id']!=newrec['revision_id'];revs.append((bn,ch))
   if a[ch]!=b[ch]:rawchap.append((bn,ch))
   for rec,lines in [(oldrec,a[ch]),(newrec,b[ch])]:assert rec['sha256']==hashlib.sha256(json.dumps(lines,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
 assert set(revs)==set(rawchap) and len(revs)==20
 report['revision_changed_chapters']=revs
 for prefix in ['in/mam-ws-special','MAM-for-Sefaria','MAM-OSIS','MAM-morphhb','Taamey-D','in/stress-helpers','gh-pages/stress-helpers','out/explicit-xataf','Yeivin-ITM','gh-pages/yeivin-itm']:
  assert not changed(prefix),prefix
 report['unchanged_scope_prefixes']=['special-page mirror (36 declared pages)','Sefaria','OSIS','morphhb','Taamey-D','stress-helper inputs/pages','explicit-xataf','Yeivin-ITM']
 a,b=plus(OLD,'MAM-parsed/plus'),plus(NEW,'MAM-parsed/plus');assert a.keys()==b.keys()
 mpp={k:(a[k],b[k]) for k in a if a[k]!=b[k]};assert len(mpp)==21
 assert all(x[:2]==y[:2] for x,y in mpp.values())
 bodykeys={k for k,(x,y) in mpp.items() if note_bodies(x[2])!=note_bodies(y[2])}
 expectnotes={('Numbers',11,'8'),('Deuter',33,'21'),('Judges',18,'19'),('Jeremiah',11,'10'),('Ezekiel',19,'9')}
 assert bodykeys==expectnotes;report['changed_note_verses']=sorted(bodykeys)
 aa,bb=simple(OLD,'MAM-simple/json-vtrad-mam'),simple(NEW,'MAM-simple/json-vtrad-mam');assert aa.keys()==bb.keys()
 sv={k:(aa[k],bb[k]) for k in aa if aa[k]!=bb[k]};assert len(sv)==16
 refs={decode_id(k) for k in sv};assert refs==set(mpp)-bodykeys
 expected={('Joshua',7,'7'),('1Samuel',17,'37'),('1Samuel',17,'39'),('1Samuel',26,'15'),('2Samuel',4,'6'),('2Samuel',13,'20'),('2Samuel',19,'31'),('2Kings',9,'36'),('Isaiah',10,'16'),('Isaiah',39,'2'),('Jeremiah',21,'10'),('Jeremiah',40,'15'),('Ezekiel',13,'19'),('Ezekiel',14,'16'),('Amos',6,'10'),('2Chronicles',20,'27')}
 assert refs==expected
 pairs=[];classes=Counter()
 for osis,(x,y) in sv.items():
  differences=delta(x,y);assert len(differences)==1
  path,s,t=differences[0];assert isinstance(s,str) and isinstance(t,str)
  assert ''.join(c for c in s if c not in MARKS)==''.join(c for c in t if c not in MARKS)
  dif=Counter(t)-Counter(s);negative=Counter(s)-Counter(t)
  if sum(dif.values())==1 and not negative:typ='addition'
  elif sum(negative.values())==1 and not dif:typ='removal'
  else:
   assert not dif and not negative;typ='move'
   edits=[(tag,s[i:j],t[k:l]) for tag,i,j,k,l in SequenceMatcher(None,s,t,autojunk=False).get_opcodes() if tag!='equal']
   assert sorted(tag for tag,_,_ in edits)==['delete','insert']
   assert all(all(c in MARKS for c in v+w) for _,v,w in edits)
  assert all(c in MARKS for c in dif+negative)
  classes[typ]+=1;pairs.append((s,t));
 assert classes=={'addition':13,'move':2,'removal':1}
 report['text_change_classes']=dict(classes);report['text_verses']=sorted(refs)
 for tradition in ['bhs','sef']:
  x,y=simple(OLD,'MAM-simple/json-vtrad-'+tradition),simple(NEW,'MAM-simple/json-vtrad-'+tradition)
  assert x.keys()==y.keys();d=[(k,delta(x[k],y[k])) for k in x if x[k]!=y[k]]
  assert len(d)==9
  assert all(len(z)==1 and (z[0][1],z[0][2]) in pairs for _,z in d)
  report['simple_'+tradition+'_changes']=len(d)
 na,nb=plus(OLD,'out/near-aleppo/plus'),plus(NEW,'out/near-aleppo/plus');assert na.keys()==nb.keys()
 nearchanges={k for k in na if na[k]!=nb[k]};assert nearchanges==expectnotes
 assert all(na[k]==nb[k] for k in refs);report['near_aleppo_text_verses_exact']=16;report['near_aleppo_changes_only_five_notes']=True
 la,lb=js(OLD,'in/near-aleppo/doc-note-review.json'),js(NEW,'in/near-aleppo/doc-note-review.json')
 assert len(la['notes'])==len(lb['notes'])==1558
 ld=[(x,y) for x,y in zip(la['notes'],lb['notes']) if x!=y];assert len(ld)==2
 assert all(x['id']==y['id'] for x,y in ld)
 assert {y['id'].split(' note ')[0] for x,y in ld}=={'A4-Numbers 11:8','C2-Jeremiah 11:10'}
 assert all(y['review']['status']=='reviewed' and y['review']['presentation']=='recast' for x,y in ld)
 report['reviewed_ledger_rows']=[{'id':y['id'],'candidate_clause':y['candidate_clause'],'dispositions':[z['disposition'] for z in y['review']['clauses']]} for x,y in ld]
 oldlog,newlog=js(OLD,'gh-pages/MAM-with-doc/change-log/unpinned-latest.json'),js(NEW,'gh-pages/MAM-with-doc/change-log/unpinned-latest.json')
 assert oldlog['diff_count']==12 and newlog['diff_count']==28
 assert all(x in newlog['diffs'] for x in oldlog['diffs'])
 additions=[x for x in newlog['diffs'] if x not in oldlog['diffs']]
 endpoint=json.loads((E/'endpoint.json').read_text())
 assert additions==endpoint['diffs'] and len(additions)==16
 for p in files(NEW,'gh-pages/MAM-with-doc/change-log'):
  if p.rsplit('/',1)[-1] not in ['index.html','unpinned-latest.html','unpinned-latest.json']:assert raw(OLD,p)==raw(NEW,p)
 report['change_log']={'retained':12,'added':16,'total':28,'historical_release_bytes_unchanged':True}
 oldwords,newwords=[{json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')) for x in js(r,'out/mam-qere-words.json')} for r in [OLD,NEW]];assert len(oldwords-newwords)==16 and len(newwords-oldwords)==7
 report['word_list']={'removed':16,'added':7}
 pa,pb=js(OLD,'out/accgram/post-stress-meteg.json'),js(NEW,'out/accgram/post-stress-meteg.json')
 report['post_stress_delta_paths']=[list(path) for path,_,_ in delta(pa,pb)]
 assert [(path,t-s) for path,s,t in delta(pa,pb)]==[(('fit_for_mas','candidate_chanted_words'),7),(('fit_for_mas','accent_grammar_token_counts','1'),7)]
 report['source_inventory_paths']=len(changed());report['passed']=True
 (E/'public-consistency.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')

import ast
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
from near_aleppo import foi_qere_without_ketiv as qpage
from mb_misc import mb_html,printed_tradition
class HTMLTree(HTMLParser):
 def __init__(self,text):
  super().__init__(convert_charrefs=True);self.root=['ROOT',{},[]];self.stack=[self.root];self.feed(text)
 def handle_starttag(self,tag,attrs):
  n=[tag,dict(attrs),[]];self.stack[-1][2].append(n)
  if tag not in {'meta','link','img','br','hr','input','wbr','source','area','base','embed'}:self.stack.append(n)
 def handle_startendtag(self,t,a):self.handle_starttag(t,a);self.handle_endtag(t)
 def handle_endtag(self,tag):
  for i in range(len(self.stack)-1,0,-1):
   if self.stack[i][0]==tag:self.stack=self.stack[:i];break
 def handle_data(self,d):self.stack[-1][2].append(d)
def nodes(n):
 if isinstance(n,list):
  yield n
  for child in n[2]:yield from nodes(child)
def hn(seq,unwrap=False):
 out=[]
 def add(x):
  if isinstance(x,str) and out and isinstance(out[-1],str):out[-1]+=x
  else:out.append(x)
 for item in seq:
  if isinstance(item,str):add(item)
  elif unwrap and item.get('attr',{}).get('class')=='explained':
   for s in hn(item['contents'],True):add(s)
  else:add((item['_htel_tag'],item.get('attr',{}),hn(item.get('contents',[]),unwrap)))
 return out
def html_norm(n,unwrap=False):
 if isinstance(n,str):return re.sub(r'\s+',' ',n)
 children=[]
 for x in n[2]:
  if isinstance(x,list) and unwrap and x[0]=='span' and x[1].get('class')=='explained':parts=x[2]
  else:parts=[x]
  for p in parts:
   v=html_norm(p,unwrap)
   if isinstance(v,str) and children and isinstance(children[-1],str):children[-1]+=v
   else:children.append(v)
 return (n[0],n[1],tuple(re.sub(r'\s+',' ',x) if isinstance(x,str) else x for x in children))
def test_hover_differential_and_page():
 tree=ast.parse(raw(OLD,'py/near_aleppo/foi_qere_without_ketiv.py'))
 fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_prose')
 ns=dict(qpage.__dict__);exec(compile(ast.Module(body=[fn],type_ignores=[]),'committed-old-_prose','exec'),ns);old=ns['_prose']
 cases=['Plain English','the printed tradition','The printed tradition and the printed tradition','part of the printed tradition','most of the printed tradition','מילה and pointed שָׁטוּ֩','the printed tradition: שָׁטוּ֩','<script>alert("x")</script> & the printed tradition','legarmeh and the printed tradition','prefix the printed traditions','other\nthe printed\ntradition','The printed tradition, ל, and text']
 for text in cases:
  for roman in [(),('legarmeh',)]:assert hn(old(text,roman))==hn(qpage._prose(text,roman),True)
 escaped=mb_html.html_text(qpage._prose(cases[7]),mb_html.WriteCtx('probe','unused'))
 assert '<script>alert' not in escaped and '&lt;script&gt;' in escaped and '&amp;' in escaped
 path='gh-pages/near-aleppo/foi/qere-without-ketiv.html';a,b=(raw(r,path).decode() for r in [OLD,NEW])
 def visible_hebrew(n):
  if isinstance(n,str):return ''.join(re.findall(r'[\u0590-\u05ff\u034f]',n))
  return ''.join(visible_hebrew(x) for x in n[2])
 assert visible_hebrew(HTMLTree(a).root)==visible_hebrew(HTMLTree(b).root)
 x,y=HTMLTree(a),HTMLTree(b)
 h=[n for n in nodes(y.root) if n[0]=='span' and n[1].get('class')=='explained'];assert len(h)==1
 assert h[0][1]['title']==printed_tradition.HOVER
 assert html_norm(x.root)==html_norm(y.root,True)
 css=[n[1]['href'] for n in nodes(y.root) if n[0]=='link' and n[1].get('rel')=='stylesheet']
 assert any(printed_tradition.STYLE in ((C/path).parent/unquote(s)).resolve().read_text() for s in css if not urlsplit(s).scheme)
 (E/'hover-consistency.json').write_text(json.dumps({'plain_text_cases':len(cases)*2,'original_old_function_compiled_from_frozen_source':True,'outside_hover_tree_and_exact_Hebrew_preserved':True,'escaping':True,'new_hovers':1,'shared_title_style':True,'entire_page_equal_after_unwrapping_and_whitespace_comparison':True,'browser_or_visual_proof':False},indent=2)+'\n')
def test_published_verse_scope_and_phonetic_projection():
 expectedtext={tuple(x) for x in json.loads((E/'public-consistency.json').read_text())['text_verses']}
 expectednotes={tuple(x) for x in json.loads((E/'public-consistency.json').read_text())['changed_note_verses']}
 htmlrefs=set();localrefs=0;ids_cache={}
 for p in changed('gh-pages/MAM-with-doc'):
  if not re.fullmatch(r'gh-pages/MAM-with-doc/[A-F][A-Z1-9]-[^/]+\.html',p):continue
  # Large-note pages have their own format and are checked by link resolution below.
  if '-big-doc.html' in p:continue
  a,b=(HTMLTree(raw(r,p).decode()) for r in [OLD,NEW])
  def rows(t):
   ans={}
   for tr in nodes(t.root):
    if tr[0]!='tr':continue
    cs=[n for n in tr[2] if isinstance(n,list) and n[0]=='td' and re.fullmatch(r'c\d+v\d+',n[1].get('id',''))]
    if cs:
     assert len(cs)==1;ans[cs[0][1]['id']]=html_norm(tr)
   return ans
  aa,bb=rows(a),rows(b);assert aa.keys()==bb.keys()
  book=next(q['book'] for f in files(NEW,'Phonetic-MAM/data') if f.rsplit('/',1)[-1].split('-')[0]==p.rsplit('/',1)[-1].split('-')[0] for q in [js(NEW,f)]) if not p.rsplit('/',1)[-1].startswith(('A4-','A5-','B2-')) else {'A4':'Numbers','A5':'Deuter','B2':'Judges'}[p.rsplit('/',1)[-1].split('-')[0]]
  for key in aa:
   if aa[key]!=bb[key]:
    c,v=map(int,re.fullmatch(r'c(\d+)v(\d+)',key).groups());htmlrefs.add((book,c,str(v)))
 assert htmlrefs==expectedtext|expectednotes
 for p in changed('gh-pages/MAM-with-doc'):
  if not p.endswith('.html'):continue
  tree=HTMLTree((C/p).read_text())
  for n in nodes(tree.root):
   for key in ['href','src']:
    u=n[1].get(key)
    if not u:continue
    z=urlsplit(u)
    if z.scheme or z.netloc:continue
    dest=((C/p).parent/unquote(z.path)).resolve() if z.path else C/p
    assert dest.is_relative_to(C) and dest.is_file(),(p,u)
    if z.fragment and dest.suffix=='.html':
     if dest not in ids_cache:ids_cache[dest]={x[1]['id'] for x in nodes(HTMLTree(dest.read_text()).root) if 'id'in x[1]}
     assert unquote(z.fragment) in ids_cache[dest],(p,u)
    localrefs+=1
 changes=[];transcription_changes=[]
 for p in changed('Phonetic-MAM/data'):
  x,y=js(OLD,p),js(NEW,p);assert {k:v for k,v in x.items() if k!='chapters'}=={k:v for k,v in y.items() if k!='chapters'}
  def vv(d):return {(c['number'],v['number']):v for c in d['chapters'] for v in c['verses']}
  aa,bb=vv(x),vv(y);assert aa.keys()==bb.keys()
  for cv in aa:
   if aa[cv]==bb[cv]:continue
   ref=(x['book'],cv[0],str(cv[1]));changes.append(ref)
   a,b=aa[cv],bb[cv];assert a.keys()==b.keys() and len(a['rows'])==len(b['rows'])
   for z in ['hebrew_columns','transcription_columns','number']:assert a[z]==b[z]
   trchanged=False
   for u,v in zip(a['rows'],b['rows']):
    assert u.keys()==v.keys()
    for path,s,t in delta(u['hebrew'],v['hebrew']):
     assert isinstance(s,str) and isinstance(t,str)
     assert ''.join(c for c in s if c not in MARKS)==''.join(c for c in t if c not in MARKS)
    trchanged|=u['transcriptions']!=v['transcriptions']
   if trchanged:transcription_changes.append(ref)
 assert set(changes)==expectedtext and len(changes)==16
 assert len(transcription_changes)==15 and expectedtext-set(transcription_changes)=={('2Samuel',13,'20')}
 (E/'published-consistency.json').write_text(json.dumps({'MAM_with_doc_changed_verse_rows':sorted(htmlrefs),'local_link_occurrences_resolve':localrefs,'phonetic_changed_verses':sorted(changes),'transcription_changed_verses':15,'unchanged_transcription_verse':'2Samuel 13:20','original_source_or_stress_research':False},indent=2)+'\n')

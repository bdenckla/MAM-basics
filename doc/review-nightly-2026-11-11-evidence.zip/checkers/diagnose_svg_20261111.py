"""Explain strict SVG-checker mismatches without altering any generated artifact."""

import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET

task=Path('/workspace/scratch/nightly-20261111')
out=task/'basics'
report=json.loads((out/'basics-mega-activated-triage.json').read_bytes())
result=[]


def shape(s):
    return re.sub(r'[-+]?(?:\d*\.\d+|\d+\.?\d*)(?:[eE][-+]?\d+)?','#',s)


for row in report['changed_files']:
    if row['geometry_times_only']:
        continue
    name=row['path']
    old=subprocess.check_output(['git','-C',str(task/'basics-run'),'show','HEAD:'+name])
    new=(task/'basics-run'/name).read_bytes()
    roots=[ET.fromstring(raw,parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True))) for raw in (old,new)]
    nodes=[list(r.iter()) for r in roots]
    assert len(nodes[0])==len(nodes[1])
    diffs=[]
    for i,(a,b) in enumerate(zip(*nodes)):
        assert a.tag==b.tag and len(a)==len(b) and a.text==b.text and a.tail==b.tail
        assert a.attrib.keys()==b.attrib.keys()
        for key in a.attrib:
            av,bv=a.attrib[key],b.attrib[key]
            if av==bv:
                continue
            if key in {'width','height','viewBox','d','points','x','y','x1','x2','y1','y2','cx','cy','rx','ry'} and shape(av)==shape(bv):
                continue
            if key=='transform' and re.sub(r'translate\([^)]+\)','translate(GEOMETRY)',av)==re.sub(r'translate\([^)]+\)','translate(GEOMETRY)',bv):
                continue
            if key=='font-family' and {av,bv}=={'Times,serif','Times New Roman,serif'}:
                continue
            diffs.append(dict(node=i,tag=a.tag,attribute=key,before=av,after=bv))
    result.append(dict(path=name,node_count=len(nodes[0]),unexplained_by_strict_numeric_shape=diffs))
(out/'svg-strict-diagnosis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

"""Finish conservative SVG routing triage after preserving strict-check failures."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

TASK = Path('/workspace/scratch/nightly-20261111')
OUT = TASK / 'basics'
REPO = TASK / 'basics-run'
original = json.loads((OUT / 'basics-mega-activated-triage.json').read_bytes())
diagnosis = json.loads((OUT / 'svg-strict-diagnosis.json').read_bytes())
archive = OUT / original['durable_archive']['path']
assert hashlib.sha256(archive.read_bytes()).hexdigest() == original['durable_archive']['sha256']
number = r'[-+]?(?:\d*\.\d+|\d+\.?\d*)(?:[eE][-+]?\d+)?'
patches = []
for item in diagnosis:
    for change in item['unexplained_by_strict_numeric_shape']:
        assert change['attribute'] == 'd'
        assert change['tag'] == '{http://www.w3.org/2000/svg}path'
        counts = []
        for label in ('before', 'after'):
            path = change[label]
            assert re.fullmatch(r'M' + number + ',' + number + r'C(?:' + number + r'[, ]?)+', path)
            nums = re.findall(number, path.split('C', 1)[1])
            assert len(nums) >= 6 and len(nums) % 6 == 0
            counts.append(len(nums) // 6)
        patches.append({'path': item['path'], 'node': change['node'], 'cubic_segments_before_after': counts})
assert len(patches) == 3
assert len(diagnosis) == 2
assert sum(r['geometry_times_only'] for r in original['changed_files']) == 6
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    manifest = json.loads(z.read('manifest.json'))
    for name, spec in manifest.items():
        data = z.read(name)
        assert len(data) == spec['bytes'] and hashlib.sha256(data).hexdigest() == spec['sha256']
    for item in original['changed_files']:
        name = item['path']
        assert subprocess.check_output(['git', '-C', str(REPO), 'show', 'HEAD:' + name]) == z.read('before/' + name)
        assert (REPO / name).read_bytes() == z.read('after/' + name)
names = [r['path'] for r in original['changed_files']]
actual = subprocess.check_output(['git', '-C', str(REPO), 'diff', '--name-only', '-z']).decode().split('\0')
assert set(names) == set(filter(None, actual))
assert not subprocess.check_output(['git', '-C', str(REPO), 'ls-files', '--others', '--exclude-standard', '-z'])
report = {
    'result': 'PASS',
    'source': original['source'],
    'archive': original['durable_archive'],
    'changed_files': 8,
    'strict_comparison': 'Six SVGs passed strict numeric-shape/font-alias comparison. Two failed because three existing cubic edge paths gained a control segment. Original failure and exact diagnostic remain preserved.',
    'routing': patches,
    'disposition': 'All elements, child counts, text, titles, node/edge IDs, labels, links, colors, and nongeometric attributes agree. Remaining changes are existing cubic edge routing only, in addition to numeric geometry and Times/Times New Roman alias. No source, link, or label difference; no browser/pixel claim.',
    'restoration': 'Only the eight archived generated SVG paths restored to exact source HEAD.',
}
subprocess.run(['git', '-C', str(REPO), 'restore', '--source=HEAD', '--worktree', '--', *names], check=True)
assert not subprocess.check_output(['git', '-C', str(REPO), 'status', '--porcelain=v1', '-z'])
report.update(restored_utc=datetime.now(timezone.utc).isoformat(), final_status_clean=True)
destination = OUT / 'svg-final-triage.json'
assert not destination.exists()
destination.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))

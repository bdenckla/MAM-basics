"""Preserve every output difference and explain only strict SVG geometry/alias cases."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

TASK=Path('/workspace/scratch/nightly-20261111')
stage=sys.argv[1]
kind='basics' if stage.startswith('basics') else 'private'
out=TASK/kind
record=json.loads((out/(stage+'.json')).read_bytes())
repo=Path(record['cwd'])
assert record['state']=='completed' and record['exit_code']==0
destination=out/(stage+'-triage.json')
assert not destination.exists()


def git(*args):
    return subprocess.check_output(['git','-C',str(repo),*args])


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def dump(value):
    return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()


def numeric_shape(value):
    return re.sub(r'[-+]?(?:\d*\.\d+|\d+\.?\d*)(?:[eE][-+]?\d+)?','#',value)


def canonical(raw):
    parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True))
    root=ET.fromstring(raw,parser=parser)
    records=[]
    for n in root.iter():
        attributes={}
        for key,value in n.attrib.items():
            if key in {'width','height','viewBox','d','points','x','y','x1','x2','y1','y2','cx','cy','rx','ry'}:
                value=numeric_shape(value)
            elif key=='transform':
                value=re.sub(r'translate\(([^)]+)\)',lambda m:'translate('+numeric_shape(m[1])+')',value)
            elif key=='font-family' and value in {'Times,serif','Times New Roman,serif'}:
                value='PINNED_GRAPHVIZ_TIMES_ALIAS'
            attributes[key]=value
        text=n.text if n.text and n.text.strip() else None
        tail=n.tail if n.tail and n.tail.strip() else None
        records.append((n.tag if isinstance(n.tag,str) else '#comment',attributes,text,tail,len(n)))
    return records


files=[s for s in git('diff','--name-only','-z').decode().split('\0') if s]
untracked=[s for s in git('ls-files','--others','--exclude-standard','-z').decode().split('\0') if s]
payloads={}
results=[]
for path in files:
    before=git('show','HEAD:'+path)
    after=(repo/path).read_bytes()
    payloads['before/'+path]=before
    payloads['after/'+path]=after
    equivalent=False
    reason='Unexplained non-SVG difference; retained without restoration.'
    if path.endswith('.svg'):
        try:
            equivalent=canonical(before)==canonical(after)
            reason='All elements, child counts, IDs, labels, links, colors, non-coordinate attributes and meaningful text agree; differences are numeric geometry and the known Times/Times New Roman alias only.' if equivalent else 'SVG canonical comparison differs beyond declared geometry/alias fields; retained without restoration.'
        except ET.ParseError as exc:
            reason='SVG parsing failed: '+str(exc)
    results.append(dict(path=path,before_bytes=len(before),after_bytes=len(after),before_sha256=sha(before),after_sha256=sha(after),geometry_times_only=equivalent,disposition=reason))
for path in untracked:
    payloads['untracked/'+path]=(repo/path).read_bytes()
report=dict(stage=stage,source=git('rev-parse','HEAD').decode().strip(),observed_utc=datetime.now(timezone.utc).isoformat(),changed_files=results,untracked_files=untracked,all_explained=not untracked and all(r['geometry_times_only'] for r in results),restored=False)
if payloads:
    payloads['triage-before-restoration.json']=dump(report)
    payloads['manifest.json']=dump({p:dict(bytes=len(b),sha256=sha(b)) for p,b in sorted(payloads.items())})
    archive=out/(stage+'-differences.zip')
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for path,payload in sorted(payloads.items()):
            z.writestr(path,payload)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
        for path,entry in json.loads(z.read('manifest.json')).items():
            payload=z.read(path)
            assert len(payload)==entry['bytes'] and sha(payload)==entry['sha256']
    report['durable_archive']=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()))
destination.write_bytes(dump(report))
assert report['all_explained'],'Keep unexplained differences; investigate before restoration'
if files:
    git('restore','--source=HEAD','--worktree','--',*files)
assert not git('status','--porcelain=v1','-z')
report.update(restored=True,restored_utc=datetime.now(timezone.utc).isoformat(),final_status_clean=True)
destination.write_bytes(dump(report))
print(json.dumps(report,indent=2))

# Source at the start of each shell used for repository commands.
export PATH=/workspace/.cloud-setup/bin:$PATH
export XDG_CACHE_HOME=/workspace/.cloud-setup/cache
export PIP_CACHE_DIR=/workspace/.cloud-setup/cache/pip
export UV_CACHE_DIR=/workspace/.cloud-setup/cache/uv
export UV_PYTHON_INSTALL_DIR=/workspace/.cloud-setup/python
export PLAYWRIGHT_BROWSERS_PATH=/workspace/.cloud-setup/cache/ms-playwright

from pathlib import Path
import json
import subprocess
import time
ROOT=Path(__file__).parent
SRC=ROOT/'public-source'
OUT=ROOT/'public'
command=['/workspace/MAM-basics/.venv/bin/python','py/check_html_syntax_and_sanity.py','gh-pages/stress-helpers']
t=time.monotonic()
p=subprocess.run(command,cwd=SRC,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(OUT/'scoped-html.log').write_bytes(p.stdout)
status=subprocess.check_output(['git','status','--porcelain=v1','-z'],cwd=SRC)
diff=subprocess.check_output(['git','diff','--binary'],cwd=SRC)
(OUT/'scoped-html-status.z').write_bytes(status)
(OUT/'scoped-html-diff.patch').write_bytes(diff)
r={'stage':'scoped-html','command':command,'exit':p.returncode,'seconds':round(time.monotonic()-t,6),'status_bytes':len(status),'diff_bytes':len(diff)}
(OUT/'scoped-html-result.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r));print(p.stdout.decode())

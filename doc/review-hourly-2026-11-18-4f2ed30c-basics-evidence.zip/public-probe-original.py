from pathlib import Path
from collections import Counter
from urllib.parse import urlsplit, unquote
import hashlib
import json
import re
import subprocess
from lxml import html
from PIL import Image

ROOT=Path(__file__).parent
SRC=ROOT/'public-source'
OUT=ROOT/'public'
PAGE=SRC/'gh-pages/stress-helpers'
def old(name):
    return json.loads(subprocess.check_output(['git','show','8c2c3378:in/stress-helpers/'+name+'.json'],cwd=SRC))
def current(name):
    return json.loads((SRC/('in/stress-helpers/'+name+'.json')).read_bytes())
def identity(r):
    return tuple(r.get(k) for k in ('book','chapter','verse','atom','strand'))
records={ed:current(ed) for ed in ('koren','simanim-tanakh')}
result=current('results')
assert list(result)==['editions']
deltas=[]
for ed in records:
    assert len(old(ed)['differences'])==len(records[ed]['differences'])
    for before,after in zip(old(ed)['differences'],records[ed]['differences']):
        assert before['mam']==after['mam'] and before['printed']==after['printed']
        changes={k:{'old':before.get(k),'new':after.get(k)} for k in before.keys()|after.keys() if before.get(k)!=after.get(k)}
        if changes:deltas.append({'edition':ed,'scope':'index','identity':identity(after),'changes':changes})
removed=[]
for ed,tables in result['editions'].items():
    prior={identity(r):r for r in old('results')['editions'][ed]['differences']}
    actual={identity(r):r for r in tables['differences']}
    assert len(actual)==len(tables['differences'])
    assert actual.keys()<=prior.keys()
    for key,r in actual.items():
        before=prior[key]
        changes={k:{'old':before.get(k),'new':r.get(k)} for k in before.keys()|r.keys() if before.get(k)!=r.get(k)}
        if changes:deltas.append({'edition':ed,'scope':'results','identity':key,'changes':changes})
    removed.extend({'edition':ed,'record':prior[key]} for key in prior.keys()-actual.keys())
(OUT/'record-deltas.json').write_text(json.dumps({'changes':deltas,'removed_difference_records':removed,'removed_spelling_records':{ed:len(old('results')['editions'][ed]['spelling']) for ed in records}},ensure_ascii=False,indent=2)+'\n')

inventory=[]
models=[]
all_refs=set()
all_links=0
rowcounts={}
for name,inputs in [('index.html',{ed:data['differences'] for ed,data in records.items()}),('results.html',{ed:data['differences'] for ed,data in result['editions'].items()})]:
    document=html.fromstring((PAGE/name).read_bytes())
    assert len(document.xpath('//table'))==1
    assert not document.xpath('//details | //table[@class="census"] | //table[@id="spelling"]')
    ids=document.xpath('//@id');assert len(ids)==len(set(ids))
    rows=document.xpath('//table[@id="observations"]/tbody/tr')
    expected={}
    for ed,items in inputs.items():
        for r in items:
            key=tuple(r.get(k) for k in ('book','chapter','verse','atom','strand','location','mam','printed','verse_href','category'))
            expected.setdefault(key,{})[ed]=r
    assert len(rows)==len(expected)
    expected_forms=Counter((key[6],key[7]) for key in expected)
    actual_forms=Counter(tuple(row.xpath('.//span[@class="hebrew"]/text()')) for row in rows)
    assert expected_forms==actual_forms
    for key, sources in expected.items():
        form_mam,form_printed=key[6:8]
        matches=[r for r in rows if tuple(r.xpath('.//span[@class="hebrew"]/text()'))==(form_mam,form_printed) and r.xpath('./th/a/@href')==[key[8]] and r.get('data-filter').startswith(key[9]+'-')]
        # Repeated words may share forms and BCV; atom ordering is the remaining input tie-break.
        assert matches,(name,key)
        if len(matches)>1:
            matches=[r for r in matches if sorted(r.xpath('./td[@class="scan"]//img/@src'))==sorted([crop for source in sources.values() for crop in source['crops']]+[crop for source in sources.values() for items in source.get('comparison_crops',{}).values() for crop in items])]
        assert len(matches)==1,(name,key)
        row=matches[0]
        assert row.xpath('./td[@class="scan"]/@hidden')==['hidden']
        assert len(row.xpath('./td | ./th'))==4
        wanted=[]
        for ed,r in sources.items():
            wanted.extend(r['crops'])
            wanted.extend(c for cs in r.get('comparison_crops',{}).values() for c in cs)
            label=''.join(row.xpath('./th/span[@class="source"][@title=$scan]/text()',scan=r['scan']))
            assert ('p. '+str(r['page'])) in label
            assert ('appendix' in label)==(r.get('page_section')=='appendix')
            for crop in r['crops']:
                assert Path(crop).name.startswith(ed+'-')
                assert r['scan'].removesuffix('.jpg') in crop
                assert f'-{r["chapter"]}-{r["verse"]}-' in crop
                if 'atom' in r: assert f'-a{r["atom"]}-' in crop
            inventory.append({'page':name,'edition':ed,'identity':identity(r),'mam':r['mam'],'printed':r['printed'],'page_number':r['page'],'page_section':r.get('page_section'),'scan':r['scan'],'crops':r['crops']})
        actual=row.xpath('./td[@class="scan"]//img/@src')
        assert Counter(wanted)==Counter(actual)
        all_refs.update(actual)
    assert len(document.xpath('//*[@id="toggle-images"][@aria-expanded="false"]'))==1
    for attr in document.xpath('//@href | //@src'):
        url=urlsplit(attr)
        if url.scheme or url.netloc:continue
        target=PAGE/unquote(url.path) if url.path else PAGE/name
        assert target.is_file(),(name,attr)
        if url.fragment:
            dest=html.fromstring(target.read_bytes())
            assert dest.xpath('//*[@id=$id]',id=unquote(url.fragment)),(name,attr)
        all_links+=1
    for span in document.xpath('//*[@lang="hbo"]'):
        assert re.search('[\u0591-\u05bd\u05bf-\u05c7\u05c9]',span.text_content())
    models.append({'name':name,'rows':[{'cells':[cell.text_content() for cell in r.xpath('./td | ./th')],'filter':r.get('data-filter')} for r in rows],'options':[{'value':o.get('value'),'text':o.text_content()} for o in document.xpath('//select[@id="filter"]/option')],'scans':len(document.xpath('//*[@id="observations"]//*[@class="scan"]')),'toggle':True,'spelling_rows':0})
    rowcounts[name]={'rows':len(rows),'edition_records':sum(map(len,inputs.values())),'filter_counts':dict(Counter(r.get('data-filter') for r in rows))}
images=[]
for p in sorted((PAGE/'img').glob('*.png')):
    with Image.open(p) as im:
        size=im.size;fmt=im.format;im.verify()
    assert fmt=='PNG' and min(size)>0
    images.append({'path':str(p.relative_to(SRC)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'width':size[0],'height':size[1],'linked':str(p.relative_to(PAGE)) in all_refs})
added=subprocess.check_output(['git','diff','--diff-filter=A','--name-only','-z','8c2c3378','4f2ed30c','--','gh-pages/stress-helpers/img'],cwd=SRC).decode().rstrip('\0').split('\0')
assert len(added)==74
assert all(str(Path(p).relative_to('gh-pages/stress-helpers')) in all_refs for p in added)
assert len([x for x in images if not x['linked']])==4
(OUT/'record-inventory.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2)+'\n')
(OUT/'control-models.json').write_text(json.dumps(models,ensure_ascii=False,indent=2)+'\n')
(OUT/'crop-inventory.json').write_text(json.dumps(images,indent=2)+'\n')
summary={'rows':rowcounts,'local_link_asset_occurrences':all_links,'pngs_verified':len(images),'unique_linked_crops':len(all_refs),'new_crops_all_linked':len(added),'historical_orphan_crops':[x['path'] for x in images if not x['linked']],'removed_spelling_records':{ed:len(old('results')['editions'][ed]['spelling']) for ed in records},'removed_difference_records':removed,'data_delta_records':len(deltas),'scope':'Committed public data/DOM/PNG integrity and filename associations; not original source/census verification or browser layout'}
(OUT/'independent-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))

from pathlib import Path
import datetime
import json
import subprocess
import time

ROOT = Path(__file__).parent
SRC = ROOT / 'public-source'
OUT = ROOT / 'public'
PYTHON = '/workspace/MAM-basics/.venv/bin/python'
stages = [
    ('diff-check', ['git', 'diff', '--check', '8c2c3378487c9587659cd0b4a8f3db4690dbcf08', '4f2ed30c5ba8764baa01884637c90248892576f5']),
    ('black', [PYTHON, '-m', 'black', '--check', 'py/author_site/stress_helper_comparison.py']),
    ('gen-site', [PYTHON, 'py/main_authored.py', 'gen-site', '--trust-surveys']),
    ('focused-tests', [PYTHON, 'py/main_test.py', 'py/tests/test_prose_conventions.py', 'py/tests/test_prose_mark_order.py', 'py/tests/test_shared_html_styles.py', '-q']),
    ('html', [PYTHON, 'py/check_html_syntax_and_sanity.py', '--help']),
]
results = []
for name, cmd in stages:
    start = time.monotonic()
    proc = subprocess.run(cmd, cwd=SRC, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (OUT / (name + '.log')).write_bytes(proc.stdout)
    status = subprocess.check_output(['git','status','--porcelain=v1','-z'], cwd=SRC)
    diff = subprocess.check_output(['git','diff','--binary'], cwd=SRC)
    (OUT / (name + '-status.z')).write_bytes(status)
    (OUT / (name + '-diff.patch')).write_bytes(diff)
    result = {'stage':name,'command':cmd,'cwd':str(SRC),'exit':proc.returncode,'seconds':round(time.monotonic()-start,6),'status_bytes':len(status),'diff_bytes':len(diff),'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    results.append(result)
    (OUT/'checks.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(result),flush=True)
    if proc.returncode or status or diff:
        if name != 'html':
            raise SystemExit('Stopped for failure or unexplained change; evidence preserved')

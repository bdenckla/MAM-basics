"""Extract two committed public crops for bounded visual inspection only."""

from pathlib import Path
import hashlib
import json
import subprocess

root = Path('/workspace/scratch/hourly-4f2ed30c-root-pixels')
root.mkdir(exist_ok=False)
source = '4f2ed30c5ba8764baa01884637c90248892576f5'
paths = [
    'gh-pages/stress-helpers/img/simanim-tanakh-joshua-7-7-B1-Js-0366-a6-1.png',
    'gh-pages/stress-helpers/img/simanim-tanakh-jeremiah-21-10-C2-Je-0775-a3-1.png',
]
rows = []
for path in paths:
    prefix = ['git', '--no-optional-locks', '-C', '/workspace/MAM-basics']
    data = subprocess.check_output(prefix + ['show', source + ':' + path])
    blob = subprocess.check_output(prefix + ['rev-parse', source + ':' + path]).decode().strip()
    target = root / Path(path).name
    target.write_bytes(data)
    rows.append({'path': path, 'local_path': str(target), 'blob': blob, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
(root / 'manifest.json').write_text(json.dumps({'source': source, 'crops': rows}, indent=2) + '\n', encoding='utf-8')
print(json.dumps(rows, indent=2))

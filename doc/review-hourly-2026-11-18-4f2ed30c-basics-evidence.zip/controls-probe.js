// Runs the committed script in a disposable offline DOM adapter, not a browser.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');
const base = __dirname;
const started = performance.now();
const models = JSON.parse(fs.readFileSync(path.join(base, 'public/control-models.json'), 'utf8'));
const code = fs.readFileSync(path.join(base, 'public-source/gh-pages/stress-helpers/controls.js'), 'utf8');
let checks = 0;
const summaries = [];
function element(value = '') {
  return {value, defaultValue: value, textContent: '', hidden: false, handlers: {}, attributes: {},
    addEventListener(event, fn) { this.handlers[event] = fn; },
    getAttribute(name) { return this.attributes[name]; },
    setAttribute(name, value) { this.attributes[name] = String(value); }};
}
function key(text) { return text.toLowerCase().replace(/[\u0591-\u05bd\u05bf-\u05c7]/g, ''); }
for (const model of models) {
  const elems = Object.fromEntries(['hebrew-size', 'size-value', 'size-reset', 'find', 'filter', 'visible'].map(id => ['#' + id, element(id === 'hebrew-size' ? '30' : '')]));
  if (model.toggle) { elems['#toggle-images'] = element(); elems['#toggle-images'].attributes['aria-expanded'] = 'false'; }
  const rows = model.rows.map(row => ({cells: row.cells.map(textContent => ({textContent})), dataset: {filter: row.filter}, hidden: false}));
  const scans = Array.from({length: model.scans}, () => ({hidden: true}));
  const spelling = Array.from({length: model.spelling_rows}, () => ({hidden: false}));
  const style = {};
  const document = {
    documentElement: {style: {setProperty(name, value) {style[name] = value;}}},
    querySelector(selector) { assert.ok(selector in elems || selector === '#toggle-images'); return elems[selector] ?? null; },
    querySelectorAll(selector) { if (selector === '#observations .scan') return scans; if (selector === '#observations tbody tr') return rows; throw Error(selector); }
  };
  vm.runInNewContext(code, {document}, {timeout: 1000});
  assert.equal(style['--hebrew-size'], '30px');
  assert.equal(elems['#visible'].textContent, `${rows.length} differences`);
  elems['#hebrew-size'].value = '48'; elems['#hebrew-size'].handlers.input();
  assert.equal(style['--hebrew-size'], '48px'); assert.equal(elems['#size-value'].textContent, '48 px');
  elems['#size-reset'].handlers.click(); assert.equal(style['--hebrew-size'], '30px');
  checks += 4;
  if (model.toggle) {
    const toggle = elems['#toggle-images'];
    toggle.handlers.click(); assert.ok(scans.every(c => !c.hidden)); assert.equal(toggle.textContent, 'Hide images'); assert.equal(toggle.attributes['aria-expanded'], 'true');
    toggle.handlers.click(); assert.ok(scans.every(c => c.hidden)); assert.equal(toggle.textContent, 'Show images'); assert.equal(toggle.attributes['aria-expanded'], 'false');
    checks += 2;
  }
  for (const option of model.options) {
    const actual = model.rows.filter(r => !option.value || r.filter === option.value).length;
    assert.equal(Number(option.text.match(/\((\d+)\)$/)[1]), actual);
    checks++;
  }
  const queries = [...new Set(['', 'nothing-matches-this', '  1SAM  ', ...model.rows.flatMap(r => r.cells.flatMap(c => [c, key(c)]))])];
  let combinations = 0;
  for (const query of queries) {
    for (const option of model.options) {
      elems['#find'].value = query; elems['#filter'].value = option.value;
      elems['#find'].handlers.input();
      const expected = model.rows.map(r => r.cells.some(c => key(c).includes(key(query.trim()))) && (!option.value || r.filter === option.value));
      assert.deepEqual(rows.map(r => !r.hidden), expected);
      const n = expected.filter(Boolean).length;
      assert.equal(elems['#visible'].textContent, n + (n === 1 ? ' difference' : ' differences'));
      assert.ok(spelling.every(r => !r.hidden));
      combinations++; checks++;
    }
  }
  elems['#filter'].handlers.change(); // Both actual event bindings invoke the same filter.
  summaries.push({page: model.name, rows: rows.length, options: model.options.length, queries: queries.length, filter_search_combinations: combinations, spelling_rows_outside_filter: spelling.length, images_button: model.toggle});
}
console.log(JSON.stringify({scope: 'actual controls.js with offline scratch DOM adapter; no browser layout/rendering proof', summaries, checks, elapsed_seconds: (performance.now()-started)/1000}, null, 2));

import hashlib
import importlib.metadata
import json
from pathlib import Path
import subprocess
import sys
from packaging.requirements import Requirement

tree = Path(sys.argv[1])
bad, absent, checked = [], [], []
for line in (tree / 'constraints.txt').read_text(encoding='utf-8').splitlines():
    line = line.strip()
    if not line or line.startswith('#'):
        continue
    name, expected = line.split('==')
    try:
        actual = importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        absent.append(name)
        continue
    checked.append(name)
    if actual != expected:
        bad.append(dict(name=name, expected=expected, actual=actual))
required = []
for line in (tree / 'requirements.txt').read_text(encoding='utf-8').splitlines():
    line = line.split('#', 1)[0].strip()
    if line:
        name = Requirement(line).name
        required.append(dict(name=name, version=importlib.metadata.version(name)))
assert not bad, bad
assert sys.version_info[:3] == (3, 13, 15)
pip = subprocess.run([sys.executable, '-m', 'pip', 'check'], capture_output=True, text=True, encoding='utf-8')
assert pip.returncode == 0, pip.stdout + pip.stderr
print(json.dumps(dict(tree=str(tree), interpreter=sys.executable, python=sys.version, constrained_installed=len(checked), absent_unused_constraints=absent, required=required, mismatches=bad, pip_check=pip.stdout.strip(), constraints_sha256=hashlib.sha256((tree/'constraints.txt').read_bytes()).hexdigest())))

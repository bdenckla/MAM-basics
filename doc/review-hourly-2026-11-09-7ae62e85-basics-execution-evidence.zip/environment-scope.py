import importlib.metadata
import json
from pathlib import Path
import site
import sys
from packaging.requirements import Requirement
from packaging.utils import canonicalize_name

tree = Path(sys.argv[1])
pins = {canonicalize_name(line.split('==')[0]) for line in (tree/'constraints.txt').read_text(encoding='utf-8').splitlines() if line.strip() and not line.startswith('#')}
required = {canonicalize_name(Requirement(line.split('#',1)[0].strip()).name) for line in (tree/'requirements.txt').read_text(encoding='utf-8').splitlines() if line.split('#',1)[0].strip()}
installed = {canonicalize_name(dist.metadata['Name']) for dist in importlib.metadata.distributions()}
unpinned = installed - pins - {'pip'}
assert not unpinned, sorted(unpinned)
assert required <= pins, sorted(required-pins)
assert site.ENABLE_USER_SITE is False
assert all(Path(path).is_relative_to(Path(sys.prefix)) for path in site.getsitepackages())
print(json.dumps(dict(tree=str(tree),unpinned_application_packages=[],direct_requirements_constrained=True,no_system_or_user_site=True)))

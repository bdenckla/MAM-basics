"""Run all, or a selected subset, of the processing jobs in sequence.

The sequence combines this repository's processing steps with the wlc steps
that write into this repository's ``out/`` and ``gh-pages/wlc/`` trees. The
ordinary sequence begins by deriving MAM-parsed plus from committed Wikisource
input. The five downstream MAM product generators write into this
repository after the fourth-stage Repoint steps completed on 2026-09-10. One
step uses the MAM-private sibling through a read-only source adapter: the
Phonetic MAM exporter. That step is cloud-skipped; the renderer and both meteg
surveys consume the tracked public release in every environment. The exporter
finds the sibling through
``mb_cmn.paths.repos_root()``, which in a worktree looks beside the worktree's
home clone, so a worktree run needs no ``REPOS_ROOT``. Until 2026-09-11 a
second step, ``near-aleppo-census``, ran MAM-private's near-Aleppo census and
rewrote that clone's tracked goldens. Ben had it deleted that day, so that this
run writes nothing outside this repository; MAM-private's own mega then ran the
census until near-Aleppo's census moved into this repository, and it no longer
does. Since 2026-10-05 a step of the same name has run near-Aleppo's
local census, ``py/main_near_aleppo.py --census``, which reads only this
repository's MAM-parsed plus and Aleppo coverage index and writes
``in/near-aleppo/census/``.

Since 2026-09-10 the sequence also runs the five UXLC steps that
``py/main_uxlc_mega.py`` ran until it was folded in here, from
``uxlc-check-changes`` to ``uxlc-word-list``. They write into ``uxlc/``,
``gh-pages/uxlc/`` and ``in/UXLC-misc/``.

Six more steps joined on 2026-09-10, when Ben agreed to add the other offline
generators of tracked files, from ``clc`` to ``map-changes-to-book-of-job``.
They write into ``gh-pages/clc/`` (plus legacy HTML redirects under
``gh-pages/uxlc/clc/``), ``holman/``, ``gh-pages/holman/``,
``gh-pages/book-of-job/``, ``book-of-job/out/`` and ``uxlc/in/UXLC-misc/``.
Three of them fail the run on purpose, as their notes say:
``render-uxlc-corrections``, ``verify-and-render-table`` and
``book-of-job-site``, the last on any spelling finding in book-of-job's pages.

Six more generators of tracked files joined the same day, each placed by what
it reads: ``mam-simple-docs``, the doc half of ``py/main_mam_simple.py``, after
``mam-simple``; the two Holman corpus searches after ``wordlist``; and
``diffable-pointed-hebrew``, ``ac-gen-index-flat-annotated`` and
``pipeline-graph``, whose inputs no step writes, after ``gen-site``.

The ``diff-ctr-vs-mam`` step joined the same day, after ``diff-mpplus``, once
``py/diff_ctr_vs_mam/massage_mpu_verse.py`` could handle the narrow-sense paseq
template that Proverbs 8:34 has had in MAM-parsed since 2026-03-16.
"""

import argparse
from dataclasses import dataclass
import subprocess
import sys
import time
from typing import Callable

from mb_cmn import git_process
from mb_cmn import graphviz_pin
from mb_cmn import paths

import main_explicit_xataf

# main_download_mam_fr_google.py
# main_download_mam_fr_wikisource.py
import main_authored
import main_decnreub
import main_diff
import main_foi_features_of_interest
import main_multimark
import main_sigil_inventory
import main_tmpl_survey
import main_wordlist
import main_mam_with_doc
import main_near_aleppo
import main_mam_simple
import main_letter_small_job
import main_tmpl_survey_toy

# The wlc half of the pipeline.  Its code moved here on 2026-08-01
# (doc/PLAN-evacuate-python-from-wlc-utils.md) and the corpus it reads and writes
# followed on 2026-08-12 (doc/PLAN-evacuate-the-rest-of-wlc-utils.md).
import main_accgram
import main_phonetic_mam
import main_yeivin_itm
import main_find_uxlc_accent_changes
import main_uxlc_grammar_test
import main_wlc_a_notes
import main_wlc_diffs_420422
import main_wlc_json_and_unicode
from subcommands import diff_mpplus
from subcommands import parse_ws
from subcommands import ws_bot_proto
from wlc_cmn.utf8_io import force_utf8_io

# The UXLC steps, folded in from py/main_uxlc_mega.py on 2026-09-10.
import main_amb_early_mtg
import main_fois
import main_uxlc_check_changes
import main_uxlc_word_list
import main_write_page_break_info

# The other offline generators of tracked files, added on 2026-09-10.
import main_clc
import main_estimate_uxlc_locations
import main_gen_misc_authored_english_documents
import main_map_changes_to_book_of_job
import main_render_uxlc_corrections
import main_verify_and_render_table

# The MAM-side and remaining offline generators, added the same day.
import main_ac_gen_index_flat_annotated
import main_diffable_pointed_hebrew
import main_pipeline_graph
import main_search_final_hiriq_verse_text
import main_search_holam_he_qere

# Taamey D's page generator, which moved here from hbofonts on 2026-10-28, and its
# shaping checks, corpus refresh and release tool, which followed on 2026-10-29.  The
# release tool's exception for a shallow checkout lets a cloud session skip its check.
import main_taamey_d
from taamey_d.release import SourceCommitOutsideShallowHistory


@dataclass(frozen=True)
class StepRecord:
    step_id: str
    runner: Callable[[], object]
    note: str | None


def _run_near_aleppo_census():
    main_near_aleppo.almost_main(["--census"])


def _run_near_aleppo_build():
    main_near_aleppo.almost_main(["--refresh-note-review"])
    main_near_aleppo.almost_main(["--build"])


def _run_near_aleppo_html():
    main_near_aleppo.almost_main(["--html"])


def _run_vendored_tmpl_survey_toy():
    subprocess.run(
        [sys.executable, "py-examples/main_tmpl_survey_toy_example.py"],
        cwd=paths.mam_parsed_dir(),
        check=True,
    )


def _run_vendored_letter_small_job():
    subprocess.run(
        [sys.executable, "py-examples/main_letter_small_job_example.py"],
        cwd=paths.repo_root() / "MAM-simple",
        check=True,
    )


def _run_diff_ctr_vs_mam():
    main_diff.almost_main(["ctr-vs-mam"])


# Every step this run skipped because it is running in a cloud session, in order, each with
# the reason it was skipped.  Read by _report_cloud_skips, which reports them once at the
# end of the run, beside graphviz_pin's list of unrendered SVGs.
_CLOUD_SKIPPED_STEPS: list[tuple[str, str]] = []


def _run_accgram_prose():
    main_accgram.almost_main(["run-prose"])


def _run_accgram_test_fixes():
    main_accgram.almost_main(["test-fixes"])


def _run_accgram_dual_cant():
    main_accgram.almost_main(["run-dual-cant"])


def _run_accgram_printed_decalogue():
    main_accgram.almost_main(["run-printed-decalogue"])


def _run_accgram_poetic():
    main_accgram.almost_main(["run-poetic"])


def _run_accgram_xcheck_poetic():
    main_accgram.almost_main(["xcheck-poetic"])


def _run_accgram_servi_xcheck():
    main_accgram.almost_main(["servi-xcheck"])


def _run_accgram_grammaticality():
    main_accgram.almost_main(["grammaticality"])


def _run_accgram_survey_chanted_word_accents():
    main_accgram.almost_main(["survey-chanted-word-accents"])


def _run_phonetic_mam_export():
    if graphviz_pin.in_cloud_session():
        step_id = "phonetic-mam-export"
        reason = "it reads private source inputs; public renderers and surveys use the tracked release"
        _CLOUD_SKIPPED_STEPS.append((step_id, reason))
        print(
            f"STEP SKIPPED in this cloud session: {step_id}: {reason}", file=sys.stderr
        )
        return
    main_phonetic_mam.almost_main(["export"])


def _run_phonetic_mam_render():
    main_phonetic_mam.almost_main(["render"])


def _run_accgram_survey_meteg_before_stress():
    main_accgram.almost_main(["survey-meteg-before-stress"])


def _run_yeivin_itm_survey_meteg_claims():
    main_yeivin_itm.almost_main(["survey-meteg-claims"])


def _run_yeivin_itm_render():
    main_yeivin_itm.almost_main(["render"])


def _run_accgram_survey_post_stress_meteg():
    main_accgram.almost_main(["survey-post-stress-meteg"])


def _run_gen_site():
    # --trust-surveys because accgram-survey-post-stress-meteg ran directly above and wrote
    # out/accgram/post-stress-meteg.json, so recomputing the survey here would walk the corpus
    # a second time -- the reason accgram-generate-html is passed --trust-survey.
    # Both environments now run the survey against the tracked public release.
    main_authored.gen_site(trust_surveys=True)


def _run_accgram_generate_html():
    # --trust-survey because accgram-survey-chanted-word-accents ran directly above and wrote
    # out/accgram/chanted-word-accents.json.  Without it the residue page rebuilds that survey,
    # and the mega walks all three corpora twice for a minute it has already spent (#219; Ben's
    # decision, 2026-08-04, over paying the minute twice or leaving the survey out).
    main_accgram.almost_main(["generate-html", "--trust-survey"])


# The three runners below pass their programs' argument lists explicitly, as the
# main_accgram.py runners above do.  Until 2026-09-10 (phase 5c of
# doc/PLAN-mega-coverage.md) each of the three programs read sys.argv by hand, and the
# mega got the mode it runs only because this module's main() blanks sys.argv while the
# steps run.
def _run_clc():
    main_clc.almost_main(["all"])


def _run_find_uxlc_accent_changes():
    main_find_uxlc_accent_changes.almost_main([])


def _run_ac_gen_index_flat_annotated():
    main_ac_gen_index_flat_annotated.almost_main([])


def _run_taamey_d_doc():
    main_taamey_d.almost_main(["doc"])


def _run_taamey_d_qa():
    reports = main_taamey_d.almost_main(["qa"])
    _check_taamey_d_reports_against_index(reports)


def _git_paths(*args):
    """The paths that a Git command run in this repository lists, NUL-delimited by -z."""
    listed = subprocess.run(
        git_process.git_command(paths.repo_root(), *args),
        check=True,
        capture_output=True,
    ).stdout.decode("utf-8")
    return [path for path in listed.split("\0") if path]


def _check_taamey_d_reports_against_index(reports):
    """Raise if the shaping checks left their reports different from Git's index.

    hbofonts' mega made this comparison with ``git diff --exit-code``: the reports are
    tracked, so a difference is a change in the font's shaping that nobody has accepted.
    It compares with the index rather than with HEAD, so a baseline that Ben has approved
    passes once it is staged, and an untracked file there, such as the report of a new
    test-case file, is a difference too.  reports is the directory the checks wrote, as
    py/taamey_d/qa/run_checks.py returns it, so that no second copy of its path can
    drift; and a directory where Git tracks no report raises, since comparing it would
    check nothing.
    """
    pathspec = reports.relative_to(paths.repo_root()).as_posix()
    if not _git_paths("ls-files", "-z", "--", pathspec):
        raise RuntimeError(
            f"Git tracks no Taamey D shaping-check report in {pathspec}, so the"
            " reports the checks wrote cannot be compared with any"
        )
    differing = _git_paths("diff", "--name-only", "-z", "--", pathspec)
    differing += _git_paths(
        "ls-files", "--others", "--exclude-standard", "-z", "--", pathspec
    )
    if differing:
        shown = "".join(f"\n    {path}" for path in differing[:20])
        if len(differing) > 20:
            shown += f"\n    ... and {len(differing) - 20} more"
        raise RuntimeError(
            f"{len(differing)} Taamey D shaping-check report(s) differ from Git's"
            f" index:{shown}\nRead the shaping checks' results; stage a new baseline"
            " only once Ben has approved it (Taamey-D/README.md)."
        )


def _run_taamey_d_release_check():
    try:
        main_taamey_d.almost_main(["release-check"])
    except SourceCommitOutsideShallowHistory as error:
        # release-check compares each snapshot's archives with the snapshot's source
        # commit, which a cloud session's shallow checkout may lack (Phase 4 of
        # MAM-private's doc/PLAN-evacuate-hbofonts-into-MAM-basics.md).  Anywhere else a
        # missing source commit is a failure.
        if not graphviz_pin.in_cloud_session():
            raise
        step_id = "taamey-d-release-check"
        reason = str(error)
        _CLOUD_SKIPPED_STEPS.append((step_id, reason))
        print(
            f"STEP SKIPPED in this cloud session: {step_id}: {reason}", file=sys.stderr
        )


# Each step that found a refresh pending, with what is pending, in the order run.
# Appended to by _run_taamey_d_corpus and read by _report_pending_refreshes, which
# reports them once at the end of the run.
_PENDING_REFRESHES: list[tuple[str, str]] = []


def _run_taamey_d_corpus():
    # --check: by Ben's decision of 2026-10-28, a refresh of MAM's text only reports that
    # Taamey D's corpus is due a refresh, which then needs his baseline acceptance.
    if main_taamey_d.almost_main(["corpus", "--check"]):
        _PENDING_REFRESHES.append(
            (
                "taamey-d-corpus",
                "Taamey D's shaping-check corpus, Taamey-D/qa-in/, is due a refresh from"
                " the word lists; Taamey-D/README.md says how, and the refresh needs"
                " Ben's baseline acceptance",
            )
        )


_STEPS = [
    StepRecord(
        "parse-ws",
        parse_ws.almost_main,
        "mam_parsed must come before mam_simple, mam_tmpl_survey, & many others",
    ),
    # We run "features of interest" early, straight after parse-ws, since it
    # provides information about any malformed Unicode.
    # On later "main" functions, such malformed Unicode will cause
    # asserts that provide little information.
    #
    # parse-ws itself checks every plus book it writes with check_mpplus, and raises on
    # any error (py/subcommands/parse_ws_products.py).  So a string out of standard mark
    # order, a doc-note template with the wrong arguments, or a note-link template whose
    # target is the wrong kind, stops the run in parse-ws, before this step can report
    # it.  Ben's decision, 2026-09-10, keeps the check inside parse-ws, rather than in
    # the separate check-mpplus step that phases 5b and 5c of doc/PLAN-mega-coverage.md
    # had placed after this one.
    StepRecord(
        "foi-features-of-interest",
        main_foi_features_of_interest.almost_main,
        None,
    ),
    StepRecord("mam-with-doc", main_mam_with_doc.almost_main, None),
    # run_all, not almost_main, since 2026-08-25.  almost_main is only
    # run_unpinned_latest, so for four months the mega refreshed unpinned-latest on
    # every run while the five NAMED release reports and index.html were rewritten by
    # nobody -- they had gone untouched since 2026-04-21 and were stale by two changes
    # that had landed here meanwhile (the provenance key of 4f3cc11, the
    # nusach_notes -> docnote_notes rename of d205dbb).  The tracked generated artifact
    # is the test in this repo (CLAUDE.md), and that check was simply not running on
    # these eleven files: the giveaway was a committed index.html advertising "11 body
    # text changes" for an unpinned-latest.json that said 0.  ~40s.
    #
    # Named diff-mpplus since 2026-09-11, when py/main_diff.py's subcommand and
    # py/subcommands/diff_mpplus.py were renamed with it, by Ben's decision that day: "mpp"
    # fits MAM-parsed's plain/ as well as its plus/.  Issue #63 had retired that
    # abbreviation, and fc0dc027 named the module main_diff_mpplus.py in April; 9d5693d0
    # brought it back in May as the diff-mpp step, the mpp subcommand and diff_mpp.py.
    # Dated records under doc/ and in/ keep those names.
    StepRecord(
        "diff-mpplus",
        diff_mpplus.run_all,
        "every named release from releases.json, plus unpinned-latest and index.html",
    ),
    # Added 2026-09-10, in phase 5c of doc/PLAN-mega-coverage.md.  Until then nothing
    # routine ran py/main_diff.py ctr-vs-mam, and the only commit of
    # out/diff_ctr_mam.json was d86e5779 (2026-03-09).  From 2026-03-16 on, ctr-vs-mam
    # could not complete: Proverbs 8:34 has had the narrow-sense paseq template since
    # MAM-parsed revision 1880cbbd of that day, and
    # py/diff_ctr_vs_mam/massage_mpu_verse.py raised a KeyError on that template until
    # the commit that added this step gave the template a handler.
    StepRecord(
        "diff-ctr-vs-mam",
        _run_diff_ctr_vs_mam,
        "py/main_diff.py ctr-vs-mam: compares Psalms and Proverbs in MAM-parsed's"
        " plus/ tree with the committed CTR JSON under in/chabad-ctr/, and writes"
        " out/diff_ctr_mam.json; must come after parse-ws",
    ),
    StepRecord(
        "tmpl-survey",
        main_tmpl_survey.almost_main,
        "must come after mam_parsed",
    ),
    StepRecord(
        "tmpl-survey-toy",
        main_tmpl_survey_toy.almost_main,
        "must come after parse-ws",
    ),
    StepRecord(
        "vendored-tmpl-survey-toy",
        _run_vendored_tmpl_survey_toy,
        "runs MAM-parsed/py-examples/main_tmpl_survey_toy_example.py as subprocess; must come after parse-ws",
    ),
    StepRecord(
        "mam-simple",
        main_mam_simple.almost_main,
        "must come after mam_parsed",
    ),
    # Added 2026-09-10.  The mam-simple step above runs almost_main, the export and the
    # support-file copy, which never reaches the doc half of py/main_mam_simple.py, so
    # until then nothing routine rewrote these docs.  doc/mega-coverage-2026-09-10.md,
    # section 5, records that they had gone stale once.
    StepRecord(
        "mam-simple-docs",
        main_mam_simple.write_generated_docs,
        "py/main_mam_simple.py doc-only: reads MAM-parsed's plus/ tree and rewrites,"
        " each only where its content changed,"
        " gh-pages/MAM-simple/versification-differences.html,"
        " gh-pages/MAM-simple/versification-and-cantillation.html with its CSS,"
        " and gh-pages/MAM-simple/index.html; must come after parse-ws",
    ),
    # The mam4sef-and-ajf and mam-osis steps stood here until 2026-09-12, when Ben
    # took both out: "I know of no reason to be supplying constantly-updated versions
    # of these; as far as I know those two versions would only take on update if I did
    # it (in the case of StepBible (OSIS)) or if I asked them to do it (Sefaria)."  The
    # other reason to keep a program in the mega, that running it keeps its code
    # working, he weighed and rejected for these two: "that code is unlikely to break
    # (or if it does, would be easy to fix) because the code isn't that 'interesting',
    # because IMO these editions are pretty close to MAM-simple.  So it is really
    # MAM-simple's code and data that needs to be kept up to date, which they
    # presumably will be kept, by keeping MAM-simple's code run in 'mega'."  So the
    # mam-simple step below is what now stands behind both products, and the two
    # programs are declared in py/tests/test_mega_coverage.py's NOT_IN_MEGA.
    StepRecord(
        "letter-small-job",
        main_letter_small_job.almost_main,
        "must come after mam_simple",
    ),
    StepRecord(
        "vendored-letter-small-job",
        _run_vendored_letter_small_job,
        "runs the landed MAM-simple py-examples/main_letter_small_job_example.py as a subprocess; must come after mam_simple",
    ),
    StepRecord("decnreub", main_decnreub.almost_main, None),
    StepRecord("multimark", main_multimark.almost_main, None),
    StepRecord("wordlist", main_wordlist.almost_main, None),
    # The two Holman corpus searches, added 2026-09-10; until then nothing routine
    # rewrote their tracked reports.  They sit after wordlist because
    # search-holam-he-qere compares its hits with the qere word list that wordlist
    # writes.
    StepRecord(
        "search-final-hiriq-verse-text",
        main_search_final_hiriq_verse_text.main,
        "reads MAM-parsed's plus/ tree; writes"
        " holman/out/final_hiriq_verse_text_report.json",
    ),
    StepRecord(
        "search-holam-he-qere",
        main_search_holam_he_qere.main,
        "must come after wordlist, whose out/mam-qere-words.json it reads with"
        " MAM-parsed's plus/ tree; writes holman/out/holam_he_qere_report.json",
    ),
    StepRecord(
        "explicit-xataf",
        main_explicit_xataf.almost_main,
        None,
    ),
    StepRecord(
        "ws-bot-proto",
        ws_bot_proto.almost_main,
        "relies on download of ws",
    ),
    # Named gen-misc since 2026-09-10, after the py/main_authored.py subcommand it runs.
    # Until then it was gen-misc-authored-english-documents, the file name main_authored.py
    # had until eb18bb71 (2026-05-05).  book-of-job's site generator arrived under that
    # freed module name on 2026-08-19 (ef8e384c), and the shared name let
    # doc/PLAN-evacuate-the-rest-of-three-repos.md count that generator as a mega step when
    # no step ran it.  book-of-job-site, further down, runs it now.
    StepRecord(
        "gen-misc",
        main_authored.almost_main,
        "runs py/main_authored.py gen-misc, which writes the authored documents under"
        " gh-pages/MAM-with-doc/; not py/main_gen_misc_authored_english_documents.py,"
        " which book-of-job-site runs",
    ),
    # Added 2026-11-11, when the review of the Israel Bible left gh-pages/MAM-with-doc/misc/,
    # which gen-misc writes, for a folder of its own at Ben's word (py/main_authored.py's
    # docstring, "WHERE A NEW PAGE GOES").  It reads only in/israel-bible-review/ and the
    # stylesheet beside its module, which no step writes, so nothing orders it; it stands
    # after gen-misc, which ran it until then.
    StepRecord(
        "israel-bible-review",
        main_authored.gen_israel_bible_review,
        "runs py/main_authored.py gen-israel-bible-review, which writes"
        " gh-pages/israel-bible-review/index.html and its style.css from"
        " in/israel-bible-review/",
    ),
    # The wlc steps, in the order wlc-utils' own mega ran them until it was
    # absorbed here on 2026-08-01.  They are LAST rather than free-standing because
    # accgram reads MAM-simple's json-vtrad-bhs, which mam-simple above regenerates:
    # while the two megas were separate, nothing ordered them, and an accgram run could
    # silently consume a stale MAM-simple.
    StepRecord(
        "wlc-json-and-unicode",
        main_wlc_json_and_unicode.almost_main,
        "must come before accgram, which reads out/wlc422-kq-u",
    ),
    StepRecord(
        "accgram-run-prose",
        _run_accgram_prose,
        "must come after mam-simple and wlc-json-and-unicode",
    ),
    # Not a step wlc-utils' own mega ever had.  Added 2026-08-04 (#219 major 5) after its
    # artifact, wlc-utils' tracked out/accgram/fix-tester/, went stale twice in one window
    # through exactly this gap -- wlc-utils 97c695e's message named the channel and
    # predicted the recurrence.  ~3s.
    StepRecord(
        "accgram-test-fixes",
        _run_accgram_test_fixes,
        "must come after accgram-run-prose; also reads out/wlc422-kq-u, in/UXLC-39 and MAM-simple",
    ),
    # The six steps below, and find-uxlc-accent-changes and uxlc-grammar-test further down,
    # joined the mega on 2026-08-04 for the reason accgram-test-fixes did the same morning
    # (#219): each writes a git-tracked artifact, and until now nothing routine rewrote any
    # of them.  Two were already stale when the wiring was done --
    # out/accgram/_grammaticality.txt since 2026-06-29 and out/accgram/uxlc_grammar_test.txt
    # since the METHIGAZAQEF change of #218 -- which is the channel doing exactly what it did
    # to fix-tester.  ~12 s for all eight together.
    StepRecord(
        "accgram-run-dual-cant",
        _run_accgram_dual_cant,
        "reads out/wlc422-kq-u and MAM-simple; run after accgram-run-prose (wlc-utils#36)",
    ),
    StepRecord(
        "accgram-run-poetic",
        _run_accgram_poetic,
        "must come after mam-simple and wlc-json-and-unicode",
    ),
    StepRecord(
        "accgram-xcheck-poetic",
        _run_accgram_xcheck_poetic,
        "cross-checks the poetic scanner against MAM-simple; reads out/wlc422-kq-u, not the poetic run",
    ),
    StepRecord(
        "accgram-servi-xcheck",
        _run_accgram_servi_xcheck,
        "same inputs as accgram-xcheck-poetic, per-disjunctive servant instead of segmentation",
    ),
    StepRecord(
        "accgram-grammaticality",
        _run_accgram_grammaticality,
        "must come after BOTH accgram-run-prose and accgram-run-poetic: it estimates its PCFG"
        " over the *_ag.json those two write",
    ),
    StepRecord(
        "accgram-run-printed-decalogue",
        _run_accgram_printed_decalogue,
        "reads only committed inputs (the mirrored in/mam-ws-special/decalogue-base.mediawiki"
        " and in/accgram/edition_transcriptions), so nothing above it feeds it",
    ),
    StepRecord(
        "accgram-survey-chanted-word-accents",
        _run_accgram_survey_chanted_word_accents,
        "must come after mam-simple and wlc-json-and-unicode -- and BEFORE"
        " accgram-generate-html, which is passed --trust-survey on the strength of it",
    ),
    StepRecord(
        "accgram-generate-html",
        _run_accgram_generate_html,
        "must come after accgram-run-prose, accgram-run-poetic and"
        " accgram-survey-chanted-word-accents",
    ),
    # The five UXLC steps, in the order py/main_uxlc_mega.py ran them until Ben agreed on
    # 2026-09-10 to fold that program in here.  It was UXLC-utils' own mega, renamed on
    # arrival, and its reason for standing apart -- that it rebuilt the sibling
    # UXLC-utils' trees -- stopped being true when uxlc/ landed here on 2026-09-03.  The
    # five read only committed inputs, so no step above feeds them.  They sit here because
    # uxlc-check-changes rewrites the in/UXLC-misc/all_changes.json that
    # find-uxlc-accent-changes filters, and until then nothing in the mega rebuilt it.
    StepRecord(
        "uxlc-check-changes",
        main_uxlc_check_changes.main,
        "reads the UXLC change logs under uxlc/in/, in/UXLC-39 and in/lci_recs.json;"
        " writes the canonical in/UXLC-misc/all_changes.json and its derivatives under"
        " uxlc/out/UXLC-misc/; must come before uxlc-fois and find-uxlc-accent-changes",
    ),
    StepRecord(
        "uxlc-fois",
        main_fois.main,
        "reads in/UXLC-39 and in/UXLC-misc/all_changes.json; writes the UXLC features"
        " of interest, JSON and HTML, under gh-pages/uxlc/fois/; must come after"
        " uxlc-check-changes",
    ),
    StepRecord(
        "uxlc-write-page-break-info",
        main_write_page_break_info.main,
        "reads in/UXLC-39 and in/lci_recs.json; writes uxlc/data/lci_augrecs.json, and"
        " page_counts.json and lci_recs.xml under uxlc/out/UXLC-misc/",
    ),
    StepRecord(
        "uxlc-amb-early-mtg",
        main_amb_early_mtg.main,
        "reads the records in py/uxlc_amb_early_mtg/amb_early_mtg.py, in/UXLC-39 and"
        " in/lci_recs.json; writes the HTML pages under gh-pages/uxlc/amb-early-mtg/",
    ),
    StepRecord(
        "uxlc-word-list",
        main_uxlc_word_list.main,
        "reads in/UXLC-39; writes uxlc/out/uxlc-words.json and"
        " uxlc/out/uxlc-words-fragile.json",
    ),
    # The six steps below joined the mega on 2026-09-10, when Ben agreed to add the other
    # offline generators of tracked files (phase 5a of doc/PLAN-mega-coverage.md); until
    # then nothing routine rewrote what they write.  They sit after the UXLC steps because
    # clc, estimate-uxlc-locations, verify-and-render-table and map-changes-to-book-of-job
    # read the committed UXLC inputs, though none of the six reads what those five steps
    # write.  Where one of the six must follow another step, its note says so.  Three of
    # them fail the mega on purpose: render-uxlc-corrections, verify-and-render-table and
    # book-of-job-site, each for the reason its note gives.
    StepRecord(
        "clc",
        _run_clc,
        "py/main_clc.py all: reads in/UXLC-39 and the note pages and change logs"
        " under uxlc/in/; writes the five pilot jobs' pages, notes JSON and"
        " long-notes pages and index under gh-pages/clc/",
    ),
    StepRecord(
        "estimate-uxlc-locations",
        main_estimate_uxlc_locations.main,
        "reads the derivative of Holman's UXLC-correction emails under holman/emails/,"
        " in/UXLC-39 and in/lci_recs.json; writes holman/data/uxlc_atom_locations.json"
        " and holman/data/uxlc_standard_atoms.json; must come before"
        " render-uxlc-corrections",
    ),
    StepRecord(
        "render-uxlc-corrections",
        main_render_uxlc_corrections.main,
        "must come after estimate-uxlc-locations, whose two JSON files it reads, and"
        " raises unless they cover exactly the cases in holman/emails/; writes"
        " gh-pages/holman/uxlc_corrections.html with its CSS and JS, and"
        " holman/docs-not-served/uxlc_corrections.json",
    ),
    StepRecord(
        "verify-and-render-table",
        main_verify_and_render_table.main,
        "must come after parse-ws: checks Holman's ketiv/qere review table against"
        " MAM-parsed's plus/ tree and in/UXLC-39, and raises on any verification"
        " failure; writes its summary into holman/docs-not-served/table_data.json"
        " and the gh-pages/holman/table_data_findings* pages with their CSS and JS",
    ),
    StepRecord(
        "book-of-job-site",
        main_gen_misc_authored_english_documents.main,
        "book-of-job's site generator: reads only committed inputs; deletes and"
        " rewrites the HTML and CSS under gh-pages/book-of-job/ and the generated JSON"
        " under book-of-job/out/; ends in a spell check of those pages that exits 1 on"
        " any spelling, apostrophe or period finding, so such a finding fails the"
        " mega, following the historical Phase 7 decision in"
        " https://github.com/bdenckla/MAM-basics/blob/f72297084ab94aea6fd1274dc1bc3d7ce6acddd5/doc/PLAN-mega-coverage.md"
        " (with update https://github.com/bdenckla/MAM-basics/blob/f72297084ab94aea6fd1274dc1bc3d7ce6acddd5/doc/PLAN-mega-coverage-update.md)",
    ),
    StepRecord(
        "map-changes-to-book-of-job",
        main_map_changes_to_book_of_job.main,
        "must come after book-of-job-site, whose gh-pages/book-of-job/jobn-details/"
        " pages and book-of-job/out/enriched-quirkrecs.json it reads, with"
        " uxlc/in/UXLC-misc/2026.04.01 - Changes.xml; writes"
        " uxlc/in/UXLC-misc/2026.04.01-map-to-book-of-job.json",
    ),
    StepRecord(
        "find-uxlc-accent-changes",
        _run_find_uxlc_accent_changes,
        "py/main_find_uxlc_accent_changes.py without --audit; must come after"
        " uxlc-check-changes, which rewrites the in/UXLC-misc/all_changes.json this"
        " step filters; writes the tracked in/accgram/uxlc_accent_changes.json",
    ),
    StepRecord(
        "uxlc-grammar-test",
        main_uxlc_grammar_test.main,
        "must come after find-uxlc-accent-changes, whose JSON it reads, and after"
        " wlc-json-and-unicode",
    ),
    StepRecord("wlc-diffs-420422", main_wlc_diffs_420422.almost_main, None),
    StepRecord("wlc-a-notes", main_wlc_a_notes.almost_main, None),
    # The sigil inventory reads MAM-parsed's plus/ tree, so it belongs after parse-ws and
    # after everything else that writes MAM-parsed.  Added 2026-08-27, for the reason
    # accgram-test-fixes was added on 2026-08-04 (and near-aleppo-census on 2026-08-26, a
    # step deleted on 2026-09-11 whose name a local census took on 2026-10-05) --
    # py/main_sigil_inventory.py
    # was imported by nothing, so nothing routine rewrote its tracked artifact.  This one had
    # already gone stale, and provably so twice over: out/sigil-inventory.json had exactly one
    # commit in its history, c14122a of 2026-04-07, and d205dbb changed this generator's own
    # header description string on 2026-05-21 while the committed JSON kept the old spelling.
    # So the file was three months stale on a string alone, before any corpus change was
    # counted.  The rebuild moved every header count -- notes_scanned 3847 -> 3863,
    # distinct_expressions 1711 -> 1721, distinct_expression_tokens 2363 -> 2371,
    # distinct_prose_tokens 667 -> 678 -- and 5,536 lines of the 73,847-line file.  ~1.5s.
    StepRecord(
        "sigil-inventory",
        main_sigil_inventory.almost_main,
        "reads MAM-parsed's plus/ tree; writes the tracked out/sigil-inventory.json",
    ),
    StepRecord(
        "phonetic-mam-export",
        _run_phonetic_mam_export,
        "reads private sources through a read-only adapter; writes only Phonetic-MAM; cloud-skipped",
    ),
    StepRecord(
        "phonetic-mam-render",
        _run_phonetic_mam_render,
        "reads the tracked public release, its stylesheet and script in"
        " py/phonetic_mam/assets/, the five example images in in/phonetic-mam-images/,"
        " the site's one font, gh-pages/woff2/Taamey_D.woff2 (Taamey D 1.2), which it"
        " checks against its pin, and in/font-support/taamey-d-1.2/; writes the unified"
        " phonetic-mam site, the font's three notice and source files beside it in"
        " gh-pages/woff2/ and the shared gh-pages/font-sources/taamey-d-1.2/ package,"
        " which yeivin-itm-render also writes; runs in cloud",
    ),
    StepRecord(
        "accgram-survey-meteg-before-stress",
        _run_accgram_survey_meteg_before_stress,
        "independent analysis of the public release; writes out/accgram/meteg-before-stress.json",
    ),
    StepRecord(
        "yeivin-itm-survey-meteg-claims",
        _run_yeivin_itm_survey_meteg_claims,
        "projects the independent analysis into Yeivin-ITM/meteg-claims.json; runs in cloud",
    ),
    StepRecord(
        "yeivin-itm-render",
        _run_yeivin_itm_render,
        "reads the approved tracked claims, the adaptation and"
        " py/yeivin_itm/assets/style.css, the site's one font,"
        " gh-pages/woff2/Taamey_D.woff2 (Taamey D 1.2), which it checks against its"
        " pin, and in/font-support/taamey-d-1.2/; writes the 17 public Yeivin pages,"
        " gh-pages/yeivin-itm/style.css, and the font's three notice and source files"
        " in gh-pages/woff2/ and the shared gh-pages/font-sources/taamey-d-1.2/"
        " package, both of which phonetic-mam-render also writes",
    ),
    # Added 2026-09-10, when Ben decided the survey "should join mega" on two conditions: a
    # worktree run finds MAM-private beside its home clone with no REPOS_ROOT (516a4a1a), and
    # a cloud run skips the survey altogether.  Until then nothing routine rewrote
    # out/accgram/post-stress-meteg.json; the survey was run by hand from main_accgram.py when
    # the corpus moved.  Since 9a67d51b (2026-10-01) the survey reads the tracked Phonetic-MAM
    # release rather than MAM-private, so neither condition concerns it any more: it runs in a
    # cloud session too, and the cloud skip belongs to phonetic-mam-export.  Placed immediately
    # before gen-site, which renders from the JSON it writes, and so after every step that
    # writes MAM-simple, whose json-vtrad-mam it reads (paths.mam_simple_vtrad_mam_dir).  It
    # also reads MAM-parsed's plus/ tree, which parse-ws writes far earlier
    # (py/accgram/post_stress_meteg_sources.py, through read_books_from_mam_parsed_plus).  This
    # comment and the description below said xml-vtrad-mam until 2026-09-11.
    StepRecord(
        "accgram-survey-post-stress-meteg",
        _run_accgram_survey_post_stress_meteg,
        "reads public Phonetic-MAM, MAM-simple's json-vtrad-mam and MAM-parsed's"
        " plus/ tree, and writes the tracked out/accgram/post-stress-meteg.json;"
        " runs in a cloud session; must come before gen-site",
    ),
    # Must come after accgram-survey-post-stress-meteg, since 2026-09-10: it renders the nine
    # post-stress-meteg pages that read the survey from the JSON that step writes.  It also
    # reads the tracked outputs of two steps that run far earlier.  mam-simple writes
    # MAM-simple: the post-silluq page's _mam_final_forms lifts MAM's verse-final chanted
    # words from it, and reference_forms reads it for the Phonetic MAM annotation check.
    # wlc-json-and-unicode writes out/wlc422/1verses_03_jsju1s.json: _post_silluq_comparison
    # reads it to check that WLC 4.22 and UXLC 3.9 agree on the verse-final chanted word at
    # 1 Samuel 17:5.  Nothing else it reads is written by a step; its other inputs include
    # the vendored in/UXLC-39 and the two authored in/meteg_after_silluq_*.json ledgers.
    # Until 2026-08-31 it also had to follow every step writing a subtree, because the
    # landing page's manifest section was DERIVED from the set of tracked
    # gh-pages/<subtree>/index.html; Ben deleted that section that day, and
    # py/author_site/published_subtrees.py with it.  Until 2026-09-25 this comment called
    # the survey JSON the only step output it read.
    StepRecord(
        "gen-site",
        _run_gen_site,
        "writes gh-pages/index.html and gh-pages/unicode-proposals.html; into"
        " gh-pages/post-stress-meteg/, nine post-stress-meteg pages from the"
        " survey JSON and one post-silluq case page per entry of"
        " site_data.POST_STRESS_METEG_POST_SILLUQ_IMAGE_PAGES; and the forwarding"
        " stubs gh-pages/post-stress-meteg.html and"
        " gh-pages/post-stress-meteg-post-silluq-1s17v5.html; must come after"
        " accgram-survey-post-stress-meteg; also reads MAM-simple and"
        " out/wlc422/1verses_03_jsju1s.json",
    ),
    # The three steps below joined on 2026-09-10, with the other offline generators of
    # tracked files that Ben agreed to add; until then nothing routine rewrote what they
    # write.  Each reads only committed inputs that no step writes, so nothing orders
    # them against the steps above: they sit together after gen-site, at the end of
    # the run.
    StepRecord(
        "diffable-pointed-hebrew",
        main_diffable_pointed_hebrew.write_tracked_expansions,
        "reads only committed inputs: expands the two zarqa tables under"
        " misc/zarqa-table-diff/ into the two tracked outputs beside them, the pairs"
        " in py/main_diffable_pointed_hebrew.py's TRACKED_EXPANSIONS",
    ),
    StepRecord(
        "ac-gen-index-flat-annotated",
        _run_ac_gen_index_flat_annotated,
        "py/main_ac_gen_index_flat_annotated.py with no arguments, so with its"
        " default paths: reads only the committed, hand-corrected"
        " aleppo/aleppo-wiki/index-flat-corrected.json; writes"
        " aleppo/index-flat-annotated.json",
    ),
    StepRecord(
        "near-aleppo-census",
        _run_near_aleppo_census,
        "five MAM-only population baselines; after parse-ws and the Aleppo coverage index",
    ),
    StepRecord(
        "near-aleppo-build",
        _run_near_aleppo_build,
        "refreshes the note-review ledger, then builds from local MAM plus the stored pointings; validates every changed-note review before baking, checks its counts against the census, and writes out/near-aleppo/plus and in/near-aleppo/build-populations.json after the census",
    ),
    StepRecord(
        "near-aleppo-html",
        _run_near_aleppo_html,
        "formats stored notes; writes gh-pages/near-aleppo after the build",
    ),
    StepRecord(
        "pipeline-graph",
        main_pipeline_graph.almost_main,
        "writes doc/process-documentation/pipeline.dot and pipeline.svg from the"
        " py/pipeline_graph/pipeline_graph_spec.py spec, and renders the Ben-written"
        " MAM-process.dot to MAM-process.dot.svg; needs the pinned"
        " Graphviz, and a cloud session skips its two SVG renders as it does"
        " tmpl-survey's",
    ),
    # Added 2026-10-26, when gh-pages/MAM-for-Sefaria/index.html stopped being hand-authored
    # (https://github.com/bdenckla/MAM-basics/blob/462984bb567a6498fd4f2d7ef00e3186fcd00f02/doc/PLAN-rewrite-MAM-for-Sefaria-encoding-page.md);
    # the same day its listings and its
    # AJF variant got pages of their own, unicode-names/index.html and ajf/index.html.  The
    # pages read only tracked files, MAM-for-Sefaria/'s and, for the meteg-after-silluq table,
    # MAM-simple/json-vtrad-mam/, so they follow any later rerun of the hand-run
    # py/main_mam4sef.py.  The step is last because MAM-for-Sefaria/ may lag MAM-simple (Ben's
    # decision of 2026-09-30, in AGENTS.md), and the pages raise rather than state a claim
    # their files no longer bear out, such as a meteg-after-silluq annotation of MAM-simple
    # that the CSV files predate; last, that failure stops no other step.
    StepRecord(
        "mam-for-sefaria-doc",
        main_authored.gen_mam_for_sefaria_doc,
        "runs py/main_authored.py gen-mam-for-sefaria-doc, which writes"
        " gh-pages/MAM-for-Sefaria/index.html, unicode-names/index.html and"
        " ajf/index.html; must come after mam-simple",
    ),
    # Added 2026-10-28, when Taamey D's sources, build and pages moved here from hbofonts
    # (Phase 2 of MAM-private's doc/PLAN-evacuate-hbofonts-into-MAM-basics.md).  It reads
    # only its own code, the font version in py/taamey_d_build/font_version.py and the frozen
    # comparison images' PROVENANCE.json, none of which a step writes, so nothing orders
    # it; the plan put it last, and the three steps of Phases 3 and 4 follow it.  The
    # FontForge build of the font is not a step, by Ben's decision of that day: "Yes, keep
    # FontForge run out of MAM-basics mega."  So the pages follow the committed font
    # version, and test_mega_coverage.py's NOT_IN_MEGA declares the build,
    # py/main_taamey_d_build.py.
    StepRecord(
        "taamey-d-doc",
        _run_taamey_d_doc,
        "runs py/main_taamey_d.py doc, which writes gh-pages/taamey-d/Taamey_D.html and"
        " Xolam_xaser_for_alef.html; refuses if a comparison cell no longer matches its"
        " record in the frozen gh-pages/taamey-d/img/comparison/PROVENANCE.json",
    ),
    # Added 2026-10-29, when Taamey D's shaping checks and their corpus moved here from
    # hbofonts (Phase 3 of the same plan).  The checks shape the corpus in Taamey-D/qa-in/
    # with the committed font, Taamey-D/font-m-TaD/Taamey_D.ttf, which no step writes,
    # since the FontForge build is hand-run; so nothing orders this step either.  As in
    # hbofonts' mega, the step fails if the rewritten reports differ from Git's index, so
    # a new baseline that Ben has approved is staged before the mega runs.
    StepRecord(
        "taamey-d-qa",
        _run_taamey_d_qa,
        "runs py/main_taamey_d.py qa, Taamey D's shaping checks, on"
        " Taamey-D/font-m-TaD/Taamey_D.ttf and the corpus in Taamey-D/qa-in/; rewrites"
        " Taamey-D/qa-out/Taamey_D/; raises on a SKIP, an unknown status, an"
        " anchor-family FAIL, or a report that differs from Git's index, an untracked"
        " one included",
    ),
    # Added 2026-10-29, when Taamey D's release tool moved here from hbofonts (Phase 4 of
    # the same plan).  It reads only the tracked downloads tree,
    # gh-pages/taamey-d/downloads/, and Git, which no step writes, so nothing orders it.
    # It comes before taamey-d-corpus because hbofonts' mega checked its downloads before
    # its corpus, so that a pending refresh ended the output.  Writing a snapshot,
    # py/main_taamey_d.py release-publish, is outward-facing release preparation, which
    # test_mega_coverage.py's NOT_IN_MEGA declares.
    StepRecord(
        "taamey-d-release-check",
        _run_taamey_d_release_check,
        "runs py/main_taamey_d.py release-check, which checks Taamey D's published"
        " downloads, gh-pages/taamey-d/downloads/, against Git and writes nothing;"
        " before the first snapshot it reports that none is published; a cloud session"
        " skips it if its shallow checkout lacks a snapshot's source commit",
    ),
    # Added the same day as taamey-d-qa, and last: after wordlist and uxlc-word-list,
    # which write the two word lists it reads, and so that a pending refresh ends the
    # run's output, as in hbofonts' mega.  It writes nothing.  By Ben's decision of
    # 2026-10-28 a refresh of MAM's text does not oblige refreshing the corpus, so a
    # pending refresh goes into the run's closing summary instead of failing it, and only
    # an error that would stop a refresh raises.  The refresh itself, py/main_taamey_d.py
    # corpus without --check, and accept-baseline are declared in test_mega_coverage.py's
    # NOT_IN_MEGA.
    StepRecord(
        "taamey-d-corpus",
        _run_taamey_d_corpus,
        "runs py/main_taamey_d.py corpus --check, which compares the corpus in"
        " Taamey-D/qa-in/ with out/mam-qere-words.json and uxlc/out/uxlc-words.json and"
        " writes nothing; reports REFRESH PENDING at the end of the run rather than"
        " failing; must come after wordlist and uxlc-word-list",
    ),
]

_STEP_NAMES = [step.step_id for step in _STEPS]


def _report_cloud_skips():
    """Announce, once and at the end, every step and SVG render skipped for the cloud.

    Two kinds of thing are skipped in a cloud session, which
    graphviz_pin.in_cloud_session detects. A cloud container has no Graphviz, so
    the tmpl-survey step skips its renders rather than killing the run -- Ben's
    decision, 2026-09-09; graphviz_pin's docstring has the reasoning. And the one
    step that uses private source inputs, phonetic-mam-export, is skipped
    altogether. Rendering and both meteg surveys run from the tracked public
    release, so gen-site receives the regenerated public survey in the cloud too.
    Since 2026-10-29 taamey-d-release-check is skipped too, but only when the cloud
    session's shallow checkout lacks the source commit of a Taamey D snapshot, against
    which the step checks that snapshot's archives.

    Such a run is CLOUD-COMPLETE, meaning that no step failed, and that every step
    either ran or was skipped for the cloud, while some SVGs may have gone
    unrendered. It is deliberately not called incomplete, and the exit status
    stays 0.

    The banner exists because the skips are printed beside whichever step
    produced them, thousands of lines up by the time a full run ends. It also
    names the one hazard an SVG skip leaves behind, which is not obvious: the
    .dot beside an unrendered .svg IS rewritten, so committing a .dot change
    without its .svg would put the tracked pair out of step -- the very drift
    the Graphviz pin exists to prevent.
    """
    skipped_steps = tuple(_CLOUD_SKIPPED_STEPS)
    skipped_svgs = graphviz_pin.cloud_skipped_renders()
    if not skipped_steps and not skipped_svgs:
        return
    print()
    print("=" * 80)
    print(
        f"  MEGA RUN IS CLOUD-COMPLETE: {len(skipped_steps)} step(s) and "
        f"{len(skipped_svgs)} SVG render(s) skipped for the cloud"
    )
    print("=" * 80)
    print("No step failed. This is a cloud session, so what is listed below was")
    print("skipped rather than run.")
    if skipped_steps:
        print()
        print("STEPS SKIPPED:")
        for step_id, reason in skipped_steps:
            print(f"    {step_id}: {reason}")
    if skipped_svgs:
        print()
        print("SVG RENDERS SKIPPED. This container has no Graphviz, so the SVG files")
        print("below were not re-rendered. Their .dot sources WERE rewritten.")
        print()
        print("  DO NOT COMMIT A CHANGED .dot WITHOUT ITS .svg. The two are a matched")
        print("  pair in the tracked tree, and letting them drift apart is what the")
        print("  Graphviz pin exists to prevent. If `git status` shows no .dot change,")
        print("  nothing was lost and this notice is informational.")
        print()
        for svg_path in skipped_svgs:
            print(f"    {svg_path}")
    print("=" * 80)


def _report_pending_refreshes():
    """Announce, once and at the end, every refresh that a step found pending.

    Added 2026-10-29 with the taamey-d-corpus step.  By Ben's decision of 2026-10-28, a
    refresh of MAM's text does not oblige refreshing Taamey D's shaping-check corpus, so
    that step reports a pending refresh rather than failing, and the run's exit status
    stays 0.  This banner keeps the report from being lost in the run's output.
    """
    if not _PENDING_REFRESHES:
        return
    print()
    print("=" * 80)
    print(
        f"  REFRESH PENDING: {len(_PENDING_REFRESHES)} step(s) found a refresh pending"
    )
    print("=" * 80)
    for step_id, what in _PENDING_REFRESHES:
        print(f"    {step_id}: {what}")
    print("=" * 80)


@dataclass(frozen=True)
class StepTime:
    step_id: str
    seconds: float
    # None when the step returned, else the name of the exception it raised.
    raised: str | None


# Every step this run timed, in the order run.  Appended to by _time_step and read by
# _report_step_times.
_STEP_TIMES: list[StepTime] = []


def _time_step(step):
    """Run one step, print how long it took, and record that in _STEP_TIMES.

    The line is printed and the StepTime recorded even when the step raises, so a
    run that stops at a failing step still says how long the failure took.
    """
    start = time.perf_counter()
    raised = None
    try:
        step.runner()
    except BaseException as exc:
        raised = type(exc).__name__
        raise
    finally:
        seconds = time.perf_counter() - start
        suffix = "" if raised is None else f", then raised {raised}"
        print(f"STEP TIME: {step.step_id}: {seconds:.1f} s{suffix}", flush=True)
        _STEP_TIMES.append(StepTime(step.step_id, seconds, raised))


def _report_step_times(run_seconds):
    """Print every timed step, slowest first, with its share of the step loop's time.

    Added 2026-09-11, when a mega run became the check on every integration of a
    worktree branch (CLAUDE.md, "Integrating a worktree branch here"), so that each
    run shows where its time goes. Printed even when a step raises; the traceback
    then follows it.
    """
    if not _STEP_TIMES:
        return
    cloud_skipped = {step_id for step_id, _reason in _CLOUD_SKIPPED_STEPS}
    print()
    print("=" * 80)
    print(
        f"  MEGA STEP TIMES: {len(_STEP_TIMES)} step(s) in {run_seconds:.1f} s,"
        " slowest first"
    )
    print("=" * 80)
    for step_time in sorted(_STEP_TIMES, key=lambda st: st.seconds, reverse=True):
        share = 100 * step_time.seconds / run_seconds if run_seconds else 0.0
        notes = []
        if step_time.raised is not None:
            notes.append(f"raised {step_time.raised}")
        if step_time.step_id in cloud_skipped:
            notes.append("skipped for the cloud")
        note = f"  ({'; '.join(notes)})" if notes else ""
        print(f"  {step_time.seconds:7.1f} s  {share:5.1f}%  {step_time.step_id}{note}")
    print("=" * 80)


def _check_graphviz_first():
    """Check, before any step runs, that the SVG renders will be able to run.

    Ben's decision, 2026-09-14. Two steps render SVGs, tmpl-survey eighth and
    pipeline-graph near the end, and until then each found out only on arriving
    that this machine could not render. That day one run stopped at tmpl-survey
    after 65 s on a Graphviz other than the pinned one, and a second after 79 s
    on a font the machine lacked. graphviz_pin.check_rendering_environment makes
    the checks render_svg makes, on the same dot. A cloud session skips its
    renders, so it skips this check too.
    """
    if graphviz_pin.in_cloud_session():
        print("GRAPHVIZ CHECK SKIPPED: this cloud session skips its SVG renders")
        return
    print(f"GRAPHVIZ CHECK: {graphviz_pin.check_rendering_environment()}", flush=True)


def main():
    """Run various mains"""
    # The wlc steps emit Hebrew.  Their own `if __name__ == "__main__"` blocks called
    # this and no longer run now that they are in-process steps, and on Windows a
    # redirected stdout encodes with cp1252, so without this the first Hebrew print
    # raises UnicodeEncodeError whenever the mega is run into a file or a pipe.
    force_utf8_io()
    parser = argparse.ArgumentParser(description="Run the mega pipeline")
    parser.add_argument(
        "--resume-from",
        choices=_STEP_NAMES,
        metavar="STEP",
        help="Skip steps before STEP and resume from there. Choices: "
        + ", ".join(_STEP_NAMES),
    )
    args = parser.parse_args()
    _check_graphviz_first()
    resuming = args.resume_from is not None
    old_argv = sys.argv
    run_start = time.perf_counter()
    try:
        # Isolate mega CLI flags from child parsers in step scripts.
        sys.argv = [old_argv[0]]
        for step in _STEPS:
            if resuming:
                if step.step_id == args.resume_from:
                    resuming = False
                else:
                    print(f"Skipping {step.step_id}")
                    continue
            _time_step(step)
    finally:
        sys.argv = old_argv
        _report_step_times(time.perf_counter() - run_start)
    _report_cloud_skips()
    _report_pending_refreshes()
    #
    # Download of ws (Wikisource) can be accomplished by running:
    #    py/main_download.py fr-wikisource
    # It must be run in a venv like this:
    #    .venv/Scripts/python.exe py/main_download.py fr-wikisource


if __name__ == "__main__":
    main()

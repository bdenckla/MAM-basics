"""Prepare an execution-backed bounded receipt, without source changes."""

import json
from pathlib import Path
import subprocess

PREFIX = Path('/workspace/scratch/basics-9f8901a9')
meta = json.loads(Path(str(PREFIX) + '-init.json').read_text())
out = Path(meta['out'])


def git(*args):
    return subprocess.check_output(['git', '-C', meta['home'], *args])


workflow = '.github/workflows/pages.yml'
expected = '18ceb19405424710bda47d9a38c470cc2ed9c385'
for rev in [meta['head'], meta['parent']]:
    names = git('ls-tree', '-r', '--name-only', '-z', rev, '.github').split(b'\0')
    assert [n.decode() for n in names if n] == [workflow]
    assert git('rev-parse', rev + ':' + workflow).decode().strip() == expected
    text = git('show', rev + ':' + workflow).decode()
    assert 'on:\n  workflow_dispatch:\n' in text
    assert '\n  push:' not in text and '\n  pull_request:' not in text
assert not git('ls-remote', '--heads', 'origin', 'refs/heads/' + meta['branch'])
(out / 'publication-preflight.json').write_text(json.dumps({
    'source': meta['head'], 'parent': meta['parent'], 'branch': meta['branch'],
    'branch_absent': True, 'sole_workflow': workflow, 'workflow_blob': expected,
    'trigger': 'workflow_dispatch only; no dispatch requested or performed',
    'ownership': 'Task-owned isolated branch; no shared or deployment dependency assigned.',
}, indent=2) + '\n')
(out / 'review-summary.md').write_text('''Frozen endpoint `d957048a20f671fbadea37325c91dd9c9bfe4ee9` -> `9f8901a92f8f040060841b1e5ba19524b97bbba3`: four commits / 28 paths. No consequential introduced defect established; no product repair.

The FOI index conversion preserves all 26 destinations, order, labels, descriptions and inline markup after serializer whitespace folding. Hebrew codepoints are unchanged. The complete maintained FOI generator reproduces committed outputs exactly; all 53 other FOI outputs have identical endpoint blobs. The source change uses the existing anchor/description producers and coverage guard, with two-column table styling and viewport metadata.

Twenty focused maintained tests pass: shared styles (2), receipt links (1), source hygiene (9), prose conventions (4), and tracked Phonetic MAM release (4). Changed-source Black passes for all three Python paths. FOI HTML validation reports no output issues, with 1,160 informational undefined CSS-class references retained; this is not an assertion that every CSS reference has been resolved. Every executed stage leaves zero tracked or untracked product differences. There were no failed execution stages or diagnostic retries in this window.

The other two Python deltas are docstring/comment-only by AST comparison. Three Phonetic MAM approval-string changes add archival URL prefixes, preserving all other configuration. All 16 retired documents match their base blobs at full archival commit `462984bb567a6498fd4f2d7ef00e3186fcd00f02`; 33 distinct immutable file targets in changed surviving prose/configuration resolve locally. Recorded retirement approval and external issue-body audit remain attributed; no external audit was repeated. The appended maintenance report was read, but its historical C1/S1/S2 and latent findings belong to the existing Claude maintenance session and Ben. This screen neither reopens those decisions nor claims to have independently rerun that audit.

Overall reviewed-through remains `210affe3ac2931473bead0de839be0de08309e3d`; broad-tested remains `354cc0b7077cb46ba5d7cfc8dd9b453ff68c7bf0`. All inherited rows, pending windows and immutable receipts are carried forward. No broad suite/mega, live-source/editorial/manuscript check or browser/font verification ran. The earlier responsive-browser failures and gap remain open; no failed browser harness was repeated. Local slot/process ownership was clear at admission; cross-machine ownership remains unverified. Existing maintenance owners resolve their findings; the next scheduled broad owner handles broad coverage. A corrected supported browser setup is the trigger for future visual checks.

Only this task's isolated receipt branch is published. Its source and receipt-parent workflows are the same manual-dispatch-only Pages workflow; no dispatch, integration or deployment is performed. Home and unrelated checkouts are preserved. Exact remote SHA/scope/evidence verification and task-worktree cleanup are reported at closeout.
''')
meta.update({
    'stem': 'review-hourly-2026-11-11-9f8901a9-basics',
    'scope': 'four commits / 28 paths; FOI index table and proportionate documentation/retirement review',
    'disposition': 'No consequential introduced defect or repair; existing maintenance findings retain their assigned owners.',
    'brief_checks': 'FOI regeneration exact; 20 selected tests, three-file Black and FOI HTML check pass (1,160 informational CSS references). All 26 index entries and 53 other outputs preserved; 16 archived documents and 33 immutable targets verified.',
    'anchors': ['210affe3ac2931473bead0de839be0de08309e3d', '354cc0b7077cb46ba5d7cfc8dd9b453ff68c7bf0'],
    'rename_old_labels': ['Latest bounded screen d957048a', 'Latest focused evidence d957048a'],
    'required_stages': ['foi', 'black', 'focused-tests', 'html-foi', 'independent'],
    'input_files': ['py/foi/foi_finals.py', 'gh-pages/MAM-with-doc/foi/index.html', 'py/author_misc/mam4sef_index.py', 'py/main_0_mega.py', 'in/phonetic_mam_display_corrections.json'],
    'scripts': ['/workspace/scratch/check_basics_9f8901a9.py', '/workspace/scratch/record_hourly_20261111_15.py', '/workspace/scratch/package_hourly_20261111_15.py', '/workspace/scratch/prepare_basics_9f8901a9.py'],
    'config': str(PREFIX) + '-config.json',
    'prepared': str(PREFIX) + '-prepared.json',
})
Path(str(PREFIX) + '-meta.json').write_text(json.dumps(meta, indent=2) + '\n')

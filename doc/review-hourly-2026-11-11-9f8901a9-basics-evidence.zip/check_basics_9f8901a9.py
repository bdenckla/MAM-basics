"""Index field preservation and bounded historical-reference integrity."""

import ast
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import subprocess

BASE = "d957048a20f671fbadea37325c91dd9c9bfe4ee9"
HEAD = "9f8901a92f8f040060841b1e5ba19524b97bbba3"
ARCHIVE = "462984bb567a6498fd4f2d7ef00e3186fcd00f02"
OUT = Path("/workspace/scratch/basics-9f8901a9-artifacts")


def git(*args):
    return subprocess.check_output(["git", *args])


def text(ref, path):
    return git("show", ref + ":" + path).decode("utf-8")


class Fragment(HTMLParser):
    def __init__(self, s):
        super().__init__()
        self.events = []
        self.feed(s)

    def handle_starttag(self, t, a):
        self.events.append((t, sorted(a)))

    def handle_endtag(self, t):
        self.events.append(("/" + t,))

    def handle_data(self, s):
        s = " ".join(s.split())
        if s:
            self.events.append(("text", s))


path = "gh-pages/MAM-with-doc/foi/index.html"
old, new = [text(ref, path) for ref in [BASE, HEAD]]
items = re.findall(r"<li>(<a\b.*?</a>) — (.*?)</li>", old, re.S)
rows = re.findall(r"<tr>\s*<td>(<a\b.*?</a>)</td>\s*<td>(.*?)</td>\s*</tr>", new, re.S)
assert len(items) == len(rows) == 26
for before, after in zip(items, rows):
    assert Fragment(before[0]).events == Fragment(after[0]).events
    assert Fragment(before[1]).events == Fragment(after[1]).events
assert "<th>Feature</th>\n<th>Description</th>" in new
assert new.count('<meta name="viewport"') == 1
assert re.findall(r'href="([^"]+)"', old) == re.findall(r'href="([^"]+)"', new)
assert re.findall(r"[\u0590-\u05ff]+", old) == re.findall(r"[\u0590-\u05ff]+", new)
all_outputs = {}
for ref in [BASE, HEAD]:
    entries = {}
    for item in git("ls-tree", "-r", "-z", ref, "gh-pages/MAM-with-doc/foi").split(
        b"\0"
    ):
        if item:
            meta, name = item.decode().split("\t", 1)
            entries[name] = meta.split()[2]
    all_outputs[ref] = entries
assert all_outputs[BASE].keys() == all_outputs[HEAD].keys()
changed_outputs = [
    name
    for name in all_outputs[BASE]
    if all_outputs[BASE][name] != all_outputs[HEAD][name]
]
assert changed_outputs == [path]
for name in ["py/author_misc/mam4sef_index.py", "py/main_0_mega.py"]:
    trees = [ast.parse(text(ref, name)) for ref in [BASE, HEAD]]
    for t in trees:
        if (
            isinstance(t.body[0], ast.Expr)
            and isinstance(t.body[0].value, ast.Constant)
            and isinstance(t.body[0].value.value, str)
        ):
            t.body.pop(0)
    assert ast.dump(trees[0]) == ast.dump(trees[1]), name
name = "in/phonetic_mam_display_corrections.json"
configs = [json.loads(text(ref, name)) for ref in [BASE, HEAD]]
for key, oldvalue in configs[0]["chapters"].items():
    assert (
        configs[1]["chapters"][key].replace(
            "https://github.com/bdenckla/MAM-basics/blob/" + ARCHIVE + "/", ""
        )
        == oldvalue
    )
for c in configs:
    c.pop("chapters")
assert configs[0] == configs[1]
deleted = (
    git("diff", "--diff-filter=D", "--name-only", "-z", BASE, HEAD)
    .decode()
    .strip("\0")
    .split("\0")
)
assert len(deleted) == 16
archive_blobs = {}
for name in deleted:
    blob = git("rev-parse", ARCHIVE + ":" + name).decode().strip()
    assert blob == git("rev-parse", BASE + ":" + name).decode().strip()
    archive_blobs[name] = blob
changed = (
    git("diff", "--diff-filter=AM", "--name-only", "-z", BASE, HEAD)
    .decode()
    .strip("\0")
    .split("\0")
)
targets = set()
for name in changed:
    if not name.endswith((".md", ".py", ".json")):
        continue
    for sha, target in re.findall(
        r'https://github\.com/bdenckla/MAM-basics/blob/([0-9a-f]{40})/([^\s)\]`"<>]+)',
        text(HEAD, name),
    ):
        target = target.split("#", 1)[0].rstrip(".,;")
        subprocess.run(
            ["git", "cat-file", "-e", sha + ":" + target],
            check=True,
            capture_output=True,
        )
        targets.add((sha, target))
result = dict(
    result="PASS",
    base=BASE,
    head=HEAD,
    index_rows=26,
    preserved="Destinations, order, labels, description text and inline markup exact after serializer whitespace folding.",
    unchanged_other_foi_outputs=len(all_outputs[HEAD]) - 1,
    comment_docstring_only_ASTs=2,
    phonetic_approval_changes="Only archival URL prefixes in three nonempty approval strings; all other configuration unchanged.",
    retired_documents=len(deleted),
    archive_commit=ARCHIVE,
    archive_blobs=archive_blobs,
    verified_immutable_targets=len(targets),
    targets=sorted(targets),
    limits="Local tracked-file/archival integrity only; no repeated external issue audit or maintenance finding adjudication, broad suite, source/editorial or visual/browser claim.",
)
(OUT / "independent-result.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
)
print(
    json.dumps(
        {k: v for k, v in result.items() if k not in {"archive_blobs", "targets"}},
        ensure_ascii=False,
        indent=2,
    )
)

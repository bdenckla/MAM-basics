"""Adapt inspected prior controls to this exact frozen window."""

from pathlib import Path

ROOT = Path(__file__).resolve().parent
OLD = Path("/workspace/scratch/basics-4214fd93")
SOURCE = "9b5086dc6f8543dba99f855851f9ccc9f625e9b3"
PARENT = "04d8c567659353f0742b659d27b12846ad55d9dd"
for name in ("setup.py", "run.py", "publish.py", "js-probe.cjs"):
    code = (OLD / name).read_text(encoding="utf-8")
    code = code.replace("4214fd938d0bfaa92e693f09bfbc1b7207e0a451", SOURCE)
    code = code.replace("5a1df63a8907752324bf61c50d17cc154f7d39cb", PARENT)
    code = code.replace("/workspace/scratch/basics-4214fd93", str(ROOT))
    code = code.replace(
        "Record bounded November 13 23:00 UTC endpoint screen",
        "Record bounded November 14 00:00 UTC cycle screen",
    )
    code = code.replace("assert.equal(count, 2);", "assert(count > 0);")
    (ROOT / name).write_text(code, encoding="utf-8", newline="\n")

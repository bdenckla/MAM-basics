"""Keep future cleanup control metadata out of the frozen public evidence."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "evidence"
record = json.loads((ROOT / "publication-prepared.json").read_bytes())
archive = ROOT / "receipts/doc" / record["archive"]["path"]
preserved = ROOT / "first-preparation"
assert not preserved.exists()
preserved.mkdir()
for p in (archive, ROOT / "publication-prepared.json"):
    shutil.copy2(p, preserved / p.name)


def dump(value):
    return (json.dumps(value, indent=2) + "\n").encode("utf-8")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


note = {
    "observed_utc": datetime.now(timezone.utc).isoformat(),
    "adjustment": "Omitted the unexecuted future cleanup helper from the public archive because it carries unrelated private home metadata. The inspected helper remains available for later owned cleanup; only its archive inclusion changed.",
    "initial_preparation_preserved_locally": str(preserved),
    "product_checks_repeated": False,
    "finalization_command": [
        "/workspace/MAM-basics/.venv/bin/python",
        "-B",
        str(ROOT / "finalize.py"),
    ],
}
(OUT / "preparation-adjustment.json").write_bytes(dump(note))
with zipfile.ZipFile(archive) as z:
    payload = {
        name: z.read(name)
        for name in z.namelist()
        if name not in {"manifest.json", "checkers/window-controls.py"}
    }
for p in OUT.iterdir():
    if p.is_file():
        payload[p.name] = p.read_bytes()
for name in ("prepare.py", "finalize.py"):
    payload["checkers/" + name] = (ROOT / name).read_bytes()
payload["manifest.json"] = dump(
    {
        name: {"bytes": len(raw), "sha256": sha(raw)}
        for name, raw in sorted(payload.items())
    }
)
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as z:
    for name, raw in sorted(payload.items()):
        z.writestr(name, raw)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist()))
    manifest = json.loads(z.read("manifest.json"))
    assert set(z.namelist()) == set(manifest) | {"manifest.json"}
    for name, entry in manifest.items():
        assert (
            len(z.read(name)) == entry["bytes"] and sha(z.read(name)) == entry["sha256"]
        )
record.update(
    archive={
        "path": archive.name,
        "bytes": archive.stat().st_size,
        "sha256": sha(archive.read_bytes()),
        "payload_files": len(payload) - 1,
    },
    prepared_utc=datetime.now(timezone.utc).isoformat(),
)
(ROOT / "publication-prepared.json").write_bytes(dump(record))
print(json.dumps(record, indent=2))

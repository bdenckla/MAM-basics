"""Freeze completed evidence and prepare exactly three receipt paths."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "evidence"
TREE = ROOT / "head"
RECEIPTS = ROOT / "receipts"
BASE = "4214fd938d0bfaa92e693f09bfbc1b7207e0a451"
SOURCE = "9b5086dc6f8543dba99f855851f9ccc9f625e9b3"
PARENT = "04d8c567659353f0742b659d27b12846ad55d9dd"
BRANCH = "review-hourly-20261113-7173440e-basics-receipts"
NAME = "review-hourly-2026-11-14-9b5086dc-basics"


def git(*args, tree=TREE):
    return subprocess.check_output(["git", "-C", str(tree), *args])


def dump(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


assert git("rev-parse", "HEAD").decode().strip() == SOURCE
assert not git("status", "--porcelain=v1", "-z")
assert git("rev-parse", "HEAD", tree=RECEIPTS).decode().strip() == PARENT
assert git("branch", "--show-current", tree=RECEIPTS).decode().strip() == BRANCH
assert not git("status", "--porcelain=v1", "-z", tree=RECEIPTS)
stages = {}
for name in (
    "black",
    "gen-site",
    "tests",
    "html",
    "probes",
    "javascript",
    "scratch-black",
):
    result = json.loads((OUT / (name + ".json")).read_bytes())
    assert result["exit"] == (1 if name == "html" else 0)
    assert (
        not (OUT / (name + ".diff")).read_bytes()
        and not (OUT / (name + ".status")).read_bytes()
    )
    stages[name] = result
probe = json.loads((OUT / "probe-result.json").read_bytes())
js = json.loads((OUT / "js-result.json").read_bytes())
old_row_bytes = {
    line
    for line in git("show", BASE + ":gh-pages/stress-helpers/index.html").splitlines()
    if line.startswith(b"<tr data-filter=")
}
new_row_bytes = {
    line
    for line in (TREE / "gh-pages/stress-helpers/index.html").read_bytes().splitlines()
    if line.startswith(b"<tr data-filter=")
}
assert len(old_row_bytes & new_row_bytes) == probe["unchanged_prior_rows"]
(OUT / "row-byte-preservation.json").write_bytes(
    dump(
        {
            "base": BASE,
            "source": SOURCE,
            "old_rows": len(old_row_bytes),
            "new_rows": len(new_row_bytes),
            "identical_source_rows": len(old_row_bytes & new_row_bytes),
        }
    )
)
assert "13 passed" in (OUT / "tests.log").read_text(encoding="utf-8")
html_log = (OUT / "html.log").read_text(encoding="utf-8")
assert "Found 4 issue(s)." in html_log
assert html_log.count("orphan image: ") == 4
css_references = int(
    re.search(r"Informational: (\d+) undefined CSS class reference", html_log)[1]
)
admission = json.loads((OUT / "admission.json").read_bytes())
start = admission["observed_utc"]
finish = stages["javascript"]["finished_utc"]
date = finish[:10]
disposition = {
    "source": SOURCE,
    "base": BASE,
    "requested_cycle": "2026-11-14 00:00 UTC",
    "actual_execution_start_utc": start,
    "actual_focused_finish_utc": finish,
    "outcome": "No consequential introduced defect established; no product repair.",
    "mechanics": "Optional location participates in comparison identity, escaped visible text and lowercased escaped crop alt. Existing instance/strand separation, exact category/source-set membership and supplemental crop behavior retained.",
    "source_limits": "Printed readings, old source revisions, MAM lag, thirteen-case census and existing issue interpretation remain owner-attributed research. No new source/image editorial or manuscript judgment.",
    "retained_html_failure": f"HTML validator exits 1 for four known retained orphan Decalogue PNGs; {css_references} CSS references informational. No cleanup or HTML-clean claim.",
    "overall_reviewed": "210affe3ac2931473bead0de839be0de08309e3d",
    "broad_tested": "9ed47c6e8999ecaf56031e9b3f524bee6e01507a",
    "preservation": "All earlier status bytes/rows, pending gaps, immutable receipts, November 13 nightly and Windows 3030161007bc393f554cf0c95cf819ed4d81a93c evidence retained from exact parent.",
    "limits": "No browser, HP/laptop, full-suite/mega/nightly rerun, Private review, hbofonts work, font/baseline acceptance, source refresh, main/shared integration, dispatch, deployment or scheduling. Cross-machine ownership unverified.",
    "publication": "Preparation only; push and cleanup are separate later publication.json/closeout.json records.",
    "initial_read_only_lookups": "Some discovery commands returned nonzero for absent paths or missing optional live configuration; no source writes resulted. Maintained check failure remains separately recorded.",
}
(OUT / "disposition.json").write_bytes(dump(disposition))
completed = {
    "state": "completed",
    "source": SOURCE,
    "completed_utc": datetime.now(timezone.utc).isoformat(),
    "stages": stages,
    "outcome": disposition["outcome"],
    "known_failure": disposition["retained_html_failure"],
}
(ROOT / "stage.json").write_bytes(dump(completed))
(OUT / "stage.json").write_bytes(dump(completed))
payload = {p.name: p.read_bytes() for p in OUT.iterdir() if p.is_file()}
for name in (
    "bootstrap.py",
    "setup.py",
    "run.py",
    "probe.py",
    "js-probe.cjs",
    "prepare.py",
    "publish.py",
):
    payload["checkers/" + name] = (ROOT / name).read_bytes()
for source, name in (
    (Path("/workspace/scratch/admit_window_20261112.py"), "admit.py"),
):
    payload["checkers/" + name] = source.read_bytes()
payload["manifest.json"] = dump(
    {
        name: {"bytes": len(raw), "sha256": sha(raw)}
        for name, raw in sorted(payload.items())
    }
)
archive = RECEIPTS / "doc" / (NAME + "-evidence.zip")
assert not archive.exists()
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as z:
    for name, raw in sorted(payload.items()):
        z.writestr(name, raw)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist()))
    manifest = json.loads(z.read("manifest.json"))
    assert set(z.namelist()) == set(manifest) | {"manifest.json"}
    for name, entry in manifest.items():
        assert (
            len(z.read(name)) == entry["bytes"] and sha(z.read(name)) == entry["sha256"]
        )
report = f"""# Bounded Basics screen, November 14, 2026, 00:00 UTC cycle

State: completed {date}; focused technical review, no product repair

Reviewed `{BASE}` → `{SOURCE}`: **one commit / seven paths**, 41 insertions / 15 deletions. No consequential introduced defect established. The optional `location` field distinguishes occurrences in grouping, displays an escaped label and supplies lowercased escaped crop alt text. The new Koren Jeremiah 22:23 record, two revised Simanim Tanakh records and Ruth crop replacement agree with the committed inputs. These owner-selected readings and notes were preserved without editorial adjudication.

All **{sum(probe['edition_records'].values())} edition records** ({probe['edition_records']['koren']} Koren / {probe['edition_records']['simanim-tanakh']} Simanim Tanakh), **{probe['rows']} rows** ({probe['shared']} shared / {probe['single']} single) and **{probe['populated_choices']} populated exact-set menu choices** reconcile independently. All {probe['unchanged_prior_rows']} unaffected prior rows remain byte-identical. `gen-site --trust-surveys` reproduces tracked outputs exactly; changed-source Black and **13 selected site/style/prose tests** pass. HTML validation **exits 1** for the same four retained orphan Decalogue crops, with {css_references} informational CSS references.

Independent checks pass for {probe['local_attributes']} local attributes, public MAM body/qere destinations, {probe['pngs']} PNGs / {probe['linked_images']} linked images, six invalid supplemental-crop cases rejected before output, and ten valid mechanical cases. Different locations remain separate, equal/absent locations merge across editions, instance/strand distinctions persist, markup/quotes/ampersands are escaped, Scripture codepoints survive unchanged, and supplemental crops preserve edition membership. The actual unchanged `controls.js` passes **{js['query_group_combinations']:,} query/group combinations through each of two handlers**, including location searches, size/reset and image toggles, in a minimal Node DOM.

Actual admitted execution began **{start}**; focused checks finished **{finish}**. The requested November 14 cycle label is distinct from those actual UTC dates. The [evidence archive]({archive.name}) retains command arrays, UTC times, logs, complete textual endpoint/generated diffs, statuses, checker scripts and committed PNG identities/hashes. It contains no crop-content copies. No browser, layout, accessibility-tree, font, live source, printed-source editorial or manuscript verification is claimed; source revisions, census and existing issue interpretation remain attributed research.

Receipt parent `{PARENT}` preserves all earlier status bytes, pending gaps, immutable receipts and November 13 nightly/Windows evidence. Overall reviewed `210affe3ac2931473bead0de839be0de08309e3d` and broad-tested `9ed47c6e8999ecaf56031e9b3f524bee6e01507a` remain unchanged. No broad rerun, Private/hbofonts work, main/shared integration, dispatch, deployment or scheduling. Publication and cleanup are separate later closeout steps; cross-machine ownership is unverified.
"""
(RECEIPTS / "doc" / (NAME + ".md")).write_text(report, encoding="utf-8", newline="\n")
status = RECEIPTS / "doc/review-trial-status.md"
before = status.read_text(encoding="utf-8")
section = f"""## Bounded screen, 2026-11-14 00:00 UTC cycle, 9b5086dc

Reviewed `{BASE}` → `{SOURCE}`: one commit / seven paths; no consequential introduced defect or product repair. Location grouping/escaping and new/revised rows reconcile across {sum(probe['edition_records'].values())} edition records, {probe['rows']} rows ({probe['shared']} shared/{probe['single']} single) and {probe['populated_choices']} menu choices; {probe['unchanged_prior_rows']} unaffected prior rows remain exact. gen-site exact; Black and 13 focused tests pass. HTML exits 1 for four retained orphan crops ({css_references} informational CSS references). Independent {probe['local_attributes']}-local-attribute, {probe['pngs']}-PNG/{probe['linked_images']}-linked, six invalid-input rejection, ten valid mechanical and {js['query_group_combinations']:,} actual-JS combination checks pass. No browser/new source/editorial judgment. Actual admitted start `{start}`; focused finish `{finish}`. [Receipt]({NAME}.md), [evidence]({archive.name}).

Receipt parent `{PARENT}` preserves historical rows, pending windows, immutable receipts and November 13 nightly/Windows evidence. Overall reviewed `210affe3ac2931473bead0de839be0de08309e3d` and broad-tested `9ed47c6e8999ecaf56031e9b3f524bee6e01507a` remain unchanged. Preparation only; publication/cleanup have separate later evidence. No Private, hbofonts, main/shared/deployment or schedule work.

"""
anchor = "## Bounded screen, 2026-11-13 23:00 UTC cycle, 4214fd93"
assert before.count(anchor) == 1
after = before.replace(anchor, section + anchor, 1)
table = "| Anchor | Commit/result |\n| --- | --- |\n"
rows = f'| Bounded screen 9b5086dc, 2026-11-14 00:00 UTC cycle | `{BASE}` → `{SOURCE}`; one commit / seven paths; no consequential defect or repair. Actual focused completion {finish}. [Receipt]({NAME}.md). |\n| Focused evidence 9b5086dc | gen-site exact; 13 tests/Black pass; HTML exit 1 for four retained orphan crops. {sum(probe["edition_records"].values())} records/{probe["rows"]} rows/{probe["populated_choices"]} choices; {probe["local_attributes"]} local attributes; {probe["pngs"]} PNGs/{probe["linked_images"]} linked; six rejection/ten valid cases; {js["query_group_combinations"]:,} Node combinations. [Evidence]({archive.name}). |\n'
assert after.count(table) == 1
after = after.replace(table, table + rows, 1)
assert after.replace(section, "", 1).replace(rows, "", 1) == before
status.write_text(after, encoding="utf-8", newline="\n")
paths = sorted(
    [
        "doc/" + NAME + ".md",
        "doc/" + NAME + "-evidence.zip",
        "doc/review-trial-status.md",
    ]
)
changed = set(
    filter(None, git("diff", "--name-only", "-z", tree=RECEIPTS).decode().split("\0"))
) | set(
    filter(
        None,
        git("ls-files", "--others", "--exclude-standard", "-z", tree=RECEIPTS)
        .decode()
        .split("\0"),
    )
)
assert changed == set(paths)
git("diff", "--check", tree=RECEIPTS)
record = {
    "branch": BRANCH,
    "parent": PARENT,
    "source": SOURCE,
    "paths": paths,
    "archive": {
        "path": archive.name,
        "bytes": archive.stat().st_size,
        "sha256": sha(archive.read_bytes()),
        "payload_files": len(payload) - 1,
    },
    "prepared_utc": datetime.now(timezone.utc).isoformat(),
}
(ROOT / "publication-prepared.json").write_bytes(dump(record))
print(json.dumps(record, indent=2))

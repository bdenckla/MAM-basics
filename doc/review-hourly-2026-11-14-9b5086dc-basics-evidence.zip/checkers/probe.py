"""Independent named-field source/DOM oracle and bounded mechanical probes."""

from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from urllib.parse import unquote, urlsplit

from lxml import html
from PIL import Image

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "head"
OUT = ROOT / "evidence"
BASE = "4214fd938d0bfaa92e693f09bfbc1b7207e0a451"
SOURCE = "9b5086dc6f8543dba99f855851f9ccc9f625e9b3"
PARENT = "04d8c567659353f0742b659d27b12846ad55d9dd"
sys.path.insert(0, str(TREE / "py"))  # Disposable scratch harness only.
from author_site import stress_helper_comparison as renderer
from mb_cmn import uni_denorm

FIELDS = (
    "book",
    "chapter",
    "verse",
    "strand",
    "instance",
    "location",
    "mam",
    "printed",
    "verse_href",
    "category",
)


def git(*args):
    return subprocess.check_output(["git", "-C", str(TREE), *args])


def save(name, value):
    (OUT / name).write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def text(node):
    return " ".join(node.text_content().split())


def ident(record):
    return tuple(record.get(k) for k in FIELDS)


def crops(sources):
    return [
        (edition, p)
        for edition in ("koren", "simanim-tanakh")
        for p in sources.get(edition, {}).get("crops", [])
        + [
            p
            for r in sources.values()
            for p in r.get("comparison_crops", {}).get(edition, [])
        ]
    ]


def check_crops(row, sources):
    record = next(iter(sources.values()))
    expected = crops(sources)
    anchors = row.xpath('./td[@class="scan"]/a')
    assert len(anchors) == len(expected)
    ref = text(row.xpath("./th/a")[0])
    if record.get("location"):
        ref += ", " + record["location"].lower()
    for anchor, (edition, path) in zip(anchors, expected):
        full, short = (
            ("Koren", "Koren")
            if edition == "koren"
            else ("the Simanim Tanakh", "SimTan")
        )
        assert anchor.get("href") == path and anchor.xpath("./img/@src") == [path]
        assert anchor.xpath("./img/@alt") == [full + " scan crop for " + ref]
        assert anchor.xpath("./img/@loading") == ["lazy"] and anchor.xpath(
            "./img/@decoding"
        ) == ["async"]
        assert [text(n) for n in anchor.xpath('./span[@class="source"]')] == (
            [short] if len({e for e, _ in expected}) > 1 else []
        )


assert git("rev-parse", "HEAD").decode().strip() == SOURCE
assert not git("status", "--porcelain=v1", "-z")
changed = [
    p for p in git("diff", "--name-only", "-z", BASE, SOURCE).decode().split("\0") if p
]
assert len(changed) == 7
git("diff", "--check", BASE, SOURCE)
(OUT / "endpoint.diff").write_bytes(git("diff", BASE, SOURCE))
(OUT / "commits.txt").write_bytes(git("log", "--format=fuller", BASE + ".." + SOURCE))
identities = {}
for p in changed:
    identities[p] = {}
    for ref in (BASE, SOURCE):
        result = subprocess.run(
            ["git", "-C", str(TREE), "show", ref + ":" + p], capture_output=True
        )
        identities[p][ref] = {
            "exists": result.returncode == 0,
            "bytes": len(result.stdout),
            "sha256": (
                hashlib.sha256(result.stdout).hexdigest()
                if result.returncode == 0
                else None
            ),
        }
save("identities.json", identities)

inputs, groups, deltas = {}, {}, []
for edition in ("koren", "simanim-tanakh"):
    p = "in/stress-helpers/" + edition + ".json"
    current = json.loads((TREE / p).read_bytes())
    old = json.loads(git("show", BASE + ":" + p))
    assert {k: v for k, v in current.items() if k != "differences"} == {
        k: v for k, v in old.items() if k != "differences"
    }
    old_records = {
        tuple(r.get(k) for k in FIELDS if k != "location"): r
        for r in old["differences"]
    }
    for record in current["differences"]:
        key = tuple(record.get(k) for k in FIELDS if k != "location")
        before = old_records.pop(key, None)
        if before != record:
            deltas.append({"edition": edition, "before": before, "after": record})
        if before is not None:
            allowed = (
                {"location", "notes", "comparison_crops"}
                if edition == "simanim-tanakh"
                and (record["book"], record["chapter"], record["verse"])
                in {("Jeremiah", 22, 23), ("Ruth", 2, 9)}
                else set()
            )
            assert {k: v for k, v in before.items() if k not in allowed} == {
                k: v for k, v in record.items() if k not in allowed
            }
        assert all(uni_denorm.has_std_mark_order(record[k]) for k in ("mam", "printed"))
        assert edition not in groups.setdefault(ident(record), {})
        groups[ident(record)][edition] = record
    assert not old_records
    inputs[edition] = current
assert len(deltas) == 3
assert sum(d["before"] is None for d in deltas) == 1
save("data-deltas.json", deltas)

target = TREE / "gh-pages/stress-helpers/index.html"
new_raw = target.read_bytes()
doc = html.fromstring(new_raw)
rows = doc.xpath('//table[@id="observations"]/tbody/tr')
assert len(rows) == len(groups)
ids = doc.xpath("//*[@id]/@id")
assert len(ids) == len(set(ids))
remaining = dict(groups)
counts, memberships = Counter(), Counter()
row_evidence, js_rows, linked = [], [], set()
cache = {}


def page(path):
    path = path.resolve()
    if path not in cache:
        cache[path] = html.fromstring(path.read_bytes())
    return cache[path]


def qere(node):
    node = deepcopy(node)
    for ketiv in node.xpath('.//span[@class="mam-kq-k"]'):
        ketiv.drop_tree()
    return text(node).replace("[", "").replace("]", "")


for row in rows:
    forms = row.xpath('.//span[@class="hebrew"]/text()')
    href = row.xpath("./th/a/@href")
    small = [text(n) for n in row.xpath("./th/small")]
    candidates = []
    for key, sources in remaining.items():
        r = next(iter(sources.values()))
        labels = ([f"Instance {r['instance']}"] if r.get("instance") else []) + (
            [r["location"]] if r.get("location") else []
        )
        if (
            [r["mam"], r["printed"]] == forms
            and [r["verse_href"]] == href
            and labels == small
            and row.xpath("./th/bdi/text()")
            == ([r["strand"]] if r.get("strand") else [])
        ):
            candidates.append((key, sources))
    assert len(candidates) == 1
    key, sources = candidates[0]
    remaining.pop(key)
    r = next(iter(sources.values()))
    suffix = {
        frozenset(["koren"]): "Kor",
        frozenset(["simanim-tanakh"]): "Sim",
        frozenset(["koren", "simanim-tanakh"]): "KorSim",
    }[frozenset(sources)]
    expected_filter = r["category"] + "-" + suffix
    assert row.get("data-filter") == expected_filter
    counts[expected_filter] += 1
    memberships[len(sources)] += 1
    assert row.xpath('./th/span[@class="source"]/@title') == [
        s["scan"] for s in sources.values()
    ]
    assert [text(n) for n in row.xpath('.//span[@class="edition"]')] == [
        "MAM",
        " / ".join("Koren" if e == "koren" else "SimTan" for e in sources),
    ]
    check_crops(row, sources)
    linked.update(p for _, p in crops(sources))
    loc = urlsplit(r["verse_href"])
    anchors = page(target.parent / unquote(loc.path)).xpath(
        "//*[@id=$ident]", ident=loc.fragment
    )
    assert len(anchors) == 1 and " ".join(r["mam"].split()) in qere(
        anchors[0].getparent()
    )
    assert [text(n) for n in row.xpath('./td[@class="difference"]/p')] == list(
        dict.fromkeys(
            n["text"] + (" " + n.get("label", "MAM doc-note") if n.get("href") else "")
            for s in sources.values()
            for n in s.get("notes", [])
        )
    )
    row_evidence.append(
        {
            "identity": dict(zip(FIELDS, key)),
            "editions": list(sources),
            "filter": expected_filter,
            "crops": crops(sources),
        }
    )
    js_rows.append(
        {
            "filter": expected_filter,
            "category": r["category"],
            "editions": list(sources),
            "cells": [text(c) for c in row],
        }
    )
assert not remaining
options = doc.xpath('//*[@id="filter"]/option')
assert (
    options[0].get("value") == ""
    and text(options[0]) == f"All differences ({len(rows)})"
)
assert {o.get("value") for o in options[1:]} == set(counts)
assert all(text(o).endswith(f"({counts[o.get('value')]})") for o in options[1:])
old_doc = html.fromstring(git("show", BASE + ":gh-pages/stress-helpers/index.html"))
old_rows = old_doc.xpath('//table[@id="observations"]/tbody/tr')
serialized = {html.tostring(r) for r in rows}
unchanged_rows = sum(html.tostring(r) in serialized for r in old_rows)
assert unchanged_rows == len(old_rows) - 2
assert (
    git("show", BASE + ":gh-pages/stress-helpers/controls.js")
    == (target.parent / "controls.js").read_bytes()
)
local, external = 0, set()
for node in doc.xpath("//*[@href or @src]"):
    for attr in ("href", "src"):
        value = node.get(attr)
        if value is None:
            continue
        loc = urlsplit(value)
        if loc.scheme or loc.netloc:
            external.add(value)
            continue
        dest = (target.parent / unquote(loc.path)).resolve() if loc.path else target
        assert dest.is_relative_to(TREE / "gh-pages") and dest.is_file(), value
        if loc.fragment:
            assert page(dest).xpath(
                "//*[@id=$ident or @name=$ident]", ident=unquote(loc.fragment)
            ), value
        local += 1
pngs = {}
for p in sorted((target.parent / "img").glob("*.png")):
    with Image.open(p) as image:
        assert image.format == "PNG"
        pngs["img/" + p.name] = {
            "width": image.width,
            "height": image.height,
            "bytes": p.stat().st_size,
            "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
        }
        image.verify()
orphans = sorted(pngs.keys() - linked)
assert orphans == [
    "img/koren-deuter-5-13-A5-D-281-370-1.png",
    "img/koren-deuter-5-13-A5-D-281-370-2.png",
    "img/simanim-tanakh-deuter-5-6-A9-A5-10C-0351-1685-1.png",
    "img/simanim-tanakh-exodus-20-2-A9-A2-10C-0350-1684-1.png",
]

seed = deepcopy(inputs["simanim-tanakh"]["differences"][0])
seed.pop("comparison_crops", None)
seed.pop("instance", None)
seed.pop("strand", None)
seed.pop("location", None)
valid_crop = inputs["koren"]["differences"][0]["crops"][0]
synthetic = []
for field, values, expected_rows in [
    ("location", (None, None), 1),
    ("location", ("Opening qere", "Opening qere"), 1),
    ("location", ("First occurrence", "Second occurrence"), 2),
    ("instance", (1, 2), 2),
    ("strand", ("strand-one", "strand-two"), 2),
]:
    a, b = deepcopy(seed), deepcopy(seed)
    for r, value in ((a, values[0]), (b, values[1])):
        if value is not None:
            r[field] = value
    output = html.fromstring(
        renderer._document(
            {"coverage": [], "source_notes": []},
            {
                "koren": {"edition_credit": "", "differences": [a]},
                "simanim-tanakh": {"edition_credit": "", "differences": [b]},
            },
            "scratch grouping",
        )
    )
    observed = output.xpath('//table[@id="observations"]/tbody/tr')
    assert len(observed) == expected_rows
    assert [r.get("data-filter") for r in observed] == [
        seed["category"] + s
        for s in (["-KorSim"] if expected_rows == 1 else ["-Kor", "-Sim"])
    ]
    synthetic.append({"field": field, "values": values, "rows": len(observed)})

escaped = deepcopy(seed)
escaped["location"] = 'Opening <em>QERE</em> "quoted" & apostrophe\''
escaped["comparison_crops"] = {"koren": [valid_crop]}
raw = renderer._row({"simanim-tanakh": escaped}, seed["category"] + "-Sim")
row = html.fromstring(raw)
assert row.xpath("./th/small/text()") == [escaped["location"]]
assert not row.xpath("./th/small/*")
assert "&lt;em&gt;" in raw and "&quot;" in raw and "&amp;" in raw and "&#x27;" in raw
assert row.xpath('.//span[@class="hebrew"]/text()') == [seed["mam"], seed["printed"]]
check_crops(row, {"simanim-tanakh": escaped})
synthetic.append(
    {
        "field": "escaped-location",
        "text": escaped["location"],
        "raw_markup_escaped": True,
        "scripture_codepoints_unchanged": True,
    }
)
for mapping in (
    {},
    {"koren": [valid_crop, valid_crop]},
    {"simanim-tanakh": list(seed["crops"])},
    {"simanim-tanakh": list(seed["crops"]), "koren": [valid_crop]},
):
    r = deepcopy(seed)
    if mapping:
        r["comparison_crops"] = mapping
    renderer._check({"differences": [r]}, target.parent)
    check_crops(
        html.fromstring(renderer._row({"simanim-tanakh": r}, r["category"] + "-Sim")),
        {"simanim-tanakh": r},
    )
    synthetic.append({"comparison_crops": mapping, "membership": "Sim"})

invalid = {
    "unknown-edition": {"unknown": [valid_crop]},
    "empty": {"koren": []},
    "traversal": {"koren": ["img/../outside.png"]},
    "absolute": {"koren": [str(target.parent / valid_crop)]},
    "missing": {"koren": ["img/nonexistent-review-probe.png"]},
    "wrong-directory": {"koren": ["elsewhere/crop.png"]},
}
rejected = []
with TemporaryDirectory(prefix="bounded-crop-probe-", dir=ROOT) as temporary:
    scratch = Path(temporary)
    for name, mapping in invalid.items():
        r = deepcopy(seed)
        r["comparison_crops"] = mapping
        for edition, data in {
            "koren": {"differences": []},
            "simanim-tanakh": {"differences": [r]},
            "common": {"coverage": [], "source_notes": []},
        }.items():
            (scratch / (edition + ".json")).write_text(
                json.dumps(data), encoding="utf-8", newline="\n"
            )
        try:
            renderer.render(
                scratch, target.parent, generated_comment="scratch rejection"
            )
        except (ValueError, FileNotFoundError) as error:
            rejected.append(
                {
                    "case": name,
                    "exception": type(error).__name__,
                    "message": str(error).replace(str(TREE), "SOURCE"),
                }
            )
        else:
            raise AssertionError("Invalid input accepted: " + name)
        assert target.read_bytes() == new_raw

workflow = {}
for ref in (PARENT, SOURCE):
    files = [
        p
        for p in git("ls-tree", "-r", "--name-only", "-z", ref, "--", ".github")
        .decode()
        .split("\0")
        if p
    ]
    assert files == [".github/workflows/pages.yml"]
    blob = git("rev-parse", ref + ":.github/workflows/pages.yml").decode().strip()
    assert blob == "18ceb19405424710bda47d9a38c470cc2ed9c385"
    assert b"on:\n  workflow_dispatch:\n" in git(
        "show", ref + ":.github/workflows/pages.yml"
    )
    workflow[ref] = blob
save("rows.json", row_evidence)
save("assets.json", pngs)
save("negative-probes.json", rejected)
save("valid-grouping-probes.json", synthetic)
save(
    "js-input.json",
    {
        "rows": js_rows,
        "options": [o.get("value") for o in options],
        "queries": [
            "Koren",
            "SimTan",
            "Jer 22:23",
            "Ruth 2:9",
            "Opening qere",
            "Second occurrence",
            *[r["cells"][0] for r in js_rows],
        ],
    },
)
save(
    "probe-result.json",
    {
        "observed_utc": datetime.now(timezone.utc).isoformat(),
        "source": SOURCE,
        "base": BASE,
        "changed_paths": len(changed),
        "edition_records": {e: len(d["differences"]) for e, d in inputs.items()},
        "rows": len(rows),
        "shared": memberships[2],
        "single": memberships[1],
        "filter_counts": counts,
        "populated_choices": len(options) - 1,
        "unchanged_prior_rows": unchanged_rows,
        "local_attributes": local,
        "external_links_not_fetched": sorted(external),
        "pngs": len(pngs),
        "linked_images": len(linked),
        "retained_orphans": orphans,
        "negative_rejections_before_output": len(rejected),
        "valid_probe_cases": len(synthetic),
        "workflow": workflow,
        "limitation": "Mechanical source/DOM/image integrity only; no browser or source-image editorial reading.",
    },
)
assert not git("status", "--porcelain=v1", "-z")
print((OUT / "probe-result.json").read_text(encoding="utf-8"))

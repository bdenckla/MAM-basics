"""Record final source facts from completed focused work; no additional generator run."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/workspace/MAM-basics')
out = Path(__file__).parent
base = 'b85275921e02f4b1475446908d5cb997ca0083f7'
tip = '3ae838d11db68b99c1d7a7019026470657b41fef'
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root)
assert git('rev-parse', 'HEAD').decode().strip() == tip
assert not git('status', '--porcelain', '-z')
intro = json.loads((root / 'in/mam-ws-bot-edits/intro-uxlc-name-and-host.json').read_bytes())
intro_counts = {}
for slug, edits in intro['pages'].items():
    old = git('show', base + ':in/mam-ws-intro/' + slug + '.mediawiki').decode()
    for edit in edits:
        assert old.count(edit['old']) == 1
        old = old.replace(edit['old'], edit['new'])
    assert old.encode() == (root / 'in/mam-ws-intro' / (slug + '.mediawiki')).read_bytes()
    intro_counts[slug] = len(edits)
manifest = json.loads((root / 'in/mam-ws-intro/manifest.json').read_bytes())
assert len(manifest['pages']) == 13
for slug, value in manifest['pages'].items():
    assert len((root / 'in/mam-ws-intro' / (slug + '.mediawiki')).read_bytes()) == value['size']
pages = json.loads((root / 'in/mam-ws-bot-edits/pages-uxlc-host.json').read_bytes())
payload = {}
for key, page in pages['pages'].items():
    links = 0
    for edit in page['edits']:
        assert edit['old'].endswith('\n') and edit['new'].endswith('\n')
        expected = edit['old'].replace('https://www.hcanat.us/', 'https://tanach.us/').replace('https://hcanat.us/', 'https://tanach.us/')
        assert expected == edit['new']
        links += edit['old'].count('https://www.hcanat.us/') + edit['old'].count('https://hcanat.us/')
    payload[key] = {'base_revision': page['base-revid'], 'edits': len(page['edits']), 'links': links}
assert len(payload) == 4 and sum(v['edits'] for v in payload.values()) == 23 and sum(v['links'] for v in payload.values()) == 24
template_path = 'py/concrete_transcription/ct_page_template.html'
candidate_match = None
candidate = '66ad7750196fcff55abcef09b038fb54e0889d39'
probe = subprocess.run(['git', 'cat-file', '-e', candidate + ':' + template_path], cwd=root, capture_output=True)
if probe.returncode == 0:
    candidate_match = git('show', candidate + ':' + template_path) == (root / template_path).read_bytes()
    assert candidate_match
editor_files = [p for p in (out / 'editor-work').rglob('*') if p.is_file()] + [out / ('editor-page' + str(n) + '.html') for n in (1, 2, 3)]
editor_hashes = {str(path.relative_to(out)): hashlib.sha256(path.read_bytes()).hexdigest() for path in editor_files}
(out / 'editor-output-hashes.json').write_text(json.dumps(editor_hashes, indent=2) + '\n')
facts = {'recorded_utc': datetime.now(timezone.utc).isoformat(), 'base': base, 'tip': tip, 'reachable_commits': git('rev-list', '--reverse', base + '..' + tip).decode().splitlines(), 'paths': len([p for p in git('diff', '--name-only', '-z', base, tip).split(b'\0') if p]), 'mirror_reconstruction': intro_counts, 'mirror_sizes_match': 13, 'pages_payload': payload, 'draft_pr369_template_blob_matches': candidate_match, 'editor_output_files_hashed': len(editor_hashes), 'source_diff_check': 'passed', 'fixture_failures': 'Initial FOI fixture used an invalid BCVT tuple and assumed 39 JSON files instead of 39 books in 24 files. Its first census then stopped on an unclassified cant-all-three node. Corrected the fixture using the canonical locale constructor and explicit combined-cantillation projection. Original diagnostics retained; no product/source repair.', 'live_evidence': 'Owner-reported bot saves/protection/revision/flag checks and Windows browser results remain attributed. No bot command, external source request or browser route was executed by this review.'}
git('diff', '--check', base, tip)
(out / 'source-facts.json').write_text(json.dumps(facts, indent=2) + '\n')
print(json.dumps(facts, indent=2))

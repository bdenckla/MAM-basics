"""Sequential focused FOI and trial-editor regeneration; never calls live fetch."""
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import time

root = Path('/workspace/MAM-basics')
out = Path(__file__).parent
work = out / 'editor-work'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == '3ae838d11db68b99c1d7a7019026470657b41fef'
assert not subprocess.check_output(['git', 'status', '--porcelain', '-z'], cwd=root)
python = '.venv/bin/python'
cli = [python, 'py/main_concrete_transcription.py']
commands = [
    ('foi-selected', [python, 'py/main_foi_features_of_interest.py', '--foi', 'args-foi-holam-before-vav', '--single-threaded']),
    ('foi-full', [python, 'py/main_foi_features_of_interest.py', '--single-threaded']),
    ('editor-level1', cli + ['level1', 'doc/concrete-transcription-2026-11-03/download-image/112-Detail.jpg', str(work)]),
]
for draft in ('1', '2', '3'):
    commands.extend([
        ('editor-draft' + draft, cli + ['draft', str(work), draft]),
        ('editor-shapes' + draft, cli + ['shapes', str(work), draft]),
        ('editor-page' + draft, cli + ['page', str(work), str(out / ('editor-page' + draft + '.html')), draft]),
    ])
    if draft == '1':
        commands.append(('editor-fold', cli + ['fold', str(work), 'doc/concrete-transcription-2026-11-03/edits/ben-edits-1.json', str(work / 'folded-ben-1.json')]))
results = []
for label, command in commands:
    started = time.perf_counter()
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
    item = {'stage': label, 'command': command, 'exit_code': result.returncode, 'seconds': round(time.perf_counter() - started, 3), 'finished_utc': datetime.now(timezone.utc).isoformat()}
    results.append(item)
    (out / 'regeneration-execution.json').write_text(json.dumps(results, indent=2) + '\n')
    diff = subprocess.check_output(['git', 'diff', '--binary'], cwd=root)
    (out / (label + '-tracked.diff')).write_bytes(diff)
    print(json.dumps(item), flush=True)
    if result.returncode or diff:
        raise SystemExit('Focused stage failed or changed tracked output; evidence preserved without restoration.')

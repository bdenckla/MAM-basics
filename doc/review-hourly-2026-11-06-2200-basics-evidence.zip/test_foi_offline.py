"""Selected projection/category contracts and an independent MAM-simple census."""
from collections import Counter
import json
from pathlib import Path
from types import SimpleNamespace
import unicodedata

import pytest

from foi import foi_struct
from foi import foiz_wt_holam_before_vav as foi
from mb_cmn import bib_locales as tbn
from mb_cmn import template_names as names

ROOT = Path('/workspace/MAM-basics')
OUT = Path('/workspace/scratch/review-20261106-2200')
MATCH = '\u05e7\u05b9\u05d5\u05b8'
OTHER = '\u05d0\u05b8\u05d1'


def template(name, **params):
    return {'tmpl_name': name, 'tmpl_params': {key: [value] for key, value in params.items()}}


def found(ep):
    return foi.find_fois_wt({'mroge-minirow': SimpleNamespace(EP=ep), 'mroge-bcvt': tbn.mk_bcvtmam(tbn.ALL_BK39_IDS[0], 1, 1)})


@pytest.mark.parametrize('marks,category', [('\u05b8\u0594', 'Other forms with a mark above vav'), ('\u05b8\u05a5', 'Other forms without a mark above vav'), ('\u05b8\u034f', 'Other forms without a mark above vav'), ('\u05bf', 'Other forms with a mark above vav')])
def test_mark_categories_keep_raw_marks(marks, category):
    rows = found(['\u05e7\u05b9\u034f\u05d5' + marks])
    assert len(rows) == 1 and rows[0][0][1] == category
    assert foi_struct.qtar_qual(rows[0][1]) == {'vav_marks': marks}


@pytest.mark.parametrize('middle', [' ', '\u05be', '\u05c0'])
def test_not_across_atom_boundaries(middle):
    assert found(['\u05e7\u05b9' + middle + '\u05d5']) == []


def test_divine_prefix_and_above_accent():
    rows = found(['\u05d1\u05d9\u05d4\u05b9\u05d5\u05b8\u0594\u05d4'])
    assert rows[0][0][1] == 'The divine name with an accent above vav'
    assert found(['\u05d9\u05d4\u05b9\u05d5\u05b8\u05a5\u05d4'])[0][0][1] == 'The divine name without an accent above vav'


def test_vav_guard_and_duplicate_good_ending():
    with pytest.raises(ValueError, match='U\\+05BA'):
        found(['\u05d5\u05ba\u05d5'])
    assert foi.find_fois_wt({'mroge-minirow': None}) == []


@pytest.mark.parametrize('name', list(names.STRESS_HELPER_TMPL_NAMES))
def test_only_first_stress_form_is_selected(name):
    assert len(found([template(name, **{'1': MATCH, '2': OTHER})])) == 1
    assert found([template(name, **{'1': OTHER, '2': MATCH})]) == []


def test_qere_trivial_ketiv_qamats_combined_and_note_scope():
    assert len(found([template('כו״ק', **{'1': OTHER, '2': MATCH})])) == 1
    assert found([template('כו״ק', **{'1': MATCH, '2': OTHER})]) == []
    assert len(found([template(names.TRIVIAL_QERE, **{'1': MATCH, '2': 'אב', '3': OTHER})])) == 1
    assert found([template(names.TRIVIAL_QERE, **{'1': OTHER, '2': 'אב', '3': MATCH})]) == []
    assert len(found([template(names.QAMATS_VARIANT, **{'ד': MATCH, 'ס': OTHER})])) == 1
    assert found([template(names.QAMATS_VARIANT, **{'ד': OTHER, 'ס': MATCH})]) == []
    assert len(found([template(names.DUAL_CANTILLATION, **{'כפול': MATCH, 'א': OTHER, 'ב': OTHER})])) == 1
    assert found([template(names.DUAL_CANTILLATION, **{'כפול': OTHER, 'א': MATCH, 'ב': MATCH})]) == []
    assert found([template('נוסח', **{'1': OTHER, '2': MATCH})]) == []


def project(node):
    kind = node['type']
    if kind == 'kq':
        qere = [part for part in node['contents'] if part['type'] == 'kq-q']
        assert len(qere) == 1
        return project(qere[0])
    if kind == 'cant-all-three':
        combined = [part for part in node['contents'] if part['type'] == 'cant-combined']
        assert len(combined) == 1
        return project(combined[0])
    if kind in {'kq-k', 'kq-k-velo-q', 'sdt-note', 'good-ending'}:
        return ''
    if kind in {'spi-samekh2', 'spi-samekh3', 'spi-pe2', 'spi-pe3', 'shirah-space', 'spi-invnun'}:
        return ' '
    if kind in {'implicit-maqaf', 'kq-k-velo-q-maq'}:
        return '\u05be'
    if kind in {'lp-paseq', 'lp-legarmeih'}:
        return '\u05c0'
    if kind == 'slh-word':
        return node['slhw-desc-0']
    if kind in {'text', 'verse', 'letter-large', 'letter-small', 'letter-hung', 'kq-trivial', 'kq-q', 'kq-q-velo-k', 'sdt-target', 'silluq-before-meteg', 'scrdfftar', 'cant-combined'}:
        if 'text' in node:
            return node['text']
        return ''.join(project(part) for part in node['contents'])
    raise AssertionError('Unclassified independent MAM-simple structure: ' + kind)


def atoms(text):
    current = []
    for char in text:
        if '\u05d0' <= char <= '\u05ea' or current and unicodedata.category(char).startswith('M'):
            current.append(char)
        elif current:
            yield ''.join(current)
            current = []
    if current:
        yield ''.join(current)


def test_independent_simple_corpus_matches_all_output_rows():
    expected = json.loads((ROOT / 'gh-pages/MAM-with-doc/foi/foi-holam-before-vav.json').read_bytes())
    short = {'Gen': 'G', 'Isa': 'I', 'Prov': 'Pr', 'Lam': 'La', 'Ezek': 'Ee', 'Ps': 'Ps', 'Eccl': 'Ec', 'Esth': 'Es', 'Neh': 'Ne'}
    matches, divine, guard_count, verses = [], {}, 0, 0
    paths = sorted((ROOT / 'MAM-simple/json-vtrad-mam').glob('*.json'))
    assert len(paths) == 24
    book_count = 0
    for path in paths:
        data = json.loads(path.read_bytes())
        books = [book for book in data['contents'] if book['type'] == 'book39']
        for book in books:
            book_count += 1
            for chapter in book['contents']:
                if chapter['type'] != 'chapter': continue
                for verse in chapter['contents']:
                    if verse['type'] != 'verse': continue
                    verses += 1
                    for atom in atoms(project(verse)):
                        groups = []
                        for char in atom:
                            if '\u05d0' <= char <= '\u05ea': groups.append([char, ''])
                            else: groups[-1][1] += char
                        for index, (left, right) in enumerate(zip(groups, groups[1:])):
                            if right[0] != '\u05d5': continue
                            guard_count += left[0] == '\u05d5' and '\u05ba' in left[1]
                            if left[0] == '\u05d5' or '\u05b9' not in left[1]: continue
                            is_divine = ''.join(g[0] for g in groups).endswith('יהוה') and index == len(groups) - 3
                            above = {char for char in right[1] if unicodedata.combining(char) == 230 or char in '\u05b9\u05ba\u05bf\u05c1\u05c2'}
                            if is_divine:
                                # Genesis contains the first example of both categories.
                                if book['osisID'] == 'Gen':
                                    category = 'The divine name with an accent above vav' if any(unicodedata.combining(char) == 230 and '\u0591' <= char <= '\u05af' for char in right[1]) else 'The divine name without an accent above vav'
                                    divine.setdefault(category, {'bcv_short': 'G' + ':'.join(verse['osisID'].split('.')[1:]), 'vav_marks': right[1], 'fp': category, 'r': atom})
                            else:
                                osis = book['osisID']; assert osis in short
                                category = 'Other forms with a mark above vav' if above else 'Other forms without a mark above vav'
                                matches.append({'bcv_short': short[osis] + ':'.join(verse['osisID'].split('.')[1:]), 'vav_marks': right[1], 'fp': category, 'r': atom})
    assert book_count == 39 and guard_count == 0
    actual = matches + list(divine.values())
    normalize = lambda rows: Counter(tuple(row[key] for key in ('bcv_short', 'vav_marks', 'fp', 'r')) for row in rows)
    assert normalize(actual) == normalize(expected)
    assert len(matches) == 17 and len({row['bcv_short'] for row in matches}) == 16 and len(divine) == 2
    (OUT / 'independent-census.json').write_text(json.dumps({'books': 39, 'verses': verses, 'ordinary_occurrences': 17, 'ordinary_verses': 16, 'divine_examples': divine, 'forbidden_vav_pair_count': guard_count, 'source': 'Independent closed MAM-simple projection and Unicode-category clustering; no source normalization.'}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

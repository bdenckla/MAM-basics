"""Pages-mode contracts with every network/save surface replaced by fixtures."""
from copy import deepcopy
import json
from types import SimpleNamespace
from unittest.mock import Mock

import pytest
import requests

import main_ws_bot
from subcommands import ws_bot_pages as bot
from ws import ws_revision_api


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    guard = Mock(side_effect=AssertionError('External traffic is forbidden in this test'))
    monkeypatch.setattr('socket.socket.connect', guard)
    monkeypatch.setattr(requests.sessions.Session, 'request', guard)
    yield
    guard.assert_not_called()


def spec(pages=1):
    return {'summary': 'Fixture summary', 'edit-kind': 'explicit-replacement', 'pages': {
        f'p{i}': {'title': f'Exact title {i}', 'base-revid': 100 + i,
                 'edits': [{'old': f'old {i}', 'new': f'new {i}'}]}
        for i in range(pages)}}


def write_spec(tmp_path, value):
    path = tmp_path / 'edits.json'
    path.write_text(json.dumps(value), encoding='utf-8')
    return str(path)


def test_parser_routes_exact_title_mode_without_chapter_selector():
    args = main_ws_bot.build_parser().parse_args(['pages', '--edits', 'fixture.json', '--no-save'])
    assert args.func is main_ws_bot._run_pages and args.selector_parser is None
    assert args.allow_extra_args and args.no_save


@pytest.mark.parametrize('kind', ['extra-key', 'bad-kind', 'empty-summary', 'empty-pages', 'bad-key', 'bad-title', 'boolean-revid', 'empty-edits', 'empty-old', 'bad-new', 'duplicate-title'])
def test_spec_refuses_invalid_inputs_before_api(tmp_path, kind):
    value = spec(2)
    first = value['pages']['p0']
    if kind == 'extra-key': value['unknown'] = 1
    elif kind == 'bad-kind': value['edit-kind'] = 'invented'
    elif kind == 'empty-summary': value['summary'] = ''
    elif kind == 'empty-pages': value['pages'] = {}
    elif kind == 'bad-key': value['pages']['../escape'] = value['pages'].pop('p0')
    elif kind == 'bad-title': first['title'] = ''
    elif kind == 'boolean-revid': first['base-revid'] = True
    elif kind == 'empty-edits': first['edits'] = []
    elif kind == 'empty-old': first['edits'][0]['old'] = ''
    elif kind == 'bad-new': first['edits'][0]['new'] = None
    else: value['pages']['p1']['title'] = first['title']
    with pytest.raises(SystemExit): bot._read_spec(write_spec(tmp_path, value))


def test_valid_spec_and_exact_occurrence_guards(tmp_path):
    value = spec()
    assert bot._read_spec(write_spec(tmp_path, value)) == value
    edits = [{'old': 'x', 'new': 'y'}]
    assert bot._edited('p0', 'a x b', edits) == 'a y b'
    for text in ('a b', 'x x', 'a y b'):
        with pytest.raises(AssertionError, match='Expected 1 occurrence'):
            bot._edited('p0', text, edits)


def install_client(monkeypatch, pages, *, rejected=None, bodies=None):
    client = Mock()
    identities = {}
    for number, (key, page) in enumerate(pages.items()):
        identity = {'requested_title': page['title'], 'resolved_title': page['title'],
                    'page_id': number + 200, 'revision_id': page['base-revid']}
        if rejected == 'redirect': identity['resolved_title'] = 'Different exact title'
        if rejected == 'chapter': identity['page_id'] = 999
        if rejected == 'stale': identity['revision_id'] += 1
        identities[page['title']] = (identity, None)
    client.by_titles.return_value = identities
    def raw(batch):
        return {item['requested_title']: (item, {
            'revision_id': item['revision_id'], 'revision_timestamp': '2026-11-06T00:00:00Z',
            'content': (bodies or {}).get(item['requested_title'], b'old 0')}) for item in batch}
    client.by_raw_revisions.side_effect = raw
    downloader = Mock()
    downloader.__enter__ = Mock(return_value=downloader)
    downloader.__exit__ = Mock(return_value=False)
    monkeypatch.setattr(bot.polite_download, 'PoliteDownloader', Mock(return_value=downloader))
    monkeypatch.setattr(bot.ws_revision_api, 'ChapterClient', Mock(return_value=client))
    monkeypatch.setattr(bot, '_chapter_page_ids', lambda: {999})
    monkeypatch.setattr(bot.download_wikisource_intro, 'read_manifest', lambda: {'pages': {'intro': {'title': 'Introduction title'}}})
    return client


@pytest.mark.parametrize('kind', ['redirect', 'chapter', 'stale', 'intro'])
def test_base_refusals_precede_content_or_save(monkeypatch, kind):
    pages = spec()['pages']
    if kind == 'intro': pages['p0']['title'] = 'Introduction title'
    client = install_client(monkeypatch, pages, rejected=kind)
    with pytest.raises(SystemExit, match='Refused'):
        bot._base_revisions(pages)
    client.by_raw_revisions.assert_not_called()
    if kind == 'intro': client.by_titles.assert_not_called()


def test_exact_base_bytes_are_revision_pinned(monkeypatch):
    pages = spec()['pages']
    raw = 'source \u05e9\u05b8\u05c1\n'.encode('utf-8')
    client = install_client(monkeypatch, pages, bodies={pages['p0']['title']: raw})
    bases = bot._base_revisions(pages)
    assert bases['p0']['content'] == raw and bases['p0']['revision_id'] == 100
    assert client.by_raw_revisions.call_args.args[0][0]['revision_id'] == 100


def test_save_sends_original_revision_guards_and_exact_text(monkeypatch):
    page = SimpleNamespace(latest_revision_id=301, save=Mock())
    page_factory = Mock(return_value=page)
    monkeypatch.setattr(bot.pywikibot, 'Page', page_factory)
    base = {'title': 'Exact title', 'page_id': 200, 'revision_id': 100,
            'revision_timestamp': '2026-11-06T00:00:00Z'}
    result = bot._save(object(), 'p0', base, 'raw edited text', 'summary')
    assert page.text == 'raw edited text'
    assert page.save.call_args.args == ('summary',)
    assert page.save.call_args.kwargs == {'minor': True, 'apply_cosmetic_changes': False,
                                        'nocreate': True, 'baserevid': 100,
                                        'basetimestamp': base['revision_timestamp']}
    assert result['oldrevid'] == 100 and result['newrevid'] == 301 and not result['verified']
    assert result['title'] == base['title'] and result['pageid'] == 200


def install_run(monkeypatch, tmp_path, count=1):
    value = spec(count)
    bases = {key: {'title': page['title'], 'page_id': 200 + i,
                   'revision_id': page['base-revid'], 'revision_timestamp': '2026-11-06T00:00:00Z',
                   'content': f'old {i}'.encode()} for i, (key, page) in enumerate(value['pages'].items())}
    monkeypatch.setattr(bot, '_RUNS_ROOT', str(tmp_path / 'runs'))
    monkeypatch.setattr(bot.ws_bot_real, 'assert_pywikibot_dir_configured', lambda args: None)
    monkeypatch.setattr(bot, '_base_revisions', lambda pages: bases)
    monkeypatch.setattr(bot, '_report_special_pages', Mock())
    monkeypatch.setattr(bot.pywikibot, 'Site', Mock(return_value=object()))
    def record(_site, key, base, text, summary):
        return {'key': key, 'title': base['title'], 'pageid': base['page_id'],
                'oldrevid': base['revision_id'], 'newrevid': base['revision_id'] + 1000,
                'diff': 'fixture-diff', 'verified': False}
    save = Mock(side_effect=record)
    monkeypatch.setattr(bot, '_save', save)
    return write_spec(tmp_path, value), save, bases


def receipt(tmp_path):
    paths = list((tmp_path / 'runs').glob('*/misc/saved-pages.json'))
    assert len(paths) == 1
    return json.loads(paths[0].read_text(encoding='utf-8'))


def test_no_save_writes_artifacts_without_site_or_verification(monkeypatch, tmp_path):
    path, save, _bases = install_run(monkeypatch, tmp_path)
    verify = Mock()
    monkeypatch.setattr(bot, '_verify', verify)
    with pytest.raises(SystemExit, match='would change'):
        bot.run(path, [], no_save=True)
    save.assert_not_called(); bot.pywikibot.Site.assert_not_called(); verify.assert_not_called()
    assert receipt(tmp_path) == []
    assert list((tmp_path / 'runs').glob('*/base/p0.mediawiki'))[0].read_bytes() == b'old 0'
    assert list((tmp_path / 'runs').glob('*/pages/p0.mediawiki'))[0].read_bytes() == b'new 0'


def test_verification_exception_keeps_saved_identity(monkeypatch, tmp_path):
    path, save, _bases = install_run(monkeypatch, tmp_path)
    monkeypatch.setattr(bot, '_verify', Mock(side_effect=RuntimeError('fixture readback outage')))
    with pytest.raises(RuntimeError, match='readback outage'): bot.run(path, [])
    assert save.call_count == 1
    assert receipt(tmp_path)[0]['newrevid'] == 1100 and not receipt(tmp_path)[0]['verified']


def test_first_save_failure_stops_and_keeps_previous_success(monkeypatch, tmp_path):
    path, save, _bases = install_run(monkeypatch, tmp_path, 3)
    original = save.side_effect
    def fail_second(*args):
        if args[1] == 'p1': raise bot.pywikibot.exceptions.Error('fixture protected page')
        return original(*args)
    save.side_effect = fail_second
    def verify(saved, texts):
        assert [item['key'] for item in saved] == ['p0']
        saved[0]['verified'] = True
        return []
    monkeypatch.setattr(bot, '_verify', verify)
    with pytest.raises(SystemExit, match='save failed'): bot.run(path, [])
    assert [call.args[1] for call in save.call_args_list] == ['p0', 'p1']
    assert receipt(tmp_path)[0]['verified']


@pytest.mark.parametrize('matches', [True, False])
def test_saved_content_must_match_exact_bytes(monkeypatch, matches):
    item = {'key': 'p0', 'title': 'Exact title 0', 'pageid': 200, 'newrevid': 1100, 'verified': False}
    install_client(monkeypatch, spec()['pages'])
    monkeypatch.setattr(bot, '_saved_content', lambda client, identity: b'new 0' if matches else b'different')
    failures = bot._verify([item], {'p0': 'new 0'})
    assert item['verified'] is matches and bool(failures) is not matches


def test_saved_revision_retry_is_bounded_without_sleep(monkeypatch):
    client = Mock()
    client.by_raw_revisions.side_effect = ws_revision_api.ChapterResponseError('fixture replica lag')
    sleep = Mock()
    monkeypatch.setattr(bot.time, 'sleep', sleep)
    identity = {'requested_title': 'Exact title'}
    with pytest.raises(ws_revision_api.ChapterResponseError): bot._saved_content(client, identity)
    assert client.by_raw_revisions.call_count == 4
    assert [call.args[0] for call in sleep.call_args_list] == [5.0, 10.0, 20.0]

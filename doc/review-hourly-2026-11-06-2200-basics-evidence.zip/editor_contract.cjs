// Execute only the actual shared edit callback with instrumented dependencies.
const fs = require('fs');
const cp = require('child_process');
const vm = require('vm');
const crypto = require('crypto');
const path = require('path');
const root = '/workspace/MAM-basics';
const out = '/workspace/scratch/review-20261106-2200';
const template = 'py/concrete_transcription/ct_page_template.html';
const oldText = cp.execFileSync('git', ['show', 'b85275921e02f4b1475446908d5cb997ca0083f7:' + template], {cwd:root, encoding:'utf8'});
const newText = fs.readFileSync(path.join(root, template), 'utf8');
const extract = text => {
  const match = text.match(/function afterEdit\(s\) \{[\s\S]*?\n\}/);
  if (!match) throw Error('Missing shared afterEdit callback');
  return match[0];
};
const oldFn = extract(oldText), newFn = extract(newText);
if (newText.replace(newFn, oldFn) !== oldText) throw Error('An unrelated template change exists');
function run(fn) {
  const trace = [];
  const context = {};
  for (const name of ['updateShape','drawHandles','drawLabels','markChanged','showSelected','save','refreshExport','drawDiff']) context[name] = () => trace.push(name);
  vm.runInNewContext(fn + ';afterEdit({fixture:true});', context, {timeout:1000});
  return trace;
}
const before = run(oldFn), after = run(newFn);
if (before.includes('drawDiff') || after.filter(x=>x==='drawDiff').length!==1 || after.at(-1)!=='drawDiff') throw Error('Redraw regression contract failed');
if (JSON.stringify(after.slice(0,-1))!==JSON.stringify(before)) throw Error('Existing edit callback effects changed');
const pages = [];
for (const draft of [1,2,3]) {
  const filename = path.join(out, 'editor-page' + draft + '.html');
  const data = fs.readFileSync(filename);
  if (extract(data.toString())!==newFn) throw Error('Generated draft callback differs');
  pages.push({draft, bytes:data.length, sha256:crypto.createHash('sha256').update(data).digest('hex')});
}
const result = {before, after, rebuilt_pages:pages, limit:'Offline callback and generated-source contract only. No browser, canvas pixels, drag, cap/width interaction or rendered verification claimed.'};
fs.writeFileSync(path.join(out,'editor-contract.json'), JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));

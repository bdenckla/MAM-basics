"""Frozen unread-ketiv dispatch and consumer/output differentials."""

from collections import Counter
import copy
import difflib
import json
from pathlib import Path
import subprocess
import types

from explicit_xataf import extract
from mb_cmn import hebrew_punctuation as hpu
from mb_cmn import ws_tmpl2 as wtp

ROOT = Path.cwd()
OUT = ROOT.parent / "evidence"
BASE = "85be75d0adda39b4e42eff713caada8d3cf08ce4"
PIN = "89cb865729b0876f1fd32a8a3579eaec80b4fc0c"
NAME = extract._KETIV_WITHOUT_QERE
old = types.ModuleType("prior_extract")
raw = subprocess.check_output(["git", "show", BASE + ":py/explicit_xataf/extract.py"])
exec(compile(raw, "prior_extract", "exec"), old.__dict__)


def walk(node):
    if isinstance(node, dict):
        if node.get("tmpl_name") == NAME:
            yield node
        for child in node.values():
            yield from walk(child)
    elif isinstance(node, list):
        for child in node:
            yield from walk(child)


calls = []
current_targets = 0
current_deltas = []
current_errors = 0
for path in sorted((ROOT / "MAM-parsed/plus").glob("*.json")):
    if path.name == "header.json":
        continue
    raw = path.read_bytes()
    data = json.loads(raw)
    found = list(walk(data))
    historical = list(
        walk(
            json.loads(
                subprocess.check_output(
                    ["git", "show", PIN + ":" + path.relative_to(ROOT).as_posix()]
                )
            )
        )
    )
    assert found == historical, path.name
    assert raw.decode().count(json.dumps(NAME, ensure_ascii=False)) == len(found)
    calls.extend(found)
    for book in data["book39s"]:
        for chapter, verses in book["chapters"].items():
            for verse, cells in verses.items():
                for col, cell in enumerate(cells):
                    for n, note in enumerate(extract.find_docnote_tmpls(cell)):
                        target = note["tmpl_params"]["1"]
                        results = []
                        for module in (old, extract):
                            try:
                                results.append(("text", module.flatten_text(target)))
                            except ValueError as error:
                                assert str(error).startswith(
                                    "Unexpected template in flatten_text:"
                                )
                                results.append(("error", str(error)))
                        current_targets += 1
                        if results[0][0] == "error":
                            current_errors += 1
                        if results[0] != results[1]:
                            assert results[0][0] == results[1][0] == "text"
                            assert old.has_varika(target) == extract.has_varika(target)
                            current_deltas.append(
                                {
                                    "file": path.name,
                                    "book": book["book24_name"],
                                    "chapter": chapter,
                                    "verse": verse,
                                    "column": col,
                                    "note": n,
                                    "before": results[0][1],
                                    "after": results[1][1],
                                }
                            )
assert len(calls) == 8 and len(current_deltas) == 1
assert current_deltas[0]["chapter"] == "5" and current_deltas[0]["verse"] == "18"
for call in calls:
    expected = old.flatten_text(call["tmpl_params"]["2"])
    if "3" in call["tmpl_params"]:
        assert wtp.template_param_val(call, "3") == [hpu.MAQ]
        expected += hpu.MAQ
    assert extract.flatten_text(call) == expected
    params = call["tmpl_params"]
    for order in (tuple(params), tuple(reversed(params))):
        assert (
            extract.flatten_text(
                {**call, "tmpl_params": {key: params[key] for key in order}}
            )
            == expected
        )

guards = 0


def rejects(node):
    global guards
    try:
        extract.flatten_text(node)
    except (ValueError, TypeError, AssertionError, KeyError):
        guards += 1
        return
    raise AssertionError("required validation missing")


for key in ("1", "2"):
    bad = copy.deepcopy(calls[0])
    del bad["tmpl_params"][key]
    rejects(bad)
bad = copy.deepcopy(calls[0])
bad["tmpl_params"]["4"] = ["unknown"]
rejects(bad)
for value in ([], [" "], [hpu.MAQ, hpu.MAQ], "unknown", [[hpu.MAQ]]):
    bad = copy.deepcopy(calls[0])
    bad["tmpl_params"]["3"] = value
    rejects(bad)
for value in (None, 7, {"tmpl_name": "unclassified-template"}):
    rejects(value)

path = "doc/intro-doc-audit/notes.json"
before = json.loads(subprocess.check_output(["git", "show", BASE + ":" + path]))
after = json.loads((ROOT / path).read_bytes())
assert len(before) == len(after) == 3905
changed = []
projection_errors = 0
for a, b in zip(before, after):
    results = []
    for module in (old, extract):
        try:
            results.append(module.flatten_text(a["target_node"]))
        except ValueError as error:
            assert str(error) == a["target_projection_error"]
            results.append(None)
    assert results == [a["target_survey_text"], b["target_survey_text"]]
    projection_errors += results[0] is None
    if a != b:
        copy_a = copy.deepcopy(a)
        copy_a["target_survey_text"] = b["target_survey_text"]
        assert copy_a == b
        edits = [
            e
            for e in difflib.SequenceMatcher(
                None, results[0], results[1], autojunk=False
            ).get_opcodes()
            if e[0] != "equal"
        ]
        assert len(edits) == 1 and edits[0][0] == "insert"
        _, _, __, j, k = edits[0]
        assert results[1][j:k] == hpu.MAQ
        changed.append(a["id"])
assert changed == ["2Kings 5:18/2/0"]
result = {
    "result": "PASS",
    "whole_json_calls_current_and_historical_identical": len(calls),
    "calls_with_parameter_3": sum("3" in n["tmpl_params"] for n in calls),
    "parameter_shape_counts": dict(Counter(",".join(n["tmpl_params"]) for n in calls)),
    "current_topmost_targets": current_targets,
    "current_preserved_projection_errors": current_errors,
    "current_changed_targets": current_deltas,
    "historical_records": len(after),
    "historical_preserved_projection_errors": projection_errors,
    "only_stored_change": changed,
    "negative_guards": guards,
    "parameter_order_checks": len(calls) * 2,
    "limits": "Committed-input dispatch and consistency only; no new editorial/source/browser/font/broad conclusion.",
}
(OUT / "probe-result.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8",
    newline="\n",
)
print(json.dumps(result, ensure_ascii=False, indent=2))

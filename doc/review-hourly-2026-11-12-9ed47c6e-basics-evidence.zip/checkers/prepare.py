"""Prepare only this bounded public receipt and its exact diagnostic evidence."""

import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "head"
OUT = ROOT / "evidence"
BASE = "85be75d0adda39b4e42eff713caada8d3cf08ce4"
SOURCE = "9ed47c6e8999ecaf56031e9b3f524bee6e01507a"
PARENT = "b3639547460fd30f29da8485cf42e0ac2630c117"
NAME = "review-hourly-2026-11-12-9ed47c6e-basics"
BRANCH = "review-hourly-20261112-9ed47c6e-basics-receipts"


def git(*args, tree=TREE):
    return subprocess.check_output(["git", "-C", str(tree), *args])


def dump(d):
    return (json.dumps(d, ensure_ascii=False, indent=2) + "\n").encode()


def sha(b):
    return hashlib.sha256(b).hexdigest()


assert not git("status", "--porcelain=v1", "-z")
assert not git("ls-remote", "origin", "refs/heads/" + BRANCH)
for ref in (SOURCE, PARENT):
    assert (
        git("rev-parse", ref + ":.github/workflows/pages.yml").decode().strip()
        == "18ceb19405424710bda47d9a38c470cc2ed9c385"
    )
    assert b"on:\n  workflow_dispatch:\n" in git(
        "show", ref + ":.github/workflows/pages.yml"
    )
paths = list(
    filter(None, git("diff", "--name-only", "-z", BASE, SOURCE).decode().split("\0"))
)
assert len(paths) == 3
identities = {}
for side, ref in (("base", BASE), ("head", SOURCE)):
    for path in paths:
        raw = git("show", ref + ":" + path)
        identities[side + "/" + path] = {
            "blob": git("rev-parse", ref + ":" + path).decode().strip(),
            "bytes": len(raw),
            "sha256": sha(raw),
        }
(OUT / "identities.json").write_bytes(dump(identities))
(OUT / "endpoint.diff").write_bytes(git("diff", "--binary", BASE, SOURCE))
git("diff", "--check", BASE, SOURCE)
modules = [
    ast.parse(git("show", ref + ":py/explicit_xataf/extract.py"))
    for ref in (BASE, SOURCE)
]
functions = [
    {n.name: ast.dump(n) for n in module.body if isinstance(n, ast.FunctionDef)}
    for module in modules
]
assert functions[1].keys() - functions[0].keys() == {"_ketiv_without_qere_text"}
assert not functions[0].keys() - functions[1].keys()
assert [n for n in functions[0] if functions[0][n] != functions[1][n]] == [
    "flatten_text"
]
probe = json.loads((OUT / "probe-result.json").read_bytes())
hist = json.loads((OUT / "historical-inputs.json").read_bytes())
previous = json.loads(
    Path(
        "/workspace/scratch/basics-85be75d0/evidence/historical-inputs.json"
    ).read_bytes()
)
assert hist["inputs"] == previous["inputs"]
stages = [
    json.loads((OUT / (n + ".json")).read_bytes())
    for n in (
        "tests",
        "explicit-xataf",
        "intro-review",
        "black",
        "probes",
        "historical-audit",
        "probes-corrected",
    )
]
assert [s["exit"] for s in stages] == [0, 0, 0, 0, 1, 0, 0]
assert all((OUT / (s["stage"] + ".diff")).read_bytes() == b"" for s in stages)
assert "21 passed" in (OUT / "tests.log").read_text()
assert probe["result"] == "PASS"
(OUT / "disposition.json").write_bytes(
    dump(
        {
            "result": "PASS",
            "scope": "three commits / three paths",
            "function_delta": "Only flatten_text changes and _ketiv_without_qere_text is added; all other function ASTs are exact.",
            "historical_input_files": len(hist["inputs"]),
            "historical_inputs_equal_prior_verified_replay": True,
            "original_harness": "The original reused historical replay script is retained byte-for-byte, including its inherited label-only caption; exact code_source and tested_snapshot identify the separator-fix replay.",
            "first_probe": "Reviewer incorrectly compared raw singleton storage to the accessor-restored list. Corrected to use ws_tmpl2.template_param_val; both storage forms are legal. Original checker/log retained, no product failure or mutation.",
            "preserved_projection_errors": probe[
                "historical_preserved_projection_errors"
            ],
            "limits": "No new source/editorial/browser/font/Windows/broad verification or global-anchor advancement.",
        }
    )
)
payload = {p.name: p.read_bytes() for p in OUT.iterdir() if p.is_file()}
for n in ("run.py", "probe.py", "historical.py", "prepare.py"):
    payload["checkers/" + n] = (ROOT / n).read_bytes()
payload["manifest.json"] = dump(
    {n: {"bytes": len(b), "sha256": sha(b)} for n, b in sorted(payload.items())}
)
receipts = ROOT / "receipts"
subprocess.run(
    [
        "git",
        "-C",
        "/workspace/MAM-basics",
        "worktree",
        "add",
        "-b",
        BRANCH,
        str(receipts),
        PARENT,
    ],
    check=True,
    capture_output=True,
)
archive = receipts / "doc" / (NAME + "-evidence.zip")
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as z:
    for n, b in sorted(payload.items()):
        z.writestr(n, b)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist()))
    for n, item in json.loads(z.read("manifest.json")).items():
        assert len(z.read(n)) == item["bytes"] and sha(z.read(n)) == item["sha256"]
rows = "\n".join(
    f"| `{shlex.join(s['command'][2:])}` | {s['exit']} | {s['seconds']} |"
    for s in stages
)
report = f"""# Bounded Basics screen, November 12, 2026, 23:00 UTC cycle

State: completed 2026-11-12; owner-recorded separator closure independently verified

Frozen endpoint `{BASE}` -> `{SOURCE}`: three commits / three paths, fully reviewed. Receipt lineage continues from `{PARENT}`; no main source or editorial changes were made. The owner chose optional parameter 3 on the unread-ketiv template, closing the prior separator caveat. The implementation adds a named validated arm returning parameter 2 plus that optional maqaf; other function ASTs are unchanged. No additional consequential introduced defect established.

Independent current/historical whole-JSON comparison finds the same **eight** template calls, **two** with parameter 3. All calls return the intended bytes; **sixteen** parameter-order checks and **eleven** malformed/unknown-input rejection probes pass. Among **3,905** current topmost note targets and all **3,905** stored historical records, only `2Kings 5:18/2/0` changes, by one U+05BE maqaf. Every other record field/codepoint and all **35** existing unclassified-projection errors remain exact; no unsupported projection was invented. Varika detection remains unchanged.

Actual maintained results: **21 focused tests pass**, changed-source Black passes, `main_explicit_xataf.py` reproduces both tracked artifacts (673 mappings, zero failures, 73 extras), and Introduction `review` reproduces its outputs exactly, including both rendered copies. Its reported checks are 719 literal passages, 15 proposed quotations and 11 applied quotations; they establish consistency, not new editorial approval.

Only the affected historical audit generator was replayed: current source plus the same **{len(hist['inputs'])}** exact Git inputs as the preceding verified original-input replay (81 source-pin blobs at `89cb865729b0876f1fd32a8a3579eaec80b4fc0c`, three MAM-simple blobs at the recorded `fb566021` commit), in committed isolated snapshot `{hist['isolated_tested_snapshot']}`. Its five artifacts reproduce the committed head byte-for-byte. No research enumeration ran against current working-source inputs; unaffected historical enumerators and completed prior checks were not repeated.

All commands used `/workspace/MAM-basics/.venv/bin/python -B` from the recorded isolated root. The historical row used the separately committed original-input snapshot.

| Actual arguments | Exit | Seconds |
| --- | ---: | ---: |
{rows}

The first scratch probe assumed a raw singleton was stored as a list; the repository accessor restores it from a string. Its original checker/failure is preserved; the corrected small probe passes. This was a reviewer error, not a product failure. All tracked command diffs are empty. Owner mega/full-suite/Windows results remain attributed; no broad run was repeated.

The former separator caveat is closed at this endpoint under the owner's decision. All other pending windows and source/browser/font/Windows limitations remain. Overall reviewed-through stays `210affe3ac2931473bead0de839be0de08309e3d`; latest broad-tested stays `cfdbb64ef8fc24e777d4d296efb7fe4ac966346d`. No private screen/material, source acquisition, new interpretation, font/baseline or hbofonts work, deployment/dispatch or schedule change. Local slot/process/worktree preflight was clear; cross-machine ownership remains unverified.

Only this fresh isolated receipt/status/evidence branch is published. Source and receipt parent retain manual-dispatch-only Pages; no main/shared integration. [Evidence]({archive.name}): {archive.stat().st_size} bytes, SHA-256 `{sha(archive.read_bytes())}`; all payload sizes/hashes and CRC verified. Exact remote scope/bytes and owned-worktree cleanup/release are checked at closeout; prior finished receipts remain unchanged.
"""
(receipts / "doc" / (NAME + ".md")).write_text(report, encoding="utf-8", newline="\n")
status_path = receipts / "doc/review-trial-status.md"
status = status_path.read_text()
status = status.replace(
    "Latest bounded screen 85be75d0", "Previous bounded screen 85be75d0", 1
).replace("Latest focused evidence 85be75d0", "Previous focused evidence 85be75d0", 1)
status = status.replace(
    "| Adopted baseline |",
    f"| Latest bounded screen 9ed47c6e | `{BASE}` -> `{SOURCE}`; three commits / three paths. Owner-recorded unread-ketiv parameter-3 separator choice independently verified; former caveat closed here, no additional consequential introduced defect or product repair. [Receipt]({NAME}.md). |\n| Latest focused evidence 9ed47c6e | 21 tests, changed-source Black, explicit-xataf and Introduction review pass; original-input audit replay exact. Eight calls, 3,905 note targets/records, eleven negatives and sixteen order probes checked; one stored maqaf insertion only, 35 prior projection errors preserved. Corrected singleton-storage scratch assertion retained. [Evidence]({archive.name}). |\n| Adopted baseline |",
    1,
)
status += f"\n\n## Bounded screen, 2026-11-12 23:00 UTC cycle, 9ed47c6e\n\nThe owner-recorded unread-ketiv parameter-3 separator caveat is now independently verified closed in this three-commit/three-path window. Twenty-one focused tests, Black, explicit-xataf, Introduction review and the affected original-input audit replay pass with empty tracked diffs. Only the declared maqaf insertion changes one stored survey text; every other record and 35 prior projection errors remain exact. The corrected raw-singleton scratch assumption is preserved as a reviewer error. No product repair, new editorial choice, duplicate broad run or private review occurred. Overall reviewed `210affe3ac2931473bead0de839be0de08309e3d`, broad-tested `cfdbb64ef8fc24e777d4d296efb7fe4ac966346d`, every other historical pending window/limitation and finished receipt remain unchanged. [Receipt]({NAME}.md), [evidence]({archive.name}).\n"
status_path.write_text(status, encoding="utf-8", newline="\n")
paths = sorted(
    [
        "doc/" + NAME + ".md",
        "doc/" + NAME + "-evidence.zip",
        "doc/review-trial-status.md",
    ]
)
actual = set(
    filter(None, git("diff", "--name-only", "-z", tree=receipts).decode().split("\0"))
) | set(
    filter(
        None,
        git("ls-files", "--others", "--exclude-standard", "-z", tree=receipts)
        .decode()
        .split("\0"),
    )
)
assert actual == set(paths)
git("diff", "--check", tree=receipts)
(ROOT / "publication-prepared.json").write_bytes(
    dump(
        {
            "branch": BRANCH,
            "parent": PARENT,
            "source": SOURCE,
            "paths": paths,
            "archive": {
                "path": archive.name,
                "bytes": archive.stat().st_size,
                "sha256": sha(archive.read_bytes()),
                "payload_files": len(payload) - 1,
            },
            "prepared_utc": datetime.now(timezone.utc).isoformat(),
        }
    )
)
print("Prepared bounded public receipt/status/evidence only.")

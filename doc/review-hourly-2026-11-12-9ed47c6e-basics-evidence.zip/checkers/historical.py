"""Replay label-only historical audit with exact retained original Git inputs."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "historical"
HEAD = "9ed47c6e8999ecaf56031e9b3f524bee6e01507a"
OUT = ROOT / "evidence"
assert not TREE.exists()
assert json.loads((ROOT / "stage.json").read_bytes())["state"] == "completed"
subprocess.run(
    [
        "git",
        "-C",
        "/workspace/MAM-basics",
        "worktree",
        "add",
        "--detach",
        str(TREE),
        HEAD,
    ],
    check=True,
    capture_output=True,
)


def git(*args):
    return subprocess.check_output(["git", "-C", str(TREE), *args])


pin = json.loads((TREE / "doc/intro-doc-audit/source-pin.json").read_bytes())
inputs = []
for group in pin["inputs"].values():
    for item in group["objects"]:
        header, path = item.split("\t")
        sha = header.split()[2]
        assert git("rev-parse", pin["base_commit"] + ":" + path).decode().strip() == sha
        inputs.append((path, pin["base_commit"], sha))
for name in ("Ps", "Prov", "Job"):
    path = "MAM-simple/json-vtrad-mam/" + name + ".json"
    commit = git("rev-parse", "fb566021").decode().strip()
    inputs.append(
        (path, commit, git("rev-parse", commit + ":" + path).decode().strip())
    )
identities = {}
for path, commit, sha in inputs:
    raw = git("show", commit + ":" + path)
    assert (
        hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest() == sha
    )
    (TREE / path).write_bytes(raw)
    identities[path] = {
        "input_commit": commit,
        "blob": sha,
        "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
    }
git("add", "--", *[path for path, _, __ in inputs])
subprocess.run(
    [
        "git",
        "-C",
        str(TREE),
        "commit",
        "--allow-empty",
        "-m",
        "Isolate original Introduction audit inputs for label-only replay",
    ],
    check=True,
    capture_output=True,
)
snapshot = git("rev-parse", "HEAD").decode().strip()
assert not git("status", "--porcelain=v1", "-z")
(OUT / "historical-inputs.json").write_text(
    json.dumps(
        {
            "code_source": HEAD,
            "isolated_tested_snapshot": snapshot,
            "input_boundary": pin["base_commit"],
            "inputs": identities,
        },
        indent=2,
    )
    + "\n"
)
env = os.environ.copy()
env.update(
    PATH="/workspace/.cloud-setup/bin:" + env["PATH"],
    PYTHONDONTWRITEBYTECODE="1",
    PYTHONUNBUFFERED="1",
)
for key in ("REPO_MAM_PRIVATE_DIR", "REPO_MAM_BASICS_DIR", "REPO_MAM_PARSED_DIR"):
    env.pop(key, None)
for name, args in [("audit", [])]:
    target = OUT / ("historical-" + name + ".json")
    assert not target.exists()
    command = [
        "/workspace/MAM-basics/.venv/bin/python",
        "-B",
        "py/main_intro_doc_audit.py",
        *args,
    ]
    d = {
        "stage": "historical-" + name,
        "state": "running",
        "source": HEAD,
        "tested_snapshot": snapshot,
        "cwd": str(TREE),
        "command": command,
        "started_utc": datetime.now(timezone.utc).isoformat(),
    }
    (ROOT / "stage.json").write_text(json.dumps(d, indent=2) + "\n")
    start = time.monotonic()
    with (OUT / ("historical-" + name + ".log")).open("wb") as log:
        r = subprocess.run(
            command, cwd=TREE, env=env, stdout=log, stderr=subprocess.STDOUT
        )
    patch = git("diff", "--binary")
    (OUT / ("historical-" + name + ".diff")).write_bytes(patch)
    (OUT / ("historical-" + name + "-status.z")).write_bytes(
        git("status", "--porcelain=v1", "-z")
    )
    d.update(
        state="completed",
        exit=r.returncode,
        seconds=round(time.monotonic() - start, 6),
        clean=not patch,
        finished_utc=datetime.now(timezone.utc).isoformat(),
    )
    target.write_text(json.dumps(d, indent=2) + "\n")
    (ROOT / "stage.json").write_text(json.dumps(d, indent=2) + "\n")
    print(json.dumps(d), flush=True)
    assert (
        r.returncode == 0 and not patch
    ), "Preserved historical mismatch; no next stage executed"
assert not git("status", "--porcelain=v1", "-z")

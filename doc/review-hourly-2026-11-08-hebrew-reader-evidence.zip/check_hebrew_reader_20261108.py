"""Independent literal/DOM/link/asset checks of the bounded public page."""

import ast
import hashlib
import json
import re
import struct
import subprocess
import time
import zlib
from collections import Counter
from dataclasses import dataclass, field
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path("/workspace/MAM-basics")
EVID = ROOT / ".novc/review-hebrew-reader-20261108-e8e75686"
PAGE = (
    ROOT / "gh-pages/MAM-with-doc/misc/review_of_hebrew_reader_for_the_pentateuch.html"
)
SOURCE = ROOT / "py/author_misc/review_of_hebrew_reader_for_the_pentateuch.py"
VOID = {
    "area",
    "base",
    "br",
    "col",
    "embed",
    "hr",
    "img",
    "input",
    "link",
    "meta",
    "param",
    "source",
    "track",
    "wbr",
}


@dataclass
class Node:
    tag: str
    attrs: dict = field(default_factory=dict)
    children: list = field(default_factory=list)

    def all(self, tag=None):
        if tag is None or self.tag == tag:
            yield self
        for child in self.children:
            if isinstance(child, Node):
                yield from child.all(tag)

    def text(self):
        return "".join(c.text() if isinstance(c, Node) else c for c in self.children)


class Parser(HTMLParser):
    def __init__(self, text):
        super().__init__(convert_charrefs=True)
        self.root = Node("root")
        self.stack = [self.root]
        self.feed(text)
        assert len(self.stack) == 1, [x.tag for x in self.stack]

    def handle_starttag(self, tag, attrs):
        n = Node(tag, dict(attrs))
        self.stack[-1].children.append(n)
        if tag not in VOID:
            self.stack.append(n)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in VOID:
            self.handle_endtag(tag)

    def handle_endtag(self, tag):
        assert self.stack[-1].tag == tag, (tag, [n.tag for n in self.stack])
        self.stack.pop()

    def handle_data(self, data):
        self.stack[-1].children.append(data)


def fold(text):
    return " ".join(text.split())


def png(path):
    b = path.read_bytes()
    assert b[:8] == b"\x89PNG\r\n\x1a\n"
    pos, chunks = 8, []
    while pos < len(b):
        size = struct.unpack(">I", b[pos : pos + 4])[0]
        kind, data = b[pos + 4 : pos + 8], b[pos + 8 : pos + 8 + size]
        assert len(data) == size
        crc = struct.unpack(">I", b[pos + 8 + size : pos + 12 + size])[0]
        assert zlib.crc32(kind + data) & 0xFFFFFFFF == crc
        chunks.append((kind, data))
        pos += 12 + size
    assert pos == len(b) and chunks[0][0] == b"IHDR" and chunks[-1][0] == b"IEND"
    width, height, depth, color, compression, filt, interlace = struct.unpack(
        ">IIBBBBB", chunks[0][1]
    )
    assert width > 0 and height > 0 and compression == 0 and filt == 0
    raw = zlib.decompress(b"".join(data for kind, data in chunks if kind == b"IDAT"))
    assert raw
    return dict(
        path=path.relative_to(ROOT).as_posix(),
        width=width,
        height=height,
        bit_depth=depth,
        color_type=color,
        interlace=interlace,
        bytes=len(b),
        sha256=hashlib.sha256(b).hexdigest(),
        crc_and_idat="pass",
    )


def main():
    start = time.monotonic()
    text = PAGE.read_text(encoding="utf8")
    dom = Parser(text).root
    ids = [n.attrs["id"] for n in dom.all() if "id" in n.attrs]
    assert len(ids) == len(set(ids)) == 28
    nodes = {n.attrs["id"]: n for n in dom.all() if "id" in n.attrs}
    for i in range(1, 15):
        ref, note = nodes[f"fnref-{i}"], nodes[f"fn-{i}"]
        assert ref.tag == note.tag == "a"
        assert ref.attrs["href"] == f"#fn-{i}" and note.attrs["href"] == f"#fnref-{i}"
        assert ref.text() == note.text() == f"[{i}]"
        assert any(ref in n.children for n in dom.all("sup"))
    assert len(list(dom.all("h1"))) == len(list(dom.all("h2"))) == 1
    assert len(list(dom.all("h3"))) == 4
    assert len(list(dom.all("ol"))) == 4
    assert len(list(dom.all("blockquote"))) == 1
    tables = list(dom.all("table"))
    cells = list(dom.all("td"))
    assert len(tables) == 2 and len(cells) == 8
    assert all(n.attrs.get("dir") == "rtl" for n in cells)
    assert all(len(list(t.all("tr"))) == 2 for t in tables)
    assert sum(n.attrs.get("class") == "gray" for n in dom.all("span")) == 2
    pointed = [n for n in dom.all("bdi") if n.attrs.get("class") == "big"]
    assert len(pointed) == 4
    for table in tables:
        a, b = list(table.all("tr"))
        assert list(a.all("span"))[0].attrs.get("class") == "gray"
        assert not list(b.all("span"))
    tree = ast.parse(SOURCE.read_text(encoding="utf8"))
    calls = sorted(
        (
            n
            for n in ast.walk(tree)
            if isinstance(n, ast.Call)
            and isinstance(n.func, ast.Name)
            and n.func.id == "_hbo_checked"
        ),
        key=lambda n: n.lineno,
    )
    literals = [ast.literal_eval(n.args[0]) for n in calls]
    rendered = [fold(n.text()) for n in dom.all("bdi")]
    assert (
        literals == rendered
    ), "Source literal order/codepoints differ from rendered Hebrew"
    priority = {0x05C1: 10, 0x05C2: 11, 0x05BC: 21, 0x05C9: 21, 0x05BF: 23}
    cluster = re.compile(
        r"[\u05d0-\u05ea][\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7\u05c8\u05c9]*"
    )
    clusters = 0
    for value in literals:
        for match in cluster.finditer(value):
            s = match[0]
            assert s[1:] == "".join(
                sorted(s[1:], key=lambda c: priority.get(ord(c), 300))
            )
            clusters += 1
    for n in dom.all("p"):
        assert not re.match(
            r"^[\s\W]*[\u05d0-\u05ea]", n.text()
        ), "Hebrew-first English paragraph"
    bad = {"script", "iframe", "form", "object", "embed"}
    assert not any(n.tag in bad for n in dom.all())
    assert not re.search(r"\$[A-Za-z_]", dom.text()), "Unexpanded authored placeholder"
    links = []
    cache = {}
    for n in dom.all("a"):
        href = n.attrs["href"]
        u = urlsplit(href)
        local = not u.scheme and not u.netloc
        site = u.netloc == "bdenckla.github.io" and u.path.startswith("/MAM-basics/")
        row = dict(href=href, text=fold(n.text()), target_checked=local or site)
        if local or site:
            target = (
                ROOT / "gh-pages" / unquote(u.path[len("/MAM-basics/") :])
                if site
                else PAGE.parent / unquote(u.path)
            )
            if not u.path:
                target = PAGE
            assert target.is_file(), str(target)
            if u.fragment:
                if target not in cache:
                    sub = Parser(target.read_text(encoding="utf8")).root
                    cache[target] = {x.attrs.get("id") for x in sub.all()}
                assert unquote(u.fragment) in cache[target], (href, target)
        links.append(row)
    assert len([r for r in links if not r["href"].startswith("#")]) == 39
    images = list(dom.all("img"))
    assert len(images) == 7
    image_info = [png(PAGE.parent / unquote(n.attrs["src"])) for n in images]
    assert len({r["path"] for r in image_info}) == 7
    for n in images:
        assert re.fullmatch(r"width: [0-9.]+em", n.attrs["style"])
    source_images = [
        n
        for n in ast.walk(tree)
        if isinstance(n, ast.Call)
        and isinstance(n.func, ast.Attribute)
        and n.func.attr == "para_for_img"
    ]
    assert len(source_images) == 7
    for source_call, img in zip(sorted(source_images, key=lambda n: n.lineno), images):
        assert "img/" + ast.literal_eval(source_call.args[0]) == unquote(
            img.attrs["src"]
        )
        width = next(
            ast.literal_eval(k.value)
            for k in source_call.keywords
            if k.arg == "width_em"
        )
        assert img.attrs["style"] == f"width: {width}em"
    for link in dom.all("link"):
        assert (PAGE.parent / unquote(link.attrs["href"])).is_file()
    for rel, expected_href in [
        ("gh-pages/MAM-with-doc/misc/index.html", PAGE.name),
        (
            "gh-pages/index.html",
            "https://bdenckla.github.io/MAM-basics/MAM-with-doc/misc/" + PAGE.name,
        ),
    ]:
        index = Parser((ROOT / rel).read_text(encoding="utf8")).root
        matches = [n for n in index.all("a") if n.attrs.get("href") == expected_href]
        assert len(matches) == 1, rel
        if rel == "gh-pages/index.html":
            assert matches[0].attrs["data-na-link"] == "page"
    for path in (
        SOURCE,
        PAGE,
        ROOT / "py/main_authored.py",
        ROOT / "py/author_site/site_data.py",
    ):
        b = path.read_bytes()
        assert not b.startswith(b"\xef\xbb\xbf") and b"\r" not in b and b"\t" not in b
        assert "\ufffd" not in b.decode("utf8")
        assert not any(line.endswith((b" ", b"\t")) for line in b.splitlines())
    out = dict(
        result="pass",
        seconds=round(time.monotonic() - start, 3),
        headings=dict(h1=1, h2=1, h3=4),
        ordered_lists=4,
        tables=2,
        rtl_cells=8,
        gray_rows=2,
        pointed_forms=4,
        literal_hebrew_runs=len(literals),
        checked_clusters=clusters,
        unique_ids=len(ids),
        footnote_pairs=14,
        hyperlinks=len(links),
        non_footnote_links=39,
        checked_local_or_site_links=sum(r["target_checked"] for r in links),
        images=image_info,
        links=links,
        source_export_available_locally=False,
        page=dict(
            bytes=PAGE.stat().st_size,
            sha256=hashlib.sha256(PAGE.read_bytes()).hexdigest(),
        ),
    )
    (EVID / "independent-check.json").write_text(
        json.dumps(out, indent=2, ensure_ascii=False) + "\n"
    )
    print(
        json.dumps(
            {k: v for k, v in out.items() if k not in ("links", "images")},
            ensure_ascii=True,
        )
    )


if __name__ == "__main__":
    main()

"""Independent extraction and geometry comparisons for the frozen endpoint."""

import ast
import hashlib
import json
from pathlib import Path
import subprocess
import types

import numpy as np

from explicit_xataf import extract
from mb_cmn import ws_tmpl2 as wtp
from pen_stroke import geometry

ROOT = Path(__file__).resolve().parents[1]
OUT = Path("/workspace/scratch/review-hourly-20261030-2000/basics")
BASE = "bbb8a23a589358974c1257102bc395f466c4cd90"
TIP = "83a88bf9117f5aa10d9418079d26166a7f463380"


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)


old = types.ModuleType("previous_extract")
exec(
    compile(
        git("show", BASE + ":py/explicit_xataf/extract.py"),
        "previous_extract.py",
        "exec",
    ),
    old.__dict__,
)


def nodes(value):
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from nodes(child)
    elif isinstance(value, list):
        for child in value:
            yield from nodes(child)


preserved = 0
for path in sorted((ROOT / "MAM-parsed/plus").glob("*.json")):
    previous = json.loads(git("show", BASE + ":" + path.relative_to(ROOT).as_posix()))
    for node in nodes(previous):
        if "tmpl_name" not in node or not wtp.is_doc_template(node):
            continue
        target = wtp.template_param_val(node, "1")
        if not extract.has_varika(target):
            continue
        body = wtp.template_param_val(node, "2")
        assert old.extract_xataf_word(body) == extract.extract_xataf_word(body)
        preserved += 1

current = json.loads((ROOT / "out/explicit-xataf.json").read_bytes())
previous = json.loads(git("show", BASE + ":out/explicit-xataf.json"))
before = previous["mappings"]
after = current["mappings"]
assert len(before) == len(after) == 670 and not current["failures"]
changed = []
for a, b in zip(before, after, strict=True):
    assert {k: v for k, v in a.items() if k != "match_kind"} == {
        k: v for k, v in b.items() if k != "match_kind"
    }
    if a != b:
        assert a["match_kind"] == "sigla=word" and b["match_kind"] == "sigla=plus-form"
        changed.append(b["ref"])
assert len(changed) == 5
assert current["counts"] == previous["counts"]

a, b = chr(0x05D0), chr(0x05D1)
sheva, hir = chr(0x05B0), chr(0x05B4)
valid = "s=" + a + sheva + "+" + a + hir + " (" + a + sheva + hir + ")"
assert extract.extract_xataf_word(valid) == (
    a + sheva + hir,
    "sigla=plus-form",
    {"sigla": "s"},
)
bad = [
    valid.replace("(" + a, "(" + b),
    valid.replace("+" + a, "+" + b),
    valid.replace(")", b + ")"),
]
for text in bad:
    try:
        extract.extract_xataf_word(text)
    except ValueError:
        pass
    else:
        raise AssertionError("invalid fold accepted")

# Exhaustive tiny masks test pixel contours against the independent input array.
for number in range(512):
    mask = np.array([(number >> i) & 1 for i in range(9)], dtype=bool).reshape(3, 3)
    encoded = geometry.mask_path(mask)
    for rule in ("nonzero", "evenodd"):
        assert np.array_equal(geometry.path_mask(encoded, 3, 3, rule), mask), (
            number,
            rule,
        )

module = ast.parse((ROOT / "py/main_pen_stroke.py").read_text(encoding="utf-8"))
previous_module = ast.parse(git("show", TIP + ":py/main_pen_stroke.py").decode())
module.body = module.body[1:]
previous_module.body = previous_module.body[1:]
assert ast.dump(module) == ast.dump(previous_module)
changed_paths = git("diff", "--name-only", "-z").decode().split("\0")[:-1]
assert set(changed_paths) == {
    "py/main_pen_stroke.py",
    "py/tests/test_graphviz_version_pin.py",
}

result = dict(
    old_varika_note_cases_preserved=preserved,
    mappings=670,
    extraction_failures=0,
    metadata_only_changes=changed,
    valid_new_plus_control=1,
    invalid_fold_refusals=3,
    exhaustive_mask_roundtrips=1024,
    repair_entrypoint_executable_ast_unchanged=True,
    generated_outputs_byte_identical=True,
    tracked_diff=changed_paths,
    crop_provenance_limit="Tracked crops checked; original remote JPEG claims attributed, no source-image downloads/research.",
)
(OUT / "independent-audit.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8",
    newline="\n",
)
print(json.dumps(result, ensure_ascii=False, indent=2))

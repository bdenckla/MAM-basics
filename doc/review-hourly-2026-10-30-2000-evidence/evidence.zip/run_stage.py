"""Run one focused stage synchronously with exact command and complete output."""

import datetime
import json
from pathlib import Path
import subprocess
import sys
import time

name, cwd, *command = sys.argv[1:]
out = Path("/workspace/scratch/review-hourly-20261030-2000") / (
    "basics" if cwd.startswith("/workspace/MAM-basics") else "private"
)
tick = time.monotonic()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
done = subprocess.run(command, cwd=cwd, capture_output=True)
(out / (name + ".log")).write_bytes(done.stdout + done.stderr)
row = dict(
    name=name,
    cwd=cwd,
    command=command,
    started=started,
    elapsed_seconds=round(time.monotonic() - tick, 3),
    exit=done.returncode,
)
(out / (name + ".json")).write_text(
    json.dumps(row, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n"
)
print(json.dumps(row), flush=True)
print((done.stdout + done.stderr).decode("utf-8", errors="replace")[-3500:])
raise SystemExit(done.returncode)

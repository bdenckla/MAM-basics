from pathlib import Path
from datetime import datetime,timezone
import json,os,subprocess,time
R=Path('/workspace/scratch/hourly-20261119-controls');C=R/'basics-source';E=R/'public-artifacts';PY='/workspace/MAM-basics/.venv/bin/python'
assert not(E/'commands.json').exists();env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
jobs=[('diff-check',['git','diff','--check','45c6f6a85cb5f144447f678781b75eb2b4b331a8','629b269c93910191182c4b726eaf8ef7f30b8feb']),('black',[PY,'-m','black','--check','py/tests/test_h_dot_below_nfc.py']),('nfc-tests',[PY,'py/main_test.py','py/tests/test_h_dot_below_nfc.py','-q','-ra']),('boundary-probes',[PY,'py/main_test.py',str(E/'test_nfc_boundary_review.py'),'-q','-ra'])]
rows=[]
for label,argv in jobs:
 assert not subprocess.check_output(['git','status','--porcelain=v1','-z'],cwd=C)
 t=time.perf_counter();start=datetime.now(timezone.utc).isoformat()
 with(E/(label+'.log')).open('xb')as f:p=subprocess.run(argv,cwd=C,env=env,stdout=f,stderr=subprocess.STDOUT)
 status=subprocess.check_output(['git','status','--porcelain=v1','-z'],cwd=C);diff=subprocess.check_output(['git','diff','HEAD','--binary'],cwd=C)
 (E/(label+'-status.z')).write_bytes(status);(E/(label+'-diff.patch')).write_bytes(diff)
 row=dict(stage=label,argv=argv,cwd=str(C),started_utc=start,finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=round(time.perf_counter()-t,6),exit=p.returncode,status_clean=not status,diff_empty=not diff)
 rows.append(row);(E/'commands.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print(json.dumps(row),flush=True)
 if p.returncode or status:
  print((E/(label+'.log')).read_text(encoding='utf-8')[-2500:]);raise SystemExit('Unexpected result preserved')

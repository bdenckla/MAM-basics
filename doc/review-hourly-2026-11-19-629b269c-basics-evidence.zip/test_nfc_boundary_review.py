import ast,copy,hashlib,importlib.util,json,subprocess,sys
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from mb_cmn import paths

ROOT=paths.repo_root();PREFIX='in/mam-go-changes-tab/'
spec=importlib.util.spec_from_file_location('review_nfc_current',ROOT/'py/tests/test_h_dot_below_nfc.py')
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
def blob(path):return subprocess.check_output(['git','show','45c6f6a85cb5f144447f678781b75eb2b4b331a8:'+path],cwd=ROOT)

def test_exact_scope_delta_and_capture():
    scope=m._scopes()[0];assert PREFIX in scope.exclude_dir_prefixes
    oldscope=replace(scope,exclude_dir_prefixes=tuple(p for p in scope.exclude_dir_prefixes if p!=PREFIX))
    oldset=set(m._tracked_files_in_scope(oldscope));newset=set(m._tracked_files_in_scope(scope))
    assert oldset-newset=={PREFIX+'changes.csv',PREFIX+'manifest.json'}and not newset-oldset
    for p in['in/mam-change-log-credits.json','doc/PLAN-change-log-credits.md','py/mb_diff_mpu/mpplus_credits.py']:
        assert p in newset
    raw=(ROOT/PREFIX/'changes.csv').read_bytes();manifest=json.loads((ROOT/PREFIX/'manifest.json').read_text())
    assert raw==blob(PREFIX+'changes.csv')and len(raw)==manifest['bytes']==189511
    assert hashlib.sha256(raw).hexdigest()==manifest['sha256']=='030cb757027c00754600a43a989d8fd5bf6b8f2ed3f6196f23d39d6f1567684e'
    assert (ROOT/PREFIX/'manifest.json').read_bytes()==blob(PREFIX+'manifest.json')
    badlines=[i for i,line in enumerate(raw.decode('utf-8').splitlines(),1)if'h'+chr(0x323)in line or'H'+chr(0x323)in line]
    assert badlines==[159]
    Path(__file__).with_name('boundary-result.json').write_text(json.dumps(dict(old_main_scope_files=len(oldset),new_main_scope_files=len(newset),only_excluded=sorted(oldset-newset),capture_bytes=len(raw),capture_sha256=manifest['sha256'],preserved_decomposed_source_lines=badlines,ordinary_authored_examples_retained=True),indent=2)+'\n',encoding='utf-8')

def test_directory_boundary_and_validator_still_detects(tmp_path):
    names=[PREFIX+'changes.csv',PREFIX+'manifest.json','in/mam-go-changes-tab-extra/hand.md','in/mam-go-changes-tab.md','doc/hand.md','py/hand.py','hand-authored.json']
    bad='h'+chr(0x323)
    for name in names:
        p=tmp_path/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(bad,encoding='utf-8')
    scope=m._Scope('boundary fixture',tmp_path,(PREFIX,),frozenset(),0)
    with patch.object(m.subprocess,'run',return_value=SimpleNamespace(stdout='\0'.join(names)+'\0')):
        selected=m._tracked_files_in_scope(scope)
    assert selected==names[2:]
    for name in selected:
        text=(tmp_path/name).read_text();assert m._string_has_h_dot_below(text)and m._find_decomposed_latin_clusters(text)

def test_only_ast_change_is_declared_prefix():
    before=ast.parse(blob('py/tests/test_h_dot_below_nfc.py'))
    after=ast.parse((ROOT/'py/tests/test_h_dot_below_nfc.py').read_bytes())
    node=next(n for n in after.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='_EXCLUDE_DIR_PREFIXES'for t in n.targets))
    assert sum(isinstance(e,ast.Constant)and e.value==PREFIX for e in node.value.elts)==1
    node.value.elts=[e for e in node.value.elts if not(isinstance(e,ast.Constant)and e.value==PREFIX)]
    assert ast.dump(before,include_attributes=False)==ast.dump(after,include_attributes=False)

"""Bounded actual lookup CLI probes using only disposable public scan paths."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import time

root=Path('/workspace/scratch/basics-647ef21c');tree=root/'head';out=root/'evidence'
python='/workspace/MAM-basics/.venv/bin/python'
scans=root/'fixtures/scans'
env=dict(os.environ);env['BOOK_SCANS_ROOT']=str(scans)
cases=[
 ('obadiah-split',['Obadiah','1:9','--edition','jc1'],0,'JC1 Jerusalem Crown',['544-A-O.jpg','545-O-Jn.jpg']),
 ('jc1-named-body',['Exodus','20:9e','--edition','jc1'],0,'JC1 Jerusalem Crown',['069-E.jpg','070-E.jpg']),
 ('bhl-named-appendix',['Exodus','20:9e','--edition','bhl'],0,'Biblia Hebraica Leningradensia',['1227-Exod-Decalogue-Upper.jpg']),
 ('tiqqun-named-body',['Exodus','20:5e','--edition','simanim-tiqqun'],0,'Feldheim Simanim Tiqqun',['C083.jpg','C084.jpg']),
 ('tiqqun-named-appendix',['Exodus','20:5t','--edition','simanim-tiqqun'],0,'Feldheim Simanim Tiqqun',['C246.jpg']),
 ('unavailable-named-range',['Genesis','1:1e','--edition','bhl'],1,None,[]),
 ('printed-form-needs-phrase',['Genesis','1:1','--printed-form','--edition','jc1'],1,None,[]),
 ('rite-rejects-other-edition',['Hosea','11:7','--rite','vayetze-sephardi','--edition','jc1'],1,None,[]),
]
results=[]
for label,args,expected,folder,pages in cases:
    argv=[python,'py/main_scan_pages.py','lookup',*args]
    start=datetime.now(timezone.utc).isoformat();clock=time.perf_counter()
    result=subprocess.run(argv,cwd=tree,env=env,capture_output=True)
    duration=time.perf_counter()-clock
    (out/f'cli-{label}.stdout').write_bytes(result.stdout)
    (out/f'cli-{label}.stderr').write_bytes(result.stderr)
    assert result.returncode==expected,(label,result.returncode)
    actual=result.stdout.decode().splitlines()
    expected_urls=[(scans/folder/page).as_uri() for page in pages] if folder else []
    assert actual==expected_urls,(label,actual,expected_urls)
    if expected:assert result.stderr
    results.append({'name':label,'argv':argv,'cwd':str(tree),'BOOK_SCANS_ROOT':str(scans),
                    'start_utc':start,'wall_seconds':round(duration,6),'exit':result.returncode,
                    'expected_exit':expected,'expected_pages':pages,'stdout_exact':True})
(out/'cli-results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'cases':len(results),'successes':5,'expected_refusals':3}))

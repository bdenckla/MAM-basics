"""Sequential focused checks with exact exits, logs, and checkout evidence."""
from datetime import datetime, timezone
import hashlib
from importlib import metadata
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/basics-647ef21c')
TREE = ROOT / 'head'
EVIDENCE = ROOT / 'evidence'
PYTHON = '/workspace/MAM-basics/.venv/bin/python'
SOURCE = '647ef21ca9d09b1b50264b000cd6a31fd376e572'
BASE = 'fb4341ffe3e12f55137aa9d9988db88fe84cdcec'

def dump(value): return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()
def git(*args): return subprocess.check_output(['git','-C',str(TREE),*args])
def snapshot(name):
    (EVIDENCE / f'{name}.status.z').write_bytes(git('status','--porcelain=v1','-z'))
    (EVIDENCE / f'{name}.diff').write_bytes(git('diff','--binary'))

def run(name,args,*,cwd=TREE,env=None,expected=0):
    assert not (EVIDENCE/f'{name}.result.json').exists(),name
    assert git('rev-parse','HEAD').decode().strip()==SOURCE
    assert json.loads(Path(str(ROOT)+'-slot.json').read_bytes())['state']=='claimed'
    snapshot(name+'.before')
    start=datetime.now(timezone.utc).isoformat();clock=time.perf_counter()
    with (EVIDENCE/f'{name}.stdout').open('wb') as out, (EVIDENCE/f'{name}.stderr').open('wb') as err:
        result=subprocess.run(args,cwd=cwd,env=env,stdout=out,stderr=err)
    elapsed=time.perf_counter()-clock
    snapshot(name+'.after')
    record={'name':name,'argv':list(map(str,args)),'cwd':str(cwd),'start_utc':start,
            'finish_utc':datetime.now(timezone.utc).isoformat(),'wall_seconds':round(elapsed,6),
            'exit':result.returncode,'expected_exit':expected}
    (EVIDENCE/f'{name}.result.json').write_bytes(dump(record))
    print(json.dumps(record),flush=True)
    assert result.returncode==expected,record
    assert not git('status','--porcelain=v1','-z'),'Preserve and triage source modifications'

def setup():
    files=[p for p in git('diff','--name-only','-z',BASE,SOURCE).decode().split('\0') if p]
    tracked={}
    for name in files:
        data=(TREE/name).read_bytes()
        tracked[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
                       'blob':git('rev-parse',SOURCE+':'+name).decode().strip()}
    (EVIDENCE/'source-inventory.json').write_bytes(dump({'base':BASE,'source':SOURCE,'paths':tracked}))
    (EVIDENCE/'endpoint.diff').write_bytes(git('diff','--binary',BASE,SOURCE))
    (EVIDENCE/'endpoint.log').write_bytes(git('log','--format=fuller',BASE+'..'+SOURCE))
    distributions={}
    for requirement in ('black','pytest','packaging','potracer','lxml'):
        try: distributions[requirement]=metadata.version(requirement)
        except metadata.PackageNotFoundError: distributions[requirement]=None
    (EVIDENCE/'environment.json').write_bytes(dump({'python':sys.version,'executable':sys.executable,
       'platform':platform.platform(),'distributions':distributions,
       'requirements_sha256':hashlib.sha256((TREE/'requirements.txt').read_bytes()).hexdigest(),
       'constraints_sha256':hashlib.sha256((TREE/'constraints.txt').read_bytes()).hexdigest(),
       'siblings':'No sibling inputs required or read by this focused scan-index path.'}))
    for ref in (SOURCE,'4f4dbd35e716535ec5ed6e95f56d982adc8519bf'):
        assert git('ls-tree','-r','--name-only','-z',ref,'--','.github').decode().split('\0')==['.github/workflows/pages.yml','']
        assert git('rev-parse',ref+':.github/workflows/pages.yml').decode().strip()=='18ceb19405424710bda47d9a38c470cc2ed9c385'
    (EVIDENCE/'workflow.yml').write_bytes(git('show',SOURCE+':.github/workflows/pages.yml'))
    print(json.dumps({'paths':len(files),'python_files':sum(p.endswith('.py') for p in files),'environment':distributions}))

if __name__=='__main__':
    mode=sys.argv[1]
    if mode=='setup':setup()
    elif mode=='checker':run('01-checker',[PYTHON,'py/main_scan_pages.py','check'])
    elif mode=='black':
        files=[p for p in git('diff','--name-only','-z',BASE,SOURCE).decode().split('\0') if p.endswith('.py')]
        run('02-black',[PYTHON,'-m','black','--check',*files])
    elif mode=='tests':
        run('03-tests',[PYTHON,'py/main_test.py','py/tests/test_scan_pages_index.py','py/tests/test_mega_coverage.py',
                       'py/tests/test_product_scopes.py','py/tests/test_prose_mark_order.py','py/tests/test_tracked_filenames.py',
                       'py/tests/test_entry_point_subcommands.py::test_every_subcommand_is_documented_and_every_entry_registered[main_scan_pages]',
                       'py/tests/test_entry_point_subcommands.py::test_a_pattern_entry_spells_out_every_family_member[main_scan_pages]','-q'])
    elif mode in {'inventory','intervals','fixtures'}:
        helper=TREE/'py/_review_probe_647ef21c.py'
        assert not helper.exists()
        content=(ROOT/'probe.py').read_bytes()
        # Take the before snapshot while source remains clean, and permit only
        # this task-owned ephemeral import entry point during the command.
        name={'inventory':'04-inventory','intervals':'05-intervals','fixtures':'06-fixtures'}[mode]
        snapshot(name+'.before')
        helper.write_bytes(content)
        start=datetime.now(timezone.utc).isoformat();clock=time.perf_counter()
        args=[PYTHON,str(helper),mode]
        with (EVIDENCE/f'{name}.stdout').open('wb') as out, (EVIDENCE/f'{name}.stderr').open('wb') as err:
            result=subprocess.run(args,cwd=TREE,stdout=out,stderr=err)
        elapsed=time.perf_counter()-clock
        assert helper.read_bytes()==content
        helper.unlink()
        snapshot(name+'.after')
        record={'name':name,'argv':args,'cwd':str(TREE),'start_utc':start,'finish_utc':datetime.now(timezone.utc).isoformat(),
                'wall_seconds':round(elapsed,6),'exit':result.returncode,'expected_exit':0,
                'ephemeral_helper_sha256':hashlib.sha256(content).hexdigest(),'helper_removed':not helper.exists()}
        (EVIDENCE/f'{name}.result.json').write_bytes(dump(record));print(json.dumps(record),flush=True)
        assert result.returncode==0,record
        assert not git('status','--porcelain=v1','-z')
    else:raise ValueError(mode)

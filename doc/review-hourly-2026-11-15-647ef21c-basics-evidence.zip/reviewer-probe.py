"""Public-only independent interval and disposable-filename workflow probes.

Executed through a task-owned temporary file in the frozen checkout's py directory;
all source modules import normally. Catalog-path injection affects only the fixture
replay. No scan image is read and no real user scan location is consulted.
"""
from collections import Counter
from copy import deepcopy
from functools import cache
import hashlib
import json
import os
from pathlib import Path
import re
from statistics import median
import subprocess
import sys

from scan_pages import census, editions, index_io, lookup, text, survey, decalogue

ROOT=Path('/workspace/scratch/basics-647ef21c')
TREE=ROOT/'head'
OUT=ROOT/'evidence'
PYTHON='/workspace/MAM-basics/.venv/bin/python'
SOURCE='647ef21ca9d09b1b50264b000cd6a31fd376e572'
BASE='fb4341ffe3e12f55137aa9d9988db88fe84cdcec'

def dump(value):return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
def save(name,value):(OUT/name).write_bytes(dump(value))
def raw_catalogs():return {eid:(TREE/'in/scan-pages'/f'{eid}.json').read_bytes() for eid in editions.ALL_EDITION_IDS}

def inventory():
    text.book_atoms=cache(text.book_atoms)
    summary={};density=[];eligible_total=0;data_changes={}
    for eid,raw in raw_catalogs().items():
        index=json.loads(raw)
        old=json.loads(subprocess.check_output(['git','-C',str(TREE),'show',BASE+':in/scan-pages/'+eid+'.json']))
        old_pages={p['file']:p for p in old['pages']};pages={p['file']:p for p in index['pages']}
        assert old_pages.keys()==pages.keys(),eid
        changed=[{'file':name,'before':old_pages[name],'after':pages[name]} for name in pages if old_pages[name]!=pages[name]]
        data_changes[eid]={'classification_changes':changed,'pages_added':[],'pages_removed':[]}
        row={'pages':len(pages),'page_kinds':dict(Counter(p['kind'] for p in pages.values())),
             'ordinary_records':len(index['recs']),'segments':len(index['segments']),
             'printed_forms':len(index.get('printed-forms',[])),'named_ranges':sum(len(v) for v in index.get('decalogue-ranges',{}).values())}
        if 'tiqqun' in index:
            data=index['tiqqun'];row.update(occurrences=len(data['occurrences']),occurrence_intervals=sum(len(e['pages']) for e in data['occurrences']),rites=len(data['rites']))
        else:
            covered={r['bkid'] for r in index['recs']}
            assert len(covered)==39 and all(r['stopc'] is not None for r in index['recs'])
            row['complete_books']=len(covered)
            for book in sorted(covered):
                records=[r for r in index['recs'] if r['bkid']==book]
                verses=text.book_atoms(book)
                ordered=[(c,v,p) for (c,v),atoms in verses.items() for p in range(1,len(atoms)+1)]
                ordinal={pos:n for n,pos in enumerate(ordered)}
                interior=[r for r in records[1:-1] if pages[r['page']].get('bkids')==[book]]
                if len(interior)<8:continue
                eligible_total+=len(interior)
                sizes=[(r['page'],ordinal[tuple(r['stop'+k] for k in 'cvp')]-ordinal[tuple(r['start'+k] for k in 'cvp')]+1) for r in interior]
                typical=median(n for _,n in sizes)
                density.extend({'edition':eid,'book':book,'page':name,'atoms':size,'median':typical} for name,size in sizes if 2*size<typical or 2*size>3*typical)
        summary[eid]=row
    save('catalog-summary.json',{'editions':summary,'density_eligible_pages':eligible_total,'density_advisories':density})
    save('catalog-page-delta.json',data_changes)

def intervals():
    # Cache immutable source text/strand projections only; expected sets below are
    # rebuilt directly from catalog intervals and query positions for each query.
    original_book=text.book_atoms;original_strand=decalogue.strand_atoms
    text.book_atoms=cache(original_book)
    named_cache={}
    def strand(book,verses,first,last,reading):
        key=(book,first,last,reading)
        if key not in named_cache:named_cache[key]=original_strand(book,verses,first,last,reading)
        return named_cache[key]
    decalogue.strand_atoms=strand
    # Keep one real validation per immutable ordinary catalog/book. The checker
    # already ran the original validators; this bounds repeated query cost.
    original_validate=census.validate_book;validated={}
    def validate(index,book,verses):
        key=index['edition'],book
        if key not in validated:validated[key]=original_validate(index,book,verses)
        return validated[key]
    census.validate_book=validate
    checks=Counter();query_records=[]
    @cache
    def positions(book):
        verses=text.book_atoms(book)
        return tuple((c,v,p) for (c,v),atoms in verses.items() for p in range(1,len(atoms)+1))
    @cache
    def ordinals(book):return {pos:n for n,pos in enumerate(positions(book))}
    @cache
    def immutable_span(book,first,last):
        ordered=positions(book);ordinal=ordinals(book)
        return frozenset(ordered[ordinal[first]:ordinal[last]+1])
    def span(book,first,last):return immutable_span(book,tuple(first),tuple(last))
    def query_positions(book,cv,phrase):
        atoms=text.book_atoms(book)[cv]
        if phrase is None:return {(*cv,n) for n in range(1,len(atoms)+1)}
        assert atoms.count(phrase)==1
        return {(*cv,atoms.index(phrase)+1)}
    def named_expected(index,book,reading,cv,phrase):
        extent=index['decalogue-ranges'][book][reading]
        allowed=span(book,extent['start'],extent['stop'])
        query=query_positions(book,cv,phrase)
        result=[]
        if 'appendix' in extent and not extent.get('body',False):
            candidates=[(extent['appendix'],allowed)]
        else:
            candidates=[(r['page'],span(book,[r['start'+k] for k in 'cvp'],[r['stop'+k] for k in 'cvp'])&allowed) for r in index['recs'] if r['bkid']==book]
        for page,part in candidates:
            if part&query:
                result.append({'page':page,'bkid':book,'strand':reading,**{'start'+k:v for k,v in zip('cvp',min(part))},**{'stop'+k:v for k,v in zip('cvp',max(part))}})
        return result
    for eid in editions.ALL_EDITION_IDS:
        index=index_io.read_index(eid)
        for book,readings in index.get('decalogue-ranges',{}).items():
            verses=text.book_atoms(book)
            for reading,extent in readings.items():
                suffix={'taxton':'t','elyon':'e'}[reading]
                cvs=sorted({p[:2] for p in span(book,extent['start'],extent['stop'])})
                for cv in cvs:
                    expected=named_expected(index,book,reading,cv,None)
                    assert lookup.resolve(index,book,*cv,strand=suffix)==expected,(eid,book,reading,cv)
                    checks['named_verse']+=1
                    # Unique single atoms at either end of each returned page's
                    # portion supply focused phrase-side selection at splits.
                    for row in expected:
                        for end in ('start','stop'):
                            pos=tuple(row[end+k] for k in 'cvp')
                            if pos[:2]!=cv:continue
                            atom=verses[cv][pos[2]-1]
                            if verses[cv].count(atom)!=1:continue
                            expected_phrase=named_expected(index,book,reading,cv,atom)
                            assert lookup.resolve(index,book,*cv,atom,strand=suffix)==expected_phrase
                            checks['named_unique_boundary_atom']+=1
                outside=(cvs[0][0],cvs[0][1]-1)
                if outside in verses:
                    assert lookup.resolve(index,book,*outside,strand=suffix)==[]
                    checks['named_outside_range']+=1
        for form in index.get('printed-forms',[]):
            phrase=' '.join(form['lines']);cv=tuple(form['first'][:2]);book=form['bkid']
            def independent_atoms(value):
                return tuple(letters for token in re.split(r'[\s\u05be]+',value) if (letters:=''.join(c for c in token if '\u05d0'<=c<='\u05ea')))
            expected=[f for f in index['printed-forms'] if f['bkid']==book and tuple(f['first'][:2])==cv and independent_atoms(' '.join(f['lines']))==independent_atoms(phrase)]
            assert lookup.resolve_printed_forms(index,book,*cv,phrase)==expected
            checks['printed_form']+=1
    index=index_io.read_index(editions.SIMANIM_TIQQUN);data=index['tiqqun']
    def tiqqun_expected(book,cv,phrase=None,*,suffix=None,rite=None):
        query=query_positions(book,cv,phrase);result=[]
        selection=data['rites'].get(rite) if rite else None
        if selection and selection['bkid']!=book:return []
        for entry in data['occurrences']:
            if entry['bkid']!=book:continue
            reading={'t':'taxton','e':'elyon'}.get(suffix)
            if suffix=='e':
                if entry['section']!='ordinary_torah' or book not in data['elyon_body']:continue
                limit=data['elyon_body'][book]
            else:
                if entry.get('strand')!=reading:continue
                limit=selection
            if selection and (entry['section']!='haftarah' or entry['occurrence']!=selection['occurrence']):continue
            allowed=span(book,limit['start'],limit['stop']) if limit else frozenset(positions(book))
            for leaf in entry['pages']:
                part=span(book,leaf['start'],leaf['stop'])&allowed
                if part&query:
                    row={'page':leaf['page'],'bkid':book,'section':entry['section'],'occurrence':entry['occurrence'],
                         'start':list(min(part)),'stop':list(max(part)),'rotation_clockwise':leaf.get('rotation_clockwise',0)}
                    if reading:row['strand']=reading
                    result.append(row)
        return sorted(result,key=lambda r:r['page'])
    queries=set()
    for entry in data['occurrences']:
        suffix='t' if entry.get('strand')=='taxton' else None
        for leaf in entry['pages']:
            for end in ('start','stop'):queries.add((entry['bkid'],tuple(leaf[end][:2]),suffix,None))
    for book,extent in data['elyon_body'].items():
        for cv in sorted({p[:2] for p in span(book,extent['start'],extent['stop'])}):queries.add((book,cv,'e',None))
    for name,rite in data['rites'].items():
        for cv in sorted({p[:2] for p in span(rite['bkid'],rite['start'],rite['stop'])}):queries.add((rite['bkid'],cv,None,name))
    for book,cv,suffix,rite in sorted(queries,key=repr):
        expected=tiqqun_expected(book,cv,suffix=suffix,rite=rite)
        assert lookup.resolve(index,book,*cv,strand=suffix,rite=rite)==expected,(book,cv,suffix,rite)
        checks['tiqqun_rite_verse' if rite else 'tiqqun_named_verse' if suffix else 'tiqqun_bare_edge_verse']+=1
        query_records.append({'book':book,'cv':list(cv),'suffix':suffix,'rite':rite,'expected_pages':[r['page'] for r in expected]})
    for name,rite in data['rites'].items():
        wrong='Genesis' if rite['bkid']!='Genesis' else 'Exodus'
        assert lookup.resolve(index,wrong,1,1,rite=name)==[];checks['tiqqun_wrong_book_refusal']+=1
    try:lookup.resolve(index,'Genesis',1,1,rite='unapproved-review-fixture')
    except ValueError:checks['tiqqun_unknown_rite_refusal']+=1
    else:raise AssertionError('Unknown rite accepted')
    save('interval-oracle.json',{'checks':dict(checks),'actual_validated_catalog_books':len(validated),
        'named_strand_projections':len(named_cache),'method':'Expected rows derive from explicit sets of canonical positions per catalog interval, independent of resolver clipping. Real validation memoized once per immutable catalog/book; source projections memoized; expected query results are rebuilt.',
        'tiqqun_queries':query_records})
    print(json.dumps(dict(checks)))

def fixtures():
    fixture=ROOT/'fixtures';scans=fixture/'scans';catalogs=fixture/'catalogs'
    assert not fixture.exists();scans.mkdir(parents=True);catalogs.mkdir()
    originals=raw_catalogs();indexes={eid:json.loads(raw) for eid,raw in originals.items()}
    for eid,index in indexes.items():
        folder=scans/editions.folder_name(eid);folder.mkdir()
        for page in index['pages']:(folder/page['file']).write_bytes(b'')
        (catalogs/f'{eid}.json').write_bytes(originals[eid])
    os.environ['BOOK_SCANS_ROOT']=str(scans)
    assert all(editions.edition_dir(eid).is_relative_to(scans) for eid in editions.ALL_EDITION_IDS)
    # Actual unmodified survey CLI writes the five tracked catalogs, which must
    # reproduce byte for byte. All filenames are disposable zero-byte fixtures.
    command=[PYTHON,'py/main_scan_pages.py','survey']
    process=subprocess.run(command,cwd=TREE,capture_output=True)
    (OUT/'survey-cli.stdout').write_bytes(process.stdout);(OUT/'survey-cli.stderr').write_bytes(process.stderr)
    assert process.returncode==0 and raw_catalogs()==originals
    cli=[{'argv':command,'exit':process.returncode,'fixture_scans':5720,'tracked_catalogs_byte_identical':True}]
    # Every mutation replay routes catalog writes only into a disposable public
    # copy. MAM text still comes from the frozen tracked products.
    editions.index_dir=lambda:catalogs
    results=[]
    def catalog_bytes():return {eid:(catalogs/f'{eid}.json').read_bytes() for eid in editions.ALL_EDITION_IDS}
    def rejected(label,operation,errors=(survey.SurveyError,ValueError)):
        before=catalog_bytes()
        try:operation()
        except errors as error:
            assert catalog_bytes()==before,label
            results.append({'check':label,'outcome':'expected refusal before any write','type':type(error).__name__,'message':str(error)})
        else:raise AssertionError(label+' was accepted')
    nontext={'jc1':'#99-front-cover.jpg','koren':'X-review-front-cover.jpg','simanim-tanakh':'X-review-front-cover.jpg',
             'simanim-tiqqun':'A99.jpg','bhl':'#99-front-cover.jpg'}
    newtext={'jc1':'999-G.jpg','koren':'A1-G-999.jpg','simanim-tanakh':'A1-G-9999.jpg','simanim-tiqqun':'C999.jpg','bhl':'9999-G.jpg'}
    for eid,index in indexes.items():
        folder=scans/editions.folder_name(eid)
        added=folder/nontext[eid];added.write_bytes(b'')
        survey.survey_editions((eid,))
        revised=index_io.read_index(eid)
        assert {k:v for k,v in revised.items() if k!='pages'}=={k:v for k,v in index.items() if k!='pages'}
        assert len(revised['pages'])==len(index['pages'])+1
        added.unlink();survey.survey_editions((eid,))
        assert (catalogs/f'{eid}.json').read_bytes()==originals[eid]
        results.append({'check':eid+' nontext addition/removal','outcome':'all non-page fields exact; removal restores original bytes'})
        page=next(p['file'] for p in index['pages'] if p['kind']=='body')
        missing=folder/page;missing.unlink()
        rejected(eid+' missing text',lambda:survey.survey_editions((eid,)))
        missing.write_bytes(b'')
        extra=folder/newtext[eid];extra.write_bytes(b'')
        rejected(eid+' new text',lambda:survey.survey_editions((eid,)))
        extra.unlink()
    # The last requested edition fails only after earlier editions can prepare a
    # nontext addition. No catalog may be written for this validation failure.
    early=scans/editions.folder_name('jc1')/nontext['jc1'];early.write_bytes(b'')
    missing_name=next(p['file'] for p in indexes['bhl']['pages'] if p['kind']=='body')
    late=scans/editions.folder_name('bhl')/missing_name;late.unlink()
    rejected('last-edition validation failure',survey.survey_all)
    late.write_bytes(b'');early.unlink()
    assert catalog_bytes()==originals
    book='Obadiah';eid='jc1';index=indexes[eid]
    records=[r for r in index['recs'] if r['bkid']==book]
    edges=[{'page':r['page'],'printed_page':r['printed_page'],'note':r['note'],
            'start':[r['startc'],r['startv'],r['start_phrase']],
            'stop':[r['stopc'],r['stopv'],r['stop_phrase']]} for r in records]
    save('census-public-edges.json',edges)
    census_command=[PYTHON,'py/main_scan_pages.py','census',eid,book,str(OUT/'census-public-edges.json')]
    census_process=subprocess.run(census_command,cwd=TREE,capture_output=True)
    (OUT/'census-cli.stdout').write_bytes(census_process.stdout);(OUT/'census-cli.stderr').write_bytes(census_process.stderr)
    assert census_process.returncode==0 and raw_catalogs()==originals
    cli.append({'argv':census_command,'exit':census_process.returncode,'records':len(edges),'tracked_catalogs_byte_identical':True})
    rejected('census missing terminal page',lambda:census.run(eid,book,edges[:-1]),(ValueError,))
    bad=deepcopy(edges);bad[0]['start'][2]=''
    rejected('census empty cue',lambda:census.run(eid,book,bad),(ValueError,))
    before=index_io.read_index(eid)
    assert census.run(eid,book,edges)==len(edges)
    after=index_io.read_index(eid)
    assert (catalogs/f'{eid}.json').read_bytes()==originals[eid]
    assert [r for r in before['recs'] if r['bkid']!=book]==[r for r in after['recs'] if r['bkid']!=book]
    results.append({'check':'census stored-public-cue replay','records':len(edges),'other_book_records_preserved':len(before['recs'])-len(edges),'outcome':'whole catalog byte-identical'})
    assert raw_catalogs()==originals
    save('fixture-results.json',{'fixture':'5720 zero-byte public filename fixtures; never actual scans',
        'cli':cli,'catalog_path_injection':'Only mutation/census library replays set editions.index_dir to fresh fixture/catalogs; production modules and MAM products remain frozen.',
        'checks':results,'tracked_catalogs_unchanged':True,'all_fixture_catalogs_equal_source':catalog_bytes()==originals})
    save('fixture-inventory.json',{eid:{'folder':editions.folder_name(eid),'files':[p['file'] for p in idx['pages']]} for eid,idx in indexes.items()})
    print(json.dumps({'fixture_files':sum(len(i['pages']) for i in indexes.values()),'checks':len(results),'cli_exit':process.returncode}))

if __name__=='__main__':
    if sys.argv[1]=='inventory':inventory()
    elif sys.argv[1]=='intervals':intervals()
    elif sys.argv[1]=='fixtures':fixtures()
    else:raise ValueError(sys.argv[1])

from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
root=Path('/workspace/scratch/basics-647ef21c')
home=Path('/workspace/MAM-basics')
def git(tree,*args):return subprocess.check_output(['git','-C',str(tree),*args])
assert git(root/'head','rev-parse','HEAD').decode().strip()=='647ef21ca9d09b1b50264b000cd6a31fd376e572'
assert git(root/'receipts','rev-parse','HEAD').decode().strip()=='4f4dbd35e716535ec5ed6e95f56d982adc8519bf'
assert not git(root/'head','status','--porcelain=v1','-z')
assert not git(root/'receipts','status','--porcelain=v1','-z')
record=json.loads(Path(str(root)+'-slot.json').read_bytes())
record.update(observed_utc=datetime.now(timezone.utc).isoformat(),released_slots_observed=41,
              active_checks=[],home_head=git(home,'rev-parse','HEAD').decode().strip(),
              worktrees=git(home,'worktree','list','--porcelain').decode(),receipt_parent=git(root/'receipts','rev-parse','HEAD').decode().strip(),
              setup_corrections=['Initial pre-claim helper counted its own PID 795; corrected only self-PID exclusion.',
                                 'Local receipt branch was clean at 50cf1ba9; fast-forwarded to exact remote 4f4dbd35 before edits.'])
(root/'evidence/admission.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record,indent=2))

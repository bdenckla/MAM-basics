from pathlib import Path
from html.parser import HTMLParser
import json
import os
import re
import runpy
import subprocess
from urllib.parse import unquote,urlsplit

import pytest
import main_0_mega as mega
import main_taamey_d as cli
import main_taamey_d_build as build
from taamey_d.doc import gen_doc

ROOT=Path('/workspace/review-hourly-20261029-phase2-basics')

def font_bytes():
    return {str(p.relative_to(ROOT)):p.read_bytes() for p in (ROOT/'Taamey-D/font-m-TaD').iterdir() if p.is_file()}|{'site-font':(ROOT/'gh-pages/woff2/Taamey_D.woff2').read_bytes()}

def test_mega_doc_step_never_builds_or_spawns(monkeypatch):
    assert mega._STEPS[-1].step_id=='taamey-d-doc'
    assert mega._STEPS[-1].runner is mega._run_taamey_d_doc
    before=font_bytes()
    def forbidden(*args,**kwargs):raise AssertionError('font build/process invocation from documentation scope')
    with monkeypatch.context() as m:
        m.setattr(build,'generate',forbidden);m.setattr(build,'run_fontforge',forbidden)
        m.setattr(build.fill_in_template,'fill_in',forbidden)
        m.setattr(subprocess,'run',forbidden);m.setattr(subprocess,'Popen',forbidden);m.setattr(os,'system',forbidden)
        mega._STEPS[-1].runner()
    assert font_bytes()==before

def test_document_parser_cannot_dispatch_build():
    assert cli.build_parser().parse_args(['doc']).command=='doc'
    with pytest.raises(SystemExit) as e:cli.build_parser().parse_args(['build'])
    assert e.value.code==2

def test_build_import_lint_has_negative_controls():
    mod=runpy.run_path(str(ROOT/'py/tests/test_taamey_d_build_imports.py'))
    check=mod['_import_problems']
    assert check('probe','taamey_d_build.fill_in_template','import mb_cmn')
    assert check('probe','taamey_d_build.fill_in_template',"__import__('mb_cmn')")
    assert check('probe','taamey_d_build.fill_in_template','importlib.import_module(variable)')
    assert not check('probe','taamey_d_build.fill_in_template','from . import my_open\nimport pathlib')

def test_frozen_image_guard_precedes_writes(tmp_path,monkeypatch):
    pages=[ROOT/'gh-pages/taamey-d/Taamey_D.html',ROOT/'gh-pages/taamey-d/Xolam_xaser_for_alef.html']
    before=[p.read_bytes() for p in pages]
    data=json.loads(gen_doc._COMPARISON_PROVENANCE.read_text());data['images'][0]['text (code points)']=['U+0041']
    path=tmp_path/'provenance.json';path.write_text(json.dumps(data),encoding='utf-8');monkeypatch.setattr(gen_doc,'_COMPARISON_PROVENANCE',path)
    with pytest.raises(AssertionError,match='differs from its frozen image'):cli.almost_main(['doc'])
    assert [p.read_bytes() for p in pages]==before

class Links(HTMLParser):
    def __init__(self):super().__init__();self.links=[]
    def handle_starttag(self,tag,attrs):
        self.links.extend(v for k,v in attrs if k in ('href','src') and v)

def test_moved_page_and_CSS_assets_resolve():
    for page in (ROOT/'gh-pages/taamey-d').glob('*.html'):
        parser=Links();parser.feed(page.read_text())
        for value in parser.links:
            url=urlsplit(value)
            if url.scheme or url.netloc or not url.path:continue
            target=(page.parent/unquote(url.path)).resolve()
            assert target.is_relative_to(ROOT/'gh-pages'),(page.name,value)
            assert target.exists(),(page.name,value)
    css=ROOT/'gh-pages/taamey-d/Taamey-doc-styles.css'
    urls=re.findall(r'url\([\"\x27]?([^\"\x27)]+)',css.read_text())
    assert urls==['../woff2/Taamey_D.woff2']
    assert (css.parent/urls[0]).resolve()==ROOT/'gh-pages/woff2/Taamey_D.woff2'

"""Public-only parser/regex probes and actual Black caller on disposable fixtures."""

import ast
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
from unittest.mock import patch

from repo_util import maintenance_policy as policy, run_black
from repo_util.repo_selection import RepoInfo

ROOT = Path("/workspace/scratch/basics-cfdbb64e-checkout")
OUT = Path("/workspace/scratch/basics-cfdbb64e-artifacts")
BASE = "9f8901a92f8f040060841b1e5ba19524b97bbba3"
HEAD = "cfdbb64ef8fc24e777d4d296efb7fe4ac966346d"
FIXTURES = Path("/workspace/scratch/basics-cfdbb64e-fixtures")


def git(*args):
    return subprocess.check_output(["git", "-C", str(ROOT), *args])


def capture(rev, name):
    return git("show", rev + ":" + name)


assert git("rev-parse", "HEAD").decode().strip() == HEAD
assert policy.DEFAULT_VENDORING_POLICY == ROOT / "in/vendoring_policy.json"
names = [
    n.decode() for n in git("diff", "--name-only", "-z", BASE, HEAD).split(b"\0") if n
]
assert names == ["in/vendoring_policy.json", "py/repo_util/maintenance_policy.py"]
before = json.loads(capture(BASE, names[0]))
after = json.loads(capture(HEAD, names[0]))
remaining = {k: v for k, v in after.items() if k not in {"comment", "record_dirs"}}
assert remaining == {k: v for k, v in before.items() if k != "comment"}
declared = policy._record_dirs(after)
assert len(declared) == 1 and sum(map(len, declared.values())) == 3
merged = policy.vendored_overrides()
for repo, dirs in declared.items():
    assert merged[repo][-len(dirs) :] == dirs

# Syntax and all unaffected function ASTs are independently checked.
trees = [ast.parse(capture(rev, names[1])) for rev in [BASE, HEAD]]
ignored = {"_record_dirs", "vendored_overrides", "vendored_exclude_regex"}
functions = [
    {
        n.name: ast.dump(n)
        for n in t.body
        if isinstance(n, ast.FunctionDef) and n.name not in ignored
    }
    for t in trees
]
assert functions[0] == functions[1]

bad_sections = [None, {}, "not-list"]
bad_entries = [
    None,
    [],
    {},
    {"dest_repo": "Example"},
    {"dest_repo": "Example", "dest_dirs": ["records/"], "extra": True},
    {"dest_repo": None, "dest_dirs": ["records/"]},
    {"dest_repo": "Example", "dest_dirs": None},
    {"dest_repo": "Example", "dest_dirs": "records/"},
    {"dest_repo": "Example", "dest_dirs": []},
    {"dest_repo": "Example", "dest_dirs": [3]},
    {"dest_repo": "Example", "dest_dirs": ["records"]},
    {"dest_repo": "Example", "dest_dirs": [""]},
]
rejected = 0
for section in bad_sections + [[entry] for entry in bad_entries]:
    try:
        policy._record_dirs({"record_dirs": section})
    except ValueError:
        rejected += 1
    else:
        raise AssertionError(("Accepted invalid record_dirs", section))
assert policy._record_dirs({"record_dirs": []}) == {}
assert policy._record_dirs(
    {
        "record_dirs": [
            {"dest_repo": "Example", "dest_dirs": ["first/"]},
            {"dest_repo": "Example", "dest_dirs": ["next/"]},
        ]
    }
) == {"Example": ["first/", "next/"]}

checks = []
regex = re.compile(
    policy.vendored_exclude_regex(["vendor_pkg"], ["records[+]/", "single.copy.py"])
)
cases = [
    ("/records[+]/", True),
    ("/records[+]/new.py", True),
    ("/records[+]/nested/future.py", True),
    ("/recordsx/new.py", False),
    ("/records[+]-extra/new.py", False),
    ("/single.copy.py", True),
    ("/single.copy.py.extra.py", False),
    ("/singleXcopy.py", False),
    ("/single.copy.py/child.py", False),
    ("/py/vendor_pkg/one.py", True),
    ("/deep/py/vendor_pkg/one.py", True),
    ("/py/vendor_pkg_extra/one.py", False),
]
for name, expected in cases:
    assert bool(regex.search(name)) == expected, name
    checks.append({"path": name, "excluded": expected})
actual_policy_checks = 0
for repo, dirs in declared.items():
    compiled = re.compile(
        policy.vendored_exclude_regex(policy.vendored_package_names(), merged[repo])
    )
    for directory in dirs:
        for path, expected in [
            ("/" + directory, True),
            ("/" + directory + "future/nested.py", True),
            ("/" + directory[:-1] + "-extra/live.py", False),
        ]:
            assert bool(compiled.search(path)) == expected, path
            actual_policy_checks += 1
# Both existing file branches and new folder branches are leading-slash searches,
# rather than start-of-string anchors. Record that limit without claiming a
# root-only matcher or inspecting any private path inventory.
assert regex.search("/prefix/records[+]/new.py")


def fixture(folder, files):
    folder.mkdir(parents=True)
    subprocess.run(
        ["git", "init", "-q", "--initial-branch=main", str(folder)], check=True
    )
    subprocess.run(
        [
            "git",
            "-C",
            str(folder),
            "config",
            "remote.origin.url",
            "https://github.com/example/" + folder.name + ".git",
        ],
        check=True,
    )
    for name in files:
        path = folder / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("value=  1\n", encoding="utf-8", newline="\n")
    subprocess.run(["git", "-C", str(folder), "add", "--", *files], check=True)
    return RepoInfo(
        path=folder, head_commit="synthetic-fixture", head_committer_iso=None
    )


def portable(repo_dir, target, extra):
    # The unchanged command selector discovers Windows .venv/Scripts paths.
    # Adapt only that discovery for this Linux fixture, keeping the real caller,
    # regex, subprocess execution and actual owning Black implementation.
    return [sys.executable, "-B", "-m", "black", *extra, target]


files = [
    "records/keep.py",
    "records/nested/future.py",
    "records-extra/live.py",
    "single.copy.py",
    "single.copy.py.extra.py",
    "nested/vendor_pkg/keep.py",
    "nested/vendor_pkg_extra/live.py",
    "live.py",
]
info = fixture(FIXTURES / "PublicFixture", files)
excluded = {
    "records/keep.py",
    "records/nested/future.py",
    "single.copy.py",
    "nested/vendor_pkg/keep.py",
}
with patch.object(run_black, "_select_black_command", side_effect=portable):
    results = run_black.run_black_across_repos(
        [info],
        black_target=".",
        black_timeout_sec=30,
        frozen_repos={},
        vendored_package_names=["vendor_pkg"],
        vendored_overrides={"PublicFixture": ["records/", "single.copy.py"]},
        source_repo=ROOT,
        report_json=None,
        report_txt=None,
    )
assert results[0]["black"]["success"]
for name in files:
    expected = "value=  1\n" if name in excluded else "value = 1\n"
    assert (info.path / name).read_text() == expected, name
source = fixture(
    FIXTURES / "PublicSourceFixture", ["records/one.py", "py/vendor_pkg/two.py"]
)
with patch.object(run_black, "_select_black_command", side_effect=portable):
    own = run_black.run_black_across_repos(
        [source],
        black_target=".",
        black_timeout_sec=30,
        frozen_repos={},
        vendored_package_names=["vendor_pkg"],
        vendored_overrides={"PublicSourceFixture": ["records/"]},
        source_repo=source.path,
        report_json=None,
        report_txt=None,
    )
assert (
    own[0]["black"]["success"] and "--extend-exclude" not in own[0]["black"]["command"]
)
assert all(
    (source.path / name).read_text() == "value = 1\n"
    for name in ["records/one.py", "py/vendor_pkg/two.py"]
)
assert not git("status", "--porcelain=v1", "-z")
result = {
    "result": "PASS",
    "base": BASE,
    "head": HEAD,
    "scope": "One commit / two public paths; no private input read.",
    "malformed_entries_rejected": rejected,
    "valid_empty_and_merged_repo_sections": True,
    "regex_cases": checks,
    "declared_policy_regex_cases": actual_policy_checks,
    "unaffected_function_ASTs": len(functions[0]),
    "caller": {
        "disposable_files": 10,
        "non_source_preserved": 4,
        "non_source_formatted": 4,
        "source_originals_formatted": 2,
        "real_Black_invocations": 2,
        "portable_adapter": "Only Windows executable discovery replaced with the owning Linux interpreter; maintained run_black_across_repos and real Black used.",
        "results": results + own,
    },
    "limits": "Regex uses slash-bounded search, not start-of-string anchoring. No private-file inventory or real repository sweep, full CLI/Windows execution, product generation, broad test or source/editorial/browser claim.",
}
(OUT / "independent-result.json").write_text(
    json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
)
print(json.dumps({k: v for k, v in result.items() if k != "caller"}, indent=2))

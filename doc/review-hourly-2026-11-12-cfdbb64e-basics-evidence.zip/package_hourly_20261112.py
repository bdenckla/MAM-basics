"""Package a completed owning-repository screen without importing source main."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

meta = json.loads(Path(sys.argv[1]).read_text())
home, source, receipt, out = [
    Path(meta[k]) for k in ["home", "source", "receipt", "out"]
]
stem, parent, head, repo = [meta[k] for k in ["stem", "parent", "head", "repo"]]


def git(root, *args):
    return subprocess.check_output(["git", "-C", str(root), *args])


assert git(receipt, "rev-parse", "HEAD").decode().strip() == parent
assert not git(receipt, "status", "--porcelain=v1", "-z")
assert not git(source, "status", "--porcelain=v1", "-z")
stages = []
for file in sorted(out.glob("*.json")):
    record = json.loads(file.read_text())
    if "stage" in record and file.name != "current-stage.json":
        assert record["state"] == "completed", file
        assert record["status_clean"] or record["stage"] in meta.get(
            "recorded_setup_failures", []
        ), file
        stages.append(record)
for name in meta["required_stages"]:
    assert name in {s["stage"] for s in stages}, name
for s in stages:
    expected = meta.get("expected_nonzero", {}).get(s["stage"], 0)
    assert s["exit_code"] == expected, (s["stage"], s["exit_code"], expected)
summary = (out / "review-summary.md").read_text()
original_status = git(home, "show", f"{parent}:doc/review-trial-status.md").decode()
status = original_status
for token in meta["anchors"]:
    assert token in status, token
for label in meta.get("rename_old_labels", []):
    status = status.replace(
        "| " + label + " |",
        "| " + label.replace("Latest", "Previous", 1) + " |",
        1,
    )
new_rows = (
    f'| Latest bounded screen {meta["short"]} | `{meta["base"]}` -> `{head}`; {meta["scope"]}. {meta["disposition"]} [Receipt]({stem}.md). |\n'
    f'| Latest focused evidence {meta["short"]} | {meta["brief_checks"]} Historical overall-reviewed and broad-run anchors unchanged. [Evidence]({stem}-evidence.zip). |\n'
)
marker = "| Adopted baseline |"
assert marker in status
index = status.index(marker)
status = status[:index] + new_rows + status[index:]
status += (
    f'\n\n## Bounded screen, 2026-11-12 (UTC), {meta["short"]}\n\n'
    + summary
    + f"\n\n[Receipt]({stem}.md) and [evidence]({stem}-evidence.zip). Overall anchors, pending windows and immutable prior receipts are retained.\n"
)
for target in set(re.findall(r"\]\(([^)]+)\)", status)):
    if (
        "://" in target
        or target.startswith("#")
        or target in [stem + ".md", stem + "-evidence.zip"]
    ):
        continue
    if not (receipt / "doc" / target.split("#")[0]).exists():
        raise AssertionError(
            ("Missing inherited relative link; retain an immutable target", target)
        )
for name in meta.get("input_files", []):
    (out / ("input-" + name.replace("/", "-"))).write_bytes(
        git(home, "show", f"{head}:{name}")
    )
(out / "inherited-status.md").write_text(original_status)
(out / "stage-summary.json").write_text(
    json.dumps(sorted(stages, key=lambda s: s["started_utc"]), indent=2) + "\n"
)
for key, name in [("source", head), ("parent", parent)]:
    (out / ("workflows-" + key + ".txt")).write_bytes(
        git(home, "ls-tree", "-r", name, ".github")
    )
for script in meta.get("scripts", []):
    path = Path(script)
    (out / path.name).write_bytes(path.read_bytes())
(out / "run-config.json").write_bytes(Path(meta["config"]).read_bytes())
payload = {}
for file in sorted(out.iterdir()):
    if file.is_file():
        raw = file.read_bytes()
        payload[file.name] = dict(
            bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()
        )
archive = receipt / "doc" / (stem + "-evidence.zip")
with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as z:
    for name in payload:
        z.write(out / name, name)
    z.writestr("manifest.json", json.dumps(payload, indent=2) + "\n")
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name, info in payload.items():
        raw = z.read(name)
        assert (
            len(raw) == info["bytes"]
            and hashlib.sha256(raw).hexdigest() == info["sha256"]
        )
text = (
    f"# {repo} bounded hourly screen\n\nState: completed 2026-11-12; bounded screen and focused checks only\n\n"
    + summary
    + "\n\nCommands ran sequentially in the exact committed owning checkout, with the home interpreter; baseline comparisons are explicitly identified below. Full command arrays, UTC timestamps, durations, failures, output diffs, checker and payload manifest are in the evidence ZIP.\n\n| Stage | Command | Exit | Seconds |\n| --- | --- | --- | --- |\n"
)
for stage in sorted(stages, key=lambda s: s["started_utc"]):
    command = stage["command"]
    show = " ".join(command[2:]) if command[0].endswith("python") else " ".join(command)
    if len(show) > 240:
        show = " ".join(command[2:4]) + " (full command in evidence)"
    text += f'| {stage["stage"]} | `{show}` | {stage["exit_code"]} | {stage["elapsed_seconds"]:.6f} |\n'
text += f"\n[Evidence]({stem}-evidence.zip). Receipt parent `{parent}`; source `{head}`. This commit changes only the receipt, evidence and maintained status. No main/shared integration or deployment.\n"
(receipt / "doc" / (stem + ".md")).write_text(text)
(receipt / "doc/review-trial-status.md").write_text(status)
prepared = dict(
    repo=repo,
    parent=parent,
    source=head,
    branch=meta["branch"],
    prepared_utc=datetime.now(timezone.utc).isoformat(),
    paths=[f"doc/{stem}.md", f"doc/{stem}-evidence.zip", "doc/review-trial-status.md"],
    evidence_bytes=archive.stat().st_size,
    evidence_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
    payload_count=len(payload),
    stages=len(stages),
    stage_successes=sum(s["exit_code"] == 0 for s in stages),
    stage_failures=sum(s["exit_code"] != 0 for s in stages),
)
Path(meta["prepared"]).write_text(json.dumps(prepared, indent=2) + "\n")
print(json.dumps(prepared, indent=2))

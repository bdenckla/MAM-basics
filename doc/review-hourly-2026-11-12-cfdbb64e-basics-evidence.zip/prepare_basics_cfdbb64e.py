"""Prepare the public maintenance-policy receipt from public inputs only."""

import json
from pathlib import Path
import subprocess

PREFIX = Path('/workspace/scratch/basics-cfdbb64e')
meta = json.loads(Path(str(PREFIX) + '-init.json').read_text())
out = Path(meta['out'])
def git(*args):
    return subprocess.check_output(['git', '-C', meta['home'], *args])

workflow = '.github/workflows/pages.yml'
expected = '18ceb19405424710bda47d9a38c470cc2ed9c385'
for rev in [meta['head'], meta['parent']]:
    assert [x.decode() for x in git('ls-tree', '-r', '--name-only', '-z', rev, '.github').split(b'\0') if x] == [workflow]
    assert git('rev-parse', rev + ':' + workflow).decode().strip() == expected
    assert 'on:\n  workflow_dispatch:\n' in git('show', rev + ':' + workflow).decode()
assert not git('ls-remote', '--heads', 'origin', 'refs/heads/' + meta['branch'])
(out / 'publication-preflight.json').write_text(json.dumps({'source': meta['head'], 'parent': meta['parent'], 'branch': meta['branch'], 'branch_absent': True, 'sole_workflow_blob': expected, 'trigger': 'workflow_dispatch only; none performed', 'ownership': 'Fresh task-owned isolated receipt branch; no assigned shared/deployment dependency.'}, indent=2) + '\n')
(out / 'review-summary.md').write_text('''Frozen endpoint `9f8901a92f8f040060841b1e5ba19524b97bbba3` -> `cfdbb64ef8fc24e777d4d296efb7fe4ac966346d`: one commit / two public paths. No consequential introduced defect established; no product repair. Review and execution use public material only.

The public policy adds three declared record-folder exclusions. The parser requires the record section/list, exact entry keys, string folder entries and trailing slashes, and merges those folders with existing file exclusions. The regex escapes metacharacters, retains file end anchors, and treats a trailing-slash entry as a whole subtree. All other configuration apart from the explanatory comment and new section is unchanged; all five unaffected function ASTs match the base. The unchanged maintained caller still adds exclusions only for repositories other than the source repository.

Changed-source Black passes (0.151923 s); all four existing prose-convention tests pass through `py/main_test.py` (16.145645 s wall / 15.93 s pytest). Independent checks pass (0.431051 s): 15 malformed policy cases rejected; valid empty and repeated-repository sections handled; 12 generic file/folder/package/metacharacter regex cases and nine declared-policy cases pass. The maintained `run_black_across_repos` is exercised against two disposable public Git fixtures with actual owning-environment Black. Four excluded files retain exact bad-format bytes, four nearby live files are formatted, and both source-repository originals are formatted without exclusions. Only the unchanged Windows executable-discovery helper is adapted to the owning Linux interpreter; this is not full CLI or native Windows evidence. No actual repository sweep or private inventory was run.

The regex is a leading-slash path-component search, not a start-of-string anchor; a nested occurrence of the same folder suffix also matches. The probes record this behavior explicitly and do not claim root-only matching. No consequential incorrect exclusion is established by this public-only bounded screen. There were no failed command/check attempts and no tracked or untracked source differences. The real maintenance CLI and roster were inspected without dispatching the mutating sweep. No product generation, broad mega/suite, private input inspection, source refresh or visual/font check was warranted or run.

Lineage continues from `6187492ddea354efca7b80909e7f62a27f62447e`, keeping every historical row, pending window and finished receipt. Overall reviewed remains `210affe3ac2931473bead0de839be0de08309e3d`; broad-tested remains `354cc0b7077cb46ba5d7cfc8dd9b453ff68c7bf0`. Prior browser/source/editorial/HP and frozen-font limits remain separate. Local process/slot ownership was clear; cross-machine ownership remains unverified. The maintenance owner retains real sweep/decision work, and the next broad owner retains broad coverage.

Source and receipt parent share the same sole manual-dispatch Pages workflow, verified before the fresh isolated receipt push. No workflow dispatch, main/shared integration or deployment occurs. Exact remote commit/scope/evidence verification and task-worktree/slot cleanup are recorded at closeout; home and unrelated work are preserved.
''')
meta.update({
    'stem': 'review-hourly-2026-11-12-cfdbb64e-basics',
    'scope': 'one commit / two public maintenance-policy paths',
    'disposition': 'No consequential introduced defect or repair; no real repository sweep or product generation.',
    'brief_checks': 'Source Black and four prose tests pass. Fifteen parser negatives, 21 regex cases and two actual Black caller fixture runs pass; no private input read. Regex search/portable-discovery limits retained.',
    'anchors': ['210affe3ac2931473bead0de839be0de08309e3d', '354cc0b7077cb46ba5d7cfc8dd9b453ff68c7bf0'],
    'rename_old_labels': ['Latest bounded screen 9f8901a9', 'Latest focused evidence 9f8901a9'],
    'required_stages': ['black', 'prose-tests', 'independent'],
    'input_files': ['in/vendoring_policy.json', 'py/repo_util/maintenance_policy.py', 'py/repo_util/run_black.py', 'py/main_repo_util.py'],
    'scripts': ['/workspace/scratch/check_basics_cfdbb64e.py', '/workspace/scratch/record_hourly_20261111_15.py', '/workspace/scratch/package_hourly_20261112.py', '/workspace/scratch/prepare_basics_cfdbb64e.py'],
    'config': str(PREFIX) + '-config.json', 'prepared': str(PREFIX) + '-prepared.json',
})
Path(str(PREFIX) + '-meta.json').write_text(json.dumps(meta, indent=2) + '\n')

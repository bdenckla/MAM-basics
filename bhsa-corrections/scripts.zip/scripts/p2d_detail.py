"""Details of Test A's ps/nu/gn/prs groups from out/p2d-scan.json, for judging them.

Throwaway scratch (slice p2d). Usage (from the MAM-basics root):
  python -I p2d_detail.py <this folder> <out txt> [<kind>]

For each group of the kind (default "ps/nu/gn/prs"): the key, the group's analysis and the key's
analyses with counts, every reference, MAM's atom there, the fields that differ from the key's
commonest analysis, the morphology features of the first atom's slots and of an atom with the
commonest analysis; then the first atom's verse, atom by atom, each with its analysis and its
phrase's function, the flagged atom marked with "=>".
"""

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402
import p2d_scan_atoms as P  # noqa: E402


def tup(a):
    return tuple(tuple(t) for t in a)


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8", errors="backslashreplace")
    here, out = Path(sys.argv[1]), Path(sys.argv[2])
    kind = sys.argv[3] if len(sys.argv) > 3 else "ps/nu/gn/prs"
    data = json.loads((here / "out" / "p2d-scan.json").read_text(encoding="utf-8"))
    B = C.Bhsa()
    gw = B.wf("g_word_utf8")
    feats = [B.wf(f) for f in P.FIELDS]
    function = B.nf("function")
    english = {short.replace(" ", ""): name for name, short in C.ib_review.SHORT.items()}
    english["Eccl"] = "Ecclesiastes"
    by_ref = {}
    for (book, ch, v) in B.verse_slots:
        by_ref["%s %d:%d" % (english[C.OSIS_FROM_BHSA[book]], ch, v)] = (C.OSIS_FROM_BHSA[book], ch, v)
    lines = []
    for g in data["test_a"]:
        if g["kind"] != kind:
            continue
        k = (tuple(g["key"][0]), g["key"][1])
        lines.append("A%d | %s | this: %s x%d | %s" % (
            g["n"], P.fmt_key(k), P.fmt(tup(g["analysis"])), len(g["atoms"]), "; ".join(g["refs"])))
        lines.append("   key: %s" % ", ".join("%s x%d" % (P.fmt(tup(a)), n) for a, n in g["key_counts"]))
        lines.append("   MAM: %s" % " | ".join(C.mnorm(C.ib_review.stripped(m)) if m else "(not aligned)" for m in g["mam"]))
        if g.get("diffs"):
            lines.append("   differs: %s" % "; ".join("%s %s %s (commonest %s)" % (d["lex"], d["field"], d["this"], d["commonest"]) for d in g["diffs"]))
        for label, ms in (("this", g.get("morph", [])), ("commonest at " + g["commonest_ref"], g.get("commonest_morph", []))):
            lines.append("   morph, %s: %s" % (label, " | ".join(
                "%s sp %s st %s pfm %s vbs %s vbe %s nme %s uvf %s prs %s" % (
                    C.mnorm(m["g_word_utf8"]), m["sp"], m["st"], C.mnorm(m["g_pfm_utf8"]), C.mnorm(m["g_vbs_utf8"]),
                    C.mnorm(m["g_vbe_utf8"]), C.mnorm(m["g_nme_utf8"]), C.mnorm(m["g_uvf_utf8"]), C.mnorm(m["g_prs_utf8"]))
                for m in ms)))
        osis, ch, v = by_ref[g["refs"][0]]
        first_slots = set()
        # the first atom's slots: find them by the verse's atoms and the group's key and analysis
        for ba in B.atoms(osis, ch, v, "ketiv"):
            a = tuple(tuple(f[s] for f in feats) for s in ba["slots"])
            if a == tup(g["analysis"]) and C.skey(ba["text"]).rstrip(C.MAQAF) == g["key"][1]:
                first_slots = set(ba["slots"])
                break
        verse = []
        for ba in B.atoms(osis, ch, v, "ketiv"):
            a = tuple(tuple(f[s] for f in feats) for s in ba["slots"])
            mark = "=>" if set(ba["slots"]) == first_slots else "  "
            verse.append("     %s %s [%s] {%s}" % (
                mark, C.mnorm(C.ib_review.stripped(ba["text"])), P.fmt(a),
                ",".join(function.get(B.phrase_of.get(s), "-") for s in ba["slots"])))
        lines.append("   verse %s:" % g["refs"][0])
        lines += verse
        lines.append("")
    out.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print("wrote", out, len(lines), "lines")


if __name__ == "__main__":
    main()

"""Examples of slot-level Test B rows whose atoms change class at the atom level (slice p2d).

Throwaway scratch. Usage (from the MAM-basics root): python -I p2d_explore.py <this folder> <out txt>

For each change of class (slot level -> atom level) other than both -> both: up to 12 examples,
each with the slot-level row (slot form, MAM's piece, analysis, own key, MAM's key) and the
atom-level row (atom forms, analysis, own key, MAM's key).
"""

import json
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402
import p2d_scan_atoms as P  # noqa: E402


def tup(a):
    return tuple(tuple(t) for t in a)


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    here, out = Path(sys.argv[1]), Path(sys.argv[2])
    atom_run = json.loads((here / "out" / "p2d-scan.json").read_text(encoding="utf-8"))
    slot_run = json.loads((here / "out" / "32-part2-scan.json").read_text(encoding="utf-8"))
    by_slot = {}
    for cls, rows in atom_run["test_b"].items():
        for r in rows:
            for s in r["slots"]:
                by_slot[s] = (cls, r)
    changes = defaultdict(list)
    for cls, rows in slot_run["test_b"].items():
        for r in rows:
            acls, ar = by_slot.get(r["slot"], ("(none)", None))
            if (cls, acls) != ("both", "both"):
                changes[(cls, acls)].append((r, ar))
    lines = []
    for (cls, acls), pairs in sorted(changes.items()):
        lines.append("== slot %s -> atom %s: %d slot rows" % (cls, acls, len(pairs)))
        for r, ar in pairs[:12]:
            sk = lambda a: "%s%s" % (a[1], "" if a[2] == "NA" else " %s %s" % (a[2], a[3]))  # noqa: E731
            lines.append("  %s | slot %s / MAM %s | %s | own %s | MAM's %s" % (
                r["ref"], C.mnorm(C.skey(r["bhsa"])), C.mnorm(C.skey(r["mam_piece"])), sk(r["analysis"]),
                ", ".join("%s x%d" % (sk(a), n) for a, n in r["own"]) or "-",
                ", ".join("%s x%d" % (sk(a), n) for a, n in r["mam_key"]) or "-"))
            if ar:
                lines.append("      atom %s / MAM %s | %s | own %s | MAM's %s" % (
                    C.mnorm(ar["bhsa_key"][1]), C.mnorm(ar["mam_key"][1]), P.fmt(tup(ar["analysis"])),
                    ", ".join("%s x%d" % (P.fmt(tup(a)), n) for a, n in ar["own"][:4]) or "-",
                    ", ".join("%s x%d" % (P.fmt(tup(a)), n) for a, n in ar["mam_key_counts"][:4]) or "-"))
        lines.append("")
    out.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print("wrote", out, len(lines), "lines")


if __name__ == "__main__":
    main()

"""p2a: a few more facts for the review (throwaway scratch).

Usage (from the MAM-basics root):
  .venv/Scripts/python.exe -I <folder>/scripts/p2a_extra.py <folder>

Writes out/p2a-extra.txt:
  - every one-yod qal imperfect or wayyiqtol of JR>[ (third masculine plural), with its accents;
  - every qal word of >SP[ whose first letter has a holam;
  - WLC 4.18's atoms aligned with the BHSA's at the review's places.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402
from p2a_check import Ctx  # noqa: E402

YOD = "\N{HEBREW LETTER YOD}"
HOLAM = "\N{HEBREW POINT HOLAM}"
PLACES = [158430, 342192, 163423, 299793, 301390, 230330, 420804, 378150, 419936, 152786, 328516, 156661]


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    here = Path(sys.argv[1])
    X = Ctx()
    f, gw = X.f, X.gw
    out = ["== JR>[ qal impf or wayq, p3 pl m, written with one yod at the start of the stem"]
    for s in sorted(X.key_of):
        if f["lex"][s] == "JR>[" and f["vs"][s] == "qal" and f["vt"][s] in ("impf", "wayq") and (f["ps"][s], f["nu"][s], f["gn"][s]) == ("p3", "pl", "m"):
            if not C.letters(gw[s]).startswith(YOD + YOD):
                out.append("   %s slot %d %s%s | %s | %s" % (X.ref(s), s, C.mnorm(gw[s]), f["trailer_utf8"].get(s, ""), f["g_word"][s], f["vt"][s]))
    out += ["", "== >SP[ qal words whose first letter has a holam"]
    for s in sorted(X.key_of):
        if f["lex"][s] == ">SP[" and f["vs"][s] == "qal":
            cl = C.clusters(gw[s])
            if cl and HOLAM in cl[0][1]:
                out.append("   %s slot %d %s | %s | %s" % (X.ref(s), s, C.mnorm(gw[s]), f["g_word"][s], X.morph(s)))
    out += ["", "== WLC 4.18's atoms at the review's places, aligned with the BHSA's atoms by letters"]
    for s in PLACES:
        b, ch, v = X.B.ref_of_slot[s]
        osis = C.OSIS_FROM_BHSA[b]
        b_atoms, mam, _ = X.verse(s)
        wlc = C.wlc418_side(C.read_wlc418_book(osis)[(ch, v)], "ketiv")
        to_w = C.align([a["text"] for a in b_atoms], [a["text"] for a in wlc])
        i, atom, mam_atom = X.atom_of(s)
        w = [wlc[j] for j in to_w[i]]
        out.append("   %s slot %d | BHSA %s | WLC 4.18 %s (notes %s) | MAM %s" % (
            X.ref(s), s, C.mnorm(atom["text"]), " ".join(C.mnorm(a["text"]) for a in w),
            [n for a in w for n in a["notes"]], C.mnorm(mam_atom)))
    (here / "out" / "p2a-extra.txt").write_text("\n".join(out) + "\n", encoding="utf-8", newline="\n")
    print("wrote out/p2a-extra.txt")


if __name__ == "__main__":
    main()

"""Print the BHSA's words of a lexeme in named verses, with their features, and MAM's atom that
has the same letters.

Throwaway scratch. Usage (from the MAM-basics root):
  python -I verify_slots.py <out txt> <OSIS>:<ch>:<v>:<lex> ...
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402

SHORT_FROM_OSIS = {s.replace(" ", ""): s for s in C.ib_review.SHORT.values()}
FEATS = ["lex", "sp", "vs", "vt", "ps", "nu", "gn", "st", "prs", "gloss", "voc_lex_utf8"]


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    out = Path(sys.argv[1])
    B = C.Bhsa()
    lint = C.load_lint()
    lines = []
    for arg in sys.argv[2:]:
        osis, ch, v, lex = arg.split(":", 3)
        ch, v = int(ch), int(v)
        atoms = B.atoms(osis, ch, v, "ketiv")
        mam = C.mam_atoms(lint, SHORT_FROM_OSIS[osis], ch, v, "ketiv", "cant-combined", arg)
        for a in atoms:
            hits = [s for s in a["slots"] if B.wf("lex").get(s) == lex]
            if not hits:
                continue
            same = [m for m in mam if C.letters(m) == C.letters(a["text"])]
            lines.append("%s %d:%d | BHSA atom %s | MAM atoms with its letters: %s" % (
                osis, ch, v, C.mnorm(a["text"]), " ".join(C.mnorm(m) for m in same) or "none"))
            for s in hits:
                lines.append("   slot %d %s | %s" % (s, C.mnorm(B.wf("g_word_utf8").get(s, "")),
                    " ".join("%s=%s" % (f, B.wf(f).get(s, "")) for f in FEATS)))
    out.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()

"""Glosses of the lexemes that slice p2b's reasons name (throwaway scratch).

Usage (from the MAM-basics root):
  C:/Users/BenDe/GitRepos/MAM-basics/.venv/Scripts/python.exe -I <this folder>/scripts/p2b_glosses.py

Prints each lexeme's BHSA gloss values with counts; writes out/p2b-glosses.txt.
"""

import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402

HERE = Path(__file__).resolve().parent.parent
LEXEMES = [">NJH/", ">NJH=/", "<Z==/", "<Z===/", ">LH/", ">LH===/", "FJM[", ">L/", ">L", ">L=", "R>H[", "HNH=", "HNH==",
           "CMRH=/", "XDL/", "KX=/"]


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    B = C.Bhsa()
    lex, gloss = B.wf("lex"), B.wf("gloss")
    found = defaultdict(Counter)
    for s, lx in lex.items():
        if lx in LEXEMES:
            found[lx][gloss.get(s, "")] += 1
    out = ["%s: %s" % (lx, dict(found[lx])) for lx in LEXEMES]
    text = "\n".join(out) + "\n"
    (HERE / "out" / "p2b-glosses.txt").write_text(text, encoding="utf-8", newline="\n")
    print(text)


if __name__ == "__main__":
    main()

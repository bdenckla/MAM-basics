"""Wait until the p2d scan's log shows its end or an error (throwaway scratch, slice p2d).

Usage: python -I p2d_wait.py <log file> <end marker> [<timeout seconds>]

Checks the log first, then every 5 seconds; prints the log's last lines and exits 0 at the end
marker, 1 at a traceback, 2 at the timeout.
"""

import sys
import time
from pathlib import Path


def tail(path, n=12):
    try:
        text = Path(path).read_text(encoding="utf-8", errors="replace")
    except FileNotFoundError:
        return ""
    return "\n".join(text.splitlines()[-n:])


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    log, marker = sys.argv[1], sys.argv[2]
    timeout = float(sys.argv[3]) if len(sys.argv) > 3 else 540
    t0 = time.monotonic()
    while True:
        try:
            text = Path(log).read_text(encoding="utf-8", errors="replace")
        except FileNotFoundError:
            text = ""
        if marker in text:
            print(tail(log))
            return 0
        if "Traceback" in text:
            print(tail(log, 40))
            return 1
        if time.monotonic() - t0 > timeout:
            print("timeout; log so far:\n" + tail(log))
            return 2
        time.sleep(5)


if __name__ == "__main__":
    sys.exit(main())

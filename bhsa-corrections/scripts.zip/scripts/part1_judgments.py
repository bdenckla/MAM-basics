"""Part 1's judgments: each case's class and the reason, written by Claude (Opus 5.5) on
2026-11-13 from out/10-part1-cases.txt, out/11-part1-compact.txt and out/13-lexinfo-part1.txt.

Classes, as the brief defines them:
  a: the BHSA's analysis fits only its written form (here WLC 4.18's), not MAM's;
  b: it fits only MAM's form: a correction;
  c: it fits both, because the difference is only in pointing;
  d: the BHSA's written form itself differs from WLC 4.18's (by the review's key, with the
     BHSA's way of writing a holam male not counted); the analysis class follows after "; ".

Each entry is (reference as the review has it, class, note). The notes name lexemes in the
ETCBC's transliteration and never retype Hebrew.
"""

JUDGMENTS = {
    1: ("Genesis 32:18", "c", "The conjunction `W` and a qal perfect; the conjunction's vowel does not bear on the analysis."),
    2: ("Genesis 34:11", "c", "Suffix `H` (third feminine singular) on `>B/` 'father': the analysis has the suffix that both spell, though WLC's he has no qamats."),
    3: ("Exodus 1:3", "c", "The conjunction and the name `BNJMN/`."),
    4: ("Exodus 10:28", "b", "Written with segol, analysed as the negative: lexeme `>L=`, part of speech `nega`, its own phrase `NegP` with function `Nega`, in a clause of type `xYq0`."),
    5: ("Numbers 2:14", "c", "The conjunction and `MVH/` 'staff'."),
    6: ("Numbers 26:7", "c", "The article and the gentilic `R>WBNJ/`."),
    7: ("Deuteronomy 2:9", "a", "Written with segol and analysed as the preposition `>L`, but placed inside the verb's phrase (`VP`, `Pred`) rather than in a `PP`; no `NegP`. Its clause type is `ZYq0`, where Exodus 10:28's, with its `NegP`, is `xYq0`. The BHSA's next atom differs from WLC's in one accent code point: HEBREW ACCENT QADMA where WLC has the first of two HEBREW ACCENT PASHTA marks."),
    8: ("Deuteronomy 3:12", "c", "Preposition, an unwritten article, and `R>WBNJ/`."),
    9: ("Deuteronomy 3:16", "c", "As at Deuteronomy 3:12, with the conjunction."),
    10: ("Deuteronomy 4:43", "c", "As at Deuteronomy 3:12."),
    11: ("Joshua 12:6", "c", "As at Deuteronomy 3:12."),
    12: ("Joshua 22:19", "a", "As at Deuteronomy 2:9: written with segol, analysed as the preposition `>L` inside the verb's phrase (`VP`, `Pred`); clause type `WxY0`."),
    13: ("Judges 15:14", "d; c", "The BHSA's text has MAM's vowels, unlike WLC 4.18, 4.20, 4.22 and UXLC 2.6. WLC 4.18's notes Q, n and v say that WLC reads the vowels of L differently from BHS here, so the BHSA, a transcription of BHS, has BHS's form. The analysis, `PLCTJ/` 'Philistine', fits both."),
    14: ("Judges 16:2", "c", "A qal perfect, first person plural, with suffix `HW`; the sheva under resh does not change it."),
    15: ("Judges 19:4", "a", "Stem `qal`, tense `wayq`: the vowels of WLC's form. MAM's form is a hiphil."),
    16: ("Judges 19:23", "b", "Written with pataḥ, analysed as the preposition: lexeme `>L`, part of speech `prep`, in a `PP` with function `Cmpl`, whose object is the next atom. The verse's other three atoms with pataḥ are the negative `>L=`."),
    17: ("1 Samuel 27:10", "c", "The article and the gentilic `JRXM>LJ/`."),
    18: ("2 Samuel 11:1", "b", "Lexeme `MLK/` 'king', against the vowels of mem and lamed, which are those of `ML>K/` 'messenger'. The written atom also has a rafeh on its alef, as WLC 4.18 does, marking the alef silent, which fits 'kings' written with an alef, as MAM has it, rather than 'messengers', whose alef has a vowel. So the written atom is mixed, and the analysis takes MAM's word."),
    19: ("2 Samuel 13:33", "a", "MAM leaves this atom unpointed, a word written but not read; the BHSA points it, as WLC does, and analyses it as a read word: the conjunction `>M` 'if', in a phrase `CP` of its clause."),
    20: ("2 Samuel 15:21", "a", "As at 2 Samuel 13:33: the conjunction `>M`, read, in a phrase `CP`. The maqaf after it is WLC's too."),
    21: ("2 Kings 10:33", "c", "The conjunction, the article and `R>WBNJ/`."),
    22: ("2 Kings 18:27", "d; c", "The row's forms are of the qere. The BHSA's qere has MAM's tsere under the first mem, with a meteg there, and no accent on its first atom, where WLC and MAM have a merkha on the second mem; WLC 4.18's notes c, n and v say that WLC reads the accents and the vowels of L differently from BHS. The analysis, `MJM/` 'water' and `RGL/` 'foot', fits both. The BHSA's ketiv is two slots, each with its own qere."),
    23: ("Isaiah 23:8", "c", "A qal participle, plural, with suffix `H`. The BHSA's atom differs from WLC's in one accent code point only: HEBREW ACCENT QADMA where WLC has the first of two HEBREW ACCENT PASHTA marks."),
    24: ("Isaiah 46:4", "c", "`FJBH/` 'age': the analysis takes the letter as sin; WLC's letter, like the BHSA's (`#` in its transliteration), has neither dot."),
    25: ("Isaiah 66:22", "a", "Lexeme `XDC=/` 'month', a noun: the vowel of the written ḥataf qamats. MAM's ḥataf pataḥ is the adjective `XDC/` 'new', which the BHSA gives to the same verse's other atom of that root."),
    26: ("Jeremiah 3:17", "c", "A niphal perfect of `QWH=[` 'collect'."),
    27: ("Jeremiah 47:6", "b", "Written with pataḥ, analysed as the preposition: lexeme `>L`, part of speech `prep`, in a `PP` with function `Cmpl` whose object is the next atom."),
    28: ("Hosea 2:4", "c", "Suffix `H` on `PNH/`, as at Genesis 34:11."),
    29: ("Hosea 2:17", "c", "The conjunction, `K`, and `JWM/` 'day'."),
    30: ("Joel 2:12", "c", "The conjunction, `B` and `BKJ/` 'weeping'."),
    31: ("Jonah 3:2", "c", "The conjunction and a qal imperative."),
    32: ("Zechariah 2:2", "c", "The conjunction and `JRWCLM/`."),
    33: ("Psalms 45:3", "c", "`B` and `FPH/` 'lip', plural, with suffix `K`."),
    34: ("Proverbs 12:9", "a", "Stem `tif`, which the ETCBC's documentation of `vs` calls tif‘al, and a participle: the analysis follows the written vowels of the prefix. MAM's form is a hitpael participle."),
    35: ("Proverbs 20:1", "c", "The article and `JJN/` 'wine'."),
    36: ("Proverbs 31:12", "c", "Suffix `H` on `XJJM/`, as at Genesis 34:11."),
    37: ("Job 31:7", "c", "`M>WM/` 'blemish'."),
    38: ("Song of Songs 5:11", "c", "`QWYWT/` 'hairlocks', plural, with suffix `W`."),
    39: ("Daniel 2:45", "c", "A haphel perfect, third feminine singular: both vowels under the dalet fit it."),
    40: ("Daniel 5:24", "c", "A peil perfect, third masculine singular."),
    41: ("Daniel 7:20", "c", "The conjunction and `PM/` 'mouth'."),
    42: ("Nehemiah 9:14", "c", "A hiphil perfect, second masculine singular."),
    43: ("1 Chronicles 3:1", "c", "`DWD==/` 'David'."),
    44: ("Deut 3:22", "d; c", "The BHSA's text has MAM's form, with no sheva beside the ḥiriq; WLC 4.18's notes Q, n and v say that WLC reads the vowels of L differently from BHS. The analysis, a qal imperfect with suffix `M`, fits both."),
    45: ("Isa 49:23", "d; c", "The BHSA's text has the ḥolam on the qof, as MAM does; WLC has it on the vav, with no note. The BHSA's transliteration writes a ḥolam before its vav, so this may be how its transcription renders BHS rather than a different reading. The analysis, a qal participle with suffix `J`, fits both."),
    46: ("Lam 3:25", "d; c", "The BHSA has a ketiv and qere here, ketiv letters only and a qere with a yod; WLC 4.18's note q says that WLC abandoned a ketiv and qere of BHS. The BHSA's ketiv with the qere's points has the ḥolam on the qof, as MAM's form does. The analysis, a qal participle, plural, with suffix `W`, fits both."),
    47: ("Lam 4:4", "d; c", "The BHSA's text has MAM's ḥiriq under the ḥet; WLC 4.18's notes Q, n and v. The analysis, `XK/` 'palate' with suffix `W`, fits both."),
    48: ("Eccl 2:23", "d; c", "The BHSA's text has the ḥolam that WLC 4.20, WLC 4.22 and MAM have and WLC 4.18 lacks; WLC 4.18's notes Q, n and v. The analysis, `LB/` 'heart' with suffix `W`, fits both."),
    49: ("Exod 20:3", "c", "`PNH/`, plural, with suffix `J`; the BHSA has WLC's qamats and pataḥ."),
    50: ("Deut 5:7", "c", "As at Exodus 20:3."),
    51: ("Exod 20:4", "c", "`MN` and `TXT/`; the BHSA has WLC's qamats and pataḥ under the tav."),
    52: ("Exod 20:9", "c", "`KL/`, construct, and `ML>KT/` with suffix `K`; the dagesh does not change it."),
    53: ("Exod 20:10", "c", "The negative `L>` and a qal imperfect; the BHSA has WLC's maqaf, which the analysis does not depend on."),
    54: ("Deut 5:8", "c", "As at Exodus 20:10, with `L` and suffix `K`."),
    55: ("Deut 5:8", "c", "`MN` and `TXT/`; the BHSA has WLC's qamats."),
    56: ("Deut 5:13", "c", "As at Exodus 20:9; the BHSA has WLC 4.18's rafeh too."),
}

HATAF_NOTE = (
    "At all six verses the BHSA's atom is WLC 4.18's, with no ḥataf, and its analysis fits "
    "both: `QDC/` 'holiness' (Ezekiel 44:13, 2 Chronicles 5:7), `>RKWJ/` (Ezra 4:9, a qere in "
    "the BHSA), qal imperfects with suffix `HW` (Numbers 35:20, 1 Samuel 26:10) and "
    "`YLYLJM/` 'cymbals' (2 Samuel 6:5)."
)

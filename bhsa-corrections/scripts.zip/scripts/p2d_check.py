"""Checks behind p2d's judgments (throwaway scratch, slice p2d).

Usage (from the MAM-basics root): python -I p2d_check.py <this folder> <out txt>

1. Every BHSA atom whose key is one of KEYS' keys (taken from out/p2d-scan.json's Test A
   groups by number): its full text with accents, its analysis, the names of its accents, and
   its reference, so that a pausal form can be told from a contextual one.
2. Every BHSA word with lexeme R<=/ ('friend'), number pl and suffix HW or W: its form.
3. The BHSA's slots at Job 33:28 that have a qere: g_word_utf8, qere_utf8, kq_hybrid_utf8 and the
   analysis; and MAM-simple's verse there, ketiv side and qere side.
4. The verses of Test A's segmentation groups: the BHSA's slots (form, transliteration,
   analysis), MAM-simple's atoms and WLC 4.18's atoms (ketiv side, with WLC's notes).
5. For the keys of some Test A groups, the ETCBC's morphemes of each atom's last slot (nominal
   ending, univalent final, pronominal suffix), counted by the atom's analysis.
6. The noun lexemes whose gender is "unknown" in some slots and m or f in others.
"""

import json
import sys
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402
import p2d_scan_atoms as P  # noqa: E402

GROUPS = (16, 61, 63, 175, 186, 111, 139)
MORPH_GROUPS = (16, 61, 111, 139, 175, 186)


def accents(s):
    return [unicodedata.name(ch).replace("HEBREW ACCENT ", "").replace("HEBREW POINT ", "").lower()
            for ch in s if "\N{HEBREW ACCENT ETNAHTA}" <= ch <= "\N{HEBREW MARK MASORA CIRCLE}" or ch == "\N{HEBREW POINT METEG}"]


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8", errors="backslashreplace")
    here, out = Path(sys.argv[1]), Path(sys.argv[2])
    data = json.loads((here / "out" / "p2d-scan.json").read_text(encoding="utf-8"))
    want = {}
    for g in data["test_a"]:
        if g["n"] in GROUPS:
            want[(tuple(g["key"][0]), g["key"][1])] = g["n"]
    B = C.Bhsa()
    gw, qw = B.wf("g_word_utf8"), B.wf("qere_utf8")
    lang = B.wf("language")
    feats = [B.wf(f) for f in P.FIELDS]
    english = {short.replace(" ", ""): name for name, short in C.ib_review.SHORT.items()}
    english["Eccl"] = "Ecclesiastes"
    lines = ["1. Atoms of the keys of Test A groups %s" % (GROUPS,)]
    found = []
    for ref in sorted(B.verse_slots, key=lambda r: B.verse_slots[r][0]):
        book, ch, v = ref
        osis = C.OSIS_FROM_BHSA[book]
        for ba in B.atoms(osis, ch, v, "ketiv"):
            if any(s in qw for s in ba["slots"]) or not C.letters(ba["text"]):
                continue
            k = (tuple(sorted({lang[s] for s in ba["slots"]})), C.skey(ba["text"]).rstrip(C.MAQAF))
            if k in want:
                a = tuple(tuple(f[s] for f in feats) for s in ba["slots"])
                found.append((want[k], P.fmt(a), "%s %d:%d" % (english[osis], ch, v), C.mnorm(ba["text"]), accents(ba["text"])))
    for n in GROUPS:
        rows = [r for r in found if r[0] == n]
        lines.append("")
        lines.append("A%d: %d atoms; analyses %s" % (n, len(rows), dict(Counter(r[1] for r in rows))))
        for r in rows:
            lines.append("   %s | %s | %s | %s" % (r[1], r[2], r[3], ", ".join(r[4]) or "-"))
    lines += ["", "2. BHSA words with lexeme R<=/, number pl, suffix HW or W"]
    lex, nu, prs = B.wf("lex"), B.wf("nu"), B.wf("prs")
    for s in range(1, B.max_slot + 1):
        if lex.get(s) == "R<=/" and nu.get(s) == "pl" and prs.get(s) in ("HW", "W"):
            book, ch, v = B.ref_of_slot[s]
            lines.append("   %s %d:%d | %s | prs %s%s" % (
                english[C.OSIS_FROM_BHSA[book]], ch, v, C.mnorm(C.ib_review.stripped(gw.get(s, ""))), prs[s],
                " | qere %s" % C.mnorm(C.ib_review.stripped(qw[s])) if s in qw else ""))
    lines += ["", "3. Job 33:28: the BHSA's slots with a qere"]
    kq = B.wf("kq_hybrid_utf8")
    for s in B.slots("Job", 33, 28):
        if s in qw:
            lines.append("   slot %d | g_word_utf8 %s | qere_utf8 %s | kq_hybrid_utf8 %s | %s" % (
                s, C.mnorm(gw.get(s, "")), C.mnorm(C.ib_review.stripped(qw[s])), C.mnorm(C.ib_review.stripped(kq.get(s, ""))),
                P.fmt_slot(tuple(f[s] for f in feats))))
    lint = C.load_lint()
    for side in ("ketiv", "qere"):
        atoms = C.mam_atoms(lint, "Job", 33, 28, side, "cant-combined", "Job 33:28")
        lines.append("   MAM-simple, %s side: %s" % (side, " ".join(C.mnorm(C.ib_review.stripped(a)) for a in atoms)))
    lines += ["", "4. Test A's segmentation groups: the BHSA's slots, MAM-simple's verse and WLC 4.18's verse"]
    g_word = B.wf("g_word")
    for osis, ch, v, form in (("Deut", 25, 7, None), ("Ps", 73, 20, None), ("Ezra", 3, 10, None), ("2Chr", 30, 10, None)):
        lines.append("   %s %d:%d" % (english[osis], ch, v))
        for s in B.slots(osis, ch, v):
            lines.append("      slot %d | %s | %s | %s" % (s, C.mnorm(C.ib_review.stripped(gw.get(s, ""))), g_word.get(s, ""),
                                                      P.fmt_slot(tuple(f[s] for f in feats))))
        mam = C.mam_atoms(lint, P.SHORT_FROM_OSIS[osis], ch, v, "ketiv", "cant-combined", "%s %d:%d" % (osis, ch, v))
        lines.append("      MAM-simple: %s" % " ".join(C.mnorm(C.ib_review.stripped(a)) for a in mam))
        wlc = C.wlc418_side(C.read_wlc418_book(osis)[(ch, v)], "ketiv")
        lines.append("      WLC 4.18: %s" % " ".join(C.mnorm(C.ib_review.stripped(a["text"])) + ("[%s]" % ",".join(a["notes"]) if a["notes"] else "") for a in wlc))
    lines += ["", "5. The ETCBC's morphemes (nme, uvf, prs; accents stripped) of the keys of Test A groups %s, by analysis" % (MORPH_GROUPS,)]
    want5 = {}
    for g in data["test_a"]:
        if g["n"] in MORPH_GROUPS:
            want5[(tuple(g["key"][0]), g["key"][1])] = g["n"]
    nme, uvf, gprs = B.wf("g_nme_utf8"), B.wf("g_uvf_utf8"), B.wf("g_prs_utf8")
    morph5 = {n: {} for n in MORPH_GROUPS}
    for ref in sorted(B.verse_slots, key=lambda r: B.verse_slots[r][0]):
        book, ch, v = ref
        for ba in B.atoms(C.OSIS_FROM_BHSA[book], ch, v, "ketiv"):
            if any(s in qw for s in ba["slots"]) or not C.letters(ba["text"]):
                continue
            k = (tuple(sorted({lang[s] for s in ba["slots"]})), C.skey(ba["text"]).rstrip(C.MAQAF))
            if k not in want5:
                continue
            s = ba["slots"][-1]
            a = P.fmt(tuple(tuple(f[x] for f in feats) for x in ba["slots"]))
            m = "nme [%s] uvf [%s] prs [%s]" % tuple(C.mnorm(C.ib_review.stripped(x.get(s, ""))) for x in (nme, uvf, gprs))
            morph5[want5[k]].setdefault(a, Counter())[m] += 1
    for n in MORPH_GROUPS:
        for a, c in morph5[n].items():
            lines.append("   A%d | %s | %s" % (n, a, "; ".join("%s x%d" % (m, k) for m, k in c.most_common())))
    lines += ["", "6. Nouns (sp subs) whose gender is 'unknown' in some slots and m or f in others"]
    sp, gn = B.wf("sp"), B.wf("gn")
    by_lex = defaultdict(Counter)
    for s in range(1, B.max_slot + 1):
        if sp.get(s) == "subs":
            by_lex[lex[s]][gn.get(s)] += 1
    mixed = {lx: c for lx, c in by_lex.items() if "unknown" in c and ({"m", "f"} & set(c))}
    lines.append("   %d of %d noun lexemes; %d slots of them" % (len(mixed), len(by_lex), sum(sum(c.values()) for c in mixed.values())))
    for lx, c in sorted(mixed.items(), key=lambda kv: -sum(kv[1].values()))[:15]:
        lines.append("   %s %s" % (lx, dict(c)))
    out.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print("wrote", out, len(lines), "lines")


if __name__ == "__main__":
    main()

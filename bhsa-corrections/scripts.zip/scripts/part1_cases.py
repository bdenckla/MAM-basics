"""Part 1: the Israel Bible review's cases in the BHSA 2021, beside WLC 4.18, 4.20, 4.22 and MAM.

Throwaway scratch for the brief
C:/Users/BenDe/GitRepos/MAM-basics/.novc/commander-session/bhsa-corrections-brief-2026-11-13.md.
The case-finding follows the morphhb session's scripts/part1_cases.py.

Usage: python -I part1_cases.py <out json> <out txt>

The cases are forms.json's rows and review.md's two data tables (the tour's and the
Decalogues'), read with the review module's own readers. For each case, on each side of every
ketiv/qere:

1. MAM's verse (MAM-simple, BHS versification, read by the review's lint's own functions, in the
   row's strand) and WLC 4.18's verse are split into atoms and aligned by their letters; the
   case's place is where WLC 4.18's atoms match the Israel Bible's form and MAM's aligned atoms
   match MAM's form, both by the review's comparison key (israel_bible_review_index.key).
2. The BHSA's verse, at the same reference, is split into atoms (bc_common.Bhsa.atoms: on the
   ketiv side the "hybrid" atoms, the ketiv's letters with the qere's points, as tanach.us's <k>
   elements have them; on the qere side the qere's) and aligned with WLC 4.18's by letters. The
   BHSA's slots at the place are reported with their features and their phrase's and clause's.
3. The BHSA's form at the place is compared with WLC 4.18's and with MAM's, by the review's key
   and by a full key that keeps every mark (each letter's marks sorted). WLC 4.20's and 4.22's
   forms at the place are reported too.
"""

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402

WORD_FEATURES = [
    "g_word_utf8",
    "trailer_utf8",
    "qere_utf8",
    "qere_trailer_utf8",
    "kq_hybrid_utf8",
    "g_word",
    "lex",
    "voc_lex_utf8",
    "g_lex_utf8",
    "gloss",
    "language",
    "sp",
    "pdp",
    "ls",
    "vs",
    "vt",
    "ps",
    "nu",
    "gn",
    "st",
    "prs",
    "g_pfm_utf8",
    "g_vbs_utf8",
    "g_vbe_utf8",
    "g_nme_utf8",
    "g_uvf_utf8",
    "g_prs_utf8",
]
BHSA_SIDE = {"ketiv": "hybrid", "qere": "qere"}


def slot_record(B, s):
    rec = {"slot": s}
    for name in WORD_FEATURES:
        v = B.wf(name).get(s)
        if v is not None and v != "":
            rec[name] = v
    p, c = B.phrase_of.get(s), B.clause_of.get(s)
    typ, func = B.nf("typ"), B.nf("function")
    rec["phrase"] = {"node": p, "typ": typ.get(p), "function": func.get(p)}
    rec["clause"] = {"node": c, "typ": typ.get(c)}
    return rec


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    out_json, out_txt = Path(sys.argv[1]), Path(sys.argv[2])
    B = C.Bhsa()
    lint = C.load_lint()
    wlc420, wlc422 = C.read_wlc42x("4.20"), C.read_wlc42x("4.22")
    results = []
    for case in C.review_cases():
        osis, ch, vs = case["osis"], case["chapter"], case["verse"]
        w418_all = C.read_wlc418_book(osis)[(ch, vs)]
        res = dict(case)
        res["bhsa_ref"] = [C.BHSA_BOOK[osis], ch, vs]
        res["sides"] = {}
        for side in ("ketiv", "qere"):
            w418 = C.wlc418_side(w418_all, side)
            w418_atoms = [a["text"] for a in w418]
            mam = C.mam_atoms(lint, case["short"], ch, vs, side, case["strand"], case["reference"])
            to_mam = C.align(w418_atoms, mam)
            places = []
            for run in C.find_runs(case["ib"], w418_atoms):
                mam_idx = sorted({j for i in run for j in to_mam[i]})
                if C.find_runs(case["mam"], [mam[j] for j in mam_idx], case["keep_rafeh"]):
                    places.append((run, mam_idx))
            if not places:
                res["sides"][side] = {"found": False}
                continue
            b_atoms = B.atoms(osis, ch, vs, BHSA_SIDE[side])
            to_b = C.align(w418_atoms, [a["text"] for a in b_atoms])
            v420 = C.wlc42x_side(wlc420[(osis, ch, vs)], side)
            v422 = C.wlc42x_side(wlc422[(osis, ch, vs)], side)
            to420 = C.align(w418_atoms, [a["text"] for a in v420])
            to422 = C.align(w418_atoms, [a["text"] for a in v422])
            ux = C.wlc418_side(C.read_wlc418_book(osis, C.UXLC26_BOOKS)[(ch, vs)], side)
            toux = C.align(w418_atoms, [a["text"] for a in ux])
            side_res = {"found": True, "places": []}
            for run, mam_idx in places:
                b_idx = sorted({j for i in run for j in to_b[i]})
                i420 = sorted({j for i in run for j in to420[i]})
                i422 = sorted({j for i in run for j in to422[i]})
                iux = sorted({j for i in run for j in toux[i]})
                w418_text = [w418[i]["text"] for i in run]
                b_text = [b_atoms[j]["text"] for j in b_idx]
                mam_text = [mam[j] for j in mam_idx]
                slots = [s for j in b_idx for s in b_atoms[j]["slots"]]

                def keys(atoms, fn):
                    return [fn(a).rstrip(C.SOF_PASUQ) for a in atoms]

                side_res["places"].append(
                    {
                        "wlc418_idx": run,
                        "wlc418": [w418[i] for i in run],
                        "wlc420": [v420[j] for j in i420],
                        "wlc422": [v422[j] for j in i422],
                        "uxlc26": [ux[j] for j in iux],
                        "bkey_bhsa_eq_uxlc26": keys(b_text, C.bkey) == keys([ux[j]["text"] for j in iux], C.bkey),
                        "bkey_uxlc26_eq_mam": keys([ux[j]["text"] for j in iux], C.bkey) == keys(mam_text, C.bkey),
                        "mam_idx": mam_idx,
                        "mam": mam_text,
                        "bhsa_idx": b_idx,
                        "bhsa": b_text,
                        "bhsa_slots": [slot_record(B, s) for s in slots],
                        "skey_bhsa_eq_wlc418": keys(b_text, C.skey) == keys(w418_text, C.skey),
                        "skey_bhsa_eq_mam": keys(b_text, C.skey) == keys(mam_text, C.skey),
                        "bkey_bhsa_eq_wlc418": keys(b_text, C.bkey) == keys(w418_text, C.bkey),
                        "bkey_bhsa_eq_mam": keys(b_text, C.bkey) == keys(mam_text, C.bkey),
                        "bfkey_bhsa_eq_wlc418": keys(b_text, C.bfkey) == keys(w418_text, C.bfkey),
                        "fkey_bhsa_eq_wlc418": keys(b_text, C.fkey) == keys(w418_text, C.fkey),
                        "fkey_bhsa_eq_wlc420": keys(b_text, C.fkey)
                        == keys([v420[j]["text"] for j in i420], C.fkey),
                        "fkey_bhsa_eq_wlc422": keys(b_text, C.fkey)
                        == keys([v422[j]["text"] for j in i422], C.fkey),
                    }
                )
            res["sides"][side] = side_res
        if not any(s["found"] for s in res["sides"].values()):
            raise SystemExit("case not found on either side: %s" % case["reference"])
        results.append(res)
    out_json.write_text(json.dumps(results, ensure_ascii=False, indent=1), encoding="utf-8", newline="\n")
    with open(out_txt, "w", encoding="utf-8", newline="\n") as f:
        for n, res in enumerate(results, 1):
            f.write("== %d. %s (%s, page %s)%s; BHSA %s %d:%d\n" % (
                n, res["reference"], res["source"], res["page"],
                " [%s]" % res["label"] if res["label"] else "", *res["bhsa_ref"]))
            f.write("   IB:  %s\n   MAM: %s\n" % (res["ib"], res["mam"]))
            for side, sres in res["sides"].items():
                if not sres["found"]:
                    f.write("   [%s side] not found\n" % side)
                    continue
                for p in sres["places"]:
                    f.write("   [%s side] WLC 4.18 atoms %s: %s notes %s\n" % (
                        side, p["wlc418_idx"], " | ".join(a["text"] for a in p["wlc418"]), [a["notes"] for a in p["wlc418"]]))
                    f.write("      WLC 4.20: %s notes %s\n" % (" | ".join(a["text"] for a in p["wlc420"]), [a["notes"] for a in p["wlc420"]]))
                    f.write("      WLC 4.22: %s notes %s\n" % (" | ".join(a["text"] for a in p["wlc422"]), [a["notes"] for a in p["wlc422"]]))
                    f.write("      MAM:      %s\n" % " | ".join(p["mam"]))
                    f.write("      BHSA:     %s  (atoms %s)\n" % (" | ".join(p["bhsa"]), p["bhsa_idx"]))
                    for r in p["bhsa_slots"]:
                        f.write("        slot %d %s%s | %s | lex %s %s %s | sp %s pdp %s ls %s | vs %s vt %s | ps %s nu %s gn %s st %s prs %s | phrase %s %s | clause %s%s\n" % (
                            r["slot"], r.get("g_word_utf8", ""), r.get("trailer_utf8", ""), r.get("g_word", ""),
                            r.get("lex"), r.get("voc_lex_utf8", ""), r.get("gloss", ""),
                            r.get("sp"), r.get("pdp"), r.get("ls"), r.get("vs"), r.get("vt"),
                            r.get("ps"), r.get("nu"), r.get("gn"), r.get("st"), r.get("prs"),
                            r["phrase"]["typ"], r["phrase"]["function"], r["clause"]["typ"],
                            (" | qere %s kq_hybrid %s" % (r["qere_utf8"], r.get("kq_hybrid_utf8", ""))) if "qere_utf8" in r else ""))
                    f.write("      BHSA==WLC4.18 by review key: %s; BHSA==MAM by review key: %s; full key: ==4.18 %s, ==4.20 %s, ==4.22 %s\n" % (
                        p["skey_bhsa_eq_wlc418"], p["skey_bhsa_eq_mam"], p["fkey_bhsa_eq_wlc418"], p["fkey_bhsa_eq_wlc420"], p["fkey_bhsa_eq_wlc422"]))
            f.write("\n")
    print("cases: %d" % len(results))


if __name__ == "__main__":
    main()

"""Readers shared by this folder's scripts (throwaway scratch).

Brief: C:/Users/BenDe/GitRepos/MAM-basics/.novc/commander-session/bhsa-corrections-brief-2026-11-13.md.

- The BHSA's Text-Fabric features, version 2021, fetched into ../fetched/etcbc-bhsa-2021-<f>/:
  read_feature, read_oslots, and the class Bhsa. The TF reading follows the MACULA session's
  scripts/bhsa_verse.py.
- WLC 4.18 (tanach.us build 24.2, Sefaria-Data's copy, in GitRepos2's .novc), WLC 4.20 and 4.22
  (MAM-basics' tracked out/wlc420-u and out/wlc422-u), and the review's comparison keys: copied
  from the morphhb session's scripts/mhb_common.py, with morphhb's reader left out.
- The review's cases and MAM's atoms: the review module's own readers and its lint's functions,
  as the morphhb session's scripts/part1_cases.py uses them.

Every reader dispatches explicitly on what it was written for and raises on anything else.
"""

import difflib
import importlib.util
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

MB_ROOT = Path("C:/Users/BenDe/GitRepos/MAM-basics")
HERE = Path(__file__).resolve().parent.parent
if str(MB_ROOT / "py") not in sys.path:
    sys.path.insert(0, str(MB_ROOT / "py"))

from author_misc import israel_bible_review_index as ib_review  # noqa: E402
from mb_cmn.uni_denorm import give_std_mark_order  # noqa: E402

VERSION = "2021"
MAQAF = "\N{HEBREW PUNCTUATION MAQAF}"
SOF_PASUQ = "\N{HEBREW PUNCTUATION SOF PASUQ}"
PASEQ = "\N{HEBREW PUNCTUATION PASEQ}"
CGJ = "\N{COMBINING GRAPHEME JOINER}"
HEB_LETTER = re.compile("[\N{HEBREW LETTER ALEF}-\N{HEBREW LETTER TAV}]")

# ------------------------------------------------------------------ books

# (OSIS, tanach.us file stem, Michigan-Claremont abbreviation, BHSA book name)
BOOKS = [
    ("Gen", "Genesis", "gn", "Genesis"),
    ("Exod", "Exodus", "ex", "Exodus"),
    ("Lev", "Leviticus", "lv", "Leviticus"),
    ("Num", "Numbers", "nu", "Numeri"),
    ("Deut", "Deuteronomy", "dt", "Deuteronomium"),
    ("Josh", "Joshua", "js", "Josua"),
    ("Judg", "Judges", "ju", "Judices"),
    ("1Sam", "Samuel_1", "1s", "Samuel_I"),
    ("2Sam", "Samuel_2", "2s", "Samuel_II"),
    ("1Kgs", "Kings_1", "1k", "Reges_I"),
    ("2Kgs", "Kings_2", "2k", "Reges_II"),
    ("Isa", "Isaiah", "is", "Jesaia"),
    ("Jer", "Jeremiah", "je", "Jeremia"),
    ("Ezek", "Ezekiel", "ek", "Ezechiel"),
    ("Hos", "Hosea", "ho", "Hosea"),
    ("Joel", "Joel", "jl", "Joel"),
    ("Amos", "Amos", "am", "Amos"),
    ("Obad", "Obadiah", "ob", "Obadia"),
    ("Jonah", "Jonah", "jn", "Jona"),
    ("Mic", "Micah", "mi", "Micha"),
    ("Nah", "Nahum", "na", "Nahum"),
    ("Hab", "Habakkuk", "hb", "Habakuk"),
    ("Zeph", "Zephaniah", "zp", "Zephania"),
    ("Hag", "Haggai", "hg", "Haggai"),
    ("Zech", "Zechariah", "zc", "Sacharia"),
    ("Mal", "Malachi", "ma", "Maleachi"),
    ("Ps", "Psalms", "ps", "Psalmi"),
    ("Prov", "Proverbs", "pr", "Proverbia"),
    ("Job", "Job", "jb", "Iob"),
    ("Song", "Song_of_Songs", "ca", "Canticum"),
    ("Ruth", "Ruth", "ru", "Ruth"),
    ("Lam", "Lamentations", "lm", "Threni"),
    ("Eccl", "Ecclesiastes", "ec", "Ecclesiastes"),
    ("Esth", "Esther", "es", "Esther"),
    ("Dan", "Daniel", "da", "Daniel"),
    ("Ezra", "Ezra", "er", "Esra"),
    ("Neh", "Nehemiah", "ne", "Nehemia"),
    ("1Chr", "Chronicles_1", "1c", "Chronica_I"),
    ("2Chr", "Chronicles_2", "2c", "Chronica_II"),
]
TANACH_US = {b[0]: b[1] for b in BOOKS}
MC = {b[0]: b[2] for b in BOOKS}
OSIS_FROM_MC = {b[2]: b[0] for b in BOOKS}
BHSA_BOOK = {b[0]: b[3] for b in BOOKS}
OSIS_FROM_BHSA = {b[3]: b[0] for b in BOOKS}

# ------------------------------------------------------------------ Text-Fabric

ESC = {"t": "\t", "n": "\n", "\\": "\\"}


def feature_path(name, here=HERE, version=VERSION):
    return here / "fetched" / ("etcbc-bhsa-%s-%s" % (version, name)) / (name + ".tf")


def data_lines(path):
    """A TF file's data lines: after the header lines beginning with "@" and one empty line."""
    lines = Path(path).read_text(encoding="utf-8").split("\n")
    i = 0
    while lines[i].startswith("@"):
        i += 1
    if lines[i] != "":
        raise ValueError("%s: no empty line after the header (line %d)" % (path, i))
    body = lines[i + 1 :]
    if body and body[-1] == "":
        body.pop()
    return body


def header(path):
    out = {}
    for line in Path(path).read_text(encoding="utf-8").split("\n"):
        if not line.startswith("@"):
            break
        k, _, v = line[1:].partition("=")
        out[k] = v
    return out


def unescape(v):
    return re.sub(r"\\(.)", lambda m: ESC.get(m.group(1), m.group(0)), v)


def ranges(spec):
    out = []
    for part in spec.split(","):
        a, _, b = part.partition("-")
        out.append((int(a), int(b or a)))
    return out


def read_feature(path, keep=None):
    """A node feature: {node: value}; a line is "<node spec>\\t<value>" or "<value>" for the
    node after the previous line's last node."""
    vals = {}
    node = 0
    for line in data_lines(path):
        if "\t" in line:
            spec, value = line.split("\t", 1)
            rs = ranges(spec)
        else:
            value = line
            rs = [(node + 1, node + 1)]
        value = unescape(value)
        for a, b in rs:
            for n in range(a, b + 1):
                if keep is None or keep(n):
                    vals[n] = value
        node = rs[-1][1]
    return vals


def read_oslots(path, first_node, keep=None):
    """oslots, an edge feature from each non-slot node to its slots: {node: [(a, b), ...]}."""
    out = {}
    node = first_node - 1
    for line in data_lines(path):
        if "\t" in line:
            src, spec = line.split("\t", 1)
            node = int(src)
        else:
            node += 1
            spec = line
        rs = ranges(spec)
        if keep is None or keep(node, rs):
            out[node] = rs
    return out


class Bhsa:
    """The BHSA 2021, as far as this folder's features go. Word features load on demand."""

    def __init__(self, here=HERE):
        self.here = here
        self.types = {}
        for line in data_lines(feature_path("otype", here)):
            spec, t = line.split("\t")
            self.types[t] = ranges(spec)[0]
        self.max_slot = self.types["word"][1]
        self._wf = {}
        self._nf = {}
        oslots = read_oslots(feature_path("oslots", here), self.max_slot + 1)
        is_verse = self.is_type("verse")
        is_phrase = self.is_type("phrase")
        is_clause = self.is_type("clause")
        book = read_feature(feature_path("book", here), is_verse)
        chapter = read_feature(feature_path("chapter", here), is_verse)
        verse = read_feature(feature_path("verse", here), is_verse)
        self.verse_slots = {}
        self.ref_of_slot = {}
        self.phrase_of = {}
        self.clause_of = {}
        for node, rs in oslots.items():
            slots = [s for a, b in rs for s in range(a, b + 1)]
            if is_verse(node):
                ref = (book[node], int(chapter[node]), int(verse[node]))
                if ref in self.verse_slots:
                    raise ValueError("two verse nodes for %r" % (ref,))
                self.verse_slots[ref] = slots
                for s in slots:
                    self.ref_of_slot[s] = ref
            elif is_phrase(node):
                for s in slots:
                    if s in self.phrase_of:
                        raise ValueError("slot %d in two phrases" % s)
                    self.phrase_of[s] = node
            elif is_clause(node):
                for s in slots:
                    if s in self.clause_of:
                        raise ValueError("slot %d in two clauses" % s)
                    self.clause_of[s] = node
        if len(self.ref_of_slot) != self.max_slot:
            raise ValueError("not every slot is in a verse")

    def is_type(self, t):
        lo, hi = self.types[t]
        return lambda n: lo <= n <= hi

    def wf(self, name):
        """A word feature, {slot: value}, for every slot that has a value."""
        if name not in self._wf:
            self._wf[name] = read_feature(feature_path(name, self.here), lambda n: n <= self.max_slot)
        return self._wf[name]

    def nf(self, name):
        """A feature over all nodes."""
        if name not in self._nf:
            self._nf[name] = read_feature(feature_path(name, self.here))
        return self._nf[name]

    def slots(self, osis, chapter, verse):
        return self.verse_slots[(BHSA_BOOK[osis], chapter, verse)]

    def atoms(self, osis, chapter, verse, side):
        """The verse's atoms on one side of every ketiv/qere: a list of {"text", "slots"}. An
        atom ends after a slot whose trailer has a space or a maqaf; the maqaf stays on the
        atom. A slot with a qere contributes, on side "qere", qere_utf8 and qere_trailer_utf8;
        on side "hybrid", kq_hybrid_utf8 (the ketiv's letters with the qere's points, without
        the sof pasuq that it sometimes ends with) and trailer_utf8; on side "ketiv",
        g_word_utf8 (the ketiv's letters, unpointed) and trailer_utf8."""
        gw, tr = self.wf("g_word_utf8"), self.wf("trailer_utf8")
        qw, qt = self.wf("qere_utf8"), self.wf("qere_trailer_utf8")
        kq = self.wf("kq_hybrid_utf8")
        out, text, slots = [], "", []
        for s in self.slots(osis, chapter, verse):
            if side == "qere" and s in qw:
                w, t = qw[s], qt.get(s, "")
            elif side == "hybrid" and s in qw:
                w, t = kq[s].rstrip(SOF_PASUQ), tr.get(s, "")
            elif side in ("ketiv", "qere", "hybrid"):
                w, t = gw.get(s, ""), tr.get(s, "")
            else:
                raise ValueError(side)
            text += w
            slots.append(s)
            ends = trailer_ends_atom(t)
            if MAQAF in t:
                text += MAQAF
            if ends:
                out.append({"text": text, "slots": slots, "trailer": t})
                text, slots = "", []
        if slots:
            out.append({"text": text, "slots": slots, "trailer": ""})
        return out


# Every trailer_utf8 and qere_trailer_utf8 value that out/02-census.txt found.
TRAILERS = {
    "",
    " ",
    MAQAF,
    SOF_PASUQ,
    SOF_PASUQ + " ",
    PASEQ + " ",
    " " + PASEQ + " ",
    SOF_PASUQ + " \N{HEBREW LETTER SAMEKH} ",
    SOF_PASUQ + " \N{HEBREW LETTER PE} ",
    " \N{HEBREW LETTER SAMEKH} ",
    " \N{HEBREW LETTER PE} ",
    SOF_PASUQ + " \N{HEBREW PUNCTUATION NUN HAFUKHA} ",
    SOF_PASUQ + " \N{HEBREW LETTER NUN} \N{HEBREW LETTER SAMEKH} ",
    SOF_PASUQ + " \N{HEBREW LETTER NUN} \N{HEBREW LETTER PE} ",
}


def trailer_ends_atom(t):
    if t not in TRAILERS:
        raise ValueError("an unknown trailer %r" % t)
    return " " in t or MAQAF in t


# ------------------------------------------------------------------ keys


def letters(s):
    """The letters alone, final forms kept."""
    return "".join(HEB_LETTER.findall(s))


def skey(s, keep_rafeh=False):
    """The review's comparison key (israel_bible_review_index.key): accents, meteg, rafeh,
    paseq, sof pasuq, the dots and invisible marks stripped, qamats qatan read as qamats and
    holam haser for vav as holam, then each letter's marks sorted."""
    return ib_review.key(s, keep_rafeh)


def fkey(s):
    """A full key: every mark on a letter kept, each letter's marks sorted; CGJ, "/", paseq,
    sof pasuq and whitespace dropped."""
    for ch in (CGJ, "/", PASEQ, SOF_PASUQ, " "):
        s = s.replace(ch, "")
    out, cluster = [], []
    for ch in s:
        if ib_review.is_mark(ch):
            cluster.append(ch)
        else:
            out.extend(sorted(cluster))
            cluster = []
            out.append(ch)
    out.extend(sorted(cluster))
    return "".join(out)


def mnorm(s):
    """A form in MAM-normal mark order, for display."""
    return give_std_mark_order(s)


VAV = "\N{HEBREW LETTER VAV}"
HOLAM = "\N{HEBREW POINT HOLAM}"
HOLAM_HASER_FOR_VAV = "\N{HEBREW POINT HOLAM HASER FOR VAV}"
VOWEL_POINTS = set(
    "\N{HEBREW POINT SHEVA}\N{HEBREW POINT HATAF SEGOL}\N{HEBREW POINT HATAF PATAH}"
    "\N{HEBREW POINT HATAF QAMATS}\N{HEBREW POINT HIRIQ}\N{HEBREW POINT TSERE}"
    "\N{HEBREW POINT SEGOL}\N{HEBREW POINT PATAH}\N{HEBREW POINT QAMATS}"
    "\N{HEBREW POINT HOLAM}\N{HEBREW POINT HOLAM HASER FOR VAV}\N{HEBREW POINT QUBUTS}"
    "\N{HEBREW POINT QAMATS QATAN}"
)


def clusters(s):
    """[(base, [marks])]: each letter with the marks after it; any other character alone."""
    out = []
    for ch in s:
        if ib_review.is_mark(ch) and out and HEB_LETTER.match(out[-1][0]):
            out[-1][1].append(ch)
        else:
            out.append((ch, []))
    return out


def holam_to_prev(s):
    """The BHSA's way of writing a holam male, applied to any form: a holam on a vav whose
    only vowel it is moves to the letter before the vav, when that letter has no vowel of its
    own. WLC and MAM write a holam male as a vav with a holam (וֹ); the BHSA's g_word_utf8
    writes a holam on the letter before the vav (ֹו), its transcription's O before W."""
    cl = clusters(s)
    for i in range(1, len(cl)):
        base, marks = cl[i]
        prev_base, prev_marks = cl[i - 1]
        if (
            base == VAV
            and HOLAM in marks
            and not (set(marks) - {HOLAM}) & VOWEL_POINTS
            and HEB_LETTER.match(prev_base)
            and not set(prev_marks) & VOWEL_POINTS
        ):
            marks.remove(HOLAM)
            prev_marks.append(HOLAM)
    return "".join(b + "".join(m) for b, m in cl)


def bkey(s, keep_rafeh=False):
    """The review's key after holam_to_prev: compares a BHSA form with WLC's or MAM's without
    counting the BHSA's way of writing a holam male as a difference."""
    return skey(holam_to_prev(s), keep_rafeh)


def bfkey(s):
    """The full key after holam_to_prev."""
    return fkey(holam_to_prev(s))


def form_atoms(form):
    """A form split into atoms: at spaces, and after each maqaf (kept on its atom)."""
    atoms = []
    for piece in form.split():
        parts = piece.split(MAQAF)
        for i, part in enumerate(parts):
            if i < len(parts) - 1:
                atoms.append(part + MAQAF)
            elif part:
                atoms.append(part)
    return atoms


def align(a_atoms, b_atoms):
    """Map each index of a_atoms to the indices of b_atoms that align with it by letters."""
    la = [letters(x) for x in a_atoms]
    lb = [letters(x) for x in b_atoms]
    sm = difflib.SequenceMatcher(None, la, lb, autojunk=False)
    mapping = {i: [] for i in range(len(a_atoms))}
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            for d in range(i2 - i1):
                mapping[i1 + d].append(j1 + d)
        else:
            for i in range(i1, i2):
                mapping[i].extend(range(j1, j2))
    return mapping


def find_runs(form, atoms, keep_rafeh=False):
    """Every run of atoms whose review keys equal the form's atoms' keys; the form's last atom,
    if it has no final maqaf, matches an atom with or without one."""
    fa = form_atoms(form)

    def k(a, last):
        x = skey(a, keep_rafeh)
        return x.rstrip(MAQAF) if last else x

    target = [k(a, i == len(fa) - 1 and not a.endswith(MAQAF)) for i, a in enumerate(fa)]
    hits = []
    for i in range(len(atoms) - len(fa) + 1):
        if all(
            k(atoms[i + j], j == len(fa) - 1 and not fa[j].endswith(MAQAF)) == t
            for j, t in enumerate(target)
        ):
            hits.append(list(range(i, i + len(fa))))
    return hits


# ------------------------------------------------------------------ WLC

WLC418_BOOKS = Path(
    "C:/Users/BenDe/GitRepos2/MAM-basics/.novc/wlc418-tanach-us/sefaria-data-0f63a5fe/books"
)
UXLC26_BOOKS = MB_ROOT / "in" / "UXLC-39"
WLC42X_DIRS = {"4.20": MB_ROOT / "out" / "wlc420-u", "4.22": MB_ROOT / "out" / "wlc422-u"}
_WLC418_CACHE = {}


def read_wlc418_book(osis, books_dir=WLC418_BOOKS):
    """{(chapter, verse): [atom, ...]}; an atom is {"tag": w|k|q|x|pe|samekh|reversednun,
    "text", "raw", "notes"}. Reads tanach.us's XML: WLC 4.18 by default, UXLC 2.6 with
    books_dir=UXLC26_BOOKS."""
    ck = (str(books_dir), osis)
    if ck in _WLC418_CACHE:
        return _WLC418_CACHE[ck]
    path = Path(books_dir) / (TANACH_US[osis] + ".xml")
    root = ET.parse(path).getroot()
    out = {}
    tanach = root.find("tanach")
    for book in tanach.findall("book"):
        for c in book.findall("c"):
            for v in c.findall("v"):
                key = (int(c.get("n")), int(v.get("n")))
                atoms = []
                for el in v:
                    if el.tag in ("w", "k", "q"):
                        text, notes = el.text or "", []
                        for sub in el:
                            if sub.tag == "x":
                                notes.append(sub.text)
                            elif sub.tag == "s":
                                text += sub.text or ""
                            else:
                                raise ValueError("%s %s: %r in %r" % (osis, key, sub.tag, el.tag))
                            text += sub.tail or ""
                        # tanach.us's text marks morpheme boundaries with "/": kept in "raw",
                        # dropped from "text".
                        raw = text.strip()
                        atoms.append({"tag": el.tag, "text": raw.replace("/", ""), "raw": raw, "notes": notes})
                    elif el.tag == "x":
                        atoms.append({"tag": "x", "text": "", "notes": [el.text]})
                    elif el.tag in ("pe", "samekh", "reversednun"):
                        atoms.append({"tag": el.tag, "text": "", "notes": []})
                    else:
                        raise ValueError("%s %s: unknown v child %r" % (osis, key, el.tag))
                out[key] = atoms
    _WLC418_CACHE[ck] = out
    return out


def wlc418_side(atoms, side):
    """The atoms of one side of every ketiv/qere, as text records; notes stay on their atom."""
    keep = ("w", "k") if side == "ketiv" else ("w", "q")
    return [a for a in atoms if a["tag"] in keep]


_WLC42X_CACHE = {}


def read_wlc42x(version):
    """{(osis, chapter, verse): [atom, ...]} from MAM-basics' out/wlc42x-u; an atom is
    {"text", "notes", "kq": None | "k" | "q", "spi"}."""
    if version in _WLC42X_CACHE:
        return _WLC42X_CACHE[version]
    out = {}
    for path in sorted(WLC42X_DIRS[version].glob("1verses_*.json")):
        for verse in json.loads(path.read_text(encoding="utf-8")):
            m = re.fullmatch(r"([0-9a-z]{2})(\d+):(\d+)", verse["bcv"])
            osis = OSIS_FROM_MC[m.group(1)]
            key = (osis, int(m.group(2)), int(m.group(3)))
            atoms = []
            for vel in verse["vels"]:
                if isinstance(vel, str):
                    word, notes = vel, []
                elif set(vel) == {"word", "notes"}:
                    word, notes = vel["word"], list(vel["notes"])
                elif set(vel) == {"sam_pe_inun"}:
                    atoms.append({"text": "", "notes": [], "kq": None, "spi": vel["sam_pe_inun"]})
                    continue
                else:
                    raise ValueError("%s: unknown vel %r" % (key, vel))
                kq = None
                if word.startswith("**"):
                    word, kq = word[2:], "q"
                elif word.startswith("*"):
                    word, kq = word[1:], "k"
                atoms.append({"text": word, "notes": notes, "kq": kq, "spi": None})
            out[key] = atoms
    _WLC42X_CACHE[version] = out
    return out


def wlc42x_side(atoms, side):
    keep = (None, "k") if side == "ketiv" else (None, "q")
    return [a for a in atoms if a["spi"] is None and a["kq"] in keep]


# ------------------------------------------------------------------ the review and MAM

LINT_PATH = MB_ROOT / "py" / "tests" / "test_israel_bible_review_mam_forms.py"


def load_lint():
    spec = importlib.util.spec_from_file_location("ib_lint", LINT_PATH)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def review_cases():
    """The review's cases: forms.json's rows, then review.md's tour table, then its Decalogue
    table, read with the review module's own readers."""
    out = []
    for row in ib_review.forms():
        book, ch, vs = ib_review.bcv(row["reference"])
        out.append(
            {
                "source": "forms.json",
                "reference": row["reference"],
                "short": ib_review.SHORT[book],
                "osis": ib_review.SHORT[book].replace(" ", ""),
                "chapter": ch,
                "verse": vs,
                "page": row["page"],
                "ib": row["israel_bible"],
                "mam": row["mam"],
                "label": row.get("label"),
                "strand": None,
                "keep_rafeh": row["reference"] in ib_review.RAFEH_REFS,
            }
        )
    lines = ib_review.review_lines()
    for headers, table, strand in (
        (ib_review.TOUR_ROW_HEADERS, "review.md tour table", None),
        (ib_review.DECALOGUE_ROW_HEADERS, "review.md Decalogue table", "cant-bet"),
    ):
        for k, cells in enumerate(ib_review.data_table_rows(lines, headers), 1):
            short, cv = cells[0].rsplit(" ", 1)
            ch, vs = (int(x) for x in cv.split(":"))
            out.append(
                {
                    "source": "%s row %d" % (table, k),
                    "reference": cells[0],
                    "short": short,
                    "osis": short.replace(" ", ""),
                    "chapter": ch,
                    "verse": vs,
                    "page": int(cells[1]),
                    "ib": cells[2],
                    "mam": cells[3],
                    "label": None,
                    "strand": strand,
                    "keep_rafeh": False,
                }
            )
    return out


def mam_atoms(lint, short, chapter, verse, side, strand, where):
    node = lint._verse(short, chapter, verse)
    return form_atoms(lint._verse_text(node, side, strand, where))

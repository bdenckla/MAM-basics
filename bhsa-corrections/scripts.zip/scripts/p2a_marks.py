"""p2a: the code points of the BHSA's, WLC 4.18's and MAM's atoms at given slots (scratch).

Usage (from the MAM-basics root):
  .venv/Scripts/python.exe -I <folder>/scripts/p2a_marks.py <folder> <slot> ...

Writes out/p2a-marks.txt: for each slot, each text's characters by Unicode name.
"""

import sys
import unicodedata
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402
from p2a_check import Ctx  # noqa: E402
from p2a_render import Renderer  # noqa: E402


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    here = Path(sys.argv[1])
    X = Ctx()
    R = Renderer(X)
    out = []
    for s in (int(a) for a in sys.argv[2:]):
        _, atom, mam = X.atom_of(s)
        out.append("slot %d (%s)" % (s, R.eng(s)))
        for name, text in (("BHSA", atom["text"]), ("WLC 4.18", R.wlc_atoms(s)), ("MAM", mam)):
            out.append("  %s: %s" % (name, " | ".join(unicodedata.name(ch, "U+%04X" % ord(ch)) for ch in text)))
            out.append("  %s in MAM-normal order: %s" % (name, " | ".join(unicodedata.name(ch, "U+%04X" % ord(ch)) for ch in C.mnorm(text))))
    (here / "out" / "p2a-marks.txt").write_text("\n".join(out) + "\n", encoding="utf-8", newline="\n")
    print("wrote out/p2a-marks.txt")


if __name__ == "__main__":
    main()

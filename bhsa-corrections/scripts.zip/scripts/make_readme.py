"""Write README.md from scripts/README.template.md, expanding {{FILE:<path>}} placeholders with
the named file's text (a path relative to this folder).

Throwaway scratch. Usage: python -I make_readme.py <this folder>
"""

import re
import sys
from pathlib import Path


def main():
    here = Path(sys.argv[1])
    text = (here / "scripts" / "README.template.md").read_text(encoding="utf-8")
    text = re.sub(
        r"\{\{FILE:([^}]+)\}\}",
        lambda m: (here / m.group(1)).read_text(encoding="utf-8").rstrip("\n"),
        text,
    )
    if "{{" in text:
        raise SystemExit("an unexpanded placeholder remains")
    (here / "README.md").write_text(text, encoding="utf-8", newline="\n")
    print("wrote", here / "README.md")


if __name__ == "__main__":
    main()

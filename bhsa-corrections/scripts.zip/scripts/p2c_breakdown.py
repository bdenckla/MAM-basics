"""Count slice p2c's judgments by category and by the shared reason each one starts with.

Throwaway scratch. Usage: python -I p2c_breakdown.py <out txt>
"""

import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import p2c_judgments as PJ  # noqa: E402

SHARED = {
    "HATAF_VOCAL": PJ.HATAF_VOCAL[:-1],
    "MAM_HATAF": PJ.MAM_HATAF[:-1],
    "FULL_FOR_HATAF": PJ.FULL_FOR_HATAF[:-1],
    "HATAF_CLOSED": PJ.HATAF_CLOSED[:-1],
    "HATAF_DOUBLED": PJ.HATAF_DOUBLED[:-1],
    "WAYQ_DAGESH": PJ.WAYQ_DAGESH[:-1],
    "KQ": PJ.KQ[:-1],
    "INITIAL_LENE": PJ.INITIAL_LENE,
    "INTERNAL_LENE": PJ.INTERNAL_LENE[:-1],
    "VAV_DOT": PJ.VAV_DOT,
}


def main():
    out = Path(sys.argv[1])
    c = Counter()
    for s, (cat, reason) in PJ.J.items():
        kind = next((k for k, v in SHARED.items() if reason.startswith(v)), "own reason")
        c[(cat, kind)] += 1
    lines = ["%s | %s | %d" % (cat, kind, n) for (cat, kind), n in sorted(c.items())]
    lines.append("total | %d" % sum(c.values()))
    out.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()

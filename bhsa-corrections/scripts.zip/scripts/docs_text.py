"""Extract the main text of fetched documentation pages, and grep it.

Throwaway scratch. Usage: python -I docs_text.py <this folder> <out txt> <regex>

For each fetched/etcbc-docs-*/page.html, the text inside <article> (MkDocs Material's content),
as lines, goes to out/docs/<name>.txt; then every line matching <regex> (case-insensitive) is
written, with its page and line number, to <out txt>.
"""

import re
import sys
from html.parser import HTMLParser
from pathlib import Path

BLOCK = {"p", "li", "h1", "h2", "h3", "h4", "h5", "tr", "td", "th", "pre", "br", "dt", "dd", "div", "table"}


class ArticleText(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.depth = 0
        self.parts = []

    def handle_starttag(self, tag, attrs):
        if tag == "article":
            self.depth += 1
        if self.depth and tag in BLOCK:
            self.parts.append("\n")
        if self.depth and tag == "td":
            self.parts.append(" | ")

    def handle_endtag(self, tag):
        if tag == "article" and self.depth:
            self.depth -= 1

    def handle_data(self, data):
        if self.depth:
            self.parts.append(data)


def main():
    here, out, rx = Path(sys.argv[1]), Path(sys.argv[2]), re.compile(sys.argv[3], re.I)
    (here / "out" / "docs").mkdir(exist_ok=True)
    hits = []
    for page in sorted((here / "fetched").glob("etcbc-docs-*/page.html")):
        name = page.parent.name[len("etcbc-docs-") :]
        p = ArticleText()
        p.feed(page.read_text(encoding="utf-8"))
        text = re.sub(r"\n\s*\n+", "\n", "".join(p.parts)).strip()
        (here / "out" / "docs" / (name + ".txt")).write_text(text + "\n", encoding="utf-8", newline="\n")
        for i, line in enumerate(text.split("\n"), 1):
            if rx.search(line):
                hits.append("%s:%d: %s" % (name, i, line.strip()))
    out.write_text("\n".join(hits) + "\n", encoding="utf-8", newline="\n")
    print(len(hits), "hits")


if __name__ == "__main__":
    main()

"""Part 1, the footnote mam-hataf-ng's six verses: MAM's hataf under a non-guttural where WLC
4.18 has none, with the BHSA's words there.

Throwaway scratch for the brief
C:/Users/BenDe/GitRepos/MAM-basics/.novc/commander-session/bhsa-corrections-brief-2026-11-13.md.
Adapted from the morphhb session's scripts/part1_hataf.py.

Usage: python -I part1_hataf.py <out json> <out txt>

In each verse, MAM's atoms (MAM-simple, BHS versification, read by the review's lint) and WLC
4.18's are aligned by letters. A case is an atom in which MAM has a hataf (segol, patah or
qamats) under a letter other than alef, he, het and ayin, while the aligned WLC 4.18 atom has
no hataf under that letter. The BHSA's atoms are aligned with WLC 4.18's by letters as in
part1_cases.py.
"""

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402
import part1_cases as P  # noqa: E402

VERSES = [
    ("Ezekiel 44:13", "Ezek", 44, 13),
    ("Ezra 4:9", "Ezra", 4, 9),
    ("2 Chronicles 5:7", "2Chr", 5, 7),
    ("Numbers 35:20", "Num", 35, 20),
    ("1 Samuel 26:10", "1Sam", 26, 10),
    ("2 Samuel 6:5", "2Sam", 6, 5),
]
HATAFS = {
    "\N{HEBREW POINT HATAF SEGOL}",
    "\N{HEBREW POINT HATAF PATAH}",
    "\N{HEBREW POINT HATAF QAMATS}",
}
GUTTURALS = set("\N{HEBREW LETTER ALEF}\N{HEBREW LETTER HE}\N{HEBREW LETTER HET}\N{HEBREW LETTER AYIN}")


def letter_clusters(atom):
    return [(b, set(m)) for b, m in C.clusters(atom) if C.HEB_LETTER.match(b)]


def hataf_ng_letters(atom):
    return [i for i, (b, m) in enumerate(letter_clusters(atom)) if b not in GUTTURALS and m & HATAFS]


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    out_json, out_txt = Path(sys.argv[1]), Path(sys.argv[2])
    B = C.Bhsa()
    lint = C.load_lint()
    results, lines = [], []
    for (ref, osis, ch, vs), side in [(v, s) for v in VERSES for s in ("ketiv", "qere")]:
        short = osis if osis not in ("1Sam", "2Sam", "1Chr", "2Chr") else osis[0] + " " + osis[1:]
        mam = C.mam_atoms(lint, short, ch, vs, side, None, ref)
        w418 = [a["text"] for a in C.wlc418_side(C.read_wlc418_book(osis)[(ch, vs)], side)]
        b_atoms = B.atoms(osis, ch, vs, P.BHSA_SIDE[side])
        mam_to_418 = C.align(mam, w418)
        to_b = C.align(w418, [a["text"] for a in b_atoms])
        lines.append("== %s (%s side), BHSA %s %d:%d" % (ref, side, C.BHSA_BOOK[osis], ch, vs))
        for i, atom in enumerate(mam):
            idx = hataf_ng_letters(atom)
            if not idx:
                continue
            for j in mam_to_418[i]:
                wl, ml = letter_clusters(w418[j]), letter_clusters(atom)
                if len(wl) != len(ml):
                    lines.append("   MAM %s vs WLC 4.18 %s: letter counts differ" % (atom, w418[j]))
                    continue
                missing = [k for k in idx if not (wl[k][1] & HATAFS)]
                if not missing:
                    continue
                bs = [b_atoms[x] for x in to_b[j]]
                rec = {
                    "reference": ref,
                    "side": side,
                    "mam": atom,
                    "wlc418": w418[j],
                    "letters": [ml[k][0] for k in missing],
                    "bhsa": [b["text"] for b in bs],
                    "bhsa_slots": [P.slot_record(B, s) for b in bs for s in b["slots"]],
                    "bkey_bhsa_eq_wlc418": [C.bkey(b["text"]) for b in bs] == [C.bkey(w418[j])],
                    "bkey_bhsa_eq_mam": [C.bkey(b["text"]) for b in bs] == [C.bkey(atom)],
                }
                results.append(rec)
                lines.append("   MAM %s | WLC 4.18 %s | BHSA %s | hataf under %s | BHSA=WLC4.18 %s BHSA=MAM %s" % (
                    C.mnorm(atom), w418[j], " ".join(rec["bhsa"]), rec["letters"],
                    rec["bkey_bhsa_eq_wlc418"], rec["bkey_bhsa_eq_mam"]))
                for r in rec["bhsa_slots"]:
                    lines.append("      slot %d %s [%s] lex %s %s %s | sp %s | vs %s vt %s | nu %s st %s prs %s | phrase %s %s" % (
                        r["slot"], r.get("g_word_utf8", ""), r.get("g_word", ""), r.get("lex"), r.get("voc_lex_utf8", ""),
                        r.get("gloss", ""), r.get("sp"), r.get("vs"), r.get("vt"), r.get("nu"), r.get("st"), r.get("prs"),
                        r["phrase"]["typ"], r["phrase"]["function"]))
    out_txt.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    out_json.write_text(json.dumps(results, ensure_ascii=False, indent=1), encoding="utf-8", newline="\n")
    print("cases: %d" % len(results))


if __name__ == "__main__":
    main()

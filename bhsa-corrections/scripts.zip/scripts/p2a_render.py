"""p2a: render the review out/p2a-test-a-review.md from out/p2a-review-template.md (scratch).

Usage (from the MAM-basics root):
  .venv/Scripts/python.exe -I <folder>/scripts/p2a_render.py <folder>

The template holds no Hebrew. Every form comes from the data, in MAM-normal mark order, through
these placeholders:
  {g:S}     the BHSA's written word at slot S (g_word_utf8), accents kept;
  {gk:S}    the same, by the review's key (accents, meteg and rafeh stripped);
  {atom:S}  the BHSA's atom holding slot S (ketiv side), accents kept; {atomk:S} by the key;
  {mam:S}   MAM's atom(s) aligned with that atom; {mamk:S} by the key;
  {wlc:S}   WLC 4.18's atom(s) aligned with that atom; {wlck:S} by the key;
  {vl:S}    voc_lex_utf8 at slot S;
  {verse:OSIS:CH:V:S,S}  a table of the verse, atom by atom, the atoms holding slots S marked;
  {groups}  the table of Test A's lines 259 to 308, with the categories in GROUPS below.
"""

import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402
from p2a_check import Ctx, fmt  # noqa: E402

ENGLISH = {short.replace(" ", ""): name for name, short in C.ib_review.SHORT.items()}

NAME = "homograph: name"
HOMONYM = "homograph: homonym"
HOMOGRAPH = "homograph"
ARTIFACT = "artifact"
CORRECTION = "**correction**"

# line of out/30-part2-test-a.txt: (category, reason); a reason of None is written from the data
# (a proper name spelled like the key's commonest analysis).
GROUPS = {
    259: (ARTIFACT, "The dagesh in the yod follows the relative particle `C`, a slot of its own, not a wayyiqtol's conjunction; the qal imperfect is what the pointing spells."),
    260: (ARTIFACT, "As at line 259: both words follow the relative particle `C`."),
    261: (ARTIFACT, "As at line 259 for the tense. The lexeme `JR>[` for this one-yod pointing is the key's second analysis (9 wayyiqtol words) and Micah 7:17's."),
    262: (HOMOGRAPH, "The piel infinitives absolute and construct of `BQC[` are spelled alike; this one, after two infinitives construct with `L` and without one, is read as absolute."),
    263: (ARTIFACT, "As at line 259: the relative particle `C`."),
    264: (HOMOGRAPH, "The hiphil imperfect, first person plural, of `BW>[` ('we bring') is spelled like 'prophet'; each place has an object (`Objc`)."),
    265: (HOMONYM, "`CNH=/` 'sleep' and `CNH/` 'year', each with the suffix `W`, are spelled alike."),
    266: (ARTIFACT, "The wayyiqtol is marked only by the conjunction's qamats before alef, in the slot `W`; the first person piel imperfect and wayyiqtol are otherwise spelled alike."),
    267: (HOMOGRAPH, "The -in plural of 'day': the BHSA's `nme` is `JN` here and on 23 other Hebrew words (13 of them `MLH/` in Job); 'at the end of the ...' decides against 'the right hand'."),
    268: (NAME, None),
    269: (NAME, None),
    270: (HOMONYM, "`<NH==[` 'sing' and `<NH[` 'answer' are spelled alike."),
    271: (ARTIFACT, "As at line 266: the conjunction's qamats before alef."),
    272: (HOMONYM, "`<ZB=[` (the BHSA's gloss 'flag') and `<ZB[` 'leave' are spelled alike."),
    273: (HOMOGRAPH, "The niphal participle and the qal imperfect, first person plural, of `<FH[` are spelled alike; after `HJH[` 'be' the participle is read."),
    274: (HOMOGRAPH, "`MRJ/` 'rebellion' with the suffix `M` ('their rebellion') is spelled like the name Miriam."),
    **{n: (NAME, None) for n in range(275, 302)},
    302: (HOMOGRAPH, "The qal participle, feminine singular, of `<LH[` 'ascend', after the article, is spelled like `<LH/` 'burnt offering'."),
    303: (HOMOGRAPH, "The qal infinitive absolute of `GDL[` is spelled like the adjective `GDWL/` 'great'; the BHSA has it without the dagesh, {gk:163152}, at 2 Samuel 5:10 and 1 Chronicles 11:9, and here it is paired with the hiphil infinitive absolute {gk:407477}."),
    304: (HOMOGRAPH, "The qal imperative, masculine singular, of `BW>[` is spelled like its infinitive construct; the parallel 1 Kings 22:30, {atomk:194279}, is analysed as an imperative too."),
    305: (HOMONYM, "`DBR=[` 'push back' and `DBR[` 'speak' are spelled alike."),
    306: (HOMOGRAPH, "The noun `CRT/` 'cultic service' is spelled like the piel infinitive construct of `CRT[`."),
    307: (HOMOGRAPH, "The verse's last atom, with silluq: the qal perfect's pausal form, spelled like the adjective `XZQ/` 'strong'; the BHSA's five other qal perfects, third masculine singular, of `XZQ[` without a suffix are {gk:23425}, with pataḥ under the zayin."),
    308: (CORRECTION, "The pointing is that of the noun `M<L=/` 'unfaithfulness'; the BHSA's five other qal perfects, third masculine singular, of `M<L[` are {gk:125766}, with qamats under the mem. A new candidate: see its section."),
}


class Renderer:
    def __init__(self, X):
        self.X = X
        self._wlc = {}

    def eng(self, s):
        b, ch, v = self.X.B.ref_of_slot[s]
        return "%s %d:%d" % (ENGLISH[C.OSIS_FROM_BHSA[b]], ch, v)

    def wlc_atoms(self, s):
        X = self.X
        b, ch, v = X.B.ref_of_slot[s]
        osis = C.OSIS_FROM_BHSA[b]
        if (osis, ch, v) not in self._wlc:
            b_atoms, _, _ = X.verse(s)
            wlc = C.wlc418_side(C.read_wlc418_book(osis)[(ch, v)], "ketiv")
            self._wlc[(osis, ch, v)] = (wlc, C.align([a["text"] for a in b_atoms], [a["text"] for a in wlc]))
        wlc, to_w = self._wlc[(osis, ch, v)]
        i, _, _ = X.atom_of(s)
        return " ".join(wlc[j]["text"] for j in to_w[i])

    def slot_value(self, kind, s):
        X = self.X
        if kind == "g":
            return C.mnorm(X.gw[s])
        if kind == "gk":
            return C.mnorm(C.skey(X.gw[s]))
        if kind in ("atom", "atomk", "mam", "mamk"):
            _, atom, mam = X.atom_of(s)
            text = atom["text"] if kind.startswith("atom") else mam
            return C.mnorm(C.skey(text) if kind.endswith("k") else text)
        if kind in ("wlc", "wlck"):
            text = self.wlc_atoms(s)
            return C.mnorm(C.skey(text) if kind == "wlck" else text)
        if kind == "vl":
            return C.mnorm(X.f["voc_lex_utf8"][s])
        raise ValueError(kind)

    def slot_analysis(self, s):
        X, f = self.X, self.X.f
        parts = ["`%s`" % f["lex"][s]]
        if f["sp"][s] == "verb":
            parts.append("%s %s" % (f["vs"][s], f["vt"][s]))
            parts += [f[n][s] for n in ("ps", "nu", "gn") if f[n][s] not in ("NA", "unknown")]
        else:
            parts.append(f["sp"][s])
            if f["nu"][s] not in ("NA", "unknown"):
                parts.append(f["nu"][s])
        if f["prs"][s] not in ("absent", "n/a"):
            parts.append("suffix `%s`" % f["prs"][s])
        p = X.B.phrase_of.get(s)
        return "%s '%s' (%s %s)" % (" ".join(parts), f["gloss"].get(s, ""), X.typ.get(p), X.fun.get(p))

    def verse_table(self, osis, ch, v, marks):
        X = self.X
        first = X.B.slots(osis, ch, v)[0]
        b_atoms, mam, to_mam = X.verse(first)
        rows = [
            "%s %d:%d, atom by atom (the reviewed atom's number in bold):" % (ENGLISH[osis], ch, v),
            "",
            "| # | The BHSA's analysis, slot by slot | The BHSA's atom | MAM's atom |",
            "|---|---|---|---|",
        ]
        for i, a in enumerate(b_atoms):
            n = ("**%d**" % (i + 1)) if set(a["slots"]) & marks else str(i + 1)
            rows.append("| %s | %s | %s | %s |" % (
                n, "; ".join(self.slot_analysis(s) for s in a["slots"]), C.mnorm(a["text"]),
                " ".join(C.mnorm(mam[j]) for j in to_mam[i])))
        return "\n".join(rows)

    def name_reason(self, k, a, slots):
        X, f = self.X, self.X.f
        s0 = slots[0]
        if f["sp"][s0] != "nmpr":
            raise ValueError("line with a non-name analysis given as a name: %r" % (a,))
        top = X.by_key[k].most_common(1)[0][0]
        t0 = X.slots_of[(k, top)][0]
        like = "the name " if f["sp"][t0] == "nmpr" else ""
        return "A proper name, `%s` '%s', spelled like %s`%s` '%s', the key's commonest analysis." % (
            f["lex"][s0], f["gloss"][s0], like, fmt(top), f["gloss"][t0])

    def groups_table(self, here):
        X = self.X
        lines_txt = (here / "out" / "30-part2-test-a.txt").read_text(encoding="utf-8").split("\n")
        groups = json.loads((here / "out" / "32-part2-scan.json").read_text(encoding="utf-8"))["test_a"]
        if len(groups) != 305 or lines_txt[308] != "" or len(lines_txt) != 309:
            raise ValueError("the test A files are not as reviewed")
        rows = [
            "| Line | Category | Pointed key | Flagged analysis | The key's analyses | Where | Reason |",
            "|---|---|---|---|---|---|---|",
        ]
        counts = {}
        for n in range(259, 309):
            g = groups[n - 4]
            slots = [int(x) for x in re.findall(r"slot (\d+)", lines_txt[n - 1])]
            if slots != g["slots"]:
                raise ValueError("line %d does not match its group" % n)
            k, a = tuple(g["key"]), tuple(g["analysis"])
            cat, reason = GROUPS[n]
            counts[cat] = counts.get(cat, 0) + 1
            if reason is None:
                reason = self.name_reason(k, a, slots)
            rows.append("| %d | %s | %s | `%s` x%d | %s | %s | %s |" % (
                n, cat, C.mnorm(k[1]), fmt(a), len(slots),
                ", ".join("`%s` x%d" % (fmt(b), c) for b, c in X.by_key[k].most_common()),
                "; ".join(self.eng(s) for s in slots), reason))
        if sum(counts.values()) != 50:
            raise ValueError(counts)
        summary = "Categories: " + ", ".join("%s %d" % (c.strip("*"), counts[c]) for c in (CORRECTION, NAME, HOMONYM, HOMOGRAPH, ARTIFACT)) + "."
        # MAM's atom against the BHSA's at every word of the 50 groups, by the review's key with
        # the BHSA's way of writing a holam male allowed for.
        words, differ = 0, []
        for n in range(259, 309):
            for s in groups[n - 4]["slots"]:
                words += 1
                _, atom, mam = X.atom_of(s)
                if C.bkey(atom["text"]).rstrip(C.MAQAF) != C.bkey(mam).rstrip(C.MAQAF):
                    differ.append("%s (line %d): the BHSA %s, MAM %s" % (
                        self.eng(s), n, C.mnorm(C.skey(atom["text"])), C.mnorm(C.skey(mam))))
        check = "By the review's key, with the BHSA's way of writing a ḥolam male allowed for (`bc_common.bkey`), MAM's atom has the BHSA's pointing at %d of the %d words of these 50 groups%s" % (
            words - len(differ), words, (": it differs at " + "; ".join(differ) + ".") if differ else ".")
        return summary + " " + check + "\n\n" + "\n".join(rows)

    def same_atoms(self, slots):
        """Whether the BHSA's atom, WLC 4.18's and MAM's have the same letters and the same marks
        on each letter, accents included, at each slot: bc_common.bfkey, which ignores the order
        of a letter's marks, the sof pasuq and the BHSA's way of writing a holam male. Also
        whether the three are the same string in MAM-normal order."""
        out = []
        for s in slots:
            _, atom, mam = self.X.atom_of(s)
            texts = (atom["text"], self.wlc_atoms(s), mam)
            keys = {C.bfkey(t) for t in texts}
            strings = {C.mnorm(t.replace(C.SOF_PASUQ, "").strip()) for t in texts}
            out.append((s, self.eng(s), len(keys) == 1, len(strings) == 1))
        return out

    def render(self, text, here):
        def verse(m):
            marks = {int(x) for x in m.group(4).split(",")}
            return self.verse_table(m.group(1), int(m.group(2)), int(m.group(3)), marks)

        text = text.replace("{groups}", self.groups_table(here))
        text = re.sub(r"\{verse:(\w+):(\d+):(\d+):([\d,]+)\}", verse, text)
        text = re.sub(r"\{(g|gk|atom|atomk|mam|mamk|wlc|wlck|vl):(\d+)\}", lambda m: self.slot_value(m.group(1), int(m.group(2))), text)
        left = re.findall(r"\{[a-z]+:[^}]*\}|\{groups\}", text)
        if left:
            raise ValueError("unrendered placeholders: %r" % left)
        return text


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    here = Path(sys.argv[1])
    X = Ctx()
    R = Renderer(X)
    # Facts the template states without a placeholder, checked here.
    f = X.f
    k = X.key_of[299793]
    prs = sorted({f["prs"][s] for s in X.key_of if X.key_of[s] == k and f["lex"][s] == ">B/"})
    print("Mic 1:15's key, >B/ suffixes:", prs)
    for s in (152786, 328516, 420804, 158430):
        k = X.key_of[s]
        print("slot %d (%s): its key's words: %d; analyses %s" % (
            s, X.ref(s), sum(X.by_key[k].values()), X.by_key[k].most_common()))
    for s, ref, same_key, same_string in R.same_atoms([158430, 342192, 163423, 299793, 301390, 230330, 420804, 152786]):
        print("slot %d (%s): the BHSA's, WLC 4.18's and MAM's atoms: same by bfkey %s; same string %s" % (
            s, ref, same_key, same_string))
    template = (here / "out" / "p2a-review-template.md").read_text(encoding="utf-8")
    hebrew = re.findall("[\N{HEBREW ACCENT ETNAHTA}-\N{HEBREW PUNCTUATION GERSHAYIM}\N{HEBREW LETTER YOD WITH HIRIQ}-\N{HEBREW LIGATURE ALEF LAMED}]", template)
    if hebrew:
        raise ValueError("the template holds Hebrew: %r" % hebrew[:5])
    out = R.render(template, here)
    (here / "out" / "p2a-test-a-review.md").write_text(out, encoding="utf-8", newline="\n")
    print("wrote out/p2a-test-a-review.md")


if __name__ == "__main__":
    main()

"""Find the BHSA slots of named lexemes in named verses, for slice p2c's placeholders.

Throwaway scratch. Usage (from the MAM-basics root):
  python -I p2c_slots.py <this folder> <out txt> <OSIS>:<chapter>:<verse>:<lex> ...

Prints each matching slot with its written form (the qere where it has one), its analysis and
its person, number and suffix. Forms are emitted from the data in MAM-normal mark order.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    here, out = Path(sys.argv[1]), Path(sys.argv[2])
    B = C.Bhsa()
    gw, qw, lex = B.wf("g_word_utf8"), B.wf("qere_utf8"), B.wf("lex")
    vs, vt, ps, nu, prs = B.wf("vs"), B.wf("vt"), B.wf("ps"), B.wf("nu"), B.wf("prs")
    lines = []
    for spec in sys.argv[3:]:
        osis, ch, v, lx = spec.split(":", 3)
        slots = [s for s in B.slots(osis, int(ch), int(v)) if lex.get(s) == lx]
        if not slots:
            raise SystemExit("no slot of %s in %s %s:%s" % (lx, osis, ch, v))
        for s in slots:
            lines.append("%s | slot %d | %s%s | %s %s %s | ps %s nu %s prs %s" % (
                spec, s, C.mnorm(qw.get(s) or gw[s]), " (qere)" if s in qw else "",
                lex[s], vs[s], vt[s], ps[s], nu[s], prs[s]))
    out.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print("wrote", out)


if __name__ == "__main__":
    main()

"""Fourth targeted check for slice p2b (throwaway scratch).

Usage (from the MAM-basics root):
  C:/Users/BenDe/GitRepos/MAM-basics/.venv/Scripts/python.exe -I <this folder>/scripts/p2b_checks4.py

Every distinct pointed key, with its state and count, of a few lexemes whose rows turn on a
vowel's quality: Aramaic >NC/ (Daniel 2:10), >NQH/ (Psalms 12:6), BHMH/ with a suffix
(Deuteronomy 28:11), >XCWRWC/ (Esther 9:2). Writes out/p2b-checks4.txt.
"""

import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402

HERE = Path(__file__).resolve().parent.parent
WANT = [("Aramaic", ">NC/"), ("Hebrew", ">NQH/"), ("Hebrew", "BHMH/"), ("Hebrew", ">XCWRWC/")]


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    B = C.Bhsa()
    gw, qw = B.wf("g_word_utf8"), B.wf("qere_utf8")
    lang, lex, st, prs = B.wf("language"), B.wf("lex"), B.wf("st"), B.wf("prs")
    out = []
    for lg, lx in WANT:
        c, ex = Counter(), {}
        for s in range(1, B.max_slot + 1):
            if lex.get(s) == lx and lang.get(s) == lg and s not in qw and C.letters(gw.get(s, "")):
                k = (C.skey(gw[s]), st.get(s, ""), prs.get(s, ""))
                c[k] += 1
                ex.setdefault(k, s)
        out.append("== %s %s" % (lg, lx))
        for (k, s_, p), n in c.most_common():
            b, ch, v = B.ref_of_slot[ex[(k, s_, p)]]
            out.append("  %s st=%s prs=%s x%d (%s %d:%d)" % (C.mnorm(k), s_, p, n, b, ch, v))
    text = "\n".join(out) + "\n"
    (HERE / "out" / "p2b-checks4.txt").write_text(text, encoding="utf-8", newline="\n")
    print(text)


if __name__ == "__main__":
    main()

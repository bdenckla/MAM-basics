"""p2a: list the lines of a file whose first strong character is right-to-left (scratch).

Usage: python -I p2a_bidi.py <file>
"""

import sys
import unicodedata
from pathlib import Path


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    for n, line in enumerate(Path(sys.argv[1]).read_text(encoding="utf-8").split("\n"), 1):
        for ch in line:
            b = unicodedata.bidirectional(ch)
            if b == "L":
                break
            if b in ("R", "AL"):
                print("line %d: %s" % (n, line[:60]))
                break


if __name__ == "__main__":
    main()

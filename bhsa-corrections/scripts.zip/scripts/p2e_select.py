"""Slice p2e: select the atom-level rows that no slice has judged, and gather their evidence.

Throwaway scratch for the brief
C:/Users/BenDe/GitRepos/MAM-basics/.novc/commander-session/bhsa-corrections-brief-2026-11-13.md,
written by a sub-agent (slice p2e) of the session that wrote ../README.md. No existing file is
edited.

Usage (from the MAM-basics root): python -I p2e_select.py <this folder>

The rows:
1. out/p2d-scan.json's Test A groups marked new (no slot of their atoms among the slot-level
   Test A words) of the kinds lexeme, stem/tense and segmentation (p2d reviewed the kind
   ps/nu/gn/prs);
2. its Test B atoms of the classes mam-unique and neither none of whose slots is a row of
   out/p2b-mam-unique.json or out/p2c-neither.json, the slot-level judgments.

The atoms are recomputed as p2d_scan_atoms.py computes them (same order, so the same ids), and
checked against out/p2d-scan.json. For each row: the BHSA's atom and its slots' features, MAM's
atom, the per-letter difference of marks (after bc_common.holam_to_prev and the review's
stripping), WLC 4.18's aligned atom with its notes, the verse's atoms around it, the BHSA's other
atoms with the same pointed key (their analyses, with an example), and the BHSA's atoms with the
same letters and the same analysis (their pointings, with an example).

Writes out/p2e-candidates.txt and out/p2e-candidates.json.
"""

import json
import sys
import time
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402

FIELDS = ("lex", "vs", "vt", "ps", "nu", "gn", "prs")
SLOT_FEATS = ("language", "lex", "sp", "vs", "vt", "ps", "nu", "gn", "st", "prs", "gloss")
KINDS_A = ("segmentation", "lexeme", "stem/tense")
CLASSES_B = ("mam-unique", "neither")
NO_SUFFIX = ("absent", "n/a")
WINDOW = 5


def fmt_slot(t):
    """p2d_scan_atoms.fmt_slot."""
    lex, vs, vt, ps, nu, gn, prs = t
    s = lex
    if (vs, vt) != ("NA", "NA"):
        s += " %s %s" % (vs, vt)
    png = (ps, nu, gn)
    if png != ("NA", "NA", "NA"):
        s += " " + ".".join({"NA": "-", "unknown": "?"}.get(x, x) for x in png)
    if prs not in NO_SUFFIX:
        s += " +" + prs
    elif prs == "n/a" and png != ("NA", "NA", "NA"):
        s += " +n/a"
    return s


def fmt(a):
    return " + ".join(fmt_slot(tuple(t)) for t in a)


def show(s):
    """A form for display: stripped as the review's page strips its forms, MAM-normal order."""
    return C.mnorm(C.ib_review.stripped(s))


def mark_name(ch):
    n = unicodedata.name(ch, "U+%04X" % ord(ch))
    for p in ("HEBREW POINT ", "HEBREW PUNCTUATION ", "HEBREW MARK ", "HEBREW ACCENT "):
        if n.startswith(p):
            return n[len(p):].lower()
    return n.lower()


def letter_name(ch):
    return unicodedata.name(ch).replace("HEBREW LETTER ", "").lower()


def mark_diff(bhsa, mam):
    """Each letter whose marks differ, after holam_to_prev and the review's stripping; also a
    difference in the atom's inner maqafs."""
    a = C.clusters(C.ib_review.stripped(C.holam_to_prev(bhsa)).rstrip(C.MAQAF))
    b = C.clusters(C.ib_review.stripped(C.holam_to_prev(mam)).rstrip(C.MAQAF))
    la = [(x, m) for x, m in a if C.HEB_LETTER.match(x)]
    lb = [(x, m) for x, m in b if C.HEB_LETTER.match(x)]
    if [x for x, _ in la] != [x for x, _ in lb]:
        return ["letters differ"]
    out = []
    for i, ((x, ma), (_, mb)) in enumerate(zip(la, lb), 1):
        if sorted(ma) != sorted(mb):
            out.append("letter %d (%s): BHSA [%s], MAM [%s]" % (
                i, letter_name(x), ", ".join(mark_name(c) for c in ma) or "none",
                ", ".join(mark_name(c) for c in mb) or "none"))
    na = sum(1 for x, _ in a if x == C.MAQAF)
    nb = sum(1 for x, _ in b if x == C.MAQAF)
    if na != nb:
        out.append("inner maqafs: BHSA %d, MAM %d" % (na, nb))
    sa = sum(1 for x, _ in a if x == " ")
    sb = sum(1 for x, _ in b if x == " ")
    if sa != sb:
        out.append("inner spaces: BHSA %d, MAM %d" % (sa, sb))
    return out


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8", errors="backslashreplace")
    here = Path(sys.argv[1])
    out = here / "out"
    t0 = time.perf_counter()
    scan = json.loads((out / "p2d-scan.json").read_text(encoding="utf-8"))
    p2b = json.loads((out / "p2b-mam-unique.json").read_text(encoding="utf-8"))
    p2c = json.loads((out / "p2c-neither.json").read_text(encoding="utf-8"))
    slot_run = json.loads((out / "32-part2-scan.json").read_text(encoding="utf-8"))
    judged = {r["slot"]: "p2b" for r in p2b["rows"]}
    for r in p2c["rows"]:
        if r["slot"] in judged:
            raise ValueError("slot %d judged by both p2b and p2c" % r["slot"])
        judged[r["slot"]] = "p2c"
    slot_rows = {}
    for cls, rows in slot_run["test_b"].items():
        for r in rows:
            if r["slot"] in slot_rows:
                raise ValueError("slot %d in two slot-level classes" % r["slot"])
            slot_rows[r["slot"]] = dict(r, cls=cls)

    B = C.Bhsa()
    gw, qw, lang = B.wf("g_word_utf8"), B.wf("qere_utf8"), B.wf("language")
    feats = [B.wf(f) for f in FIELDS]
    sf = {f: B.wf(f) for f in SLOT_FEATS}
    english = {short.replace(" ", ""): name for name, short in C.ib_review.SHORT.items()}
    english["Eccl"] = "Ecclesiastes"

    def eref(ref):
        book, ch, v = ref
        return "%s %d:%d" % (english[C.OSIS_FROM_BHSA[book]], ch, v)

    # every atom, as p2d_scan_atoms.py makes them
    atoms = []
    verse_atoms = {}
    by_key = defaultdict(Counter)
    ids_of = defaultdict(list)
    by_letters = defaultdict(Counter)
    first_form = {}
    for ref in sorted(B.verse_slots, key=lambda r: B.verse_slots[r][0]):
        book, ch, v = ref
        osis = C.OSIS_FROM_BHSA[book]
        ids = []
        for ba in B.atoms(osis, ch, v, "ketiv"):
            aid = len(atoms)
            ids.append(aid)
            rec = {"id": aid, "ref": ref, "text": ba["text"], "slots": ba["slots"], "key": None, "analysis": None}
            atoms.append(rec)
            if any(s in qw for s in ba["slots"]) or not C.letters(ba["text"]):
                continue
            langs = tuple(sorted({lang[s] for s in ba["slots"]}))
            k = (langs, C.skey(ba["text"]).rstrip(C.MAQAF))
            a = tuple(tuple(f[s] for f in feats) for s in ba["slots"])
            rec["key"], rec["analysis"] = k, a
            by_key[k][a] += 1
            ids_of[(k, a)].append(aid)
            lk =(C.letters(ba["text"]), a)
            by_letters[lk][k[1]] += 1
            first_form.setdefault((lk, k[1]), aid)
        verse_atoms[ref] = ids
    print("atoms read, %.0f s" % (time.perf_counter() - t0), flush=True)

    def jk(k):
        return [list(k[0]), k[1]]

    def ja(a):
        return [list(t) for t in a]

    def tk(k):
        return (tuple(k[0]), k[1])

    def ta(a):
        return tuple(tuple(t) for t in a)

    def slot_info(s):
        d = {f: sf[f].get(s, "") for f in SLOT_FEATS}
        d["slot"] = s
        d["g_word"] = show(gw.get(s, ""))
        sr = slot_rows.get(s)
        if sr:
            d["slot_level"] = {
                "class": sr["cls"],
                "mam_piece": show(sr["mam_piece"]),
                "own": [[" ".join(x[1:]), n] for x, n in sr["own"]],
                "mam_key": [[" ".join(x[1:]), n] for x, n in sr["mam_key"]],
            }
        return d

    def counts_with_examples(k, counter, skip_aids=()):
        """The analyses of a key's atoms, each with its count and the references of up to three
        of its atoms other than skip_aids."""
        rows = []
        for a, n in counter.most_common():
            ex = [i for i in ids_of.get((k, a), []) if i not in skip_aids][:3]
            rows.append({"analysis": fmt(a), "count": n, "examples": [eref(atoms[i]["ref"]) for i in ex]})
        return rows

    def pointings_of(aid):
        rec = atoms[aid]
        lk = (C.letters(rec["text"]), rec["analysis"])
        rows = []
        for form, n in by_letters[lk].most_common(6):
            ex = first_form[(lk, form)]
            rows.append({"form": show(form), "count": n, "example": eref(atoms[ex]["ref"])})
        return rows

    def wlc418(aid):
        rec = atoms[aid]
        book, ch, v = rec["ref"]
        osis = C.OSIS_FROM_BHSA[book]
        try:
            w = C.wlc418_side(C.read_wlc418_book(osis)[(ch, v)], "ketiv")
        except KeyError:
            return [{"text": "(no such verse in WLC 4.18)", "notes": []}]
        ids = verse_atoms[rec["ref"]]
        m = C.align([atoms[i]["text"] for i in ids], [x["text"] for x in w])
        j = ids.index(aid)
        return [{"text": show(w[x]["text"]), "notes": w[x]["notes"]} for x in m[j]]

    def place(aid):
        """The atom's verse (OSIS, chapter, verse), the verse's BHSA atoms (ketiv side) and the
        atom's index among them, for aligning other texts' atoms with it later."""
        book, ch, v = atoms[aid]["ref"]
        ids = verse_atoms[atoms[aid]["ref"]]
        return {"osis": C.OSIS_FROM_BHSA[book], "ch": ch, "v": v,
                "verse_atoms": [atoms[i]["text"] for i in ids], "index": ids.index(aid)}

    def context(aid):
        ids = verse_atoms[atoms[aid]["ref"]]
        j = ids.index(aid)
        lo, hi = max(0, j - WINDOW), min(len(ids), j + WINDOW + 1)
        parts = []
        for i in ids[lo:hi]:
            t = show(atoms[i]["text"])
            parts.append("[%s]" % t if i == aid else t)
        return ("... " if lo > 0 else "") + " ".join(parts) + (" ..." if hi < len(ids) else "")

    rows = []
    # ---------------------------------------------------------------- Test A
    for g in scan["test_a"]:
        if not g["new"] or g["kind"] not in KINDS_A:
            continue
        k, a = tk(g["key"]), ta(g["analysis"])
        for aid in g["atoms"]:
            if (atoms[aid]["key"], atoms[aid]["analysis"]) != (k, a):
                raise ValueError("A%d: atom %d does not match" % (g["n"], aid))
        rows.append({
            "id": "A%d" % g["n"],
            "test": "A",
            "kind": g["kind"],
            "key_form": show(g["key"][1]),
            "languages": g["key"][0],
            "analysis": fmt(a),
            "key_counts": counts_with_examples(k, by_key[k], set(g["atoms"])),
            "atoms": [{
                "atom": aid,
                "ref": eref(atoms[aid]["ref"]),
                "bhsa": show(atoms[aid]["text"]),
                "bhsa_raw": atoms[aid]["text"],
                "mam": show(m) if m else None,
                "mam_raw": m,
                "diff": mark_diff(atoms[aid]["text"], m) if m else ["MAM's atom not aligned"],
                "wlc418": wlc418(aid),
                "context": context(aid),
                "place": place(aid),
                "slots": [slot_info(s) for s in atoms[aid]["slots"]],
            } for aid, m in zip(g["atoms"], g["mam"])],
        })
    # ---------------------------------------------------------------- Test B
    stats = Counter()
    for cls in CLASSES_B:
        for r in scan["test_b"][cls]:
            aid = r["atom"]
            if atoms[aid]["slots"] != r["slots"] or atoms[aid]["text"] != r["bhsa"]:
                raise ValueError("Test B atom %d does not match" % aid)
            by = sorted({judged[s] for s in r["slots"] if s in judged})
            if by:
                stats["%s: judged by %s" % (cls, "+".join(by))] += 1
                continue
            origin = sorted({slot_rows[s]["cls"] for s in r["slots"] if s in slot_rows}) or ["no slot-level row"]
            stats["%s: not judged, from slot-level %s" % (cls, "+".join(origin))] += 1
            kb, km = tk(r["bhsa_key"]), tk(r["mam_key"])
            own = Counter({ta(x): n for x, n in r["own"]})
            rows.append({
                "id": "B%d" % aid,
                "test": "B",
                "class": cls,
                "slot_level_origin": origin,
                "analysis": fmt(ta(r["analysis"])),
                "atoms": [{
                    "atom": aid,
                    "ref": r["ref"],
                    "bhsa": show(r["bhsa"]),
                    "bhsa_raw": r["bhsa"],
                    "mam": show(r["mam"]),
                    "mam_raw": r["mam"],
                    "diff": mark_diff(r["bhsa"], r["mam"]),
                    "wlc418": wlc418(aid),
                    "context": context(aid),
                    "place": place(aid),
                    "slots": [slot_info(s) for s in r["slots"]],
                }],
                "own": counts_with_examples(kb, own, {aid}),
                "mam_key_form": show(km[1]),
                "mam_key_counts": counts_with_examples(km, by_key[km], {aid}),
                "same_letters_and_analysis": pointings_of(aid),
            })
    print("rows gathered, %.0f s" % (time.perf_counter() - t0), flush=True)

    # ---------------------------------------------------------------- outputs
    lines = [
        "p2e candidates (scripts/p2e_select.py): %d rows" % len(rows),
        "Test A groups: %s" % json.dumps(Counter(r["kind"] for r in rows if r["test"] == "A")),
        "Test B atoms: %s" % json.dumps(dict(stats)),
        "",
    ]
    for r in rows:
        if r["test"] == "A":
            lines.append("== %s (Test A, %s) | key %s%s | this: %s" % (
                r["id"], r["kind"], r["key_form"], "" if r["languages"] == ["Hebrew"] else " " + "+".join(r["languages"]),
                r["analysis"]))
            lines.append("  key: " + "; ".join("%s x%d (%s)" % (x["analysis"], x["count"], ", ".join(x["examples"])) for x in r["key_counts"]))
        else:
            lines.append("== %s (Test B, %s, slot level %s) | this: %s" % (
                r["id"], r["class"], "+".join(r["slot_level_origin"]), r["analysis"]))
            lines.append("  own key's other atoms: " + ("; ".join("%s x%d (%s)" % (x["analysis"], x["count"], ", ".join(x["examples"])) for x in r["own"]) or "none"))
            lines.append("  MAM's key %s in the BHSA: " % r["mam_key_form"] + ("; ".join("%s x%d (%s)" % (x["analysis"], x["count"], ", ".join(x["examples"])) for x in r["mam_key_counts"]) or "none"))
            lines.append("  same letters and analysis, pointed: " + "; ".join("%s x%d (%s)" % (x["form"], x["count"], x["example"]) for x in r["same_letters_and_analysis"]))
        for at in r["atoms"]:
            lines.append("  %s | BHSA %s | MAM %s | WLC 4.18 %s" % (
                at["ref"], at["bhsa"], at["mam"],
                " ".join("%s%s" % (w["text"], " (notes %s)" % ",".join(w["notes"]) if w["notes"] else "") for w in at["wlc418"])))
            lines.append("    diff: %s" % ("; ".join(at["diff"]) or "none"))
            lines.append("    context: %s" % at["context"])
            for s in at["slots"]:
                sl = s.get("slot_level")
                lines.append("    slot %d %s | %s %s %s %s %s %s.%s.%s st=%s prs=%s '%s'%s" % (
                    s["slot"], s["g_word"], s["language"][:3], s["lex"], s["sp"], s["vs"], s["vt"],
                    s["ps"], s["nu"], s["gn"], s["st"], s["prs"], s["gloss"],
                    "" if not sl else " | slot level %s, MAM piece %s, own %s, MAM's %s" % (
                        sl["class"], sl["mam_piece"],
                        ", ".join("%s x%d" % (x, n) for x, n in sl["own"]) or "-",
                        ", ".join("%s x%d" % (x, n) for x, n in sl["mam_key"]) or "-")))
        lines.append("")
    (out / "p2e-candidates.txt").write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    (out / "p2e-candidates.json").write_text(json.dumps({"stats": dict(stats), "rows": rows}, ensure_ascii=False, indent=1),
                                             encoding="utf-8", newline="\n")
    print("\n".join(lines[:4]))
    print("done, %.0f s" % (time.perf_counter() - t0))


if __name__ == "__main__":
    main()

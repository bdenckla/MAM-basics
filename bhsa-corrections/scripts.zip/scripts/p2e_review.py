"""Slice p2e: the judgments of the atom-level rows that no slice had judged, and their page.

Throwaway scratch for the brief
C:/Users/BenDe/GitRepos/MAM-basics/.novc/commander-session/bhsa-corrections-brief-2026-11-13.md,
written by a sub-agent (slice p2e) of the session that wrote ../README.md. No existing file is
edited.

Usage (from the MAM-basics root): python -I p2e_review.py <this folder>

Reads out/p2e-candidates.json (scripts/p2e_select.py). JUDGMENTS holds a category, a homograph's
kind and a reason for every row: A<n> is Test A's group n of out/p2d-scan.json, B<id> Test B's
atom id. For the another-word and unsure rows the page adds evidence: the BHSA's slots of the
lexemes by pointing, and the atom in the five texts that scripts/show_texts.py prints (WLC 4.18,
WLC 4.20, UXLC 2.6, MAM, the BHSA). Writes out/p2e-review.md and out/p2e-review.json.
"""

import json
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402

CATEGORIES = ("another-word", "follows-pointing", "no-word", "variant", "homograph", "artifact", "unsure")
AW, FP, NW, VA, HO, AR, UN = CATEGORIES
HOMOGRAPH_KINDS = {
    "name": "a name against a common noun",
    "lexeme": "two of the ETCBC's lexemes of one spelling (numbered homonyms or a split lexeme)",
    "form": "two forms or parts of speech spelled alike",
    "article": "with or without the article",
}
SHORT_FROM_OSIS = {s.replace(" ", ""): s for s in C.ib_review.SHORT.values()}

# Reasons shared by several rows.
HATAF_SHEVA = "A ḥataf pataḥ under the %s for MAM's vocal sheva: a ḥataf for a vocal sheva, the same word."
DROP_DAGESH = ("No dagesh forte in the %s, which has sheva, after %s, where MAM has one: a dagesh forte "
               "that a letter with sheva may lack%s.")
NO_DAGESH_FULL = "No dagesh forte in the %s, which has %s, after %s, where MAM has one; spells no other word%s."
WAYQ = ("No dagesh forte in the yod of the wayyiqtol's prefix after the conjunction's pataḥ, where MAM has one; "
        "the conjunction marks the tense, and the analysis reads the regular wayyiqtol (WLC 4.18 has the "
        "BHSA's, with note 1). One of the four slot-level mam-elsewhere artifacts of out/p2d-review.md.")
UZZIAH = ("No dagesh forte in the zayin of Uzziah, which the qubuts before it needs and MAM has, as p2c judged "
          "1 Chronicles 11:44's Uzzia; the BHSA has this name so at 2 other words (slot level).")
ISSACHAR = ("No dagesh forte in the first sin of Issachar, which MAM has; the BHSA has the name so at 13 other "
            "words (slot level), against 29 with MAM's dagesh.")
HATAF_CLOSED = ("A ḥataf pataḥ under the ḥet before the doubled lamed, whose doubling closes the syllable, where "
                "MAM has a full pataḥ; p2c judges such a ḥataf no-word, p2b a variant, and neither makes it a "
                "correction.")
DAGESH_LENE = ("No dagesh lene in the %s that begins the atom, which %s, after an atom ending in %s: a dagesh lene "
               "that depends on the atom before.")
CONJ_DAGESH_MAM = ("No dagesh in the %s that begins the atom, where MAM has the conjunctive dagesh after %s: a "
                   "dagesh that depends on the atom before.")
INTERROG_SHEVA = "A sheva under the interrogative he for MAM's ḥataf pataḥ: a sheva for a ḥataf%s."
INTERROG_FULL = ("The interrogative he with pataḥ for MAM's ḥataf pataḥ: a full vowel for a ḥataf under a "
                 "guttural; with no dagesh after it, it cannot be the article.")

JUDGMENTS = {
    # ------------------------------------------------------------ Test A, lexeme
    "A5": (HO, "name", "The name Shem (`CM=/`) and the noun 'name' (`CM/`, 89 atoms with the conjunction) are "
           "pointed alike; the verse lists Noah's sons."),
    "A6": (HO, "name", "The place name Salem and the adjective 'complete' (`CLM=/`, 17 atoms) are pointed alike; "
           "here 'king of Salem'."),
    "A10": (HO, "form", "The short qal perfect of `XJH[` 'be alive' and the adjective 'alive' (`XJ/`, 21 atoms) "
            "are pointed alike; here 'which he lived', of Abraham's years."),
    "A18": (HO, "lexeme", "The ETCBC's `<D==/` 'prey' and the preposition 'until' (`<D`) are pointed alike; here "
            "'devours prey' and 'prey of great spoil'."),
    "A25": (HO, "name", "The place name Elim and the plural of 'ram' spelled without the yod of its ending "
            "(`>JL=/`, 25 atoms) are pointed alike; here 'between Elim and Sinai'."),
    "A26": (HO, "form", "The qal perfect third feminine singular of `R<<[` 'be evil' and the noun 'evil' "
            "(`R<H/`) or the adjective (`R</`) are pointed alike, accents aside; here 'if she displeases her "
            "master'."),
    "A28": (HO, "form", "The adjective 'unclean' (`VM>/`) and the stative verb's perfect (`VM>[`, 22 atoms with "
            "the conjunction) are pointed alike; here the cry 'unclean' and 'the uncircumcised and the "
            "unclean'."),
    "A31": (HO, "form", "As at A28, the other way: here the verb, 'because his consecration was defiled'."),
    "A34": (AW, "", "The pointing is the feminine pronoun 'you' (`>T=`), which the BHSA gives the other 32 "
            "atoms of this pointing; the analysis is the masculine `>TH`, by context: Moses addresses God "
            "(Numbers 11:15), God the prince of Tyre (Ezekiel 28:14). The BHSA has no qere at either place; "
            "where it has the ketiv's two letters with the masculine's qere, at 5 places, it analyses the "
            "masculine too (out/p2e-checks.txt, part 5). A correction of gender by context."),
    "A35": (HO, "form", "The noun 'nose, anger' (`>P/`, construct) and the particle 'also' (`>P`, 23 atoms "
            "with the conjunction) are pointed alike; here 'the anger of the LORD' and 'the anger of God'."),
    "A38": (HO, "form", "Before a he, the interrogative he and the article both have pataḥ; here the question "
            "'has he said, and will he not do it?'."),
    "A40": (AW, "", "As at A34, with the conjunction: the pointing is the feminine pronoun, which the BHSA gives "
            "the other 12 atoms of this pointing (`W + >T=`); the analysis is the masculine, the people "
            "addressing Moses."),
    "A44": (HO, "lexeme", "The ETCBC's second lexeme `CWB=[` (its gloss 'gather'), used with 'fortunes', and "
            "`CWB[` 'return' (29 atoms with the conjunction) are pointed alike."),
    "A54": (HO, "form", "The feminine participle 'going up' (`<LH[`) and the noun 'burnt offering' (`<LH/`, 61 "
            "atoms), each with the article, are pointed alike; here 'the highway that goes up' and the spirit "
            "'that goes upward'."),
    "A73": (HO, "lexeme", "The ETCBC's lexemes `QYH/` (14 atoms) and `QYWT/`, both glossed 'end', have this "
            "plural construct alike; which of the two an atom gets is the ETCBC's lexicography, not its "
            "pointing."),
    "A76": (HO, "name", "The place name Adamah and the noun 'ground' (`>DMH/`, 111 atoms with the article) are "
            "pointed alike; the BHSA takes the place name at both verses, 'the ford of Adamah', where they are "
            "also read 'the clay ground'."),
    "A82": (HO, "name", "The place name Sela and the noun 'rock' (`SL</`, 11 atoms with the article) are "
            "pointed alike; here 'he took Sela'."),
    "A85": (HO, "form", "The long form of 'to you' and the imperative 'go' (`HLK[`, 26 atoms) are pointed alike; "
            "here 'you have a cloak'."),
    "A87": (HO, "name", "'My princes' (`FR/` with suffix `J`) and the name Sarai (`FRJ/`, 13 atoms) are pointed "
            "alike; here 'are not my princes all kings?'."),
    "A99": (HO, "form", "The participle of `RJB[` 'contend' and the adjective 'much' (`RB/`, 47 atoms) are "
            "pointed alike; here 'him who strives with his maker' and 'I am pleading your cause'."),
    "A104": (HO, "lexeme", "The ETCBC's homonyms `XJH/` 'animal' (31 atoms) and `XJH==/` 'life' are pointed "
             "alike."),
    "A108": (HO, "form", "The qal infinitive of `JD<[` 'know' and the noun 'knowledge' (`D<T/`, 11 atoms) are "
             "pointed alike; here with an object, 'they refuse to know me'."),
    "A120": (HO, "form", "'Their day' (`JWM/` with suffix `M`) and the adverb 'by day' (`JWMM`, 47 atoms) are "
             "pointed alike; here 'their day has come'."),
    "A125": (HO, "name", "The noun 'big tree' (`>LH/`) and the name Elah (`>LH===/`, 12 atoms) are pointed "
             "alike; here 'under every leafy terebinth'."),
    "A126": (HO, "name", "The feminine participle 'lofty' (`RWM[`) and the place name Ramah (`RMH==/`, 12 "
             "atoms), each with the article, are pointed alike; here 'the lofty cedar'."),
    "A131": (HO, "form", "The construct of 'reed' (`QNH/`) and the imperative 'buy' (`QNH[`, 12 atoms) are "
             "pointed alike; here 'a measuring reed'."),
    "A132": (HO, "lexeme", "The ETCBC's homonyms `>JL=/` 'ram' (16 atoms) and `>JL===/` 'pillar' are pointed "
             "alike; here the gate's pillars."),
    "A136": (HO, "form", "The noun 'height' (`<L=/`) and the preposition 'upon' (`<L`, 3476 atoms) are pointed "
             "alike; here after a preposition, 'they call him upward'."),
    "A140": (HO, "name", "The noun 'date-palm' (`TMR/`) and the name Tamar (`TMR===/`, 16 atoms) are pointed "
             "alike; here in a list of trees."),
    "A142": (HO, "lexeme", "The ETCBC's homonyms `R>C/` 'head' (23 atoms with the preposition) and `R>C=/` "
             "'poison' are pointed alike; here 'you have turned justice into poison'."),
    "A156": (HO, "form", "The noun 'integrity' (`TM=/`) and the qal infinitive of `TMM[` (11 atoms) are pointed "
             "alike; here 'integrity and uprightness'."),
    "A157": (HO, "lexeme", "The ETCBC's homonyms `<Z/` 'power' (32 atoms) and `<Z=/` 'protection' are pointed "
             "alike."),
    "A174": (HO, "lexeme", "As at A44: `CWB=[` with 'fortunes', pointed as `CWB[` 'return' is (33 atoms)."),
    "A177": (HO, "name", "The noun 'fondling' (`>MWN=/`) and the name Amon (`>MWN==/`, 16 atoms) are pointed "
             "alike; here Wisdom 'beside him'."),
    "A179": (HO, "lexeme", "The ETCBC's homonyms `>LP=/` 'thousand' (119 atoms) and `>LP/` 'cattle' are pointed "
             "alike; here 'where there are no oxen'."),
    "A184": (HO, "form", "The adjective 'full' (`ML>/`) and the participle of `ML>[` (18 atoms) are pointed "
             "alike; here 'I went away full'."),
    "A185": (HO, "lexeme", "The ETCBC's homonyms `CC/` 'six' (83 atoms), `CC=/` 'linen' (16) and `CC==/` "
             "'alabaster' are pointed alike; here 'pillars of alabaster'."),
    "A187": (HO, "name", "The noun 'account' (`XCBWN/`) and the place name Heshbon (`XCBWN==/`, 23 atoms) are "
             "pointed alike; here 'to find the account'."),
    "A189": (HO, "name", "The noun 'linen' (`XWR/`) and the name Hur (`XWR=/`, 11 atoms) are pointed alike; "
             "here in a list of fabrics."),
    "A197": (HO, "name", "The name Jamin and the noun 'right hand' (`JMJN/`, 21 atoms) are pointed alike; here "
             "in a list of names."),
    "A198": (HO, "form", "The plural construct of 'leafage' (`<LH=/`) and the poetic preposition 'upon' (`<L`, "
             "38 atoms) are pointed alike; here 'olive branches'."),
    "A207": (HO, "name", "The name Abdi and 'my servant' (`<BD/` with suffix `J`, 52 atoms) are pointed alike; "
             "here in genealogies."),
    "A208": (HO, "name", "The place name Ashan and the noun 'smoke' (`<CN/`, 12 atoms) are pointed alike; here "
             "in a list of towns."),
    "A216": (HO, "form", "The short demonstrative 'these' (`>L===`) and 'God' (`>L/`, 162 atoms) are pointed "
             "alike; here 'these were born to the giant'."),
    # ------------------------------------------------------------ Test A, stem/tense
    "A11": (HO, "form", "The niphal perfect third feminine singular and the qal cohortative first plural of "
            "`KRT[` are pointed alike; here 'let us make a covenant'."),
    "A36": (HO, "form", "As at A11, for `NTN[`: here 'let us appoint a head'."),
    "A41": (HO, "form", "The qal infinitive construct and the imperative of `CMR[` (11 atoms) are pointed alike; "
            "here after 'so as not to'."),
    "A58": (HO, "form", "The qal passive participle of `FJM[` 'put', its imperative (23 atoms) and its "
            "infinitive are pointed alike; the BHSA reads 'set' at both verses: what is left, 'set before "
            "you', and a nest 'set among the stars'."),
    "A78": (HO, "form", "After a preposition the hiphil infinitive can lack its he, and then it is pointed as "
            "the qal infinitive is (18 atoms); the BHSA reads 'until the offering up of the oblation'."),
    "A145": (HO, "form", "The stative verb's perfect (28 atoms) and its participle (`XPY[`) are pointed alike; "
             "here 'he delights in mercy' and 'a God who delights in wickedness'."),
    "A149": (HO, "form", "The infinitive with suffix `J` and the feminine imperative of `QWM[` (14 atoms) are "
             "pointed alike; here 'the day of my rising'."),
    # ------------------------------------------------------------ Test A, segmentation
    "A43": (AW, "", "The BHSA's letters have a yod after the second tsere, which MAM's lack. So pointed, the "
            "atom is 'from' and 'nothing' (`MN + >JN/`), the BHSA's analysis of the other 26 atoms of this "
            "pointing; the analysis is the one word that MAM's letters spell, the piel perfect 'refuses' "
            "(`M>N[`), which the BHSA has without the yod at 4 other words (out/p2e-checks.txt, part 4): it "
            "takes the yod for a vowel letter. WLC 4.18, WLC 4.20 and UXLC 2.6 have the yod. Test B skips the "
            "atom, its letters differing from MAM's."),
    "A192": (HO, "article", "Before a ḥataf pataḥ the preposition has pataḥ with or without the article, so the "
             "pointing spells 'with trumpets', the analysis of the other 13 atoms of this pointing, and 'with "
             "the trumpets', this analysis, alike."),
    "A222": (HO, "article", "Before a stressed monosyllable in a paired phrase the qamats under the preposition "
             "can be its vowel, with no article: here 'from city to city', whose first atom has no article, as "
             "the BHSA reads 'from gate to gate' at Exodus 32:27 and 'from generation to generation' at "
             "Isaiah 34:10 (out/p2e-checks.txt, part 2). The other 25 atoms of this pointing have the "
             "article."),
    # ------------------------------------------------------------ Test B, mam-unique
    "B4762": (NW, "", "No dagesh forte in the tsadi after the article, where MAM has one; with pataḥ and no "
              "dagesh the he is not the interrogative either, and the analysis reads the article and 'bird' "
              "(`YPWR/`) through it (WLC 4.18 has the BHSA's, with note 1). One of the four slot-level "
              "mam-elsewhere artifacts of out/p2d-review.md."),
    "B11268": (NW, "", "A dagesh in the preposition's lamed at the start of the atom, which MAM lacks, after an "
               "atom with tipeḥa, a disjunctive accent, where the rules of the conjunctive dagesh give none; "
               "spells no other word (WLC 4.18 has it, with note 1)."),
    "B12313": (NW, "", "No dagesh forte in the mem after the article, where MAM has one, as the BHSA has it "
               "twice in the next verse; spells no other word (WLC 4.18 has the BHSA's, with note 1)."),
    "B15635": (NW, "", "No dagesh forte in the tet after the article, where MAM has one, as the BHSA has it at "
               "its 5 other atoms of this analysis (as at Genesis 37:36); spells no other word (WLC 4.18 note "
               "1)."),
    "B16215": (NW, "", "The article has qamats and the shin no dagesh forte, where MAM has pataḥ and the "
               "dagesh; the article has qamats instead of a dagesh only before a guttural or resh, and the "
               "verse's other atom of this noun has pataḥ (WLC 4.18 has the BHSA's, with note 1)."),
    "B20938": (NW, "", WAYQ),
    "B32091": (NW, "", "The conjunction has pataḥ, its vowel before a ḥataf pataḥ, but the ḥet after it has a "
               "full pataḥ, before which the conjunction has sheva, as MAM's atom has; outside the wayyiqtol "
               "the BHSA has the conjunction with pataḥ before a guttural with a full pataḥ only here, at "
               "Numbers 16:21 and at Daniel 5:12 (out/p2e-checks.txt, part 3)."),
    "B36526": (VA, "", DROP_DAGESH % ("lamed", "the preposition `MN`", "")),
    "B49943": (NW, "", "A sheva under the conjunction's vav before mem, where the rule gives a shuruq, as MAM "
               "has (the review's case 5, Part 1's class c)."),
    "B57361": (NW, "", "No sheva in the final kaf, which MAM has (WLC 4.18 has the BHSA's, with note 1)."),
    "B60481": (VA, "", HATAF_SHEVA % "resh"),
    "B60987": (NW, "", "A qubuts under the resh as well as the shuruq after the alef, where MAM has no vowel "
               "under the resh and a rafeh on the alef: two vowels for one syllable, as p2c judged the same "
               "pattern at Job 31:7 (the review's case 6, Part 1's class c; WLC 4.18 note 1)."),
    "B67025": (NW, "", "As at Numbers 26:7 (the review's case 9, Part 1's class c; WLC 4.18 note U)."),
    "B95325": (VA, "", DAGESH_LENE % ("bet", "MAM has", "a vowel")),
    "B95348": (VA, "", "A sheva under the final tav of the second feminine singular perfect, which MAM lacks; "
               "it marks the feminine ending, and the word is the same (WLC 4.18 has it, with note U)."),
    "B111052": (VA, "", HATAF_SHEVA % "lamed"),
    "B114192": (NW, "", "A dagesh in the dalet after the preposition's vocal sheva, where neither a dagesh "
                "lene nor the piel's doubling, which is in the bet, belongs; WLC 4.18 and MAM lack it."),
    "B114276": (NW, "", WAYQ),
    "B119492": (VA, "", "The compound name in two parts joined by a maqaf, where MAM has one atom: the same "
                "name, divided."),
    "B119742": (NW, "", "A ḥiriq under the preposition before a letter with a full vowel, where the rule gives "
                "sheva, as WLC 4.18 and MAM have; the verse's earlier 'before your father' has the ḥiriq of "
                "the construct."),
    "B126114": (NW, "", ISSACHAR),
    "B135147": (VA, "", INTERROG_SHEVA % "; the BHSA's interrogative he has sheva at 2 other words (slot level)"),
    "B135837": (VA, "", DROP_DAGESH % ("zayin", "the article", " (WLC 4.18 note 1)")),
    "B136611": (NW, "", "A sheva under the conjunction's vav and no vowel under the name's yod, where the rule "
                "gives the vav a ḥiriq, as MAM has; spells no other word (WLC 4.18 note 1)."),
    "B137860": (NW, "", "No sheva in the final kaf, which MAM has."),
    "B140816": (NW, "", "No sheva in the final kaf, which MAM has (WLC 4.18 note 1)."),
    "B144095": (NW, "", UZZIAH),
    "B144293": (VA, "", DROP_DAGESH % ("yod", "the article", "")),
    "B153887": (NW, "", "No furtive pataḥ under the final ḥet, which MAM has."),
    "B157860": (VA, "", DROP_DAGESH % ("qof", "the article", "")),
    "B158377": (NW, "", NO_DAGESH_FULL % ("yod", "qamats", "the preposition `MN`", " (WLC 4.18 note 1)")),
    "B164844": (VA, "", "As at Judges 11:35: a sheva under the final tav of the second feminine singular "
                "perfect (WLC 4.18 note 1)."),
    "B185728": (NW, "", "No vowel under the preposition's lamed, where WLC 4.18 and MAM have ḥiriq."),
    "B188595": (VA, "", CONJ_DAGESH_MAM % ("shin", "an atom with merkha ending in qamats")),
    "B191270": (VA, "", "Jerusalem without the orphaned ḥiriq of the implicit yod, which MAM and WLC 4.18 have "
                "(WLC's note v); most of the BHSA's words of this analysis have it."),
    "B191748": (NW, "", NO_DAGESH_FULL % ("nun", "ḥiriq", "the article", " (WLC 4.18 note 1)")),
    "B193102": (NW, "", "A ḥiriq under the conjunction's vav before a nun with ḥiriq, where the rule gives "
                "sheva, as MAM and WLC 4.18 have (WLC's note v)."),
    "B194351": (NW, "", "A dagesh in the preposition's lamed at the start of the atom, which MAM lacks, after an "
                "atom with pashta, a disjunctive accent, where the rules of the conjunctive dagesh give none "
                "(WLC 4.18 has it)."),
    "B208609": (NW, "", "Qamats under the wayyiqtol's conjunction before the prefix's yod with dagesh, where the "
                "rule gives pataḥ, as MAM has. The analysis's lexeme, `FWR[` (gloss '<uncertain>'), is one of "
                "the two that the BHSA gives MAM's pointing: `FWR[` at 1 Chronicles 20:3, `FRR[` at Judges "
                "9:22."),
    "B209170": (NW, "", NO_DAGESH_FULL % ("shin", "pataḥ", "the preposition `MN`", " (WLC 4.18 note U)")),
    "B212015": (VA, "", "A dagesh in the samekh that begins the atom, which MAM lacks, after an atom joined to "
                "it by maqaf: a conjunctive dagesh, which depends on the atom before (WLC 4.18 has it)."),
    "B212655": (NW, "", "The conjunction's vav has a shuruq dot and a ḥiriq, where MAM has a shuruq (the "
                "review's case 31, Part 1's class c; WLC 4.18 note U)."),
    "B217248": (VA, "", "Jerusalem without the orphaned ḥiriq of the implicit yod, which MAM has (the review's "
                "case 32, Part 1's class c; WLC 4.18 note U)."),
    "B232471": (VA, "", HATAF_SHEVA % "preposition's lamed"),
    "B240515": (VA, "", DAGESH_LENE % ("bet", "MAM has", "a vowel")),
    "B242039": (NW, "", WAYQ),
    "B250288": (VA, "", "Qamats under the tet, the vowel of the noun's pausal form, which the BHSA has at 4 "
                "other words of this noun (as at Isaiah 34:2 and Ezekiel 21:20), where MAM has the contextual "
                "segol; here the atom has munaḥ, a conjunctive accent, so the vowel is unexpected (WLC 4.18 has "
                "the BHSA's, with note U). The qal perfect of `VBX[` would be pointed alike, but the BHSA has "
                "no such word, and the context wants the noun (out/p2e-checks.txt, part 1)."),
    "B257311": (NW, "", HATAF_CLOSED),
    "B263747": (NW, "", "No furtive pataḥ under the final ḥet, which MAM has (WLC 4.18 note U)."),
    "B269698": (NW, "", "A sheva under the conjunction's vav before pe, where the rule gives a shuruq, as MAM "
                "has (Aramaic; the review's case 41, Part 1's class c)."),
    "B290458": (NW, "", ISSACHAR),
    "B304199": (VA, "", HATAF_SHEVA % "first resh"),
    # ------------------------------------------------------------ Test B, neither
    "B9969": (VA, "", HATAF_SHEVA % "resh"),
    "B10335": (VA, "", HATAF_SHEVA % "resh"),
    "B12607": (NW, "", "A ḥiriq under the conjunction's vav before a shin with sheva, where the rule gives a "
               "shuruq, as MAM has (the review's case 1, Part 1's class c; WLC 4.18 note 1)."),
    "B19615": (VA, "", HATAF_SHEVA % "resh"),
    "B52248": (VA, "", HATAF_SHEVA % "resh"),
    "B67849": (VA, "", DROP_DAGESH % ("lamed", "the preposition `MN`", " (WLC 4.18 note U)")),
    "B76818": (VA, "", "The article has qamats before the ayin, its usual vowel there, where MAM has pataḥ."),
    "B78808": (VA, "", "The interrogative he as a separate atom, with ḥataf pataḥ, its vowel before the "
               "next atom's pataḥ, and a maqaf; MAM's atom has pataḥ, its vowel before the sheva of MAM's next "
               "atom. Both are the interrogative."),
    "B78809": (VA, "", "Pataḥ under the preposition and a sheva under the divine name's yod, a sheva that the "
               "BHSA's 572 other atoms of this analysis with that pataḥ lack (as at Genesis 4:3); MAM's atom "
               "has a sheva under the preposition, the same sheva under the yod and a ḥolam on the he. Both are "
               "the preposition with the divine name."),
    "B104213": (VA, "", HATAF_SHEVA % "resh"),
    "B105206": (VA, "", "The compound name in two parts joined by a maqaf, where MAM has one atom: the same "
                "name, divided."),
    "B121506": (VA, "", DAGESH_LENE % ("bet", "WLC 4.18 and MAM have", "a consonant")),
    "B143798": (NW, "", UZZIAH),
    "B152607": (VA, "", "The preposition `MN` has tsere before the resh, its usual vowel there, where MAM has "
                "ḥiriq."),
    "B154111": (VA, "", CONJ_DAGESH_MAM % ("mem", "'what' joined by maqaf")),
    "B154114": (VA, "", CONJ_DAGESH_MAM % ("mem", "'what' joined by maqaf")),
    "B156861": (HO, "form", "The second masculine and third feminine singular are pointed alike; the subject is "
                "'a sword', feminine, and the BHSA's other 5 atoms of this pointing are second masculine (as at "
                "Numbers 18:10). The ḥataf pataḥ under the kaf, where MAM has sheva, is the BHSA's pointing of "
                "those 5 atoms too. out/p2d-review.md lists this atom among Test B's departures in person, "
                "number, gender or suffix."),
    "B166062": (FP, "", "The noun 'month' (`XDC=/`), which the ḥataf qamats spells; MAM's ḥataf pataḥ spells "
                "the adjective 'new' (`XDC/`), which the BHSA gives the verse's other atom of that root (the "
                "review's case 25, Part 1's class a)."),
    "B169391": (VA, "", "The interrogative he and the divine name, without the ḥolam on the he that MAM's atom "
                "has."),
    "B169418": (VA, "", "The interrogative he with pataḥ before a letter with ḥataf qamats, without the dagesh "
                "that MAM's atom has after it; that dagesh is optional after the interrogative, and without it "
                "the atom cannot have the article, so the pointing spells the analysis."),
    "B178161": (VA, "", DROP_DAGESH % ("qof", "the preposition `MN`", "")),
    "B195406": (NW, "", "No mappiq in the final he, which has a furtive pataḥ, a vowel that only a consonant "
                "has; MAM has the mappiq (WLC 4.18 note 1)."),
    "B195815": (NW, "", NO_DAGESH_FULL % ("shin", "pataḥ", "the preposition `MN`", "")),
    "B196336": (VA, "", DAGESH_LENE % ("tav", "MAM has", "a consonant") + " WLC 4.18 lacks it too."),
    "B197674": (VA, "", DAGESH_LENE % ("bet", "MAM has", "a consonant")),
    "B199639": (VA, "", "A dagesh forte in the gimel, which has sheva, after the preposition `MN`, which MAM and "
                "WLC 4.18 lack: a dagesh forte that a letter with sheva may have or lack."),
    "B203044": (NW, "", HATAF_CLOSED),
    "B206999": (NW, "", "The conjunction's vav has a shuruq dot and a ḥiriq, where MAM has a shuruq (the "
                "review's case 29, Part 1's class c; WLC 4.18 note U)."),
    "B209394": (NW, "", "A sheva under the preposition before a bet with sheva, two sheva marks in a row, where "
                "the rule gives the preposition ḥiriq, as MAM has (the review's case 30, Part 1's class c; WLC "
                "4.18 note U)."),
    "B209651": (VA, "", HATAF_SHEVA % "mem"),
    "B218909": (VA, "", CONJ_DAGESH_MAM % ("yod", "'and how' joined by maqaf")),
    "B223241": (VA, "", DAGESH_LENE % ("bet", "WLC 4.18 and MAM have", "a vowel")),
    "B224820": (VA, "", HATAF_SHEVA % "resh"),
    "B236945": (VA, "", CONJ_DAGESH_MAM % ("sin", "an atom ending in qamats")),
    "B241402": (NW, "", "No mappiq in the final he, which has a furtive pataḥ, a vowel that only a consonant "
                "has; MAM has the mappiq."),
    "B245426": (VA, "", INTERROG_FULL),
    "B247140": (VA, "", INTERROG_FULL),
    "B247316": (NW, "", "A sheva under the conjunction's vav before the preposition's sheva, two sheva marks in "
                "a row, where the rule gives a shuruq, as WLC 4.18 and MAM have."),
    "B247812": (VA, "", INTERROG_SHEVA % " (WLC 4.18 note 1)"),
    "B248163": (VA, "", INTERROG_SHEVA % ""),
    "B256127": (VA, "", "No dagesh forte in the piel's qof, which has ḥataf qamats, a vocal sheva's vowel, where "
                "MAM has one: a dagesh forte that such a letter may lack (WLC 4.18 has none in the qof and one in "
                "the tet, with notes Q, n and p)."),
    "B256188": (VA, "", "No dagesh forte in the piel's qof, which has ḥataf qamats, a vocal sheva's vowel, where "
                "MAM has one: a dagesh forte that such a letter may lack."),
    "B257474": (VA, "", HATAF_SHEVA % "mem"),
    "B258854": (VA, "", "The relative particle with segol, its usual vowel before he, where MAM has sheva; both "
                "are the relative particle."),
    "B265966": (VA, "", HATAF_SHEVA % "preposition's lamed, before a second lamed,"),
    "B268467": (NW, "", "As at Exodus 29:23, in Aramaic: the conjunction has pataḥ before an alef with a full "
                "pataḥ, where MAM has sheva."),
    "B275395": (NW, "", UZZIAH),
    "B276742": (VA, "", "Ḥiriq under the second tav and a dagesh in the yod, the usual feminine plural of an "
                "adjective ending in ḥiriq and yod, where MAM has a sheva under the tav and no dagesh in the "
                "yod."),
    "B292869": (VA, "", HATAF_SHEVA % "first resh"),
    "B296463": (FP, "", "With pataḥ, the preposition before a ḥataf pataḥ has no article, and the analysis has "
                "none (`L + >CRH/`); MAM's qamats is the article's, as the BHSA analyses that pointing at "
                "1 Kings 15:13 and 2 Kings 23:7 (`L + H + >CRH/`)."),
}

# The lexemes whose spellings the evidence of an another-word row lists: (lex, {feature: value}).
EVIDENCE_LEXEMES = {
    "A34": [(">TH", {}), (">T=", {})],
    "A40": [(">TH", {}), (">T=", {})],
    "A43": [("M>N[", {"vs": "piel", "vt": "perf", "ps": "p3", "nu": "sg", "gn": "m"}), ("M>N[", {})],
}


def show(s):
    """A form for display: stripped as the review's page strips its forms, MAM-normal order."""
    return C.mnorm(C.ib_review.stripped(s))


def distinct(xs):
    out = []
    for x in xs:
        if x not in out:
            out.append(x)
    return out


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8", errors="backslashreplace")
    here = Path(sys.argv[1])
    out = here / "out"
    cand = json.loads((out / "p2e-candidates.json").read_text(encoding="utf-8"))
    rows = cand["rows"]
    ids = [r["id"] for r in rows]
    if len(set(ids)) != len(ids):
        raise ValueError("duplicate row ids")
    missing = sorted(set(ids) - set(JUDGMENTS))
    extra = sorted(set(JUDGMENTS) - set(ids))
    if missing or extra:
        raise ValueError("judgments missing for %s; judgments with no row: %s" % (missing, extra))
    for k, (cat, sub, reason) in JUDGMENTS.items():
        if cat not in CATEGORIES:
            raise ValueError("%s: unknown category %r" % (k, cat))
        if (cat == HO) != bool(sub) or (sub and sub not in HOMOGRAPH_KINDS):
            raise ValueError("%s: homograph kind %r does not fit category %r" % (k, sub, cat))
        if "\N{COMBINING DOT BELOW}" in reason or C.HEB_LETTER.search(reason):
            raise ValueError("%s: a decomposed letter or a Hebrew letter in the reason" % k)

    # ------------------------------------------------------------ evidence for another-word and unsure
    need = [r for r in rows if JUDGMENTS[r["id"]][0] in (AW, UN)]
    evidence = {}
    if need:
        B = C.Bhsa()
        lint = C.load_lint()
        w420 = C.read_wlc42x("4.20")
        english = {short.replace(" ", ""): name for name, short in C.ib_review.SHORT.items()}
        english["Eccl"] = "Ecclesiastes"

        def eref(ref):
            book, ch, v = ref
            return "%s %d:%d" % (english[C.OSIS_FROM_BHSA[book]], ch, v)

        gw, qw, lexf = B.wf("g_word_utf8"), B.wf("qere_utf8"), B.wf("lex")

        def spellings(lex, want):
            fs = {k: B.wf(k) for k in want}
            c, ex = Counter(), {}
            for s in range(1, B.max_slot + 1):
                if lexf.get(s) != lex or any(fs[k].get(s) != v for k, v in want.items()):
                    continue
                k = show(gw.get(s, ""))
                if s in qw:
                    k += " (ketiv; qere %s)" % show(qw[s])
                c[k] += 1
                ex.setdefault(k, eref(B.ref_of_slot[s]))
            return [{"form": k, "count": n, "example": ex[k]} for k, n in c.most_common()]

        def five_texts(p):
            osis, ch, v = p["osis"], p["ch"], p["v"]
            where = "%s %d:%d" % (osis, ch, v)
            texts = [
                ("WLC 4.18", [(a["text"], a["notes"]) for a in C.wlc418_side(C.read_wlc418_book(osis)[(ch, v)], "ketiv")]),
                ("WLC 4.20", [(a["text"], a["notes"]) for a in C.wlc42x_side(w420[(osis, ch, v)], "ketiv")]),
                ("UXLC 2.6", [(a["text"], a["notes"]) for a in C.wlc418_side(C.read_wlc418_book(osis, C.UXLC26_BOOKS)[(ch, v)], "ketiv")]),
                ("MAM", [(a, []) for a in C.mam_atoms(lint, SHORT_FROM_OSIS[osis], ch, v, "ketiv", "cant-combined", where)]),
            ]
            res = []
            for name, atoms in texts:
                m = C.align(p["verse_atoms"], [t for t, _ in atoms])
                res.append({"text": name, "atoms": [{"form": show(atoms[j][0]), "notes": list(atoms[j][1])} for j in m[p["index"]]]})
            res.append({"text": "BHSA", "atoms": [{"form": show(p["verse_atoms"][p["index"]]), "notes": []}]})
            return res

        for r in need:
            evidence[r["id"]] = {
                "spellings": [{"lex": lx, "filter": want, "spellings": spellings(lx, want)} for lx, want in EVIDENCE_LEXEMES.get(r["id"], [])],
                "texts": [{"ref": at["ref"], "texts": five_texts(at["place"])} for at in r["atoms"]],
            }

    # ------------------------------------------------------------ counts
    counts = Counter(JUDGMENTS[r["id"]][0] for r in rows)
    by_test = {
        "A groups": Counter(JUDGMENTS[r["id"]][0] for r in rows if r["test"] == "A"),
        "A atoms": Counter(),
        "B atoms": Counter(JUDGMENTS[r["id"]][0] for r in rows if r["test"] == "B"),
    }
    for r in rows:
        if r["test"] == "A":
            by_test["A atoms"][JUDGMENTS[r["id"]][0]] += len(r["atoms"])
    ho_kinds = Counter(JUDGMENTS[r["id"]][1] for r in rows if JUDGMENTS[r["id"]][0] == HO)
    ho_kinds_a = Counter(JUDGMENTS[r["id"]][1] for r in rows if r["test"] == "A" and JUDGMENTS[r["id"]][0] == HO)
    n_a = sum(1 for r in rows if r["test"] == "A")
    n_a_atoms = sum(len(r["atoms"]) for r in rows if r["test"] == "A")
    n_b = sum(1 for r in rows if r["test"] == "B")
    kinds_a = Counter(r["kind"] for r in rows if r["test"] == "A")
    origin_b = Counter((r["class"], "+".join(r["slot_level_origin"])) for r in rows if r["test"] == "B")
    neither_b = [r for r in rows if r["test"] == "B" and r["class"] == "neither"]
    neither_no_mam = sum(1 for r in neither_b if not r["mam_key_counts"])

    # ------------------------------------------------------------ the BHSA against WLC 4.18
    wlc_diffs = []
    for r in rows:
        for at in r["atoms"]:
            w = at["wlc418"]
            if len(w) != 1:
                continue
            if C.bkey(at["bhsa_raw"]).rstrip(C.MAQAF) != C.bkey(w[0]["text"]).rstrip(C.MAQAF):
                wlc_diffs.append((r["id"], at["ref"], at["bhsa"], w[0]["text"], w[0]["notes"]))

    # ------------------------------------------------------------ the page
    def cell(s):
        return s.replace("|", "\\|")

    def jl(r):
        return JUDGMENTS[r["id"]]

    L = []
    L.append("# Part 2, slice p2e: the atom-level rows that no slice had judged")
    L.append("")
    L.append("Written by Claude (Opus 5.5) on 2026-11-13, New York time, as a sub-agent of the session that wrote "
             "this folder's `README.md`, by `scripts/p2e_review.py` from `out/p2e-candidates.json` "
             "(`scripts/p2e_select.py`) and the checks in `out/p2e-checks.txt` (`scripts/p2e_checks.py`) and "
             "`out/p2e-texts.txt` (`scripts/show_texts.py`). Not reviewed by a human. Nothing tracked changed. "
             "Every form here is a transcription's, the BHSA 2021's (`g_word_utf8`), MAM's (MAM-simple, as "
             "the scan read it), WLC 4.18's, WLC 4.20's or UXLC 2.6's, emitted by script and stripped of "
             "accents as the review's page strips its forms; nothing here says what the Leningrad Codex has.")
    L.append("")
    L.append("## The answer")
    L.append("")
    L.append("| Category | Test A groups | Test A atoms | Test B atoms | All rows |")
    L.append("|---|---|---|---|---|")
    for cat in CATEGORIES:
        L.append("| %s | %d | %d | %d | %d |" % (cat, by_test["A groups"][cat], by_test["A atoms"][cat],
                                                 by_test["B atoms"][cat], counts[cat]))
    L.append("| all | %d | %d | %d | %d |" % (n_a, n_a_atoms, n_b, len(rows)))
    L.append("")
    aw = [r for r in rows if jl(r)[0] == AW]
    fp = [r for r in rows if jl(r)[0] == FP]
    L.append("1. **Test B over atoms adds no correction toward MAM.** None of its %d unjudged atoms is another-word; "
             "%d follow the BHSA's pointing where MAM's would give another analysis: %s. The rest are pointings "
             "that spell no well-formed word (%d) or variant spellings of the analysed word (%d), and one homograph "
             "of person and gender (Isaiah 31:8)."
             % (n_b, len(fp), "; ".join("%s (%s)" % (r["atoms"][0]["ref"], "the review's class a case" if r["id"] == "B166062"
                                                      else "new: the preposition's pataḥ, analysed without the article, where MAM's qamats is the article's")
                                         for r in fp),
                by_test["B atoms"][NW], by_test["B atoms"][VA]))
    L.append("2. **Of Test A's %d new groups, %d are another-word, all already raised by out/p2d-review.md for Ben's "
             "judgment:** %s. The other %d groups are homographs that context decides: %s."
             % (n_a, by_test["A groups"][AW],
                "; ".join("%s (%s, %s)" % (r["id"], "; ".join(at["ref"] for at in r["atoms"]),
                                           "the feminine pronoun's pointing analysed as the masculine" if r["id"] in ("A34", "A40")
                                           else "letters with a yod, which spell 'from nothing', analysed as 'refuses'")
                          for r in aw),
                by_test["A groups"][HO],
                "; ".join("%d %s" % (ho_kinds_a[k], v) for k, v in HOMOGRAPH_KINDS.items() if ho_kinds_a[k])))
    L.append("3. **No row is artifact or unsure.** The four slot-level mam-elsewhere artifacts (Genesis 15:10, Exodus "
             "2:10, 2 Samuel 3:32, Job 8:1) fall in this slice by its rule, since none of their slots is in p2b's or "
             "p2c's JSON; over atoms each is a missing dagesh forte, judged no-word as p2b and p2c judge the same "
             "lack.")
    L.append("")
    L.append("## The another-word rows and their evidence")
    L.append("")
    for r in aw:
        cat, sub, reason = jl(r)
        ev = evidence[r["id"]]
        L.append("### %s: %s" % (r["id"], "; ".join(at["ref"] for at in r["atoms"])))
        L.append("")
        L.append("- The BHSA's analysis: `%s`; its slots: %s." % (
            r["analysis"], "; ".join("`%s` %s '%s'" % (s["lex"], s["sp"], s["gloss"]) for s in r["atoms"][0]["slots"])))
        L.append("- The other analyses of its pointing in the BHSA (Test A's key): %s." % "; ".join(
            "`%s` x%d, as at %s" % (k["analysis"], k["count"], k["examples"][0] if k["examples"] else "-")
            for k in r["key_counts"] if k["analysis"] != r["analysis"]))
        for sp in ev["spellings"]:
            L.append("- The BHSA's slots of `%s`%s, by pointing: %s." % (
                sp["lex"], (" (%s)" % ", ".join("%s %s" % kv for kv in sp["filter"].items())) if sp["filter"] else "",
                "; ".join("%s x%d, as at %s" % (x["form"], x["count"], x["example"]) for x in sp["spellings"])))
        L.append("- Why: %s" % reason)
        L.append("")
        refs = [t["ref"] for t in ev["texts"]]
        L.append("| Text | %s |" % " | ".join(refs))
        L.append("|---|" + "---|" * len(refs))
        for i, name in enumerate(x["text"] for x in ev["texts"][0]["texts"]):
            cells = []
            for t in ev["texts"]:
                ats = t["texts"][i]["atoms"]
                cells.append(" ".join(a["form"] + (" (notes %s)" % ",".join(a["notes"]) if a["notes"] else "") for a in ats) or "-")
            L.append("| %s | %s |" % (name, " | ".join(cell(c) for c in cells)))
        L.append("")
    L.append("## The categories")
    L.append("")
    L.append("- **another-word**: the BHSA's pointing is a well-formed spelling of another word, or of another "
             "person, number, gender or suffix, attested in the BHSA, and the analysis takes it as a different one. "
             "A correction candidate.")
    L.append("- **follows-pointing**: the analysis is what the BHSA's pointing spells, while MAM's pointing would "
             "give another (Part 1's class a).")
    L.append("- **no-word**: the pointing breaks a rule that the analysed word needs and spells no other word; the "
             "analysis reads through it. Here: a dagesh forte missing from a letter with a full vowel; a missing "
             "mappiq, furtive pataḥ or final kaf's sheva; a missing vowel; a conjunction's or preposition's vowel "
             "that no rule gives; two vowels for one syllable; a ḥataf before a doubled letter (as p2c judges it; "
             "p2b calls it a variant); an atom-initial dagesh after a disjunctive accent.")
    L.append("- **variant**: a recognized spelling of the same word, MAM's and the BHSA's alike: a ḥataf for a vocal "
             "sheva or a sheva for a ḥataf; a full vowel for a ḥataf under a guttural; a dagesh forte that a letter "
             "with sheva has or lacks; an atom-initial dagesh lene or conjunctive dagesh that depends on the atom "
             "before (after a conjunctive accent or maqaf); a usual vowel before a guttural or resh where MAM has "
             "another; a compound name divided; Jerusalem without its orphaned ḥiriq; a pausal vowel.")
    L.append("- **homograph**: the same pointing is a normal spelling of both analyses, and context decides; its "
             "kinds: %s." % "; ".join("**%s**, %s" % kv for kv in HOMOGRAPH_KINDS.items()))
    L.append("- **artifact** of the test's method, and **unsure**: no row.")
    L.append("")
    L.append("Both no-word and variant say that the analysis reads the same word as MAM's pointing; they differ only in "
             "whether the BHSA's pointing is well formed, and p2b and p2c drew that line slightly differently (a ḥataf "
             "before a doubled letter). Neither is a correction.")
    L.append("")
    L.append("## Which rows")
    L.append("")
    L.append("1. **Test A over atoms (`out/p2d-test-a.txt`, `out/p2d-scan.json`), the groups marked new**, of the kinds "
             "lexeme, stem/tense and segmentation: %d groups, %d atoms (%s). p2d reviewed the 21 new ps/nu/gn/prs groups."
             % (n_a, n_a_atoms, ", ".join("%s %d" % (k, kinds_a[k]) for k in ("lexeme", "stem/tense", "segmentation"))))
    L.append("2. **Test B over atoms, classes mam-unique and neither, with no slot among the rows of "
             "`out/p2b-mam-unique.json` or `out/p2c-neither.json`**: %d atoms. By the slot-level class of their "
             "slots: %s. MAM's whole atom occurs nowhere in the BHSA at %d of the %d neither atoms."
             % (n_b, "; ".join("%s from %s %d" % (c, o, n) for (c, o), n in sorted(origin_b.items())),
                neither_no_mam, len(neither_b)))
    L.append("")
    L.append("`scripts/p2e_select.py` recomputes the atoms as `scripts/p2d_scan_atoms.py` makes them and checks every "
             "row against `out/p2d-scan.json`; `out/p2e-candidates.txt` has each row's slots, features, context, "
             "per-letter difference from MAM's atom, WLC 4.18's atom and the BHSA's other atoms of the same pointing "
             "and of the same letters and analysis.")
    L.append("")
    L.append("## Where the BHSA's atom differs from WLC 4.18's")
    L.append("")
    L.append("At %d of these %d atoms the BHSA's atom differs in pointing from WLC 4.18's aligned atom (by `bkey`, "
             "accents aside); at the 2 compound names WLC 4.18 has two atoms where the BHSA has one, which is not "
             "counted. A difference with no WLC note may be the BHSA's transcription of BHS; BHS itself was not read."
             % (len(wlc_diffs), n_a_atoms + n_b))
    L.append("")
    L.append("| # | Reference | BHSA | WLC 4.18 | WLC 4.18's notes |")
    L.append("|---|---|---|---|---|")
    for rid, ref, bh, wt, notes in wlc_diffs:
        L.append("| %s | %s | %s | %s | %s |" % (rid, ref, bh, show(wt), ", ".join(notes) or "-"))
    L.append("")
    L.append("## The rows: Test A's new groups")
    L.append("")
    L.append("A slot is `lex [vs vt] [ps.nu.gn] [+prs]`, with `-` for NA and `?` for unknown; slots are joined by ` + `.")
    L.append("")
    L.append("| # | Kind | Reference | BHSA | MAM | BHSA's analysis | The pointing's other analyses | Category | Reason |")
    L.append("|---|---|---|---|---|---|---|---|---|")
    for r in rows:
        if r["test"] != "A":
            continue
        cat, sub, reason = jl(r)
        others = [k for k in r["key_counts"] if k["analysis"] != r["analysis"]]
        L.append("| %s | %s | %s | %s | %s | `%s` | %s | **%s**%s | %s |" % (
            r["id"], r["kind"], "; ".join(at["ref"] for at in r["atoms"]),
            " / ".join(distinct(at["bhsa"] for at in r["atoms"])),
            " / ".join(distinct((at["mam"] or "(not aligned)") for at in r["atoms"])),
            cell(r["analysis"]),
            "; ".join("`%s` x%d" % (cell(k["analysis"]), k["count"]) for k in others[:3]),
            cat, (" (%s)" % sub) if sub else "", cell(reason)))
    L.append("")
    L.append("## The rows: Test B's atoms")
    L.append("")
    L.append("| # | Reference | Class (slot level) | BHSA | MAM | BHSA's analysis | Category | Reason |")
    L.append("|---|---|---|---|---|---|---|---|")
    for r in rows:
        if r["test"] != "B":
            continue
        cat, sub, reason = jl(r)
        at = r["atoms"][0]
        L.append("| %s | %s | %s (%s) | %s | %s | `%s` | **%s**%s | %s |" % (
            r["id"], at["ref"], r["class"], "+".join(r["slot_level_origin"]), at["bhsa"], at["mam"],
            cell(r["analysis"]), cat, (" (%s)" % sub) if sub else "", cell(reason)))
    L.append("")
    L.append("## Files")
    L.append("")
    L.append("- `scripts/p2e_select.py`: the selection and its evidence, `out/p2e-candidates.txt` and `.json`.")
    L.append("- `scripts/p2e_checks.py`: `out/p2e-checks.txt`, the checks that reasons cite (part 1, Proverbs 7:22 and "
             "the spellings of `VBX/`; part 2, the preposition with qamats and no article; part 3, the conjunction with "
             "pataḥ before a guttural with pataḥ; part 4, `M>N[`; part 5, `>TH` and `>T=`; part 6, the differences from "
             "WLC 4.18; part 7, accents).")
    L.append("- `scripts/show_texts.py` (not edited): `out/p2e-texts.txt`, the another-word verses in five texts.")
    L.append("- `scripts/p2e_review.py`: the judgments (`JUDGMENTS`), this page and `out/p2e-review.json`.")
    text = "\n".join(L) + "\n"
    (out / "p2e-review.md").write_text(text, encoding="utf-8", newline="\n")

    js = {
        "categories": list(CATEGORIES),
        "homograph_kinds": HOMOGRAPH_KINDS,
        "counts": {c: counts[c] for c in CATEGORIES},
        "counts_by_test": {k: {c: v[c] for c in CATEGORIES} for k, v in by_test.items()},
        "homograph_kind_counts": dict(ho_kinds),
        "rows": [{
            "id": r["id"],
            "test": r["test"],
            "kind": r.get("kind"),
            "class": r.get("class"),
            "slot_level_origin": r.get("slot_level_origin"),
            "refs": [at["ref"] for at in r["atoms"]],
            "atoms": [{"atom": at["atom"], "ref": at["ref"], "bhsa": at["bhsa"], "mam": at["mam"],
                       "wlc418": at["wlc418"], "slots": [s["slot"] for s in at["slots"]]} for at in r["atoms"]],
            "analysis": r["analysis"],
            "category": jl(r)[0],
            "homograph_kind": jl(r)[1] or None,
            "reason": jl(r)[2],
            "evidence": evidence.get(r["id"]),
        } for r in rows],
        "bhsa_differs_from_wlc418": [{"id": a, "ref": b, "bhsa": c, "wlc418": show(d), "notes": e} for a, b, c, d, e in wlc_diffs],
    }
    (out / "p2e-review.json").write_text(json.dumps(js, ensure_ascii=False, indent=1), encoding="utf-8", newline="\n")
    print("counts: %s" % json.dumps({c: counts[c] for c in CATEGORIES}))
    print("by test: %s" % json.dumps({k: {c: v[c] for c in CATEGORIES if v[c]} for k, v in by_test.items()}))
    print("homograph kinds: %s" % json.dumps(dict(ho_kinds)))
    print("WLC 4.18 differences: %d" % len(wlc_diffs))


if __name__ == "__main__":
    main()

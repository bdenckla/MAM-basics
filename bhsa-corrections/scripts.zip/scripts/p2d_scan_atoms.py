"""Part 2, slice p2d: part2_scan.py's two tests over BHSA atoms rather than slots.

Throwaway scratch for the brief
C:/Users/BenDe/GitRepos/MAM-basics/.novc/commander-session/bhsa-corrections-brief-2026-11-13.md,
written by a sub-agent of the session that wrote ../README.md. part2_scan.py is not edited.

Usage (from the MAM-basics root): python -I p2d_scan_atoms.py <this folder>

It removes two limits of part2_scan.py's first pass:

1. The unit is a BHSA atom (bc_common.Bhsa.atoms, ketiv side), not a slot, so a conjunction,
   an article or a preposition is judged with the word it is written on: a wayyiqtol's prefix
   with the conjunction's patah, a noun with the article's dagesh. Atoms that contain a slot
   with a qere are skipped, and so are atoms with no letters.
2. The analysis compared is the tuple, over the atom's slots, of (lex, vs, vt, ps, nu, gn, prs),
   not (language, lex, vs, vt).

An atom's pointed key is (the languages of its slots, as a sorted tuple of the distinct
values; bc_common.skey of the atom's text with any final maqaf stripped). The languages are a
set, not one per slot, so that the number of slots belongs to the analysis, not the key: an atom
that the BHSA cuts into slots otherwise than it cuts its pointing elsewhere is a departure of
kind "segmentation".

Support (as part2_scan.supported): an analysis is supported by a key when the key's atoms have
it at least 3 times, or at least a tenth as often as the key's commonest analysis.

Test A, independent of MAM: an atom whose analysis its own key does not support, where the key
has some analysis at least 5 times. A group is (key, analysis); its kind compares the analysis
with the key's commonest analysis: segmentation (another number of slots), lexeme (some slot's
lex differs), stem/tense (same lexemes, some vs or vt differs), or ps/nu/gn/prs (same lex, vs
and vt in every slot).

Test B, against MAM: MAM-simple's verse (BHS versification, ketiv side, combined strand of a
dual cantillation, read by the review's lint) is aligned with the BHSA's atoms by letters, as
part2_scan.py does. Where an atom has the same letters in both and the pointing differs
(bc_common.bkey, final maqaf stripped), the whole atom is classed by whether its analysis is
supported by its own key among the BHSA's other atoms and by MAM's key (MAM's atom after
holam_to_prev, skey, final maqaf stripped, with the BHSA atom's languages) among the BHSA's
atoms: mam-elsewhere, mam-unique, written, both, neither, as in part2_scan.py.

The slot-level run's results (out/32-part2-scan.json, read only) are cross-tabulated against
this run's: each slot-level Test B row and each slot-level Test A word is followed to the atom
that holds its slot.

Writes out/p2d-scan-run.txt, out/p2d-test-a.txt, out/p2d-test-b.txt and out/p2d-scan.json.
"""

import json
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402

SHORT_FROM_OSIS = {s.replace(" ", ""): s for s in C.ib_review.SHORT.values()}
FIELDS = ("lex", "vs", "vt", "ps", "nu", "gn", "prs")
CLASSES = ("mam-elsewhere", "mam-unique", "written", "both", "neither")
KINDS = ("segmentation", "lexeme", "stem/tense", "ps/nu/gn/prs")
MORPH = ("sp", "st", "g_pfm_utf8", "g_vbs_utf8", "g_vbe_utf8", "g_nme_utf8", "g_uvf_utf8", "g_prs_utf8")
NO_SUFFIX = ("absent", "n/a")


def supported(counter, a):
    """part2_scan.supported: at least 3 times, or at least a tenth of the commonest."""
    if not counter or counter[a] <= 0:
        return False
    return counter[a] >= 3 or counter[a] * 10 >= max(counter.values())


def fmt_slot(t):
    lex, vs, vt, ps, nu, gn, prs = t
    s = lex
    if (vs, vt) != ("NA", "NA"):
        s += " %s %s" % (vs, vt)
    png = (ps, nu, gn)
    if png != ("NA", "NA", "NA"):
        s += " " + ".".join({"NA": "-", "unknown": "?"}.get(x, x) for x in png)
    if prs not in NO_SUFFIX:
        s += " +" + prs
    elif prs == "n/a" and png != ("NA", "NA", "NA"):
        s += " +n/a"
    return s


def fmt(a):
    return " + ".join(fmt_slot(t) for t in a)


def fmt_key(k):
    langs, form = k
    pre = "" if langs == ("Hebrew",) else ("Aram " if langs == ("Aramaic",) else "+".join(langs) + " ")
    return pre + C.mnorm(form)


def fmt_counter(c, n=None):
    return ", ".join("%s x%d" % (fmt(a), k) for a, k in c.most_common(n)) or "-"


def kind_of(a, top):
    if len(a) != len(top):
        return "segmentation"
    if any(x[0] != y[0] for x, y in zip(a, top)):
        return "lexeme"
    if any(x[1:3] != y[1:3] for x, y in zip(a, top)):
        return "stem/tense"
    return "ps/nu/gn/prs"


def field_diffs(a, top):
    """The fields in which a departs from top, slot by slot (only for equal lengths)."""
    out = []
    for x, y in zip(a, top):
        for f, xv, yv in zip(FIELDS, x, y):
            if xv != yv:
                out.append({"lex": x[0], "field": f, "this": xv, "commonest": yv})
    return out


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8", errors="backslashreplace")
    here = Path(sys.argv[1])
    t0 = time.perf_counter()
    B = C.Bhsa()
    gw, qw = B.wf("g_word_utf8"), B.wf("qere_utf8")
    lang = B.wf("language")
    feats = [B.wf(f) for f in FIELDS]
    english = {short.replace(" ", ""): name for name, short in C.ib_review.SHORT.items()}
    english["Eccl"] = "Ecclesiastes"

    def eref(ref):
        book, ch, v = ref
        return "%s %d:%d" % (english[C.OSIS_FROM_BHSA[book]], ch, v)

    # ---------------------------------------------------------------- every atom
    stats = Counter()
    atoms = []
    atom_of_slot = {}
    verse_atoms = {}
    by_key = defaultdict(Counter)
    first_of = {}
    for ref in sorted(B.verse_slots, key=lambda r: B.verse_slots[r][0]):
        book, ch, v = ref
        osis = C.OSIS_FROM_BHSA[book]
        ids = []
        for ba in B.atoms(osis, ch, v, "ketiv"):
            aid = len(atoms)
            ids.append(aid)
            rec = {"id": aid, "ref": ref, "text": ba["text"], "slots": ba["slots"], "key": None, "analysis": None}
            atoms.append(rec)
            for s in ba["slots"]:
                atom_of_slot[s] = aid
            stats["BHSA atoms"] += 1
            if any(s in qw for s in ba["slots"]):
                stats["BHSA atoms with a qere slot, skipped"] += 1
                rec["skip"] = "qere"
                continue
            if not C.letters(ba["text"]):
                stats["BHSA atoms with no letters, skipped"] += 1
                rec["skip"] = "no letters"
                continue
            langs = tuple(sorted({lang[s] for s in ba["slots"]}))
            if len(langs) > 1:
                stats["BHSA atoms with slots of two languages"] += 1
            k = (langs, C.skey(ba["text"]).rstrip(C.MAQAF))
            a = tuple(tuple(f[s] for f in feats) for s in ba["slots"])
            rec["key"], rec["analysis"] = k, a
            by_key[k][a] += 1
            first_of.setdefault((k, a), aid)
            stats["BHSA atoms keyed"] += 1
        verse_atoms[ref] = ids
    stats["pointed keys"] = len(by_key)
    # part2_scan.py's slot-level keys, only to count how many words its Test A could judge
    slot_keys = defaultdict(Counter)
    vs_f, vt_f, lex_f = B.wf("vs"), B.wf("vt"), B.wf("lex")
    for s in range(1, B.max_slot + 1):
        w = gw.get(s, "")
        if s in qw or not C.letters(w):
            continue
        slot_keys[(lang[s], C.skey(w))][(lang[s], lex_f[s], vs_f[s], vt_f[s])] += 1
    slot_testable = sum(sum(c.values()) for c in slot_keys.values() if max(c.values()) >= 5)
    slot_keyed = sum(sum(c.values()) for c in slot_keys.values())
    del slot_keys
    print("atoms read, %.0f s" % (time.perf_counter() - t0), flush=True)

    # ---------------------------------------------------------------- MAM's atoms
    lint = C.load_lint()
    mam_found = set()
    for ref, ids in verse_atoms.items():
        book, ch, v = ref
        osis = C.OSIS_FROM_BHSA[book]
        where = "%s %d:%d" % (osis, ch, v)
        try:
            mam = C.mam_atoms(lint, SHORT_FROM_OSIS[osis], ch, v, "ketiv", "cant-combined", where)
        except AssertionError:
            stats["verses missing in MAM-simple"] += 1
            continue
        mam_found.add(ref)
        to_mam = C.align([atoms[i]["text"] for i in ids], mam)
        for j, aid in enumerate(ids):
            js = to_mam[j]
            if len(js) == 1 and C.letters(mam[js[0]]) == C.letters(atoms[aid]["text"]):
                atoms[aid]["mam"] = mam[js[0]]
    print("MAM aligned, %.0f s" % (time.perf_counter() - t0), flush=True)

    # ---------------------------------------------------------------- test A
    testable = 0
    flagged = defaultdict(list)
    for rec in atoms:
        k, a = rec["key"], rec["analysis"]
        if k is None:
            continue
        c = by_key[k]
        if max(c.values()) < 5:
            continue
        testable += 1
        if not supported(c, a):
            flagged[(k, a)].append(rec["id"])
    stats["test A: atoms whose key has some analysis at least 5 times"] = testable
    groups_a = []
    kinds_atoms, kinds_groups = Counter(), Counter()
    for (k, a), ids in sorted(flagged.items(), key=lambda kv: kv[1][0]):
        top = by_key[k].most_common(1)[0][0]
        kind = kind_of(a, top)
        kinds_atoms[kind] += len(ids)
        kinds_groups[kind] += 1
        g = {
            "n": len(groups_a) + 1,
            "kind": kind,
            "key": k,
            "analysis": a,
            "atoms": ids,
            "refs": [eref(atoms[i]["ref"]) for i in ids],
            "key_counts": by_key[k].most_common(),
            "commonest": top,
            "commonest_ref": eref(atoms[first_of[(k, top)]]["ref"]),
            "commonest_atom": first_of[(k, top)],
            "mam": [atoms[i].get("mam") for i in ids],
        }
        if kind == "ps/nu/gn/prs":
            g["diffs"] = field_diffs(a, top)
        groups_a.append(g)
    stats["test A: atoms flagged"] = sum(kinds_atoms.values())
    stats["test A: groups"] = len(groups_a)

    # morphology of the ps/nu/gn/prs groups' atoms and of a commonest-analysis atom of their key
    morph = {f: B.wf(f) for f in MORPH}

    def slot_morph(s):
        return {"slot": s, "g_word_utf8": gw.get(s, ""), **{f: morph[f].get(s, "") for f in MORPH}}

    for g in groups_a:
        if g["kind"] == "ps/nu/gn/prs":
            g["morph"] = [slot_morph(s) for s in atoms[g["atoms"][0]]["slots"]]
            g["commonest_morph"] = [slot_morph(s) for s in atoms[g["commonest_atom"]]["slots"]]

    # ---------------------------------------------------------------- test B
    stats_b = Counter()
    rows_b = defaultdict(list)
    class_of_atom = {}
    for ref, ids in verse_atoms.items():
        if ref not in mam_found:
            continue
        for aid in ids:
            rec = atoms[aid]
            stats_b["atoms"] += 1
            if rec.get("skip") == "qere":
                stats_b["atoms with a ketiv, skipped"] += 1
                class_of_atom[aid] = "skipped: ketiv"
                continue
            if "mam" not in rec:
                stats_b["atoms whose letters differ from MAM's, skipped"] += 1
                class_of_atom[aid] = "skipped: letters differ"
                continue
            if rec.get("skip"):
                stats_b["atoms with no letters, skipped"] += 1
                class_of_atom[aid] = "skipped: no letters"
                continue
            m = rec["mam"]
            if C.bkey(m).rstrip(C.MAQAF) == C.bkey(rec["text"]).rstrip(C.MAQAF):
                class_of_atom[aid] = "same pointing"
                continue
            stats_b["atoms whose pointing differs from MAM's"] += 1
            kb = rec["key"]
            km = (kb[0], C.bkey(m).rstrip(C.MAQAF))
            if kb == km:
                stats_b["atoms whose keys are equal after all"] += 1
                class_of_atom[aid] = "keys equal"
                rows_b["keys equal"].append({"atom": aid, "ref": eref(ref), "bhsa": rec["text"], "mam": m})
                continue
            a = rec["analysis"]
            own = Counter(by_key[kb])
            own[a] -= 1
            own = +own
            theirs = by_key[km]
            cls = {
                (False, True): "mam-elsewhere" if own else "mam-unique",
                (True, False): "written",
                (True, True): "both",
                (False, False): "neither",
            }[(supported(own, a), supported(theirs, a))]
            stats_b["atoms: " + cls] += 1
            class_of_atom[aid] = cls
            rows_b[cls].append({
                "atom": aid,
                "slots": rec["slots"],
                "ref": eref(ref),
                "bhsa": rec["text"],
                "mam": m,
                "bhsa_key": kb,
                "mam_key": km,
                "analysis": a,
                "own": own.most_common(),
                "mam_key_counts": theirs.most_common(),
            })
    print("tests done, %.0f s" % (time.perf_counter() - t0), flush=True)

    # ---------------------------------------------------------------- against the slot-level run
    slot_run = json.loads((here / "out" / "32-part2-scan.json").read_text(encoding="utf-8"))
    cross_b = Counter()
    slot_rows = {}
    for cls, rows in slot_run["test_b"].items():
        for r in rows:
            aid = atom_of_slot[r["slot"]]
            cross_b[(cls, class_of_atom.get(aid, "not reached"))] += 1
            if cls == "mam-elsewhere":
                slot_rows.setdefault(cls, []).append({
                    "slot": r["slot"], "slot_ref": r["ref"], "slot_analysis": r["analysis"],
                    "atom": aid, "atom_ref": eref(atoms[aid]["ref"]), "atom_class": class_of_atom.get(aid, "not reached"),
                })
    flagged_atom = {i: g for g in groups_a for i in g["atoms"]}
    slot_flagged = {s for g in slot_run["test_a"] for s in g["slots"]}
    new_groups, new_atoms = Counter(), Counter()
    for g in groups_a:
        g["new"] = not any(s in slot_flagged for i in g["atoms"] for s in atoms[i]["slots"])
        if g["new"]:
            new_groups[g["kind"]] += 1
            new_atoms[g["kind"]] += len(g["atoms"])
    cross_a = Counter()
    slot_a_detail = []
    for g in slot_run["test_a"]:
        for s in g["slots"]:
            aid = atom_of_slot[s]
            rec = atoms[aid]
            if aid in flagged_atom:
                fate = "flagged, " + flagged_atom[aid]["kind"]
            elif rec["key"] is None:
                fate = "atom skipped"
            elif max(by_key[rec["key"]].values()) < 5:
                fate = "atom's key under 5"
            else:
                fate = "supported"
            cross_a[(g["kind"], fate)] += 1
            slot_a_detail.append({"slot": s, "slot_kind": g["kind"], "atom": aid, "ref": eref(rec["ref"]), "fate": fate})

    # ---------------------------------------------------------------- outputs
    out = here / "out"
    slot_b = slot_run["test_b_stats"]
    run = [
        "p2d: part2_scan.py's tests over BHSA atoms (scripts/p2d_scan_atoms.py), %.0f s" % (time.perf_counter() - t0),
        "",
        "BHSA atoms: %s" % json.dumps({k: v for k, v in stats.items() if not k.startswith("test A")}),
        "",
        "Test A, atom level: %d atoms in %d groups; slot level (out/33-part2-scan-run.txt): 359 words in 305 groups"
        % (stats["test A: atoms flagged"], stats["test A: groups"]),
        "  testable atoms (key has some analysis at least 5 times): %d of %d keyed" % (testable, stats["BHSA atoms keyed"]),
        "  slot level, testable words (part2_scan.py's keys, recounted here): %d of %d keyed" % (slot_testable, slot_keyed),
        "  by kind, atoms: %s" % json.dumps({k: kinds_atoms[k] for k in KINDS}),
        "  by kind, groups: %s" % json.dumps({k: kinds_groups[k] for k in KINDS}),
        "  new at the atom level (no slot of the group's atoms flagged at the slot level), groups: %s; atoms: %s"
        % (json.dumps({k: new_groups[k] for k in KINDS}), json.dumps({k: new_atoms[k] for k in KINDS})),
        "  slot level by kind, words: {'stem/tense': 62, 'lexeme': 297}",
        "",
        "Test B, atom level: %s" % json.dumps(dict(stats_b)),
        "Test B, slot level: %s" % json.dumps(slot_b),
        "",
        "%-14s %10s %10s" % ("class", "atoms", "slots (slot level)"),
    ]
    for cls in CLASSES:
        run.append("%-14s %10d %10d" % (cls, stats_b["atoms: " + cls], slot_b.get("slots: " + cls, 0)))
    run += ["", "Atoms whose pointing differs by bkey but whose keys are equal (skey of the BHSA's text, bkey of MAM's):"]
    for r in rows_b["keys equal"]:
        run.append("  %s | BHSA %s | MAM %s" % (r["ref"], C.mnorm(C.ib_review.stripped(r["bhsa"])), C.mnorm(C.ib_review.stripped(r["mam"]))))
    run += ["", "Slot-level Test B rows (by class) -> the class of the atom that holds the slot:"]
    for (sc, ac), n in sorted(cross_b.items()):
        run.append("  %-14s -> %-24s %6d" % (sc, ac, n))
    run += ["", "Slot-level mam-elsewhere rows -> their atoms:"]
    for r in slot_rows.get("mam-elsewhere", []):
        run.append("  %s slot %d (%s) -> atom %d, %s" % (r["slot_ref"], r["slot"], " ".join(r["slot_analysis"][1:]), r["atom"], r["atom_class"]))
    run += ["", "Slot-level Test A words (by kind) -> the fate of the atom that holds the slot:"]
    for (sk, fate), n in sorted(cross_a.items()):
        run.append("  %-10s -> %-28s %6d" % (sk, fate, n))
    (out / "p2d-scan-run.txt").write_text("\n".join(run) + "\n", encoding="utf-8", newline="\n")

    lines = [
        "Test A, atom level: %d atoms in %d groups (pointed key, analysis) whose analysis their key does not support"
        % (stats["test A: atoms flagged"], len(groups_a)),
        "by kind (atoms): %s" % json.dumps({k: kinds_atoms[k] for k in KINDS}),
        "Analysis per slot: lex [vs vt] [ps.nu.gn, - for NA and ? for unknown] [+prs]; slots joined by ' + '.",
        "(new): no slot of the group's atoms is among the slot-level Test A words (out/30-part2-test-a.txt).",
        "",
    ]
    for kind in KINDS:
        sel = [g for g in groups_a if g["kind"] == kind]
        lines += ["== %s: %d groups, %d atoms" % (kind, len(sel), sum(len(g["atoms"]) for g in sel))]
        for g in sel:
            extra = ""
            if kind == "ps/nu/gn/prs":
                extra = " | differs: %s" % "; ".join("%s %s %s (commonest %s)" % (d["lex"], d["field"], d["this"], d["commonest"]) for d in g["diffs"])
            mam0 = g["mam"][0]
            lines.append("A%d%s | %s | this: %s x%d | key: %s | %s | MAM at the first: %s%s" % (
                g["n"], " (new)" if g["new"] else "", fmt_key(g["key"]), fmt(g["analysis"]), len(g["atoms"]),
                fmt_counter(Counter(dict(g["key_counts"]))),
                "; ".join(g["refs"]), C.mnorm(C.ib_review.stripped(mam0)) if mam0 else "(not aligned)", extra))
        lines.append("")
    (out / "p2d-test-a.txt").write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")

    blines = ["Test B, atom level: %s" % json.dumps(dict(stats_b)), ""]
    for cls in CLASSES:
        groups = defaultdict(list)
        for r in rows_b[cls]:
            groups[(r["bhsa_key"], r["mam_key"], r["analysis"])].append(r)
        blines.append("== %s: %d atoms in %d groups (BHSA's key, MAM's key, analysis)" % (cls, len(rows_b[cls]), len(groups)))
        if cls == "both":
            blines += ["(listed in out/p2d-scan.json only)", ""]
            continue
        for n, ((kb, km, a), rs) in enumerate(sorted(groups.items(), key=lambda kv: kv[1][0]["atom"]), 1):
            r0 = rs[0]
            blines.append("%d. BHSA %s | MAM %s | %s | own: %s | MAM's key: %s | %s" % (
                n, fmt_key(kb), fmt_key(km), fmt(a),
                fmt_counter(Counter(dict(r0["own"]))), fmt_counter(Counter(dict(r0["mam_key_counts"]))),
                "; ".join(r["ref"] for r in rs)))
        blines.append("")
    (out / "p2d-test-b.txt").write_text("\n".join(blines) + "\n", encoding="utf-8", newline="\n")

    def jkey(k):
        return [list(k[0]), k[1]]

    def janal(a):
        return [list(t) for t in a]

    (out / "p2d-scan.json").write_text(json.dumps({
        "stats": dict(stats),
        "test_a": [{
            **g,
            "key": jkey(g["key"]),
            "analysis": janal(g["analysis"]),
            "commonest": janal(g["commonest"]),
            "key_counts": [[janal(a), n] for a, n in g["key_counts"]],
        } for g in groups_a],
        "test_a_kinds_atoms": dict(kinds_atoms),
        "test_a_kinds_groups": dict(kinds_groups),
        "test_b_stats": dict(stats_b),
        "test_b": {c: [{
            **r,
            "bhsa_key": jkey(r["bhsa_key"]),
            "mam_key": jkey(r["mam_key"]),
            "analysis": janal(r["analysis"]),
            "own": [[janal(a), n] for a, n in r["own"]],
            "mam_key_counts": [[janal(a), n] for a, n in r["mam_key_counts"]],
        } for r in rows_b[c]] for c in CLASSES},
        "test_b_keys_equal": rows_b["keys equal"],
        "slot_level": {
            "test_a_testable_words": slot_testable,
            "test_a_keyed_words": slot_keyed,
            "test_b_stats": slot_b,
            "cross_b": [[sc, ac, n] for (sc, ac), n in sorted(cross_b.items())],
            "mam_elsewhere_rows": slot_rows.get("mam-elsewhere", []),
            "cross_a": [[sk, fate, n] for (sk, fate), n in sorted(cross_a.items())],
            "test_a_words": slot_a_detail,
        },
    }, ensure_ascii=False, indent=1), encoding="utf-8", newline="\n")
    print("\n".join(run))


if __name__ == "__main__":
    main()

"""Group Test B's rows of one class by (the BHSA's key, MAM's key, analysis), for review.

Throwaway scratch. Usage: python -I part2_group.py <this folder> <class> <out txt>
"""

import json
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402


def fmt(a):
    lang, lex, vs, vt = a
    return "%s%s%s" % ("Aram " if lang == "Aramaic" else "", lex, "" if vs == "NA" else " %s %s" % (vs, vt))


def main():
    here, cls, out = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3])
    data = json.loads((here / "out" / "32-part2-scan.json").read_text(encoding="utf-8"))
    groups = defaultdict(list)
    for r in data["test_b"].get(cls, []):
        groups[(C.skey(r["bhsa"]), C.skey(r["mam_piece"]), tuple(r["analysis"]))].append(r)
    lines = ["Test B class %s: %d slots in %d groups" % (cls, sum(len(v) for v in groups.values()), len(groups))]
    for n, ((kb, km, a), rs) in enumerate(sorted(groups.items(), key=lambda kv: kv[1][0]["slot"]), 1):
        r0 = rs[0]
        lines.append("%d. BHSA %s | MAM %s | %s | own: %s | MAM's key: %s | %s" % (
            n, kb, km, fmt(a),
            ", ".join("%s x%d" % (fmt(x), k) for x, k in r0["own"]) or "-",
            ", ".join("%s x%d" % (fmt(x), k) for x, k in r0["mam_key"]) or "-",
            "; ".join(r["ref"] for r in rs)))
    out.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print(lines[0])


if __name__ == "__main__":
    main()

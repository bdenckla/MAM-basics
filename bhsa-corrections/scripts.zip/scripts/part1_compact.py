"""A compact view of out/10-part1-cases.json: one block per case, sides merged when equal.

Throwaway scratch. Usage: python -I part1_compact.py <in json> <out txt>
"""

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402


def slot_line(r):
    feats = [r.get("lex", ""), r.get("sp", ""), r.get("pdp", "")]
    if r.get("vs") not in (None, "NA"):
        feats += [r["vs"], r["vt"]]
    for k in ("ps", "nu", "gn", "st"):
        if r.get(k) not in (None, "NA"):
            feats.append("%s=%s" % (k, r[k]))
    if r.get("prs") not in (None, "absent", "n/a"):
        feats.append("prs=%s" % r["prs"])
    q = (" qere=%s hybrid=%s" % (r["qere_utf8"], r.get("kq_hybrid_utf8", ""))) if "qere_utf8" in r else ""
    return "%s [%s] %s | %s %s | %s" % (
        r.get("g_word_utf8", "") or "(empty)", r.get("g_word", ""), " ".join(feats),
        r["phrase"]["typ"], r["phrase"]["function"], r.get("gloss", "")) + q


def main():
    data = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    out = []
    for n, res in enumerate(data, 1):
        out.append("%d. %s (%s)%s" % (n, res["reference"], res["source"], " [%s]" % res["label"] if res["label"] else ""))
        seen = []
        for side in ("ketiv", "qere"):
            s = res["sides"][side]
            if not s["found"]:
                out.append("   %s: not found" % side)
                continue
            for p in s["places"]:
                sig = json.dumps([p["bhsa"], p["wlc418_idx"]], ensure_ascii=False)
                if sig in seen:
                    out.append("   %s: as above" % side)
                    continue
                seen.append(sig)
                out.append("   %s: WLC418 %s | 4.20 %s | 4.22 %s | UXLC2.6 %s | MAM %s | BHSA %s" % (
                    side,
                    " ".join(a["text"] for a in p["wlc418"]),
                    " ".join(a["text"] for a in p["wlc420"]),
                    " ".join(a["text"] for a in p["wlc422"]),
                    " ".join(a["text"] for a in p["uxlc26"]),
                    " ".join(p["mam"]),
                    " ".join(p["bhsa"])))
                out.append("      bkey BHSA=UXLC2.6 %s UXLC2.6=MAM %s" % (p["bkey_bhsa_eq_uxlc26"], p["bkey_uxlc26_eq_mam"]))
                out.append("      skey BHSA=418 %s BHSA=MAM %s | bkey BHSA=418 %s BHSA=MAM %s | bfkey BHSA=418 %s | fkey BHSA=418 %s =420 %s =422 %s | notes %s" % (
                    p["skey_bhsa_eq_wlc418"], p["skey_bhsa_eq_mam"], p["bkey_bhsa_eq_wlc418"],
                    p["bkey_bhsa_eq_mam"], p["bfkey_bhsa_eq_wlc418"], p["fkey_bhsa_eq_wlc418"],
                    p["fkey_bhsa_eq_wlc420"], p["fkey_bhsa_eq_wlc422"], [a["notes"] for a in p["wlc418"]]))
                for r in p["bhsa_slots"]:
                    out.append("      " + slot_line(r))
    Path(sys.argv[2]).write_text("\n".join(out) + "\n", encoding="utf-8", newline="\n")
    print("wrote", sys.argv[2])


if __name__ == "__main__":
    main()

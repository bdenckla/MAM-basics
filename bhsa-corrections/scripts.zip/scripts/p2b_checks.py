"""Targeted checks of the BHSA's own data for slice p2b's judgments (throwaway scratch).

Usage (from the MAM-basics root):
  C:/Users/BenDe/GitRepos/MAM-basics/.venv/Scripts/python.exe -I <this folder>/scripts/p2b_checks.py

Each check prints what the BHSA 2021 has; out/p2b-checks.txt keeps the output.
1. Verbs of a lexeme ending "H[" (third he), qal perfect third masculine singular with a third
   feminine singular suffix (prs H): their forms, so that the regular spelling of "he did it"
   with a mappiq can be seen (Genesis 39:19).
2. Every <FH[ word with prs H.
3. Imperfect and wayyiqtol words with prs H: the endings of their written forms (Genesis 2:18).
4. Atoms whose first slot is a one-letter proclitic with hiriq and whose next slot begins with a
   yod with sheva (2 Kings 9:15).
5. Joshua 15:4's slots, with qere and accents (the word before the row's).
6. Perfects second masculine singular with suffix M (Jeremiah 11:2).
7. Every distinct pointed key of the preposition MN with a suffix (Genesis 16:2, Psalms 139:12).
8. Hitpael perfects third masculine singular before a maqaf (Deuteronomy 4:21).
9. Song of Songs 6:8 and Numbers 19:21: the word before the row's, with its accents.
"""

import sys
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402

HERE = Path(__file__).resolve().parent.parent
DAGESH = "\N{HEBREW POINT DAGESH OR MAPIQ}"
SEGOL = "\N{HEBREW POINT SEGOL}"
HIRIQ = "\N{HEBREW POINT HIRIQ}"
SHEVA = "\N{HEBREW POINT SHEVA}"
HE = "\N{HEBREW LETTER HE}"
YOD = "\N{HEBREW LETTER YOD}"


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    B = C.Bhsa()
    gw, qw, tr = B.wf("g_word_utf8"), B.wf("qere_utf8"), B.wf("trailer_utf8")
    f = {n: B.wf(n) for n in ("language", "lex", "vs", "vt", "ps", "nu", "gn", "prs", "sp")}
    out = []

    def ref(s):
        b, ch, v = B.ref_of_slot[s]
        return "%s %d:%d" % (b, ch, v)

    def show(s):
        return "%s %s [%s %s %s %s%s%s prs=%s]" % (
            ref(s), C.mnorm(gw.get(s, "")), f["lex"][s], f["vs"][s], f["vt"][s], f["ps"][s], f["nu"][s], f["gn"][s], f["prs"][s])

    words = [s for s in range(1, B.max_slot + 1) if s not in qw and C.letters(gw.get(s, ""))]

    out.append("== 1. third-he verbs, qal perfect 3ms with suffix H")
    hits = [s for s in words if f["lex"][s].endswith("H[") and f["vs"][s] == "qal" and f["vt"][s] == "perf"
            and f["ps"][s] == "p3" and f["nu"][s] == "sg" and f["gn"][s] == "m" and f["prs"][s] == "H"]
    keys = Counter(C.skey(gw[s]) for s in hits)
    out.append("%d words, %d keys" % (len(hits), len(keys)))
    for s in hits[:40]:
        out.append("  " + show(s))

    out.append("")
    out.append("== 2. <FH[ with prs H")
    for s in words:
        if f["lex"][s] == "<FH[" and f["prs"][s] == "H":
            out.append("  " + show(s))

    out.append("")
    out.append("== 3. impf/wayq with prs H: endings (last two letters with marks)")
    ends = Counter()
    ex = {}
    for s in words:
        if f["vt"][s] in ("impf", "wayq") and f["prs"][s] == "H":
            cl = [(b, m) for b, m in C.clusters(C.skey(gw[s])) if C.HEB_LETTER.match(b)]
            e = "".join(b + "".join(m) for b, m in cl[-2:])
            ends[e] += 1
            ex.setdefault(e, s)
    for e, n in ends.most_common():
        out.append("  %s x%d e.g. %s" % (C.mnorm(e), n, show(ex[e])))
    out.append("  -- any word (any analysis) whose key ends in segol + he with mappiq:")
    seg_he = Counter()
    seg_ex = {}
    for s in words:
        cl = [(b, m) for b, m in C.clusters(C.skey(gw[s])) if C.HEB_LETTER.match(b)]
        if len(cl) >= 2 and cl[-1][0] == HE and DAGESH in cl[-1][1] and SEGOL in cl[-2][1]:
            k = (f["lex"][s], f["vt"][s], f["prs"][s])
            seg_he[k] += 1
            seg_ex.setdefault(k, s)
    for k, n in seg_he.most_common():
        out.append("  %s x%d e.g. %s" % (k, n, show(seg_ex[k])))

    out.append("")
    out.append("== 4. a proclitic with hiriq, then a slot beginning with yod + sheva")
    n4 = 0
    for (book, ch, v), slots in B.verse_slots.items():
        for a, b in zip(slots, slots[1:]):
            wa, wb = gw.get(a, ""), gw.get(b, "")
            if len(C.letters(wa)) != 1 or tr.get(a, "") != "":
                continue
            ca = C.clusters(C.skey(wa))
            cb = C.clusters(C.skey(wb)) if wb else []
            if ca and HIRIQ in ca[0][1] and cb and cb[0][0] == YOD and SHEVA in cb[0][1]:
                n4 += 1
                if n4 <= 30:
                    out.append("  %s | %s + %s [%s %s]" % (ref(a), C.mnorm(wa), C.mnorm(wb), f["lex"][a], f["lex"][b]))
    out.append("  total %d" % n4)

    out.append("")
    out.append("== 5. Joshua 15:4 slots")
    for s in B.verse_slots[("Josua", 15, 4)][:6]:
        out.append("  slot %d g_word %s | qere %s | trailer %r | marks %s" % (
            s, C.mnorm(gw.get(s, "")), C.mnorm(qw.get(s, "")), tr.get(s, ""),
            ", ".join(unicodedata.name(x).replace("HEBREW ", "").lower() for x in (qw.get(s) or gw.get(s, ""))
                      if "\N{HEBREW ACCENT ETNAHTA}" <= x <= "\N{HEBREW MARK MASORA CIRCLE}" or x == "\N{HEBREW POINT METEG}")))

    out.append("")
    out.append("== 6. perfects 2ms with suffix M")
    for s in words:
        if f["vt"][s] == "perf" and f["ps"][s] == "p2" and f["nu"][s] == "sg" and f["gn"][s] == "m" and f["prs"][s] == "M":
            out.append("  " + show(s))

    out.append("")
    out.append("== 7. MN with a suffix: distinct keys")
    mn = defaultdict(Counter)
    mnx = {}
    for s in words:
        if f["lex"][s] == "MN" and f["prs"][s] not in ("absent", "n/a"):
            k = C.skey(gw[s])
            mn[f["prs"][s]][k] += 1
            mnx.setdefault(k, s)
    for p, c in sorted(mn.items()):
        out.append("  prs %s: %s" % (p, "; ".join("%s x%d (%s)" % (C.mnorm(k), n, ref(mnx[k])) for k, n in c.most_common())))

    out.append("")
    out.append("== 8. hitpael perfect 3ms before a maqaf")
    for s in words:
        if f["vs"][s] == "hit" and f["vt"][s] == "perf" and f["ps"][s] == "p3" and f["nu"][s] == "sg" and C.MAQAF in tr.get(s, ""):
            out.append("  " + show(s))

    out.append("")
    out.append("== 9. words before the rows at Song of Songs 6:8 (slot 358786) and Numbers 19:21 (slot 82499)")
    for s in (358785, 82498, 371179, 324931):
        out.append("  slot %d %s %s | trailer %r | accents %s" % (
            s, ref(s), C.mnorm(gw.get(s, "")), tr.get(s, ""),
            ", ".join(unicodedata.name(x).replace("HEBREW ", "").lower() for x in gw.get(s, "")
                      if "\N{HEBREW ACCENT ETNAHTA}" <= x <= "\N{HEBREW MARK MASORA CIRCLE}" or x == "\N{HEBREW POINT METEG}")))

    text = "\n".join(out) + "\n"
    (HERE / "out" / "p2b-checks.txt").write_text(text, encoding="utf-8", newline="\n")
    print(text)


if __name__ == "__main__":
    main()

"""Slice p2c's tables of Test B's class neither: out/p2c-neither.md and out/p2c-neither.json.

Throwaway scratch. Usage (from the MAM-basics root):
  python -I p2c_table.py <this folder>

Reads out/32-part2-scan.json ["test_b"]["neither"], out/p2c-prefilter.json (p2c_prefilter.py)
and the judgments in p2c_judgments.py, and checks that every row has exactly one judgment in a
known category. Every Hebrew form is emitted from the data, accents removed, in MAM-normal mark
order; a reason's "{slot|N}" becomes BHSA slot N's written form (its qere where it has one).
"""

import json
import re
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402
import p2c_judgments as PJ  # noqa: E402

ACCENTS = re.compile(
    "[\N{HEBREW ACCENT ETNAHTA}-\N{HEBREW MARK MASORA CIRCLE}"
    "\N{HEBREW PUNCTUATION SOF PASUQ}\N{HEBREW PUNCTUATION PASEQ}]"
)
PLACEHOLDER = re.compile(r"\{slot\|(\d+)\}")


def shown(s):
    """A form for display: accents, sof pasuq and paseq removed, every other mark kept, in
    MAM-normal mark order."""
    return C.mnorm(ACCENTS.sub("", s))


def mam_own_piece(mam_atom, atom_slots, slot, piece_as_compared):
    """MAM's piece for one slot in MAM's own pointing: MAM's atom cut into the BHSA's slots by
    letter count, as Test B cuts it, but without first moving a holam male dot to the letter
    before the vav. Checked against the piece that Test B compared."""
    units = [(b, m) for b, m in C.clusters(mam_atom) if C.HEB_LETTER.match(b)]
    i = 0
    for x in atom_slots:
        n = len(C.letters(x["form"]))
        piece = "".join(b + "".join(m) for b, m in units[i : i + n])
        i += n
        if x["slot"] == slot:
            if C.skey(C.holam_to_prev(piece)) != C.skey(piece_as_compared):
                raise ValueError("slot %d: MAM's own piece does not match Test B's" % slot)
            return piece
    raise ValueError("slot %d not in its atom" % slot)


def english_book(bhsa_book):
    stem = C.TANACH_US[C.OSIS_FROM_BHSA[bhsa_book]]
    m = re.fullmatch(r"(.+)_(\d)", stem)
    return "%s %s" % (m.group(2), m.group(1)) if m else stem.replace("_", " ")


def english_ref(bhsa_ref):
    book, cv = bhsa_ref.rsplit(" ", 1)
    return "%s %s" % (english_book(book), cv)


def analysis_text(a, gloss):
    lang, lex, vs, vt = a
    return "%s`%s`%s '%s'" % ("Aramaic " if lang == "Aramaic" else "", lex,
                              "" if vs == "NA" else " %s %s" % (vs, vt), gloss)


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    here = Path(sys.argv[1])
    rows = json.loads((here / "out" / "32-part2-scan.json").read_text(encoding="utf-8"))["test_b"]["neither"]
    pre = {r["slot"]: r for r in json.loads((here / "out" / "p2c-prefilter.json").read_text(encoding="utf-8"))}
    slots = [r["slot"] for r in rows]
    if len(slots) != 169 or len(set(slots)) != 169:
        raise ValueError("expected 169 distinct rows, got %d" % len(slots))
    if set(PJ.J) != set(slots):
        raise ValueError("judged but not a row: %s; a row not judged: %s" % (
            sorted(set(PJ.J) - set(slots)), sorted(set(slots) - set(PJ.J))))
    if set(pre) != set(slots):
        raise ValueError("the pre-filter's rows are not the scan's")
    for s, (cat, reason) in PJ.J.items():
        if cat not in PJ.CATEGORIES:
            raise ValueError("slot %d: unknown category %r" % (s, cat))
        if C.HEB_LETTER.search(reason):
            raise ValueError("slot %d: a reason with a Hebrew letter typed by hand" % s)
    B = C.Bhsa()
    gw, qw = B.wf("g_word_utf8"), B.wf("qere_utf8")

    def fill(reason):
        def form(m):
            s = int(m.group(1))
            return shown(qw.get(s) or gw[s])
        return PLACEHOLDER.sub(form, reason)

    out_rows = []
    for n, r in enumerate(rows, 1):
        s = r["slot"]
        p = pre[s]
        cat, reason = PJ.J[s]
        a = tuple(r["analysis"])
        own_piece = mam_own_piece(r["mam_atom"], p["bhsa_atom_slots"], s, r["mam_piece"])
        out_rows.append({
            "n": n,
            "slot": s,
            "ref": english_ref(r["ref"]),
            "bhsa_ref": r["ref"],
            "bhsa": shown(r["bhsa"]),
            "mam": shown(own_piece),
            "analysis": list(a),
            "analysis_text": analysis_text(a, p["features"]["gloss"]),
            "category": cat,
            "reason": fill(reason),
            "evidence": {
                "bhsa_raw": C.mnorm(r["bhsa"]),
                "mam_piece_raw": C.mnorm(own_piece),
                "mam_piece_as_compared": C.mnorm(r["mam_piece"]),
                "bhsa_atom": shown(p["bhsa_atom"]),
                "mam_atom": shown(p["mam_atom"]),
                "wlc418_atom": p["wlc418"],
                "features": p["features"],
                "own_key_elsewhere": p["own_elsewhere"],
                "mam_key_in_bhsa": p["mam_key_in_bhsa"],
                "neighbours_other": [x for x in p["neighbours"] if x["other"]],
                "neighbours_same": [x for x in p["neighbours"] if not x["other"]],
                "same_full_analysis_forms": p["same_full_analysis_forms"],
            },
        })
    counts = Counter(x["category"] for x in out_rows)
    n_nb = sum(1 for x in out_rows if x["evidence"]["neighbours_other"])
    n_mk = sum(1 for x in out_rows if any(y["other"] for y in x["evidence"]["mam_key_in_bhsa"]))
    (here / "out" / "p2c-neither.json").write_text(json.dumps({
        "categories": list(PJ.CATEGORIES),
        "counts": {c: counts.get(c, 0) for c in PJ.CATEGORIES},
        "rows": out_rows,
    }, ensure_ascii=False, indent=1), encoding="utf-8", newline="\n")

    L = []
    L.append("# Test B's class neither, read row by row (slice p2c)")
    L.append("")
    L.append("Written by Claude (Opus 5.5) on 2026-11-13, New York time, as a sub-agent of the session "
             "that wrote this folder's README.md. Not reviewed by a human. Every form is a "
             "transcription's: the BHSA 2021's (`g_word_utf8`), MAM-simple's, or WLC 4.18's where it is "
             "named; nothing here says what any manuscript has.")
    L.append("")
    L.append("The 169 rows are Test B's class neither (`out/35-part2-test-b-neither.txt`, "
             "`out/32-part2-scan.json`): BHSA words (slots) where MAM's pointing differs and the analysis "
             "(language, `lex`, `vs`, `vt`) is supported neither by the BHSA's own pointing elsewhere nor "
             "by the BHSA's words with MAM's pointing. A slot is one BHSA word, a part of an atom.")
    L.append("")
    L.append("## Method")
    L.append("")
    L.append("1. **Pre-filter** (`scripts/p2c_prefilter.py`, `out/p2c-prefilter.txt` and `.json`): for each "
             "row, every BHSA pointed key equal to the row's key after one small edit (a dagesh or mappiq "
             "added or removed, one vowel point removed, added or changed, a ḥolam moved to the next or "
             "previous letter, a shin dot exchanged for a sin dot or back; the review's key ignores "
             "accents, meteg and silluq, so an edit to U+05BD changes no key), with its analyses, counts "
             "and an example; the analyses of MAM's pointing in the BHSA; the spellings of the row's full "
             "analysis (with person, number, gender, state and suffix) elsewhere; and WLC 4.18's aligned "
             "atom with its notes. %d rows have a one-edit neighbour analysed with another lexeme, stem or "
             "tense, and %d have MAM's pointing in the BHSA with another analysis." % (n_nb, n_mk))
    L.append("2. **Lookups** for the judgments: `scripts/p2c_lexforms.py` (`out/p2c-lexforms.txt`, the "
             "forms of 25 lexemes), `scripts/p2c_context.py` (`out/p2c-context.txt`, verses in the BHSA "
             "and MAM) and `scripts/p2c_slots.py` (`out/p2c-slots.txt`, the slots that reasons cite).")
    L.append("3. **Judgments**, by Hebrew morphology and the BHSA's own data, in `scripts/p2c_judgments.py`; "
             "this page and `out/p2c-neither.json` come from `scripts/p2c_table.py`.")
    L.append("")
    L.append("## Categories")
    L.append("")
    L.append("- **another-word**: the BHSA's pointing is a well-formed spelling of another attested word "
             "(another lexeme, or another stem, tense or person of the same lexeme), and the analysis "
             "departs from it. A correction candidate.")
    L.append("- **follows-pointing**: the analysis is what the BHSA's own pointing spells, even if rare, "
             "while MAM's pointing would have another analysis (Part 1's class a).")
    L.append("- **no-word**: the BHSA's pointing breaks a rule of Tiberian pointing: it lacks a vowel, a "
             "mappiq, a dagesh forte or a word-internal dagesh lene that the word needs, or it has a ḥataf "
             "vowel in a closed syllable or a mark where none can stand. The analysis reads the regular "
             "word through it, as at Genesis 34:11.")
    L.append("- **variant**: the BHSA's pointing is a regular or recognized spelling of the analysed word: "
             "a ḥataf vowel for a vocal shewa under a letter that is not a guttural (or MAM's ḥataf where "
             "the BHSA has the regular vowel), a full vowel for a ḥataf under a guttural, another vowel "
             "that spells no other word, a dagesh lene at a word's start (which depends on the atom "
             "before), a dagesh dirimens, the dot in a consonantal vav that the review's footnote "
             "`vav-dot` describes, a ketiv's letters with the qere's vowels where MAM has a ketiv and "
             "qere. Not a correction.")
    L.append("- **unsure**: the evidence does not settle the category.")
    L.append("")
    L.append("## Counts")
    L.append("")
    L.append("| Category | Rows |")
    L.append("|---|---|")
    for c in PJ.CATEGORIES:
        L.append("| %s | %d |" % (c, counts.get(c, 0)))
    L.append("| total | %d |" % len(out_rows))
    L.append("")
    L.append("## Rows of note")
    L.append("")
    L.append("Every another-word, follows-pointing and unsure row, and two no-word rows whose stem or "
             "tense is open to question: Ezekiel 37:23, analysed as a piel where the BHSA's pointing "
             "lacks only the dagesh of MAM's hitpael, and Psalms 94:1, analysed as an imperative where "
             "the BHSA analyses MAM's pointing three times as a perfect.")
    L.append("")
    order = {c: i for i, c in enumerate(PJ.CATEGORIES)}
    noted = [x for x in out_rows if x["category"] in ("another-word", "follows-pointing", "unsure")
             or x["slot"] in PJ.NOTABLE]
    for x in sorted(noted, key=lambda x: (order[x["category"]], x["n"])):
        e = x["evidence"]
        L.append("### %s (row %d, slot %d): %s" % (x["ref"], x["n"], x["slot"], x["category"]))
        L.append("")
        L.append("- The BHSA's slot: %s, in the atom %s" % (x["bhsa"], e["bhsa_atom"]))
        L.append("- MAM's piece: %s, in the atom %s" % (x["mam"], e["mam_atom"]))
        L.append("- Analysis: %s; ps %s, nu %s, gn %s, st %s, prs %s; the lexeme's part of the slot in the "
                 "ETCBC's segmentation (`g_lex_utf8`): %s" % (
                     x["analysis_text"], e["features"]["ps"], e["features"]["nu"], e["features"]["gn"],
                     e["features"]["st"], e["features"]["prs"], shown(e["features"]["g_lex_utf8"])))
        if isinstance(e["wlc418_atom"], list):
            L.append("- WLC 4.18's atom: %s" % "; ".join(
                "%s%s" % (shown(w["text"]), (" (notes %s)" % ", ".join(w["notes"])) if w["notes"] else "")
                for w in e["wlc418_atom"]))
        def times(k):
            return "once" if k == 1 else "%d times" % k

        for y in e["neighbours_other"]:
            L.append("- A one-edit neighbour (%s): %s, `%s`%s, %s, as at %s" % (
                y["edit"], y["form"], y["analysis"][1],
                "" if y["analysis"][2] == "NA" else " %s %s" % (y["analysis"][2], y["analysis"][3]),
                times(y["count"]), english_ref(y["example"])))
        for y in e["mam_key_in_bhsa"]:
            if y["other"]:
                L.append("- MAM's pointing in the BHSA: `%s`%s, %s, as at %s" % (
                    y["analysis"][1], "" if y["analysis"][2] == "NA" else " %s %s" % (y["analysis"][2], y["analysis"][3]),
                    times(y["count"]), english_ref(y["example"])))
        L.append("- Reason: %s" % x["reason"])
        L.append("")
    L.append("## Every row")
    L.append("")
    L.append("Forms are the BHSA's slot and MAM's piece of its atom, cut by letters as Test B cuts them, "
             "with accents, sof pasuq and paseq removed. MAM's piece is in MAM's own pointing, with a "
             "ḥolam male dot on its vav; Test B compared it after moving that dot to the letter before "
             "the vav, the BHSA's way of writing a ḥolam male. The evidence for each row is in "
             "`out/p2c-neither.json`.")
    L.append("")
    L.append("| # | Verse | BHSA | MAM | Analysis | Category | Reason |")
    L.append("|---|---|---|---|---|---|---|")
    for x in out_rows:
        L.append("| %d | %s | %s | %s | %s | %s | %s |" % (
            x["n"], x["ref"], x["bhsa"], x["mam"], x["analysis_text"], x["category"],
            x["reason"].replace("|", "\\|")))
    L.append("")
    (here / "out" / "p2c-neither.md").write_text("\n".join(L), encoding="utf-8", newline="\n")
    print("counts:", {c: counts.get(c, 0) for c in PJ.CATEGORIES})
    print("rows with a neighbour analysed otherwise:", n_nb, "| MAM's key analysed otherwise:", n_mk)


if __name__ == "__main__":
    main()

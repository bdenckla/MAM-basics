"""Writes out/p2d-review.md, slice p2d's findings, from out/p2d-scan.json and the BHSA.

Throwaway scratch. Usage (from the MAM-basics root): python -I p2d_review.py <this folder>

The prose and the judgments are this script's own (Claude's). Every Hebrew form, count and
reference in the page comes from the data: out/p2d-scan.json, out/32-part2-scan.json, the BHSA's
features, MAM-simple and WLC 4.18. Forms are shown stripped of accents as the review's page
strips its forms (israel_bible_review_index.stripped), in MAM-normal mark order.
"""

import json
import sys
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402
import p2d_scan_atoms as P  # noqa: E402

# Test A's ps/nu/gn/prs groups: group number -> (its first reference, does the pointing spell the
# BHSA's person, number, gender or suffix?, why).
JUDGE = {
    16: ("Genesis 49:11", "yes",
         "Pointed alike as 'my son' and as the construct 'son of' with the old ending -î, the "
         "ḥiriq compaginis. The ETCBC's morphology gives the ḥiriq and yod to a univalent final "
         "(`g_uvf_utf8`) in the construct state, not to a suffix; the next atom, 'his she-ass', "
         "makes the phrase 'his she-ass's colt'."),
    29: ("Leviticus 20:17", "yes",
         "The prefix t- with no ending is second masculine and third feminine singular alike; "
         "the subject is the feminine pronoun just before it."),
    61: ("1 Samuel 30:26", "only with an unwritten yod",
         "Pointed and written as the singular 'to his friend': the plural ending's tsere is the "
         "singular's vowel too, and the plural's yod is not written. The ETCBC's morphology "
         "gives the tsere to the plural ending (`g_nme_utf8`) and only the he and shuruq to the "
         "suffix, where its singular atoms of the key give the tsere to the suffix. The context, "
         "spoil sent 'to the elders of Judah, his friends', is the evident ground."),
    63: ("2 Samuel 3:34", "yes at 2 Samuel 3:34; either at Jeremiah 40:4",
         "See the accents below: at 2 Samuel 3:34 the segol, with a conjunctive accent, is the "
         "vowel of the suffix on a plural or dual noun, whose yod is not written; at Jeremiah "
         "40:4, with a disjunctive accent, it can be the pausal singular's."),
    66: ("2 Samuel 12:10", "yes",
         "The wayyiqtol with t- is second masculine and third feminine singular alike; Nathan is "
         "addressing David ('you despised me')."),
    77: ("1 Kings 13:22", "yes",
         "As at 2 Samuel 12:10: the old prophet addresses the man of God, and the verse's next "
         "two wayyiqtol verbs are also analysed as second masculine."),
    93: ("Isaiah 26:17", "yes", "Second masculine and third feminine alike; the subject is 'a pregnant woman'."),
    97: ("Isaiah 34:1", "yes", "Second masculine and third feminine alike; the subject is 'the earth'."),
    102: ("Isaiah 53:10", "yes",
          "Second masculine ('if you make his soul a guilt offering') and third feminine ('if his "
          "soul makes a guilt offering') are spelled alike; the BHSA makes 'his soul' the "
          "subject, an interpretive choice that the pointing allows."),
    111: ("Jeremiah 15:19", "yes",
          "'My mouth' and the construct 'mouth of' (in the sense 'according to') are pointed "
          "alike; here 'you shall be as my mouth'."),
    117: ("Jeremiah 44:16", "yes",
          "'He is not' and 'we are not' are pointed alike with this suffix; the plural participle "
          "'listening' that follows makes it 'we'."),
    128: ("Ezekiel 22:4", "yes",
          "The atom is second masculine or third feminine singular. The BHSA takes the person "
          "from the context, an address to Jerusalem, and the gender from the atom: a second "
          "feminine singular would end in -î, as the verse's preceding wayyiqtol does. So the "
          "analysis does not correct the atom to the feminine."),
    139: ("Hosea 13:4", "yes",
          "The particle 'except' and 'besides me' are pointed alike; the ETCBC gives the ḥiriq "
          "and yod to a univalent final in its other atoms of the key and to a first singular "
          "suffix here, where the verse ends 'there is no savior besides me'."),
    151: ("Malachi 1:4", "yes", "Second masculine and third feminine alike; the subject is Edom, as a feminine."),
    158: ("Psalms 37:30", "yes", "Second masculine and third feminine alike; the subject is 'his tongue', feminine."),
    164: ("Psalms 97:3", "yes", "Second masculine and third feminine alike; the subject is 'fire', feminine."),
    165: ("Psalms 118:21", "yes",
          "The wayyiqtol with t- is second masculine and third feminine alike; God is addressed "
          "('you answered me')."),
    173: ("Job 33:28", "yes",
          "Second masculine and third feminine alike; the subject is 'life', feminine (a ketiv "
          "'my life' and a qere 'his life', in the BHSA and in MAM)."),
    175: ("Job 42:10", "only with an unwritten yod",
          "As at 1 Samuel 30:26: Job prayed for his three friends, and the ETCBC again gives the "
          "tsere to the plural ending."),
    186: ("Song of Songs 6:12", "yes",
          "As at Genesis 49:11: the construct with the ḥiriq compaginis (univalent final, "
          "construct state) before 'noble'. The BHSA's atom has a maqaf after it, binding it to "
          "the next atom; MAM's has none."),
    199: ("Nehemiah 9:9", "yes",
          "The wayyiqtol with t- is second masculine and third feminine alike; God is addressed "
          "throughout the prayer."),
}

# Test A's segmentation groups: group number -> (first reference, note).
SEGMENTATION = {
    43: ("Deuteronomy 25:7",
         "The BHSA's atom, like WLC 4.18's (a near-copy of BHS, so not an independent check), "
         "has a yod after the second tsere that MAM's lacks. The BHSA analyses it as one slot, the "
         "piel perfect 'refuses' (`M>N[`), the word that MAM's letters spell, where its other "
         "atoms of this pointing are two slots, 'from' and 'nothing'. Its own letters spell "
         "'refuses' only with the yod as a vowel letter. Test B skips the atom, its letters "
         "differing from MAM's."),
    162: ("Psalms 73:20",
          "'When (you) arouse', the hiphil infinitive of `<WR[` with its he unwritten after the "
          "preposition, where the key's other atoms are 'in the city'. The pointing spells both; "
          "context decides."),
    192: ("Ezra 3:10",
          "An unwritten article ('with the trumpets'), where the key's other atoms have none. "
          "Before a ḥataf pataḥ the preposition has pataḥ with or without the article, so the "
          "pointing spells both."),
    222: ("2 Chronicles 30:10",
          "No article ('from city to city'), where the key's other atoms have one. The qamats "
          "under the preposition is elsewhere always analysed as the article's; whether it can "
          "be the preposition's own in this paired phrase is for a reader to judge."),
}

ACCENT_NAMES = {
    "HEBREW ACCENT MUNAH": ("munaḥ", False),
    "HEBREW ACCENT SEGOL": ("segolta", True),
    "HEBREW ACCENT ZAQEF QATAN": ("zaqef", True),
    "HEBREW ACCENT ETNAHTA": ("atnaḥ", True),
    "HEBREW ACCENT REVIA": ("revia", True),
}


def accent_of(text, verse_final):
    """The accent of an atom with one accent, by name, and whether it is disjunctive. Closed
    dispatch over the accents that this page's atoms have; anything else raises."""
    names = sorted(unicodedata.name(ch) for ch in text
                   if "\N{HEBREW ACCENT ETNAHTA}" <= ch <= "\N{HEBREW MARK MASORA CIRCLE}" or ch == "\N{HEBREW POINT METEG}")
    if names == ["HEBREW POINT METEG"] and verse_final:
        return "silluq", True
    if names == ["HEBREW ACCENT MERKHA", "HEBREW ACCENT OLE"]:
        return "oleh-weyored", True
    if len(names) == 1 and names[0] in ACCENT_NAMES:
        return ACCENT_NAMES[names[0]]
    raise ValueError("unexpected accents %r" % names)


def tup(a):
    return tuple(tuple(t) for t in a)


def heb(s):
    return C.mnorm(C.ib_review.stripped(s))


def an(a):
    return "`%s`" % P.fmt(tup(a))


def counts(pairs, limit=None):
    return ", ".join("`%s` x%d" % (P.fmt(tup(a)), n) for a, n in pairs[:limit]) or "none"


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8", errors="backslashreplace")
    here = Path(sys.argv[1])
    data = json.loads((here / "out" / "p2d-scan.json").read_text(encoding="utf-8"))
    slot_run = json.loads((here / "out" / "32-part2-scan.json").read_text(encoding="utf-8"))
    groups = {g["n"]: g for g in data["test_a"]}
    for n, (ref, *_rest) in list(JUDGE.items()) + list(SEGMENTATION.items()):
        if groups[n]["refs"][0] != ref:
            raise ValueError("group A%d starts at %s, not %s" % (n, groups[n]["refs"][0], ref))
    png = [g for g in data["test_a"] if g["kind"] == "ps/nu/gn/prs"]
    if sorted(g["n"] for g in png) != sorted(JUDGE):
        raise ValueError("the ps/nu/gn/prs groups and JUDGE differ")
    seg = [g for g in data["test_a"] if g["kind"] == "segmentation"]
    if sorted(g["n"] for g in seg) != sorted(SEGMENTATION):
        raise ValueError("the segmentation groups and SEGMENTATION differ")

    # ---------------------------------------------------------------- the BHSA, for evidence
    B = C.Bhsa()
    lang = B.wf("language")
    feats = [B.wf(f) for f in P.FIELDS]
    english = {short.replace(" ", ""): name for name, short in C.ib_review.SHORT.items()}
    english["Eccl"] = "Ecclesiastes"
    qw = B.wf("qere_utf8")
    need = set()
    for r in data["test_b"]["mam-elsewhere"]:
        need.add((tuple(r["bhsa_key"][0]), r["bhsa_key"][1]))
        need.add((tuple(r["mam_key"][0]), r["mam_key"][1]))
    hand_key = (tuple(groups[63]["key"][0]), groups[63]["key"][1])
    need.add(hand_key)
    index = defaultdict(list)
    verse_atoms = {}
    for ref in sorted(B.verse_slots, key=lambda r: B.verse_slots[r][0]):
        book, ch, v = ref
        osis = C.OSIS_FROM_BHSA[book]
        atoms = B.atoms(osis, ch, v, "ketiv")
        verse_atoms[(osis, ch, v)] = atoms
        for i, ba in enumerate(atoms):
            if any(s in qw for s in ba["slots"]) or not C.letters(ba["text"]):
                continue
            k = (tuple(sorted({lang[s] for s in ba["slots"]})), C.skey(ba["text"]).rstrip(C.MAQAF))
            if k in need:
                a = tuple(tuple(f[s] for f in feats) for s in ba["slots"])
                index[k].append({"a": a, "ref": "%s %d:%d" % (english[osis], ch, v), "text": ba["text"],
                                 "final": i == len(atoms) - 1})

    def refs_of(k, a):
        return [x["ref"] for x in index[k] if x["a"] == tup(a)]

    lint = C.load_lint()

    def mam_and_wlc(osis, ch, v, atom_index):
        """MAM's and WLC 4.18's atoms aligned with the BHSA's atom by letters (ketiv side)."""
        b_texts = [a["text"] for a in verse_atoms[(osis, ch, v)]]
        mam = C.mam_atoms(lint, P.SHORT_FROM_OSIS[osis], ch, v, "ketiv", "cant-combined", "%s %d:%d" % (osis, ch, v))
        wlc = [a["text"] for a in C.wlc418_side(C.read_wlc418_book(osis)[(ch, v)], "ketiv")]
        return ([mam[j] for j in C.align(b_texts, mam)[atom_index]],
                [wlc[j] for j in C.align(b_texts, wlc)[atom_index]])

    # 1 Kings 16:11: the BHSA's plural of 'friend' with suffix HW
    lex, nu = B.wf("lex"), B.wf("nu")
    k16 = [(i, a) for i, a in enumerate(verse_atoms[("1Kgs", 16, 11)])
           if any(lex[s] == "R<=/" and nu[s] == "pl" for s in a["slots"])]
    if len(k16) != 1:
        raise ValueError("1 Kings 16:11: %d atoms" % len(k16))
    k16_i, k16_atom = k16[0]
    k16_mam, _ = mam_and_wlc("1Kgs", 16, 11, k16_i)
    k16_a = tuple(tuple(f[s] for f in feats) for s in k16_atom["slots"])
    k16_key = (tuple(sorted({lang[s] for s in k16_atom["slots"]})), C.skey(k16_atom["text"]).rstrip(C.MAQAF))
    k16_counts = Counter()
    for atoms in verse_atoms.values():
        for ba in atoms:
            if any(s in qw for s in ba["slots"]) or not C.letters(ba["text"]):
                continue
            if C.skey(ba["text"]).rstrip(C.MAQAF) == k16_key[1] and \
                    tuple(sorted({lang[s] for s in ba["slots"]})) == k16_key[0]:
                k16_counts[tuple(tuple(f[s] for f in feats) for s in ba["slots"])] += 1
    if max(k16_counts.values()) >= 5:
        raise ValueError("1 Kings 16:11's key has an analysis 5 times or more: %r" % k16_counts)

    # the masculine pronoun's slots in the three verses, and how part2_scan.py's slot-level key of
    # their written form counts its analyses (language, lex, vs, vt)
    gw0 = B.wf("g_word_utf8")
    vs_f, vt_f = B.wf("vs"), B.wf("vt")
    th_forms, th_n = set(), 0
    for osis, ch, v in (("Num", 11, 15), ("Deut", 5, 27), ("Ezek", 28, 14)):
        for s in B.slots(osis, ch, v):
            # the masculine pronoun written without the qamats of its usual atom
            if lex.get(s) == ">TH" and "\N{HEBREW POINT QAMATS}" not in gw0[s]:
                th_forms.add((lang[s], C.skey(gw0[s])))
                th_n += 1
    if len(th_forms) != 1 or th_n != 3:
        raise ValueError("the masculine pronoun's slots: %d slots, %d keys" % (th_n, len(th_forms)))
    th_slot_counts = Counter()
    for s in range(1, B.max_slot + 1):
        w_ = gw0.get(s, "")
        if s in qw or not C.letters(w_) or (lang[s], C.skey(w_)) not in th_forms:
            continue
        th_slot_counts[(lang[s], lex[s], vs_f[s], vt_f[s])] += 1
    if th_slot_counts[("Hebrew", ">TH", "NA", "NA")] != 3:
        raise ValueError("the slot-level key has %r" % th_slot_counts)

    # Deuteronomy 25:7: the atom analysed as 'refuses'
    d257 = [(i, a) for i, a in enumerate(verse_atoms[("Deut", 25, 7)]) if any(lex[s] == "M>N[" for s in a["slots"])]
    if len(d257) != 1:
        raise ValueError("Deuteronomy 25:7: %d atoms" % len(d257))
    d257_mam, d257_wlc = mam_and_wlc("Deut", 25, 7, d257[0][0])

    # the accents of the key of Test A's group 63 (nu is the analysis's fifth field)
    hand = []
    for x in index[hand_key]:
        if len(x["a"]) != 1:
            raise ValueError("group 63's key: an atom of %d slots" % len(x["a"]))
        name, disj = accent_of(x["text"], x["final"])
        hand.append((x["ref"], x["a"][0][4], name, disj))
    if {nu_ for ref, nu_, name, disj in hand} != {"sg", "du"}:
        raise ValueError("group 63's key: numbers %r" % {nu_ for ref, nu_, name, disj in hand})
    hand_sg = Counter(name for ref, nu_, name, disj in hand if nu_ == "sg")
    hand_du = [(ref, name, disj) for ref, nu_, name, disj in hand if nu_ == "du"]
    if not all(disj for ref, nu_, name, disj in hand if nu_ == "sg"):
        raise ValueError("a singular atom of group 63's key has a conjunctive accent")

    # every plural of R<=/ ('friend') with a third masculine singular suffix, by suffix
    prs_f, gw = B.wf("prs"), B.wf("g_word_utf8")
    friends = defaultdict(list)
    for s in range(1, B.max_slot + 1):
        if lex.get(s) == "R<=/" and nu.get(s) == "pl" and prs_f.get(s) in ("HW", "W"):
            book, ch, v = B.ref_of_slot[s]
            friends[(prs_f[s], heb(gw[s]))].append("%s %d:%d" % (english[C.OSIS_FROM_BHSA[book]], ch, v))

    # Daniel 5:6 and 5:9: MAM's holam haser for vav stays on the vav under bkey; the BHSA's holam moves
    ke = data["test_b_keys_equal"]
    hhv = "\N{HEBREW POINT HOLAM HASER FOR VAV}"
    if sorted(r["ref"] for r in ke) != ["Daniel 5:6", "Daniel 5:9"] or not all(
        hhv in r["mam"] and hhv not in r["bhsa"] and C.bkey(r["bhsa"]) != C.skey(r["bhsa"]) for r in ke
    ):
        raise ValueError("the atoms whose keys are equal after all are not as described")

    # ---------------------------------------------------------------- numbers
    st, sb = data["stats"], data["test_b_stats"]
    slot_b = slot_run["test_b_stats"]
    slot_a_words = sum(len(g["slots"]) for g in slot_run["test_a"])
    slot_a_groups = len(slot_run["test_a"])
    n_a = sum(len(g["atoms"]) for g in data["test_a"])
    kinds_atoms, kinds_groups = data["test_a_kinds_atoms"], data["test_a_kinds_groups"]
    new_groups = Counter(g["kind"] for g in data["test_a"] if g["new"])
    new_atoms = Counter()
    for g in data["test_a"]:
        if g["new"]:
            new_atoms[g["kind"]] += len(g["atoms"])
    cross_a = Counter()
    for sk, fate, n in data["slot_level"]["cross_a"]:
        cross_a[(sk, fate)] += n
    cross_b = {(sc, ac): n for sc, ac, n in data["slot_level"]["cross_b"]}
    me_rows = data["test_b"]["mam-elsewhere"]
    me_refs = list(dict.fromkeys(r["ref"] for r in me_rows))
    artifacts = [r for r in data["slot_level"]["mam_elsewhere_rows"] if r["atom_class"] != "mam-elsewhere"]
    unique_rows = {r["atom"]: r for r in data["test_b"]["mam-unique"]}
    png_yes = [g for g in png if JUDGE[g["n"]][1] == "yes"]
    pn_verbs = [g for g in png_yes if {d["field"] for d in g["diffs"]} == {"ps", "gn"}]
    pron = [g for g in data["test_a"] if g["kind"] == "lexeme" and any(t[0] == ">TH" for t in g["analysis"])]
    pron_atoms = sum(len(g["atoms"]) for g in pron)
    pron_refs = [r for g in pron for r in g["refs"]]
    if sorted(pron_refs) != ["Deuteronomy 5:27", "Ezekiel 28:14", "Numbers 11:15"]:
        raise ValueError("the pronoun groups are not as described: %r" % pron_refs)
    b_png = [(c, r) for c in ("mam-elsewhere", "mam-unique", "written", "neither") for r in data["test_b"][c]
             if r["mam_key_counts"] and tup(r["analysis"]) != tup(r["mam_key_counts"][0][0])
             and P.kind_of(tup(r["analysis"]), tup(r["mam_key_counts"][0][0])) == "ps/nu/gn/prs"]
    if {c for c, r in b_png} != {"neither"} or sorted(r["ref"] for c, r in b_png) != [
        "2 Samuel 20:8", "Deuteronomy 15:20", "Isaiah 31:8", "Jeremiah 11:2", "Leviticus 5:12"
    ]:
        raise ValueError("Test B's person, number, gender and suffix departures are not as described")
    lev512 = [r for c, r in b_png if r["ref"] == "Leviticus 5:12"]
    # MAM's atom has the BHSA's pointing (by bkey) at every atom of the ps/nu/gn/prs groups
    png_same = all(m is not None and C.bkey(m).rstrip(C.MAQAF) == g["key"][1] for g in png for m in g["mam"])
    if len(artifacts) != 4 or {r["atom_class"] for r in artifacts} != {"mam-unique"}:
        raise ValueError("the slot-level artifacts are not four mam-unique atoms")
    art_slots = {r["slot"] for r in artifacts}
    art_a = [(x["ref"], x["slot_kind"], x["fate"]) for x in data["slot_level"]["test_a_words"] if x["slot"] in art_slots]
    # slot-level "both" rows whose atoms are "written" or "neither": how many of those atoms have a
    # MAM pointing that no BHSA atom has
    atom_row = {}
    for c in P.CLASSES:
        for r in data["test_b"][c]:
            for s in r["slots"]:
                atom_row[s] = (c, r)
    moved = {}
    for r in slot_run["test_b"]["both"]:
        c, ar = atom_row[r["slot"]]
        if c in ("written", "neither"):
            moved[ar["atom"]] = (c, not ar["mam_key_counts"])
    moved_n = Counter(c for c, absent in moved.values())
    moved_absent = Counter(c for c, absent in moved.values() if absent)
    # noun lexemes whose gender is "unknown" in some slots and m or f in others
    sp_f, gn_f = B.wf("sp"), B.wf("gn")
    noun_gn = defaultdict(set)
    for s in range(1, B.max_slot + 1):
        if sp_f.get(s) == "subs":
            noun_gn[lex[s]].add(gn_f.get(s))
    mixed_gn = [lx for lx, gs in noun_gn.items() if "unknown" in gs and gs & {"m", "f"}]
    order = {"%s %d:%d" % (english[C.OSIS_FROM_BHSA[b]], c_, v_): ss[0] for (b, c_, v_), ss in B.verse_slots.items()}
    pron_refs = sorted(pron_refs, key=order.__getitem__)

    # ---------------------------------------------------------------- the page
    L = []
    w = L.append
    w("# Part 2, slice p2d: the two tests over atoms")
    w("")
    w("Written by Claude (Opus 5.5) on 2026-11-13, New York time, as a sub-agent of the session that "
      "wrote `README.md`, by `scripts/p2d_review.py` from `out/p2d-scan.json`. Not reviewed by a "
      "human. Nothing tracked changed. Every form here is from a transcription, the BHSA's "
      "(`g_word_utf8`) or MAM's (MAM-simple), and once WLC 4.18's, emitted by script, stripped of "
      "accents as the review's page strips its forms; nothing here says what the Leningrad Codex has.")
    w("")
    w("## The answer")
    w("")
    w("1. **Test B over atoms finds %d atoms of class mam-elsewhere, against %d slots at the slot level:** "
      "the review's three al/el corrections (%s) and Leviticus 4:35, still borderline (one atom on each side)."
      % (sb["atoms: mam-elsewhere"], slot_b["slots: mam-elsewhere"],
         ", ".join(x for x in me_refs if x != "Leviticus 4:35")))
    w("2. **The four slot-level artifacts are gone from mam-elsewhere.** %s each move to mam-unique: the "
      "BHSA's whole atom, conjunction or article included, has a pointing found nowhere else in the BHSA "
      "(a dagesh missing after the article or after the wayyiqtol's conjunction), and its analysis is the "
      "one the BHSA gives MAM's pointing of the atom. The conjunction's and the article's pataḥ already "
      "spell that analysis, so the missing dagesh changes nothing in it."
      % ", ".join(r["atom_ref"] for r in artifacts))
    w("3. **Test A over atoms flags %d atoms in %d groups, against %d slots in %d groups.** %d groups (%d "
      "atoms) depart from their key's commonest analysis only in person, number, gender or suffix, a kind "
      "that the slot-level test could not see. In none does the analysis give a person, gender or suffix "
      "that the pointing does not spell: %d groups are homographs that context decides, %d of them "
      "prefix-conjugation verbs that are second masculine and third feminine singular alike. The number "
      "departures are the ones to judge:"
      % (n_a, len(data["test_a"]), slot_a_words, slot_a_groups, len(png), sum(len(g["atoms"]) for g in png),
         len(png_yes), len(pn_verbs)))
    w("   - **1 Samuel 30:26 and Job 42:10, 'his friend' analysed as plural ('his friends').** The pointing "
      "is the same for both numbers and the letters lack the plural's yod, so the analysis gives a number "
      "that the atom spells only with an unwritten yod. The BHSA analyses %s the same way (%s, `%s`); Test A "
      "could not judge that atom: %s."
      % ("1 Kings 16:11", heb(k16_atom["text"]), P.fmt(k16_a),
         "its key, with the conjunction, has no other atom in the BHSA" if sum(k16_counts.values()) == 1 else
         "its key, with the conjunction, has %d atoms in all (%s)" % (
             sum(k16_counts.values()), ", ".join("`%s` x%d" % (P.fmt(a), n) for a, n in k16_counts.most_common()))))
    w("   - **2 Samuel 3:34, 'your hand' analysed as dual:** the pointing spells it (a segol with munaḥ, a "
      "conjunctive accent, where the singular has sheva); only the yod is unwritten. At Jeremiah 40:4 the "
      "same atom has segolta, where the segol can be the pausal singular's.")
    w("4. **Two more departures over atoms, beyond the brief, worth Ben's judgment.** The BHSA analyses the "
      "atom pointed as the feminine 'you' as the masculine 'you' (`>TH`) at %s, where a man or God is "
      "addressed; at the slot level the %d slots supported one another. And at Deuteronomy 25:7 it analyses "
      "an atom whose letters have a yod that MAM's lack as the verb 'refuses', the word MAM's letters spell."
      % (", ".join(pron_refs), pron_atoms))
    w("")
    w("## Method")
    w("")
    w("`scripts/p2d_scan_atoms.py` adapts `part2_scan.py` without editing it. Its unit is a BHSA atom "
      "(`bc_common.Bhsa.atoms`, ketiv side); %d atoms with a slot that has a qere are skipped. An atom's "
      "**pointed key** is the set of its slots' languages and `bc_common.skey` of its text, final maqaf "
      "stripped; the languages are a set, so that the number of slots belongs to the analysis. Its "
      "**analysis** is the tuple, over its slots, of `lex`, `vs`, `vt`, `ps`, `nu`, `gn` and `prs`. "
      "Support, Test A and Test B are `part2_scan.py`'s, applied to whole atoms: Test B compares the "
      "BHSA's atom with MAM's whole atom, MAM's key being `bkey` of MAM's atom, final maqaf stripped. A "
      "Test A group's kind compares its analysis with its key's commonest: **segmentation** (another "
      "number of slots), **lexeme**, **stem/tense**, or **ps/nu/gn/prs** (the same `lex`, `vs` and `vt` "
      "in every slot). In the analyses below a slot is `lex [vs vt] [ps.nu.gn] [+prs]`, with `-` for "
      "NA and `?` for unknown, and slots are joined by ` + `."
      % st["BHSA atoms with a qere slot, skipped"])
    w("")
    w("## Counts against the slot level")
    w("")
    w("| Class | Atoms | Slots at the slot level (`out/33-part2-scan-run.txt`) |")
    w("|---|---|---|")
    for cls in P.CLASSES:
        w("| %s | %d | %d |" % (cls, sb["atoms: " + cls], slot_b["slots: " + cls]))
    w("")
    w("Both runs read %d atoms, of which %d have a ketiv and %d letters that differ from MAM's atom; "
      "%d atoms have pointing that differs from MAM's. Over atoms, %d of these have equal keys after all: "
      "at Daniel 5:6 and 5:9 MAM's atom has HEBREW POINT HOLAM HASER FOR VAV on a consonantal vav, which "
      "`bkey` leaves in place, while it moves the BHSA's ḥolam on that vav to the letter before."
      % (sb["atoms"], sb["atoms with a ketiv, skipped"], sb["atoms whose letters differ from MAM's, skipped"],
         sb["atoms whose pointing differs from MAM's"], sb["atoms whose keys are equal after all"]))
    w("")
    w("Where the slot-level rows went, by the atom that holds each slot:")
    w("")
    w("| Slot-level class | Atom-level class | Slot rows |")
    w("|---|---|---|")
    for (sc, ac), n in sorted(cross_b.items()):
        w("| %s | %s | %d |" % (sc, ac, n))
    w("")
    w("A slot-level `both` becomes `mam-unique` when the BHSA's whole atom is found nowhere else though "
      "each slot's pointing is (a conjunction's unusual vowel, a dagesh missing after the article). It "
      "becomes `written` or `neither` when MAM's whole atom does not occur in the BHSA, as with MAM's "
      "ḥolam in the divine name after a preposition: so at %d of the %d such `written` atoms and %d of "
      "the %d such `neither` atoms. A slot-level `mam-unique` becomes `neither` when MAM's whole atom "
      "does not occur in the BHSA, or when the finer analysis differs, as at Leviticus 5:12 (below). "
      "Examples are in `out/p2d-class-changes.txt`."
      % (moved_absent["written"], moved_n["written"], moved_absent["neither"], moved_n["neither"]))
    w("")
    w("**Test A:** %d atoms in %d groups, against %d slots in %d groups. By kind, atoms: %s. Groups that "
      "the slot level did not flag at all: %s. Test A can judge an atom only when its key has some "
      "analysis at least 5 times: %d of %d keyed atoms, against %d of %d keyed slots at the slot level. "
      "Of the slot level's %d stem/tense words, %d are still flagged, %d lie in atoms whose key is too "
      "small to judge, and %d is supported; of its %d lexeme words, %d are still flagged (%d of them as "
      "segmentation), %d lie in atoms whose key is too small, and %d are supported."
      % (n_a, len(data["test_a"]), slot_a_words, slot_a_groups,
         ", ".join("%s %d" % (k, kinds_atoms.get(k, 0)) for k in P.KINDS),
         ", ".join("%s %d (%d atoms)" % (k, new_groups[k], new_atoms[k]) for k in P.KINDS),
         st["test A: atoms whose key has some analysis at least 5 times"], st["BHSA atoms keyed"],
         data["slot_level"]["test_a_testable_words"], data["slot_level"]["test_a_keyed_words"],
         sum(n for (sk, f), n in cross_a.items() if sk == "stem/tense"), cross_a[("stem/tense", "flagged, stem/tense")],
         cross_a[("stem/tense", "atom's key under 5")], cross_a[("stem/tense", "supported")],
         sum(n for (sk, f), n in cross_a.items() if sk == "lexeme"),
         cross_a[("lexeme", "flagged, lexeme")] + cross_a[("lexeme", "flagged, segmentation")],
         cross_a[("lexeme", "flagged, segmentation")], cross_a[("lexeme", "atom's key under 5")],
         cross_a[("lexeme", "supported")]))
    w("")
    w("## The mam-elsewhere atoms")
    w("")
    w("Each is analysed as MAM's pointing is analysed elsewhere in the BHSA, while the BHSA's own "
      "pointing is analysed otherwise elsewhere. Counts are of the BHSA's other atoms; where a count is "
      "3 or less, its references follow.")
    w("")
    w("| Verse | BHSA | MAM | BHSA's analysis | Its own key's other atoms | MAM's key's atoms in the BHSA |")
    w("|---|---|---|---|---|---|")
    for r in me_rows:
        kb = (tuple(r["bhsa_key"][0]), r["bhsa_key"][1])
        km = (tuple(r["mam_key"][0]), r["mam_key"][1])

        def cell(pairs, k, exclude_ref=None):
            out = []
            for a, n in pairs:
                s = "`%s` x%d" % (P.fmt(tup(a)), n)
                if n <= 3:
                    refs = [x for x in refs_of(k, a) if x != exclude_ref]
                    s += " (%s)" % ", ".join(refs)
                out.append(s)
            return ", ".join(out) or "none"

        w("| %s | %s | %s | %s | %s | %s |" % (
            r["ref"], heb(r["bhsa"]), heb(r["mam"]), an(r["analysis"]),
            cell(r["own"], kb, r["ref"]), cell(r["mam_key_counts"], km)))
    w("")
    w("Exodus 10:28, Judges 19:23 and Jeremiah 47:6 are the review's al/el corrections, and Part 1 "
      "reads them. Leviticus 4:35 stays borderline: the BHSA's atom has no mappiq in its final he, the "
      "pointing of the place name Helbah at its one other atom, and is analysed with the suffix that "
      "MAM's atom, with the mappiq, spells at its one other atom in the BHSA.")
    w("")
    w("## The four slot-level artifacts")
    w("")
    w("| Verse | Slot level | BHSA atom | MAM atom | BHSA's analysis | Atom level | MAM's key's atoms in the BHSA |")
    w("|---|---|---|---|---|---|---|")
    for r in artifacts:
        u = unique_rows[r["atom"]]
        w("| %s | mam-elsewhere, `%s` | %s | %s | %s | %s | %s |" % (
            r["atom_ref"], " ".join(x for x in r["slot_analysis"][1:] if x != "NA"), heb(u["bhsa"]), heb(u["mam"]),
            an(u["analysis"]), r["atom_class"], counts(u["mam_key_counts"])))
    w("")
    if not art_a or {fate for ref, kind, fate in art_a} != {"atom's key under 5"}:
        raise ValueError("the artifacts' slot-level Test A fates are not as described: %r" % art_a)
    w("Over atoms each has no other atom of its own pointing, so it is mam-unique, the class that needs a "
      "reader (like the review's Genesis 34:11). The slot-level Test A had also flagged the slots of %s "
      "(%s); over atoms their keys, each found once, are too small for Test A to judge."
      % (" and ".join([", ".join(ref for ref, k, f in art_a[:-1]), art_a[-1][0]]) if len(art_a) > 1 else art_a[0][0],
         ", ".join(sorted({kind for ref, kind, fate in art_a}))))
    w("")
    w("## Test A: departures only in person, number, gender or suffix")
    w("")
    w("All %d groups; %s. \"Spelled?\" says whether the pointing spells the person, number, gender or "
      "suffix that the BHSA gives. %s" % (
          len(png),
          "none was flagged at the slot level" if all(g["new"] for g in png) else "some were flagged at the slot level",
          "MAM's atom has the BHSA's pointing at every one of their atoms, by `bkey` (accents, and the BHSA's "
          "way of writing a ḥolam male, aside)." if png_same else
          "MAM's atom differs from the BHSA's in pointing at some of their atoms (`out/p2d-test-a.txt`)."))
    w("")
    w("| # | Verse | BHSA | BHSA's analysis | The key's analyses | Departs in (this for the key's commonest) | Spelled? | Why |")
    w("|---|---|---|---|---|---|---|---|")
    for g in sorted(png, key=lambda g: g["n"]):
        ref, verdict, why = JUDGE[g["n"]]
        depart = "; ".join("%s %s for %s" % (d["field"], d["this"], d["commonest"]) for d in g["diffs"])
        w("| A%d | %s | %s | %s | %s | %s | %s | %s |" % (
            g["n"], "; ".join(g["refs"]), C.mnorm(g["key"][1]), an(g["analysis"]), counts(g["key_counts"]),
            depart, verdict, why))
    w("")
    w("**The accents of A%d's key.** The key's %d singular atoms all have disjunctive accents (%s), where "
      "the segol under the dalet is the pausal singular's. The two dual atoms: %s."
      % (63, sum(hand_sg.values()), ", ".join("%s %d" % (k, n) for k, n in hand_sg.most_common()),
         "; ".join("%s, %s (%s)" % (ref, name, "disjunctive" if disj else "conjunctive") for ref, name, disj in hand_du)))
    w("")
    w("**The plurals of 'his friend'.** Every BHSA slot of `R<=/` that is plural with a third masculine "
      "singular suffix: %s. 1 Kings 16:11's atom is %s (MAM %s), analysed `%s`. These plurals of the suffix "
      "`HW` are the person, number, gender and suffix departures that correct the written atom: they "
      "correct its spelling, by context, not its pointing (`out/p2d-check.txt`, part 2)."
      % ("; ".join("suffix `%s`, slot %s, at %s" % (p, form, ", ".join(refs)) for (p, form), refs in sorted(friends.items())),
         heb(k16_atom["text"]), " ".join(heb(m) for m in k16_mam), P.fmt(k16_a)))
    w("")
    w("## Other things that the atom-level tests show")
    w("")
    w("1. **The segmentation kind, %d groups.**" % len(seg))
    for g in sorted(seg, key=lambda g: g["n"]):
        ref, note = SEGMENTATION[g["n"]]
        extra = ""
        if g["n"] == 43:
            extra = " MAM %s; WLC 4.18 %s." % (" ".join(heb(m) for m in d257_mam), " ".join(heb(x) for x in d257_wlc))
        w("   - A%d, %s, %s: %s; the key: %s. %s%s" % (
            g["n"], ref, C.mnorm(g["key"][1]), an(g["analysis"]), counts(g["key_counts"]), note, extra))
    pron_groups = " ".join(
        "A%d: %s, %s, key %s (%s)." % (g["n"], C.mnorm(g["key"][1]), an(g["analysis"]), counts(g["key_counts"]),
                                      "; ".join(g["refs"])) for g in pron)
    th_counts = ", ".join("`%s%s` x%d" % ("" if a[0] == "Hebrew" else "Aram ", a[1], n)
                          for a, n in th_slot_counts.most_common())
    w("2. **The pronoun 'you'.** %s The BHSA analyses the atom pointed as the feminine 'you' as the "
      "masculine (`>TH`, second masculine singular) where a man or God is addressed: Moses to God at "
      "Numbers 11:15, the people to Moses at Deuteronomy 5:27, God to the king of Tyre at Ezekiel 28:14. "
      "MAM's atoms there have the same pointing. Over slots the three supported one another: "
      "`part2_scan.py`'s key of the pronoun's slot has %s, and 3 meets the support threshold. Over atoms "
      "the conjunction at Deuteronomy 5:27 splits them. A correction of gender by context, for Ben's "
      "judgment." % (pron_groups, th_counts))
    w("3. **Test B with the finer analysis.** %d atoms of Test B depart from MAM's key's commonest analysis "
      "only in person, number, gender or suffix, all of class neither (`out/p2d-test-b-png.txt`). None is "
      "a correction toward MAM. One shows the BHSA not correcting where it corrects elsewhere: at "
      "Leviticus 5:12 its atom %s has no mappiq, MAM's %s has one, and the BHSA analyses it with no "
      "suffix (%s), following the missing mappiq, while at Leviticus 4:35 the same lack is analysed with the "
      "suffix. The others are second masculine or third feminine homographs (Deuteronomy 15:20, Isaiah "
      "31:8), a suffix written with a shuruq where MAM's has a ḥolam male (2 Samuel 20:8), and Jeremiah "
      "11:2, where the BHSA's atom is pointed and analysed as second singular with a suffix, and MAM's "
      "atom is pointed as second plural."
      % (len(b_png), heb(lev512[0]["bhsa"]), heb(lev512[0]["mam"]), an(lev512[0]["analysis"])))
    w("4. **New lexeme and stem/tense groups.** %d lexeme groups and %d stem/tense groups were not flagged at "
      "the slot level. Apart from the pronoun, read above, they were skimmed, not read one by one: they "
      "look like homographs that context decides (a name against a common noun, the ETCBC's numbered "
      "homonyms, an adjective against a participle, a niphal perfect against a qal cohortative). They "
      "are marked `(new)` in `out/p2d-test-a.txt`."
      % (new_groups["lexeme"], new_groups["stem/tense"]))
    w("")
    w("## What the atom-level tests cannot find")
    w("")
    w("1. **Less of Test A is testable.** A whole atom's key is narrower than a slot's, so fewer keys "
      "reach 5 atoms of one analysis; %d slot-level Test A words lie in atoms that are too few to judge, "
      "1 Kings 16:11's plural among them. The two runs complement each other; neither replaces the other."
      % (cross_a[("stem/tense", "atom's key under 5")] + cross_a[("lexeme", "atom's key under 5")]))
    w("2. **A conjunction or a preposition splits a key.** The same word with and without a prefix has "
      "two keys. That is what unmasks the pronoun above, and what hides 1 Kings 16:11.")
    w("3. **Test B still skips atoms whose letters differ from MAM's**, as at Deuteronomy 25:7, and the "
      "slots of a ketiv.")
    w("4. **The finer analysis splits support.** An analysis that differs only in a feature the pointing "
      "does not decide counts as another analysis. For example, %d of the BHSA's %d noun lexemes have "
      "the gender `unknown` in some slots and `m` or `f` in others (`out/p2d-check.txt`, part 6)."
      % (len(mixed_gn), len(noun_gn)))
    w("")
    w("## Files")
    w("")
    w("- `scripts/p2d_scan_atoms.py`: the scan. Its outputs: `out/p2d-scan-run.txt` (counts and the "
      "cross-tabulations against the slot level), `out/p2d-test-a.txt`, `out/p2d-test-b.txt`, "
      "`out/p2d-scan.json`, and the run's log `out/p2d-scan-log.txt`.")
    w("- `scripts/p2d_detail.py`: `out/p2d-detail-png.txt`, each ps/nu/gn/prs group with the ETCBC's "
      "morphology features and its verse, atom by atom.")
    w("- `scripts/p2d_check.py`: `out/p2d-check.txt`, the accents of the keys behind the judgments, the "
      "BHSA's plurals of 'friend', Job 33:28's ketiv and qere, and the segmentation groups' verses.")
    w("- `scripts/p2d_explore.py`: `out/p2d-class-changes.txt`; `scripts/p2d_png_b.py`: "
      "`out/p2d-test-b-png.txt`; `scripts/p2d_wait.py`, a helper that was not needed.")
    w("- `scripts/p2d_review.py`: this page.")
    (here / "out" / "p2d-review.md").write_text("\n".join(L) + "\n", encoding="utf-8", newline="\n")
    print("wrote out/p2d-review.md, %d lines" % len(L))


if __name__ == "__main__":
    main()

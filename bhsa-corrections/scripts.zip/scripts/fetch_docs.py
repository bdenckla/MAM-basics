"""Fetch pages of the ETCBC's BHSA documentation site politely, each into its own new folder.

Throwaway scratch for the brief
C:/Users/BenDe/GitRepos/MAM-basics/.novc/commander-session/bhsa-corrections-brief-2026-11-13.md.

Usage: python -I fetch_docs.py <this folder> <name>=<url> ...

Uses MAM-basics' mb_cmn.polite_download.PoliteDownloader: robots.txt obeyed, no cache, at least
3 and on average 5 seconds between requests. Each page goes to fetched/etcbc-docs-<name>/page.html
unchanged and is logged in out/fetch_log.jsonl.
"""

import datetime
import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, "C:/Users/BenDe/GitRepos/MAM-basics/py")
from mb_cmn.polite_download import (  # noqa: E402
    PoliteDownloadConfig,
    PoliteDownloader,
    ThrottleConfig,
)


def main():
    here = Path(sys.argv[1])
    log = here / "out" / "fetch_log.jsonl"
    cfg = PoliteDownloadConfig(
        user_agent="MAM-basics BHSA documentation reader",
        obey_robots_txt=True,
        throttle=ThrottleConfig(min_delay_s=3.0, mean_delay_s=5.0),
    )
    with PoliteDownloader(cfg) as dl:
        for arg in sys.argv[2:]:
            name, url = arg.split("=", 1)
            folder = here / "fetched" / ("etcbc-docs-" + name)
            folder.mkdir(parents=True, exist_ok=False)
            body = dl.get_bytes(url, allow_cache=False)
            out = folder / "page.html"
            out.write_bytes(body)
            rec = {
                "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                "kind": "polite",
                "url": url,
                "out": str(out),
                "bytes": len(body),
                "sha256": hashlib.sha256(body).hexdigest(),
            }
            with open(log, "a", encoding="utf-8", newline="\n") as f:
                f.write(json.dumps(rec) + "\n")
            print(name, len(body), flush=True)


if __name__ == "__main__":
    main()

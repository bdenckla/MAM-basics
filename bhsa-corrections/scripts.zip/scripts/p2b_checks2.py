"""Second targeted check for slice p2b (throwaway scratch).

Usage (from the MAM-basics root):
  C:/Users/BenDe/GitRepos/MAM-basics/.venv/Scripts/python.exe -I <this folder>/scripts/p2b_checks2.py

Prints, for a few rows of out/32-part2-scan.json's mam-unique class, the BHSA's slots around
the row's slot with g_word_utf8, qere_utf8, the trailer and the names of the accents, so that
a dagesh at the start of a word can be judged against the word before it. Writes
out/p2b-checks2.txt.
"""

import sys
import unicodedata
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402

HERE = Path(__file__).resolve().parent.parent
# Rows whose first letter's dagesh differs: Deuteronomy 8:20, Joshua 15:4, Psalms 83:11,
# Daniel 2:31, Numbers 19:21, Song of Songs 6:8, Psalms 59:2.
SLOTS = [98390, 121460, 324932, 371180, 82499, 358786, 320049]


def marks(w):
    return ", ".join(unicodedata.name(x).replace("HEBREW ", "").lower() for x in w
                     if "\N{HEBREW ACCENT ETNAHTA}" <= x <= "\N{HEBREW MARK MASORA CIRCLE}" or x == "\N{HEBREW POINT METEG}")


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    B = C.Bhsa()
    gw, qw, tr = B.wf("g_word_utf8"), B.wf("qere_utf8"), B.wf("trailer_utf8")
    out = []
    for s in SLOTS:
        b, ch, v = B.ref_of_slot[s]
        out.append("== slot %d, %s %d:%d" % (s, b, ch, v))
        for t in range(s - 3, s + 2):
            q = qw.get(t, "")
            out.append("  %s slot %d | g_word %s | qere %s | trailer %r | accents %s | qere accents %s" % (
                "->" if t == s else "  ", t, C.mnorm(gw.get(t, "")), C.mnorm(q), tr.get(t, ""),
                marks(gw.get(t, "")) or "-", marks(q) or "-"))
    text = "\n".join(out) + "\n"
    (HERE / "out" / "p2b-checks2.txt").write_text(text, encoding="utf-8", newline="\n")
    print(text)


if __name__ == "__main__":
    main()

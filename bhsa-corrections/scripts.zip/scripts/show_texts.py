"""Print one verse's atoms in WLC 4.18, WLC 4.20, UXLC 2.6, MAM and the BHSA, side by side by
letters.

Throwaway scratch. Usage (from the MAM-basics root): python -I show_texts.py <out txt> <OSIS>:<ch>:<v> ...
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402

SHORT_FROM_OSIS = {s.replace(" ", ""): s for s in C.ib_review.SHORT.values()}


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    out = Path(sys.argv[1])
    B = C.Bhsa()
    lint = C.load_lint()
    w420 = C.read_wlc42x("4.20")
    lines = []
    for arg in sys.argv[2:]:
        osis, ch, v = arg.split(":")
        ch, v = int(ch), int(v)
        texts = {
            "WLC 4.18": [a["text"] for a in C.wlc418_side(C.read_wlc418_book(osis)[(ch, v)], "ketiv")],
            "WLC 4.20": [a["text"] for a in C.wlc42x_side(w420[(osis, ch, v)], "ketiv")],
            "UXLC 2.6": [a["text"] for a in C.wlc418_side(C.read_wlc418_book(osis, C.UXLC26_BOOKS)[(ch, v)], "ketiv")],
            "MAM": C.mam_atoms(lint, SHORT_FROM_OSIS[osis], ch, v, "ketiv", "cant-combined", arg),
            "BHSA": [a["text"] for a in B.atoms(osis, ch, v, "hybrid")],
        }
        lines.append("== %s %d:%d" % (osis, ch, v))
        for name, atoms in texts.items():
            lines.append("  %-8s %s" % (name, " ".join(C.mnorm(a) for a in atoms)))
    out.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()

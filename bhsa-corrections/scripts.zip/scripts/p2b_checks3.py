"""Third targeted check for slice p2b (throwaway scratch).

Usage (from the MAM-basics root):
  C:/Users/BenDe/GitRepos/MAM-basics/.venv/Scripts/python.exe -I <this folder>/scripts/p2b_checks3.py

How often the BHSA 2021 has a letter with a hataf followed at once by a letter with a sheva,
the pattern of several mam-unique rows (Exodus 8:3, Leviticus 25:46, 2 Samuel 10:11, Daniel
9:19, Ezra 10:14): the number of words, of keys, and examples. Writes out/p2b-checks3.txt.
"""

import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402

HERE = Path(__file__).resolve().parent.parent
HATAFS = {"\N{HEBREW POINT HATAF SEGOL}", "\N{HEBREW POINT HATAF PATAH}", "\N{HEBREW POINT HATAF QAMATS}"}
SHEVA = "\N{HEBREW POINT SHEVA}"


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    B = C.Bhsa()
    gw, qw = B.wf("g_word_utf8"), B.wf("qere_utf8")
    lex = B.wf("lex")
    n, keys, ex = 0, Counter(), {}
    for s in range(1, B.max_slot + 1):
        w = gw.get(s, "")
        if s in qw or not C.letters(w):
            continue
        k = C.skey(w)
        cl = [(b, m) for b, m in C.clusters(k) if C.HEB_LETTER.match(b)]
        if any(set(m1) & HATAFS and SHEVA in m2 for (_, m1), (_, m2) in zip(cl, cl[1:])):
            n += 1
            keys[k] += 1
            ex.setdefault(k, s)
    out = ["words with a hataf followed at once by a sheva: %d, in %d keys" % (n, len(keys))]
    for k, c in keys.most_common(40):
        b, ch, v = B.ref_of_slot[ex[k]]
        out.append("  %s x%d (%s %d:%d, %s)" % (C.mnorm(k), c, b, ch, v, lex[ex[k]]))
    text = "\n".join(out) + "\n"
    (HERE / "out" / "p2b-checks3.txt").write_text(text, encoding="utf-8", newline="\n")
    print(text)


if __name__ == "__main__":
    main()

"""Pre-filter for Test B's class mam-unique (slice p2b): one-edit neighbours of each row's pointing.

Throwaway scratch. Usage (from the MAM-basics root):
  C:/Users/BenDe/GitRepos/MAM-basics/.venv/Scripts/python.exe -I <this folder>/scripts/p2b_prefilter.py

For each of the 184 rows of out/32-part2-scan.json ["test_b"]["mam-unique"]:
- the BHSA word's features, its atom, the atoms before and after it, its trailer and the names
  of its accents (for pausal and conjunctive-dagesh contexts);
- how the BHSA's key and MAM's key differ, letter by letter;
- every BHSA pointed key that equals the row's key after one small edit: a dagesh or mappiq
  added or removed; one vowel point removed, added or changed; a holam moved to the next or
  previous letter; a shin dot swapped for a sin dot or back, or either added or removed; a maqaf
  or space inside the word removed. The review's key drops meteg and rafeh, so an edit of
  either changes no key. Each such neighbour is reported with its analyses, counts and one
  example reference, and its relation to the row's analysis: another lexeme; another stem or
  tense; the same lexeme, stem and tense with another person, number, gender or suffix; another
  state; or the same;
- the analyses of MAM's pointing (MAM's key) in the BHSA;
- the spellings (keys) of the row's full analysis (language, lex, vs, vt, ps, nu, gn, st, prs)
  elsewhere, so that the regular spelling of the analysed form can be seen;
- the other BHSA keys with the row's letters, with their commonest analyses.

Keys are as Test B makes them: (language, bc_common.skey(g_word_utf8)) over words with letters
and no qere. Writes out/p2b-prefilter.json and out/p2b-prefilter.txt.
"""

import json
import sys
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402

HERE = Path(__file__).resolve().parent.parent
DAGESH = "\N{HEBREW POINT DAGESH OR MAPIQ}"
SHIN_DOT = "\N{HEBREW POINT SHIN DOT}"
SIN_DOT = "\N{HEBREW POINT SIN DOT}"
HOLAM = "\N{HEBREW POINT HOLAM}"
SHIN = "\N{HEBREW LETTER SHIN}"
# The vowels that can occur in a review key (qamats qatan and holam haser for vav are folded).
VOWELS = {
    "\N{HEBREW POINT SHEVA}": "sheva",
    "\N{HEBREW POINT HATAF SEGOL}": "hataf segol",
    "\N{HEBREW POINT HATAF PATAH}": "hataf patah",
    "\N{HEBREW POINT HATAF QAMATS}": "hataf qamats",
    "\N{HEBREW POINT HIRIQ}": "hiriq",
    "\N{HEBREW POINT TSERE}": "tsere",
    "\N{HEBREW POINT SEGOL}": "segol",
    "\N{HEBREW POINT PATAH}": "patah",
    "\N{HEBREW POINT QAMATS}": "qamats",
    "\N{HEBREW POINT HOLAM}": "holam",
    "\N{HEBREW POINT QUBUTS}": "qubuts",
}
MARK_NAMES = dict(VOWELS)
MARK_NAMES.update({DAGESH: "dagesh/mappiq", SHIN_DOT: "shin dot", SIN_DOT: "sin dot"})
FEATURES = [
    "g_word", "lex", "voc_lex_utf8", "gloss", "sp", "vs", "vt", "ps", "nu", "gn", "st", "prs",
    "g_pfm_utf8", "g_vbs_utf8", "g_lex_utf8", "g_vbe_utf8", "g_nme_utf8", "g_uvf_utf8", "g_prs_utf8",
]
FULL = ["language", "lex", "vs", "vt", "ps", "nu", "gn", "st", "prs"]
SEPARATORS = {C.MAQAF: "maqaf", " ": "space"}


def ref_en(B, s):
    """The slot's reference with an English book name, from bc_common's tanach.us file stems."""
    book, ch, v = B.ref_of_slot[s]
    stem = C.TANACH_US[C.OSIS_FROM_BHSA[book]]
    if stem[-2:] in ("_1", "_2"):
        stem = stem[-1] + " " + stem[:-2]
    return "%s %d:%d" % (stem.replace("_", " "), ch, v)


def key_clusters(key):
    """[(base, [marks])] of a review key; a maqaf or a space stands alone."""
    cl = C.clusters(key)
    for base, marks in cl:
        if not C.HEB_LETTER.match(base) and base not in SEPARATORS:
            raise ValueError("a key with %r: %r" % (base, key))
        if base in SEPARATORS and marks:
            raise ValueError("marks on a separator: %r" % key)
    return cl


def build(cl):
    return C.skey("".join(b + "".join(m) for b, m in cl))


def letter_label(cl, i):
    n = sum(1 for b, _ in cl[: i + 1] if C.HEB_LETTER.match(b))
    return "letter %d (%s)" % (n, unicodedata.name(cl[i][0]).replace("HEBREW LETTER ", "").lower())


def neighbours(key):
    """[(edit description, neighbour key)] for every one-edit change of a review key."""
    cl = key_clusters(key)
    out = []

    def variant(i, marks, desc):
        new = [(b, list(m)) for b, m in cl]
        new[i] = (new[i][0], marks)
        out.append((desc, build(new)))

    for i, (base, marks) in enumerate(cl):
        if base in SEPARATORS:
            new = cl[:i] + cl[i + 1 :]
            out.append(("remove the %s inside the word" % SEPARATORS[base], build(new)))
            continue
        pos = letter_label(cl, i)
        if DAGESH in marks:
            variant(i, [m for m in marks if m != DAGESH], "remove the dagesh or mappiq on %s" % pos)
        else:
            variant(i, marks + [DAGESH], "add a dagesh or mappiq on %s" % pos)
        vowels = [m for m in marks if m in VOWELS]
        for v in vowels:
            rest = [m for m in marks if m != v]
            variant(i, rest, "remove the %s on %s" % (VOWELS[v], pos))
            for w in VOWELS:
                if w not in marks:
                    variant(i, rest + [w], "%s for %s on %s" % (VOWELS[w], VOWELS[v], pos))
        for w in VOWELS:
            if w not in marks:
                variant(i, marks + [w], "add a %s on %s" % (VOWELS[w], pos))
        if base == SHIN:
            if SHIN_DOT in marks:
                variant(i, [SIN_DOT if m == SHIN_DOT else m for m in marks], "sin dot for shin dot on %s" % pos)
                variant(i, [m for m in marks if m != SHIN_DOT], "remove the shin dot on %s" % pos)
            elif SIN_DOT in marks:
                variant(i, [SHIN_DOT if m == SIN_DOT else m for m in marks], "shin dot for sin dot on %s" % pos)
                variant(i, [m for m in marks if m != SIN_DOT], "remove the sin dot on %s" % pos)
            else:
                variant(i, marks + [SHIN_DOT], "add a shin dot on %s" % pos)
                variant(i, marks + [SIN_DOT], "add a sin dot on %s" % pos)
        if HOLAM in marks:
            for j in (i - 1, i + 1):
                if 0 <= j < len(cl) and C.HEB_LETTER.match(cl[j][0]):
                    new = [(b, list(m)) for b, m in cl]
                    new[i] = (new[i][0], [m for m in new[i][1] if m != HOLAM])
                    new[j] = (new[j][0], new[j][1] + [HOLAM])
                    out.append(("holam moved from %s to %s" % (pos, letter_label(cl, j)), build(new)))
    seen, uniq = set(), []
    for desc, k in out:
        if k != key and k not in seen:
            seen.add(k)
            uniq.append((desc, k))
    return uniq


def key_diff(kb, km):
    """How two keys with the same letters differ, letter by letter."""
    lb = [(b, m) for b, m in key_clusters(kb) if C.HEB_LETTER.match(b)]
    lm = [(b, m) for b, m in key_clusters(km) if C.HEB_LETTER.match(b)]
    if [b for b, _ in lb] != [b for b, _ in lm]:
        return ["letters differ"]
    out = []
    seps_b = [b for b, _ in key_clusters(kb) if b in SEPARATORS]
    seps_m = [b for b, _ in key_clusters(km) if b in SEPARATORS]
    if seps_b != seps_m:
        out.append("separators: BHSA %s, MAM %s" % ([SEPARATORS[x] for x in seps_b], [SEPARATORS[x] for x in seps_m]))
    for i, ((b, mb), (_, mm)) in enumerate(zip(lb, lm)):
        if sorted(mb) != sorted(mm):
            name = unicodedata.name(b).replace("HEBREW LETTER ", "").lower()
            out.append("letter %d (%s): BHSA [%s], MAM [%s]" % (
                i + 1, name, ", ".join(MARK_NAMES.get(x, unicodedata.name(x)) for x in mb),
                ", ".join(MARK_NAMES.get(x, unicodedata.name(x)) for x in mm)))
    return out


def relation(row_full, other_full):
    """How a neighbour's full analysis relates to the row's."""
    r, o = dict(zip(FULL, row_full)), dict(zip(FULL, other_full))
    if (r["language"], r["lex"]) != (o["language"], o["lex"]):
        return "other lexeme"
    if (r["vs"], r["vt"]) != (o["vs"], o["vt"]):
        return "other stem/tense"
    if any(r[f] != o[f] for f in ("ps", "nu", "gn", "prs")):
        return "other person/number/gender/suffix"
    if r["st"] != o["st"]:
        return "other state"
    return "same"


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    data = json.loads((HERE / "out" / "32-part2-scan.json").read_text(encoding="utf-8"))
    rows = data["test_b"]["mam-unique"]
    if len(rows) != 184:
        raise ValueError("expected 184 rows, found %d" % len(rows))
    B = C.Bhsa()
    gw, qw, tr = B.wf("g_word_utf8"), B.wf("qere_utf8"), B.wf("trailer_utf8")
    lang, lex, vs, vt = B.wf("language"), B.wf("lex"), B.wf("vs"), B.wf("vt")
    feat = {f: B.wf(f) for f in FEATURES}

    def analysis(s):
        return (lang[s], lex[s], vs[s], vt[s])

    def full(s):
        return tuple(B.wf(f).get(s, "") for f in FULL)

    key_of = {}
    by_key = defaultdict(lambda: defaultdict(list))
    by_full = defaultdict(lambda: defaultdict(list))
    by_letters = defaultdict(Counter)
    for s in range(1, B.max_slot + 1):
        w = gw.get(s, "")
        if s in qw or not C.letters(w):
            continue
        k = (lang[s], C.skey(w))
        key_of[s] = k
        by_key[k][full(s)].append(s)
        by_full[full(s)][k[1]].append(s)
        by_letters[(lang[s], C.letters(w))][k[1]] += 1

    def fa(f):
        d = dict(zip(FULL, f))
        out = "%s%s" % ("Aram " if d["language"] == "Aramaic" else "", d["lex"])
        if d["vs"] != "NA":
            out += " %s %s" % (d["vs"], d["vt"])
        infl = [d[x] for x in ("ps", "nu", "gn") if d[x] not in ("NA", "unknown", "")]
        if infl:
            out += " " + "".join(infl)
        if d["st"] not in ("NA", ""):
            out += " st=%s" % d["st"]
        if d["prs"] not in ("absent", "n/a", ""):
            out += " prs=%s" % d["prs"]
        return out

    def analyses_of(k, row_full, exclude=None):
        out = []
        for f, slots in sorted(by_key.get(k, {}).items(), key=lambda kv: -len(kv[1])):
            ss = [s for s in slots if s != exclude]
            if ss:
                out.append({"full": list(f), "text": fa(f), "count": len(ss), "example": ref_en(B, ss[0]),
                            "example_slot": ss[0], "example_form": C.mnorm(gw[ss[0]]),
                            "relation": relation(row_full, f)})
        return out

    results = []
    lines = ["Pre-filter for Test B class mam-unique: %d rows" % len(rows), ""]
    n_flag = Counter()
    for n, r in enumerate(rows, 1):
        s = r["slot"]
        a = tuple(r["analysis"])
        if analysis(s) != a or gw[s] != r["bhsa"]:
            raise ValueError("row %d: the JSON and the BHSA disagree" % n)
        kb = key_of[s]
        if sum(len(v) for v in by_key[kb].values()) != 1:
            raise ValueError("row %d: the BHSA's key is not unique" % n)
        km = (lang[s], C.skey(r["mam_piece"]))
        rf = full(s)
        book, ch, v = B.ref_of_slot[s]
        osis = C.OSIS_FROM_BHSA[book]
        atoms = B.atoms(osis, ch, v, "ketiv")
        ai = next(i for i, x in enumerate(atoms) if s in x["slots"])
        atom = atoms[ai]
        accents = [unicodedata.name(ch_) for ch_ in gw[s]
                   if "\N{HEBREW ACCENT ETNAHTA}" <= ch_ <= "\N{HEBREW MARK MASORA CIRCLE}"
                   or ch_ == "\N{HEBREW POINT METEG}"]
        nb = []
        for desc, k in neighbours(kb[1]):
            kk = (kb[0], k)
            if kk in by_key:
                for x in analyses_of(kk, rf):
                    x["edit"] = desc
                    x["form"] = C.mnorm(k)
                    x["is_mam_key"] = kk == km
                    nb.append(x)
        mam_an = analyses_of(km, rf)
        same_full = []
        for k, slots in sorted(by_full[rf].items(), key=lambda kv: -len(kv[1])):
            ss = [t for t in slots if t != s]
            if ss:
                same_full.append({"form": C.mnorm(k), "count": len(ss), "example": ref_en(B, ss[0])})
        same_letters = []
        for k, cnt in by_letters[(lang[s], C.letters(gw[s]))].most_common():
            if k == kb[1]:
                continue
            top = analyses_of((lang[s], k), rf)[:3]
            same_letters.append({"form": C.mnorm(k), "count": cnt,
                                 "analyses": [{"text": x["text"], "count": x["count"], "example": x["example"],
                                               "relation": x["relation"]} for x in top]})
        rec = {
            "n": n, "slot": s, "ref": r["ref"], "ref_en": ref_en(B, s), "language": lang[s],
            "bhsa": C.mnorm(r["bhsa"]), "bhsa_key": C.mnorm(kb[1]),
            "mam_piece": C.mnorm(r["mam_piece"]), "mam_key": C.mnorm(km[1]), "mam_atom": C.mnorm(r["mam_atom"]),
            "bhsa_atom": C.mnorm(atom["text"]),
            "prev_atom": C.mnorm(atoms[ai - 1]["text"]) if ai > 0 else "",
            "next_atom": C.mnorm(atoms[ai + 1]["text"]) if ai + 1 < len(atoms) else "",
            "trailer": tr.get(s, ""),
            "accents": accents,
            "bhsa_atom_slots": [{"slot": t, "form": C.mnorm(gw.get(t, "")), "lex": lex[t]} for t in atom["slots"]],
            "diff": key_diff(kb[1], km[1]),
            "analysis": list(a), "full": list(rf), "analysis_text": fa(rf),
            "features": {f: feat[f].get(s, "") for f in FEATURES},
            "mam_key_in_bhsa": mam_an,
            "neighbours": nb,
            "same_full_analysis_forms": same_full[:6],
            "same_letters": same_letters[:10],
        }
        results.append(rec)
        flags = sorted({x["relation"] for x in nb if x["relation"] != "same" and x["relation"] != "other state"})
        for fl in flags:
            n_flag[fl] += 1
        f = rec["features"]
        lines.append("#%d slot %d | %s | %s" % (n, s, rec["ref_en"], rec["analysis_text"]))
        lines.append("  BHSA %s (key %s; %s) in atom %s | prev %s | next %s | trailer %r | accents %s" % (
            rec["bhsa"], rec["bhsa_key"], f["g_word"], rec["bhsa_atom"], rec["prev_atom"], rec["next_atom"],
            rec["trailer"], ", ".join(x.replace("HEBREW ", "").lower() for x in accents) or "-"))
        lines.append("  MAM  %s (key %s) in atom %s" % (rec["mam_piece"], rec["mam_key"], rec["mam_atom"]))
        lines.append("  diff: %s" % " | ".join(rec["diff"]))
        lines.append("  sp %s | gloss %s | voc_lex %s" % (f["sp"], f["gloss"], C.mnorm(f["voc_lex_utf8"])))
        lines.append("  morphemes: pfm %s | vbs %s | lex %s | vbe %s | nme %s | uvf %s | prs %s" % tuple(
            C.mnorm(f[x]) for x in ("g_pfm_utf8", "g_vbs_utf8", "g_lex_utf8", "g_vbe_utf8", "g_nme_utf8", "g_uvf_utf8", "g_prs_utf8")))
        if len(atom["slots"]) > 1:
            lines.append("  atom slots: %s" % "; ".join("%s %s" % (x["form"], x["lex"]) for x in rec["bhsa_atom_slots"]))
        lines.append("  MAM's key in BHSA: %s" % ("; ".join("%s%s x%d (%s)" % (
            "" if x["relation"] == "same" else "[%s] " % x["relation"], x["text"], x["count"], x["example"]) for x in mam_an) or "-"))
        for x in nb:
            if x["relation"] not in ("same",):
                lines.append("  NEIGHBOUR [%s]: %s | %s | %s x%d (%s)%s" % (
                    x["relation"], x["edit"], x["form"], x["text"], x["count"], x["example"],
                    " = MAM's key" if x["is_mam_key"] else ""))
        for x in nb:
            if x["relation"] == "same":
                lines.append("  neighbour same: %s | %s | %s x%d (%s)%s" % (
                    x["edit"], x["form"], x["text"], x["count"], x["example"], " = MAM's key" if x["is_mam_key"] else ""))
        lines.append("  same full analysis elsewhere: %s" % ("; ".join("%s x%d (%s)" % (
            x["form"], x["count"], x["example"]) for x in rec["same_full_analysis_forms"]) or "-"))
        lines.append("  same letters: %s" % ("; ".join("%s x%d [%s]" % (
            x["form"], x["count"], ", ".join("%s x%d %s" % (y["text"], y["count"], y["relation"]) for y in x["analyses"]))
            for x in rec["same_letters"]) or "-"))
        lines.append("")
    lines.insert(1, "rows with a neighbour of each relation: %s" % dict(n_flag))
    (HERE / "out" / "p2b-prefilter.txt").write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    (HERE / "out" / "p2b-prefilter.json").write_text(
        json.dumps(results, ensure_ascii=False, indent=1), encoding="utf-8", newline="\n")
    print(lines[0])
    print(lines[1])


if __name__ == "__main__":
    main()

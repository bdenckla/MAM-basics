"""Test B's atoms whose analysis departs from MAM's key's commonest analysis only in ps, nu, gn
or prs (slice p2d).

Throwaway scratch. Usage (from the MAM-basics root): python -I p2d_png_b.py <this folder> <out txt>

For every Test B atom of out/p2d-scan.json in a class other than "both": when MAM's key (MAM's
pointing of the atom, among the BHSA's atoms) has an analysis, and its commonest analysis has
the same lex, vs and vt in every slot as the atom's analysis but differs in ps, nu, gn or prs,
the atom is listed with its class, the fields that differ, and the BHSA's and MAM's atoms.
"""

import json
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402
import p2d_scan_atoms as P  # noqa: E402


def tup(a):
    return tuple(tuple(t) for t in a)


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    here, out = Path(sys.argv[1]), Path(sys.argv[2])
    data = json.loads((here / "out" / "p2d-scan.json").read_text(encoding="utf-8"))
    lines, n_by = [], Counter()
    for cls in ("mam-elsewhere", "mam-unique", "written", "neither"):
        for r in data["test_b"][cls]:
            if not r["mam_key_counts"]:
                continue
            a = tup(r["analysis"])
            top = tup(r["mam_key_counts"][0][0])
            if a == top or P.kind_of(a, top) != "ps/nu/gn/prs":
                continue
            diffs = P.field_diffs(a, top)
            n_by[cls] += 1
            lines.append("%s | %s | BHSA %s | MAM %s | this %s | MAM's key %s | differs: %s" % (
                cls, r["ref"], C.mnorm(r["bhsa_key"][1]), C.mnorm(r["mam_key"][1]), P.fmt(a),
                ", ".join("%s x%d" % (P.fmt(tup(x)), k) for x, k in r["mam_key_counts"]),
                "; ".join("%s %s %s (MAM's key %s)" % (d["lex"], d["field"], d["this"], d["commonest"]) for d in diffs)))
    lines.insert(0, "Test B atoms whose analysis departs from MAM's key's commonest only in ps/nu/gn/prs: %s" % dict(n_by))
    out.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print(lines[0])


if __name__ == "__main__":
    main()

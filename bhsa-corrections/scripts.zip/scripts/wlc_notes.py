"""WLC 4.18's note table (tanach.us build 24.2), from one book file's <notes>.

Throwaway scratch. Usage: python -I wlc_notes.py <out txt>
"""

import sys
import xml.etree.ElementTree as ET
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402


def main():
    root = ET.parse(C.WLC418_BOOKS / "Genesis.xml").getroot()
    lines = ["WLC 4.18 notes table, from %s" % (C.WLC418_BOOKS / "Genesis.xml").as_posix()]
    for note in root.find("notes"):
        code, gc, text = note.find("code"), note.find("gccode"), note.find("note")
        lines.append("code %s, gccode %s: %s" % (
            code.text if code is not None else "?",
            gc.text if gc is not None else "?",
            (text.text or "").strip() if text is not None else ""))
    Path(sys.argv[1]).write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()

"""Slice p2e: checks behind a few judgments (throwaway scratch).

Written by a sub-agent (slice p2e) of the session that wrote ../README.md.

Usage (from the MAM-basics root): python -I p2e_checks.py <this folder>

1. Proverbs 7:22: the BHSA's atoms with their accents; the BHSA's slots of VBX/ and VBX[ by
   pointing.
2. The preposition L with qamats and no article: the BHSA's atoms whose first slot is L, pointed
   with qamats, with no H slot, by analysis (A222, 2 Chronicles 30:10).
3. The conjunction W with patah before a guttural with a full patah, outside the wayyiqtol
   (Exodus 29:23, Daniel 5:12).
4. A43, Deuteronomy 25:7: the BHSA's slots of M>N[ by pointing and analysis.
5. A34, A40: the BHSA's slots of >TH and >T= by pointing.
6. Every candidate row's atom: whether the BHSA's atom differs from WLC 4.18's (bkey, final maqaf
   stripped), from out/p2e-candidates.json.
7. The accents of a few more atoms (Isaiah 3:6; 2 Chronicles 30:10; Ezekiel 3:10; Jeremiah 8:22).

Writes out/p2e-checks.txt.
"""

import json
import sys
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402

PATAH = "\N{HEBREW POINT PATAH}"
QAMATS = "\N{HEBREW POINT QAMATS}"
GUTTURALS = set("\N{HEBREW LETTER ALEF}\N{HEBREW LETTER HE}\N{HEBREW LETTER HET}\N{HEBREW LETTER AYIN}")
ACCENT_LO, ACCENT_HI = "\N{HEBREW ACCENT ETNAHTA}", "\N{HEBREW MARK MASORA CIRCLE}"


def accents(s):
    return [unicodedata.name(ch).replace("HEBREW ACCENT ", "").lower() for ch in s if ACCENT_LO <= ch <= ACCENT_HI]


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    here = Path(sys.argv[1])
    B = C.Bhsa()
    gw, lex, vt, vs = B.wf("g_word_utf8"), B.wf("lex"), B.wf("vt"), B.wf("vs")
    qw = B.wf("qere_utf8")
    english = {short.replace(" ", ""): name for name, short in C.ib_review.SHORT.items()}
    english["Eccl"] = "Ecclesiastes"

    def eref(ref):
        book, ch, v = ref
        return "%s %d:%d" % (english[C.OSIS_FROM_BHSA[book]], ch, v)

    def show(s):
        return C.mnorm(C.ib_review.stripped(s))

    lines = []

    # 1 ---------------------------------------------------------------- Proverbs 7:22
    lines.append("== 1. Proverbs 7:22, the BHSA's atoms with their accents")
    for a in B.atoms("Prov", 7, 22, "ketiv"):
        lines.append("  %s | accents: %s" % (C.mnorm(a["text"]), ", ".join(accents(a["text"])) or "none"))
    for lx in ("VBX/", "VBX[", "VBX=/", "VBX==/"):
        c = Counter()
        ex = {}
        for s in range(1, B.max_slot + 1):
            if lex.get(s) == lx:
                k = show(gw.get(s, ""))
                c[k] += 1
                ex.setdefault(k, eref(B.ref_of_slot[s]))
        lines.append("  %s: %s" % (lx, "; ".join("%s x%d (%s)" % (k, n, ex[k]) for k, n in c.most_common()) or "none"))

    # 2 ---------------------------------------------------------------- L with qamats, no article
    lines.append("")
    lines.append("== 2. Atoms whose first slot is L pointed with qamats and that have no H slot (preposition with qamats, no article)")
    rows = defaultdict(list)
    for ref in sorted(B.verse_slots, key=lambda r: B.verse_slots[r][0]):
        book, ch, v = ref
        for a in B.atoms(C.OSIS_FROM_BHSA[book], ch, v, "ketiv"):
            s0 = a["slots"][0]
            if lex.get(s0) != "L" or s0 in qw:
                continue
            w = C.ib_review.stripped(gw.get(s0, ""))
            if QAMATS not in w:
                continue
            if any(lex.get(s) == "H" for s in a["slots"]):
                continue
            rows[" + ".join(lex[s] for s in a["slots"])].append((eref(ref), show(a["text"])))
    total = sum(len(v) for v in rows.values())
    lines.append("  %d atoms in %d analyses (by lexemes)" % (total, len(rows)))
    for k, v in sorted(rows.items(), key=lambda kv: -len(kv[1])):
        lines.append("  %s x%d: %s" % (k, len(v), "; ".join("%s %s" % (r, t) for r, t in v[:6])))

    # 3 ---------------------------------------------------------------- W with patah before a guttural with patah
    lines.append("")
    lines.append("== 3. Atoms whose first slot is W with patah, followed by a guttural with a full patah, outside the wayyiqtol")
    hits = []
    for ref in sorted(B.verse_slots, key=lambda r: B.verse_slots[r][0]):
        book, ch, v = ref
        for a in B.atoms(C.OSIS_FROM_BHSA[book], ch, v, "ketiv"):
            s0 = a["slots"][0]
            if lex.get(s0) != "W" or len(a["slots"]) < 2:
                continue
            w = C.ib_review.stripped(gw.get(s0, ""))
            if PATAH not in w:
                continue
            if any(vt.get(s) == "wayq" for s in a["slots"]):
                continue
            cl = [x for x in C.clusters(C.ib_review.stripped(a["text"])) if C.HEB_LETTER.match(x[0])]
            if len(cl) > 1 and cl[1][0] in GUTTURALS and PATAH in cl[1][1]:
                hits.append("%s %s (%s)" % (eref(ref), show(a["text"]), " + ".join(lex[s] for s in a["slots"])))
    lines.append("  %d atoms: %s" % (len(hits), "; ".join(hits)))

    # 4 ---------------------------------------------------------------- M>N[
    lines.append("")
    lines.append("== 4. The BHSA's slots of M>N[ by pointing, stem and tense")
    c = Counter()
    ex = {}
    for s in range(1, B.max_slot + 1):
        if lex.get(s) == "M>N[":
            k = (show(gw.get(s, "")), vs.get(s), vt.get(s))
            c[k] += 1
            ex.setdefault(k, eref(B.ref_of_slot[s]))
    for k, n in c.most_common():
        lines.append("  %s %s %s x%d (%s)" % (k[0], k[1], k[2], n, ex[k]))

    # 5 ---------------------------------------------------------------- >TH and >T=
    lines.append("")
    lines.append("== 5. The BHSA's slots of >TH and >T= by pointing (ketiv slots show their unpointed letters)")
    for lx in (">TH", ">T="):
        c = Counter()
        ex = defaultdict(list)
        for s in range(1, B.max_slot + 1):
            if lex.get(s) == lx:
                k = show(gw.get(s, "")) + (" (ketiv; qere %s)" % show(qw[s]) if s in qw else "")
                c[k] += 1
                ex[k].append(eref(B.ref_of_slot[s]))
        lines.append("  %s: %s" % (lx, "; ".join("%s x%d (%s)" % (k, n, ", ".join(ex[k][:4])) for k, n in c.most_common())))

    # 6 ---------------------------------------------------------------- BHSA against WLC 4.18
    lines.append("")
    lines.append("== 6. Candidate atoms whose BHSA atom differs from WLC 4.18's aligned atom (bkey, final maqaf stripped)")
    cand = json.loads((here / "out" / "p2e-candidates.json").read_text(encoding="utf-8"))
    n_diff = 0
    for r in cand["rows"]:
        for at in r["atoms"]:
            w = at["wlc418"]
            wt = "".join(x["text"] for x in w)
            if len(w) != 1 or C.bkey(at["bhsa_raw"]).rstrip(C.MAQAF) != C.bkey(w[0]["text"]).rstrip(C.MAQAF):
                n_diff += 1
                lines.append("  %s %s | BHSA %s | WLC 4.18 %s%s" % (
                    r["id"], at["ref"], at["bhsa"], wt, " (notes %s)" % ",".join(n for x in w for n in x["notes"]) if any(x["notes"] for x in w) else ""))
    lines.append("  %d atoms differ" % n_diff)

    # 7 ---------------------------------------------------------------- accents of a few atoms
    lines.append("")
    lines.append("== 7. Accents of a few verses' atoms in the BHSA")
    for osis, ch, v in (("Isa", 3, 6), ("2Chr", 30, 10), ("Ezek", 3, 10), ("Gen", 30, 19), ("Ezek", 20, 8), ("Obad", 1, 3)):
        lines.append("  %s %d:%d" % (osis, ch, v))
        for a in B.atoms(osis, ch, v, "ketiv"):
            lines.append("    %s | %s" % (C.mnorm(a["text"]), ", ".join(accents(a["text"])) or "none"))

    text = "\n".join(lines) + "\n"
    (here / "out" / "p2e-checks.txt").write_text(text, encoding="utf-8", newline="\n")
    print(text)


if __name__ == "__main__":
    main()

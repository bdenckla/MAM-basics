"""Slice p2b: the judgments of Test B's class mam-unique, and the tables made from them.

Throwaway scratch. Usage (from the MAM-basics root), after p2b_prefilter.py, p2b_checks.py and
p2b_checks3.py:
  C:/Users/BenDe/GitRepos/MAM-basics/.venv/Scripts/python.exe -I <this folder>/scripts/p2b_judge.py

JUDG holds Claude's judgment of each of the 184 rows, keyed by the row's number in
out/35-part2-test-b-mam-unique.txt, with the row's slot (checked against the pre-filter), its
category and a reason. The reasons are English: every Hebrew form in the outputs comes from the
data, through bc_common.mnorm. Writes out/p2b-mam-unique.md and out/p2b-mam-unique.json.
"""

import json
import re
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402

HERE = Path(__file__).resolve().parent.parent
CATEGORIES = ["another-word", "no-word", "variant", "unsure"]


def read_checks():
    """Counts that some reasons cite, read from the checks' own output files."""
    text = (HERE / "out" / "p2b-checks.txt").read_text(encoding="utf-8")
    sections = {}
    for block in text.split("\n== ")[0:]:
        head, _, body = block.partition("\n")
        m = re.match(r"(?:== )?(\d+)\. ", head)
        if m:
            sections[int(m.group(1))] = body
    m1 = re.match(r"(\d+) words, (\d+) keys", sections[1])
    if not m1 or "Iob 28:27" not in sections[1]:
        raise ValueError("check 1 changed")
    tail = sections[3].split("-- any word (any analysis) whose key ends in segol + he with mappiq:\n")[1]
    seg_he = [ln for ln in tail.split("\n") if ln.strip()]
    if len(seg_he) != 1 or "Genesis 2:18" not in seg_he[0]:
        raise ValueError("check 3 changed")
    p2m = [ln for ln in sections[6].split("\n") if "perf p2sgm prs=M" in ln]
    if not any("Jeremia 11:2" in ln for ln in p2m):
        raise ValueError("check 6 changed")
    hit_maqaf = [ln for ln in sections[8].split("\n") if "hit perf" in ln]
    t3 = (HERE / "out" / "p2b-checks3.txt").read_text(encoding="utf-8").split("\n")[0]
    m3 = re.match(r"words with a hataf followed at once by a sheva: (\d+), in (\d+) keys", t3)
    return {
        "he_perf_h": int(m1.group(1)),
        "p2sgm_m_other": len(p2m) - 1,
        "hit_maqaf": len(hit_maqaf),
        "hataf_sheva_words": int(m3.group(1)),
        "hataf_sheva_keys": int(m3.group(2)),
    }


K = read_checks()
HATAF_SHEVA = (" (a hataf before a sheva, as in %d words in %d keys of the BHSA, out/p2b-checks3.txt)"
               % (K["hataf_sheva_words"], K["hataf_sheva_keys"]))
IDENTICAL = " (under the first of two identical letters)"


def hs(h, letter, extra=""):
    return "A %s under the %s where MAM has a sheva: a hataf for a sheva, a variation of the same word%s." % (h, letter, extra)


def sh(h, letter, extra=""):
    return "A sheva under the %s where MAM has a %s: a sheva for a hataf, a variation of the same word%s." % (letter, h, extra)


def hf(h, full, letter, extra=""):
    return "A %s under the %s where MAM has a full %s: the same vowel reduced, a hataf variation of the same word%s." % (
        h, letter, full, extra)


def fh(full, h, letter, extra=""):
    return "A full %s under the %s where MAM has a %s: the same vowel unreduced, a hataf variation of the same word%s." % (
        full, letter, h, extra)


def no_dagesh_sheva(letter, extra=""):
    return ("No dagesh forte in the %s with sheva, where MAM has one: the dagesh that a letter with sheva often "
            "drops; the same word%s." % (letter, extra))


def miss(v, letter, extra=""):
    return "No %s under the %s, where MAM has one%s: a missing vowel; spells no other word, and the analysis reads through it." % (
        v, letter, extra)


def miss_mappiq(letter="final he", extra=""):
    return "No mappiq in the %s, where MAM has one%s; spells no other word, and the analysis reads through it." % (letter, extra)


def final_kaf(extra=""):
    return "No sheva under the final kaf, where MAM has one%s; spells no other word, and the analysis reads through it." % extra


def furtive(letter):
    return "No furtive patah under the final %s, where MAM has one; spells no other word, and the analysis reads through it." % letter


def name_sep(sep, extra=""):
    return "The compound name written in two parts with a %s between them where MAM writes one word%s: the same name, divided." % (
        sep, extra)


def extra_dagesh(letter, extra=""):
    return "A dagesh in the %s, which MAM lacks%s; spells no other word, and the analysis reads through it." % (letter, extra)


def no_dagesh(letter, what="dagesh", extra=""):
    return "No %s in the %s, where MAM has one%s; spells no other word, and the analysis reads through it." % (what, letter, extra)


def vowel_for(bv, mv, letter, extra=""):
    return "A %s under the %s where MAM has %s%s; spells no other word, and the analysis reads through it." % (bv, letter, mv, extra)


SIN_DOT = "A sin dot on the shin where MAM has a shin dot; spells no other word, and the analysis reads through it."
TWO_SHEVAS = ("A sheva under the bet where MAM has hiriq, so that the word begins with two shevas%s; spells no other word, "
              "and the analysis reads through it.")
NO_QAMATS_HE = ("No qamats under the he of the third feminine singular suffix, where MAM has one%s; spells no other word, "
                "and the analysis, with suffix `H`, reads through it.")
WORD_DAGESH = "a word-initial dagesh lene variation; the same word."

JUDG = {
    1: (899, "variant", hs("hataf patah", "zayin")),
    2: (1007, "no-word", "A dagesh (mappiq) in the final he, which MAM lacks: the BHSA's imperfects with a third feminine "
        "singular suffix end in a he with qamats, in a qamats and a he with mappiq, or in an energic nun (a third-he "
        "verb's in segol and a he with qamats), and this is the BHSA's only word whose key ends in segol and a he "
        "with mappiq (out/p2b-checks.txt, check 3); spells no word, and the analysis, with no suffix, reads through "
        "it."),
    3: (6392, "no-word", no_dagesh("sin after the article", "dagesh forte")),
    4: (6542, "variant", name_sep("maqaf", ", and without MAM's sheva under the resh before it")),
    5: (7063, "no-word", vowel_for("tsere", "segol", "second mem", ", at etnahta; the BHSA's 60 other words of this "
                                    "preposition with this suffix have segol there (out/p2b-checks.txt, check 7)")),
    6: (8468, "variant", sh("hataf patah", "he")),
    7: (10497, "no-word", extra_dagesh("second mem")),
    8: (13000, "no-word", extra_dagesh("mem of the name's second part")),
    9: (14770, "variant", hs("hataf patah", "resh")),
    10: (18631, "no-word", NO_QAMATS_HE % " (Part 1's case 2)"),
    11: (18966, "no-word", extra_dagesh("he of the suffix `HM`")),
    12: (21819, "unsure", "A mappiq in the final he, which MAM lacks: the pointing spells the qal perfect third masculine "
         "singular with a third feminine singular object suffix ('he did it'), the pattern of `R>H[` at Job 28:27 "
         "(the BHSA's only qal perfect third masculine singular with suffix `H` of a third-he verb: %d word, "
         "out/p2b-checks.txt, check 1), while the analysis has no suffix; `<FH[` has no such perfect elsewhere in "
         "the BHSA, so this is another word only if a suffix counts as one." % K["he_perf_h"]),
    13: (23210, "variant", sh("hataf patah", "ayin")),
    14: (24253, "no-word", "No dagesh in the nun of the wayyiqtol's prefix after the conjunction's patah, where MAM has "
         "one; spells no other word, and the analysis's tense follows from the conjunction."),
    15: (25572, "no-word", extra_dagesh("tsadi")),
    16: (26204, "variant", "A dagesh in the vav, which MAM lacks: the pointing of the ETCBC's own lexeme form of this name "
         "(`voc_lex_utf8`); the same name."),
    17: (28112, "no-word", miss("qamats", "final nun", " (the third feminine plural ending)")),
    18: (28787, "no-word", TWO_SHEVAS % " after the conjunction (Part 1's case 3)"),
    19: (31150, "no-word", extra_dagesh("nun", " (no other BHSA word with these letters has a dagesh in the nun)")),
    20: (31949, "variant", fh("patah", "hataf patah", "ayin")),
    21: (32442, "variant", hf("hataf patah", "patah", "het", HATAF_SHEVA)),
    22: (32503, "variant", hs("hataf patah", "tsadi")),
    23: (36323, "no-word", miss("sheva", "mem")),
    24: (36485, "variant", no_dagesh_sheva("tsadi")),
    25: (39656, "variant", sh("hataf patah", "het")),
    26: (43587, "variant", sh("hataf patah", "het", " (in the construct, as in MAM's form)")),
    27: (48611, "no-word", SIN_DOT),
    28: (49082, "variant", fh("patah", "hataf patah", "het")),
    29: (54583, "no-word", "No mappiq in the final he, where MAM has the third feminine singular suffix; spells no word, "
         "and the analysis gives `>ZKRH/` with no suffix: it follows the missing mappiq rather than reading MAM's "
         "suffix, which Test B, comparing lexeme, stem and tense only, does not see."),
    30: (55029, "no-word", no_dagesh("bet after the silent sheva", "dagesh lene")),
    31: (59416, "no-word", vowel_for("segol", "patah", "bet", ": the first vowel of the pausal form (as at Leviticus "
                                     "14:56) with the contextual form's segol under the he, at a pashta")),
    32: (67971, "variant", hf("hataf patah", "patah", "het", HATAF_SHEVA)),
    33: (68705, "variant", "A hataf qamats under the he where MAM has a qamats qatan: the hophal's o-vowel reduced; the "
         "same word."),
    34: (70591, "variant", name_sep("maqaf")),
    35: (71373, "variant", fh("segol", "hataf segol", "alef")),
    36: (76388, "variant", hs("hataf patah", "conjunction's vav")),
    37: (76552, "variant", name_sep("space inside the BHSA's slot")),
    38: (76626, "variant", name_sep("space inside the BHSA's slot")),
    39: (80461, "variant", fh("patah", "hataf patah", "alef")),
    40: (80559, "no-word", vowel_for("segol", "patah", "resh", ", the vowel a segolate takes before a final guttural")),
    41: (80693, "variant", hs("hataf patah", "resh")),
    42: (82499, "variant", "A dagesh in the lamed, which MAM lacks, after a word ending in qamats and he with a "
         "conjunctive merkha: a conjunctive dagesh (dehiq); the same word."),
    43: (85117, "variant", hs("hataf patah", "resh")),
    44: (95637, "variant", "A segol under the nun where MAM has patah, before a maqaf: a hitpael perfect's vowel shortened "
         "before maqaf, as in the BHSA's %d other hitpael perfects third masculine singular before a maqaf, all "
         "with segol (Genesis 6:9, Deuteronomy 24:7, 1 Samuel 30:31; out/p2b-checks.txt, check 8); the same word." %
         (K["hit_maqaf"] - 1)),
    45: (98390, "variant", "No dagesh lene in the initial tav, where MAM has one, after a word ending in a consonant with "
         "a disjunctive tipeha, where the rule calls for it: " + WORD_DAGESH),
    46: (100368, "no-word", miss("sheva", "bet")),
    47: (102410, "variant", hs("hataf patah", "kaf", ", as in the BHSA's own spelling of this form with a dagesh in the "
                               "tav (Numbers 18:10 and four more)")),
    48: (107020, "no-word", extra_dagesh("shin", " (the noun 'woman' has no yod)")),
    49: (107117, "variant", fh("patah", "hataf patah", "het")),
    50: (108281, "no-word", vowel_for("patah", "segol", "he", ", which all 25 other words of this noun with a suffix "
                                       "in the BHSA have (out/p2b-checks4.txt)")),
    51: (111242, "variant", "A qamats under the bet where MAM has patah, in the last word of the verse: the pausal form; "
         "the same word."),
    52: (111670, "no-word", miss_mappiq()),
    53: (112791, "no-word", "A sheva under the final yod, which MAM lacks: the sheva of the spelling with alef, kept where "
         "no alef is written; spells no other word, and the analysis reads through it."),
    54: (119466, "variant", hs("hataf patah", "nun")),
    55: (120337, "variant", hs("hataf qamats", "nun")),
    56: (121460, "variant", "No dagesh lene in the initial tav, where MAM has one, after a word whose qere has a "
         "disjunctive tevir, where the rule calls for it: " + WORD_DAGESH),
    57: (126636, "variant", fh("segol", "hataf segol", "alef")),
    58: (129203, "variant", fh("patah", "hataf patah", "ayin")),
    59: (134096, "variant", hs("hataf patah", "first lamed", IDENTICAL)),
    60: (142834, "no-word", miss("hiriq", "he")),
    61: (143798, "variant", name_sep("maqaf")),
    62: (158444, "no-word", "A patah under the yod and a sheva under the resh where MAM has sheva and patah (Part 1's case "
         "17): the vowels exchanged, leaving three shevas in a row; spells no other word, and the analysis reads "
         "through it."),
    63: (162152, "variant", "A dagesh in the yod with sheva after the wayyiqtol's patah, which MAM lacks: the dagesh "
         "forte that such a yod often drops; the same word."),
    64: (162638, "no-word", vowel_for("segol", "tsere", "alef")),
    65: (165526, "variant", hf("hataf segol", "segol", "het", HATAF_SHEVA)),
    66: (172739, "no-word", final_kaf()),
    67: (173287, "no-word", "A shuruq in the final vav where MAM has the holam of the third masculine singular suffix; "
         "spells no other word, and the analysis reads 'his garment' through it, coding the suffix `HW` where MAM's "
         "pointing is coded `W`."),
    68: (173389, "variant", "A dagesh in the mem with sheva after the article, which MAM lacks: the dagesh forte that such "
         "a letter often drops; the same word."),
    69: (176373, "no-word", no_dagesh("yod of the name's ending", "dagesh forte")),
    70: (177571, "no-word", vowel_for("tsere", "hiriq", "gimel")),
    71: (179244, "variant", hs("hataf qamats", "mem")),
    72: (183362, "variant", sh("hataf patah", "ayin")),
    73: (200570, "no-word", "The atom has a hiriq under the preposition and a sheva under the yod where MAM has sheva and "
         "hiriq: the vowels exchanged, with a sheva under a yod that the hiriq before it would make silent; spells no "
         "other word, and the analysis reads through it."),
    74: (201936, "no-word", "A qubuts under the resh and no dot in the vav where MAM has a shuruq and a rafeh on the alef "
         "(Part 1's case 21): the u written only under the resh, which the BHSA's five other spellings with that "
         "qubuts pair with a shuruq; spells no other word, and the analysis reads through it."),
    75: (202532, "no-word", final_kaf(", before a maqaf")),
    76: (207527, "no-word", vowel_for("patah", "a silent sheva", "ayin", ": an extra vowel")),
    77: (209219, "no-word", "A sheva under the bet beside its holam, which MAM lacks: an extra vowel; spells no other "
         "word, and the analysis reads through it."),
    78: (213694, "no-word", miss_mappiq()),
    79: (216359, "no-word", furtive("het")),
    80: (216639, "no-word", miss_mappiq()),
    81: (216814, "no-word", miss("sheva", "mem")),
    82: (220573, "no-word", no_dagesh("bet after the silent sheva", "dagesh lene")),
    83: (222791, "no-word", miss("sheva", "tet")),
    84: (224917, "no-word", vowel_for("hataf qamats", "a qamats, an a-vowel", "ayin")),
    85: (226673, "no-word", furtive("ayin")),
    86: (228381, "no-word", "No sin dot on the shin, where MAM has one (Part 1's case 24); spells no other word, and the "
         "analysis reads through it."),
    87: (228396, "variant", no_dagesh_sheva("mem")),
    88: (228999, "variant", hs("hataf patah", "shin")),
    89: (234051, "no-word", SIN_DOT),
    90: (237672, "no-word", miss("sheva", "nun")),
    91: (240342, "unsure", "A qamats under the tav where MAM has segol: the pointing spells the piel perfect second "
         "masculine singular with a third masculine plural suffix, the BHSA's spelling of that form (%d other perfects "
         "second masculine singular with suffix `M`, Deuteronomy 6:7 among them; out/p2b-checks.txt, check 6), and the "
         "analysis is exactly that (`p2` `sg` `m`, suffix `M`), following the BHSA's own pointing against MAM's second "
         "masculine plural: another word but no correction, so it fits no category; Test B, comparing lexeme, stem "
         "and tense only, put it here." % K["p2sgm_m_other"]),
    92: (249131, "no-word", miss("sheva", "dalet")),
    93: (256575, "variant", name_sep("maqaf", ", and without MAM's sheva under the resh before it")),
    94: (272303, "no-word", vowel_for("hataf qamats", "a qamats", "resh", ": the reduced o of this plural belongs, if "
                                       "anywhere, to the first syllable, where MAM has a qamats qatan")),
    95: (273098, "no-word", no_dagesh("qof", "dagesh forte")),
    96: (274811, "no-word", miss("sheva", "yod")),
    97: (275082, "no-word", miss_mappiq()),
    98: (282392, "variant", sh("hataf patah", "het")),
    99: (286783, "no-word", "No dagesh forte in the nun, where MAM has one; spells no other word, and the analysis reads "
         "through it as the pronoun `HNH=` 'they', one of the two lexemes that the BHSA gives MAM's pointing."),
    100: (287454, "no-word", "A hataf qamats under the article's he where MAM has qamats; spells neither the article nor "
          "the interrogative, whose hataf is a patah, and the analysis reads through it as the article."),
    101: (291173, "no-word", NO_QAMATS_HE % " (Part 1's case 28)"),
    102: (292849, "no-word", no_dagesh("tet", "dagesh forte", " (the hitpael's assimilated tav)")),
    103: (293721, "variant", sh("hataf patah", "ayin")),
    104: (296975, "no-word", miss("hiriq", "tav")),
    105: (297889, "no-word", miss("sheva", "yod")),
    106: (298599, "variant", "A full qamats under the alef where MAM has a hataf qamats: the same o-vowel unreduced (a "
          "qamats qatan), not the hataf patah of `>NJH=/` 'mourning' (Isaiah 29:2); the same word."),
    107: (299111, "no-word", vowel_for("segol", "tsere", "vav")),
    108: (304030, "no-word", final_kaf(" (the second feminine singular suffix)")),
    109: (305204, "variant", fh("patah", "hataf patah", "he")),
    110: (306094, "no-word", no_dagesh("lamed", "dagesh forte", " (`>LH/` 'big tree' has qamats under the lamed)")),
    111: (306508, "no-word", final_kaf()),
    112: (306726, "variant", name_sep("maqaf", ", and without MAM's sheva under the resh before it")),
    113: (307828, "no-word", miss("sheva", "vav")),
    114: (312112, "variant", "A patah under the alef where MAM has segol, in the construct's closed first syllable: the "
          "a-vowel of the absolute's hataf patah (Malachi 2:13), where the BHSA's two other constructs have MAM's segol "
          "(out/p2b-checks4.txt); a variation of the same word."),
    115: (315072, "variant", hs("hataf patah", "shin")),
    116: (316024, "variant", "A hataf patah under the alef where MAM has patah, before a maqaf: the negative's a-vowel "
          "reduced, not the segol of the preposition `>L` or the tsere of `>L/` 'god'; the same word."),
    117: (319581, "variant", hs("hataf patah", "qof", ", as the BHSA has it at Psalms 55:19")),
    118: (320049, "no-word", "A dagesh in the preposition's mem, while the next slot's mem lacks the dagesh forte of the "
          "assimilated nun that MAM puts there: the dot misplaced; spells no other word, and the analysis reads "
          "through it."),
    119: (320068, "no-word", no_dagesh("zayin", "dagesh forte", " (`<Z==/` 'goat' has hiriq under the ayin)")),
    120: (321164, "no-word", furtive("het")),
    121: (321308, "variant", hs("hataf patah", "first resh", IDENTICAL)),
    122: (322775, "variant", hs("hataf patah", "resh")),
    123: (324932, "variant", "A dagesh lene in the initial dalet, which MAM lacks, after a word ending in a vowel with a "
          "conjunctive merkha, where the rule omits it: " + WORD_DAGESH),
    124: (325964, "variant", fh("segol", "hataf segol", "alef")),
    125: (333684, "variant", hs("hataf patah", "resh", ", as in the BHSA's usual spelling of this imperative (13 times, "
                                "with a dagesh in the bet)")),
    126: (334447, "no-word", no_dagesh("final kaf")),
    127: (334601, "variant", hs("hataf patah", "first nun", IDENTICAL)),
    128: (335061, "variant", hs("hataf patah", "first resh", IDENTICAL)),
    129: (335241, "variant", "A hataf patah under the yod where MAM has a sheva, and no holam where MAM has one: the "
          "Tetragrammaton pointed with the hataf patah of its reading as Adonai; the same word."),
    130: (335260, "variant", hs("hataf patah", "resh")),
    131: (336507, "no-word", "No dagesh forte in the mem, where MAM has one; with its shin dot the pointing spells no "
          "other word (with a sin dot it would be `FJM[` 'she put', 1 Samuel 19:13), and the analysis reads through it."),
    132: (338577, "variant", fh("patah", "hataf patah", "alef")),
    133: (340674, "no-word", extra_dagesh("tav")),
    134: (343091, "variant", hs("hataf patah", "bet")),
    135: (344443, "variant", hs("hataf patah", "nun")),
    136: (344682, "variant", no_dagesh_sheva("lamed")),
    137: (345255, "no-word", vowel_for("patah", "the segolate's segol", "lamed")),
    138: (349020, "no-word", final_kaf()),
    139: (349905, "no-word", SIN_DOT),
    140: (350739, "no-word", "No vowel under the conjunction's vav, where MAM has a sheva; spells no word, and the "
          "analysis reads through it."),
    141: (350876, "no-word", final_kaf()),
    142: (351883, "no-word", miss("tsere", "ayin")),
    143: (351952, "no-word", miss("sheva", "pe")),
    144: (352099, "variant", fh("patah", "hataf patah", "het", ", not the qamats of the perfect")),
    145: (352130, "no-word", miss("hiriq", "second yod", " (Part 1's case 35)")),
    146: (354794, "variant", hs("hataf qamats", "bet")),
    147: (355615, "no-word", NO_QAMATS_HE % " (Part 1's case 36)"),
    148: (356921, "no-word", "No sheva under the final tav, where MAM has one; spells no other word, and the analysis "
          "reads through it."),
    149: (358786, "no-word", "A dagesh in the initial mem with sheva, which MAM lacks, after a word with a disjunctive "
          "pashta, where no conjunctive dagesh applies; spells no other word, and the analysis reads through it."),
    150: (361175, "variant", fh("segol", "hataf segol", "alef", ", not the qamats of the infinitive absolute")),
    151: (362494, "variant", hs("hataf patah", "shin")),
    152: (363137, "no-word", furtive("ayin")),
    153: (363726, "variant", "A dagesh in the qof with sheva, which MAM lacks: the piel's dagesh forte, which a letter with "
          "sheva often drops; the same word."),
    154: (369235, "no-word", vowel_for("hataf qamats", "hataf patah", "alef", ", which the name's 29 other words in the "
                                        "BHSA have (out/p2b-checks4.txt)")),
    155: (370733, "variant", "A hataf patah under the alef where MAM has hataf segol (Aramaic): the hataf that this "
          "lexeme has in its emphatic and plural (Daniel 2:38, 4:14), where its 11 other singulars have MAM's hataf "
          "segol (out/p2b-checks4.txt); a hataf variation of the same word."),
    156: (371180, "variant", "A dagesh lene in the initial dalet, which MAM lacks, after a word ending in a vowel with a "
          "conjunctive qadma, where the rule omits it (the ETCBC's lexeme form has the dagesh): " + WORD_DAGESH),
    157: (371267, "variant", hs("hataf patah", "tav")),
    158: (371499, "no-word", vowel_for("segol", "tsere", "dalet", " (Part 1's case 39, whose analysis fits both)")),
    159: (371962, "no-word", vowel_for("tsere", "hiriq", "dalet", " (Aramaic)")),
    160: (372247, "no-word", vowel_for("qamats", "patah", "samekh")),
    161: (372328, "no-word", miss_mappiq()),
    162: (373280, "no-word", miss("sheva", "ayin")),
    163: (373651, "no-word", "A dot in the final vav (a shuruq), which MAM lacks; spells no other word, and the analysis "
          "reads through it."),
    164: (373768, "no-word", "A patah under the yod, which MAM lacks (Part 1's case 40): an extra vowel; spells no other "
          "word, and the analysis reads through it."),
    165: (374143, "no-word", miss("qamats", "vav")),
    166: (374365, "no-word", vowel_for("segol", "tsere", "yod")),
    167: (375799, "no-word", vowel_for("hiriq", "sheva", "mem")),
    168: (376204, "variant", hs("hataf patah", "qof")),
    169: (376209, "variant", hf("hataf patah", "patah", "ayin", HATAF_SHEVA)),
    170: (376622, "no-word", furtive("het")),
    171: (377857, "no-word", vowel_for("segol", "the construct's tsere", "lamed",
                                        " (the BHSA's 'my tent', `>HL/` with suffix `J`, has hiriq there)")),
    172: (382995, "variant", sh("hataf patah", "ayin")),
    173: (383045, "variant", hf("hataf patah", "patah", "ayin", HATAF_SHEVA)),
    174: (383345, "no-word", TWO_SHEVAS % ""),
    175: (384035, "no-word", miss("sheva", "yod")),
    176: (387040, "variant", hs("hataf patah", "first resh", IDENTICAL)),
    177: (388066, "no-word", "A patah under the ayin where MAM has a silent sheva, and no dagesh in the tav after it "
          "(Part 1's case 42); spells no other word, and the analysis reads the second masculine singular that the "
          "final qamats spells."),
    178: (392549, "no-word", "The hiriq under the yod where MAM has it under the vav (Part 1's case 43): a misplaced "
          "vowel; spells no other word, and the analysis reads through it."),
    179: (405019, "variant", fh("patah", "hataf patah", "het")),
    180: (406537, "variant", "A hataf qamats under the shin where MAM has a qamats qatan: the imperative's o-vowel "
          "reduced, which tells it from the perfect that MAM's pointing also spells in the BHSA; the same word."),
    181: (406787, "no-word", "No vowel under the het, where MAM has a hataf patah, and a hataf patah under the alef where "
          "MAM has patah; spells no other word, and the analysis reads through it."),
    182: (411698, "variant", hf("hataf patah", "patah", "alef", " (before the het's hataf)")),
    183: (412944, "variant", "A hataf patah under the alef and a full patah under the het, where MAM has them the other "
          "way round: the a-vowels' lengths exchanged; the same word."),
    184: (420119, "variant", hf("hataf patah", "patah", "alef", " (before the het's hataf)")),
}

HEBREW = re.compile(
    "[\N{HEBREW ACCENT ETNAHTA}-\N{HEBREW PUNCTUATION GERSHAYIM}"
    "\N{HEBREW LETTER YOD WITH HIRIQ}-\N{HEBREW LIGATURE ALEF LAMED}]"
)
DROP = re.compile(
    "["
    "\N{HEBREW ACCENT ETNAHTA}-\N{HEBREW MARK MASORA CIRCLE}"
    "\N{HEBREW POINT METEG}"
    "\N{HEBREW PUNCTUATION PASEQ}"
    "\N{HEBREW PUNCTUATION SOF PASUQ}"
    "\N{HEBREW MARK UPPER DOT}"
    "\N{HEBREW MARK LOWER DOT}"
    "\N{COMBINING GRAPHEME JOINER}"
    "\N{ZERO WIDTH NON-JOINER}"
    "\N{ZERO WIDTH JOINER}"
    "\N{LEFT-TO-RIGHT MARK}"
    "\N{RIGHT-TO-LEFT MARK}"
    "\N{WORD JOINER}"
    "\N{ZERO WIDTH NO-BREAK SPACE}"
    "]"
)


def display(s):
    """A form for the tables: accents, meteg, paseq, sof pasuq and invisible marks dropped; every
    other mark kept (rafeh, qamats qatan and holam haser for vav included); MAM-normal order."""
    return C.mnorm(DROP.sub("", s).strip())


STATE = {"a": "absolute", "c": "construct", "e": "emphatic"}


def analysis_text(rec):
    d = dict(zip(["language", "lex", "vs", "vt", "ps", "nu", "gn", "st", "prs"], rec["full"]))
    f = rec["features"]
    parts = ["%s`%s` %s" % ("Aramaic " if d["language"] == "Aramaic" else "", d["lex"], f["sp"])]
    if d["vs"] != "NA":
        parts.append("%s %s" % (d["vs"], d["vt"]))
    infl = [d[x] for x in ("ps", "nu", "gn") if d[x] not in ("NA", "unknown", "")]
    if infl:
        parts.append(" ".join(infl))
    if d["st"] in STATE:
        parts.append(STATE[d["st"]])
    if d["prs"] not in ("absent", "n/a", ""):
        parts.append("suffix `%s`" % d["prs"])
    parts.append("'%s'" % f["gloss"])
    return " ".join(parts)


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    recs = json.loads((HERE / "out" / "p2b-prefilter.json").read_text(encoding="utf-8"))
    if len(recs) != 184 or sorted(JUDG) != list(range(1, 185)):
        raise ValueError("expected 184 rows and 184 judgments")
    counts = Counter()
    rows_md, out_json = [], []
    for rec in recs:
        n = rec["n"]
        slot, cat, reason = JUDG[n]
        if slot != rec["slot"]:
            raise ValueError("row %d: judgment slot %d, pre-filter slot %d" % (n, slot, rec["slot"]))
        if cat not in CATEGORIES:
            raise ValueError("row %d: category %r" % (n, cat))
        if HEBREW.search(reason):
            raise ValueError("row %d: Hebrew in the reason" % n)
        counts[cat] += 1
        multi = len(rec["bhsa_atom_slots"]) > 1
        bhsa = display(rec["bhsa"])
        mam = display(rec["mam_piece"])
        atoms = "%s / %s" % (display(rec["bhsa_atom"]), display(rec["mam_atom"]))
        rows_md.append("| %d | %s | %s | %s | %s | %s | **%s** | %s |" % (
            n, rec["ref_en"], bhsa, mam, atoms, analysis_text(rec), cat, reason))
        other_nb = [x for x in rec["neighbours"] if x["relation"] not in ("same", "other state")]
        out_json.append({
            "n": n, "slot": slot, "ref": rec["ref_en"], "ref_bhsa": rec["ref"],
            "category": cat, "reason": reason,
            "bhsa": bhsa, "bhsa_atom": display(rec["bhsa_atom"]), "bhsa_atom_has_more_slots": multi,
            "mam_piece": mam, "mam_atom": display(rec["mam_atom"]),
            "diff": rec["diff"],
            "analysis": dict(zip(["language", "lex", "vs", "vt", "ps", "nu", "gn", "st", "prs"], rec["full"])),
            "gloss": rec["features"]["gloss"],
            "evidence": {
                "mam_key_in_bhsa": [{k: x[k] for k in ("text", "count", "example", "relation")} for x in rec["mam_key_in_bhsa"]],
                "neighbours_analysed_otherwise": [
                    {k: x[k] for k in ("edit", "form", "text", "count", "example", "relation", "is_mam_key")} for x in other_nb],
                "neighbours_analysed_alike": [
                    {k: x[k] for k in ("edit", "form", "text", "count", "example", "is_mam_key")}
                    for x in rec["neighbours"] if x["relation"] in ("same", "other state")],
                "same_full_analysis_forms": rec["same_full_analysis_forms"],
            },
        })
    head = [
        "# Test B's class mam-unique, judged: slice p2b",
        "",
        "Written by Claude (Opus 5.5) on 2026-11-13, New York time, as a sub-agent of the session that wrote this "
        "folder's README.md; generated by `scripts/p2b_judge.py` from `out/p2b-prefilter.json` "
        "(`scripts/p2b_prefilter.py`) and the checks in `out/p2b-checks*.txt` and `out/p2b-glosses.txt`. Not reviewed "
        "by a human. Every form is a transcription's: the BHSA 2021's (`g_word_utf8`) or MAM's (MAM-simple, as Test B "
        "read it). Nothing here says what the Leningrad Codex has.",
        "",
        "Each row is one BHSA word (slot) where MAM's pointing differs, the BHSA's pointing occurs nowhere else in the "
        "BHSA, and the BHSA analyses it (lexeme, stem, tense) as its words with MAM's pointing are analysed.",
        "",
        "## Counts",
        "",
        "| Category | Rows |",
        "|---|---|",
    ] + ["| %s | %d |" % (c, counts[c]) for c in CATEGORIES] + [
        "| all | %d |" % sum(counts.values()),
        "",
        "## How the rows were judged",
        "",
        "1. **Pre-filter** (`out/p2b-prefilter.txt`): every BHSA pointed key one small edit away from the row's "
        "(a dagesh or mappiq added or removed; one vowel removed, added or changed; a holam moved; a shin or sin dot "
        "changed; a maqaf or space inside the word removed; meteg and rafeh are not in the key) was looked up with "
        "its analyses. Every neighbour analysed with another lexeme, stem or tense is either MAM's own key (whose "
        "other analyses are homographs of MAM's word, such as the al/el corrections of Part 1 beside the negative) or "
        "a pointing with a vowel or dot that the BHSA's lacks (a sin dot for a shin dot, a qamats for a patah); none "
        "is spelled by the BHSA's pointing. The neighbours with another person, number, gender or suffix are likewise "
        "MAM's key or differ in such a mark; all are in `out/p2b-mam-unique.json` under `evidence`.",
        "2. **Categories.** *another-word*: the pointing is a well-formed spelling of another word attested in the "
        "BHSA, and the analysis departs from it. *no-word*: the pointing spells no word (a vowel, dagesh, mappiq, "
        "furtive patah, final kaf's sheva or shin dot missing, extra, changed or misplaced) and spells no other "
        "word; the analysis reads through it. *variant*: a legitimate variation of the same word: a hataf for a sheva "
        "or the reverse; a hataf for a full vowel of the same quality or the reverse (including a hataf before a "
        "sheva, a pattern the BHSA has in %d words); a dagesh forte omitted from, or kept in, a letter with sheva; a "
        "word-initial dagesh lene that depends on the word before; a conjunctive dagesh; a pausal or maqaf vowel; a "
        "compound name divided. *unsure*: none of these fits." % K["hataf_sheva_words"],
        "3. **Analysis column**: the BHSA's lexeme (`lex`), part of speech (`sp`), stem and tense (`vs`, `vt`), "
        "person, number and gender, state, suffix (`prs`) and gloss. MAM's form is its piece of the atom as Test B "
        "cut it, with a holam male written on the letter before the vav as the BHSA writes it; the atoms column has "
        "MAM's atom as MAM writes it. Forms are shown without accents or meteg.",
        "",
        "## The rows",
        "",
        "| # | Reference | BHSA | MAM | Atoms, BHSA / MAM | BHSA's analysis | Category | Reason |",
        "|---|---|---|---|---|---|---|---|",
    ]
    md = "\n".join(head + rows_md) + "\n"
    (HERE / "out" / "p2b-mam-unique.md").write_text(md, encoding="utf-8", newline="\n")
    (HERE / "out" / "p2b-mam-unique.json").write_text(json.dumps({
        "counts": {c: counts[c] for c in CATEGORIES},
        "checks": K,
        "rows": out_json,
    }, ensure_ascii=False, indent=1), encoding="utf-8", newline="\n")
    print(dict(counts))
    for r in out_json:
        if r["category"] in ("another-word", "unsure"):
            print(r["n"], r["ref"], r["category"], r["analysis"]["lex"], r["bhsa"], r["mam_piece"])


if __name__ == "__main__":
    main()

"""Part 2: words across the BHSA 2021 whose analysis departs from their written pointing.

Throwaway scratch for the brief
C:/Users/BenDe/GitRepos/MAM-basics/.novc/commander-session/bhsa-corrections-brief-2026-11-13.md.

Usage (from the MAM-basics root): python -I part2_scan.py <this folder>

A word is a BHSA slot with a written form (g_word_utf8) and no qere; a ketiv's slots, whose
g_word_utf8 is unpointed, are left out. Its pointed key is its language and the review's key of
its written form (accents, meteg, rafeh and the other marks the review strips, removed; each
letter's marks sorted). Its analysis is (language, lex, vs, vt): the lexeme and, for a verb,
stem and tense. For each pointed key, the analyses of all its words are counted. An analysis is
**supported** by a key when the key's words have it at least 3 times, or at least a tenth as
often as the key's commonest analysis.

Test A, independent of MAM: a word whose analysis is not supported by its own key, which has
some analysis at least 5 times: the BHSA analyses it otherwise than it analyses its pointing
nearly everywhere else.

Test B, against MAM: MAM-simple's verse (BHS versification, ketiv side, combined strand of a
dual cantillation, read by the review's lint) is aligned with the BHSA's atoms by letters. Where
an atom's letters are the same in both and the pointing differs (bc_common.bkey, so the BHSA's
way of writing a holam male does not count), MAM's atom is cut into the BHSA's slots by letter
count, and each slot whose key differs is classed by whether its analysis is supported, among
the other words of the BHSA, by its own key (excluding itself) and by MAM's key:
  mam-elsewhere: by MAM's key only, while its own key's other words have other analyses: a
    correction toward MAM's pointing;
  mam-unique: by MAM's key only, its own key having no other word: an anomalous pointing
    analysed as the word MAM has;
  written: by its own key only;
  both: by both; neither: by neither (which includes keys found nowhere else).

Writes out/30-part2-test-a.txt, out/31-part2-test-b.txt and out/32-part2-scan.json.
"""

import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402

SHORT_FROM_OSIS = {s.replace(" ", ""): s for s in C.ib_review.SHORT.values()}


def supported(counter, a):
    """Whether a key's words have analysis a often enough to count as a normal analysis of it:
    at least 3 times, or at least a tenth as often as the key's commonest analysis."""
    if not counter or counter[a] <= 0:
        return False
    return counter[a] >= 3 or counter[a] * 10 >= max(counter.values())


def fmt(a):
    lang, lex, vs, vt = a
    return "%s%s%s" % ("Aram " if lang == "Aramaic" else "", lex, "" if vs == "NA" else " %s %s" % (vs, vt))


def fmt_counter(c, n=4):
    return ", ".join("%s x%d" % (fmt(a), k) for a, k in c.most_common(n))


def ref_str(B, s):
    b, ch, v = B.ref_of_slot[s]
    return "%s %d:%d" % (b, ch, v)


def mam_pieces(mam_atom, b_slots, gw):
    """MAM's atom cut into the BHSA's slots by letter count, or None if the counts fail."""
    units = [(b, m) for b, m in C.clusters(mam_atom) if C.HEB_LETTER.match(b)]
    pieces, i = [], 0
    for s in b_slots:
        n = len(C.letters(gw.get(s, "")))
        pieces.append("".join(b + "".join(m) for b, m in units[i : i + n]))
        i += n
    return pieces if i == len(units) else None


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    here = Path(sys.argv[1])
    B = C.Bhsa()
    gw, qw = B.wf("g_word_utf8"), B.wf("qere_utf8")
    lang, lex, vs, vt = B.wf("language"), B.wf("lex"), B.wf("vs"), B.wf("vt")

    def analysis(s):
        return (lang[s], lex[s], vs[s], vt[s])

    key_of, by_key = {}, defaultdict(Counter)
    for s in range(1, B.max_slot + 1):
        w = gw.get(s, "")
        if s in qw or not C.letters(w):
            continue
        k = (lang[s], C.skey(w))
        key_of[s] = k
        by_key[k][analysis(s)] += 1

    # ---------------------------------------------------------------- test A
    flagged = defaultdict(list)
    for s, k in key_of.items():
        c, a = by_key[k], analysis(s)
        if max(c.values()) >= 5 and not supported(c, a):
            flagged[(k, a)].append(s)
    lines = ["Test A: %d words in %d groups (pointed key, analysis) whose analysis their key does not support" % (
        sum(len(v) for v in flagged.values()), len(flagged)), ""]
    kinds = Counter()
    groups = []
    for (k, a), slots in sorted(flagged.items(), key=lambda kv: kv[1][0]):
        top = by_key[k].most_common(1)[0][0]
        kind = "lexeme" if (top[0], top[1]) != (a[0], a[1]) else "stem/tense"
        kinds[kind] += len(slots)
        groups.append({"key": k, "analysis": a, "kind": kind, "slots": slots, "key_counts": by_key[k].most_common()})
        lines.append("%s | %s | this: %s x%d | key: %s | %s" % (
            kind, k, fmt(a), len(slots), fmt_counter(by_key[k]),
            "; ".join("%s slot %d" % (ref_str(B, s), s) for s in slots)))
    lines.insert(1, "by kind: %s" % dict(kinds))
    (here / "out" / "30-part2-test-a.txt").write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print(lines[0], lines[1])

    # ---------------------------------------------------------------- test B
    lint = C.load_lint()
    stats = Counter()
    rows = defaultdict(list)
    for (book, ch, v) in sorted(B.verse_slots, key=lambda r: B.verse_slots[r][0]):
        osis = C.OSIS_FROM_BHSA[book]
        where = "%s %d:%d" % (osis, ch, v)
        try:
            mam = C.mam_atoms(lint, SHORT_FROM_OSIS[osis], ch, v, "ketiv", "cant-combined", where)
        except AssertionError:
            stats["verse missing in MAM-simple"] += 1
            continue
        b_atoms = B.atoms(osis, ch, v, "ketiv")
        to_mam = C.align([a["text"] for a in b_atoms], mam)
        for i, ba in enumerate(b_atoms):
            stats["atoms"] += 1
            if any(s in qw for s in ba["slots"]):
                stats["atoms with a ketiv, skipped"] += 1
                continue
            js = to_mam[i]
            if len(js) != 1 or C.letters(mam[js[0]]) != C.letters(ba["text"]):
                stats["atoms whose letters differ from MAM's, skipped"] += 1
                continue
            m = mam[js[0]]
            if C.bkey(m).rstrip(C.MAQAF) == C.bkey(ba["text"]).rstrip(C.MAQAF):
                continue
            stats["atoms whose pointing differs from MAM's"] += 1
            pieces = mam_pieces(C.holam_to_prev(m), ba["slots"], gw)
            if pieces is None:
                stats["atoms not cut"] += 1
                continue
            for s, piece in zip(ba["slots"], pieces):
                if s not in key_of:
                    continue
                kb, km = key_of[s], (lang[s], C.skey(piece))
                if kb == km:
                    continue
                a = analysis(s)
                own = Counter(by_key[kb])
                own[a] -= 1
                own = +own
                theirs = by_key[km]
                cls = {
                    (False, True): "mam-elsewhere" if own else "mam-unique",
                    (True, False): "written",
                    (True, True): "both",
                    (False, False): "neither",
                }[(supported(own, a), supported(theirs, a))]
                stats["slots: " + cls] += 1
                rows[cls].append({
                    "slot": s, "ref": ref_str(B, s), "bhsa": gw[s], "mam_piece": piece, "mam_atom": m,
                    "analysis": a, "own": own.most_common(4), "mam_key": theirs.most_common(4),
                })
    out = ["Test B: %s" % json.dumps(dict(stats))]
    for cls in ("mam-elsewhere", "mam-unique", "written", "neither"):
        out += ["", "== %s: %d slots" % (cls, len(rows[cls]))]
        for r in rows[cls]:
            out.append("%s slot %d | BHSA %s | MAM %s (atom %s) | analysis %s | own key: %s | MAM's key: %s" % (
                r["ref"], r["slot"], r["bhsa"], r["mam_piece"], r["mam_atom"], fmt(r["analysis"]),
                fmt_counter(Counter(dict(r["own"]))), fmt_counter(Counter(dict(r["mam_key"])))))
    (here / "out" / "31-part2-test-b.txt").write_text("\n".join(out) + "\n", encoding="utf-8", newline="\n")
    (here / "out" / "32-part2-scan.json").write_text(json.dumps({
        "test_a": [{**g, "analysis": list(g["analysis"]), "key_counts": [[list(a), n] for a, n in g["key_counts"]]} for g in groups],
        "test_b_stats": dict(stats),
        "test_b": {c: [{**r, "analysis": list(r["analysis"]), "own": [[list(a), n] for a, n in r["own"]], "mam_key": [[list(a), n] for a, n in r["mam_key"]]} for r in rows[c]] for c in rows},
    }, ensure_ascii=False, indent=1), encoding="utf-8", newline="\n")
    print(out[0])
    for cls in ("mam-elsewhere", "mam-unique", "written", "both", "neither"):
        print(cls, len(rows[cls]))


if __name__ == "__main__":
    main()

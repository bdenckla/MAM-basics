"""Part 1's tables, in Markdown, from out/10-part1-cases.json, out/12-part1-hataf-ng.json and
scripts/part1_judgments.py.

Throwaway scratch. Usage: python -I part1_table.py <this folder>

Writes out/14-part1-table.md and out/15-part1-hataf-table.md. Every Hebrew form comes from the
JSON files: the review's forms as the review has them, and the BHSA's atoms stripped as the
review strips its forms (israel_bible_review_index.stripped) and put in MAM-normal mark order
for display. The raw BHSA atoms are in out/10-part1-cases.txt.
"""

import json
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402
from part1_judgments import HATAF_NOTE, JUDGMENTS  # noqa: E402


def shown(atoms):
    return C.mnorm(C.ib_review.stripped(" ".join(atoms)))


def analysis(slots):
    parts = []
    for r in slots:
        bits = ["`%s`" % r.get("lex", ""), r.get("sp", "")]
        if r.get("sp") == "verb":
            bits.append("%s %s" % (r.get("vs"), r.get("vt")))
        if r.get("prs") not in (None, "absent", "n/a"):
            bits.append("suffix `%s`" % r["prs"])
        bits.append("(%s %s)" % (r["phrase"]["typ"], r["phrase"]["function"]))
        if r.get("gloss"):
            bits.append("'%s'" % r["gloss"])
        parts.append(" ".join(bits))
    return "; ".join(parts)


def main():
    here = Path(sys.argv[1])
    data = json.loads((here / "out" / "10-part1-cases.json").read_text(encoding="utf-8"))
    if len(data) != len(JUDGMENTS):
        raise SystemExit("cases %d, judgments %d" % (len(data), len(JUDGMENTS)))
    rows = [
        "| # | Verse | Israel Bible (WLC 4.18) | MAM | BHSA | BHSA's analysis, word by word | Class | Why |",
        "|---|---|---|---|---|---|---|---|",
    ]
    classes = Counter()
    for n, res in enumerate(data, 1):
        ref, cls, note = JUDGMENTS[n]
        if ref != res["reference"]:
            raise SystemExit("case %d is %s, judged as %s" % (n, res["reference"], ref))
        side = "ketiv" if res["sides"]["ketiv"]["found"] else "qere"
        p = res["sides"][side]["places"][0]
        verse = res["reference"] + (" (qere)" if side == "qere" else "")
        rows.append("| %d | %s | %s | %s | %s | %s | **%s** | %s |" % (
            n, verse, res["ib"], res["mam"], shown(p["bhsa"]), analysis(p["bhsa_slots"]), cls, note))
        classes[cls] += 1
    (here / "out" / "14-part1-table.md").write_text("\n".join(rows) + "\n", encoding="utf-8", newline="\n")
    hataf = json.loads((here / "out" / "12-part1-hataf-ng.json").read_text(encoding="utf-8"))
    hrows = [
        "| Verse | WLC 4.18 | MAM | BHSA | BHSA's analysis, word by word | Class |",
        "|---|---|---|---|---|---|",
    ]
    seen = set()
    for rec in hataf:
        if rec["reference"] in seen:
            continue
        seen.add(rec["reference"])
        if not rec["bkey_bhsa_eq_wlc418"]:
            raise SystemExit("hataf: the BHSA differs from WLC 4.18 at %s" % rec["reference"])
        hrows.append("| %s%s | %s | %s | %s | %s | **c** |" % (
            rec["reference"], " (qere)" if rec["side"] == "qere" else "",
            shown([rec["wlc418"]]), shown([rec["mam"]]), shown(rec["bhsa"]), analysis(rec["bhsa_slots"])))
    hrows += ["", HATAF_NOTE]
    (here / "out" / "15-part1-hataf-table.md").write_text("\n".join(hrows) + "\n", encoding="utf-8", newline="\n")
    print("classes:", sorted(classes.items()), "hataf verses:", len(seen))


if __name__ == "__main__":
    main()

"""Forms of named BHSA lexemes, by pointed key and analysis, for checking slice p2c's judgments.

Throwaway scratch. Usage (from the MAM-basics root):
  python -I p2c_lexforms.py <this folder> <out txt> <lex> ...

For each lexeme: its voc_lex_utf8, gloss and part of speech; then each distinct
(review key, vs, vt, ps, nu, gn, st, prs) of its words with a count and up to three
references. Forms are emitted from the data in MAM-normal mark order.
"""

import sys
from collections import defaultdict, Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    here, out = Path(sys.argv[1]), Path(sys.argv[2])
    wanted = sys.argv[3:]
    B = C.Bhsa()
    gw, qw, lex = B.wf("g_word_utf8"), B.wf("qere_utf8"), B.wf("lex")
    f = {x: B.wf(x) for x in ("vs", "vt", "ps", "nu", "gn", "st", "prs", "voc_lex_utf8", "gloss", "sp", "language")}

    def ref(s):
        b, ch, v = B.ref_of_slot[s]
        return "%s %d:%d" % (b, ch, v)

    by_lex = defaultdict(list)
    for s, lx in lex.items():
        if lx in wanted:
            by_lex[lx].append(s)
    lines = []
    for lx in wanted:
        slots = by_lex.get(lx, [])
        lines.append("lex %s: %d words; voc_lex %s; gloss %s; sp %s; language %s" % (
            lx, len(slots),
            sorted(Counter(C.mnorm(f["voc_lex_utf8"].get(s, "")) for s in slots).items()),
            sorted(Counter(f["gloss"].get(s, "") for s in slots).items()),
            sorted(Counter(f["sp"].get(s, "") for s in slots).items()),
            sorted(Counter(f["language"].get(s, "") for s in slots).items())))
        groups = defaultdict(list)
        for s in slots:
            w = qw.get(s) or gw.get(s, "")
            tag = " (qere)" if s in qw else ""
            k = (C.mnorm(C.skey(w)) + tag,) + tuple(f[x].get(s, "") for x in ("vs", "vt", "ps", "nu", "gn", "st", "prs"))
            groups[k].append(s)
        for k, ss in sorted(groups.items(), key=lambda kv: (-len(kv[1]), kv[0])):
            lines.append("   %s | vs %s vt %s ps %s nu %s gn %s st %s prs %s | x%d | %s" % (
                k[0], k[1], k[2], k[3], k[4], k[5], k[6], k[7], len(ss), "; ".join(ref(s) for s in ss[:3])))
    out.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print("wrote", out)


if __name__ == "__main__":
    main()

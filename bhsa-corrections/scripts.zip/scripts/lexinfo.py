"""Facts about named BHSA lexemes and verses, for checking Part 1's judgments.

Throwaway scratch. Usage:
  python -I lexinfo.py <out txt> lex <lex> ... [verse <OSIS> <chapter> <verse>] ...

For each lexeme: its words' count, voc_lex_utf8, gloss, sp values, and the distinct written forms
(g_word_utf8) with counts. For each verse: every slot with its form and analysis.
"""

import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402


def main():
    out = Path(sys.argv[1])
    args = sys.argv[2:]
    B = C.Bhsa()
    lex, gw = B.wf("lex"), B.wf("g_word_utf8")
    lines = []
    i = 0
    while i < len(args):
        if args[i] == "lex":
            i += 1
            while i < len(args) and args[i] not in ("lex", "verse"):
                lx = args[i]
                slots = [s for s, v in lex.items() if v == lx]
                lines.append("lex %s: %d words; voc_lex %s; gloss %s; sp %s; language %s" % (
                    lx, len(slots),
                    sorted(Counter(B.wf("voc_lex_utf8").get(s, "") for s in slots).items()),
                    sorted(Counter(B.wf("gloss").get(s, "") for s in slots).items()),
                    sorted(Counter(B.wf("sp").get(s, "") for s in slots).items()),
                    sorted(Counter(B.wf("language").get(s, "") for s in slots).items())))
                forms = Counter(C.skey(gw.get(s, "")) for s in slots)
                lines.append("   forms by review key: %s" % sorted(forms.items(), key=lambda kv: -kv[1])[:40])
                i += 1
        elif args[i] == "verse":
            osis, ch, vs = args[i + 1], int(args[i + 2]), int(args[i + 3])
            i += 4
            lines.append("verse %s %d:%d" % (osis, ch, vs))
            for s in B.slots(osis, ch, vs):
                p, c = B.phrase_of.get(s), B.clause_of.get(s)
                lines.append("   %d %s%s | %s | %s %s %s | sp %s pdp %s | vs %s vt %s | nu %s gn %s st %s prs %s | phrase %s %s | clause %s%s" % (
                    s, gw.get(s, ""), B.wf("trailer_utf8").get(s, ""), B.wf("g_word").get(s, ""),
                    lex.get(s), B.wf("voc_lex_utf8").get(s, ""), B.wf("gloss").get(s, ""),
                    B.wf("sp").get(s), B.wf("pdp").get(s), B.wf("vs").get(s), B.wf("vt").get(s),
                    B.wf("nu").get(s), B.wf("gn").get(s), B.wf("st").get(s), B.wf("prs").get(s),
                    B.nf("typ").get(p), B.nf("function").get(p), B.nf("typ").get(c),
                    (" | qere %s" % B.wf("qere_utf8")[s]) if s in B.wf("qere_utf8") else ""))
        else:
            raise SystemExit("unknown argument %r" % args[i])
    out.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print("wrote", out)


if __name__ == "__main__":
    main()

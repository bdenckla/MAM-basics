"""The atoms around named BHSA slots, in the BHSA and in MAM, for slice p2c's judgments.

Throwaway scratch. Usage (from the MAM-basics root):
  python -I p2c_context.py <this folder> <out txt> <slot> ...

For each slot: the BHSA's verse as atoms (ketiv side, raw marks, the slot's atom marked with
brackets) and MAM's verse as atoms (MAM-simple, ketiv side, combined strand, read by the
review's lint). Forms are emitted from the data in MAM-normal mark order.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402

SHORT_FROM_OSIS = {s.replace(" ", ""): s for s in C.ib_review.SHORT.values()}


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    here, out = Path(sys.argv[1]), Path(sys.argv[2])
    slots = [int(x) for x in sys.argv[3:]]
    B = C.Bhsa()
    lint = C.load_lint()
    lines = []
    for s in slots:
        book, ch, v = B.ref_of_slot[s]
        osis = C.OSIS_FROM_BHSA[book]
        atoms = B.atoms(osis, ch, v, "ketiv")
        where = "%s %d:%d" % (osis, ch, v)
        mam = C.mam_atoms(lint, SHORT_FROM_OSIS[osis], ch, v, "ketiv", "cant-combined", where)
        lines.append("slot %d | %s" % (s, where))
        lines.append("  BHSA: %s" % " ".join(
            ("[%s]" if s in a["slots"] else "%s") % C.mnorm(a["text"]) for a in atoms))
        lines.append("  MAM:  %s" % " ".join(C.mnorm(m) for m in mam))
    out.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print("wrote", out)


if __name__ == "__main__":
    main()

"""Pre-filter for Test B's class neither (slice p2c): one-edit neighbours of each row's pointing.

Throwaway scratch. Usage (from the MAM-basics root):
  python -I p2c_prefilter.py <this folder>

For each of the 169 rows of out/32-part2-scan.json ["test_b"]["neither"]:
- the BHSA word's features, its atom, and WLC 4.18's aligned atom with its notes (evidence about
  WLC 4.18 only);
- every BHSA pointed key that equals the row's key after one small edit: a dagesh or mappiq
  added or removed; one vowel point removed, added or changed; a holam moved to the next or
  previous letter; a shin dot swapped for a sin dot or back. The review's key drops meteg, so a
  meteg edit changes no key. Each such neighbour is reported with its analyses, counts and one
  example reference, split by whether the analysis (lex, vs, vt) is the row's;
- the analyses of MAM's pointing (MAM's key) in the BHSA, with examples, flagging any other
  than the row's;
- the spellings (keys) of the row's full analysis elsewhere (language, lex, vs, vt, ps, nu,
  gn, st, prs), so that the regular spelling of the analysed form can be seen.

Writes out/p2c-prefilter.json and out/p2c-prefilter.txt. Keys are as Test B makes them:
(language, bc_common.skey(g_word_utf8)) over words with letters and no qere.
"""

import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402

DAGESH = "\N{HEBREW POINT DAGESH OR MAPIQ}"
SHIN_DOT = "\N{HEBREW POINT SHIN DOT}"
SIN_DOT = "\N{HEBREW POINT SIN DOT}"
HOLAM = "\N{HEBREW POINT HOLAM}"
# The vowels that can occur in a review key (qamats qatan and holam haser for vav are folded).
VOWELS = {
    "\N{HEBREW POINT SHEVA}": "sheva",
    "\N{HEBREW POINT HATAF SEGOL}": "hataf segol",
    "\N{HEBREW POINT HATAF PATAH}": "hataf patah",
    "\N{HEBREW POINT HATAF QAMATS}": "hataf qamats",
    "\N{HEBREW POINT HIRIQ}": "hiriq",
    "\N{HEBREW POINT TSERE}": "tsere",
    "\N{HEBREW POINT SEGOL}": "segol",
    "\N{HEBREW POINT PATAH}": "patah",
    "\N{HEBREW POINT QAMATS}": "qamats",
    "\N{HEBREW POINT HOLAM}": "holam",
    "\N{HEBREW POINT QUBUTS}": "qubuts",
}
FEATURES = [
    "g_word", "lex", "voc_lex_utf8", "gloss", "sp", "vs", "vt", "ps", "nu", "gn", "st", "prs",
    "g_pfm_utf8", "g_vbs_utf8", "g_lex_utf8", "g_vbe_utf8", "g_nme_utf8", "g_uvf_utf8", "g_prs_utf8",
]
FULL = ["language", "lex", "vs", "vt", "ps", "nu", "gn", "st", "prs"]


def letter_clusters(key):
    cl = C.clusters(key)
    for base, _ in cl:
        if not C.HEB_LETTER.match(base):
            raise ValueError("a key with a non-letter %r: %r" % (base, key))
    return cl


def build(cl):
    return C.skey("".join(b + "".join(m) for b, m in cl))


def neighbours(key):
    """[(edit description, neighbour key)] for every one-edit change of a review key."""
    cl = letter_clusters(key)
    out = []

    def variant(i, marks, desc):
        new = [(b, list(m)) for b, m in cl]
        new[i] = (new[i][0], marks)
        out.append((desc, build(new)))

    for i, (base, marks) in enumerate(cl):
        pos = "letter %d" % (i + 1)
        if DAGESH in marks:
            variant(i, [m for m in marks if m != DAGESH], "remove the dagesh or mappiq on %s" % pos)
        else:
            variant(i, marks + [DAGESH], "add a dagesh or mappiq on %s" % pos)
        vowels = [m for m in marks if m in VOWELS]
        for v in vowels:
            rest = [m for m in marks if m != v]
            variant(i, rest, "remove the %s on %s" % (VOWELS[v], pos))
            for w in VOWELS:
                if w not in marks:
                    variant(i, rest + [w], "%s for %s on %s" % (VOWELS[w], VOWELS[v], pos))
        if not vowels:
            for w in VOWELS:
                variant(i, marks + [w], "add a %s on %s" % (VOWELS[w], pos))
        if SHIN_DOT in marks:
            variant(i, [SIN_DOT if m == SHIN_DOT else m for m in marks], "sin dot for shin dot on %s" % pos)
        if SIN_DOT in marks:
            variant(i, [SHIN_DOT if m == SIN_DOT else m for m in marks], "shin dot for sin dot on %s" % pos)
        if HOLAM in marks:
            for j in (i - 1, i + 1):
                if 0 <= j < len(cl):
                    new = [(b, list(m)) for b, m in cl]
                    new[i] = (new[i][0], [m for m in new[i][1] if m != HOLAM])
                    new[j] = (new[j][0], new[j][1] + [HOLAM])
                    out.append(("holam moved from %s to letter %d" % (pos, j + 1), build(new)))
    seen, uniq = set(), []
    for desc, k in out:
        if k != key and k not in seen:
            seen.add(k)
            uniq.append((desc, k))
    return uniq


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    here = Path(sys.argv[1])
    data = json.loads((here / "out" / "32-part2-scan.json").read_text(encoding="utf-8"))
    rows = data["test_b"]["neither"]
    B = C.Bhsa()
    gw, qw = B.wf("g_word_utf8"), B.wf("qere_utf8")
    lang, lex, vs, vt = B.wf("language"), B.wf("lex"), B.wf("vs"), B.wf("vt")
    feat = {f: B.wf(f) for f in FEATURES}

    def analysis(s):
        return (lang[s], lex[s], vs[s], vt[s])

    def full(s):
        return tuple(B.wf(f).get(s, "") for f in FULL)

    def ref(s):
        b, ch, v = B.ref_of_slot[s]
        return "%s %d:%d" % (b, ch, v)

    key_of = {}
    by_key = defaultdict(lambda: defaultdict(list))
    by_full = defaultdict(lambda: defaultdict(list))
    for s in range(1, B.max_slot + 1):
        w = gw.get(s, "")
        if s in qw or not C.letters(w):
            continue
        k = (lang[s], C.skey(w))
        key_of[s] = k
        by_key[k][analysis(s)].append(s)
        by_full[full(s)][k[1]].append(s)

    def fa(a):
        lg, lx, v1, v2 = a
        return "%s%s%s" % ("Aram " if lg == "Aramaic" else "", lx, "" if v1 == "NA" else " %s %s" % (v1, v2))

    def analyses_of(k, exclude=None):
        out = []
        for a, slots in sorted(by_key.get(k, {}).items(), key=lambda kv: -len(kv[1])):
            ss = [s for s in slots if s != exclude]
            if ss:
                out.append({"analysis": list(a), "text": fa(a), "count": len(ss), "example": ref(ss[0]),
                            "example_slot": ss[0], "example_form": C.mnorm(gw[ss[0]])})
        return out

    wlc_cache = {}
    results = []
    lines = ["Pre-filter for Test B class neither: %d rows" % len(rows), ""]
    n_other = 0
    for n, r in enumerate(rows, 1):
        s = r["slot"]
        a = tuple(r["analysis"])
        if analysis(s) != a or gw[s] != r["bhsa"]:
            raise ValueError("row %d: the JSON and the BHSA disagree" % n)
        kb = key_of[s]
        km = (lang[s], C.skey(r["mam_piece"]))
        book, ch, v = B.ref_of_slot[s]
        osis = C.OSIS_FROM_BHSA[book]
        atoms = B.atoms(osis, ch, v, "ketiv")
        ai = next(i for i, x in enumerate(atoms) if s in x["slots"])
        atom = atoms[ai]
        # WLC 4.18's aligned atom, as evidence about WLC 4.18 only.
        wlc = None
        try:
            if osis not in wlc_cache:
                wlc_cache[osis] = C.read_wlc418_book(osis)
            w_atoms = C.wlc418_side(wlc_cache[osis][(ch, v)], "ketiv")
            mp = C.align([x["text"] for x in atoms], [x["text"] for x in w_atoms])
            wlc = [{"text": C.mnorm(w_atoms[j]["text"]), "notes": w_atoms[j]["notes"], "tag": w_atoms[j]["tag"]}
                   for j in mp[ai]]
        except KeyError as e:
            wlc = "not found: %r" % (e,)
        nb = []
        for desc, k in neighbours(kb[1]):
            kk = (kb[0], k)
            if kk in by_key:
                for x in analyses_of(kk):
                    x["edit"] = desc
                    x["form"] = C.mnorm(k)
                    x["other"] = tuple(x["analysis"]) != a
                    nb.append(x)
        mam_an = analyses_of(km)
        for x in mam_an:
            x["other"] = tuple(x["analysis"]) != a
        same_full = []
        for k, slots in sorted(by_full[full(s)].items(), key=lambda kv: -len(kv[1])):
            ss = [t for t in slots if t != s]
            if ss:
                same_full.append({"form": C.mnorm(k), "count": len(ss), "example": ref(ss[0])})
        rec = {
            "n": n, "slot": s, "ref": r["ref"], "language": lang[s],
            "bhsa": C.mnorm(r["bhsa"]), "bhsa_key": C.mnorm(kb[1]),
            "mam_piece": C.mnorm(r["mam_piece"]), "mam_key": C.mnorm(km[1]), "mam_atom": C.mnorm(r["mam_atom"]),
            "bhsa_atom": C.mnorm(atom["text"]),
            "bhsa_atom_slots": [{"slot": t, "form": C.mnorm(gw.get(t, "")), "lex": lex[t], "g_word": feat["g_word"].get(t, "")}
                                for t in atom["slots"]],
            "wlc418": wlc,
            "analysis": list(a), "analysis_text": fa(a),
            "features": {f: feat[f].get(s, "") for f in FEATURES},
            "own_elsewhere": analyses_of(kb, exclude=s),
            "mam_key_in_bhsa": mam_an,
            "neighbours": nb,
            "same_full_analysis_forms": same_full[:6],
        }
        results.append(rec)
        other_nb = [x for x in nb if x["other"]]
        if other_nb:
            n_other += 1
        f = rec["features"]
        lines.append("#%d slot %d | %s | %s" % (n, s, r["ref"], rec["analysis_text"]))
        lines.append("  BHSA %s (key %s; %s) in atom %s" % (rec["bhsa"], rec["bhsa_key"], f["g_word"], rec["bhsa_atom"]))
        lines.append("  MAM  %s (key %s) in atom %s" % (rec["mam_piece"], rec["mam_key"], rec["mam_atom"]))
        if isinstance(wlc, list):
            lines.append("  WLC 4.18: %s" % "; ".join("%s%s" % (x["text"], (" notes " + ",".join(x["notes"])) if x["notes"] else "") for x in wlc))
        else:
            lines.append("  WLC 4.18: %s" % wlc)
        lines.append("  %s | sp %s ps %s nu %s gn %s st %s prs %s | gloss %s | voc_lex %s" % (
            f["lex"], f["sp"], f["ps"], f["nu"], f["gn"], f["st"], f["prs"], f["gloss"], C.mnorm(f["voc_lex_utf8"])))
        lines.append("  morphemes: pfm %s | vbs %s | lex %s | vbe %s | nme %s | uvf %s | prs %s" % tuple(
            C.mnorm(f[x]) for x in ("g_pfm_utf8", "g_vbs_utf8", "g_lex_utf8", "g_vbe_utf8", "g_nme_utf8", "g_uvf_utf8", "g_prs_utf8")))
        if len(atom["slots"]) > 1:
            lines.append("  atom slots: %s" % "; ".join("%s %s" % (x["form"], x["lex"]) for x in rec["bhsa_atom_slots"]))
        lines.append("  own key elsewhere: %s" % ("; ".join("%s x%d (%s)" % (x["text"], x["count"], x["example"]) for x in rec["own_elsewhere"]) or "-"))
        lines.append("  MAM's key in BHSA: %s" % ("; ".join("%s%s x%d (%s)" % ("OTHER " if x["other"] else "", x["text"], x["count"], x["example"]) for x in mam_an) or "-"))
        for x in other_nb:
            lines.append("  NEIGHBOUR OTHER: %s | %s | %s x%d (%s)" % (x["edit"], x["form"], x["text"], x["count"], x["example"]))
        for x in nb:
            if not x["other"]:
                lines.append("  neighbour same: %s | %s | %s x%d (%s)" % (x["edit"], x["form"], x["text"], x["count"], x["example"]))
        lines.append("  same full analysis elsewhere: %s" % ("; ".join("%s x%d (%s)" % (x["form"], x["count"], x["example"]) for x in rec["same_full_analysis_forms"]) or "-"))
        lines.append("")
    lines.insert(1, "rows with a neighbour analysed otherwise: %d" % n_other)
    (here / "out" / "p2c-prefilter.txt").write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    (here / "out" / "p2c-prefilter.json").write_text(
        json.dumps(results, ensure_ascii=False, indent=1), encoding="utf-8", newline="\n")
    print(lines[0])
    print(lines[1])


if __name__ == "__main__":
    main()

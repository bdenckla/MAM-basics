import json
import sys

sys.path.insert(0, "C:/Users/BenDe/GitRepos/MAM-basics/.novc/bhsa-corrections-2026-11-13/scripts")
import bc_common as C  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8")
data = json.load(open(sys.argv[1], encoding="utf-8"))
bad = 0
for n, res in enumerate(data, 1):
    for side, s in res["sides"].items():
        if not s["found"]:
            continue
        for p in s["places"]:
            lb = C.letters("".join(p["bhsa"]))
            lw = C.letters("".join(a["text"] for a in p["wlc418"]))
            if not p["bhsa"] or lb != lw:
                bad += 1
                print(n, res["reference"], side, "BHSA letters", lb, "WLC letters", lw)
print("mismatches:", bad)

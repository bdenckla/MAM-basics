"""Census of the fetched BHSA 2021 features: headers, value sets, trailers, ketiv/qere.

Throwaway scratch. Usage: python -I census.py <out file>
"""

import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402

SMALL = ["sp", "pdp", "vs", "vt", "language", "ls", "st", "ps", "nu", "gn", "prs", "nme", "pfm", "vbs", "vbe", "uvf"]


def main():
    out = Path(sys.argv[1])
    B = C.Bhsa()
    lines = ["node types: %r" % B.types, ""]
    fetched = sorted(p for p in (C.HERE / "fetched").iterdir() if p.name.startswith("etcbc-bhsa-2021-"))
    lines.append("Feature headers (description, valueType):")
    for p in fetched:
        name = p.name[len("etcbc-bhsa-2021-") :]
        h = C.header(C.feature_path(name))
        lines.append("  %s: %s | %s" % (name, h.get("description", ""), h.get("valueType", h.get("edgeValues", ""))))
    lines.append("")
    lines.append("otext.tf:")
    lines += ["  " + x for x in C.feature_path("otext").read_text(encoding="utf-8").split("\n")]
    gw = B.wf("g_word_utf8")
    lines.append("")
    lines.append("slots %d; slots with g_word_utf8 %d; empty g_word_utf8 %d" % (
        B.max_slot, len(gw), sum(1 for s in range(1, B.max_slot + 1) if gw.get(s, "") == "")))
    for name in ("trailer_utf8", "qere_trailer_utf8"):
        c = Counter(B.wf(name).values())
        lines.append("%s values: %s" % (name, sorted(((repr(k), n) for k, n in c.items()), key=lambda x: -x[1])))
    for name in SMALL:
        c = Counter(B.wf(name).values())
        lines.append("%s (%d slots): %s" % (name, sum(c.values()), sorted(c.items(), key=lambda x: -x[1])))
    qw, kq = B.wf("qere_utf8"), B.wf("kq_hybrid_utf8")
    lines.append("")
    lines.append("qere_utf8 on %d slots; kq_hybrid_utf8 on %d slots; both %d" % (len(qw), len(kq), len(set(qw) & set(kq))))
    lines.append("First 40 slots with qere_utf8: ref | g_word_utf8 | qere_utf8 | kq_hybrid_utf8 | g_word | qere | kq_hybrid | lex")
    q_ascii, kq_ascii, g_ascii, lex = B.wf("qere"), B.wf("kq_hybrid"), B.wf("g_word"), B.wf("lex")
    for s in sorted(qw)[:40]:
        lines.append("  %s %d | %s | %s | %s | %s | %s | %s | %s" % (
            B.ref_of_slot[s], s, gw.get(s, ""), qw[s], kq.get(s, ""), g_ascii.get(s, ""), q_ascii.get(s, ""), kq_ascii.get(s, ""), lex.get(s, "")))
    only_kq = sorted(set(kq) - set(qw))
    lines.append("kq_hybrid without qere: %d; first 20:" % len(only_kq))
    for s in only_kq[:20]:
        lines.append("  %s %d | %s | %s | %s" % (B.ref_of_slot[s], s, gw.get(s, ""), kq[s], g_ascii.get(s, "")))
    out.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print("wrote", out)


if __name__ == "__main__":
    main()

"""Fetch named BHSA Text-Fabric feature files, one request at a time, and check each.

Throwaway scratch for the brief
C:/Users/BenDe/GitRepos/MAM-basics/.novc/commander-session/bhsa-corrections-brief-2026-11-13.md.
Adapted from the MACULA session's scripts/fetch_bhsa_features.py.

Usage: python -I fetch_bhsa_features.py <this folder> <commit> <version> <feature> ...

Each feature `<f>` is fetched from ETCBC/bhsa at `<commit>`, path `tf/<version>/<f>.tf`, by one
read-only `gh api` GET (scripts/gh_fetch.py), into its own new folder
`fetched/etcbc-bhsa-<version>-<f>/`, and logged in `out/fetch_log.jsonl`. Its size and Git blob
SHA-1 must equal those of the tf/<version> listing in `fetched/etcbc-bhsa-tf<version>-listing/`.
"""

import hashlib
import json
import subprocess
import sys
from pathlib import Path


def git_blob_sha1(data):
    h = hashlib.sha1()
    h.update(b"blob %d\0" % len(data))
    h.update(data)
    return h.hexdigest()


def main():
    here = Path(sys.argv[1])
    commit, version = sys.argv[2], sys.argv[3]
    fetcher = here / "scripts" / "gh_fetch.py"
    log = here / "out" / "fetch_log.jsonl"
    listing_path = here / "fetched" / ("etcbc-bhsa-tf%s-listing" % version) / "contents.json"
    by_name = {e["name"]: e for e in json.loads(listing_path.read_text(encoding="utf-8"))}
    for feature in sys.argv[4:]:
        entry = by_name[feature + ".tf"]
        folder = here / "fetched" / ("etcbc-bhsa-%s-%s" % (version, feature))
        folder.mkdir(parents=True, exist_ok=False)
        out = folder / (feature + ".tf")
        cmd = [sys.executable, "-I", str(fetcher), "raw", "ETCBC/bhsa", commit]
        cmd += ["tf/%s/%s.tf" % (version, feature), str(out), str(log)]
        subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL)
        data = out.read_bytes()
        sha = git_blob_sha1(data)
        ok = len(data) == entry["size"] and sha == entry["sha"]
        print(feature, len(data), sha, "OK" if ok else "MISMATCH", flush=True)
        if not ok:
            raise SystemExit("mismatch against the listing: %s" % feature)


if __name__ == "__main__":
    main()

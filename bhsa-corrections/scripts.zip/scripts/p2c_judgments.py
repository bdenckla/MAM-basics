"""Slice p2c's judgments of Test B's class neither: one category and one reason per slot.

Throwaway scratch, imported by p2c_table.py. Written by Claude (Opus 5.5), 2026-11-13, from
out/p2c-prefilter.txt, out/p2c-lexforms.txt, out/p2c-context.txt and out/p2c-slots.txt.

A reason names no Hebrew form by hand. "{slot|N}" stands for BHSA slot N's written form (its
qere where it has one), which p2c_table.py emits from the data, accents removed, in MAM-normal
mark order.

Categories:
  another-word: the BHSA's pointing is a well-formed spelling of another attested word (another
    lexeme, or another stem, tense or person of the same lexeme), and the analysis departs from it.
  follows-pointing: the analysis is what the BHSA's own pointing spells, while MAM's pointing
    would have another analysis.
  no-word: the BHSA's pointing breaks a rule of Tiberian pointing (it lacks a vowel, a mappiq,
    a dagesh forte or a word-internal dagesh lene that the word needs, or it has a ḥataf vowel
    in a closed syllable or a mark where none can stand), and the analysis reads the regular
    word through it.
  variant: the BHSA's pointing is a regular or recognized spelling of the analysed word, and
    the difference from MAM is one of spelling.
  unsure.
"""

CATEGORIES = ("another-word", "follows-pointing", "no-word", "variant", "unsure")

HATAF_VOCAL = (
    "The BHSA has a ḥataf vowel where MAM has a sheva, a ḥataf marking a vocal shewa under a "
    "letter that is not a guttural; both pointings spell the analysed word."
)
MAM_HATAF = (
    "MAM has a ḥataf vowel under a letter that is not a guttural where the BHSA has the full "
    "vowel of the regular spelling; both pointings spell the analysed word (one of the six "
    "verses of the review's footnote on such ḥataf vowels)."
)
FULL_FOR_HATAF = (
    "The BHSA has a full vowel under the guttural where MAM has the ḥataf vowel of the same "
    "quality; both pointings spell the analysed word."
)
HATAF_CLOSED = (
    "The BHSA has a ḥataf vowel in a syllable that the next letter's sheva closes, which no "
    "Tiberian word has; the analysis reads the word as MAM's pointing spells it, with the "
    "regular syllable."
)
HATAF_DOUBLED = (
    "The BHSA has a ḥataf vowel before a letter with dagesh forte, whose doubling closes the "
    "syllable, which no Tiberian word has; the analysis reads the word as MAM's pointing spells "
    "it, with a full vowel."
)
WAYQ_DAGESH = (
    "The slot lacks the dagesh forte that the wayyiqtol's prefix takes after the conjunction's "
    "pataḥ, which MAM's has; the conjunction still marks the tense, and the analysis reads the "
    "regular wayyiqtol."
)
KQ = (
    "MAM has a ketiv and qere here, its ketiv side unpointed; the BHSA has no qere at this slot "
    "and has the ketiv's letters with the qere's vowels, and its analysis is of that pointed word."
)
INITIAL_LENE = (
    "The pointings differ only in a dagesh lene in the first letter, which depends on the atom "
    "before rather than on this word; both spell the analysed word"
)
INTERNAL_LENE = (
    "The BHSA has the dagesh lene that the letter takes after a silent sheva, which MAM's lacks; "
    "both pointings spell the analysed word."
)
VAV_DOT = (
    "The BHSA has a dot (U+05BC) in a consonantal vav followed by the vowel u, which MAM's lacks "
    "and which can be neither a dagesh forte nor a dagesh lene there: the mark that the review's "
    "footnote vav-dot describes, after Yeivin and Dotan, and both pointings spell the analysed "
    "word"
)
HOMONYMS = (
    HATAF_VOCAL[:-1] + ", and the BHSA has this pointing for three homonyms, which it tells apart "
    "by context (Exodus 15:10, Habakkuk 3:16, Nehemiah 13:19)."
)

J = {
    1137: ("variant", HATAF_VOCAL),
    1979: ("variant", "The name's doubled yod is written with two yod letters, and the BHSA has "
           "the dagesh on the first and the qamats on the second where MAM has both on the first; "
           "the same name."),
    2897: ("no-word", "The slot lacks the dagesh forte of the piel's lamed, a letter with a full "
           "vowel here, which MAM's has; the analysis reads the piel that MAM's pointing spells "
           "(WLC 4.18 has the BHSA's, with its note 1)."),
    3524: ("no-word", WAYQ_DAGESH[:-1] + "; its one-vowel neighbour with tsere, {slot|216281}, "
           "is the BHSA's niphal imperfect (Isaiah 11:11), a word with no conjunction (WLC 4.18 "
           "has the BHSA's, with its note 1)."),
    8162: ("variant", HATAF_VOCAL),
    12761: ("variant", HATAF_VOCAL),
    14219: ("variant", HATAF_VOCAL[:-1] + "; MAM's pointing occurs in the BHSA only at Isaiah "
            "51:2, {slot|229875}, analysed as an imperfect because no wayyiqtol's conjunction "
            "precedes it there."),
    16020: ("variant", HATAF_VOCAL),
    16229: ("variant", "The BHSA has segol under the ayin where MAM has pataḥ, as the BHSA has "
            "it in the noun's plural at Ezekiel 31:8, {slot|279917}; another vowel in the same "
            "word, spelling no other (WLC 4.18 has the BHSA's, with its note 1)."),
    16253: ("variant", HATAF_VOCAL),
    17776: ("variant", INTERNAL_LENE),
    21041: ("variant", HATAF_VOCAL),
    21353: ("no-word", "The BHSA's final he lacks the mappiq that the suffix needs, which MAM's "
            "has, and the pointing spells no other word; the analysis reads the suffix (prs H), "
            "as at Genesis 34:11, {slot|18631} (WLC 4.18 has the BHSA's, with its note 1)."),
    28055: ("variant", HATAF_VOCAL),
    33259: ("no-word", HATAF_CLOSED[:-1] + "; the BHSA has the same ḥataf and sheva once more, at "
            "Exodus 8:3, {slot|32442}, and the regular pataḥ six times, as at Genesis 41:24, "
            "{slot|22790}."),
    37043: ("variant", HOMONYMS),
    47643: ("variant", "The BHSA has tsere-yod where MAM has ḥiriq-yod, in the niphal perfect of "
            "a verb with final he, whose first and second persons have either vowel; the same "
            "word (WLC 4.18 has the BHSA's, with its note 1)."),
    54440: ("no-word", "The BHSA's final ayin lacks the furtive pataḥ that MAM's has, a vowel the "
            "word needs after ḥiriq-yod; the analysis reads the regular hiphil imperfect (WLC 4.18 "
            "has the BHSA's, with its note 1)."),
    73853: ("variant", HATAF_VOCAL),
    91380: ("variant", HATAF_VOCAL),
    92201: ("variant", MAM_HATAF),
    98269: ("variant", HATAF_VOCAL),
    98465: ("variant", FULL_FOR_HATAF[:-1] + " (WLC 4.18 has the BHSA's, with its note U)."),
    106611: ("variant", HATAF_VOCAL),
    106752: ("variant", "The BHSA has qamats under the pe, before an alef that takes no dagesh, "
             "where MAM has pataḥ; both spell the piel imperfect, the BHSA's with the lengthened "
             "vowel usual in the piel of a verb whose middle letter is alef."),
    116736: ("no-word", HATAF_CLOSED[:-1] + " (MAM has qamats qatan)."),
    118926: ("variant", KQ),
    130127: ("variant", HATAF_VOCAL),
    131973: ("variant", "The pointings differ in where the ḥolam is: the BHSA, which writes a "
             "ḥolam male as a ḥolam on the letter before the vav, has it on the alef, and MAM has "
             "it on the mem, with the alef silent; the same word (WLC 4.18 has its ḥolam male dot "
             "on the vav, with its note U)."),
    132920: ("unsure", "The BHSA has tsere under the mem before the suffix KM, the vowel of a "
             "masculine plural noun's base before that suffix, so its pointing looks like a "
             "defectively written plural 'your bones', which the BHSA otherwise has only in the "
             "feminine plural, {slot|234728} (Isaiah 66:14, Ezekiel 6:5); the analysis is "
             "singular (nu sg) 'your bone', as MAM's pointing spells it and as the parallel 'your "
             "flesh' suits, and the ETCBC's segmentation puts the tsere in the lexeme with no "
             "nominal ending (WLC 4.18 has the BHSA's pointing, with its note U)."),
    137248: ("no-word", "The BHSA's resh lacks the pataḥ that MAM's has, leaving a ḥataf pataḥ "
             "and two sheva marks in a row, which no word has; the analysis reads the qal perfect "
             "with suffix that MAM's pointing spells (the review's class c case; WLC 4.18 has the "
             "BHSA's, with its note U)."),
    137585: ("variant", HATAF_VOCAL),
    144406: ("no-word", WAYQ_DAGESH[:-1] + " (WLC 4.18 has the BHSA's, with its note 1)."),
    146028: ("variant", "The BHSA has pataḥ under the qof, after the preposition's assimilated "
             "nun, where MAM has the sheva of the construct plural, which the BHSA has at Proverbs "
             "30:24, {slot|355403}; another vowel in the same word, spelling no other (WLC 4.18 has "
             "the BHSA's, with its note 1)."),
    151471: ("no-word", "The BHSA has a sheva under the prefix where the niphal wayyiqtol has the "
             "ḥiriq that MAM's has, and with the dagesh in the shin the pointing is neither a "
             "niphal nor a piel; the analysis reads the niphal (WLC 4.18 has the BHSA's, with its "
             "note 1)."),
    151713: ("variant", "The BHSA has a dagesh in the lamed, which has a vocal shewa after a "
             "short vowel (a dagesh dirimens), where MAM has none; both spell the noun 'sling' with "
             "suffix, not the slinger, whose plural is {slot|196402} (2 Kings 3:25), though the "
             "BHSA's pointing is also the one a piel infinitive of QL<[ with suffix would have, a "
             "word found nowhere else in the BHSA."),
    156227: ("variant", HATAF_VOCAL),
    156951: ("variant", INTERNAL_LENE),
    157794: ("variant", MAM_HATAF),
    163541: ("variant", MAM_HATAF),
    165715: ("another-word", "The pointing of the mem and the lamed is that of ML>K/ "
             "'messengers', which the BHSA has 17 times one vowel away, with qamats under the "
             "alef, as at Genesis 19:1, {slot|8428}, while the alef here has no vowel, as in MAM's "
             "spelling of 'kings' with an alef; the analysis is MLK/ 'king', MAM's word (the "
             "review's class b case)."),
    178733: ("variant", FULL_FOR_HATAF),
    190079: ("variant", "The BHSA has a sheva in the final tav where MAM has none; both spell the "
             "second feminine singular (ps p2, gn f), whose masculine has qamats in the tav, as the "
             "BHSA has it 11 times, {slot|46737} (Exodus 32:11) (WLC 4.18 has the BHSA's, with its "
             "note 1)."),
    191354: ("variant", FULL_FOR_HATAF),
    196629: ("variant", INITIAL_LENE + " (the BHSA's atom before it is a ketiv, unpointed, ending "
             "in a yod)."),
    204455: ("variant", "The BHSA has a sheva in the final lamed before the maqaf, which MAM's "
             "lacks; it changes neither the sounds nor the analysis of this uncertain noun, whose "
             "voc_lex_utf8 in the BHSA has the same sheva."),
    205648: ("variant", "The BHSA has pataḥ under the ayin and a silent sheva under the tsade, the "
             "regular spelling when the qal imperfect's ḥataf pataḥ stands before a vocal shewa, "
             "where MAM has a silent sheva under the ayin and a vocal shewa under the tsade; both "
             "spell the qal wayyiqtol with suffix."),
    206043: ("variant", "The BHSA has tsere-yod where MAM has the hiphil perfect's ḥiriq-yod, a "
             "vowel that this verb class has in the perfect's first and second persons, and the "
             "pointing spells no other word (WLC 4.18 has the BHSA's, with its note 1)."),
    216993: ("variant", INITIAL_LENE + " (the BHSA lacks it after an atom that ends in a "
             "consonant; WLC 4.18 has it, as MAM does)."),
    218239: ("variant", HATAF_VOCAL),
    219509: ("no-word", "The BHSA's suffix he lacks its qamats, which MAM's has, as at Genesis "
             "34:11, {slot|18631}; the analysis reads the suffix (prs H) (the review's class c "
             "case)."),
    227229: ("variant", INITIAL_LENE + "."),
    229058: ("variant", HATAF_VOCAL),
    231700: ("no-word", "The BHSA's yod lacks the ḥiriq of the second feminine singular suffix "
             "on a plural noun, which MAM's has; the analysis reads that suffix (prs K=) on the "
             "plural."),
    231829: ("variant", "The BHSA has a dagesh in the qof, which has a vocal shewa after a short "
             "vowel (a dagesh dirimens), where MAM has none; both pointings spell the qal "
             "imperfect."),
    236379: ("variant", VAV_DOT + " (the review's class c case)."),
    236470: ("variant", VAV_DOT + "."),
    242407: ("no-word", "The BHSA's vav lacks the sheva that MAM's has, so it is neither a "
             "consonant with a vowel or sheva nor a vowel letter; the analysis reads the piel "
             "participle with suffix (prs NJ)."),
    244875: ("variant", HATAF_VOCAL),
    245879: ("variant", HATAF_VOCAL),
    251275: ("variant", HATAF_VOCAL),
    261422: ("no-word", "The BHSA's final he lacks the mappiq of the root's consonant, which MAM's "
             "has, though it has the furtive pataḥ that only a consonant takes; the analysis reads "
             "the hiphil of GBH[, as the BHSA spells it at Obadiah 1:4, {slot|298217}."),
    262081: ("no-word", HATAF_DOUBLED),
    264371: ("no-word", "The BHSA's qof and yod lack the dagesh forte that MAM's have and that the "
             "BHSA has at Numbers 4:7, {slot|71889}; the analysis reads the regular noun."),
    264436: ("variant", "The BHSA has pataḥ under the alef where MAM, and the BHSA at every other "
             "place of this noun, have segol; another vowel in the same word."),
    264949: ("no-word", "The BHSA's yod lacks the dagesh forte that MAM's has; the analysis reads "
             "the regular plural with suffix (WLC 4.18 has the BHSA's, with its note 1)."),
    268281: ("variant", HATAF_VOCAL),
    271444: ("variant", "The BHSA has segol where MAM has qamats and the BHSA has pataḥ at Ezekiel "
             "43:13, {slot|287433}; another vowel in the same noun, spelling no other (WLC 4.18 has "
             "the BHSA's, with its note 1)."),
    273249: ("no-word", "The BHSA has a dagesh in the nun after the kaf's silent sheva, which can "
             "be neither a dagesh forte nor a dagesh lene there and which MAM's lacks; the analysis "
             "reads the regular niphal imperfect (WLC 4.18 has the BHSA's, with its note 1)."),
    275784: ("variant", "The BHSA has pataḥ under the prefix where MAM has segol, both of them "
             "qal prefix vowels before this guttural; the BHSA has the pataḥ again at Ezekiel "
             "23:20, {slot|276011}."),
    276851: ("variant", INITIAL_LENE + "."),
    278220: ("no-word", "The BHSA's final kaf lacks the sheva that MAM's has; the analysis reads "
             "the suffix (prs K=) (WLC 4.18 has the BHSA's, with its note 1)."),
    278253: ("variant", FULL_FOR_HATAF[:-1] + " (WLC 4.18 has the BHSA's, with its note 1)."),
    278614: ("variant", "The BHSA has segol under the prefix alef where MAM has the piel's ḥataf "
             "pataḥ; no stem has segol there with a doubled middle letter, so the pointing still "
             "spells the piel."),
    283685: ("no-word", "The BHSA's pointing is neither the piel, whose prefix has sheva, as at "
             "Numbers 5:3, {slot|72765}, nor the hitpael, whose tet has the dagesh forte that MAM's "
             "has, as the BHSA has it at Ezekiel 14:11, {slot|270592}; the analysis reads the "
             "piel, though the BHSA analyses the same pointing pattern without that dagesh as the "
             "hitpael at Hosea 9:4, {slot|292849}."),
    291796: ("variant", KQ),
    292892: ("no-word", "The BHSA's shin lacks the dagesh forte of the article, which MAM's has; "
             "the slot is otherwise the regular defective spelling of CLWM=/ 'reward', and its "
             "one-vowel neighbours, the name Shallum, {slot|204450}, and the piel perfect of CLM[, "
             "{slot|54842}, are words that this pointing does not spell (WLC 4.18 has the BHSA's, "
             "with its note U)."),
    300231: ("variant", HATAF_VOCAL),
    302080: ("no-word", "The BHSA's final kaf lacks the sheva that MAM's has; the analysis reads "
             "the suffix (prs K=) (WLC 4.18 has the BHSA's, with its note U)."),
    303007: ("variant", HOMONYMS),
    306110: ("variant", HATAF_VOCAL),
    308077: ("no-word", HATAF_CLOSED),
    309639: ("no-word", "The BHSA's nun lacks the dagesh forte of the doubled root letter, which "
             "MAM's has and the BHSA has at Psalms 67:2, {slot|321170}; the analysis reads the "
             "regular qal imperfect with suffix (WLC 4.18 has the BHSA's, with its note U)."),
    311929: ("variant", "The BHSA has segol under the lamed where MAM has tsere and the BHSA has "
             "sheva in this uncertain word's other occurrence, Psalms 10:8, {slot|311859}; another "
             "vowel in the same word."),
    312123: ("variant", HATAF_VOCAL),
    313458: ("variant", KQ),
    315594: ("variant", HATAF_VOCAL),
    317909: ("no-word", "The BHSA's sin has a sheva where MAM's has ḥiriq, leaving three sheva "
             "marks in a row from the preposition on, which no word has; the analysis reads the "
             "plural of FPH/ 'lip' with suffix (the review's class c case)."),
    319548: ("variant", HATAF_VOCAL[:-1] + "; the BHSA has the ḥataf again at Psalms 55:22, "
             "{slot|319581}."),
    320050: ("no-word", "The BHSA's participle lacks the dagesh forte of the preposition's "
             "assimilated nun, which MAM's has, and the BHSA has a dagesh in the preposition's own "
             "mem instead; the analysis reads the hitpael participle with suffix."),
    320802: ("variant", HATAF_VOCAL),
    321465: ("variant", "A pointing of the divine name: MAM has a ḥolam that the BHSA's lacks, and "
             "the BHSA has the name with ḥiriq under the vav both without a ḥolam, 270 times, as "
             "{slot|95020} (Deuteronomy 3:24), and with one, 32 times; the same name."),
    322465: ("variant", HATAF_VOCAL),
    322838: ("variant", HATAF_VOCAL),
    323240: ("variant", HATAF_VOCAL),
    324953: ("variant", HATAF_VOCAL),
    326770: ("no-word", "The BHSA has the pataḥ under the yod rather than as the furtive pataḥ "
             "under the final ayin, where MAM has it, leaving a bare ayin after a consonantal yod; "
             "with the pataḥ under the ayin, the BHSA's pointing would be {slot|112254}, which the "
             "BHSA analyses three times as the hiphil perfect (Deuteronomy 33:2, Psalms 50:2, Job "
             "37:15), and the analysis here, an imperative, is by context."),
    328054: ("no-word", "The BHSA has the pataḥ under the yod rather than as the furtive pataḥ "
             "under the final ayin, where MAM has it; the analysis reads the hiphil participle, "
             "which the BHSA spells regularly at Psalms 145:16, {slot|335389}."),
    328750: ("no-word", WAYQ_DAGESH[:-1] + " (WLC 4.18 has the dagesh, as MAM does)."),
    331840: ("no-word", HATAF_DOUBLED),
    332648: ("no-word", HATAF_CLOSED[:-1] + " (MAM has a silent sheva under the ayin)."),
    333058: ("variant", FULL_FOR_HATAF),
    335332: ("variant", HATAF_VOCAL),
    336141: ("variant", HATAF_VOCAL[:-1] + "; its one-vowel neighbour with qamats, {slot|333684}, "
             "is the BHSA's piel imperative (Psalms 134:2), but the tsere spells the perfect."),
    338069: ("no-word", HATAF_CLOSED),
    338329: ("no-word", "The BHSA's pe lacks the dagesh lene that it takes after the tav's silent "
             "sheva, which MAM's has; the analysis reads the regular hitpael imperfect (WLC 4.18 "
             "has the BHSA's, with its note 1)."),
    338834: ("no-word", "The BHSA's final vav lacks the shuruq dot that MAM's has, so the plural "
             "ending has no vowel; the analysis reads the hiphil imperfect plural."),
    340383: ("variant", HATAF_VOCAL[:-1] + "; MAM's pointing is the BHSA's qal imperative at "
             "2 Kings 5:10, {slot|197707}, and also its qere of this adjective at Proverbs 22:11, "
             "{slot|352814}, so it would bear the BHSA's analysis too."),
    340649: ("variant", "The BHSA has a sheva under the kaf before the alef where MAM has none and "
             "has a rafeh on the alef, marking it silent; both pointings spell the piel imperfect "
             "with suffix."),
    340970: ("variant", HATAF_VOCAL),
    341081: ("variant", "The BHSA has segol under the bet where MAM has the qal imperfect's "
             "silent sheva; another vowel in the same word, spelling no other."),
    341682: ("no-word", "The BHSA's lamed has no vowel, where MAM's has qamats; the analysis reads "
             "the qal imperative (WLC 4.18 has the BHSA's, with its note 1)."),
    342356: ("variant", HATAF_VOCAL),
    343476: ("no-word", "The BHSA has a qubuts under the mem as well as the shuruq after the alef, "
             "two vowels for the word's one syllable, where MAM has only the shuruq and a rafeh on "
             "the alef; the analysis reads M>WM/ 'blemish' (the review's class c case; WLC 4.18 has "
             "the BHSA's, with its note 1)."),
    343597: ("variant", HATAF_VOCAL),
    343778: ("variant", HATAF_VOCAL),
    344274: ("variant", HATAF_VOCAL),
    345970: ("variant", INITIAL_LENE + " (the BHSA has it, MAM lacks it)."),
    346313: ("variant", HATAF_VOCAL),
    349073: ("variant", "The BHSA has qamats under the ayin where MAM has the pataḥ of the plural "
             "construct, which the BHSA has at Job 28:6, {slot|342650}; another vowel in the same "
             "word, spelling no other (WLC 4.18 has the BHSA's, with its note V)."),
    349994: ("follows-pointing", "The pointing spells a participle of the stem with a prefixed "
             "tav that the ETCBC calls tif‘al, and the analysis is that stem (vs tif), while MAM's "
             "pointing is the hitpael participle (the review's class a case)."),
    350333: ("variant", INITIAL_LENE + " (the BHSA lacks it; WLC 4.18 has it, as MAM does)."),
    352509: ("variant", "The BHSA has a silent sheva under the ayin, closing the preposition's "
             "syllable, where MAM has a ḥataf pataḥ; both pointings spell the qal infinitive "
             "construct."),
    353199: ("variant", HATAF_VOCAL),
    355323: ("variant", HATAF_VOCAL),
    357659: ("variant", HATAF_VOCAL),
    358497: ("variant", VAV_DOT + ", here with the vav's own qubuts (WLC 4.18 has the BHSA's, "
             "with its note U)."),
    358617: ("no-word", "The BHSA's vav after the qof has a dot (U+05BC) and no vowel, where "
             "MAM's vav has a qubuts, so as written it is either a shuruq with no consonant before "
             "it or a consonantal vav without its vowel; the analysis reads QWYWT/ 'hairlocks' with "
             "suffix (the review's class c case; WLC 4.18 has the BHSA's, with its note U)."),
    359070: ("variant", HATAF_VOCAL),
    363592: ("variant", "MAM has a dagesh in the first letter, a nun, after an atom that ends in "
             "a vowel, which the BHSA's lacks; such a dagesh depends on the atom before rather than "
             "on this word, and both pointings spell the niphal participle (WLC 4.18 has MAM's "
             "dagesh, with its notes Q and p)."),
    364407: ("variant", HATAF_VOCAL),
    366400: ("no-word", HATAF_CLOSED),
    370758: ("no-word", "The BHSA has a dagesh in the tet after the resh's silent sheva, which can "
             "be neither a dagesh forte nor a dagesh lene there and which MAM's lacks; the analysis "
             "reads Aramaic XRVM/ 'magician', whose voc_lex_utf8 in the BHSA has the same dagesh."),
    370865: ("variant", "The BHSA has tsere where MAM has ḥiriq in the peal imperfect; another "
             "vowel in the same word, spelling no other."),
    370916: ("variant", HATAF_VOCAL[:-1] + "; the BHSA has ḥataf segol at Daniel 2:30, "
             "{slot|371156}."),
    371334: ("variant", KQ),
    372011: ("variant", KQ),
    372769: ("variant", KQ),
    372960: ("variant", "The BHSA has the construct's pataḥ under the qof where MAM has qamats; "
             "both spell the noun TQP=/, and the one-vowel neighbour with ḥiriq, {slot|372513}, the "
             "BHSA's peal perfect of TQP[ (Daniel 4:8), is a word that this pointing does not "
             "spell."),
    373385: ("variant", KQ),
    374377: ("variant", HATAF_VOCAL),
    374613: ("variant", KQ),
    374721: ("variant", KQ),
    374969: ("variant", KQ),
    374973: ("variant", HATAF_VOCAL[:-1] + "; the BHSA has ḥataf segol at Daniel 7:7, "
             "{slot|374708}."),
    374977: ("variant", KQ),
    377243: ("variant", HATAF_VOCAL),
    378088: ("variant", HATAF_VOCAL),
    380273: ("variant", "The BHSA has a ḥataf qamats under the he, a guttural, where MAM has "
             "qamats; a reduced vowel for a full one, and both pointings spell the analysed word."),
    382110: ("variant", "MAM has a dagesh in the samekh, which has a vocal shewa after a short "
             "vowel (a dagesh dirimens), where the BHSA has none; both spell the wayyiqtol, whose "
             "prefix nun has the BHSA's dagesh forte, and the neighbour without that dagesh, "
             "{slot|18289}, is the BHSA's imperfect (Genesis 33:12)."),
    383549: ("no-word", "The BHSA has a qubuts under the tav as well as the shuruq after it, two "
             "vowels for one syllable, where MAM has only the shuruq; the analysis reads the qal "
             "passive participle (WLC 4.18 has the BHSA's, with its note U)."),
    383850: ("variant", HATAF_VOCAL),
    384518: ("variant", HATAF_VOCAL[:-1] + "; MAM's pointing is the BHSA's CPWT/ 'yogurt' at "
             "2 Samuel 17:29, {slot|171027}, but here, by context, both pointings are the gate's "
             "name, >CPT/ 'ash pit', as at Nehemiah 3:14, {slot|384523}."),
    385547: ("variant", KQ),
    390199: ("variant", HATAF_VOCAL),
    390200: ("variant", HATAF_VOCAL),
    390965: ("variant", HOMONYMS),
    392395: ("variant", HATAF_VOCAL),
    392724: ("variant", INTERNAL_LENE),
    392950: ("variant", HATAF_VOCAL),
    393712: ("variant", INITIAL_LENE + " (the BHSA lacks it after an atom with a maqaf that ends "
             "in a consonant; WLC 4.18 has it, as MAM does)."),
    397575: ("no-word", HATAF_DOUBLED[:-1] + "; the BHSA has the same ḥataf before the doubled nun "
             "twice more in the defective spelling, as at Jeremiah 29:27, {slot|250096}."),
    397690: ("no-word", "The BHSA's zayin lacks the dagesh forte that MAM's has and that the qubuts "
             "before it needs; the analysis reads the name Uzzia, <ZJ>/, whose voc_lex_utf8 in "
             "the BHSA lacks the same dagesh."),
    397692: ("no-word", HATAF_CLOSED),
    404361: ("variant", HATAF_VOCAL[:-1] + "; its one-vowel neighbour with qamats, {slot|14614}, "
             "is the BHSA's piel infinitive construct (4 times, as at Genesis 28:6), but the tsere "
             "spells the perfect."),
    416604: ("variant", HATAF_VOCAL[:-1] + "; its one-vowel neighbour with qamats, {slot|129982}, "
             "is the BHSA's piel imperative (13 times, as at Judges 5:2), but the tsere spells the "
             "perfect."),
    416895: ("follows-pointing", "The BHSA's construct ending has pataḥ, the ending of MMLKH/ "
             "'kingdom', which the analysis gives; MAM's ending with segol is the pointing that "
             "the BHSA analyses all 11 times as the separate lexeme MMLKT/ 'kingdom', as at "
             "Exodus 19:6, {slot|39163}, so the two analyses differ in the ETCBC's lexeme, not in "
             "meaning."),
    417986: ("variant", HATAF_VOCAL[:-1] + "; the BHSA has the ḥataf six times in the defective "
             "spelling, as at Nehemiah 7:67, {slot|387038}."),
    421764: ("variant", "The BHSA has the dagesh in the prefix yod after the wayyiqtol's "
             "conjunction, which MAM's yod, with its sheva, lacks; the conjunction marks the tense, "
             "and MAM's pointing is the BHSA's imperfect only at Jeremiah 10:4, {slot|239965}, "
             "with no conjunction."),
}

# Rows the report discusses beside the another-word, follows-pointing and unsure rows.
NOTABLE = {283685, 326770}

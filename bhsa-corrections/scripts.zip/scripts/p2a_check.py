"""p2a: context for Test A's last groups and for the candidates (throwaway scratch).

Sub-agent slice p2a of the brief
C:/Users/BenDe/GitRepos/MAM-basics/.novc/commander-session/bhsa-corrections-brief-2026-11-13.md.

Usage (from the MAM-basics root):
  .venv/Scripts/python.exe -I <folder>/scripts/p2a_check.py <folder>

Reads out/30-part2-test-a.txt (lines 259 to 309) and out/32-part2-scan.json. Writes
  out/p2a-groups.txt: each group's words in context (the BHSA's atom, the slot before it,
    MAM's aligned atom, the word's analysis), with an example reference for each analysis of
    the group's pointed key;
  out/p2a-candidates.txt: each candidate verse word by word, the BHSA's atoms beside MAM's,
    the candidate word's pointed key with examples, the analysed lexeme's spellings, and the
    queries the review cites.

Every form printed is from the data, in MAM-normal mark order (bc_common.mnorm).
"""

import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bc_common as C  # noqa: E402

SHORT_FROM_OSIS = {s.replace(" ", ""): s for s in C.ib_review.SHORT.values()}
ALEF = "\N{HEBREW LETTER ALEF}"
FEATS = (
    "language", "lex", "sp", "vs", "vt", "ps", "nu", "gn", "st", "prs", "nme", "gloss",
    "voc_lex_utf8", "trailer_utf8", "g_word", "pdp", "ls",
)


def fmt(a):
    lang, lex, vs, vt = a
    return "%s%s%s" % ("Aram " if lang == "Aramaic" else "", lex, "" if vs == "NA" else " %s %s" % (vs, vt))


class Ctx:
    """The BHSA's words, their pointed keys and analyses as part2_scan.py counts them, and MAM's
    atoms aligned with the BHSA's."""

    def __init__(self):
        self.B = B = C.Bhsa()
        self.gw, self.qw = B.wf("g_word_utf8"), B.wf("qere_utf8")
        self.f = {n: B.wf(n) for n in FEATS}
        self.typ, self.fun = B.nf("typ"), B.nf("function")
        self.lint = C.load_lint()
        self.key_of = {}
        self.by_key = defaultdict(Counter)
        self.slots_of = defaultdict(list)
        for s in range(1, B.max_slot + 1):
            w = self.gw.get(s, "")
            if s in self.qw or not C.letters(w):
                continue
            k = (self.f["language"][s], C.skey(w))
            self.key_of[s] = k
            a = self.analysis(s)
            self.by_key[k][a] += 1
            self.slots_of[(k, a)].append(s)
        self._verse_cache = {}

    def analysis(self, s):
        f = self.f
        return (f["language"][s], f["lex"][s], f["vs"][s], f["vt"][s])

    def ref(self, s):
        b, ch, v = self.B.ref_of_slot[s]
        return "%s %d:%d" % (C.OSIS_FROM_BHSA[b], ch, v)

    def morph(self, s):
        f = self.f
        parts = []
        if f["vs"][s] != "NA":
            parts.append("%s %s" % (f["vs"][s], f["vt"][s]))
        for n in ("ps", "nu", "gn", "st"):
            if f[n][s] not in ("NA", "unknown"):
                parts.append("%s %s" % (n, f[n][s]))
        if f["prs"][s] not in ("absent", "n/a"):
            parts.append("prs %s" % f["prs"][s])
        if f["nme"][s] not in ("n/a", "", "absent"):
            parts.append("nme %s" % f["nme"][s])
        return " ".join(parts)

    def describe(self, s):
        f = self.f
        p, c = self.B.phrase_of.get(s), self.B.clause_of.get(s)
        return "%d %s%s [%s] | %s %s '%s' | sp %s | %s | phrase %s %s | clause %s%s" % (
            s, C.mnorm(self.gw.get(s, "")), f["trailer_utf8"].get(s, ""), f["g_word"].get(s, ""),
            f["lex"][s], C.mnorm(f["voc_lex_utf8"].get(s, "")), f["gloss"].get(s, ""),
            f["sp"][s], self.morph(s), self.typ.get(p), self.fun.get(p), self.typ.get(c),
            (" | qere %s" % C.mnorm(self.qw[s])) if s in self.qw else "")

    def verse(self, s):
        """(BHSA atoms, MAM atoms, alignment) for the slot's verse."""
        b, ch, v = self.B.ref_of_slot[s]
        osis = C.OSIS_FROM_BHSA[b]
        if (osis, ch, v) not in self._verse_cache:
            where = "%s %d:%d" % (osis, ch, v)
            b_atoms = self.B.atoms(osis, ch, v, "ketiv")
            mam = C.mam_atoms(self.lint, SHORT_FROM_OSIS[osis], ch, v, "ketiv", None, where)
            to_mam = C.align([a["text"] for a in b_atoms], mam)
            self._verse_cache[(osis, ch, v)] = (b_atoms, mam, to_mam)
        return self._verse_cache[(osis, ch, v)]

    def atom_of(self, s):
        """(index, BHSA atom text, MAM's aligned atoms' text)."""
        b_atoms, mam, to_mam = self.verse(s)
        for i, a in enumerate(b_atoms):
            if s in a["slots"]:
                return i, a, " ".join(mam[j] for j in to_mam[i])
        raise ValueError("slot %d in no atom" % s)

    def atom_parts(self, a):
        return " + ".join("%s %s" % (C.mnorm(self.gw.get(t, "")), self.f["lex"][t]) for t in a["slots"])

    def examples(self, k, a, n=3):
        sl = self.slots_of[(k, a)]
        return ", ".join(self.ref(t) for t in sl[:n]) + (" ..." if len(sl) > n else "")

    def key_report(self, k, indent="      "):
        out = []
        for a, cnt in self.by_key[k].most_common():
            out.append("%s%s x%d: %s" % (indent, fmt(a), cnt, self.examples(k, a)))
        return out

    def forms_of(self, keep, indent="      ", n=3, limit=40):
        """The pointed keys of every word that keep(s) accepts, with counts and examples."""
        by = defaultdict(list)
        for s, k in self.key_of.items():
            if keep(s):
                by[(k, self.morph(s))].append(s)
        out = []
        for (k, m), sl in sorted(by.items(), key=lambda kv: -len(kv[1]))[:limit]:
            out.append("%s%s (%s) x%d: %s%s" % (
                indent, C.mnorm(k[1]), m, len(sl), ", ".join(
                    "%s slot %d" % (self.ref(t), t) for t in sl[:n]), " ..." if len(sl) > n else ""))
        return out

    def verse_report(self, osis, ch, v, mark=()):
        out = ["  verse %s %d:%d, word by word:" % (osis, ch, v)]
        for s in self.B.slots(osis, ch, v):
            out.append("   %s %s" % ("*" if s in mark else " ", self.describe(s)))
        b_atoms, mam, to_mam = self.verse(self.B.slots(osis, ch, v)[0])
        out.append("  atoms, the BHSA's (ketiv side) | MAM's aligned atoms:")
        for i, a in enumerate(b_atoms):
            out.append("    %d. %s | %s | MAM %s" % (
                i + 1, C.mnorm(a["text"]), self.atom_parts(a), " ".join(C.mnorm(mam[j]) for j in to_mam[i])))
        return out


def groups_section(X, here):
    lines_txt = (here / "out" / "30-part2-test-a.txt").read_text(encoding="utf-8").split("\n")
    data = json.loads((here / "out" / "32-part2-scan.json").read_text(encoding="utf-8"))
    groups = data["test_a"]
    out = ["Test A, lines 259 to 309 of out/30-part2-test-a.txt (%d lines in the file, %d groups in the JSON)" % (
        len(lines_txt), len(groups)), ""]
    for n in range(259, 310):
        line = lines_txt[n - 1]
        if not line.strip():
            out += ["line %d: empty" % n, ""]
            continue
        g = groups[n - 4]
        slots = [int(x) for x in re.findall(r"slot (\d+)", line)]
        if slots != g["slots"]:
            raise ValueError("line %d does not match group %d" % (n, n - 4))
        k = tuple(g["key"])
        a = tuple(g["analysis"])
        out.append("line %d (group %d of 305) | %s | key %s %s | this: %s x%d" % (
            n, n - 3, g["kind"], k[0], C.mnorm(k[1]), fmt(a), len(slots)))
        out.append("    the key's analyses:")
        out += X.key_report(k, "      ")
        for s in slots:
            i, atom, mam_atom = X.atom_of(s)
            prev = s - 1
            out.append("    %s slot %d: BHSA atom %s (%s) | MAM atom %s" % (
                X.ref(s), s, C.mnorm(atom["text"]), X.atom_parts(atom), C.mnorm(mam_atom)))
            out.append("      slot before: %s" % X.describe(prev))
            out.append("      this slot:   %s" % X.describe(s))
            out.append("      slot after:  %s" % X.describe(s + 1))
        out.append("")
    (here / "out" / "p2a-groups.txt").write_text("\n".join(out) + "\n", encoding="utf-8", newline="\n")
    print("wrote out/p2a-groups.txt")


CANDIDATES = [
    ("1Sam", 27, 10, ">L=="),
    ("Job", 24, 25, ">L=/"),
    ("2Sam", 6, 1, ">SP["),
    ("Mic", 1, 15, "BW>["),
    ("Mic", 7, 17, "JR>["),
    ("Isa", 52, 2, "JCB["),
    ("2Chr", 28, 19, "M<L["),
    ("Dan", 12, 13, "JWM/"),
    ("Eccl", 3, 14, "JR>["),
    ("2Chr", 18, 29, "BW>["),
    ("1Kgs", 22, 30, "BW>["),
    ("2Chr", 26, 15, "XZQ["),
    ("2Chr", 2, 8, "GDL["),
]


def candidates_section(X, here):
    f = X.f
    out = []
    found = {}
    for osis, ch, v, lx in CANDIDATES:
        slots = [s for s in X.B.slots(osis, ch, v) if f["lex"][s] == lx]
        found[(osis, ch, v, lx)] = slots
        out.append("== %s %d:%d, lexeme %s: slots %s" % (osis, ch, v, lx, slots))
        out += X.verse_report(osis, ch, v, set(slots))
        for s in slots:
            if s not in X.key_of:
                out.append("  slot %d has no pointed key (a ketiv or no letters)" % s)
                continue
            k = X.key_of[s]
            out.append("  slot %d: pointed key %s %s; its analyses:" % (s, k[0], C.mnorm(k[1])))
            out += X.key_report(k, "      ")
            same = (f["lex"][s], f["vs"][s], f["vt"][s], f["ps"][s], f["nu"][s], f["gn"][s])
            out.append("  the spellings of %s %s %s %s %s %s (every word with this lexeme, stem, tense, person, number, gender):" % same)
            out += X.forms_of(lambda t, same=same: (f["lex"][t], f["vs"][t], f["vt"][t], f["ps"][t], f["nu"][t], f["gn"][t]) == same)
        out.append("")

    def q(title, keep, limit=40):
        out.append("== query: " + title)
        out.extend(X.forms_of(keep, limit=limit))
        out.append("")

    # (a) the negative and its homonyms
    s27 = found[("1Sam", 27, 10, ">L==")][0]
    k27 = X.key_of[s27]
    out.append("== query: the analyses of 1Sam 27:10's pointed key %s, by lexeme and part of speech" % C.mnorm(k27[1]))
    c = Counter((f["lex"][t], f["sp"][t]) for t, k in X.key_of.items() if k == k27)
    for (lx, sp), n in c.most_common():
        ex = [t for t, k in X.key_of.items() if k == k27 and f["lex"][t] == lx][:3]
        out.append("      %s %s x%d: %s" % (lx, sp, n, ", ".join("%s slot %d" % (X.ref(t), t) for t in ex)))
    out.append("")
    q("every word of the lexemes >L=, >L==, >L=/", lambda t: f["lex"][t] in (">L=", ">L==", ">L=/"))
    # (b) gather and add
    q(">SP[ words whose letters have no alef", lambda t: f["lex"][t] == ">SP[" and ALEF not in C.letters(X.gw[t]))
    q(">SP[ qal wayq, every spelling", lambda t: (f["lex"][t], f["vs"][t], f["vt"][t]) == (">SP[", "qal", "wayq"))
    q("JSP[ words whose letters have an alef", lambda t: f["lex"][t] == "JSP[" and ALEF in C.letters(X.gw[t]))
    # (c) bring
    q("BW>[ words whose letters have no alef", lambda t: f["lex"][t] == "BW>[" and ALEF not in C.letters(X.gw[t]))
    q("BW>[ hif impf p1 sg, every spelling", lambda t: (f["lex"][t], f["vs"][t], f["vt"][t], f["ps"][t], f["nu"][t]) == ("BW>[", "hif", "impf", "p1", "sg"))
    # (d) fear and see, third masculine plural, prefix tenses
    q("JR>[ qal impf or wayq, p3 pl m, every spelling",
      lambda t: f["lex"][t] == "JR>[" and f["vs"][t] == "qal" and f["vt"][t] in ("impf", "wayq") and (f["ps"][t], f["nu"][t], f["gn"][t]) == ("p3", "pl", "m"))
    q("R>H[ qal impf or wayq, p3 pl m, every spelling",
      lambda t: f["lex"][t] == "R>H[" and f["vs"][t] == "qal" and f["vt"][t] in ("impf", "wayq") and (f["ps"][t], f["nu"][t], f["gn"][t]) == ("p3", "pl", "m"))
    # (e) sit and captivity
    q("JCB[ qal impv f sg, every spelling", lambda t: (f["lex"][t], f["vs"][t], f["vt"][t], f["gn"][t], f["nu"][t]) == ("JCB[", "qal", "impv", "f", "sg"))
    q("CBJ/, every spelling", lambda t: f["lex"][t] == "CBJ/")
    s52 = found[("Isa", 52, 2, "JCB[")][0]
    k52 = X.key_of[s52]
    out.append("== query: the words of Isa 52:2's pointed key %s, by lexeme and the lexeme of the slot before" % C.mnorm(k52[1]))
    c = Counter((f["lex"][t], f["lex"].get(t - 1)) for t, k in X.key_of.items() if k == k52)
    for (lx, before), n in c.most_common():
        ex = [t for t, k in X.key_of.items() if k == k52 and f["lex"][t] == lx and f["lex"].get(t - 1) == before][:3]
        out.append("      %s after %s x%d: %s" % (lx, before, n, ", ".join("%s slot %d" % (X.ref(t), t) for t in ex)))
    out.append("")
    # (f) trespass
    q("M<L[, every spelling", lambda t: f["lex"][t] == "M<L[")
    q("M<L=/, every spelling", lambda t: f["lex"][t] == "M<L=/")
    # (g) the -in plural
    out.append("== query: Hebrew words with nme JN or JN=, by lexeme")
    c = Counter(f["lex"][t] for t in X.key_of if f["language"][t] == "Hebrew" and f["nme"][t] in ("JN", "JN="))
    for lx, n in c.most_common(60):
        ex = [t for t in X.key_of if f["language"][t] == "Hebrew" and f["nme"][t] in ("JN", "JN=") and f["lex"][t] == lx][:2]
        out.append("      %s x%d: %s" % (lx, n, ", ".join("%s slot %d %s" % (X.ref(t), t, C.mnorm(X.gw[t])) for t in ex)))
    out.append("")
    q("JWM/, every spelling with nme JN or JN=", lambda t: f["lex"][t] == "JWM/" and f["nme"][t] in ("JN", "JN="))
    q("JMJN/, every spelling", lambda t: f["lex"][t] == "JMJN/", limit=12)
    # (h) great, strong, sleep
    q("GDL[ qal infa, every spelling", lambda t: (f["lex"][t], f["vs"][t], f["vt"][t]) == ("GDL[", "qal", "infa"))
    q("XZQ[ qal perf p3 sg m, every spelling", lambda t: (f["lex"][t], f["vs"][t], f["vt"][t], f["ps"][t], f["nu"][t], f["gn"][t]) == ("XZQ[", "qal", "perf", "p3", "sg", "m"))
    q("BW>[ qal impv m sg, every spelling", lambda t: (f["lex"][t], f["vs"][t], f["vt"][t], f["gn"][t], f["nu"][t]) == ("BW>[", "qal", "impv", "m", "sg"))
    (here / "out" / "p2a-candidates.txt").write_text("\n".join(out) + "\n", encoding="utf-8", newline="\n")
    print("wrote out/p2a-candidates.txt")


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    here = Path(sys.argv[1])
    X = Ctx()
    groups_section(X, here)
    candidates_section(X, here)


if __name__ == "__main__":
    main()

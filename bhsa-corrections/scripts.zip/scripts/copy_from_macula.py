"""Copy the MACULA session's BHSA fetches into this folder, checking each feature file.

Throwaway scratch for the brief
C:/Users/BenDe/GitRepos/MAM-basics/.novc/commander-session/bhsa-corrections-brief-2026-11-13.md.

Usage: python -I copy_from_macula.py <macula folder> <this folder> <out log>

Copies, unchanged, every fetched/etcbc-bhsa-* folder of the MACULA session's folder into this
folder's fetched/, each into its own new folder. Each copied .tf file of version 2021 is checked
against ETCBC/bhsa's tf/2021 listing at 4db00e21 (fetched/etcbc-bhsa-tf2021-listing): its size
and its Git blob SHA-1 must equal the listing's. A mismatch raises.
"""

import hashlib
import json
import shutil
import sys
from pathlib import Path


def git_blob_sha1(data):
    h = hashlib.sha1()
    h.update(b"blob %d\0" % len(data))
    h.update(data)
    return h.hexdigest()


def main():
    src_root, here, log = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
    src_fetched, dst_fetched = src_root / "fetched", here / "fetched"
    folders = sorted(p for p in src_fetched.iterdir() if p.is_dir() and p.name.startswith("etcbc-bhsa-"))
    lines = ["Copied from %s" % src_fetched.as_posix()]
    for folder in folders:
        dst = dst_fetched / folder.name
        shutil.copytree(folder, dst)  # raises if dst exists
        for f in sorted(dst.iterdir()):
            lines.append("%s/%s %d bytes" % (folder.name, f.name, f.stat().st_size))
    listing = json.loads((dst_fetched / "etcbc-bhsa-tf2021-listing" / "contents.json").read_text(encoding="utf-8"))
    by_name = {e["name"]: e for e in listing}
    lines.append("")
    lines.append("Checked against the tf/2021 listing (size, Git blob SHA-1):")
    for folder in sorted(dst_fetched.iterdir()):
        if not folder.name.startswith("etcbc-bhsa-2021-"):
            continue
        for f in sorted(folder.glob("*.tf")):
            data = f.read_bytes()
            entry = by_name[f.name]
            sha = git_blob_sha1(data)
            ok = entry["size"] == len(data) and entry["sha"] == sha
            lines.append("  %s size %d sha %s %s" % (f.name, len(data), sha, "OK" if ok else "MISMATCH"))
            if not ok:
                raise SystemExit("mismatch: %s" % f)
    log.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
